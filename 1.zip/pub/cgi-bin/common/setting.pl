BEGIN {
#==============================================================================
#
#	アンケート・イベントカレンダー・フィードバック　共通変数群
#
#==============================================================================

#------------------------------------------------------------------------------
#	環境パス
#------------------------------------------------------------------------------
#--- 環境の存在する場所 （フルパスで指定）
$P_PrevApplicationRoot = "/var/www/cgi-bin";

#--- 環境までの相対パスの存在する場所 （フルパスで指定）
$P_PrevHttpRoot = "http://www.glode.co.jp";
#-- SSL対応の、環境までの相対パスの存在する場所 
$P_PrevHttpRoot_Ssl = 'http://www.glode.co.jp';

#--- 内部ドメインとして認識するURL
@P_PrevValidHttpDomain = (
	'http://www.glode.co.jp',
	'https://www.glode.co.jp'
);

#---SendMailパス
$P_SendMail     = "/usr/sbin/sendmail";

#---メールサーバー関連（Windows用）
$P_MailServer   = "mail.glode.co.jp";
#---メールドメイン（Windows用）
$P_MyMailDomain = "glode.co.jp";

#------------------------------------------------------------------------------
#---環境によっては古い Jcode.pm が使用されているためCGI付属のJcode.pmを使用
#------------------------------------------------------------------------------
require $P_PrevApplicationRoot."/Jcode.pm";
Jcode->import();

#------------------------------------------------------------------------------
#	文字コード・Perlバージョン設定ファイル名
#------------------------------------------------------------------------------
$P_SystemDatPath = $P_PrevApplicationRoot . "/system.dat";

#------------------------------------------------------------------------------
#	設定ファイルに定義される値
#------------------------------------------------------------------------------
$P_JcodeSJIS  = "shift_jis";
$P_JcodeUTF8  = "utf-8";
$P_Perlvar_50 = "5.0";
$P_Perlvar_58 = "5.8";

# OS
$P_OS_LINUX   = "/";         # Linux
$P_OS_WINDOWS = "\\";        # Windows

#-------------------------------------------------------------------------------
#	HTTPリファラチェック
#-------------------------------------------------------------------------------
# Refererを確認し、「@P_PrevValidHttpDomain」に設定されているドメインのサイト以
# 外からのアクセスの場合にエラーとする制限です。
# ※ブラウザやパーソナルファイアウォール等の設定でRefererを送信しないように設定
# 　している閲覧者からのアクセスもチェックが行えないためエラーとなります。
# 
# 1 = HTTPリファラチェックを有効にします。（デフォルト）
# 0 = HTTPリファラチェックを無効にします。
$ENABLE_REFERER_CHECK = 1;

#------------------------------------------------------------------------------
#	ページID毎　設定ファイルパス
#------------------------------------------------------------------------------
#■■■■■■■■■■■■■■■■■■■■■■■■■■
#---アンケートフォーム
#■■■■■■■■■■■■■■■■■■■■■■■■■■
#メールアドレス設定ファイル　ファイルパス
$P_QuestionSettingMail  = "/home/example/question/mail";
#メールアドレス設定ファイル　ファイル拡張子
$P_QuestionSettingExt   = ".dat";
#CSVファイル保存先フォルダ名(アンケート)
$P_QuestionSaveCSV      = "/home/example/question/csv";
#テンプレートファイル名
$P_QuestionConfim       = $P_PrevApplicationRoot . "/templates/question01/confirm.tpl";         #アンケートフォーム 確認画面テンプレート
$P_QuestionComplete     = $P_PrevApplicationRoot . "/templates/question01/complete.tpl";        #アンケートフォーム 完了画面テンプレート
$P_QuestionErr          = $P_PrevApplicationRoot . "/templates/question01/error.tpl";           #アンケートフォーム エラー画面テンプレート
$P_QuestionMailConfim   = $P_PrevApplicationRoot . "/templates/question02/confirm.tpl";         #メールフォーム     確認画面テンプレート
$P_QuestionMailComplete = $P_PrevApplicationRoot . "/templates/question02/complete.tpl";        #メールフォーム     完了画面テンプレート
$P_QuestionMailErr      = $P_PrevApplicationRoot . "/templates/question02/error.tpl";           #メールフォーム     エラー画面テンプレート
$P_QuestionMailBody     = $P_PrevApplicationRoot . "/templates/question02/return_mail.tpl";     #メールフォーム     メール本文テンプレート

#問い合わせフォームからのメール送信元を入力されたメールアドレスにするかのフラグ
$P_QuestionMailFlg      = 0;	#設定ファイルのアドレスを送信元にする（0）、入力値を送信値にする（1）

#問い合わせフォーム CSV出力機能 -----

# 出力機能の On(1)／Off(0)
$P_SaveCsvOutPutFlg = 1;

# 出力文字コード ※ "sjis" or "utf8"
$P_SaveCsvCharSet   = 'sjis';

#お問い合わせ自動返信機能

#自動返信メールタイトル
$P_ReturnMailSubject = '【XX市】お問い合わせを受け付けました';
#自動返信メール送信元
$P_MailFromAddress = 'system_info@cms8341.jp';
#アクセスログの保存先
$P_LimitLogSaveDir = "/example/question/log";
#常に制限を行なうアクセス元情報
@P_LimitRemotoHost = (
);
#連続送信制限（指定した時間（秒）を経過しないと再送信不可 0:制限無し）
$P_LimitTime = 300;
#一日の送信数制限（一日に送信できる最大数を指定 0:制限無し）
$P_LimitDay = 10;
#自動返信メールに記載するお問い合わせ先
$P_InformationStr = '' . "\n";

#■■■■■■■■■■■■■■■■■■■■■■■■■■
#---イベントカレンダー
#■■■■■■■■■■■■■■■■■■■■■■■■■■
#CSVファイル保存先フォルダ名
$P_EventCsvDir			= "/home/example/event_cal/csv";
#テンプレートファイル名
$P_EventTplFnm_Month	= $P_PrevApplicationRoot . "/templates/event_cal/month.tpl";		    #イベントカレンダー　月別一覧画面テンプレート
$P_EventTplFnm_Day		= $P_PrevApplicationRoot . "/templates/event_cal/day.tpl";		        #イベントカレンダー　日別一覧画面テンプレート
$P_EventTplFnm_Err		= $P_PrevApplicationRoot . "/templates/event_cal/error.tpl";		    #イベントカレンダー　エラー画面テンプレート
#1ページのイベント表示件数
$P_EventPageNum_Month	= 30;																	#イベントカレンダー　月別一覧イベント表示数
$P_EventPageNum_Day		= 30;																	#イベントカレンダー　日別一覧イベント表示数

#---前の月の文言
$P_PreMonthStr  = "前月";
#---次の月の文言
$P_NextMonthStr = "次月";

# イベントカレンダーCSV固定項目(定型以外)
@P_EventDefaultHeaderCSV = (
	"Title",   # 0 # ページタイトル
	"Link",    # 1 # ページパス
	"SDate",   # 2 # 開催期間(開始)
	"EDate",   # 3 # 開催期間(終了)
	"Cate",    # 4 # カテゴリーコード
	"Outline", # 5 # 
	"Area",    # 6 # 
	"Venue",   # 7 # 
	"Image",   # 8 # 
	"Update",  # 9 # 更新日
);

#日付の表示フォーマット
$P_DATE_PREV_FORMAT = "%Y年%n月%j日（%JP_l）";

#月日の表示フォーマット
$P_EVT_MD_PREV_FORMAT = "%d";

#タイトルの文言
$P_EVT_TITE_STRINGS   = "イベント";

#テーブルのサイズ
$P_EVT_CAL_TBL_SIZE   = "170";

#■■■■■■■■■■■■■■■■■■■■■■■■■■
#---フィードバック
#■■■■■■■■■■■■■■■■■■■■■■■■■■
#CSVファイル保存先フォルダ名
$P_FeedbackSaveCSV	= "/home/example/feedback/csv";
#CSVファイル保存名
$P_FeedbackNameCSV	= "feedback.csv";
# テンプレートファイル名
$P_FeedbackComplete = $P_PrevApplicationRoot . "/templates/feedback/complete.tpl";	#フィードバックフォーム　完了画面テンプレート
$P_FeedbackErr 		= $P_PrevApplicationRoot . "/templates/feedback/error.tpl";		#フィードバックフォーム　エラー画面テンプレート
#入力内容のURLチェックを行う
$P_FeedbackCheckInputURL = TRUE;

#■■■■■■■■■■■■■■■■■■■■■■■■■■
#---ファイル読込み時に自動実行するプログラム
#■■■■■■■■■■■■■■■■■■■■■■■■■■
# 共通関数ファイル
require $P_PrevApplicationRoot . '/common/com_function.pl';
require $P_PrevApplicationRoot . '/common/autorun.pl';

#---end---------------------------------------------------------------------
}
1;
