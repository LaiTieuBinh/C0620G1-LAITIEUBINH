#==============================================================================
# 緊急災害情報用設定ファイル
# 緊急災害情報で使用する定数や設定を定義する
#==============================================================================

BEGIN {
	#------------------------------------------------------------------------------
	# 共通設定ファイル読み込み 
	#------------------------------------------------------------------------------
	require $APPLICATION_ROOT_DIR . '/common/com_setting.pl';
	
	#------------------------------------------------------------------------------
	# セッション管理用のSession.pmを読み込む
	#------------------------------------------------------------------------------
	use lib $APPLICATION_ROOT_DIR . '/common/library'; 
	use CGI::Session;
	# 古いセッションを削除するモジュール
	use CGI::Session::ExpireSessions;
	#------------------------------------------------------------------------------
	# 共通設定
	#------------------------------------------------------------------------------
	# HTTPリファラチェックフラグ (0:チェック無効 / 1:チェック有効)
	our $CONST_ENABLE_REFERER_CHECK_FLG = 1;
	
	#------------------------------------------------------------------------------
	# 緊急災害情報用設定
	#------------------------------------------------------------------------------
	# 内部ドメインとして認識するURL
	our @CONST_VALID_HTTP_DOMAIN = @CONST_VALID_HTTP_INNER_DOMAIN;
	# HTMLファイル保存先フォルダ名
	our $CONST_URGENCY_HTTP_DIR_PATH = $CONST_HTTP_ROOT_DIR_PATH . '/urgency';
	# 公開パス
	our $CONST_URGENCY_HTTP_PUB_DIR = $CONST_HTTP_ROOT_DOMAIN . '/urgency';
	# セッション情報の保存先
	our $CONST_URGENCY_SESSION_DIR = $CONST_PRIVATE_APPLICATION_ROOT_DIR_PATH . '/urgency/session';
	# セッションの持続時間(単位：分)
	our $CONST_URGENCY_SESSION_TIME = '60';
	# CSVファイル保存先フォルダ名
	our $CONST_URGENCY_CSV_DIR_PATH = $CONST_PRIVATE_APPLICATION_ROOT_DIR_PATH . '/urgency/csv';
	# ユーザCSV情報ファイル名
	our $CONST_URGENCY_USER_CSV_FILE_NAME = 'user.csv';
	# ログファイル保存先パス
	our $CONST_URGENCY_LOG_FILE_PATH = $CONST_PRIVATE_APPLICATION_ROOT_DIR_PATH . '/urgency/logs/trace.log';
	
	# テンプレートファイル保存先フォルダ名
	our $CONST_URGENCY_TEMPLATE_DIR_PATH = $CONST_PUBLIC_APPLICATION_ROOT_DIR_PATH . '/templates/urgency';
	# 管理画面各ページのメニューヘッダー
	our $CONST_URGENCY_TEMPLATE_FILE_NAME_MENU_HEADER = 'menu_header.tpl';
	# ログイン画面テンプレートファイル名
	our $CONST_URGENCY_TEMPLATE_FILE_NAME_LOGIN = 'login.tpl';
	# トップ画面テンプレートファイル名
	our $CONST_URGENCY_TEMPLATE_FILE_NAME_TOP = 'top.tpl';
	# ページ一覧テンプレートファイル名
	our $CONST_URGENCY_TEMPLATE_FILE_NAME_LIST = 'list.tpl';
	# エラー画面テンプレートファイル名
	our $CONST_URGENCY_TEMPLATE_FILE_NAME_ERROR = 'error.tpl';
	# ページ作成画面画面テンプレートファイル名
	our $CONST_URGENCY_TEMPLATE_FILE_NAME_ENTRY = 'entry.tpl';
	# ページ作成確認画面テンプレートファイル名
	our $CONST_URGENCY_TEMPLATE_FILE_NAME_CONFIRM = 'confirm.tpl';
	# ページ作成完了画面テンプレートファイル名
	our $CONST_URGENCY_TEMPLATE_FILE_NAME_SUBMIT = 'submit.tpl';
	# HTMLページテンプレートファイル名
	our $CONST_URGENCY_TEMPLATE_FILE_NAME_PAGE = 'page.tpl';
	
	# ロックファイル作成のデフォルト設定
	# ロックファイル作成先
	our $DEFAULT_LOCK_FILE_DIR = $CONST_PRIVATE_APPLICATION_ROOT_DIR_PATH . '/urgency/lock';
	# デフォルトのロックファイル名
	our $DEFAULT_LOCK_FILE_NAME = 'lock.lck';
	# ロックファイル作成リトライ回数
	our $DEFAULT_LOCK_FILE_RETRY_CNT = 10;
	# ロックファイルのタイムアウト（秒）
	our $DEFAULT_LOCK_FILE_TIMEOUT = 30;
	# ファイル作成に失敗した場合のスリープタイム
	our $DEFAULT_LOCK_FILE_WAITTIME = 0.1;
	
	# タイトル必須フラグ(0:OFF、1:ON)
	our $CONST_URGENCY_TITLE_REQUIRED_FLG = 1;
	# 本文必須フラグ(0:OFF、1:ON)
	our $CONST_URGENCY_CONTEXT_REQUIRED_FLG = 1;
	# タイトルの最大文字数(日本語・全半角の英数符号全て1文字としてカウントされる)(off:0)
	our $CONST_URGENCY_TITLE_MAX_LENGTH = 50;
	# 本文の最大文字数(日本語・全半角の英数符号全て1文字としてカウントされる)(off:0)
	our $CONST_URGENCY_CONTEXT_MAX_LENGTH = 1000;
	
	# 画像ファイルの一時的のアップロード先
	our $CONST_URGENCY_UPLOAD_IMAGE_TEMP_DIR = $CONST_HTTP_ROOT_DIR_PATH . '/urgency/images/temp';
	# 画像ファイルのアップロード先
	our $CONST_URGENCY_UPLOAD_IMAGE_DIR = $CONST_HTTP_ROOT_DIR_PATH . '/urgency/images/';
	# 画像ファイルの一時的のアップロード先(HTMLに書き出す時)
	our $CONST_URGENCY_PAGE_IMAGE_TEMP_DIR = $CONST_HTTP_ROOT_DOMAIN . '/urgency/images/temp';
	# 画像ファイルのアップロード先(HTMLに書き出す時)
	our $CONST_URGENCY_PAGE_IMAGE_DIR = $CONST_HTTP_ROOT_DOMAIN . '/urgency/images/';
	# 画像のファイルサイズ上限（KB）
	our $CONST_URGENCY_IMAGE_MAX_SIZE = 15000;
	# 画像のアップロード可能な拡張子
	our @CONST_URGENCY_IMAGE_EXT_OK = ('jpg', 'gif', 'png', 'jpeg', 'bmp');
	
	# SESSIONに保存する項目
	our @CONST_URGENCY_SESSION_HASH = (
		'user_id',
		'auth',
	);
	
	# LOGIN画面のパラメータ項目
	our %CONST_URGENCY_LOGIN_CHECK_PARAMETER_HASH = (
		# パラメータ名
		'user_id' => {},
		'password' => {},
		'session_id' => {},	
	);
	
	# ページの編集->確認->実行までのパラメータ項目
	our %CONST_URGENCY_EDITING_PARAMETER_HASH = (
		'dispMode' => {
			'default' => 'new',
		},
		'file_name' => {},
		'title' => {},
		'context' => {},
		'link1-url' => {},
		'link1-title' => {},
		'link2-url' => {},
		'link2-title' => {},
		'link3-url' => {},
		'link3-title' => {},
		'uploadFile' => {},
		'image-fname' => {},
		'image-del-flg' => {},
		'image-temp-fname' => {},
	);
	
	# 出力するページ内の項目のID
	our $CONST_URGENCY_PUB_PAGE_PARAMETER_ID_UNION = 'urgency_pub_page_';
	# 出力するページ内の項目=>それを囲むタグのID
	our %CONST_URGENCY_PUB_PAGE_PARAMETER_HASH = (
		'title' => $CONST_URGENCY_PUB_PAGE_PARAMETER_ID_UNION . 'title',
		'context' => $CONST_URGENCY_PUB_PAGE_PARAMETER_ID_UNION . 'context',
		'image' => $CONST_URGENCY_PUB_PAGE_PARAMETER_ID_UNION . 'image',
		'link1' => $CONST_URGENCY_PUB_PAGE_PARAMETER_ID_UNION . 'link1',
		'link2' => $CONST_URGENCY_PUB_PAGE_PARAMETER_ID_UNION . 'link2',
		'link3' => $CONST_URGENCY_PUB_PAGE_PARAMETER_ID_UNION . 'link3',
	);

	# 緊急情報ページ情報jsonファイルパス
	our $URGENCY_LIST_FILE_PATH = $CONST_HTTP_ROOT_DIR_PATH . "/shared/system/json/urgency/urgency_list.json";
}
1;
