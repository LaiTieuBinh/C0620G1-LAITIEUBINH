# ------------------------------------------------------------------------------
# ■設定ファイル読込時に自動実行する関数
# 
# グローバル変数に引数（パラメーター）を格納
# 　　・%_POST : POSTメソッドで受け取った値を連想配列に格納
# 　　・%_GET  : GETメソッドで受け取った値を連想配列に格納
# ------------------------------------------------------------------------------

# パラメーター格納用のグローバル変数
our %_GET  = ();
our %_POST = ();

## グローバル変数にパラメータを格納
# 
# @return なし
# 
sub readParseSeparate {
	# パラメータの種類
	my %method_ary = (
		'_GET'  => 'QUERY_STRING', 
		'_POST' => 'CONTENT_LENGTH'
	);
	# パラメータ文字列
	my $query_str = '';
	# パラメータ配列
	my @query_ary = ();
	my $query_one = '';
	my $name  = '';
	my $value = '';
	
	# 引数を取得
	while ((my $method, my $env_key) = each %method_ary) {
		$method  = uc $method;
		$env_key = uc $env_key;
		
		# 取得できない場合はスキップ
		if (!exists $ENV{$env_key}) {
			next;
		}
		# POST値
		if ($env_key eq 'CONTENT_LENGTH') {
			read(STDIN, $query_str, $ENV{$env_key});
		}
		# GET値、他
		else {
			$query_str = $ENV{$env_key};
		}
		
		# パラメータを「&」で分解
		@query_ary = split(/&/, $query_str);
		# パラメータの取得
		foreach $query_one (@query_ary) {
			# 「&」で分解したパラメータを「=（名・値）」で分解
			($name, $value) = split(/=/, $query_one);
			# 値をデコード
			$value =~ tr/+/ /;
			$value =~ s/%([0-9a-fA-F][0-9a-fA-F])/pack("C", hex($1))/eg;
			# グローバル変数に格納
			$$method{$name} .= "\0" if (defined($$method{$name}));
			$$method{$name} .= $value;
		}
	}
	
	return;
}
# 関数を実行
&readParseSeparate();

# イベントカレンダー複数日対応
# 現在日
my @datetime = localtime(time);
our %CONST_NOW_DATATIME = (
	'sec' => $datetime[0],
	'min' => $datetime[1],
	'hour' => $datetime[2],
	'day' => $datetime[3],
	'month' => $datetime[4] + 1,
	'year' => $datetime[5] + 1900,
	'wday' => $datetime[6]
);

# -- EOF -----------------------------------------
1;