package pack_cgicom;
#==============================================================================
#	アンケート・イベントカレンダー・フィードバック　共通関数群
#
#
#==============================================================================

$P_JcodeSJIS = "shift_jis";
$P_JcodeUTF8 = "utf-8";
$P_Perlvar_50 = "5.0";
$P_Perlvar_58 = "5.8";

$test = "";

#==============================================================================
#	現在の時刻を取得する
#
#	【引数】フォーマット形式
#			1:	yyyy/mm/dd hh:mm:ss
#			2:	yyyy年mm月dd hh時mm分ss秒
#
#	【戻値】yyyy/mm/dd hh:mm:ss にフォーマットされた現在の日付時間
#			1	エラーあり
#
#==============================================================================
sub get_noe_datetime
{
	local ($format_type) = @_;

	#---現在の日時を取得する
	#日時取得
	my ( @ltms )	= localtime(time);
	# 現在の年を取得する
	$NowYera  = sprintf( "%2.2d", $ltms[5]-100 );
	$NowYera += 2000;
	# 現在の月を取得する
	$NowMonth = sprintf( "%2.2d", $ltms[4]+1 );
	# 現在の日を取得する
	$NowDDay = sprintf( "%2.2d", $ltms[3] );
	# 現在の時を取得する
	$NowHour = sprintf( "%2.2d", $ltms[2] );
	# 現在の分を取得する
	$NowMin = sprintf( "%2.2d", $ltms[1] );
	# 現在の秒を取得する
	$NowSec = sprintf( "%2.2d", $ltms[0] );

	#フォーマット
	if( $format_type == 2 ){
		$NowDayTime = $NowYera . "年" . $NowMonth . "月" . $NowDDay . "日 " . $NowHour . "時" . $NowMin . "分" . $NowSec . "秒";
	}
	else{
		$NowDayTime = $NowYera . "/" . $NowMonth . "/" . $NowDDay . " " . $NowHour . ":" . $NowMin . ":" . $NowSec;
	}

	return $NowDayTime;

}

#==============================================================================
#	入力項目の格納とチェック
#
#	【引数】$input			フォームから入力された値が格納されている連想配列
#			$setting_jcode	サーバー文字コード
#			$setting_pvar	perlバージョン
#			$item_cnt		入力値数
#			$frm_item		入力値格納先（配列[連想配列]の２次元配列）
#			$err_msg		エラー内容
#
#	【戻値】0	エラーなし
#			1	エラーあり
#
#==============================================================================
sub get_imput_item
{
	local ($input) = shift if @_;
	local($setting_jcode, $setting_pvar, $item_cnt, *frm_item, *err_msg ) = @_;

	#ページ共通のhidden値のチェック
	if(!exists $$input{'page_id'} || length($$input{'page_id'}) <= 0){ $err_msg .= "<li>ページIDが指定されていません。</li>"; }					#ページID 必須チェック
	elsif(!check_numeric($$input{'page_id'})){ $err_msg .= "<li>ページIDに数値以外が指定されています。</li>"; }									#ページID 数値チェック
	if(!exists $$input{'page_title'} || length($$input{'page_title'}) <= 0){ $err_msg .= "<li>ページタイトルが指定されていません。</li>"; }		#ページタイトル 必須チェック
	if($$input{'page_title'} =~ /[\r\n]/gm){ $err_msg .= "<li>ページタイトルに改行が指定されています。</li>"; }		#ページタイトル 改行チェック（メールヘッダ・インジェクション）
	if(!exists $$input{'page_url'} || length($$input{'page_url'}) <= 0){ $err_msg .= "<li>ページURLが指定されていません。</li>"; }				#ページURL 必須チェック
	elsif(!check_h_alphanumeric($$input{'page_url'})){ $err_msg .= "<li>ページURLに使用できない記号が指定されています。</li>"; }				#ページURL 英数記号チェック
	elsif(!is_valid_url($$input{'page_url'})){ $err_msg .= "<li>ページURLに使用できないURLが指定されています。</li>"; }							#ページURL 有効ドメインチェック
	if(!exists $$input{'item_cnt'} || length($$input{'item_cnt'}) <= 0){ $err_msg .= "<li>項目数が指定されていません。</li>"; }					#項目数 必須チェック
	elsif(!check_numeric($$input{'item_cnt'})){ $err_msg .= "<li>項目数に数値以外が指定されています。</li>"; }									#項目数 必須チェック

	for ($idx = 1; $idx <= $item_cnt; $idx++) {
		#フォームアイテムの格納
		push @frm_item,{ 
			"title"			=> $$input{'label_'.$idx},			#項目名
			"value"			=> $$input{'item_'.$idx},			#Form値
			"check"			=> $$input{'nes_'.$idx},			#必須(1)or省略可(0)
			"mail"			=> $$input{'mail_'.$idx},			#メールアドレス(1)orメールアドレスでない(0)
			"reply_mail"	=> $$input{'reply_mail_'.$idx},		#自動返信する(1)or自動返信しない(0)
			"desc_mail"		=> $$input{'desc_mail_'.$idx},		#自動返信メールに記載する(1)or自動返信メールに記載しない(0)
			"img"			=> $$input{'img_'.$idx},			#画像
			"img_alt"		=> $$input{'img_alt_'.$idx},		#画像ALT
			"d_title"		=> "",								#表示用項目名
			"d_value"		=> "",								#表示用From値
			"d_title_ret"	=> "",								#表示用項目名(改行変換はなし）
			"d_value_ret"	=> "",								#表示用From値(改行変換はなし）
		};
		#行末の改行コードや空白を取り去る
		$frm_item[$idx-1]->{'title'} =~ s/\s*$//;
		$frm_item[$idx-1]->{'value'} =~ s/\s*$//;
		$frm_item[$idx-1]->{'title'} =~ s/\0/,/g;
		$frm_item[$idx-1]->{'value'} =~ s/\0/,/g;
		#表示用エスケープ処理
		$frm_item[$idx-1]->{'d_title'} = &html_escapr($frm_item[$idx-1]->{'title'});
		$frm_item[$idx-1]->{'d_title_ret'} = &html_escapr($frm_item[$idx-1]->{'title'});
		$frm_item[$idx-1]->{'d_value'} = &html_escapr($frm_item[$idx-1]->{'value'});
		$frm_item[$idx-1]->{'d_value_ret'} = &html_escapr($frm_item[$idx-1]->{'value'});
		#改行変換
		$frm_item[$idx-1]->{'d_title'} = &html_escapr_ret($frm_item[$idx-1]->{'d_title'});
		$frm_item[$idx-1]->{'d_value'} = &html_escapr_ret($frm_item[$idx-1]->{'d_value'});
		#「"」対策
		$frm_item[$idx-1]->{'title'} =~ s/"/\\"/g;
		$frm_item[$idx-1]->{'value'} =~ s/"/\\"/g;
		#項目名チェック
		if( length($frm_item[$idx-1]->{'title'}) <= 0 ){
			$err_msg = $err_msg . "<li>項目名称が指定されていません。(item_$idx)</li>";
		}
		#hidden項目の妥当性チェック
		elsif ($frm_item[$idx-1]->{'check'} ne "" && ! &check_numeric($frm_item[$idx-1]->{'check'} ) ) {
			$err_msg = $err_msg . "<li>必須チェックに数値以外が指定されています。(item_$idx)</li>";
		}
		elsif ($frm_item[$idx-1]->{'mail'} ne "" && ! &check_numeric($frm_item[$idx-1]->{'mail'} ) ) {
			$err_msg = $err_msg . "<li>メールアドレスチェックに数値以外が指定されています。(item_$idx)</li>";
		}
		else{
			#機種依存チェック
#			if( 1 == &chk_pdc_utf8_sjis($setting_jcode, $frm_item[$idx-1]->{'title'})){
#				$err_item = $frm_item[$idx-1]->{'d_title'};
#				if( $setting_jcode eq $P_JcodeSJIS){	#utf-8に変換する
#					$err_item = &jcode_conv_sjis2utf8($err_item, $setting_pvar);
#				}
#				$err_msg = $err_msg . "<li>項目名称に機種依存文字は入力できません。(label_$idx)</li>";
#			}
			#各項目ごとのhidden値のチェック
			if(!exists $frm_item[$idx-1]->{'check'} || length($frm_item[$idx-1]->{'check'}) <= 0){ $err_msg .= "<li>必須フラグが指定されていません。(nes_$idx)</li>"; }
			elsif(!check_numeric($frm_item[$idx-1]->{'check'})){ $err_msg .= "<li>必須フラグに数値以外が指定されています。(nes_$idx)</li>"; }
			#項目必須チェック
			if( length($frm_item[$idx-1]->{'value'}) > 0 ){
#				#機種依存文字チェック
#				if( 1 == &chk_pdc_utf8_sjis($setting_jcode, $frm_item[$idx-1]->{'value'})){
#					$err_item = $frm_item[$idx-1]->{'d_title'};
#					if( $setting_jcode eq $P_JcodeSJIS){	#utf-8に変換する
#						$err_item = &jcode_conv_sjis2utf8($err_item, $setting_pvar);
#					}
#					$err_msg = $err_msg . "<li>" . $err_item . "に機種依存文字は入力できません。</li>";
#				}
#				else{
					if( $frm_item[$idx-1]->{'mail'} == 1 ){
						if($frm_item[$idx-1]->{'value'} !~ /^([a-zA-Z0-9\.\-\/_\!\#\$\%\&\'\*\+\=\?\^\`\{\|\}\~\(\)\ \[\]\\\<\>\@\:\;\,]{1,})@([a-zA-Z0-9\.\-\/_]{1,})\.([a-zA-Z0-9\.\-\/_]{1,})$/){
							$err_item = $frm_item[$idx-1]->{'d_title'};
							if( $setting_jcode eq $P_JcodeSJIS){	#utf-8に変換する
								$err_item = &jcode_conv_sjis2utf8($err_item, $setting_pvar);
							}
							$err_msg = $err_msg . "<li>" . $err_item . "に入力されたメールアドレスが正しく入力されていません。</li>";
						}
					}
#				}
			}
			else{
				if( $frm_item[$idx-1]->{'check'} == 1 ){
					$err_item = $frm_item[$idx-1]->{'d_title'};
					if( $setting_jcode eq $P_JcodeSJIS){	#utf-8に変換する
						$err_item = &jcode_conv_sjis2utf8($err_item, $setting_pvar);
					}
					$err_msg = $err_msg . "<li>" . $err_item . "の省略はできません。</li>";
				}
			}
		}
	}

	if( length($err_msg) > 0 ){
		return 1;
	}
	else{
		return 0;
	}

}


#==============================================================================
#	機種依存チェック
#
#	【引数】$I_jcode	文字コード
#			$I_str		変換をする文字列
#
#	【戻値】0		機種依存文字がなかった
#			1		機種依存文字が存在した
#
#==============================================================================
sub chk_pdc_utf8_sjis {
    my ($I_jcode, $I_str) = @_;


	if( $I_jcode eq $P_JcodeSJIS){	#utf-8に変換する
		$ret = &chksjis($I_str, length($I_str));
		if(( $ret != 0 ) && ( $ret != 1 )){
			return 1;
		}
	}
	else{
		$wk_str[0] = $I_str;
		if( 1 == &pdc_chk(@wk_str)){
			return 1;
		}
	}

	return 0;

}


sub length_sjis {
	my $str = shift;
	my $cnt = 0;
	while( $str =~ m/
		[\x00-\x7F\xA1-\xDF]|
		[\x81-\x9F\xE0-\xFC][\x40-\x7E\x80-\xFC]
		/gx
	) {
		$cnt++;
	}
	return $cnt;
}

#==============================================================================
#	SJISの文字コードチェック
#
#	【引数】$I_str	変換をする文字列
#			$len	文字長さ
#
#	【戻値】0		ASCII
#			1		sjis 全角文字
#			以外	機種依存・半角カナ・認められない文字
#
#==============================================================================
sub chksjis {
    my ($buf, $len) = @_;

    my $stat; # 最終バイトの状態
    my $rtn; # 返却値
    my ($c, $c1, $i);

    $rtn = 0; # ASCII
    $stat = 0;

	$test = $len . "---" . &length_sjis($buf) . "---";

	#ℓ®㎥㎠㎤㎖㏔㎢㎳
	#SJISコードには存在しない文字の対応。
	#Formから受け取った時点でコードで入ってきてしまうためチェックが難しい。
	#直値にて確認
	if(( $buf =~ /&#8467;/)||( $buf =~ /&#174;/)||( $buf =~ /&#13221;/)||
		( $buf =~ /&#13220;/)||( $buf =~ /&#13206;/)||( $buf =~ /&#13268;/)||( $buf =~ /&#13218;/)||( $buf =~ /&#13235;/)){
		return 9;
	}

	$one_word = "";
	for ($i = 0; $i < $len; $i++) {
		$c = ord(substr($buf, $i, 1));
		$one_word = $one_word . $c;
		$test = $test . "c[" . $c . "(".sprintf("%x",$c).")]";
		if ($stat == 0) { # 文字の1バイト目
			if (($c >= 0x07) && ($c <= 0x0d)) {
				# ctrl
			} elsif (($c >= 0x20) && ($c <= 0x7E)) {
				# ASCII
			} elsif (($c >= 0xA1) && ($c <= 0xDF)) {
				$rtn = $rtn | 2; # JISカナ
			} elsif (($c >= 0x81) && ($c <= 0x9F)) {
				$stat = 1; # JIS漢字(81-9F)
				$c1 = $c;
				$rtn = $rtn | 1;
			} elsif (($c >= 0xE0) && ($c <= 0xEF)) {
				$stat = 2; # JIS漢字(E0-EF)
				$c1 = $c;
				$rtn = $rtn | 1;
			} else {
				$rtn = -1; # Not SJIS
				last;
			}
		} elsif ($stat == 1) { # JIS漢字(81-9F)の2バイト目
			if ((($c >= 0x40) && ($c <= 0x7E)) ||
				(($c >= 0x80) && ($c <= 0xFC))) {
				$stat = 0;
				$test = $test . "(1)";
				$test = $test . "c1[" . $c1 . "(".sprintf("%x",$c1).")]";
				if (($c1 == 0x87) && ($c < 0x9E)) {
					$rtn = $rtn | 4; # JIS漢字(NEC拡張外字)
					$test = $test . "(11)";
				} elsif (($c1 >= 0x85) && ($c1 <= 0x87)) {
					$rtn = $rtn | 8; # JIS漢字(機種依存)
					$test = $test . "(12)";
				} elsif (($c1 == 0x88) && ($c < 0x9E)) {
					$rtn = $rtn | 8; # JIS漢字(機種依存)
					$test = $test . "(13)";
				} elsif (($c == 0xE6) || ($c == 0xE7) || ($c == 0xDF) || ($c == 0xE0) || ($c == 0xCA) ||
						 ($c == 0xE3) || ($c == 0xDB) || ($c == 0xDA) || ($c == 0xBF) || ($c == 0xBE)) {
					if( $c1 == 0x81){
						$rtn = $rtn | 8; # JIS漢字(機種依存)
						$test = $test . "(14)";
					}
				}
			} else {
				$test = $test . "(15)";
				$rtn = -1; # Not SJIS
				last;
			}
		} else { # JIS漢字(E0-EF)の2バイト目
			if ((($c >= 0x40) && ($c <= 0x7E)) ||
				(($c >= 0x80) && ($c <= 0xFC))) {
				$stat = 0;
				$test = $test . "(2)";
				$test = $test . "c1[" . $c1 . "(".sprintf("%x",$c1).")]";
				if (($c1 >= 0xED) && ($c1 <= 0xEE)) {
					$rtn = $rtn | 4; # JIS漢字(NEC拡張外字)
				} elsif (($c1 >= 0xEB) && ($c1 <= 0xEF)) {
					$rtn = $rtn | 8; # JIS漢字(機種依存)
				}
			} else {
				$rtn = -1; # Not SJIS
				last;
			}
		}
	}

	#®・㎠対策
	if(( $one_word =~ /3811410110359/)||( $one_word =~ /3835495150495459/)){
		return 10;
	}

	$test = $test . "<br>[[[" . $one_word . "]]]";

	return($rtn);

}

#==============================================================================
#	SJISからUTF-8への文字コードの変換
#
#	【引数】$I_str		変換をする文字列
#			$I_perlver	Perlバージョン
#
#	【戻値】変換された文字列
#
#
#==============================================================================
sub jcode_conv_sjis2utf8
{
	local( $I_str, $I_perlver ) = @_;

	Jcode::convert( \$I_str, "utf8", "CP932" );

	return $I_str;

}

#==============================================================================
#	UTF-8からSJISへの文字コードの変換
#
#	【引数】$I_str		変換をする文字列
#			$I_perlver	Perlバージョン
#
#	【戻値】変換された文字列
#
#
#==============================================================================
sub jcode_conv_utf82sjis
{
	local( $I_str, $I_perlver ) = @_;

	Jcode::convert( \$I_str, "CP932", "utf8" );

	return $I_str;

}


#==============================================================================
#	環境設定ファイルの読み込み
#
#	【引数】$I_fnm		ファイル名（フルパス）
#			$O_jcode	取得した文字コード
#			$O_perlver	取得したPerlバージョン
#
#	【戻値】1	設定ファイル読み込み失敗
#			0	正常終了
#
#
#==============================================================================
sub get_setting
{
	local( $I_fnm, *O_jcode, *O_perlver ) = @_;

	#---設定ファイルの読み込み
	open (IN,"$I_fnm") || die return 1;
	eval{flock(IN,1)};
	#ファイル内容の取得
	$set_cnt = 0;
	while ($value = <IN>){
		if( $set_cnt == 0 ){
			$O_jcode = $value;		#文字コード
			$O_jcode =~ s/"//g;		#テキストが""で囲まれている
			$O_jcode =~ s/\s*$//;
		}
		if( $set_cnt == 1 ){
			$O_perlver = $value;		#パールバージョン
			$O_perlver =~ s/"//g;		#テキストが""で囲まれている
			$O_perlver =~ s/\s*$//;
		}
		$set_cnt = $set_cnt + 1;
	}	
	close(IN);

	return 0;

}

#==============================================================================
#	サーバー文字コードとPerlバージョンの取得
#
#	【引数】$I_lockfnm	ロックファイル名
#			$I_sysfnm	システム設定ファイル名
#			$I_tmpnm	テンプレートファイル名
#			$O_jcode	取得した文字コード
#			$O_perlver	取得したPerlバージョン
#
#	【戻値】なし
#
#
#==============================================================================
sub get_server_setting
{
	local( $I_lockfnm, $I_sysfnm, $I_tmperr, *O_jcode, *O_perlver ) = @_;

#	$arr_err['jcode'] = "";
#	$arr_err['perlver'] = "";
#	$arr_err['page_title'] = "システムエラー";
#	$arr_err['page_url'] = "javascript:history.back()";
#	$arr_err['error'] = "";
#	$arr_err['tmp_fnm'] = $I_tmperr;
#	$arr_err['del_fnm'] = "";

	#エラー画面表示用連想配列の作成
	my %arr_err = (
		"tmp_fnm"		=> $I_tmperr,
		"jcode"			=> "",
		"perlver"		=> "",
		"page_title"	=> "システムエラー",
		"page_url"		=> "javascript:history.back()",
		"error"			=> "",
		"del_fnm"		=> "",
	);

	$O_jcode = "";
	$O_perlver = "";
	if( 0 != &file_lock('ON', $I_lockfnm)){
		$arr_err{'error'} = "<li>lock fatal</li>";
#		&disp_error($arr_err);
		&disp_error(\%arr_err);
	}
	if( 1 == &get_setting($I_sysfnm, *O_jcode, *O_perlver)){
#		&file_lock('OFF', $I_lockfnm);
		$arr_err{'error'} = "<li>read setting fatal</li>";
		$arr_err{'del_fnm'} = $I_lockfnm;
#		&disp_error($arr_err);
		&disp_error(\%arr_err);
	}
	if( 0 != &pack_cgicom'file_lock('OFF', $I_lockfnm)){
		$arr_err{'error'} = "<li>unlock fatal</li>";
		$arr_err{'del_fnm'} = $I_lockfnm;
#		&disp_error($arr_err);
		&disp_error(\%arr_err);
	}

}


#==============================================================================
#	ロックファイル作成
#
#	【引数】ファイルロック	"ON" or "OFF"
#			ロックファイル名
#
#	【戻値】n	何らかの理由で失敗をした
#			0	正常終了
#
#==============================================================================
sub file_lock
{

	#---ロックファイル名
	$strLookFnm = $_[1];

	$err_flg = 0;

	if($_[0] eq 'ON'){
		$flg = 0;
		foreach(1 .. 5){
			if(-e $strLookFnm){sleep(1);}
			else{
				if(!open(LOCK,">$strLookFnm")){
					$err_flg = 1;		#作成不可
					last;
				}
				close(LOCK);
				$flg = 1;
				last;
			}
		}
		if(!$flg){
			$err_flg = 2;	#タイムオーバー
		}
	}
	else{
		if(-e $strLookFnm){
			unlink($strLookFnm);
		}
	}
	
	return $err_flg;
	
	
}


#==============================================================================
#	タグの無効化
#
#	【引数】無効化を行なう文字列
#
#	【戻値】タグが無効化された文字列
#
#	【備考】< > & " ' をそれぞれ文字列に変換する
#
#	【作成】06/11/09 表示文字、入力文字のタグを無効にするため
#
#==============================================================================
sub html_escapr
{
	local( $InStr ) = @_;

	$InStr =~ s/&/&amp;/g;		#& → &amp;
	$InStr =~ s/</&lt;/ig;		#< → &lt;
	$InStr =~ s/>/&gt;/ig;		#> → &gt;
	$InStr =~ s/"/&quot;/g;		#" → &quot;
	$InStr =~ s/'/&#39;/g;		#' → &#39;

	$InStr =~ s/\0/,/g;


	return $InStr;

}

#==============================================================================
#	改行コードのHTMLタグ化 \n → <BR>
#
#	【引数】タグ化を行なう文字列
#
#	【戻値】タグが無効化された文字列
#
#	【備考】改行コードを<BR>に変換する
#
#	【作成】06/11/09 表示文字、入力文字のタグを無効にするため
#
#==============================================================================
sub html_escapr_ret
{
	local( $InStr ) = @_;

	$InStr =~ s/\r\n/\n/g;
	$InStr =~ s/\n/<br>/g;

	return $InStr;

}

#==============================================================================
#	タグのデコード
#
#	【引数】無効化を解除する文字列
#
#	【戻値】タグが有効となった文字列
#
#	【備考】< > & " ' をそれぞれ文字列から直値に変換する
#
#==============================================================================
sub html_decode
{
	local( $InStr ) = @_;

	$InStr =~ s/&amp;/&/g;		#& → &amp;
	$InStr =~ s/&lt;/</ig;		#< → &lt;
	$InStr =~ s/&gt;/>/ig;		#> → &gt;
	$InStr =~ s/&quot;/"/g;		#" → &quot;
	$InStr =~ s/&#39;/'/g;		#' → &#39;

	return $InStr;

}


#==============================================================================
#	機種依存文字をチェック
#
# 【引数】	チェックする文字列
#
# 【戻値】	0	機種依存文字がない場合
#			1	機種依存文字が含まれる場合
#
#==============================================================================
sub pdc_chk {

	# ** 引数を変数に代入 ** #
	# チェックする文字
	@_chk_Str = @_;

	# 機種依存文字
	@_pdc_Str = (
		#半角片仮名
		"｡" , "｢" , "｣" , "､" , "･" , "ｦ" ,
		"ｧ" , "ｨ" , "ｩ" , "ｪ" , "ｫ" , "ｬ" ,
		"ｭ" , "ｮ" , "ｯ" , "ｰ" , "ｱ" , "ｲ" ,
		"ｳ" , "ｴ" , "ｵ" , "ｶ" , "ｷ" , "ｸ" ,
		"ｹ" , "ｺ" , "ｻ" , "ｼ" , "ｽ" , "ｾ" ,
		"ｿ" , "ﾀ" , "ﾁ" , "ﾂ" , "ﾃ" , "ﾄ" ,
		"ﾅ" , "ﾆ" , "ﾇ" , "ﾈ" , "ﾉ" , "ﾊ" ,
		"ﾋ" , "ﾌ" , "ﾍ" , "ﾎ" , "ﾏ" , "ﾐ" ,
		"ﾑ" , "ﾒ" , "ﾓ" , "ﾔ" , "ﾕ" , "ﾖ" ,
		"ﾗ" , "ﾘ" , "ﾙ" , "ﾚ" , "ﾛ" , "ﾜ" ,
		"ﾝ" , "ﾞ" , "ﾟ" ,
		#Windowsの機種依存文字
		"①" , "②" , "③" , "④" , "⑤" , "⑥" ,
		"⑦" , "⑧" , "⑨" , "⑩" , "⑪" , "⑫" ,
		"⑬" , "⑭" , "⑮" , "⑯" , "⑰" , "⑱" ,
		"⑲" , "⑳" , 

		"㍉" , "㌔" , "㌢" , "㍍" , "㌘" , "㌧" ,
		"㌃" , "㌶" , "㍑" , "㍗" , "㌍" , "㌦" ,
		"㌣" , "㌫" , "㍊" , "㌻" , "㎜" , "㎝" ,
		"㎞" , "㎎" , "㎏" , "㏄" , "㎡" , "㍻" ,
		"〝" , "〟" , "№" , "㏍" , "℡" , "㊤" ,
		"㊥" , "㊦" , "㊧" , "㊨" , "㈱" , "㈲" ,
		"㈹" , "㍾" , "㍽" , "㍼" , "≒" , "≡" ,
		"∫" , "∮" , "∑" , "√" , "⊥" , "∠" ,
		"∟" , "⊿" , "∵" , "∩" , "∪" ,
		#NECのIBM拡張文字
		       "褜" , "鍈" , "銈" , "蓜" , "俉" ,
		"炻" , "昱" , "棈" , "鋹" , "曻" , "彅" ,
		"丨" , "仡" , "仼" , "伀" , "伃" , "伹" ,
		"佖" , "侒" , "侊" , "侚" , "侔" , "俍" ,
		"偀" , "倢" , "俿" , "倞" , "偆" , "偰" ,
		"偂" , "傔" , "僴" , "僘" , "兊" , "兤" ,
		"冝" , "冾" , "凬" , "刕" , "劜" , "劦" ,
		"勀" , "勛" , "匀" , "匇" , "匤" , "卲" ,
		"厓" , "厲" , "叝" , "﨎" , "咜" , "咊" ,
		"咩" , "哿" , "喆" , "坙" , "坥" , "垬" ,
		"埈" , "埇" , "﨏" , "塚" , "增" , "墲" ,
		"夋" , "奓" , "奛" , "奝" , "奣" , "妤" ,
		"妺" , "孖" , "寀" , "甯" , "寘" , "寬" ,
		"尞" , "岦" , "岺" , "峵" , "崧" , "嵓" ,
		"﨑" , "嵂" , "嵭" , "嶸" , "嶹" , "巐" ,
		"弡" , "弴" , "彧" , "德" ,
		"忞" , "恝" , "悅" , "悊" , "惞" , "惕" ,
		"愠" , "惲" , "愑" , "愷" , "愰" , "憘" ,
		"戓" , "抦" , "揵" , "摠" , "撝" , "擎" ,
		"敎" , "昀" , "昕" , "昻" , "昉" , "昮" ,
		"昞" , "昤" , "晥" , "晗" , "晙" , "晴" ,
		"晳" , "暙" , "暠" , "暲" , "暿" , "曺" ,
		"朎" , "朗" , "杦" , "枻" , "桒" , "柀" ,
		"栁" , "桄" , "棏" , "﨓" , "楨" , "﨔" ,
		"榘" , "槢" , "樰" , "橫" , "橆" , "橳" ,
		"橾" , "櫢" , "櫤" , "毖" , "氿" , "汜" ,
		"沆" , "汯" , "泚" , "洄" , "涇" , "浯" ,
		"涖" , "涬" , "淏" , "淸" , "淲" , "淼" ,
		"渹" , "湜" , "渧" , "渼" , "溿" , "澈" ,
		"澵" , "濵" , "瀅" , "瀇" , "瀨" , "炅" ,
		"炫" , "焏" , "焄" , "煜" , "煆" , "煇" ,
		"凞" , "燁" , "燾" , "犱" ,
		       "猤" , "猪" , "獷" , "玽" , "珉" ,
		"珖" , "珣" , "珒" , "琇" , "珵" , "琦" ,
		"琪" , "琩" , "琮" , "瑢" , "璉" , "璟" ,
		"甁" , "畯" , "皂" , "皜" , "皞" , "皛" ,
		"皦" , "益" , "睆" , "劯" , "砡" , "硎" ,
		"硤" , "硺" , "礰" , "礼" , "神" , "祥" ,
		"禔" , "福" , "禛" , "竑" , "竧" , "靖" ,
		"竫" , "箞" , "精" , "絈" , "絜" , "綷" ,
		"綠" , "緖" , "繒" , "罇" , "羡" , "羽" ,
		"茁" , "荢" , "荿" , "菇" , "菶" , "葈" ,
		"蒴" , "蕓" , "蕙" , "蕫" , "﨟" , "薰" ,
		"蘒" , "﨡" , "蠇" , "裵" , "訒" , "訷" ,
		"詹" , "誧" , "誾" , "諟" , "諸" , "諶" ,
		"譓" , "譿" , "賰" , "賴" , "贒" , "赶" ,
		"﨣" , "軏" , "﨤" , "逸" , "遧" , "郞" ,
		"都" , "鄕" , "鄧" , "釚" ,
		"釗" , "釞" , "釭" , "釮" , "釤" , "釥" ,
		"鈆" , "鈐" , "鈊" , "鈺" , "鉀" , "鈼" ,
		"鉎" , "鉙" , "鉑" , "鈹" , "鉧" , "銧" ,
		"鉷" , "鉸" , "鋧" , "鋗" , "鋙" , "鋐" ,
		"﨧" , "鋕" , "鋠" , "鋓" , "錥" , "錡" ,
		"鋻" , "﨨" , "錞" , "鋿" , "錝" , "錂" ,
		"鍰" , "鍗" , "鎤" , "鏆" , "鏞" , "鏸" ,
		"鐱" , "鑅" , "鑈" , "閒" , "隆" , "﨩" ,
		"隝" , "隯" , "霳" , "霻" , "靃" , "靍" ,
		"靏" , "靑" , "靕" , "顗" , "顥" , "飯" ,
		"飼" , "餧" , "館" , "馞" , "驎" , "髙" ,
		"髜" , "魵" , "魲" , "鮏" , "鮱" , "鮻" ,
		"鰀" , "鵰" , "鵫" , "鶴" , "鸙" , "黑" ,
		"ⅰ" , "ⅱ" , "ⅲ" , "ⅳ" , "ⅴ" , "ⅵ" ,
		"ⅶ" , "ⅷ" , "ⅸ" , "ⅹ" , "￢" , "￤" ,
		"＇" , "＂" ,

		#Shift_JIS 非対応記号 -----------------------------------------------------

		#Windowsの機種依存文字
		"Ⅰ" , "Ⅱ" , "Ⅲ" , "Ⅳ" , "Ⅴ" , "Ⅵ" , "Ⅶ" , "Ⅷ" , "Ⅸ" , "Ⅹ" ,
		#NECのIBM拡張文字
		"纊" , "犾" ,
		#その他
		"ℓ" , "®" ,"㎥" , "㎠" , "㎤" , "㎖" , "㏔" , "㎢" , "㎳" ,
	);

	# 機種依存文字のチェック
	for ($_i = 0 ; $_i < $#_pdc_Str+1 ; $_i ++ ) {
		for ($_j = 0 ; $_j < $#_chk_Str+1 ; $_j ++) {
			if ( $_chk_Str[$_j] =~ /$_pdc_Str[$_i]/ ) {
				# 機種依存文字が存在していれば 1
				return 1;
			}
		}
	}

	# 機種依存文字が存在していなければ 0
	return 0;

}

#==============================================================================
#
#	エラー画面の表示を行う
#
#	【引数】$I_arrErr	エラーページを表示するための連想配列
#				key値	tmp_fnm		テンプレートファイル名
#						jcode		サーバー文字コード
#						perlver		Perlバージョン
#						page_title	ページタイトル
#						page_url	ページURL
#						error		エラー内容
#						del_fnm		削除するファイル（主にロックファイル）が存在した場合に
#									ファイル名を指定する
#
#	【戻値】1	正常に終了することができなかった
#
#==============================================================================
sub disp_error
{
	my $I_arrerr = shift;


	#---引数が指定されていた場合は、指定されたファイルの消去
	if( length($$I_arrerr{'del_fnm'}) > 0){
		unlink($$I_arrerr{'del_fnm'});
	}


	#---文字コードの変更
	$str_pagetitle = $$I_arrerr{'page_title'};
	$str_errmsg = $$I_arrerr{'error'};
	if( $$I_arrerr{'jcode'} eq $P_JcodeSJIS){	#SJISに変換する
		if( length($$I_arrerr{'perlver'}) > 0 ){
			$str_pagetitle = &jcode_conv_utf82sjis($str_pagetitle, $$I_arrerr{'perlver'});	#タイトル
			$str_errmsg = &jcode_conv_utf82sjis($str_errmsg, $$I_arrerr{'perlver'});		#エラー内容
		}
	}
	$str_httproot = "";
	if( length($$I_arrerr{'httproot'}) > 0 ){
		$str_httproot = $$I_arrerr{'httproot'};
	}

	#---念のためエスケープ
#	$I_errmsg = &html_escapr($I_errmsg);

	#---テンプレートの表示
	open(IN,$$I_arrerr{'tmp_fnm'}) || die &disp_error_sub('templates err! (' . $$I_arrerr{'tmp_fnm'} . ')' );
	@Html_Lines = <IN>;
	close(IN);

	#---文字置き換え
	for($idx = 0; $idx < @Html_Lines; $idx++){
		$one_line = $Html_Lines[$idx];
		$one_line =~ s/#page_title#/$str_pagetitle/g;			#ページタイトル
		$one_line =~ s/#page_url#/$$I_arrerr{'page_url'}/g;		#ページURL
		$one_line =~ s/#error#/$str_errmsg/g;					#エラー内容
		$one_line =~ s/#httproot#/$str_httproot/g;					#公開側ルートパス
		$Html_Lines[$idx] = $one_line;
	}

	#---エラー画面表示
	if(( length($$I_arrerr{'perlver'}) > 0 ) && ( $$I_arrerr{'jcode'} eq $P_JcodeSJIS)){
		#SJIS
		print "Content-type: text/html; charset=shift_jis\n\n";
	}
	else{
		#utf-8
		print "Content-type: text/html; charset=utf-8\n\n";
	}

	print @Html_Lines;

	exit;

}

#==============================================================================
#
#	エラー画面の表示を行う（通常のエラーメッセージではない）
#
#	【引数】$I_errmsg	表示するエラーメッセージ
#
#	【戻値】なし
#
#==============================================================================
sub disp_error_sub
{
	local( $I_errmsg ) = @_;

	print "Content-type: text/html\n\n";


print <<EOM;
<html>
<head>
<title>system error</title>
EOM

	print $I_errmsg . '<br>';

print <<EOM;
</body>
</html>
EOM

	exit;

}

#==============================================================================
#
#	日時フォーマットを指定し、日時文字列を作成する
#
#	【引数】$pDT		日時データ （例:「YYYY-mm-dd HH:ii:ss」）
#			$pFormat	日時表示フォーマット （デフォルト:「%Y年%m月%d日」）
#			$pD			日付区切り文字 （デフォルト:「-」）
#			$pT			時間区切り文字 （デフォルト:「:」）
#
#	【戻値】作成した日時文字列
#
#==============================================================================
sub dtFormat{
	#引数の取得
	local($pDT,$pFormat,$pD,$pT) = @_;
	#引数チェック
	if($pFormat eq ""){ $pFormat = '%Y年%m月%d日'; }
	if($pD eq ""){ $pD = '-'; }
	if($pT eq ""){ $pT = ':'; }

	#チェック用正規表現の作成
	$regDate = '(\d{2}|\d{4})' . $pD . '(\d{1,2})' . $pD . '(\d{1,2})';
	$regTime = '(\d{1,2})' . $pT . '(\d{1,2})(' . $pT . '(\d{1,2}))?';
	#日時
	if($pDT =~ /^$regDate $regTime$/o){
		$Y = $m = $d = $H = $i = $s = $pDT;
		$Y =~ s/^$regDate $regTime$/$1/o;
		$m =~ s/^$regDate $regTime$/$2/o;
		$d =~ s/^$regDate $regTime$/$3/o;
		$H =~ s/^$regDate $regTime$/$4/o;
		$i =~ s/^$regDate $regTime$/$5/o;
		$s =~ s/^$regDate $regTime$/$7/o;
	}
	#日付
	elsif($pDT =~ /^$regDate$/o){
		$Y = $m = $d = $pDT;
		$H = $i = $s = 0;
		$Y =~ s/^$regDate$/$1/o;
		$m =~ s/^$regDate$/$2/o;
		$d =~ s/^$regDate$/$3/o;
	}
	#時間
	elsif($pDT =~ /$regTime/o){
		$Y = $m = $d = 0;
		$H = $i = $s = $pDT;
		$H =~ s/$regTime/$1/o;
		$i =~ s/$regTime/$2/o;
		$s =~ s/$regTime/$4/o;
	}
	#その他
	else{ return $pDT; }
	#曜日の出力
	$w = $l = $a = $l_JP = $a_JP = '';
	if($Y ne "" && $m ne "" && $d ne ""){
		$w = getwday($Y,$m,$d);
		SWITCH:{
			if($w == 0){ $l = 'Sunday';			$a = 'Sun';	$l_JP = '日曜日';	$a_JP = '日'; last SWITCH; }
			if($w == 1){ $l = 'Monday';			$a = 'Mon';	$l_JP = '月曜日';	$a_JP = '月'; last SWITCH; }
			if($w == 2){ $l = 'Tuesday';		$a = 'Tue';	$l_JP = '火曜日';	$a_JP = '火'; last SWITCH; }
			if($w == 3){ $l = 'Wednesday';		$a = 'Wed';	$l_JP = '水曜日';	$a_JP = '水'; last SWITCH; }
			if($w == 4){ $l = 'Thursday';		$a = 'Thu';	$l_JP = '木曜日';	$a_JP = '木'; last SWITCH; }
			if($w == 5){ $l = 'Friday';			$a = 'Fri';	$l_JP = '金曜日';	$a_JP = '金'; last SWITCH; }
			if($w == 6){ $l = 'Saturday';		$a = 'Sat';	$l_JP = '土曜日';	$a_JP = '土'; last SWITCH; }
		}
	}
	#置換処理
	%ary = (
		'%Y'		=> '' . sprintf('%04d',$Y),						#西暦4桁
		'%y'		=> '' . substr(('' . sprintf('%04d',$Y)),2),	#西暦2桁
		'%JP_Y'		=> '' . convertJpYear($Y,$m,$d),				#和暦
		'%m'		=> '' . sprintf('%02d',$m),						#月 2桁 (01～12)
		'%n'		=> '' . sprintf('%d',$m),						#月 1～2桁 (1～12)
		'%d'		=> '' . sprintf('%02d',$d),						#日 2桁 (01～31)
		'%j'		=> '' . sprintf('%d',$d),						#日 1～2桁 (1～31)
		'%H'		=> '' . sprintf('%02d',$H),						#時 2桁 (00～23)
		'%i'		=> '' . sprintf('%02d',$i),						#分 2桁 (00～59)
		'%s'		=> '' . sprintf('%02d',$s),						#秒 2桁 (00～59)
		'%w'		=> '' . $w,										#曜日 数値 (0(日曜)～6(土曜))
		'%l'		=> '' . $l,										#曜日 英語 フルスペル (Sunday～Saturday)
		'%a'		=> '' . $a,										#曜日 英語 省略 (Sun～Sat)
		'%JP_l'		=> '' . $l_JP,									#曜日 日本語 全表記 (日曜日～土曜日)
		'%JP_a'		=> '' . $a_JP,									#曜日 日本語 省略表記 (日～土)
	);
	my $ary = join('|',(map{quotemeta} keys %ary));
	$pFormat =~ s/($ary)/$ary{$1}/eg;
	return $pFormat;
}

#==============================================================================
#
#	Zellerの公式で曜日を求める
#
#	【引数】$year	年データ
#			$mon	月データ
#			$day	日データ
#
#	【戻値】曜日を示す数字 0:日～6:土
#
#==============================================================================
sub getwday{
	my $year = shift;	# 年
	my $mon = shift;	# 月
	my $day = shift;	# 日
	
	if($mon == 1 or $mon == 2){
		$year--;
		$mon += 12;
	}
	return ($year + int($year / 4) - int($year / 100) + int($year / 400) + int((13 * $mon + 8) / 5) + $day) % 7;
}

#==============================================================================
#
#	西暦を和暦に変換する
#
#	【引数】$y		年データ
#			$m		月データ
#			$d		日データ
#
#	【戻値】和暦に変換された年
#
#==============================================================================
sub convertJpYear{
	local($y,$m,$d) = @_;
	#年月日を文字列として結合
	$ymd = sprintf("%02d%02d%02d",$y,$m,$d);
	if($ymd <= "19120729"){
		$gg = "明治";
		$yy = $y - 1867;
	}
	elsif($ymd >= "19120730" && $ymd <= "19261224"){
		$gg = "大正";
		$yy = $y - 1911;
	}
	elsif($ymd >= "19261225" && $ymd <= "19890107"){
		$gg = "昭和";
		$yy = $y - 1925;
	}
	elsif($ymd >= "19890108" && $ymd <= "20190430"){
		$gg = "平成";
		$yy = $y - 1988;
	}
	elsif($ymd >= "20190501"){
		$gg = "令和";
		$yy = $y - 2018;
	}
	if ($yy == 1) {
		$yy = '元';
	}
	return $gg . $yy;
}

#==============================================================================
#	
#	CSV出力用に文字列をエスケープ
#	
#	【引数】 $str	エスケープする文字列
#	
#	【戻値】 CSV用にエスケープされた文字列
#	
#==============================================================================
sub csvEscapeStrings{
	# 引数取得
	my ( $str ) = @_;
	
	# 「\"」を「"」に戻す
	$str =~ s/\\"/"/g;
	# 「"」を「""」にエスケープ
	$str =~ s/"/""/g;
	# 「\」を「\\」にエスケープ
	$str =~ s/\\/\\\\/g;
	
	return $str;
}

#==============================================================================
#
#	数値チェック
#
#==============================================================================
sub check_numeric{
	return ( @_[0] =~ /^[0-9]+$/ );
}

#==============================================================================
#
#	半角英数チェック
#
#==============================================================================
sub check_h_alphanumeric{
	return ( @_[0] =~ /^[a-zA-Z0-9]+$/ );
}

#==============================================================================
#
#	半角英数記号チェック
#		許可される記号
#		   # ! % & = @ ; : , _ " ' ~ ` < > 
#		   - + * / . ? { } ( ) [ ] ^ $ @ | \ 
#==============================================================================
sub check_h_alphanumeric{
	return ( @_[0] =~ /^[a-zA-Z0-9#!%&=;:,_"'~`<>\-\+\*\/\.\?\{\}\(\)\[\]\^\@\|\\]+$/ );
}

#==============================================================================
#	メール送信
#	【引数】 $mail_to			メール送信先アドレス
#	         $mail_from			メール送信元アドレス
#	         $mail_subject		メール件名
#	         $mail_body			メール本文
#	【戻値】 メール送信に成功した場合は1、そうでない場合は0を返す
#==============================================================================
sub send_mail{
	#外部ファイル読み込み
	require $main::P_PrevApplicationRoot . '/question/mimew.pl';

	#引数の取得
	my($mail_to,$mail_from,$mail_subject,$mail_body) = @_;

	#Body部の文字コードを変更
	Jcode::convert(\$mail_body,"jis","sjis");

	#現在時間の作成
#	my($wday,$mon,$day,$now_time,$year,) = split(/ /,localtime(time));
#	my($mail_now_datetime) = sprintf("%s, %2d %s %s %s +0900",$wday,$day,$mon,$year,$now_time);

	my @ta = localtime(time());
	my ($year, $mon, $mday, $hour, $min, $sec, $wday) = 
	   ($ta[5] + 1900, $ta[4] + 1, $ta[3], $ta[2], $ta[1], $ta[0], $ta[6]);
	my $wdayname = ("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")[$wday];
	my $monname  = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
	                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")[$mon - 1];
	my $mail_now_datetime = sprintf("$wdayname, $mday $monname $year %02d:%02d:%02d +0900",
	                       $hour, $min, $sec);

	#OSがWindowsの場合は、SMTPを使用してメールを送信する
	if(-d $main::P_OS_WINDOWS){
		#オブジェクトの作成
		use Net::SMTP;
		$smtp = Net::SMTP->new(
			$main::P_MailServer,		#SMTPサーバ
			Hello => $main::P_MyMailDomain,
		) || die return 0;

		#ヘッダ部の組み立て
		$smtp->mail($mail_from);		#送信元の指定
		#宛先が複数ある可能性があるため配列へ分割
		@mail_to_ary = split(/,/,$mail_to);
		$smtp->to(@mail_to_ary);		#宛先の指定

		#メール件名の文字コードを変更
		Jcode::convert(\$mail_subject,"jis","sjis");

		#データ部の組み立て
		$smtp->data();
		$smtp->datasend("From:" . &main::mimeencode($mail_from) . "\n");			#送信元
		$smtp->datasend("To:" . $mail_to . "\n");									#宛先(データ部）
		$smtp->datasend("Subject:" . &main::mimeencode($mail_subject) . "\n");		#件名
		$smtp->datasend("Reply-To:" . &main::mimeencode($mail_from) . "\n");		#返信先
		$smtp->datasend("Date: " . &main::mimeencode($mail_now_datetime) . "\n");	#現在日時
		$smtp->datasend("Content-Transfer-Encoding: 7bit\n");						#タイプ
		$smtp->datasend("Content-Type: text/plain; charset=ISO-2022-JP\n\n");		#タイプ
		$smtp->datasend($mail_body);												#本文

		# データの終わり、メール送信
		$smtp->dataend();
		#SMTP接続の終了
		$smtp->quit; 
	}
	#OSがLinuxの場合は、sendmailを使用してメールを送信する
	else{
		#ヘッダ部の組み立て
		$mail_head =	"To: $mail_to\n" .
						"From: " . &main::mimeencode($mail_from) . "\n" .
						"Reply-To: " . &main::mimeencode($mail_from) . "\n" .
						"Date: " . &main::mimeencode($mail_now_datetime) . "\n" .
						"Subject: " . &main::mimeencode($mail_subject) . "\n" .
						"Content-Transfer-Encoding: 7bit\n" .
						"Content-Type: text/plain; charset=ISO-2022-JP\n\n";
		#Header部の文字コードを変更
		Jcode::convert(\$mail_head,"jis","sjis");

		#メール送信
		open(MAIL,"| $main::P_SendMail -t -i -f " . $mail_from) || die return 0;
		print MAIL $mail_head;
		print MAIL $mail_body;
		close(MAIL);
	}
	#正常終了
	return 1;
}

#==============================================================================
# 正規表現用に文字列をエスケープ
# 
# @param  $_[0] 文字列
# @return $ret  エスケープした文字列
# 
#==============================================================================
sub reg_replace {
	
	# 引数取得
	local $ret = $_[0];
	
	# 文字列のエスケープ
	$ret =~ s/[\\\*\+\.\?\{\}\(\)\[\]\^\$\-\|\/]/\\$&/g;
	
	return $ret;
}

#==============================================================================
# 設定ファイルに設定した有効ドメインかチェック
# 
# @param  $_[0] URL
# @return 1 (有効) | 0 (無効)
# 
#==============================================================================
sub is_valid_url {
	
	# 引数取得
	local $url = $_[0];
	# URLから付加情報を削除
	$url =~ s/\#.*//;
	$url =~ s/\?.*//;
	
	# 有効ドメイン
	local @chk_domain = @main::P_PrevValidHttpDomain;
	
	# 変数初期化
	local $valid_domain = "";
	local $valid_flg = 0;
	
	# チェック開始
	for (local $cnt = 0 ; $cnt < @chk_domain ; $cnt ++) {
		
		# 有効ドメインの設定値を補正
		$valid_domain = $chk_domain[$cnt];
		$valid_domain =~ s/^\s//;
		$valid_domain =~ s/\s$//;
		$valid_domain =~ s/\/$//;
		
		# 補正したドメインが空の場合はチェックなし
		if ($valid_domain eq "") {
			next;
		}
		
		# 正規表現用のエスケープ
		$valid_domain = &reg_replace($valid_domain);
		
		# チェック
		if ($url =~ /^$valid_domain(\/|$)/) {
			$valid_flg = 1;
			last;
		}
	}
	
	# 絶対パス指定と相対パス指定をチェック
	if ($valid_flg != 1 && ($url =~ /^\// || $url =~ /^\./)) {
		$valid_flg = 1;
	}
	
	# 結果を返す
	return $valid_flg;
}

## HTTPリファラのチェック
# 
# @return 1 (許可ドメイン) | 0 (無効ドメイン)
# 
sub is_valid_referer {
	# HTTPリファラ取得
	if (!exists $ENV{'HTTP_REFERER'} || $ENV{'HTTP_REFERER'} =~ /^\s*$/) {
		# 取得に失敗した場合はエラー
		return 0;
	}
	local $referer = $ENV{'HTTP_REFERER'};
	
	# チェック
	return &is_valid_url($referer);
}

1;
