#==============================================================================
# CGIプログラム 共通関数群
#	CGIで使用する共通関数を記述します。
#==============================================================================

#==============================================================================
# パッケージの宣言
#==============================================================================
package pack_com_cgi;

#==============================================================================
# 数字チェック
#	【引数】
#			string $_[0] チェック対象の文字列
#	【戻値】
#			boolean 対象の文字列が数字のみの場合は1、そうでない場合は0を返す
#==============================================================================
sub isNumeric {
	return (@_[0] =~ /^[0-9]+$/);
}

#==============================================================================
# 対象の文字列をHTMLとして表示できるようにする
#	【引数】
#			string @_[0] HTMLエスケープする文字列
#			string $_[1] XHTMLの使用フラグ[0:未使用 1:使用](未指定の場合は設定ファイルの値を利用)
#	【戻値】
#			HTMLエスケープされた文字列
#==============================================================================
sub htmlDisplay {
	# 初期値として設定ファイルのXHTML使用フラグをセット
	my $xhtml_flg = $main::CONST_USE_XHTML_FLG;
	if (exists($_[1])) {
		# 第2パラメータにて指定がある場合は指定された値をセット
		$xhtml_flg = $_[1];
	}
	return (&pack_com_cgi::nl2Br(&pack_com_cgi::escapeHTML(@_[0]), $xhtml_flg));
}

#==============================================================================
# 対象の文字列をHTMLエスケープする
#	【引数】
#			string $ret_str HTMLエスケープする文字列
#	【戻値】
#			HTMLエスケープされた文字列
#==============================================================================
sub escapeHTML {
	# 引数の取得
	my ($ret_str) = @_;
	
	# & → &amp;
	$ret_str =~ s/&/&amp;/g;
	# < → &lt;
	$ret_str =~ s/</&lt;/ig;
	# > → &gt;
	$ret_str =~ s/>/&gt;/ig;
	# " → &quot;
	$ret_str =~ s/"/&quot;/g;
	# ' → &#39;
	$ret_str =~ s/'/&#39;/g;
	
	return $ret_str;
}

#==============================================================================
# 改行文字の前にHTMLの改行タグを挿入する
#	【引数】
#			string $ret_str 改行タグを追加する文字列
#	【戻値】
#			改行タグを追加された文字列
#==============================================================================
sub nl2Br {
	# 引数の取得
	my ($ret_str, $xhtml_flg) = @_;
	# 変数の初期化
	my $br_str = '<br />';
	
	# HTMLの場合
	if ($xhtml_flg == 0) {
		$br_str = '<br>';
	}
	# 改行の前にHTMLの改行タグを追加
	$ret_str =~ s/(\r?\n|\n?\r)/$br_str$1/g;
	
	return $ret_str;
}

#==============================================================================
# 文字列中の対象文字列を置換する
#	【引数】
#			string $replace_this 置換対象文字列
#			string $with_this 置換後文字列
#			string $target_string 置換対象文字列を含む文字列
#	【戻値】
#			string 置換処理をおこなった文字列
#	【備考】
#			なし
#==============================================================================
sub strReplace {
	# 引数の取得
	my ($replace_this, $with_this, $target_string) = @_;
	
	# 文字列を置き換えする
	$replace_this = &pack_com_cgi::regReplace($replace_this);
	$target_string =~ s/$replace_this/$with_this/g;
	return $target_string;
}

#==============================================================================
# パラメータを指定に沿ってチェックする
#	【引数】
#			hash $input パラメータ入力値（$_GETや$_POST等）
#			hash $use_param_hash パラメータの詳細指定連想配列
#	【戻値】
#			multiple 正常にチェックが終了した場合は1、そうでない場合はエラー連想配列を返す
#	【備考】
#			なし
#==============================================================================
sub checkParamValue {
	# 引数の取得
	my ($input, $use_param_hash) = @_;
	# 変数の初期化
	my %ret_err_hash;
	
	# 指定パラメータの数分ループ
	foreach my $param_name(keys(%{$use_param_hash})) {
		# パラメータの値(デフォルト値を取得)
		my $param_value = (exists($$use_param_hash{$param_name}->{'default'}) ? $$use_param_hash{$param_name}->{'default'} : '');
		# パラメータが存在し値が空でない場合
		if (exists($$input{$param_name}) && $$input{$param_name} ne '') {
			$param_value = $$input{$param_name};
			$param_value =~ s/\0/,/g;
		}
		# 必須チェック
		if ($$use_param_hash{$param_name}->{'need'} == 1 && $param_value eq '') {
			$ret_err_hash{'error_code'} = '02';
			$ret_err_hash{'error_msg'} = $param_name;
			return %ret_err_hash;
		}
		# 1つのパラメータに複数データが存在する場合（チェックボックスなど）
		my @param_val_ary = ();
		if ($$use_param_hash{$param_name}->{'data_num'} eq 'MANY') {
			# テキスト項目であり複数項目の場合は全角スペースを半角スペースとして変換する
			my $tmp_param_val = $param_value;
			if ($$use_param_hash{$param_name}->{'data_type'} eq 'TEXT' && $$use_param_hash{$param_name}->{'data_num'} eq 'MANY') {
				$tmp_param_val =~ s/　/ /o;
			}
			@param_val_ary = split(/$$use_param_hash{$param_name}->{'split_str'}/, $tmp_param_val);
		}
		# 1つのパラメータに1つのデータが存在する場合（ラジオボタンなど）
		else {
			$param_val_ary[0] = $param_value;
		}
		
		# 各チェック
		foreach my $check_contents(@{$$use_param_hash{$param_name}->{'check'}}) {
			# 値ごとループ
			foreach my $check_param_val(@param_val_ary) {
				# チェックする値が無い場合はスキップ
				if ($check_param_val eq '') {
					next;
				}
				# 数値チェック
				if ($check_contents eq 'NUM' && $check_param_val !~ /^[\x20|\x30-\x39]+$/) {
					$ret_err_hash{'error_code'} = '03';
					$ret_err_hash{'error_msg'} = $param_name;
					return %ret_err_hash;
				}
				# 文字数チェック
				elsif ($check_contents =~ /^LEN\((\d+)\)$/i && length($check_param_val) != $1) {
					$ret_err_hash{'error_code'} = '04';
					$ret_err_hash{'error_msg'} = $param_name;
					return %ret_err_hash;
				}
				# 範囲チェック
				elsif ($check_contents =~ /^RANGE\((\d+),\s?(\d+)\)$/i && ($check_param_val < $1 || $2 < $check_param_val)) {
					$ret_err_hash{'error_code'} = '05';
					$ret_err_hash{'error_msg'} = $param_name . ' : 指定可能範囲[' . $1 . '～' . $2 . ']';
					return %ret_err_hash;
				}
				# 正規表現チェック
				elsif ($check_contents =~ /^REGEXP\((.+?)\)$/i && $check_param_val !~ /$1/) {
					$ret_err_hash{'error_code'} = '06';
					$ret_err_hash{'error_msg'} = $param_name;
					return %ret_err_hash;
				}
			}
		}
	}
	return 1;
}

#==============================================================================
# パラメータを指定に沿って取得する
#	【引数】
#			hash $input パラメータ入力値（$_GETや$_POST等）
#			hash $use_param_hash パラメータの詳細指定連想配列
#	【戻値】
#			hash パラメータ取得後の連想配列
#	【備考】
#			なし
#==============================================================================
sub getParamValue {
	# 引数の取得
	my ($input, $use_param_hash) = @_;
	# 変数の初期化
	my %ret_hash;
	
	# 指定パラメータの数分ループ
	foreach my $param_name(keys(%{$use_param_hash})) {
		# パラメータの値(デフォルト値を取得)
		my $param_value = (exists($$use_param_hash{$param_name}->{'default'}) ? $$use_param_hash{$param_name}->{'default'} : '');
		# パラメータが存在し値が空でない場合
		if (exists($$input{$param_name}) && $$input{$param_name} ne '') {
			$param_value = $$input{$param_name};
			$param_value =~ s/\0/,/g;
		}
		$ret_hash{$param_name} = $param_value;
	}
	return %ret_hash;
}

#==============================================================================
# エラー画面の表示を行う
#	【引数】
#			hash $system_hash システムの定義が指定された連想配列
#			hash $err_hash エラーの定義が指定された連想配列
#	【戻値】
#			なし
#==============================================================================
sub dispError {
	# 引数の取得
	my ($system_hash, $err_hash, $err_ary) = @_;
	
	# エラー言語の指定
	if (!exists($$system_hash{'lang'}) || $$system_hash{'lang'} eq '') {
		$$system_hash{'lang'} = $main::CONST_DEFAULT_LANGUAGE;
	}
	
	# 削除ファイルが指定されていた場合は、指定されたファイルの消去
	if (length($$err_hash{'delete_filename'}) > 0) {
		unlink($$err_hash{'delete_filename'});
	}
	
	# エラー内容の取得
	my $err_msg = '';
	# エラーが1件の場合
	if ($err_ary == '') {
		$err_msg = $main::CONST_MESSAGE{$$system_hash{'program'}}->{$$system_hash{'lang'}}->{$$err_hash{'error_code'}} . "\n";
		$err_msg = sprintf('<li>' . $err_msg . '</li>', $$err_hash{'error_msg'});
	}
	# エラーが複数件の場合
	else {
		foreach my $err (@{$err_ary}) {
			my $tmp_err_msg .= $main::CONST_MESSAGE{$$system_hash{'program'}}->{$$system_hash{'lang'}}->{$$err{'error_code'}} . "\n";
			$err_msg .= sprintf('<li>' . $tmp_err_msg . '</li>', $$err{'error_msg'});
		}
	}
	
	# 文字コードの指定がUTF-8以外の場合は変換する
	if (exists($$system_hash{'convert_charcode'}) && $$system_hash{'convert_charcode'} ne $main::CONST_CHAR_CODE_LIST_HASH{(lc $main::CONST_PERL_INNER_CHAR_CODE)}) {
		# タイトル
		Jcode::convert(\$$err_hash{'page_title'}, $$system_hash{'convert_charcode'}, 'utf8');
		# エラー内容
		Jcode::convert(\$err_msg, $$system_hash{'convert_charcode'}, 'utf8');
	}
	
	# テンプレートの表示
	open(IN, $$err_hash{'template_filename'}) || die &pack_com_cgi::dispErrorSub('テンプレートの読み込みに失敗しました。 (' . $$err_hash{'template_filename'} . ')' );
	@Html_Lines = <IN>;
	close(IN);
	
	# 文字置き換え
	for ($idx = 0; $idx < @Html_Lines; $idx++) {
		my $one_line = $Html_Lines[$idx];
		# ページタイトル
		$one_line =~ s/#page_title#/$$err_hash{'page_title'}/g;
		# ページURL
		$one_line =~ s/#page_url#/$$err_hash{'page_url'}/g;
		# エラー内容
		$one_line =~ s/#error#/$err_msg/g;
		# 公開側ルートパス
		$one_line =~ s/#httproot#/$main::CONST_HTTP_ROOT_DOMAIN/g;
		$one_line =~ s/#httpsroot#/$main::CONST_HTTP_ROOT_DOMAIN_SSL/g;
		$Html_Lines[$idx] = $one_line;
	}
	
	# ヘッダー情報の出力
	print 'Content-type: text/html; charset=' . (lc $$system_hash{'charset'}) . "\n\n";
	# エラー画面表示
	print @Html_Lines;
	
	exit;
}

#==============================================================================
# システムエラーの表示を行う（通常のエラーメッセージではない）
#	【引数】
#			string $err_msg 表示するエラーメッセージ
#	【戻値】
#			なし
#==============================================================================
sub dispErrorSub {
	# 引数の取得
	my ($err_msg) = @_;
	# 変数の初期化
	my $html_str = '';
	
	print "Content-type: text/html\n\n";
	$html_str .= '<html>';
	$html_str .= '<head>';
	$html_str .= '<title>system error</title>';
	$html_str .= '</head>';
	$html_str .= '<body>';
	$html_str .= $err_msg . '<br>';
	$html_str .= '</body>';
	$html_str .= '</html>';
	print $html_str;
	
	exit;
}

#==============================================================================
# 正規表現用に文字列をエスケープ
#	【引数】
#			string $ret_str エスケープ対象の文字列
#	【戻値】
#			string エスケープした文字列
#	【備考】
#			なし
#==============================================================================
sub regReplace {
	# 引数の取得
	my($ret_str) = @_;
	
	# 文字列のエスケープ
	$ret_str =~ s/[\\\*\+\.\?\{\}\(\)\[\]\^\$\-\|\/]/\\$&/g;
	return $ret_str;
}

#==============================================================================
# HTTPリファラのチェック
#	【引数】
#			なし
#	【戻値】
#			boolean HTTPリファラのURLが有効なドメインの場合1、そうでない場合0を返す
#	【備考】
#			なし
#==============================================================================
sub isValidReferer {
	# HTTPリファラ取得
	if (!exists($ENV{'HTTP_REFERER'}) || $ENV{'HTTP_REFERER'} =~ /^\s*$/) {
		# 取得に失敗した場合はエラー
		return 0;
	}
	# チェック
	return &pack_com_cgi::isValidUrl($ENV{'HTTP_REFERER'});
}

#==============================================================================
# 設定ファイルに設定した有効ドメインかチェック
#	【引数】
#			string $url チェック対象のURL
#	【戻値】
#			boolean チェック対象のURLが有効なドメインの場合1、そうでない場合0を返す
#	【備考】
#			なし
#==============================================================================
sub isValidUrl {
	# 引数の取得
	my ($url) = @_;
	# 変数の初期化
	my $valid_domain = '';
	my $valid_flg = 0;
	
	# URLから付加情報を削除
	$url =~ s/\#.*//;
	$url =~ s/\?.*//;
	
	# チェック開始
	for (my $cnt = 0; $cnt < @main::CONST_VALID_HTTP_DOMAIN; $cnt++) {
		# 有効ドメインの設定値を補正
		$valid_domain = $main::CONST_VALID_HTTP_DOMAIN[$cnt];
		$valid_domain =~ s/^\s//;
		$valid_domain =~ s/\s$//;
		$valid_domain =~ s/\/$//;
		# 補正したドメインが空の場合はチェックなし
		if ($valid_domain eq '') {
			next;
		}
		# 正規表現用のエスケープ
		$valid_domain = &pack_com_cgi::regReplace($valid_domain);
		# チェック
		if ($url =~ /^$valid_domain(\/|$)/) {
			$valid_flg = 1;
			last;
		}
	}
	# 絶対パス指定と相対パス指定をチェック
	if ($valid_flg != 1 && ($url =~ /^\// || $url =~ /^\./)) {
		$valid_flg = 1;
	}
	# 結果を返す
	return $valid_flg;
}

#==============================================================================
# ロックファイル作成
#	【引数】
#			string $lock_flg ロックフラグ文字列 'ON' or 'OFF'
#			string $lock_file_hash{'dir'} ロックファイルディレクトリ文字列
#			string $lock_file_hash{'name'} ロックファイル名文字列
#			int $lock_file_hash{'retry'} ロックファイルリトライ回数
#			int $lock_file_hash{'timeout'} ロックファイルタイムアウト
#	【戻値】
#			int 0 何らかの理由で失敗をした
#			int 1 正常終了
#==============================================================================
sub fileLock {
	# 「Fcntl」モジュールを指定
	use Fcntl;

	# 引数の取得
	my $lock_flg = $_[0];
	my %lock_file_hash = (
		'dir' => ($_[1] ne '' ? $_[1] : $main::DEFAULT_LOCK_FILE_DIR),
		'name' => ($_[2] ne '' ? $_[2] : $main::DEFAULT_LOCK_FILE_NAME),
		'retry' => ($_[3] ne '' ? $_[3] : $main::DEFAULT_LOCK_FILE_RETRY_CNT),
		'timeout' => ($_[4] ne '' ? $_[4] : $main::DEFAULT_LOCK_FILE_TIMEOUT),
		'process_id' => ($_[5] ne '' ? $_[5] : $$),
	);
	my $csv_fp = '';
	
	# 変数の初期化
	my $lock_file_name = $lock_file_hash{'dir'} . '/' . $lock_file_hash{'name'};
	my $lock_exec_flg = 0;
	
	# ロックする
	if ($lock_flg eq 'ON') {
		# ファイルの作成日時を確認し、規定日時を超えているようなら削除する
		if ((-M $lock_file_name) * 86400 > $lock_file_hash{'timeout'}) {
			&pack_com_cgi::fileLock('OFF', $lock_file_hash{'dir'}, $lock_file_hash{'name'}, $lock_file_hash{'retry'}, $lock_file_hash{'timeout'}, '-');
		}
		# リトライ回数分ループ
		foreach (1..$lock_file_hash{'retry'}) {
			# ファイルが存在していない場合に新規作成、書き込みモードで開く
			# ファイルが生成できない場合はスリープ
			if (!sysopen($csv_fp, $lock_file_name, O_WRONLY | O_EXCL | O_CREAT)) {
				sleep($main::DEFAULT_LOCK_FILE_WAITTIME);
			}
			else {
				# プロセスIDを書き込む
				print $csv_fp $lock_file_hash{'process_id'};
				$lock_exec_flg = 1;
				last;
			}
		}
		# ロックファイルの作成に失敗した場合
		if ($lock_exec_flg == 0) {
			return 0;
		}
		close($csv_fp);
		# シグナルハンドラをセット
		$SIG{HUP} = $SIG{INT} = $SIG{PIPE} = $SIG{QUIT} = $SIG{TERM} = \&pack_com_cgi::fileLock('OFF', $lock_file_hash{'dir'}, $lock_file_hash{'name'}, $lock_file_hash{'retry'}, $lock_file_hash{'timeout'}, $lock_file_hash{'process_id'});
	}
	# ロック解除
	else {
		# ファイルの存在をチェック
		if (-e $lock_file_name) {
			my $delete_flg = 0;
			# プロセスIDがある場合で、ファイル読み込みモードで開けた場合
			if ($lock_file_hash{'process_id'} ne '-' && sysopen($csv_fp, $lock_file_name, O_RDONLY)) {
				my @str = <$csv_fp>;
				# 書き込んであるプロセスIDとロックファイルのプロセスIDを比較し、同じだったら削除フラグを立てる
				if ($str[0] eq $lock_file_hash{'process_id'}) {
					$delete_flg = 1;
				}
			}
			else {
				$delete_flg = 1;
			}
			# 削除フラグがONの場合は削除
			if ($delete_flg == 1) {
				unlink($lock_file_name);
				$SIG{HUP} = $SIG{INT} = $SIG{PIPE} = $SIG{QUIT} = $SIG{TERM} = '';
			}
		}
	}
	return 1;
}

#==============================================================================
#	（新）サーバー文字コードとPerlバージョンの取得
#
#	【引数】$I_lockdir	ロックファイルフォルダ名
#			$I_lockfnm	ロックファイル名
#			$I_sysfnm	システム設定ファイル名
#			$I_tmpnm	テンプレートファイル名
#			$O_jcode	取得した文字コード
#			$O_perlver	取得したPerlバージョン
#
#	【戻値】成功（1）：失敗（エラーコード）
#
#
#==============================================================================
sub getServerSetting
{
	local( $I_lockdir, $I_lockfnm, $I_sysfnm, $I_tmperr, *O_jcode, *O_perlver ) = @_;
	my $result = 1;
	#エラー画面表示用連想配列の作成
	my %arr_err = (
		"tmp_fnm"		=> $I_tmperr,
		"jcode"			=> "",
		"perlver"		=> "",
		"page_title"	=> "システムエラー",
		"page_url"		=> "javascript:history.back()",
		"error"			=> "",
		"del_fnm"		=> "",
	);
	
	$O_jcode = "";
	$O_perlver = "";

	# ロックに失敗した場合
	if( &pack_com_cgi::fileLock('ON', $I_lockdir, $I_lockfnm) != 1 ){
		$result = 100;
		#$arr_err{'error'} = "<li>lock fatal</li>";
		#&disp_error(\%arr_err);
	}
	if( 1 == &get_setting($I_sysfnm, *O_jcode, *O_perlver)){
		$result = 101;
		#$arr_err{'error'} = "<li>read setting fatal</li>";
		#$arr_err{'del_fnm'} = $I_lockfnm;
		#&disp_error(\%arr_err);
	}
	# ロック解除失敗した場合
	if( &pack_com_cgi::fileLock('OFF', $I_lockdir, $I_lockfnm) != 1 ){
		$result = 102;
		#$arr_err{'error'} = "<li>unlock fatal</li>";
		#$arr_err{'del_fnm'} = $I_lockfnm;
		#&disp_error(\%arr_err);
	}
	return $result;
}

#==============================================================================
#	入力項目の格納とチェック
#
#	【引数】$input			フォームから入力された値が格納されている連想配列
#			$setting_jcode	サーバー文字コード
#			$setting_pvar	perlバージョン
#			$item_cnt		入力値数
#			$frm_item		入力値格納先（配列[連想配列]の２次元配列）
#			$err_msg		エラー内容
#
#	【戻値】0	エラーなし
#			1	エラーあり
#
#==============================================================================
sub getInputItem
{
	local ($input) = shift if @_;
	local($setting_jcode, $setting_pvar, $item_cnt, *frm_item, *err_msg ,$lang, $module) = @_;
	my @err_msg_ary = $main::CONST_MESSAGE{$module}{$lang};
	my $err_cnt = 0;
	my @err_ary = ();
	
	# 言語情報が取得できない場合は、デフォルトの言語を設定
	# 設定ファイル読み込み(feedbackでsetting_msg.plを読み込んでいないため)
	require $main::CONST_APPLICATION_ROOT . '/common/setting_msg.pl';
	if (!defined($lang) || $lang eq '') {
		$lang = $DEFAULT_LANG;
	}
	

	#ページ共通のhidden値のチェック
	# ページIDが指定されていません。
	if(!exists $$input{'page_id'} || length($$input{'page_id'}) <= 0){
		#ページID 必須チェック
		#$err_msg .= "<li>" . $ERR_MSG{$lang}{'1011'} . "</li>";
		push(@err_ary, {'error_code' => '1011'});
	}
	# ページIDに数値以外が指定されています。
	#elsif(!check_numeric($$input{'page_id'})){ $err_msg .= "<li>" . $ERR_MSG{$lang}{'1012'} . "</li>"; }										#ページID 数値チェック
	elsif(!isNumeric($$input{'page_id'})){
		#ページID 数値チェック>#ページID 数値チェック
		#$err_msg .= "<li>" . $ERR_MSG{$lang}{'1012'} . "</li>";
		push(@err_ary, {'error_code' => '1012'});
	}
	# ページタイトルが指定されていません。
	if(!exists $$input{'page_title'} || length($$input{'page_title'}) <= 0){
		#ページタイトル 必須チェック
		#$err_msg .= "<li>" . $ERR_MSG{$lang}{'1013'} . "</li>";
		push(@err_ary, {'error_code' => '1013'});
	}
	# ページタイトルに改行が指定されています。
	if($$input{'page_title'} =~ /[\r\n]/gm){
		#ページタイトル 改行チェック（メールヘッダ・インジェクション）
		#$err_msg .= "<li>" . $ERR_MSG{$lang}{'1014'} . "</li>";
		push(@err_ary, {'error_code' => '1014'});
	}
	# ページURLが指定されていません。
	if(!exists $$input{'page_url'} || length($$input{'page_url'}) <= 0){
		#ページURL 必須チェック
		#$err_msg .= "<li>" . $ERR_MSG{$lang}{'1015'} . "</li>";
		push(@err_ary, {'error_code' => '1015'});
	}
	# ページURLに使用できない記号が指定されています。
	elsif(!check_h_alphanumeric($$input{'page_url'})){
		#ページURL 英数記号チェック
		#$err_msg .= "<li>" . $ERR_MSG{$lang}{'1016'} . "</li>";
		push(@err_ary, {'error_code' => '1016'});
	}
	# ページURLに使用できないURLが指定されています。
	elsif(!isValidUrl($$input{'page_url'})){
		#ページURL 有効ドメインチェック
		#$err_msg .= "<li>" . $ERR_MSG{$lang}{'1017'} . "</li>";
		push(@err_ary, {'error_code' => '1017'});
	}
	# 項目数が指定されていません。
	if(!exists $$input{'item_cnt'} || length($$input{'item_cnt'}) <= 0){
		#項目数 必須チェック
		#$err_msg .= "<li>" . $ERR_MSG{$lang}{'1018'} . "</li>";
		push(@err_ary, {'error_code' => '1018'});
	}
	# 項目数に数値以外が指定されています。
	elsif(!isNumeric($$input{'item_cnt'})){
		#項目数 必須チェック
		#$err_msg .= "<li>" . $ERR_MSG{$lang}{'1019'} . "</li>";
		push(@err_ary, {'error_code' => '1019'});
	}

	for ($idx = 1; $idx <= $item_cnt; $idx++) {
		#フォームアイテムの格納
		push @frm_item,{ 
			"title"			=> $$input{'label_'.$idx},			#項目名
			"value"			=> $$input{'item_'.$idx},			#Form値
			"check"			=> $$input{'nes_'.$idx},			#必須(1)or省略可(0)
			"mail"			=> $$input{'mail_'.$idx},			#メールアドレス(1)orメールアドレスでない(0)
			"reply_mail"	=> $$input{'reply_mail_'.$idx},		#自動返信する(1)or自動返信しない(0)
			"desc_mail"		=> $$input{'desc_mail_'.$idx},		#自動返信メールに記載する(1)or自動返信メールに記載しない(0)
			"img"			=> $$input{'img_'.$idx},			#画像
			"img_alt"		=> $$input{'img_alt_'.$idx},		#画像ALT
			"d_title"		=> "",								#表示用項目名
			"d_value"		=> "",								#表示用From値
			"d_title_ret"	=> "",								#表示用項目名(改行変換はなし）
			"d_value_ret"	=> "",								#表示用From値(改行変換はなし）
		};
		#行末の改行コードや空白を取り去る
		$frm_item[$idx-1]->{'title'} =~ s/\s*$//;
		$frm_item[$idx-1]->{'value'} =~ s/\s*$//;
		$frm_item[$idx-1]->{'title'} =~ s/\0/,/g;
		$frm_item[$idx-1]->{'value'} =~ s/\0/,/g;
		#表示用エスケープ処理
		$frm_item[$idx-1]->{'d_title'} = &html_escapr($frm_item[$idx-1]->{'title'});
		$frm_item[$idx-1]->{'d_title_ret'} = &html_escapr($frm_item[$idx-1]->{'title'});
		$frm_item[$idx-1]->{'d_value'} = &html_escapr($frm_item[$idx-1]->{'value'});
		$frm_item[$idx-1]->{'d_value_ret'} = &html_escapr($frm_item[$idx-1]->{'value'});
		#改行変換
		$frm_item[$idx-1]->{'d_title'} = &html_escapr_ret($frm_item[$idx-1]->{'d_title'});
		$frm_item[$idx-1]->{'d_value'} = &html_escapr_ret($frm_item[$idx-1]->{'d_value'});
		#「"」対策
		$frm_item[$idx-1]->{'title'} =~ s/"/\\"/g;
		$frm_item[$idx-1]->{'value'} =~ s/"/\\"/g;
		#項目名チェック
		if( length($frm_item[$idx-1]->{'title'}) <= 0 ){
			# 項目名称が指定されていません。(item_$idx)
			#$err_msg = $err_msg . "<li>" . sprintf($ERR_MSG{$lang}{'1020'}, "item_$idx") . "</li>";
			push(@err_ary, {'error_code' => '1020', 'error_msg' => "item_$idx"});
		}
		#hidden項目の妥当性チェック
		elsif ($frm_item[$idx-1]->{'check'} ne "" && ! &isNumeric($frm_item[$idx-1]->{'check'} ) ) {
			# 必須チェックに数値以外が指定されています。(item_$idx)
			#$err_msg = $err_msg . "<li>" . sprintf($ERR_MSG{$lang}{'1021'}, "item_$idx") . "</li>";
			push(@err_ary, {'error_code' => '1021', 'error_msg' => "item_$idx"});
		}
		#elsif ($frm_item[$idx-1]->{'mail'} ne "" && ! &check_numeric($frm_item[$idx-1]->{'mail'} ) ) {
		elsif ($frm_item[$idx-1]->{'mail'} ne "" && ! &isNumeric($frm_item[$idx-1]->{'mail'} ) ) {
			# メールアドレスチェックに数値以外が指定されています。(item_$idx)
			#$err_msg = $err_msg . "<li>" . sprintf($ERR_MSG{$lang}{'1022'}, "item_$idx") . "</li>";
			push(@err_ary, {'error_code' => '1022', 'error_msg' => "item_$idx"});
		}
		else{
			#機種依存チェック
#			if( 1 == &chk_pdc_utf8_sjis($setting_jcode, $frm_item[$idx-1]->{'title'})){
#				$err_item = $frm_item[$idx-1]->{'d_title'};
#				if( $setting_jcode eq $CONST_JCODE_SJIS){	#utf-8に変換する
#					$err_item = &jcode_conv_sjis2utf8($err_item, $setting_pvar);
#				}
#				$err_msg = $err_msg . "<li>項目名称に機種依存文字は入力できません。(label_$idx)</li>";
#			}
			#各項目ごとのhidden値のチェック
			# 必須フラグが指定されていません。(nes_$idx)
			if(!exists $frm_item[$idx-1]->{'check'} || length($frm_item[$idx-1]->{'check'}) <= 0){
				#$err_msg .= "<li>" . sprintf($ERR_MSG{$lang}{'1023'}, "nes_$idx") . "</li>";
				push(@err_ary, {'error_code' => '1023', 'error_msg' => "nes_$idx"});
			}
			# 必須フラグに数値以外が指定されています。(nes_$idx)
			elsif(!isNumeric($frm_item[$idx-1]->{'check'})){
				#$err_msg .= "<li>" . sprintf($ERR_MSG{$lang}{'1024'}, "nes_$idx") . "</li>";
				push(@err_ary, {'error_code' => '1024', 'error_msg' => "nes_$idx"});
			}
			#項目必須チェック
			if( length($frm_item[$idx-1]->{'value'}) > 0 ){
#				#機種依存文字チェック
#				if( 1 == &chk_pdc_utf8_sjis($setting_jcode, $frm_item[$idx-1]->{'value'})){
#					$err_item = $frm_item[$idx-1]->{'d_title'};
#					if( $setting_jcode eq $CONST_JCODE_SJIS){	#utf-8に変換する
#						$err_item = &jcode_conv_sjis2utf8($err_item, $setting_pvar);
#					}
#					$err_msg = $err_msg . "<li>" . $err_item . "に機種依存文字は入力できません。</li>";
#				}
#				else{
					if( $frm_item[$idx-1]->{'mail'} == 1 ){
						if($frm_item[$idx-1]->{'value'} !~ /^([a-zA-Z0-9\.\-\/_\!\#\$\%\&\'\*\+\=\?\^\`\{\|\}\~\(\)\ \[\]\\\<\>\@\:\;\,]{1,})@([a-zA-Z0-9\.\-\/_]{1,})\.([a-zA-Z0-9\.\-\/_]{1,})$/){
							$err_item = $frm_item[$idx-1]->{'d_title'};
							if( $setting_jcode eq $CONST_JCODE_SJIS){	#utf-8に変換する
								$err_item = &jcode_conv_sjis2utf8($err_item, $setting_pvar);
							}
							#$err_item . に入力されたメールアドレスが正しく入力されていません。
							#$err_msg = $err_msg . "<li>" . sprintf($ERR_MSG{$lang}{'1025'}, $err_item) . "</li>";
							push(@err_ary, {'error_code' => '1025', 'error_msg' => $err_item});
						}
					}
#				}
			}
			else{
				if( $frm_item[$idx-1]->{'check'} == 1 ){
					$err_item = $frm_item[$idx-1]->{'d_title'};
					if( $setting_jcode eq $CONST_JCODE_SJIS){
						#utf-8に変換する
						$err_item = &jcode_conv_sjis2utf8($err_item, $setting_pvar);
					}
					# $err_item . の省略はできません
					#$err_msg = $err_msg . "<li>" . sprintf($ERR_MSG{$lang}{'1026'}, $err_item) . "</li>";
					push(@err_ary, {'error_code' => '1026', 'error_msg' => $err_item});
				}
			}
		}
	}

	return @err_ary;

	#if( length($err_msg) > 0 ){
	#	return 1;
	#}
	#else{
	#	return 0;
	#}
}






























$CONST_JCODE_SJIS = "shift_jis";
$CONST_JCODE_UTF8 = "utf-8";
$P_Perlvar_50 = "5.0";
$P_Perlvar_58 = "5.8";

$test = "";

#==============================================================================
#	現在の時刻を取得する
#
#	【引数】フォーマット形式
#			1:	yyyy/mm/dd hh:mm:ss
#			2:	yyyy年mm月dd hh時mm分ss秒
#
#	【戻値】yyyy/mm/dd hh:mm:ss にフォーマットされた現在の日付時間
#			1	エラーあり
#
#==============================================================================
sub get_now_datetime
{
	local ($format_type) = @_;

	#---現在の日時を取得する
	#日時取得
	my ( @ltms )	= localtime(time);
	# 現在の年を取得する
	$NowYera  = sprintf( "%2.2d", $ltms[5]-100 );
	$NowYera += 2000;
	# 現在の月を取得する
	$NowMonth = sprintf( "%2.2d", $ltms[4]+1 );
	# 現在の日を取得する
	$NowDDay = sprintf( "%2.2d", $ltms[3] );
	# 現在の時を取得する
	$NowHour = sprintf( "%2.2d", $ltms[2] );
	# 現在の分を取得する
	$NowMin = sprintf( "%2.2d", $ltms[1] );
	# 現在の秒を取得する
	$NowSec = sprintf( "%2.2d", $ltms[0] );

	#フォーマット
	if( $format_type == 2 ){
		$NowDayTime = $NowYera . "年" . $NowMonth . "月" . $NowDDay . "日 " . $NowHour . "時" . $NowMin . "分" . $NowSec . "秒";
	}
	else{
		$NowDayTime = $NowYera . "/" . $NowMonth . "/" . $NowDDay . " " . $NowHour . ":" . $NowMin . ":" . $NowSec;
	}

	return $NowDayTime;

}

#==============================================================================
#	入力項目の格納とチェック
#
#	【引数】$input			フォームから入力された値が格納されている連想配列
#			$setting_jcode	サーバー文字コード
#			$setting_pvar	perlバージョン
#			$item_cnt		入力値数
#			$frm_item		入力値格納先（配列[連想配列]の２次元配列）
#			$err_msg		エラー内容
#
#	【戻値】0	エラーなし
#			1	エラーあり
#
#==============================================================================
sub get_imput_item
{
	local ($input) = shift if @_;
	local($setting_jcode, $setting_pvar, $item_cnt, *frm_item, *err_msg ,$lang) = @_;
	
	# 言語情報が取得できない場合は、デフォルトの言語を設定
	# 設定ファイル読み込み(feedbackでsetting_msg.plを読み込んでいないため)
	require $main::CONST_APPLICATION_ROOT . '/common/setting_msg.pl';
	if (!defined($lang) || $lang eq '') {
		$lang = $DEFAULT_LANG;
	}
	

	#ページ共通のhidden値のチェック
	# ページIDが指定されていません。
	if(!exists $$input{'page_id'} || length($$input{'page_id'}) <= 0){
		#ページID 必須チェック
		$err_msg .= "<li>" . $ERR_MSG{$lang}{'1011'} . "</li>";
	}
	# ページIDに数値以外が指定されています。
	#elsif(!check_numeric($$input{'page_id'})){ $err_msg .= "<li>" . $ERR_MSG{$lang}{'1012'} . "</li>"; }										#ページID 数値チェック
	elsif(!isNumeric($$input{'page_id'})){
		#ページID 数値チェック>#ページID 数値チェック
		$err_msg .= "<li>" . $ERR_MSG{$lang}{'1012'} . "</li>";
	}
	# ページタイトルが指定されていません。
	if(!exists $$input{'page_title'} || length($$input{'page_title'}) <= 0){
		#ページタイトル 必須チェック
		$err_msg .= "<li>" . $ERR_MSG{$lang}{'1013'} . "</li>";
	}
	# ページタイトルに改行が指定されています。
	if($$input{'page_title'} =~ /[\r\n]/gm){
		#ページタイトル 改行チェック（メールヘッダ・インジェクション）
		$err_msg .= "<li>" . $ERR_MSG{$lang}{'1014'} . "</li>";
	}
	# ページURLが指定されていません。
	if(!exists $$input{'page_url'} || length($$input{'page_url'}) <= 0){
		#ページURL 必須チェック
		$err_msg .= "<li>" . $ERR_MSG{$lang}{'1015'} . "</li>";
	}
	# ページURLに使用できない記号が指定されています。
	elsif(!check_h_alphanumeric($$input{'page_url'})){
		#ページURL 英数記号チェック
		$err_msg .= "<li>" . $ERR_MSG{$lang}{'1016'} . "</li>";
	}
	# ページURLに使用できないURLが指定されています。
	#elsif(!is_valid_url($$input{'page_url'})){ $err_msg .= "<li>" . $ERR_MSG{$lang}{'1017'} . "</li>"; }							#ページURL 有効ドメインチェック
	elsif(!isValidUrl($$input{'page_url'})){
		#ページURL 有効ドメインチェック
		$err_msg .= "<li>" . $ERR_MSG{$lang}{'1017'} . "</li>";
	}
	# 項目数が指定されていません。
	if(!exists $$input{'item_cnt'} || length($$input{'item_cnt'}) <= 0){
		#項目数 必須チェック
		$err_msg .= "<li>" . $ERR_MSG{$lang}{'1018'} . "</li>";
	}
	# 項目数に数値以外が指定されています。
	#elsif(!check_numeric($$input{'item_cnt'})){ $err_msg .= "<li>" . $ERR_MSG{$lang}{'1019'} . "</li>"; }									#項目数 必須チェック
	elsif(!isNumeric($$input{'item_cnt'})){
		#項目数 必須チェック
		$err_msg .= "<li>" . $ERR_MSG{$lang}{'1019'} . "</li>";
	}

	for ($idx = 1; $idx <= $item_cnt; $idx++) {
		#フォームアイテムの格納
		push @frm_item,{ 
			"title"			=> $$input{'label_'.$idx},			#項目名
			"value"			=> $$input{'item_'.$idx},			#Form値
			"check"			=> $$input{'nes_'.$idx},			#必須(1)or省略可(0)
			"mail"			=> $$input{'mail_'.$idx},			#メールアドレス(1)orメールアドレスでない(0)
			"reply_mail"	=> $$input{'reply_mail_'.$idx},		#自動返信する(1)or自動返信しない(0)
			"desc_mail"		=> $$input{'desc_mail_'.$idx},		#自動返信メールに記載する(1)or自動返信メールに記載しない(0)
			"img"			=> $$input{'img_'.$idx},			#画像
			"img_alt"		=> $$input{'img_alt_'.$idx},		#画像ALT
			"d_title"		=> "",								#表示用項目名
			"d_value"		=> "",								#表示用From値
			"d_title_ret"	=> "",								#表示用項目名(改行変換はなし）
			"d_value_ret"	=> "",								#表示用From値(改行変換はなし）
		};
		#行末の改行コードや空白を取り去る
		$frm_item[$idx-1]->{'title'} =~ s/\s*$//;
		$frm_item[$idx-1]->{'value'} =~ s/\s*$//;
		$frm_item[$idx-1]->{'title'} =~ s/\0/,/g;
		$frm_item[$idx-1]->{'value'} =~ s/\0/,/g;
		#表示用エスケープ処理
		$frm_item[$idx-1]->{'d_title'} = &html_escapr($frm_item[$idx-1]->{'title'});
		$frm_item[$idx-1]->{'d_title_ret'} = &html_escapr($frm_item[$idx-1]->{'title'});
		$frm_item[$idx-1]->{'d_value'} = &html_escapr($frm_item[$idx-1]->{'value'});
		$frm_item[$idx-1]->{'d_value_ret'} = &html_escapr($frm_item[$idx-1]->{'value'});
		#改行変換
		$frm_item[$idx-1]->{'d_title'} = &html_escapr_ret($frm_item[$idx-1]->{'d_title'});
		$frm_item[$idx-1]->{'d_value'} = &html_escapr_ret($frm_item[$idx-1]->{'d_value'});
		#「"」対策
		$frm_item[$idx-1]->{'title'} =~ s/"/\\"/g;
		$frm_item[$idx-1]->{'value'} =~ s/"/\\"/g;
		#項目名チェック
		if( length($frm_item[$idx-1]->{'title'}) <= 0 ){
			# 項目名称が指定されていません。(item_$idx)
			$err_msg = $err_msg . "<li>" . sprintf($ERR_MSG{$lang}{'1020'}, "item_$idx") . "</li>";
		}
		#hidden項目の妥当性チェック
		#elsif ($frm_item[$idx-1]->{'check'} ne "" && ! &check_numeric($frm_item[$idx-1]->{'check'} ) ) {
		elsif ($frm_item[$idx-1]->{'check'} ne "" && ! &isNumeric($frm_item[$idx-1]->{'check'} ) ) {
			# 必須チェックに数値以外が指定されています。(item_$idx)
			$err_msg = $err_msg . "<li>" . sprintf($ERR_MSG{$lang}{'1021'}, "item_$idx") . "</li>";
		}
		#elsif ($frm_item[$idx-1]->{'mail'} ne "" && ! &check_numeric($frm_item[$idx-1]->{'mail'} ) ) {
		elsif ($frm_item[$idx-1]->{'mail'} ne "" && ! &isNumeric($frm_item[$idx-1]->{'mail'} ) ) {
			# メールアドレスチェックに数値以外が指定されています。(item_$idx)
			$err_msg = $err_msg . "<li>" . sprintf($ERR_MSG{$lang}{'1022'}, "item_$idx") . "</li>";
		}
		else{
			#機種依存チェック
#			if( 1 == &chk_pdc_utf8_sjis($setting_jcode, $frm_item[$idx-1]->{'title'})){
#				$err_item = $frm_item[$idx-1]->{'d_title'};
#				if( $setting_jcode eq $CONST_JCODE_SJIS){	#utf-8に変換する
#					$err_item = &jcode_conv_sjis2utf8($err_item, $setting_pvar);
#				}
#				$err_msg = $err_msg . "<li>項目名称に機種依存文字は入力できません。(label_$idx)</li>";
#			}
			#各項目ごとのhidden値のチェック
			# 必須フラグが指定されていません。(nes_$idx)
			if(!exists $frm_item[$idx-1]->{'check'} || length($frm_item[$idx-1]->{'check'}) <= 0){ $err_msg .= "<li>" . sprintf($ERR_MSG{$lang}{'1023'}, "nes_$idx") . "</li>"; }
			# 必須フラグに数値以外が指定されています。(nes_$idx)
			#elsif(!check_numeric($frm_item[$idx-1]->{'check'})){ $err_msg .= "<li>" . sprintf($ERR_MSG{$lang}{'1024'}, "nes_$idx") . "</li>"; }
			elsif(!isNumeric($frm_item[$idx-1]->{'check'})){ $err_msg .= "<li>" . sprintf($ERR_MSG{$lang}{'1024'}, "nes_$idx") . "</li>"; }
			#項目必須チェック
			if( length($frm_item[$idx-1]->{'value'}) > 0 ){
#				#機種依存文字チェック
#				if( 1 == &chk_pdc_utf8_sjis($setting_jcode, $frm_item[$idx-1]->{'value'})){
#					$err_item = $frm_item[$idx-1]->{'d_title'};
#					if( $setting_jcode eq $CONST_JCODE_SJIS){	#utf-8に変換する
#						$err_item = &jcode_conv_sjis2utf8($err_item, $setting_pvar);
#					}
#					$err_msg = $err_msg . "<li>" . $err_item . "に機種依存文字は入力できません。</li>";
#				}
#				else{
					if( $frm_item[$idx-1]->{'mail'} == 1 ){
						if($frm_item[$idx-1]->{'value'} !~ /^([a-zA-Z0-9\.\-\/_\!\#\$\%\&\'\*\+\=\?\^\`\{\|\}\~\(\)\ \[\]\\\<\>\@\:\;\,]{1,})@([a-zA-Z0-9\.\-\/_]{1,})\.([a-zA-Z0-9\.\-\/_]{1,})$/){
							$err_item = $frm_item[$idx-1]->{'d_title'};
							if( $setting_jcode eq $CONST_JCODE_SJIS){	#utf-8に変換する
								$err_item = &jcode_conv_sjis2utf8($err_item, $setting_pvar);
							}
							#$err_item . に入力されたメールアドレスが正しく入力されていません。
							$err_msg = $err_msg . "<li>" . sprintf($ERR_MSG{$lang}{'1025'}, $err_item) . "</li>";
						}
					}
#				}
			}
			else{
				if( $frm_item[$idx-1]->{'check'} == 1 ){
					$err_item = $frm_item[$idx-1]->{'d_title'};
					if( $setting_jcode eq $CONST_JCODE_SJIS){	#utf-8に変換する
						$err_item = &jcode_conv_sjis2utf8($err_item, $setting_pvar);
					}
					# $err_item . の省略はできません
					$err_msg = $err_msg . "<li>" . sprintf($ERR_MSG{$lang}{'1026'}, $err_item) . "</li>";
				}
			}
		}
	}

	if( length($err_msg) > 0 ){
		return 1;
	}
	else{
		return 0;
	}

}


#==============================================================================
#	機種依存チェック
#
#	【引数】$I_jcode	文字コード
#			$I_str		変換をする文字列
#
#	【戻値】0		機種依存文字がなかった
#			1		機種依存文字が存在した
#
#==============================================================================
sub chk_pdc_utf8_sjis {
    my ($I_jcode, $I_str) = @_;


	if( $I_jcode eq $CONST_JCODE_SJIS){	#utf-8に変換する
		$ret = &chksjis($I_str, length($I_str));
		if(( $ret != 0 ) && ( $ret != 1 )){
			return 1;
		}
	}
	else{
		$wk_str[0] = $I_str;
		if( 1 == &pdc_chk(@wk_str)){
			return 1;
		}
	}

	return 0;

}


sub length_sjis {
	my $str = shift;
	my $cnt = 0;
	while( $str =~ m/
		[\x00-\x7F\xA1-\xDF]|
		[\x81-\x9F\xE0-\xFC][\x40-\x7E\x80-\xFC]
		/gx
	) {
		$cnt++;
	}
	return $cnt;
}

#==============================================================================
#	SJISの文字コードチェック
#
#	【引数】$I_str	変換をする文字列
#			$len	文字長さ
#
#	【戻値】0		ASCII
#			1		sjis 全角文字
#			以外	機種依存・半角カナ・認められない文字
#
#==============================================================================
sub chksjis {
    my ($buf, $len) = @_;

    my $stat; # 最終バイトの状態
    my $rtn; # 返却値
    my ($c, $c1, $i);

    $rtn = 0; # ASCII
    $stat = 0;

	$test = $len . "---" . &length_sjis($buf) . "---";

	#ℓ®㎥㎠㎤㎖㏔㎢㎳
	#SJISコードには存在しない文字の対応。
	#Formから受け取った時点でコードで入ってきてしまうためチェックが難しい。
	#直値にて確認
	if(( $buf =~ /&#8467;/)||( $buf =~ /&#174;/)||( $buf =~ /&#13221;/)||
		( $buf =~ /&#13220;/)||( $buf =~ /&#13206;/)||( $buf =~ /&#13268;/)||( $buf =~ /&#13218;/)||( $buf =~ /&#13235;/)){
		return 9;
	}

	$one_word = "";
	for ($i = 0; $i < $len; $i++) {
		$c = ord(substr($buf, $i, 1));
		$one_word = $one_word . $c;
		$test = $test . "c[" . $c . "(".sprintf("%x",$c).")]";
		if ($stat == 0) { # 文字の1バイト目
			if (($c >= 0x07) && ($c <= 0x0d)) {
				# ctrl
			} elsif (($c >= 0x20) && ($c <= 0x7E)) {
				# ASCII
			} elsif (($c >= 0xA1) && ($c <= 0xDF)) {
				$rtn = $rtn | 2; # JISカナ
			} elsif (($c >= 0x81) && ($c <= 0x9F)) {
				$stat = 1; # JIS漢字(81-9F)
				$c1 = $c;
				$rtn = $rtn | 1;
			} elsif (($c >= 0xE0) && ($c <= 0xEF)) {
				$stat = 2; # JIS漢字(E0-EF)
				$c1 = $c;
				$rtn = $rtn | 1;
			} else {
				$rtn = -1; # Not SJIS
				last;
			}
		} elsif ($stat == 1) { # JIS漢字(81-9F)の2バイト目
			if ((($c >= 0x40) && ($c <= 0x7E)) ||
				(($c >= 0x80) && ($c <= 0xFC))) {
				$stat = 0;
				$test = $test . "(1)";
				$test = $test . "c1[" . $c1 . "(".sprintf("%x",$c1).")]";
				if (($c1 == 0x87) && ($c < 0x9E)) {
					$rtn = $rtn | 4; # JIS漢字(NEC拡張外字)
					$test = $test . "(11)";
				} elsif (($c1 >= 0x85) && ($c1 <= 0x87)) {
					$rtn = $rtn | 8; # JIS漢字(機種依存)
					$test = $test . "(12)";
				} elsif (($c1 == 0x88) && ($c < 0x9E)) {
					$rtn = $rtn | 8; # JIS漢字(機種依存)
					$test = $test . "(13)";
				} elsif (($c == 0xE6) || ($c == 0xE7) || ($c == 0xDF) || ($c == 0xE0) || ($c == 0xCA) ||
						 ($c == 0xE3) || ($c == 0xDB) || ($c == 0xDA) || ($c == 0xBF) || ($c == 0xBE)) {
					if( $c1 == 0x81){
						$rtn = $rtn | 8; # JIS漢字(機種依存)
						$test = $test . "(14)";
					}
				}
			} else {
				$test = $test . "(15)";
				$rtn = -1; # Not SJIS
				last;
			}
		} else { # JIS漢字(E0-EF)の2バイト目
			if ((($c >= 0x40) && ($c <= 0x7E)) ||
				(($c >= 0x80) && ($c <= 0xFC))) {
				$stat = 0;
				$test = $test . "(2)";
				$test = $test . "c1[" . $c1 . "(".sprintf("%x",$c1).")]";
				if (($c1 >= 0xED) && ($c1 <= 0xEE)) {
					$rtn = $rtn | 4; # JIS漢字(NEC拡張外字)
				} elsif (($c1 >= 0xEB) && ($c1 <= 0xEF)) {
					$rtn = $rtn | 8; # JIS漢字(機種依存)
				}
			} else {
				$rtn = -1; # Not SJIS
				last;
			}
		}
	}

	#®・㎠対策
	if(( $one_word =~ /3811410110359/)||( $one_word =~ /3835495150495459/)){
		return 10;
	}

	$test = $test . "<br>[[[" . $one_word . "]]]";

	return($rtn);

}

#==============================================================================
#	SJISからUTF-8への文字コードの変換
#
#	【引数】$I_str		変換をする文字列
#			$I_perlver	Perlバージョン
#
#	【戻値】変換された文字列
#
#
#==============================================================================
sub jcode_conv_sjis2utf8
{
	local( $I_str, $I_perlver ) = @_;

	Jcode::convert( \$I_str, "utf8", "CP932" );

	return $I_str;

}

#==============================================================================
#	UTF-8からSJISへの文字コードの変換
#
#	【引数】$I_str		変換をする文字列
#			$I_perlver	Perlバージョン
#
#	【戻値】変換された文字列
#
#
#==============================================================================
sub jcode_conv_utf82sjis
{
	local( $I_str, $I_perlver ) = @_;

	Jcode::convert( \$I_str, "CP932", "utf8" );

	return $I_str;

}


#==============================================================================
#	環境設定ファイルの読み込み
#
#	【引数】$I_fnm		ファイル名（フルパス）
#			$O_jcode	取得した文字コード
#			$O_perlver	取得したPerlバージョン
#
#	【戻値】1	設定ファイル読み込み失敗
#			0	正常終了
#
#
#==============================================================================
sub get_setting
{
	local( $I_fnm, *O_jcode, *O_perlver ) = @_;
	#---設定ファイルの読み込み
	open (IN,"$I_fnm") || die return 1;
	eval{flock(IN,1)};
	#ファイル内容の取得
	$set_cnt = 0;
	while ($value = <IN>){
		if( $set_cnt == 0 ){
			$O_jcode = $value;		#文字コード
			$O_jcode =~ s/"//g;		#テキストが""で囲まれている
			$O_jcode =~ s/\s*$//;
		}
		if( $set_cnt == 1 ){
			$O_perlver = $value;		#パールバージョン
			$O_perlver =~ s/"//g;		#テキストが""で囲まれている
			$O_perlver =~ s/\s*$//;
		}
		$set_cnt = $set_cnt + 1;
	}	
	close(IN);

	return 0;

}

=for comment
#==============================================================================
#	サーバー文字コードとPerlバージョンの取得
#
#	【引数】$I_lockfnm	ロックファイル名
#			$I_sysfnm	システム設定ファイル名
#			$I_tmpnm	テンプレートファイル名
#			$O_jcode	取得した文字コード
#			$O_perlver	取得したPerlバージョン
#
#	【戻値】なし
#
#
#==============================================================================
sub get_server_setting
{
	local( $I_lockfnm, $I_sysfnm, $I_tmperr, *O_jcode, *O_perlver ) = @_;

#	$arr_err['jcode'] = "";
#	$arr_err['perlver'] = "";
#	$arr_err['page_title'] = "システムエラー";
#	$arr_err['page_url'] = "javascript:history.back()";
#	$arr_err['error'] = "";
#	$arr_err['tmp_fnm'] = $I_tmperr;
#	$arr_err['del_fnm'] = "";

	#エラー画面表示用連想配列の作成
	my %arr_err = (
		"tmp_fnm"		=> $I_tmperr,
		"jcode"			=> "",
		"perlver"		=> "",
		"page_title"	=> "システムエラー",
		"page_url"		=> "javascript:history.back()",
		"error"			=> "",
		"del_fnm"		=> "",
	);
	$O_jcode = "";
	$O_perlver = "";
	if( 0 != &file_lock('ON', $I_lockfnm)){
		$arr_err{'error'} = "<li>lock fatal</li>";
#		&disp_error($arr_err);
		&disp_error(\%arr_err);
	}
	if( 1 == &get_setting($I_sysfnm, *O_jcode, *O_perlver)){
#		&file_lock('OFF', $I_lockfnm);
		$arr_err{'error'} = "<li>read setting fatal</li>";
		$arr_err{'del_fnm'} = $I_lockfnm;
#		&disp_error($arr_err);
		&disp_error(\%arr_err);
	}
	if( 0 != &pack_com_cgi'file_lock('OFF', $I_lockfnm)){
		$arr_err{'error'} = "<li>unlock fatal</li>";
		$arr_err{'del_fnm'} = $I_lockfnm;
#		&disp_error($arr_err);
		&disp_error(\%arr_err);
	}

}
=cut

=for comment
#==============================================================================
#	(旧）ロックファイル作成
#
#	【引数】ファイルロック	"ON" or "OFF"
#			ロックファイル名
#
#	【戻値】n	何らかの理由で失敗をした
#			0	正常終了
#
#==============================================================================
sub file_lock
{

	#---ロックファイル名
	$strLookFnm = $_[1];

	$err_flg = 0;

	if($_[0] eq 'ON'){
		$flg = 0;
		foreach(1 .. 5){
			if(-e $strLookFnm){sleep(1);}
			else{
				if(!open(LOCK,">$strLookFnm")){
					$err_flg = 1;		#作成不可
					last;
				}
				close(LOCK);
				$flg = 1;
				last;
			}
		}
		if(!$flg){
			$err_flg = 2;	#タイムオーバー
		}
	}
	else{
		if(-e $strLookFnm){
			unlink($strLookFnm);
		}
	}
	
	return $err_flg;
	
	
}
=cut

#==============================================================================
#	タグの無効化
#
#	【引数】無効化を行なう文字列
#
#	【戻値】タグが無効化された文字列
#
#	【備考】< > & " ' をそれぞれ文字列に変換する
#
#	【作成】06/11/09 表示文字、入力文字のタグを無効にするため
#
#==============================================================================
sub html_escapr
{
	local( $InStr ) = @_;

	$InStr =~ s/&/&amp;/g;		#& → &amp;
	$InStr =~ s/</&lt;/ig;		#< → &lt;
	$InStr =~ s/>/&gt;/ig;		#> → &gt;
	$InStr =~ s/"/&quot;/g;		#" → &quot;
	$InStr =~ s/'/&#39;/g;		#' → &#39;

	$InStr =~ s/\0/,/g;


	return $InStr;

}

#==============================================================================
#	改行コードのHTMLタグ化 \n → <BR>
#
#	【引数】タグ化を行なう文字列
#
#	【戻値】タグが無効化された文字列
#
#	【備考】改行コードを<BR>に変換する
#
#	【作成】06/11/09 表示文字、入力文字のタグを無効にするため
#
#==============================================================================
sub html_escapr_ret
{
	local( $InStr ) = @_;

	$InStr =~ s/\r\n/\n/g;
	$InStr =~ s/\n/<br>/g;

	return $InStr;

}

#==============================================================================
#	タグのデコード
#
#	【引数】無効化を解除する文字列
#
#	【戻値】タグが有効となった文字列
#
#	【備考】< > & " ' をそれぞれ文字列から直値に変換する
#
#==============================================================================
sub html_decode
{
	local( $InStr ) = @_;

	$InStr =~ s/&amp;/&/g;		#& → &amp;
	$InStr =~ s/&lt;/</ig;		#< → &lt;
	$InStr =~ s/&gt;/>/ig;		#> → &gt;
	$InStr =~ s/&quot;/"/g;		#" → &quot;
	$InStr =~ s/&#39;/'/g;		#' → &#39;

	return $InStr;

}


#==============================================================================
#	機種依存文字をチェック
#
# 【引数】	チェックする文字列
#
# 【戻値】	0	機種依存文字がない場合
#			1	機種依存文字が含まれる場合
#
#==============================================================================
sub pdc_chk {

	# ** 引数を変数に代入 ** #
	# チェックする文字
	@_chk_Str = @_;

	# 機種依存文字
	@_pdc_Str = (
		#半角片仮名
		"｡" , "｢" , "｣" , "､" , "･" , "ｦ" ,
		"ｧ" , "ｨ" , "ｩ" , "ｪ" , "ｫ" , "ｬ" ,
		"ｭ" , "ｮ" , "ｯ" , "ｰ" , "ｱ" , "ｲ" ,
		"ｳ" , "ｴ" , "ｵ" , "ｶ" , "ｷ" , "ｸ" ,
		"ｹ" , "ｺ" , "ｻ" , "ｼ" , "ｽ" , "ｾ" ,
		"ｿ" , "ﾀ" , "ﾁ" , "ﾂ" , "ﾃ" , "ﾄ" ,
		"ﾅ" , "ﾆ" , "ﾇ" , "ﾈ" , "ﾉ" , "ﾊ" ,
		"ﾋ" , "ﾌ" , "ﾍ" , "ﾎ" , "ﾏ" , "ﾐ" ,
		"ﾑ" , "ﾒ" , "ﾓ" , "ﾔ" , "ﾕ" , "ﾖ" ,
		"ﾗ" , "ﾘ" , "ﾙ" , "ﾚ" , "ﾛ" , "ﾜ" ,
		"ﾝ" , "ﾞ" , "ﾟ" ,
		#Windowsの機種依存文字
		"①" , "②" , "③" , "④" , "⑤" , "⑥" ,
		"⑦" , "⑧" , "⑨" , "⑩" , "⑪" , "⑫" ,
		"⑬" , "⑭" , "⑮" , "⑯" , "⑰" , "⑱" ,
		"⑲" , "⑳" , 

		"㍉" , "㌔" , "㌢" , "㍍" , "㌘" , "㌧" ,
		"㌃" , "㌶" , "㍑" , "㍗" , "㌍" , "㌦" ,
		"㌣" , "㌫" , "㍊" , "㌻" , "㎜" , "㎝" ,
		"㎞" , "㎎" , "㎏" , "㏄" , "㎡" , "㍻" ,
		"〝" , "〟" , "№" , "㏍" , "℡" , "㊤" ,
		"㊥" , "㊦" , "㊧" , "㊨" , "㈱" , "㈲" ,
		"㈹" , "㍾" , "㍽" , "㍼" , "≒" , "≡" ,
		"∫" , "∮" , "∑" , "√" , "⊥" , "∠" ,
		"∟" , "⊿" , "∵" , "∩" , "∪" ,
		#NECのIBM拡張文字
		       "褜" , "鍈" , "銈" , "蓜" , "俉" ,
		"炻" , "昱" , "棈" , "鋹" , "曻" , "彅" ,
		"丨" , "仡" , "仼" , "伀" , "伃" , "伹" ,
		"佖" , "侒" , "侊" , "侚" , "侔" , "俍" ,
		"偀" , "倢" , "俿" , "倞" , "偆" , "偰" ,
		"偂" , "傔" , "僴" , "僘" , "兊" , "兤" ,
		"冝" , "冾" , "凬" , "刕" , "劜" , "劦" ,
		"勀" , "勛" , "匀" , "匇" , "匤" , "卲" ,
		"厓" , "厲" , "叝" , "﨎" , "咜" , "咊" ,
		"咩" , "哿" , "喆" , "坙" , "坥" , "垬" ,
		"埈" , "埇" , "﨏" , "塚" , "增" , "墲" ,
		"夋" , "奓" , "奛" , "奝" , "奣" , "妤" ,
		"妺" , "孖" , "寀" , "甯" , "寘" , "寬" ,
		"尞" , "岦" , "岺" , "峵" , "崧" , "嵓" ,
		"﨑" , "嵂" , "嵭" , "嶸" , "嶹" , "巐" ,
		"弡" , "弴" , "彧" , "德" ,
		"忞" , "恝" , "悅" , "悊" , "惞" , "惕" ,
		"愠" , "惲" , "愑" , "愷" , "愰" , "憘" ,
		"戓" , "抦" , "揵" , "摠" , "撝" , "擎" ,
		"敎" , "昀" , "昕" , "昻" , "昉" , "昮" ,
		"昞" , "昤" , "晥" , "晗" , "晙" , "晴" ,
		"晳" , "暙" , "暠" , "暲" , "暿" , "曺" ,
		"朎" , "朗" , "杦" , "枻" , "桒" , "柀" ,
		"栁" , "桄" , "棏" , "﨓" , "楨" , "﨔" ,
		"榘" , "槢" , "樰" , "橫" , "橆" , "橳" ,
		"橾" , "櫢" , "櫤" , "毖" , "氿" , "汜" ,
		"沆" , "汯" , "泚" , "洄" , "涇" , "浯" ,
		"涖" , "涬" , "淏" , "淸" , "淲" , "淼" ,
		"渹" , "湜" , "渧" , "渼" , "溿" , "澈" ,
		"澵" , "濵" , "瀅" , "瀇" , "瀨" , "炅" ,
		"炫" , "焏" , "焄" , "煜" , "煆" , "煇" ,
		"凞" , "燁" , "燾" , "犱" ,
		       "猤" , "猪" , "獷" , "玽" , "珉" ,
		"珖" , "珣" , "珒" , "琇" , "珵" , "琦" ,
		"琪" , "琩" , "琮" , "瑢" , "璉" , "璟" ,
		"甁" , "畯" , "皂" , "皜" , "皞" , "皛" ,
		"皦" , "益" , "睆" , "劯" , "砡" , "硎" ,
		"硤" , "硺" , "礰" , "礼" , "神" , "祥" ,
		"禔" , "福" , "禛" , "竑" , "竧" , "靖" ,
		"竫" , "箞" , "精" , "絈" , "絜" , "綷" ,
		"綠" , "緖" , "繒" , "罇" , "羡" , "羽" ,
		"茁" , "荢" , "荿" , "菇" , "菶" , "葈" ,
		"蒴" , "蕓" , "蕙" , "蕫" , "﨟" , "薰" ,
		"蘒" , "﨡" , "蠇" , "裵" , "訒" , "訷" ,
		"詹" , "誧" , "誾" , "諟" , "諸" , "諶" ,
		"譓" , "譿" , "賰" , "賴" , "贒" , "赶" ,
		"﨣" , "軏" , "﨤" , "逸" , "遧" , "郞" ,
		"都" , "鄕" , "鄧" , "釚" ,
		"釗" , "釞" , "釭" , "釮" , "釤" , "釥" ,
		"鈆" , "鈐" , "鈊" , "鈺" , "鉀" , "鈼" ,
		"鉎" , "鉙" , "鉑" , "鈹" , "鉧" , "銧" ,
		"鉷" , "鉸" , "鋧" , "鋗" , "鋙" , "鋐" ,
		"﨧" , "鋕" , "鋠" , "鋓" , "錥" , "錡" ,
		"鋻" , "﨨" , "錞" , "鋿" , "錝" , "錂" ,
		"鍰" , "鍗" , "鎤" , "鏆" , "鏞" , "鏸" ,
		"鐱" , "鑅" , "鑈" , "閒" , "隆" , "﨩" ,
		"隝" , "隯" , "霳" , "霻" , "靃" , "靍" ,
		"靏" , "靑" , "靕" , "顗" , "顥" , "飯" ,
		"飼" , "餧" , "館" , "馞" , "驎" , "髙" ,
		"髜" , "魵" , "魲" , "鮏" , "鮱" , "鮻" ,
		"鰀" , "鵰" , "鵫" , "鶴" , "鸙" , "黑" ,
		"ⅰ" , "ⅱ" , "ⅲ" , "ⅳ" , "ⅴ" , "ⅵ" ,
		"ⅶ" , "ⅷ" , "ⅸ" , "ⅹ" , "￢" , "￤" ,
		"＇" , "＂" ,

		#Shift_JIS 非対応記号 -----------------------------------------------------

		#Windowsの機種依存文字
		"Ⅰ" , "Ⅱ" , "Ⅲ" , "Ⅳ" , "Ⅴ" , "Ⅵ" , "Ⅶ" , "Ⅷ" , "Ⅸ" , "Ⅹ" ,
		#NECのIBM拡張文字
		"纊" , "犾" ,
		#その他
		"ℓ" , "®" ,"㎥" , "㎠" , "㎤" , "㎖" , "㏔" , "㎢" , "㎳" ,
	);

	# 機種依存文字のチェック
	for ($_i = 0 ; $_i < $#_pdc_Str+1 ; $_i ++ ) {
		for ($_j = 0 ; $_j < $#_chk_Str+1 ; $_j ++) {
			if ( $_chk_Str[$_j] =~ /$_pdc_Str[$_i]/ ) {
				# 機種依存文字が存在していれば 1
				return 1;
			}
		}
	}

	# 機種依存文字が存在していなければ 0
	return 0;

}

#==============================================================================
#
#	エラー画面の表示を行う
#
#	【引数】$I_arrErr	エラーページを表示するための連想配列
#				key値	tmp_fnm		テンプレートファイル名
#						jcode		サーバー文字コード
#						perlver		Perlバージョン
#						page_title	ページタイトル
#						page_url	ページURL
#						error		エラー内容
#						del_fnm		削除するファイル（主にロックファイル）が存在した場合に
#									ファイル名を指定する
#
#	【戻値】1	正常に終了することができなかった
#
#==============================================================================
sub disp_error
{
	my $I_arrerr = shift;


	#---引数が指定されていた場合は、指定されたファイルの消去
	if( length($$I_arrerr{'del_fnm'}) > 0){
		unlink($$I_arrerr{'del_fnm'});
	}


	#---文字コードの変更
	$str_pagetitle = $$I_arrerr{'page_title'};
	$str_errmsg = $$I_arrerr{'error'};
	if( $$I_arrerr{'jcode'} eq $CONST_JCODE_SJIS){	#SJISに変換する
		if( length($$I_arrerr{'perlver'}) > 0 ){
			$str_pagetitle = &jcode_conv_utf82sjis($str_pagetitle, $$I_arrerr{'perlver'});	#タイトル
			$str_errmsg = &jcode_conv_utf82sjis($str_errmsg, $$I_arrerr{'perlver'});		#エラー内容
		}
	}
	$str_httproot = "";
	if( length($$I_arrerr{'httproot'}) > 0 ){
		$str_httproot = $$I_arrerr{'httproot'};
	}

	#---念のためエスケープ
#	$I_errmsg = &html_escapr($I_errmsg);

	#---テンプレートの表示
	open(IN,$$I_arrerr{'tmp_fnm'}) || die &disp_error_sub('templates err! (' . $$I_arrerr{'tmp_fnm'} . ')' );
	@Html_Lines = <IN>;
	close(IN);

	#---文字置き換え
	for($idx = 0; $idx < @Html_Lines; $idx++){
		$one_line = $Html_Lines[$idx];
		$one_line =~ s/#page_title#/$str_pagetitle/g;			#ページタイトル
		$one_line =~ s/#page_url#/$$I_arrerr{'page_url'}/g;		#ページURL
		$one_line =~ s/#error#/$str_errmsg/g;					#エラー内容
		$one_line =~ s/#httproot#/$str_httproot/g;					#公開側ルートパス
		$Html_Lines[$idx] = $one_line;
	}

	#---エラー画面表示
	if(( length($$I_arrerr{'perlver'}) > 0 ) && ( $$I_arrerr{'jcode'} eq $CONST_JCODE_SJIS)){
		#SJIS
		print "Content-type: text/html; charset=shift_jis\n\n";
	}
	else{
		#utf-8
		print "Content-type: text/html; charset=utf-8\n\n";
	}

	print @Html_Lines;

	exit;

}

#==============================================================================
#
#	エラー画面の表示を行う（通常のエラーメッセージではない）
#
#	【引数】$I_errmsg	表示するエラーメッセージ
#
#	【戻値】なし
#
#==============================================================================
sub disp_error_sub
{
	local( $I_errmsg ) = @_;

	print "Content-type: text/html\n\n";


print <<EOM;
<html>
<head>
<title>system error</title>
EOM

	print $I_errmsg . '<br>';

print <<EOM;
</body>
</html>
EOM

	exit;

}

#==============================================================================
#
#	日時フォーマットを指定し、日時文字列を作成する
#
#	【引数】$pDT		日時データ （例:「YYYY-mm-dd HH:ii:ss」）
#			$pFormat	日時表示フォーマット （デフォルト:「%Y年%m月%d日」）
#			$pD			日付区切り文字 （デフォルト:「-」）
#			$pT			時間区切り文字 （デフォルト:「:」）
#
#	【戻値】作成した日時文字列
#
#==============================================================================
sub dtFormat{
	#引数の取得
	local($pDT,$pFormat,$pD,$pT) = @_;
	#引数チェック
	if($pFormat eq ""){ $pFormat = '%Y年%m月%d日'; }
	if($pD eq ""){ $pD = '-'; }
	if($pT eq ""){ $pT = ':'; }

	#チェック用正規表現の作成
	$regDate = '(\d{2}|\d{4})' . $pD . '(\d{1,2})' . $pD . '(\d{1,2})';
	$regTime = '(\d{1,2})' . $pT . '(\d{1,2})(' . $pT . '(\d{1,2}))?';
	#日時
	if($pDT =~ /^$regDate $regTime$/o){
		$Y = $m = $d = $H = $i = $s = $pDT;
		$Y =~ s/^$regDate $regTime$/$1/o;
		$m =~ s/^$regDate $regTime$/$2/o;
		$d =~ s/^$regDate $regTime$/$3/o;
		$H =~ s/^$regDate $regTime$/$4/o;
		$i =~ s/^$regDate $regTime$/$5/o;
		$s =~ s/^$regDate $regTime$/$7/o;
	}
	#日付
	elsif($pDT =~ /^$regDate$/o){
		$Y = $m = $d = $pDT;
		$H = $i = $s = 0;
		$Y =~ s/^$regDate$/$1/o;
		$m =~ s/^$regDate$/$2/o;
		$d =~ s/^$regDate$/$3/o;
	}
	#時間
	elsif($pDT =~ /$regTime/o){
		$Y = $m = $d = 0;
		$H = $i = $s = $pDT;
		$H =~ s/$regTime/$1/o;
		$i =~ s/$regTime/$2/o;
		$s =~ s/$regTime/$4/o;
	}
	#その他
	else{ return $pDT; }
	#曜日の出力
	$w = $l = $a = $l_JP = $a_JP = '';
	if($Y ne "" && $m ne "" && $d ne ""){
		$w = getwday($Y,$m,$d);
		SWITCH:{
			if($w == 0){ $l = 'Sunday';			$a = 'Sun';	$l_JP = '日曜日';	$a_JP = '日'; last SWITCH; }
			if($w == 1){ $l = 'Monday';			$a = 'Mon';	$l_JP = '月曜日';	$a_JP = '月'; last SWITCH; }
			if($w == 2){ $l = 'Tuesday';		$a = 'Tue';	$l_JP = '火曜日';	$a_JP = '火'; last SWITCH; }
			if($w == 3){ $l = 'Wednesday';		$a = 'Wed';	$l_JP = '水曜日';	$a_JP = '水'; last SWITCH; }
			if($w == 4){ $l = 'Thursday';		$a = 'Thu';	$l_JP = '木曜日';	$a_JP = '木'; last SWITCH; }
			if($w == 5){ $l = 'Friday';			$a = 'Fri';	$l_JP = '金曜日';	$a_JP = '金'; last SWITCH; }
			if($w == 6){ $l = 'Saturday';		$a = 'Sat';	$l_JP = '土曜日';	$a_JP = '土'; last SWITCH; }
		}
	}
	#置換処理
	%ary = (
		'%Y'		=> '' . sprintf('%04d',$Y),						#西暦4桁
		'%y'		=> '' . substr(('' . sprintf('%04d',$Y)),2),	#西暦2桁
		'%JP_Y'		=> '' . convertJpYear($Y,$m,$d),				#和暦
		'%m'		=> '' . sprintf('%02d',$m),						#月 2桁 (01～12)
		'%n'		=> '' . sprintf('%d',$m),						#月 1～2桁 (1～12)
		'%d'		=> '' . sprintf('%02d',$d),						#日 2桁 (01～31)
		'%j'		=> '' . sprintf('%d',$d),						#日 1～2桁 (1～31)
		'%H'		=> '' . sprintf('%02d',$H),						#時 2桁 (00～23)
		'%i'		=> '' . sprintf('%02d',$i),						#分 2桁 (00～59)
		'%s'		=> '' . sprintf('%02d',$s),						#秒 2桁 (00～59)
		'%w'		=> '' . $w,										#曜日 数値 (0(日曜)～6(土曜))
		'%l'		=> '' . $l,										#曜日 英語 フルスペル (Sunday～Saturday)
		'%a'		=> '' . $a,										#曜日 英語 省略 (Sun～Sat)
		'%JP_l'		=> '' . $l_JP,									#曜日 日本語 全表記 (日曜日～土曜日)
		'%JP_a'		=> '' . $a_JP,									#曜日 日本語 省略表記 (日～土)
	);
	my $ary = join('|',(map{quotemeta} keys %ary));
	$pFormat =~ s/($ary)/$ary{$1}/eg;
	return $pFormat;
}

#==============================================================================
#
#	Zellerの公式で曜日を求める
#
#	【引数】$year	年データ
#			$mon	月データ
#			$day	日データ
#
#	【戻値】曜日を示す数字 0:日～6:土
#
#==============================================================================
sub getwday{
	my $year = shift;	# 年
	my $mon = shift;	# 月
	my $day = shift;	# 日
	
	if($mon == 1 or $mon == 2){
		$year--;
		$mon += 12;
	}
	return ($year + int($year / 4) - int($year / 100) + int($year / 400) + int((13 * $mon + 8) / 5) + $day) % 7;
}

#==============================================================================
#
#	西暦を和暦に変換する
#
#	【引数】$y		年データ
#			$m		月データ
#			$d		日データ
#
#	【戻値】和暦に変換された年
#
#==============================================================================
sub convertJpYear{
	local($y,$m,$d) = @_;
	#年月日を文字列として結合
	$ymd = sprintf("%02d%02d%02d",$y,$m,$d);
	if($ymd <= "19120729"){
		$gg = "明治";
		$yy = $y - 1867;
	}
	elsif($ymd >= "19120730" && $ymd <= "19261224"){
		$gg = "大正";
		$yy = $y - 1911;
	}
	elsif($ymd >= "19261225" && $ymd <= "19890107"){
		$gg = "昭和";
		$yy = $y - 1925;
	}
	elsif($ymd >= "19890108" && $ymd <= "20190430"){
		$gg = "平成";
		$yy = $y - 1988;
	}
	elsif($ymd >= "20190501"){
		$gg = "令和";
		$yy = $y - 2018;
	}
	if ($yy == 1) {
		$yy = '元';
	}
	return $gg . $yy;
}

#==============================================================================
#	
#	CSV出力用に文字列をエスケープ
#	
#	【引数】 $str	エスケープする文字列
#	
#	【戻値】 CSV用にエスケープされた文字列
#	
#==============================================================================
sub csvEscapeStrings{
	# 引数取得
	my ( $str ) = @_;
	
	# 「\"」を「"」に戻す
	$str =~ s/\\"/"/g;
	# 「"」を「""」にエスケープ
	$str =~ s/"/""/g;
	# 「\」を「\\」にエスケープ
	$str =~ s/\\/\\\\/g;
	
	return $str;
}

#==============================================================================
#
#	半角英数チェック
#
#==============================================================================
sub check_h_alphanumeric{
	return ( @_[0] =~ /^[a-zA-Z0-9]+$/ );
}

#==============================================================================
#
#	半角英数記号チェック
#		許可される記号
#		   # ! % & = @ ; : , _ " ' ~ ` < > 
#		   - + * / . ? { } ( ) [ ] ^ $ @ | \ 
#==============================================================================
sub check_h_alphanumeric{
	return ( @_[0] =~ /^[a-zA-Z0-9#!%&=;:,_"'~`<>\-\+\*\/\.\?\{\}\(\)\[\]\^\@\|\\]+$/ );
}

#==============================================================================
#	メール送信
#	【引数】 $mail_to			メール送信先アドレス
#	         $mail_from			メール送信元アドレス
#	         $mail_subject		メール件名
#	         $mail_body			メール本文
#	【戻値】 メール送信に成功した場合は1、そうでない場合は0を返す
#==============================================================================
sub send_mail{
	#外部ファイル読み込み
	require $main::CONST_APPLICATION_ROOT . '/common/library/mimew.pl';

	#引数の取得
	my($mail_to,$mail_from,$mail_subject,$mail_body) = @_;

	#Body部の文字コードを変更
	Jcode::convert(\$mail_body,"jis","sjis");

	#現在時間の作成
#	my($wday,$mon,$day,$now_time,$year,) = split(/ /,localtime(time));
#	my($mail_now_datetime) = sprintf("%s, %2d %s %s %s +0900",$wday,$day,$mon,$year,$now_time);

	my @ta = localtime(time());
	my ($year, $mon, $mday, $hour, $min, $sec, $wday) = 
	   ($ta[5] + 1900, $ta[4] + 1, $ta[3], $ta[2], $ta[1], $ta[0], $ta[6]);
	my $wdayname = ("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")[$wday];
	my $monname  = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
	                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")[$mon - 1];
	my $mail_now_datetime = sprintf("$wdayname, $mday $monname $year %02d:%02d:%02d +0900",
	                       $hour, $min, $sec);

	#OSがWindowsの場合は、SMTPを使用してメールを送信する
	if(-d $main::P_OS_WINDOWS){
		#オブジェクトの作成
		use Net::SMTP;
		$smtp = Net::SMTP->new(
			$main::CONST_MAIL_SERVER,		#SMTPサーバ
			Hello => $main::CONST_MAIL_DOMAIN,
		) || die return 0;

		#ヘッダ部の組み立て
		$smtp->mail($mail_from);		#送信元の指定
		#宛先が複数ある可能性があるため配列へ分割
		@mail_to_ary = split(/,/,$mail_to);
		$smtp->to(@mail_to_ary);		#宛先の指定

		#メール件名の文字コードを変更
		Jcode::convert(\$mail_subject,"jis","sjis");

		#データ部の組み立て
		$smtp->data();
		$smtp->datasend("From:" . &main::mimeencode($mail_from) . "\n");			#送信元
		$smtp->datasend("To:" . $mail_to . "\n");									#宛先(データ部）
		$smtp->datasend("Subject:" . &main::mimeencode($mail_subject) . "\n");		#件名
		$smtp->datasend("Reply-To:" . &main::mimeencode($mail_from) . "\n");		#返信先
		$smtp->datasend("Date: " . &main::mimeencode($mail_now_datetime) . "\n");	#現在日時
		$smtp->datasend("Content-Transfer-Encoding: 7bit\n");						#タイプ
		$smtp->datasend("Content-Type: text/plain; charset=ISO-2022-JP\n\n");		#タイプ
		$smtp->datasend($mail_body);												#本文

		# データの終わり、メール送信
		$smtp->dataend();
		#SMTP接続の終了
		$smtp->quit; 
	}
	#OSがLinuxの場合は、sendmailを使用してメールを送信する
	else{
		#ヘッダ部の組み立て
		$mail_head =	"To: $mail_to\n" .
						"From: " . &main::mimeencode($mail_from) . "\n" .
						"Reply-To: " . &main::mimeencode($mail_from) . "\n" .
						"Date: " . &main::mimeencode($mail_now_datetime) . "\n" .
						"Subject: " . &main::mimeencode($mail_subject) . "\n" .
						"Content-Transfer-Encoding: 7bit\n" .
						"Content-Type: text/plain; charset=ISO-2022-JP\n\n";
		#Header部の文字コードを変更
		Jcode::convert(\$mail_head,"jis","sjis");

		#メール送信
		open(MAIL,"| $main::CONST_SEND_MAIL_DIR_PATH -t -i -f " . $mail_from) || die return 0;
		print MAIL $mail_head;
		print MAIL $mail_body;
		close(MAIL);
	}
	#正常終了
#==============================================================================
# 使用するテンプレート情報を取得
# 
# @param  $_[0] アンケート種別(0: アンケート 1: 問い合わせ )
# @param  $_[1] 使用テンプレート
# @param  $_[2] 出力文字コード
# @param  $_[2] サーバー文字コード
# 
# @return %ret  テンプレート情報
# 
#==============================================================================
sub get_template_info {
	# 引数取得
	local $form_type     = $_[0];
	local $template      = $_[1];
	local $charcode      = $_[2];
	local $setting_jcode = $_[3];
	
	# 変数初期化
	# 戻値
	local %ret = ();
	# テンプレートディレクトリ
	# $form_type == 1 の場合は、アンケート。1以外は、お問い合わせ
	local $template_dir = ($form_type == 1 ? $main::CONST_QUESTION_TEMPLATE_INQUIRY_DIR_PATH : $main::CONST_QUESTION_TEMPLATE_ENQUETE_DIR_PATH );
	# 指定テンプレート
	if ($template ne "" && -d $template_dir."/".$template ) {
		$template_dir .= "/".$template;
	}
	# 基本テンプレート
	elsif ($main::CONST_QUESTION_DEFAULT_TEMPLATE_DIR ne "" ) {
		$template_dir .= "/".$main::CONST_QUESTION_DEFAULT_TEMPLATE_DIR;
	}
	
	# テンプレート
	$ret{'tpl_confirm'}  = $template_dir."/".$main::CONST_QUESTION_TEMPLATE_CONFIRM_NAME;
	$ret{'tpl_complete'} = $template_dir."/".$main::CONST_QUESTION_TEMPLATE_COMPLETE_NAME;
	$ret{'tpl_error'}    = $template_dir."/".$main::CONST_QUESTION_TEMPLATE_ERROR_NAME;
	$ret{'tpl_ret_mail'}    = $template_dir."/".$main::CONST_QUESTION_TEMPLATE_MAIL_BODY_NAME;
	# ディレクトリの区切りを調整
	$ret{'tpl_confirm'}  =~ s,/+,/,g;
	$ret{'tpl_complete'} =~ s,/+,/,g;
	$ret{'tpl_error'}    =~ s,/+,/,g;
	$ret{'tpl_ret_mail'} =~ s,/+,/,g;
	
	# 出力文字コード
	$charcode = lc $charcode;
	$ret{'charcode'} = ($charcode eq "shift_jis" || $charcode eq "sjis" ? $main::CONST_JCODE_SJIS : $setting_jcode );
	
	return %ret;
}
	return 1;
}

1;
