#==============================================================================
# イベントカレンダー用設定ファイル
# イベントカレンダーで使用する定数や設定を定義する
#==============================================================================

BEGIN {
	#------------------------------------------------------------------------------
	# 共通設定ファイル読み込み
	#------------------------------------------------------------------------------
	require $APPLICATION_ROOT_DIR . '/common/com_setting.pl';
	
	require $APPLICATION_ROOT_DIR . '/common/com_setting_msg.pl';
	#------------------------------------------------------------------------------
	# 共通設定
	#------------------------------------------------------------------------------
	# HTTPリファラチェックフラグ (0:チェック無効 / 1:チェック有効)
	our $CONST_ENABLE_REFERER_CHECK_FLG = 1;
	# 各種イベント情報表示機能
	# キャッシュファイルの有効期限(秒)
	our $CONST_CACHE_FILE_EXPIRATUON_DATE = 300;
	our $CONST_EVENT_CAL_MULTI_PREVENTION_SAVE_FILE_DIR = $main::CONST_PUBLIC_APPLICATION_ROOT_DIR_PATH . '/event_cal_multi/data';
	# 各種イベント情報表示機能
	#------------------------------------------------------------------------------
	# イベントカレンダー用設定
	#------------------------------------------------------------------------------
	# CSVファイル保存先フォルダ名
	our $CONST_EVENT_CSV_DIR_PATH = $CONST_PRIVATE_APPLICATION_ROOT_DIR_PATH . '/event_cal_multi/csv';
	# テンプレートファイル保存先フォルダ名
	our $CONST_EVENT_TEMPLATE_DIR_PATH = $CONST_PUBLIC_APPLICATION_ROOT_DIR_PATH . '/templates/event_cal_multi';
	# エラー画面テンプレートファイル名
	our $CONST_EVENT_TEMPLATE_FILE_NAME_ERROR = 'error.tpl';
	
	# 1ヶ月の表示週数 (6週間)
	our $CONST_EVENT_WEEK_MAX = 6;
	# 1週間の表示日数 (7日間)
	our $CONST_EVENT_WEEK_DAY_MAX = 7;
	# 1日のイベント表示件数 (0にするとすべて表示)
	our $CONST_EVENT_DAY_NUM = 5;
	# 日別のイベント表示件数 (0にするとすべて表示)
	our $CONST_EVENT_DAY_PAGE_NUM = 30;
	
	# 前月のリンク有効数 (当月を含む6ヶ月前まで)
	our $CONST_EVENT_PREV_MAX_MONTH = 5;
	# 次月のリンク有効数 (当月を含まず6ヶ月後まで)
	our $CONST_EVENT_NEXT_MAX_MONTH = 6;
	
	# 帯表示機能 (0:帯表示しない / 1:帯表示する)
	# ※変更する際にはテンプレートの変更も必要
	our $CONST_EVENT_COLSPAN_DISPLAY = 1;
	
	# 帯表示時に使用する色分け
	our $CONST_EVENT_COLSPAN_COLOR_CODING_STR = 'event_genre';
	
	# 祝日表示機能 (0:祝日表示しない / 1:祝日表示する)
	our $CONST_EVENT_HOLIDAY_FLG = 1;
	
	# サブサイト対応及び各種イベント情報表示機能
	# 定型項目の区切り文字
	our $CONST_KANKO_LINK_DELIMITER = '|@cms@|';
	# 定型の画像が無い場合の画像パス
	our $CONST_EVENT_NO_IMAGE_SRC = '/shared/templates/free/images/contents/event/list_day_img.png';
	# 定型の画像が無い場合の代替文字列
	our $CONST_EVENT_NO_IMAGE_ALT = 'no image';
	#ジャンル（イベントカテゴリ）名取得用ハッシュ
	our %CONST_GENRE_NAME_HASH = (
		#siteid
		'1' => {
			#genre number
			'1' => '講座・催し',
			'2' => '子育て・教育',
			'3' => 'ふれあい館・ひろば館',
			'4' => 'お祭り',
			'5' => '生涯学習・文化',
			'6' => 'スポーツ',
			'7' => '福祉・健康',
			'8' => 'その他',
		},
	);
	# サブサイト対応及び各種イベント情報表示機能

	# 日付の表示フォーマット
	our $CONST_EVENT_DATE_PREV_FORMAT = '%Y年%n月%j日（%wday_jp曜日）';
	our $CONST_EVENT_DATE_PREV_FORMAT_HOUR = ' %G時';
	our $CONST_EVENT_DATE_PREV_FORMAT_MINUTE = '';
	our $CONST_EVENT_DATE_PREV_FORMAT_SECOND = '';
	our $CONST_EVENT_DATE_PASTERN_FORMAT = ' ～ ';
	
	# 前の月へのリンク文言
	our $CONST_EVENT_PREV_MONTH_STR = '前月';
	# 次の月へのリンク文言
	our $CONST_EVENT_NEXT_MONTH_STR = '次月';
	
	# 使用パラメータ連想配列
	our %CONST_EVENT_USE_PARAMETER_HASH = (
		# パラメータ名
		'type' => {
			# データタイプ
			'data_type' => 'INT',
			# データ数（単数 or 複数）
			'data_num' => 'SINGLE',
			# データ区切り（複数の場合）
			# ※区切り指定には正規表現も可能
			'split_str' => '',
			# 必須フラグ
			'need' => 0,
			# デフォルト値
			'default' => '1',
			# チェック
			'check' => ['NUM', 'RANGE(1,3)'],
			# 検索値として使用するフラグ
			'select_data' => 0,
			# 詳細設定
			'detail' => {
				'1' => {
					'name' => '7曜カレンダー',
					'template' => 'template_month_7w.tpl',
				},
				'2' => {
					'name' => 'リストカレンダー',
					'template' => 'template_month_list.tpl',
				},
				'3' => {
					'name' => '日別カレンダー',
					'template' => 'template_day.tpl',
				},
			},
		},
		'year' => {
			'data_type' => 'INT',
			'data_num' => 'SINGLE',
			'need' => 0,
			'default' => $CONST_NOW_DATATIME{'year'},
			'check' => ['NUM', 'RANGE(2000,2037)'],
			'select_data' => 0,
		},
		'month' => {
			'data_type' => 'INT',
			'data_num' => 'SINGLE',
			'need' => 0,
			'default' => $CONST_NOW_DATATIME{'month'},
			'check' => ['NUM', 'RANGE(1,12)'],
			'select_data' => 0,
		},
		'day' => {
			'data_type' => 'INT',
			'data_num' => 'SINGLE',
			'need' => 0,
			'default' => $CONST_NOW_DATATIME{'day'},
			'check' => ['NUM', 'RANGE(1,31)'],
			'select_data' => 0,
		},
		'page' => {
			'data_type' => 'INT',
			'data_num' => 'SINGLE',
			'need' => 0,
			'default' => '1',
			'check' => ['NUM'],
			'select_data' => 0,
		},
		'template' => {
			'data_type' => 'TEXT',
			'data_num' => 'MANY',
			'split_str' => '[\s]',
			'need' => 0,
			'default' => '',
			'check' => [],
			'select_data' => 0,
		},
		# 検索用定型項目
		'event_category' => {
			'data_type' => 'INT',
			'data_num' => 'MANY',
			'split_str' => ',',
			'need' => 0,
			'default' => '',
			'check' => ['NUM', 'RANGE(1,9)'],
			'select_data' => 1,
		},
		'keyword' => {
			'data_type' => 'TEXT',
			'data_num' => 'MANY',
			'split_str' => '[\s]',
			'need' => 0,
			'default' => '',
			'check' => [],
			'select_data' => 1,
			'detail' => {
				# 検索対象CSVカラム名
				'check_column_csv' => [
					'page_title',
				],
			},
		},
		# サブサイト対応及び各種イベント情報表示機能
		# 検索用項目
		'event_genre' => {
			'data_type' => 'INT',
			'data_num' => 'MANY',
			'split_str' => ',',
			'need' => 0,
			'default' => '',
			'check' => ['NUM', 'RANGE(1,9)'],
			'select_data' => 1,
		},
		'event_area' => {
			'data_type' => 'INT',
			'data_num' => 'MANY',
			'split_str' => ',',
			'need' => 0,
			'default' => '',
			'check' => ['NUM', 'RANGE(1,9)'],
			'select_data' => 1,
		},
		'event_target' => {
			'data_type' => 'INT',
			'data_num' => 'MANY',
			'split_str' => ',',
			'need' => 0,
			'default' => '',
			'check' => ['NUM', 'RANGE(1,9)'],
			'select_data' => 1,
		},
		# サブサイト対応
		'siteid' => {
			'data_type' => 'INT',
			'data_num' => 'SINGLE',
			'need' => 0,
			'default' => '1',
			'check' => ['NUM'],
			'select_data' => 0,
		},
		# サブサイト対応及び各種イベント情報表示機能
	);
	
	# 置換対象リスト
	our %CONST_EVENT_REPLACE_TEMPLATE_HASH = (
		'start' => '<!-- InstanceBeginEditable name="%s" -->',
		'end' => '<!-- InstanceEndEditable name="%s" -->',
	);
	
	# サブサイト対応及び各種イベント情報表示機能 
	#------------------------------------------------------------------------------
	# 近日開催イベント用設定
	#------------------------------------------------------------------------------
	# 使用パラメータ連想配列
	our %CONST_UPCOMING_EVENT_USE_PARAMETER_HASH = (
		'siteid' => {
			'data_type' => 'INT',
			'data_num' => 'SINGLE',
			'need' => 1,
			'default' => '',
			'check' => ['NUM'],
			'select_data' => 0,
		},
	);
	
	# キャッシュファイル名
	our $CONST_UPCOMING_EVENT_CACHE_FILE_NAME = 'upcoming_event.dat';
	# 近日判定する日数
	our $CONST_UPCOMING_EVENT_DAY = 10;
	# 返すデータ件数
	our $CONST_UPCOMING_EVENT_RESP_DATA = 20;

	#------------------------------------------------------------------------------
	# ピックアップイベント用設定
	#------------------------------------------------------------------------------
	# 使用パラメータ連想配列
	our %CONST_PICKUP_EVENT_USE_PARAMETER_HASH = (
		'siteid' => {
			'data_type' => 'INT',
			'data_num' => 'SINGLE',
			'need' => 1,
			'default' => '',
			'check' => ['NUM'],
			'select_data' => 0,
		},
	);
	#キャッシュファイル名
	our $CONST_PICKUP_EVENT_CACHE_FILE_NAME = 'pickup_event.dat';
	# 返すデータ件数
	our $CONST_PICKUP_EVENT_RESP_DATA = 30;
	#ピックアップフラグがONの値
	our $CONST_PICKUP_FLAG_ON = 1;
	# サブサイト対応及び各種イベント情報表示機能

	#------------------------------------------------------------------------------
	# ファイル読込み時に自動実行する処理
	#------------------------------------------------------------------------------
	# 祝日のモジュールが使用可能かチェック
	if (!eval('require "Calendar/Japanese/Holiday.pm"')) {
		$CONST_EVENT_HOLIDAY_FLG = 0;
	}

	# 内部エンコードの指定
	our $CONST_PERL_INNER_CHAR_CODE = 'UTF-8';

	# Perlバージョンの設定
	our $CONST_PERL_VERSION = sprintf('%d.%d.%d', $1, $2, $3) if ($] =~ /(\d+)\.(\d{1,3})\.?(\d{1,3})/);
	# デフォルトの言語コード指定
	our $CONST_DEFAULT_LANGUAGE = 'ja';
	
	# 文字コードリスト
	our %CONST_CHAR_CODE_LIST_HASH = (
		'utf8' => 'utf-8',
		'utf-8' => 'utf-8',
		'shift_jis' => 'shift_jis',
		'sjis' => 'shift_jis',
		'euc-jp' => 'euc-jp',
		'sjis-win' => 'cp932',
		'cp932' => 'cp932',
	);
}
# サブサイト対応及び各種イベント情報表示機能
BEGIN {
	#------------------------------------------------------------------------------
	# ファイル読込み時に自動実行するプログラム
	#------------------------------------------------------------------------------
	# ライブラリフォルダにパスを通す
	# ライブラリフォルダにパスを通す
	use lib $main::CONST_PUBLIC_APPLICATION_ROOT_DIR_PATH  . '/event_cal_multi/library';
}
# サブサイト対応及び各種イベント情報表示機能

1;
