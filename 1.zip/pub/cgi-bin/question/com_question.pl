package pack_com_question;
#==============================================================================
#	アンケート　共通関数群
#
#
#==============================================================================


#==============================================================================
#	必用引数のチェック
#
#	【引数】$input			フォームから入力された値が格納されている連想配列
#			$err_msg		エラー内容
#
#	【戻値】0	エラーなし
#			1	エラーあり
#
#
#==============================================================================
sub chk_imput_item
{
	local ($input) = shift if @_;
	local(*err_msg ) = @_;

	$err_msg = "";

	#---ページID
	if( !exists $$input{'page_id'} ){
		$err_msg = $err_msg . "<li>ページIDが指定されていません。</li>";
	}
	else{
		if( length($$input{'page_id'}) <= 0){
			$err_msg = $err_msg . "<li>ページIDが指定されていません。</li>";
		}
	}

	#---ページタイトル
	if( !exists $$input{'page_title'} ){
		$err_msg = $err_msg . "<li>ページタイトルが指定されていません。</li>";
	}
	else{
		if( length($$input{'page_title'}) <= 0){
			$err_msg = $err_msg . "<li>ページタイトルが指定されていません。</li>";
		}
	}

	#---ページURL
	if( !exists $$input{'page_url'} ){
		$err_msg = $err_msg . "<li>ページURLが指定されていません。</li>";
	}
	else{
		if( length($$input{'page_url'}) <= 0){
			$err_msg = $err_msg . "<li>ページURLが指定されていません。</li>";
		}
	}

	#---項目数
	if( !exists $$input{'item_cnt'} ){
		$err_msg = $err_msg . "<li>項目数が指定されていません。</li>";
	}
	else{
		if( length($$input{'item_cnt'}) <= 0){
			$err_msg = $err_msg . "<li>項目数が指定されていません。</li>";
		}
	}

	#---フォーム種別
	if( !exists $$input{'form_type'} ){
		$err_msg = $err_msg . "<li>フォーム種別が指定されていません。</li>";
	}
	else{
		if( length($$input{'form_type'}) <= 0){
			$err_msg = $err_msg . "<li>フォーム種別が指定されていません。</li>";
		}
		else{
			if(( $$input{'form_type'} ne 0 ) && ( $$input{'form_type'} ne 1 ) && ( $$input{'form_type'} ne 2 )){
				$err_msg = $err_msg . "<li>フォーム種別に処理できない値が指定されています。</li>";
			}
		}
	}

	if( length($err_msg) > 0 ){
		return 1;
	}
	else{
		return 0;
	}

}

#==============================================================================
#	アクセス制限をチェックする
#	【引数】 $remotoAddr	リモートアドレス
#	         *err_msg		エラーメッセージ
#	【戻値】 アクセス制限が無い場合は1、そうでない場合は0を返す
#==============================================================================
sub chkAccess{
	#引数の取得
	my($remotoAddr) = shift if @_;	#リモートアドレス
	local(*err_msg) = @_;			#エラーメッセージ

	#定数の宣言
	local(@P_LimitRemotoHost) = @main::P_LimitRemotoHost;	#アクセス制限リスト

	#変数の宣言
	my($remotoHost) = &getHostByAddr($remotoAddr);	#リモートホスト
	my($remotoDate) = "";							#リモートアクセスの日付
	my($remotoTime) = "";							#リモートアクセスの時間
	my($log_Count) = 0;								#ログ中の出現回数
	my($log_Date) = "";								#ログ中の最終アクセス日付
	my($log_Time) = "";								#ログ中の最終アクセス時間

	#指定アクセス制限のチェック
	for(my($i) = 0;$i < @P_LimitRemotoHost;$i++){
		if($remotoAddr eq $P_LimitRemotoHost[$i] || $remotoHost eq $P_LimitRemotoHost[$i]){
			$err_msg .= "アクセス制限により、お問い合わせを行なうことが出来ません。";
			return 0;
		}
	}
	
	# 現在日時の取得
	my($mday, $mon, $year) = (localtime(time))[3..5];
	# 日付の補正
	$year += 1900;
	$mon += 1;
	# 日付フォーマットの設定
	$year = sprintf('%04d', $year);
	$mon = sprintf('%02d', $mon);
	$mday = sprintf('%02d', $mday);
	
	# ログファイルの読み込み設定
	my($logFileName) = $main::P_LimitLogSaveDir . "/" . $year . $mon . $mday . ".log";
	#ファイルの存在チェック
	if(-f $logFileName){
		#ログファイルの読み込み
		unless(open(LOG_IN,"< " . $logFileName)){
			$err_msg .= "ログファイルの読み込みに失敗しました。";
			return 0;
		}
		#一行ごと読み込み&解析
		while($line = <LOG_IN>){
			#改行を消す
			chomp($line);
			#一行を分割する
			my($csv_date,$csv_time,$csv_remotoAddr,$csv_remotoHost) = split(/,/,$line);
			#リモートアドレス or リモートホストがある場合
			if($remotoAddr eq $csv_remotoAddr || $remotoHost eq $csv_remotoHost){
				$log_Date = $csv_date;
				$log_Time = $csv_time;
				$log_Count++;
			}
		}
		#ファイルクローズ
		close(LOG_IN);
		#同日中の送信制限チェック
		if($main::P_LimitDay != 0 && $log_Date ne ""){
			#設定ファイルと比較
			if($log_Count >= $main::P_LimitDay){
				$err_msg .= "お問い合わせ最大回数制限により、お問い合わせを行なうことが出来ません。<br />明日以降に、再度お試しください。";
				return 0;
			}
		}
		#時間制限チェック
		if($main::P_LimitTime != 0 && $log_Time ne ""){
			#ログにあった最終投稿時間を秒に変換
			if($log_Time =~ /(\d+?)時(\d+?)分(\d+?)秒/){ $log_Time = $1 * 3600 + $2 * 60 + $3; }
			my($s,$m,$h) = (localtime(time))[0..2];
			#現在の時刻を秒に変換
			$remotoTime = $h * 3600 + $m * 60 + $s;
			#設定ファイルと比較
			if($remotoTime - $log_Time <= $main::P_LimitTime){
				$err_msg .= "現在、お問い合わせを行なうことが出来ません。<br />しばらく時間を置いてから、再度お試しください。";
				return 0;
			}
		}
	}
	return 1;
}

#==============================================================================
#	ホスト名を逆引きする
#	【引数】 $ip	逆引きしたいリモートアドレス
#	【戻値】 逆引きした結果（逆引きできればホスト名、出来なければIPを返す）
#==============================================================================
sub getHostByAddr{
	#引数の取得
	my($ip) = @_;
	#IPアドレスの解析
	my @addr = split(/\./, $ip);
	if(@addr != 4){ return $ip; }
	#逆引き実行
	my($name) = gethostbyaddr(pack("C4",@addr),2);
	#結果を返す
	return $name ? $name : $ip;
}

#==============================================================================
#	ホスト名を正引きする
#	【引数】 $hostname	正引きしたいリモートホスト名
#	【戻値】 正引きした結果（正引きできればIPの配列、出来なければホスト名を返す）
#==============================================================================
sub getHostByName{
	#引数の取得
	my($hostname) = @_;
	#正引き実行
	my($name,$aliases,$addrtype,$length,@ipaddr) = gethostbyname($hostname);
	my(@ip) = ();
	foreach(@ipaddr){
		push(@ip,join('.',unpack('C4',$_)));
	}
	#結果を返す
	return @ip ? @ip : $hostname;
}

1;
