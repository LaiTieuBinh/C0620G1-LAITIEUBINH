BEGIN {
# 簡易版FAQ用 問い合わせフォーム

#------------------------------------------------------------------------------
#	環境パス
#------------------------------------------------------------------------------
	
	#--- お問合せ先設定機能CGIまでのパス
	$P_PrevApplicationRoot = "/example/cgi-bin/simple_faq";
	#--- 非公開ディレクトリパス
	$P_PrevNoAccessRoot    = "/example/simple_faq";
	#--- HTTPルートパス
	$P_PrevHttpRoot        = "http://www.example.jp";
	#-- SSL対応の、環境までの相対パスの存在する場所 
	$P_PrevHttpRoot_Ssl    = 'http://www.example.jp';
	#--- HTTP CGI設置パス
	$P_PrevHttpCgiRoot     = "http://www.example.jp/cgi-bin/simple_faq";
	
	#--- 内部ドメインとして認識するURL
	@P_PrevValidHttpDomain = (
		$P_PrevHttpRoot,
		$P_PrevHttpRoot_Ssl
	);
	
	#--- データを登録するCSV保存ディレクトリ
	$P_SaveCsvDir          = $P_PrevNoAccessRoot    . '/csv';
	
	#--- フォーム項目CSV
	$P_loadCsv             = $P_PrevApplicationRoot . '/template/item.csv';
	
	#--- ロックファイル
	$strLookFnmlockFile    = $P_PrevApplicationRoot . '/lock/lock.lck';
	
#-------------------------------------------------------------------------------
#	HTTPリファラチェック
#-------------------------------------------------------------------------------
# Refererを確認し、「@P_PrevValidHttpDomain」に設定されているドメインのサイト以
# 外からのアクセスの場合にエラーとする制限です。
# ※ブラウザやパーソナルファイアウォール等の設定でRefererを送信しないように設定
# 　している閲覧者からのアクセスもチェックが行えないためエラーとなります。
# 
	# 1 = HTTPリファラチェックを有効にします。（デフォルト）
	# 0 = HTTPリファラチェックを無効にします。
	$ENABLE_REFERER_CHECK = 1;
	
#------------------------------------------------------------------------------
#	メール設定
#------------------------------------------------------------------------------
	
	#--- SendMailパス
	$P_SendMail     = '/usr/sbin/sendmail';
	
	#--- メールサーバー関連（Windows用）
	$P_MailServer   = 'mail.glode.co.jp';
	
	#--- メールドメイン（Windows用）
	$P_MyMailDomain = 'glode.co.jp';
	
	#--- 宛先不明（未指定）の場合の送信先アドレス ※ウェブマスター
	$MAIL_TO_WEB_MASTER = 'system_info@cms8341.jp';
	
	#--- メールの送信元アドレス
	$MAIL_FROM = 'system_info@cms8341.jp';
	
	# 送信元アドレスに指定するアドレスの設定
	# = 0 : $MAIL_FROM のアドレス
	# = 1 : フォームに入力されたアドレス(問い合わせ者のアドレス)
	#       未入力の場合は $MAIL_FROM を使用
	$MAIL_FROM_FLG = 0;
	
	#--- メール件名
	$MAIL_SUBJECT  = '【WEBサイトから問い合わせがありました】';
	
	#--- メール本文用テンプレート
	$TMP_INQUIRY_MAIL_FORMT = $P_PrevApplicationRoot . '/template/mail.txt';
	
	#--- メール記載用の HTTP ROOT (公開サーバ)
	$MAIL_HTTP_ROOT = 'http://192.168.0.220';

#------------------------------------------------------------------------------
#	メール自動返信機能
#------------------------------------------------------------------------------

	#自動返信メールタイトル
	$P_ReturnMailSubject = '【XX市】お問い合わせを受け付けました';
	#自動返信メール送信元
	$P_MailFromAddress = 'system_info@cms8341.jp';
	#アクセスログの保存先
	$P_LimitLogSaveDir = '/example/cgi-bin/question/log';
	#メール本文テンプレート
	$P_QuestionMailBody = $P_PrevApplicationRoot . "/template/return_mail.tpl";
	#常に制限を行なうアクセス元情報
	@P_LimitRemotoHost = (
	);
	#連続送信制限（指定した時間（秒）を経過しないと再送信不可 0:制限無し）
	$P_LimitTime = 300;
	#一日の送信数制限（一日に送信できる最大数を指定 0:制限無し）
	$P_LimitDay = 10;
	#自動返信メールに記載するお問い合わせ先
	$P_InformationStr = '' . "\n";

#------------------------------------------------------------------------------
#	CSV出力設定
#------------------------------------------------------------------------------
	
	# 出力機能の On(1)／Off(0)
	$P_SaveCsvOutPutFlg = 1;
	
	# 出力文字コード ※ "sjis" or "utf8"
	$P_SaveCsvCharSet   = 'sjis';
	
#------------------------------------------------------------------------------
#	HTMLテンプレート・完了画面
#------------------------------------------------------------------------------
	
	#--- テンプレート
	$TMP_INQUIRY_FORM          = $P_PrevApplicationRoot . '/template/form.tpl';         # フォーム画面
	$TMP_INQUIRY_CONFIRM       = $P_PrevApplicationRoot . '/template/confirm.tpl';      # 確認画面
	$TMP_INQUIRY_ERROR         = $P_PrevApplicationRoot . '/template/error.tpl';        # エラー画面
	$TMP_INQUIRY_COMPLETE      = $P_PrevApplicationRoot . '/template/thanks.tpl';       # 完了画面
	
	$TMP_INQUIRY_INPUT_FOMAT   = $P_PrevApplicationRoot . '/template/form_input.tpl';   # フォームのフォーマット(入力用)
	$TMP_INQUIRY_CONFIRM_FOMAT = $P_PrevApplicationRoot . '/template/form_confirm.tpl'; # フォームのフォーマット(確認用)
	
	#--- 完了画面
	$HTML_INQUIRY_COMPLETE     = $P_PrevHttpCgiRoot     . '/thanks.cgi';
	
#------------------------------------------------------------------------------
#	定数
#------------------------------------------------------------------------------
	
	require $P_PrevApplicationRoot.'/common/constants.pl';
	
#------------------------------------------------------------------------------
#	ファイル読込み時に自動実行するプログラム
#------------------------------------------------------------------------------
	require $P_PrevApplicationRoot . '/common/autorun.pl';
	
#---end------------------------------------------------------------------------
}
1;
