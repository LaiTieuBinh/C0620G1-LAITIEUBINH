#==============================================================================
# イベントカレンダー 共通関数群
#	イベントカレンダーで使用する共通関数を記述します。
#==============================================================================

#==============================================================================
# パッケージの宣言
#==============================================================================
package pack_com_event;

#==============================================================================
# 共通パッケージの読み込み
#==============================================================================
use Time::Local;

#==============================================================================
# カレンダー用配列を生成
#	【引数】
#			取得する年 西暦4桁
#			取得する月
#			一ヶ月の月週数
#			一週間の日数
#	【戻値】
#			カレンダー形式の二次元配列を返す
#	【備考】
#			指定された年月の一ヶ月のカレンダーを取得し二次元配列に格納
#			週は、日曜日から始まり土曜日が最終となる
#==============================================================================
sub getCalendarArray {
	# 引数の取得
	my ($year, $month, $month_max, $week_max) = @_;
	my @calender_table_ary = ();

	# 引数で指定された年月の1日の曜日を求める
	my $first_day_week = (localtime(timelocal(0, 0, 0, 1, $month - 1, $year)))[6];
	# 引数で指定された年月の末日を求める
	my $last_day = &getLastDay($year, $month);
	# 日付けカウンタ
	my $day = 1;
	# カレンダー配列にセット
	for ($week_index = 0; $week_index < $month_max; $week_index++) {
		for ($wday_index = $first_day_week; $wday_index < $week_max; $wday_index++) {
			# 末日以前の場合
			if ($day <= $last_day) {
				$calender_table_ary[$week_index][$wday_index] = $day++;
			}
			# 末日以降の場合
			else {
				$calender_table_ary[$week_index][$wday_index] = '';
			}
		}
		$first_day_week = 0;
	}
	return @calender_table_ary;
}

#==============================================================================
# テンプレートの置換対象のエリアを「取得」or「置換」する
#	【引数】
#			string $proc_mode 処理モード 'get' or 'replace'
#			string $target_area_name 取得、置換対象エリア名
#			string $target_str 取得、置換対象文字列
#			string $replace_after_str 置換後文字列（置換時のみ使用）
#	【戻値】
#			string 「取得」または「置換」された文字列
#==============================================================================
sub replaceTemplateArea {
	my ($proc_mode, $target_area_name, $target_str, $replace_after_str) = @_;
	my $ret_str = '';
	my $start_tag = '';
	my $end_tag = '';
	
	# 置き換え対象文字列取得
	if ($proc_mode eq 'get') {
		$start_tag = &pack_com_cgi::regReplace(sprintf($main::CONST_EVENT_REPLACE_TEMPLATE_HASH{'start'}, $target_area_name));
		$end_tag = &pack_com_cgi::regReplace(sprintf($main::CONST_EVENT_REPLACE_TEMPLATE_HASH{'end'}, $target_area_name));
		$ret_str = $1 if ($target_str =~ /(?:.|\n)*?(?:$start_tag)((?:.|\n)+?)(?:$end_tag)(?:.|\n)*?/i);
	}
	# 置き換え対象文字列置換
	elsif ($proc_mode eq 'replace') {
		$start_tag = sprintf($main::CONST_EVENT_REPLACE_TEMPLATE_HASH{'start'}, $target_area_name);
		$end_tag = sprintf($main::CONST_EVENT_REPLACE_TEMPLATE_HASH{'end'}, $target_area_name);
		$replace_before_str = &replaceTemplateArea('get', $target_area_name, $target_str);
		$ret_str = &pack_com_cgi::strReplace($start_tag . $replace_before_str . $end_tag, $replace_after_str, $target_str);
	}
	return $ret_str;
}

#==============================================================================
# 指定された年月の末日を取得する
#	【引数】
#			int $year 取得する年
#			int $month 取得する月
#	【戻値】
#			int 取得された末日
#==============================================================================
sub getLastDay {
	my ($year, $month) = @_;
	my $last_day = 0;
	
	# 桁を整える
	$month = $1 if(length($month) == 2 && $month =~ /^0(.)$/);
	# 末日を求める
	$last_day = (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)[$month - 1] + ($month == 2 and $year % 4 == 0 and ($year % 400 == 0 or $year % 100 != 0));
	return $last_day;
}

#==============================================================================
# 日時の文字列を指定されたフォーマットの文字列に変換する
#	【引数】
#			string $datetime 時間文字列（yyyy/mm/dd hh:mm:ssなど）
#			string 変換フォーマット文字列（%Y年%m月%d日など）
#	【戻値】
#			フォーマットの形式に変換された文字列
#==============================================================================
sub getStrToFormatDate {
	my ($datetime, $format) = @_;
	my $ret_str = '';
	
	# 日時形式の文字列だった場合
	if ($datetime =~ /(\d{2,4})(?:[[:punct:]])(\d{1,2})(?:[[:punct:]])(\d{1,2})(?:[\s[:punct:]](\d{1,2})(?:[[:punct:]])(\d{1,2})(?:[[:punct:]])(\d{1,2}))?/) {
		my %rep_date = (
			'%Y' => $1,
			'%m' => sprintf('%02d', $2),
			'%n' => sprintf('%d', $2),
			'%d' => sprintf('%02d', $3),
			'%j' => sprintf('%d', $3),
			'%H' => sprintf('%02d', $4),
			'%G' => sprintf('%d', $4),
			'%i' => sprintf('%02d', $5),
			'%s' => sprintf('%02d', $6),
		);
		# 存在する日付の場合
		if (&isDateExists($1, $2, $3)) {
			$wday = (localtime(timelocal(0, 0, 0, $3, $2 - 1, $1)))[6];
			$rep_date{'%wday_jp'} = ('日', '月', '火', '水', '木', '金', '土')[$wday];
			$ret_str = $format;
			foreach my $rep_key (keys(%rep_date)) {
				$ret_str =~ s/$rep_key/$rep_date{$rep_key}/g;
			}
		}
		else {
			$ret_str = $datetime;
		}
	}
	# 日時形式の文字列に一致しなかった場合
	else {
		$ret_str = $datetime;
	}
	return $ret_str;
}

#==============================================================================
# 日時存在チェック
#	【引数】
#			string $datetime 時間文字列（yyyy/mm/dd hh:mm:ssなど）
#			string 変換フォーマット文字列（%Y年%m月%d日など）
#	【戻値】
#			フォーマットの形式に変換された文字列
#==============================================================================
sub isDateExists {
	my($year, $mon, $day) = @_;
	eval {timelocal(0, 0, 0, $day, $mon-1, $year-1900);};
	if($@) {
		return 0;
	}
	return 1;
}

#==============================================================================
# 前の月リンクを生成する
#	【引数】
#			int $prev_year 指定された年
#			int $prev_month 指定された月
#			string $params_str URLへ追加するパラメータ
#			int $type タイプ
#	【戻値】
#			string 生成されたリンク文字列
#==============================================================================
sub getLinkPrevMonth {
	my ($prev_year, $prev_month, $params_str, $type) = @_;
	my $ret_str = '';
	
	# 現在日から最大で遡れる年月を求める
	my $max_prev_year = $main::CONST_NOW_DATATIME{'year'};
	my $max_prev_month = $main::CONST_NOW_DATATIME{'month'} - $main::CONST_EVENT_PREV_MAX_MONTH;
	while ($max_prev_month <= 0) {
		$max_prev_year -= 1;
		$max_prev_month += 12;
	}
	$max_prev_month = sprintf('%2.2d', $max_prev_month);
	my $max_prev_ym = ($max_prev_year . $max_prev_month) + 0;
	
	# 現在表示している年月から一ヶ月前の月を取得
	$prev_month -= 1;
	if ($prev_month <= 0) {
		$prev_year -= 1;
		$prev_month += 12;
	}
	$prev_month = sprintf('%2.2d', $prev_month);
	my $prev_ym = ($prev_year . $prev_month) + 0;
	
	# 現在から一ヶ月前の年月が、最大で遡れる年月より前の場合はリンクを切る
	if ($prev_ym < $max_prev_ym) {
		$ret_str = $main::CONST_EVENT_PREV_MONTH_STR . "\n";
	}
	# 現在から一ヶ月前の年月が、最大で遡れる年月より後の場合はリンクを作成
	else {
#		$params_str =~ s/(\W)/'%' . unpack('H2', $1)/ego;
		$ret_str = '<a href="calendar.cgi?type=' . $type . '&amp;year=' . $prev_year . '&amp;month=' . sprintf('%d', $prev_month) . $params_str . '">' . $main::CONST_EVENT_PREV_MONTH_STR . '</a>';
	}
	
	return $ret_str;
}

#==============================================================================
# 次の月リンクを生成する
#	【引数】
#			int $next_year 指定された年
#			int $next_month 指定された月
#			string $params_str URLへ追加するパラメータ
#			int $type タイプ
#	【戻値】
#			string 生成されたリンク文字列
#==============================================================================
sub getLinkNextMonth {
	my ($next_year, $next_month, $params_str, $type) = @_;
	my $ret_str = '';
	
	# 現在日から最大で進める年月を求める
	my $max_next_year = $main::CONST_NOW_DATATIME{'year'};
	my $max_next_month = $main::CONST_NOW_DATATIME{'month'} + $main::CONST_EVENT_NEXT_MAX_MONTH;
	while ($max_next_month > 12) {
		$max_next_year += 1;
		$max_next_month -= 12;
	}
	$max_next_month = sprintf('%2.2d', $max_next_month);
	my $max_next_ym = ($max_next_year . $max_next_month) + 0;
	
	# 現在表示している年月から一ヶ月先の月を取得
	$next_month += 1;
	if ($next_month > 12) {
		$next_year += 1;
		$next_month -= 12;
	}
	$next_month = sprintf('%2.2d', $next_month);
	my $next_ym = ($next_year . $next_month) + 0;
	
	# 現在から一ヶ月先の年月が、最大で進める年月より後の場合はリンクを切る
	if ($next_ym > $max_next_ym) {
		$ret_str = $main::CONST_EVENT_NEXT_MONTH_STR . "\n";
	}
	# 現在から一ヶ月先の年月が、最大で進める年月より前の場合はリンクを作成
	else {
#		$params_str =~ s/(\W)/'%' . unpack('H2', $1)/ego;
		$ret_str = '<a href="calendar.cgi?type=' . $type . '&amp;year=' . $next_year . '&amp;month=' . sprintf('%d', $next_month) . $params_str . '">' . $main::CONST_EVENT_NEXT_MONTH_STR . '</a>';
	}
	
	return $ret_str;
}

#==============================================================================
# CSVの1行分のデータを読み込む
#	【引数】
#			CSVの1行分の文字列
#	【戻値】
#			array 読み込んだCSVを区切った配列
#==============================================================================
sub getCsvLine {
	my ($csv_line_str) = @_;
	my @ret_ary = ();
	
	# 改行コードの統一
	$csv_line_str =~ s/\r\n/\n/g;
	$csv_line_str =~ s/\r/\n/g;
	# カラム毎のデータを読み込む
	while ($csv_line_str =~ s/"(.*?)"[\n,]//) {
		push(@ret_ary, $1);
	}
	
	return @ret_ary;
}
# 各種イベント情報表示機能
#==============================================================================
# CSVのデータを読み込む
#	【引数】
#			CSVのパス
#	【戻値】
#			array CSVヘッダ
#			array CSVデータ
#			int     CSVデータ行数
#==============================================================================
sub getCsvData {
	my ($event_csv_file_path) = @_;
	my $line_cnt = 0;
	my @csv_header_ary = ();
	my @csv_line_ary = ();
	
	# ファイルオープン
	if (sysopen(IN, $event_csv_file_path, O_RDONLY) == 0) {
		$err_hash{'error_code'} = '006';
		$err_hash{'error_msg'} = basename($event_csv_file_path);
		&pack_com_cgi::dispError(\%system_hash, \%err_hash);
	}
	eval{
		flock(IN, 1);
	};
	
	# ファイル内容の取得
	while (my $temp_csv_line = <IN>) {
		# エスケープされたダブルクォートを「@@escape_double_quote@@」に置換
		$temp_csv_line =~ s/\\\"/\@\@escape_double_quote\@\@/g;
		# ダブルクォートが偶数になるまで取り出す
		while ($temp_csv_line =~ tr/"// % 2 and !eof(IN)) {
			# 一行データに追加
			$temp_csv_line .= <IN>;
			# エスケープされたダブルクォートを「@@escape_double_quote@@」に置換
			$temp_csv_line =~ s/\\\"/\@\@escape_double_quote\@\@/g;
		}
		# 「@@escape_double_quote@@」をエスケープされたダブルクォートに置換
		$temp_csv_line =~ s/\@\@escape_double_quote\@\@/\\\"/g;
		# 末尾の改行をカンマに置換
		$temp_csv_line =~ s/(?:\x0D\x0A|[\x0D\x0A])?$/,/;
		# 項目毎に区切る
		my @csv_line = map {/^"(.*)"$/s ? scalar($_ = $1, s/\\\"/"/g, $_) : $_} ($temp_csv_line =~ /("[^"]*(?:\\\"[^"]*)*"|[^,]*),/g);
		# CSVで取得した値の数だけループ
		for (my $csv_column_cnt = 0; $csv_column_cnt < @csv_line; $csv_column_cnt++) {
			# 1行目の場合はヘッダー取得
			if ($line_cnt == 0) {
				# ヘッダー文字列を配列に格納
				$csv_header_ary[$csv_column_cnt] = $csv_line[$csv_column_cnt];
			}
			# 1行目以外はデータを取得
			else {
				# 配列に格納
				$csv_line_ary[($line_cnt - 1)]->{$csv_header_ary[$csv_column_cnt]} = $csv_line[$csv_column_cnt];
			}
		}
		$line_cnt++;
	}
	close(IN);
	return \@csv_header_ary,\@csv_line_ary,$line_cnt;
}	
# 各種イベント情報表示機能
1;
