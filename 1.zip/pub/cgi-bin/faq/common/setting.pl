BEGIN {
#------------------------------------------------------------------------------
#	環境パス
#------------------------------------------------------------------------------

	#--- お問合せ先設定機能CGIまでのパス
	$P_PrevApplicationRoot = "/example/cgi-bin/faq";
	#--- 非公開ディレクトリパス
	$P_PrevNoAccessRoot    = "/example/cgi-bin/faq";
	#--- HTTPルートパス
	$P_PrevHttpRoot        = "http://www.example.jp";
	#--- HTTP CGI設置パス
	$P_PrevHttpCgiRoot     = "http://www.example.jp/cgi-bin/faq";
	
	#--- 内部ドメインとして認識するURL
	@P_PrevValidHttpDomain = (
		"http://www.example.jp",
		"https://www.example.jp"
	);
	
	#--- データを登録するCSV
	$P_SaveCsv             = $P_PrevNoAccessRoot    . '/csv/save.csv';
	
	#--- フォーム項目CSV
	$P_loadCsv             = $P_PrevApplicationRoot . '/template/item.csv';
	
	#--- ロックファイル
	$strLookFnmlockFile    = $P_PrevApplicationRoot . '/lock/lock.lck';
	$strLookFnmlockFolder  = $P_PrevApplicationRoot . '/lock/cms';

#------------------------------------------------------------------------------
#---環境によっては古い Jcode.pm が使用されているためCGI付属のJcode.pmを使用
#------------------------------------------------------------------------------
	require $P_PrevApplicationRoot."/Jcode.pm";
	Jcode->import();

#-------------------------------------------------------------------------------
#	HTTPリファラチェック
#-------------------------------------------------------------------------------
# Refererを確認し、「@P_PrevValidHttpDomain」に設定されているドメインのサイト以
# 外からのアクセスの場合にエラーとする制限です。
# ※ブラウザやパーソナルファイアウォール等の設定でRefererを送信しないように設定
# 　している閲覧者からのアクセスもチェックが行えないためエラーとなります。
# 
	# 1 = HTTPリファラチェックを有効にします。（デフォルト）
	# 0 = HTTPリファラチェックを無効にします。
	$ENABLE_REFERER_CHECK = 1;

#------------------------------------------------------------------------------
#	HTMLテンプレート・完了画面
#------------------------------------------------------------------------------
	
	#--- テンプレート
	$TMP_INQUIRY_FORM          = $P_PrevApplicationRoot . '/template/form.tpl';         # フォーム画面
	$TMP_INQUIRY_CONFIRM       = $P_PrevApplicationRoot . '/template/confirm.tpl';      # 確認画面
	$TMP_INQUIRY_ERROR         = $P_PrevApplicationRoot . '/template/error.tpl';        # エラー画面
	$TMP_INQUIRY_COMPLETE      = $P_PrevApplicationRoot . '/template/thanks.tpl';       # 完了画面
	
	$TMP_INQUIRY_INPUT_FOMAT   = $P_PrevApplicationRoot . '/template/form_input.tpl';   # フォームのフォーマット(入力用)
	$TMP_INQUIRY_CONFIRM_FOMAT = $P_PrevApplicationRoot . '/template/form_confirm.tpl'; # フォームのフォーマット(確認用)
	
	#--- 完了画面
	$HTML_INQUIRY_COMPLETE     = $P_PrevHttpCgiRoot     . '/thanks.cgi';
	
#------------------------------------------------------------------------------
#	総合窓口
#------------------------------------------------------------------------------

	#--- 総合窓口として判断されるメールアドレス
	$INTEGRATRTED_MAIL  = '';

#------------------------------------------------------------------------------
#	定数
#------------------------------------------------------------------------------

	#--- 改行コード
	$BR_CODE   = '<br>';

	#--- HTTPルート置き換え用
	$HTTP_ROOT  = '#%HTTP_ROOT%#';

	#--- FORM部分
	$INNER_FORM = '#%FORM%#';

	#--- エラー置き換え
	$ERROR_MSG  = '#%ERROR_MSG%#';

	# -- 宛先となるメールアドレス
	$DEPT = 'dept';

	# -- このページのURL
	$PAGE = 'page';

	# -- 組織コード
	$CODE = 'code';

	# -- プルダウン初期値
	$PULLDOWN_BASE = '選択してください';

	# -- 必須表示
	$NEED_MESSAGE  = '<strong style="color:#990000;">(必須)</strong>';

	#--- 宛先となるメールアドレス登録カラム
	$DEPT_CLM   = 'charge';

	#--- ページのURL
	$PAGE_CLM   = 'referrer_url';

	#--- 組織コード
	$CODE_CLM   = 'dept_code';

	#--- 値を比較する項目
	@COMPARE = (
		['is_answer','^要$','1'],
		['is_answer','^不要$','0'],
	);

#------------------------------------------------------------------------------
#	ファイル読込み時に自動実行するプログラム
#------------------------------------------------------------------------------
	require $P_PrevApplicationRoot . '/common/autorun.pl';
	
#---end------------------------------------------------------------------------
}
1;
