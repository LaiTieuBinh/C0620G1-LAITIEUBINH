<?php
/**
 * Zend FW application
 * (c)2015 a.ide
 */
require_once ABSTRACTZEND_PATH."/models/AbstractIndex.php";

class Search extends AbstractIndex {

	/** constructor */
	public function __construct($controller = null) {
		parent::__construct($controller);
	}

	/**
	 * exec
	 */
	public function exec($request = array()) {

		//get data
		$start = $this->getStartPosition();

		$data = $this->getDataTable($start);
		$hitcnt = $data->count;
		$rows = $data->rows;

		//html
		$htmlrec = $this->createHtml($rows, $hitcnt);
		return $htmlrec;
	}

}
?>
