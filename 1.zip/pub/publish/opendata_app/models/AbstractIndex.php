<?php
/**
 * Zend FW application
 * (c)2015 a.ide
 */
require_once ABSTRACTZEND_PATH."/models/ApplicationException.php";
require_once ABSTRACTZEND_PATH."/models/_lib/Request.php";
require_once ABSTRACTZEND_PATH."/models/_lib/HtmlSearchForm.php";
require_once ABSTRACTZEND_PATH."/models/_lib/HtmlSearchResult.php";
require_once ABSTRACTZEND_PATH."/models/_lib/HtmlPagenate.php";

abstract class AbstractIndex {

	protected $appConfig = null;
	protected $viewPath = null;
	protected $isSubmit = false;

	protected $request = null;

	//DB TBL_OPEN_DATA object
	protected $opendata = null;


	/**
	 * abstract exec
	 */
	public abstract function exec($request = array());


	/**
	 * constructor
	 */
	public function __construct($controller = null) {
		//shared info
		$this->appConfig = $controller->appConfig;
		$this->viewPath = $controller->viewPath;
		$this->isSubmit = $controller->isPost;
		//request object
		$request = $controller->getRequest()->getParams();
		$this->request = new Request($request, $this->appConfig);
	}

	/////

	/**
	 * get start position of rows
	 */
	protected function getStartPosition() {
		$page = $this->request->page;
		// 検索条件の表示件数をセット
		$datacnt = $this->request->items['displayedresults'];
		return (($page - 1) * $datacnt) + 1;
	}

	/**
	 * get open_data information from DB
	 * @param $start data position (first=1)
	 */
	protected function getDataTable($start = 1) {
		require_once "_lib/DBOpenData.php";
		$this->opendata = new DBOpenData($this->request, $this->request->items['displayedresults'], $start);

//DEBUG a.ide
//print "DEBUG: ".get_class().": SQL=".$this->opendata->SQL."<br>\n";

		return $this->opendata;
	}

	/**
	 * create HTML search result
	 * @param $rows
	 * @param $hitcnt [optional] data hit count
 	 */
	protected function createHtml($rows = array(), $hitcnt = 0) {

		//get data start position
		$start = $this->getStartPosition();

		//result
		$view = $this->createView();
		$result = new HtmlSearchResult($view, $this->request, $rows, $hitcnt, $start, $this->appConfig);
		$htmlrec = $result->html;

		//paging
		$pagenate = new HtmlPagenate($view, $this->request, $hitcnt, $this->appConfig->application->html);
		$htmlpage = $pagenate->html;

		//form
		$view = $this->createView();
		$form = new HtmlSearchForm($view, $this->request, $this->appConfig->application->form, $this->opendata->selectOptions);
		$htmlsearchform = $form->html;

		//html
		$view = $this->createView();
		$view->addColumnItems("searchform", $htmlsearchform);
		$view->addColumnItems("searchresult", $htmlrec);
		$view->addColumnItems("pagenate", $htmlpage);
		$htmlrec = $view->render("index.phtml");
		return $htmlrec;
	}

	/**
	 * create View object
	 */
	protected function createView($viewpath = null) {
		$viewpath = (empty($viewpath)) ? $this->viewPath : $viewpath;
		$view = new View();
		$view->setScriptPath($this->viewPath);
		return $view;
	}


}
?>
