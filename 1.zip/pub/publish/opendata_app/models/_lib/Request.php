<?php
/**
 * Zend FW application
 * (c)2015 a.ide
 */
class Request {

	public static $SORT_DEFAULT = "asc";

	//shared parameter
	public $page = 1;
	public $pagestart = 1;

	public $isSort = false;	//sortクリック
	public $sort = "asc";
	public $sortcolname = "data_link_title";

	//searchForm parameter (key=value)
	public $items = array();

	//searchForm queryString
	public $query = null;

	/**
	 * constructor
	 */
	public function __construct($request = null, $config = null) {
		extract($request);

		//パラメーター
		if (isset($p)) {
			$wks = explode("_", $p);
			$this->page = $wks[0];
			$this->pagestart = $wks[1];
		}

		if (isset($desc)) {
			$this->sort = "desc";
			$this->sortcolname = $desc;

		}else if (isset($asc)) {
			$this->sort = self::$SORT_DEFAULT;
			$this->sortcolname = $asc;
		}
		if (isset($sort)) {
			$this->isSort = true;
			$this->sort = ($this->sort == self::$SORT_DEFAULT) ? "desc" : self::$SORT_DEFAULT;
			$this->page = 1;
			$this->pagestart = 1;
		}else{
			$this->isSort = false;
		}

		//リクエストから除去する要素一覧(配列化)
		$exitems = explode(",", $config->application->form->select->excludeItems);

		//searchForm
		$this->items["keyword"] = (isset($keyword)) ? $keyword : null;

		$items = (isset($categories)) ? $this->excludeItems($categories, $exitems) : array();
		$this->items["categories"] = $items;
		
		$items = (isset($datatypes)) ? $this->excludeItems($datatypes, $exitems) : array();
		$this->items["datatypes"] = $items;

		//$items = (isset($opens)) ? $this->excludeItems($opens, $exitems) : array();
		//$this->items["open"] = $items;

		$items = (isset($licenses)) ? $this->excludeItems($licenses, $exitems) : array();
		$this->items["licenses"] = $items;

		$this->items["data_time_str"] = (isset($data_time_str)) ? str_replace("/", "-", $data_time_str) : null;
		$this->items["data_time_end"] = (isset($data_time_end)) ? str_replace("/", "-", $data_time_end) : null;

		$this->items["data_upddt_str"] = (isset($data_upddt_str)) ? str_replace("/", "-", $data_upddt_str) : null;
		$this->items["data_upddt_end"] = (isset($data_upddt_end)) ? str_replace("/", "-", $data_upddt_end) : null;
		
		$items = (isset($keishikis)) ? $this->excludeItems($keishikis, $exitems) : array();
		$this->items["keishikis"] = $items;

		//$items = (isset($soshikis)) ? $this->excludeItems($soshikis, $exitems) : array();
		//$this->items["soshikis"] = $items;

		$items = (isset($dept_codes)) ? $this->excludeItems($dept_codes, $exitems) : array();
		$this->items["dept_codes"] = $items;
		
		// 表示件数 検索の場合は受け取った値、初期表示時など指定が無い場合は設定ファイルのデフォルト件数をセットする
		$this->items["displayedresults"] = (isset($displayedresults)) ? $displayedresults : $config->application->html->maxDataCntPage;
		
		$this->query = $this->createRequestUri();
	}

	/////

	//選択肢の削除 (※要素から「指定なし」を削除する)
	private function excludeItems($items, $excludeitems) {
		if (empty($items) || (!is_array($items))) {
			return array();
		}
		$newitems = array();
		foreach ($items as $item) {
			if (in_array($item, $excludeitems)) {
				continue;
			}
			$newitems[] = $item;
		}
		return $newitems;
	}

	//query文字列(検索フォームのパラメータ)の作成
	private function createRequestUri() {
		$params = array();
		foreach ($this->items as $key => $value) {		
			if (empty($value)) {
				continue;
			}
			if (is_string($value)) {
				$params[$key] = $value;

			}else if ((is_array($value)) && (count($value) > 0)) {
				$params[$key] = $value;
			}
		}
		$qry = http_build_query($params);
		return $qry;
	}

}
?>
