<?php
/**
 * Zend FW application
 * (c)2015 a.ide
 */
class DBOpenData {

	static $TABLENAME = "tbl_open_data";

	static $COLNAMES = array(
		"data_id",
		"data_num",
		"data_link_title",
		"data_link_target",
		"summary",
		"license",
		"category",
		"data_type",
		"data_upddt",
		"data_open",
		"page_id",
		"path",
		"title",
		"template_id",
		"cate_1st",
		"cate_2st",
		"cate_3st",
		"cate_4st",
		"publish_start",
		"publish_end",
		"dept_code",
		"adddt",
		"upddt",
		"data_hidden",
		"data_size",
		"data_time",
		"keyword",
		"od_data_type"
	);

/*
    data_id integer NOT NULL,
    data_num smallint NOT NULL,
    data_link_title character varying(256),
    data_link_url character varying(512),
    data_link_target character varying(8),
    summary text,
    license smallint NOT NULL,
    category character varying(256),
    data_type character varying(16),
    data_upddt date NOT NULL,
    data_open smallint,
    page_id integer,
    path character varying(256),
    title character varying(256),
    template_id smallint,
    cate_1st character varying(16),
    cate_2st character varying(16),
    cate_3st character varying(16),
    cate_4st character varying(16),
    publish_start timestamp without time zone,
    publish_end timestamp without time zone,
    dept_code character varying(16),
    adddt timestamp without time zone,
    upddt timestamp without time zone,
    data_hidden smallint,
    data_size integer
 */

	public $count = 0;
	public $rows = array();

	public $selectOptions = array();


	public $SQL = null;	//DEBUG a.ide
	
	private $_db;

	/**
	 * constructor: execute SQL
	 * @param $request
	 * @param $datacnt [optional] datacount/page
	 * @param $start [optional] startposition (first=1)
	 */
	public function __construct($request, $datacnt = 0, $start = 1) {
		try{
			$db = Zend_Registry::getInstance()->dbAdapter;
			$this->_db = $db;
			//DB検索(ヒット件数)
			$sqls = $this->createSQL($request, true);
			$stmt = $db->prepare($sqls["SQL"]);
			$stmt->execute();
			while ($row = $stmt->fetch()) {
				$this->count = $row["count"];
				break;
			}
			$stmt->closeCursor();

			//DB検索(表示データ取得) ※WHEREを再利用する
			$sqls = $this->createSQL($request, false, $sqls["WHERE"], $datacnt, ($start - 1));

			$this->SQL = $sqls["SQL"];

			$stmt = $db->prepare($sqls["SQL"]);
			$stmt->execute();
			$cols = array();
			while ($row = $stmt->fetch()) {
				$cols["data_link_title"] = $row["data_link_title"];
				$cols["data_link_url"] = $row["data_link_url"];
				$cols["data_link_target"] = $row["data_link_target"];
				$cols["summary"] = $row["summary"];
				$cols["license"] = $row["license"];
				$cols["category"] = $row["category"];
				$cols["data_type"] = $row["data_type"];
				$cols["data_upddt"] = $row["data_upddt"];
				$cols["data_open"] = $row["data_open"];
				$cols["publish_start"] = $row["publish_start"];
				$cols["publish_end"] = $row["publish_end"];
				$cols["dept_code"] = $row["dept_code"];
				$cols["path"] = $row["path"];
				$cols["data_time"] = $row["data_time"];
				$cols["keyword"] = $row["keyword"];
				$cols["od_data_type"] = $row["od_data_type"];
				
				$this->rows[] = $cols;
			}
			$stmt->closeCursor();

			//searchFormの<select>タグ<option>用の要素を取得
			$colnames = array("category", "license", "od_data_type", "data_type", "dept_code");
			$this->selectOptions = $this->getSelectItems($db, $colnames);

			$db->closeConnection();
			return;

		}catch(Exception $ex) {
			throw new Exception("unknown SQL, DBOpenData: sql={$sqls['SQL']}");
		}
	}

	//////

	/**
	 * searchFormの<SELECT>の<option>の値を取得
	 */
	private function getSelectItems($db, $colnames, $default = "指定なし") {
		try{
			$items = array();
			foreach ($colnames as $colname) {
				$sql = "SELECT DISTINCT {$colname} FROM ".self::$TABLENAME . " WHERE NOT {$colname} IS NULL ORDER BY {$colname}";
				$stmt = $db->prepare($sql);
				$stmt->execute();
				$rows = array($colname => $default);
				while ($row = $stmt->fetch()) {
					$rows[] = $row[$colname];
				}
				$stmt->closeCursor();
				$items[$colname] = $rows;
			}
			return $items;

		}catch(Exception $ex) {
			throw new Exception("unknown SQL, DBOpenData: sql={$sql}");
		}
	}

	/////

	//SQL作成 (検索)
	private function createSQL($request = null, $iscount = false, $where = null, $limit = 0, $offset = 0) {
		if ($iscount) {
			//件数取得
			$sql = "SELECT count(*) as count FROM ".self::$TABLENAME;
			$sort = null;
			$limit = null;
			//where句を作成 ※データ取得で再利用するため返却値に含める→※１参照
			$where = $this->createSQLWhere($request);

		}else{
			//データ取得
			$sql = "SELECT * FROM ".self::$TABLENAME;
			if(in_array($request->sortcolname, self::$COLNAMES)){
				$sort = "ORDER BY ".$request->sortcolname." ".strtoupper($request->sort);
			}else{
				$sort = null;
			}
			$offset = ($offset < 0) ? 0 : $offset;
			$limit = ($limit == 0) ? null : "LIMIT {$limit} OFFSET {$offset}";
		}
		$res = array(
			"SQL" => "{$sql} {$where} {$sort} {$limit}",
			"WHERE" => "{$where}"	//※１
		);
		return $res;
	}

	//WHERE句の作成
	private function createSQLWhere($request = null) {
		//固定条件のwhere句
		//$where = "(NOT (data_hidden IS NOT NULL AND data_hidden=1))";
		$where = "";
		
		//リクエストパラメータがない
		if (empty($request)) {
			return $where;
		}

		//カラムごとの条件を作成
		$items = array();
		extract($request->items);

		//LIKE句は「OR」で繋げる。
		$colnames = array("data_link_title", "summary", "title", "keyword");
		$items[] = $this->createSQLWhereLIKE($colnames, $keyword);

		//オープンデータ
		$items[] = (empty($open)) ? null : $this->_db->quoteInto("data_open = ?",$open);

		//データ時点 日付形式以外は無視
		$data_time_str = HtmlSearchForm::checkDateAndAjust($data_time_str);
		$data_time_end = HtmlSearchForm::checkDateAndAjust($data_time_end);
		$dtst = $this->_db->quoteInto("data_time >= ?",$data_time_str);
		$dted = $this->_db->quoteInto("data_time <= ?",$data_time_end);
		if (!empty($data_time_str)) {
			if (!empty($data_time_end)) {
				$items[] = "({$dtst} AND {$dted})";
			}else{
				$items[] = "({$dtst})";
			}
		}else{
			if (!empty($data_time_end)) {
				$items[] = "({$dted})";
			}
		}

		//掲載日 日付形式以外は無視
		$data_upddt_str = HtmlSearchForm::checkDateAndAjust($data_upddt_str);
		$data_upddt_end = HtmlSearchForm::checkDateAndAjust($data_upddt_end);
		$dtst = $this->_db->quoteInto("data_upddt >= ?",$data_upddt_str);
		$dted = $this->_db->quoteInto("data_upddt <= ?",$data_upddt_end);
		if (!empty($data_upddt_str)) {
			if (!empty($data_upddt_end)) {
				$items[] = "({$dtst} AND {$dted})";
			}else{
				$items[] = "({$dtst})";
			}
		}else{
			if (!empty($data_upddt_end)) {
				$items[] = "({$dted})";
			}
		}		
		
		//複数選択項目
		$items[] = $this->explodeValueWhere("category", $categories);
		$items[] = $this->createSQLWhereIN("license", $licenses);
		$items[] = $this->createSQLWhereIN("od_data_type", $datatypes);
		$items[] = $this->createSQLWhereIN("data_type", $keishikis,'str');
		$items[] = $this->createSQLWhereIN("dept_code", $dept_codes,'str');
		
		//WHERE句を作成(各カラムの条件を"AND"でつなぐ)
		foreach ($items as $item) {
			if (empty($item)) {
				continue;
			}
			if (empty($where)) {
				$where = "{$item}";
			}else{
				$where = "{$where} AND {$item}";
			}
		}
		if (empty($where)) {
			return null;
		}
		return "WHERE {$where}";
	}

	//keywordのLIKE句「((colname LIKE '%VALUE%') OR (colname LIKE '%VALUE%') OR ・・・)・・」
	private function createSQLWhereLIKE($colnames, $string) {
		$rec = null;
		$com = null;
		$strs = preg_split('/ |　/', $string);
		foreach ($colnames as $colname) {
			$rec2 = null;
			$com2 = null;
			foreach ($strs as $str) {
				if (empty($str)) {
					continue;
				}
				$rec2 = "{$rec2}{$com2}{$colname} LIKE ".$this->_db->quote("%{$str}%");
				$com2 = " OR ";
			}
			if (empty($rec2)) {
				continue;
			}
			$rec = "{$rec}{$com}{$rec2}";
			$com = " OR ";
		}
		if (empty($rec)) {
			return null;
		}
		$rec = "({$rec})";
		return $rec;
	}

	//複数指定の場合のIN句「(colname IN ('VALUE','VALUE',・・・))」
	private function createSQLWhereIN($colname, $array, $type = 'int') {
		if (!is_array($array)) {
			return null;
		}
		$rec = null;
		$rec2 = null;
		$com = null;
		$isnull = false;
		foreach ($array as $item) {
			if ((empty($item)) && (empty($rec2))) {
				//選択肢に"空"がある場合、nullと空を検索対象にする
				$rec2 = "({$colname} IS NULL OR {$colname}='')";
				continue;
			}
			switch($type){
				case 'int'://数値型
					//数字以外は無視
					if(!@is_numeric($item)){
						continue 2;
					}
					break;
				default:
					break;
			}
			$rec = "{$rec}{$com}{$this->_db->quote($item)}";
			$com = ",";
		}
		if (empty($rec)) {
			if (empty($rec2)) {
				return null;
			}
			return $rec2;
		}
		if (empty($rec2)) {
			$rec = "({$colname} IN ({$rec}))";
		}else{
			$rec = "({$colname} IN ({$rec}) OR {$rec2})";
		}
		return $rec;
	}

	//カテゴリ複数指定の場合OR句
	private function explodeValueWhere($column, $param) {
		$rec = null;
		if (empty($param)) {
			return $rec;
		}
		$paramAry = (!is_array($param)) ? explode(',', $param) : $param;
		foreach ( $paramAry as $value ) {
			$val = "'(^|,)" . $value . "(,|$)'";
			$regex_opr = ' ~ ';
			$db = Zend_Registry::getInstance()->dbAdapter;
			if ($db instanceof Zend_Db_Adapter_Pdo_Mysql) {
				$regex_opr = ' REGEXP ';
			}
			$rec .= ' OR ' . '(' . $column . $regex_opr . $val . ')';
		}
		$rec = '('.preg_replace('/^\sOR\s/i', '', $rec).')';
		return $rec;
	}
}
?>
