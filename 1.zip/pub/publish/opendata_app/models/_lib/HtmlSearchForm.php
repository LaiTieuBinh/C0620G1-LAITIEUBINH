<?php
/**
 * Zend FW application
 * (c)2015 a.ide
 */
class HtmlSearchForm {

	static $PHTML = "searchForm.phtml";

	public $html = null;

	/**
	 * constructor
	 * @param $view ZendFW View object
	 * @param $request request object
	 * @param $forminfo [optional]  application.form object in app.ini
	 * @param $items [optional] select items
	 */
	public function __construct($view, $request, $forminfo = null, $items = null) {

		$phtml = self::$PHTML;

		//html(select option)
		extract($request->items);
		$select = $forminfo->select;
		/** old
		$categories = $this->getSelectOption($select->categories, $view, $categories);
		$open = $this->getSelectOption($select->opens, $view, $open);
		$licenses = $this->getSelectOption($select->licenses, $view, $licenses);
		$keishikis = $this->getSelectOption($select->keishikis, $view, $keishikis);
		$soshikis = $this->getSelectOption($select->soshikis, $view, $soshikis);
		 */
		
		//new
		$categories = $this->getSelectOption(Config_Const::$CATEGORY, $view, $categories,true);
		$datatypes = $this->getSelectOption(Config_Const::$DATA_TYPE, $view, $datatypes,true);
		//$open = $this->getSelectOption($select->opens, $view, $open);
		$licenses = $this->getSelectOption(Config_Const::$LICENSE, $view, $licenses,true);
		$keishikis = $this->getSelectOption($items["data_type"], $view, $keishikis);
		//$soshikis = $this->getSelectOption($select->soshikis, $view, $soshikis);
		$dept_code = $this->getSelectOption($items["dept_code"], $view, $dept_codes);
		// 表示件数(その他検索項目と違い複数選択しない。選択項目の結果画面への反映の為現状のgetSelectOption内の処理に合わせて第3パラメータをarrayキャスト)
		$displayedresults = $this->getSelectOption(Config_Const::$MAXROW, $view, (array)$displayedresults, true);
		
		//html
		$view->setSearchPattern("searchform");
		$view->addColumnItems("keyword", htmlspecialchars($keyword));
		$view->addColumnItems("categories", $categories);
		$view->addColumnItems("datatypes", $datatypes);
		//$view->addColumnItems("opens", $open);
		$view->addColumnItems("licenses", $licenses);

		//日付は'/'で統一 2015/02/24
		//$view->addColumnItems("data_time_str", $data_time_str);
		//$view->addColumnItems("data_time_end", $data_time_end);
		//$view->addColumnItems("data_upddt_str", $data_upddt_str);
		//$view->addColumnItems("data_upddt_end", $data_upddt_end);
		//(isset($data_time_str)) ? str_replace("/", "-", $data_time_str) : null;
		
		$view->addColumnItems("data_time_str", (isset($data_time_str)) ? self::checkDateAndAjust($data_time_str) : null);
		$view->addColumnItems("data_time_end", (isset($data_time_end)) ? self::checkDateAndAjust($data_time_end) : null);
		$view->addColumnItems("data_upddt_str", (isset($data_upddt_str)) ? self::checkDateAndAjust($data_upddt_str) : null);
		$view->addColumnItems("data_upddt_end", (isset($data_upddt_end)) ? self::checkDateAndAjust($data_upddt_end) : null);
		$view->addColumnItems("keishikis", $keishikis);
		//$view->addColumnItems("soshikis", $soshikis);
		$view->addColumnItems("dept_codes", $dept_code);
		$view->addColumnItems("displayedresults", $displayedresults);
		
		$htmlrec = $view->render($phtml);
		$this->html = $htmlrec;
	}

	private function getSelectOption($csv, $view, $request, $useKey = false) {
		if (is_array($csv)) {
			$items = $csv;
		}else{
			$items = explode(",",$csv);
		}
		$htmlrec = null;
		$view->setSearchPattern("select_option");
		foreach ($items as $key => $item) {
			if ((is_array($request)) && (in_array($item, $request))) {
				$selected = "selected";

			}else if ((is_string($request)) && ($item == $request)) {
				$selected = "selected";

			}else{
				$selected = null;
			}
			if($useKey){
				$view->addColumnItems("value", $key);	//value
				if ((is_array($request)) && (in_array($key, $request))){
					$selected = "selected";
				}
			}else{
				$view->addColumnItems("value", $item);	//value
			}
			$view->addColumnItems("text", $item);	//表示項目
			$view->addColumnItems("selected", $selected);
			$htmlrec .= trim($view->render(HtmlSearchForm::$PHTML))."\n";
		}
		return $htmlrec;
	}

	//日付チェック&整形
	public static function checkDateAndAjust($date){
		$pregCheck = preg_match('/^(\d{4})([-\/]\d{1,2}|\d{2})([-\/]\d{1,2}|\d{2})/',$date);
		$timeCheck = (@strtotime($date) !== false);
		if($pregCheck && $timeCheck){
			return date('Y/m/d',strtotime($date));
		}
		return '';
	}

}
?>
