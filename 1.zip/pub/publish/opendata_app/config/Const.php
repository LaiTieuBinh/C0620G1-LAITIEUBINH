<?php

class Config_Const {
	//カテゴリ
	public  static  $CATEGORY = array(
		'指定なし' => '指定なし',
		1 => '防災・減災',
		2 => '計画・財政・行革',
		3 => '健康・福祉・医療',
		4 => '子育て',
		5 => '環境・ゴミ',
		6 => '経済',
		7 => '観光・文化・スポーツ',
		8 => '都市整備・社会基盤・インフラ',
		9 => '教育・生涯学習',
		10 => 'その他'
	);
	//license
	public static $LICENSE = array(
		'指定なし' => '指定なし',
		1 => 'CC BY',
		2 => 'CC BY-NC',
		3 => 'CC BY-SA',
		4 => 'CC BY-NC-SA',
		5 => 'CC BY-ND',
		6 => 'CC BY-NC-ND', 
		7 => '著作物ではありません'
	);
	//データタイプ
	public static $DATA_TYPE = array(
		'指定なし' => '指定なし',
		1 => '統計データ',
		2 => '地理データ',
		3 => '測定データ',
		4 => 'その他',
	);
	// 1ページあたりの表示件数
	public static $MAXROW = array(
		10 => '１０件表示', 
		30 => '３０件表示', 
		50 => '５０件表示', 
		100 => '１００件表示', 
		100000 => '全て表示'
	);
	//ヒットなしメッセージ
	public static $ITEM_NONE_MSG = '該当するデータがありません。';
}

