<?php
/**
 * ZendFWの利用：URLから直接ZendFWアプリを実行するときに利用する。
 * 2015/1/20 a.ide create
 */
require_once 'Zend/Controller/Action.php';
require_once 'Zend/Exception.php';

//ビュークラス
require_once ABSTRACTZEND_PATH .'/controllers/lib/View.php';

/**
 * ZendFWのコントローラー
 */
class IndexController extends Zend_Controller_Action {

	public $viewPath = null;
	public $appConfig = null;

	public $isGet = false;
	public $isPost = false;

	//
	public function indexAction() {
		try{
			$this->viewPath = ABSTRACTZEND_PATH."/views";

			//config
			$registry = Zend_Registry::getInstance();
			$this->appConfig = $registry->configuration;

			//リクエストパラメーターの取得
			$request = $this->getRequest()->getParams();

			//submit
			if (count($_POST) > 0) {
				$this->isPost = true;
				$_GET = array();
				$action = "search";

			}else if (count($_GET) > 0) {
				$this->isGet = true;
				$action = "search";

			}else{
				$action = "index";
			}

			require_once(ABSTRACTZEND_PATH."/models/{$action}.php");
			$svc = new $action($this);
			$htmlrec = $svc->exec($request);

			echo $htmlrec;

		}catch(Exception $ex) {
			echo "ERR: ".$ex->getMessage();
			throw $ex;
		}
	}
			
	//ファイルのダウンロード
	public function downloadAction()
	{
		try{
			//リクエストパラメーターの取得
			$request = $this->getRequest()->getParams();
			extract($request);
			if (!isset($dl)) {
				throw new Exception("unknown download file.");
			}
			//ダウンロードファイル
			$file = trim($dl, "/");
			$wks = explode("/", $file);
			$dlFilePath = $file;
			$dlFileName = $wks[(count($wks) - 1)];
	
			//download
			$this->_helper->viewRenderer->setNoRender();
			// ヘッダの設定
			$this->getResponse()->setHeader('Content-type', 'application/octet-stream');
			$this->getResponse()->setHeader('Content-Disposition', 'attachment; filename='.$dlFileName);
			$this->getResponse()->setHeader('Content-length', filesize($dlFilePath));
			// ヘッダの送信
			$this->getResponse()->sendHeaders();
			// 出力バッファを無効にする。
			ob_end_clean();
			// 再度バッファリングを有効にする場合は記述する。
			//ob_start(null, 81920);
			/*
			 * readfile() 関数などで一度にファイルを読み込むとメモリ不足エラーと
			* なるので少しずつ出力する
			*/
			$fhandle = fopen($dlFilePath, 'rb');
			while (!feof($fhandle)) {
				// body にセットし、出力する
				$this->getResponse()->setBody(fread($fhandle, 8192));
				$this->getResponse()->outputBody();
				// 上記２行は、以下の処理と等価である
				//echo implode('', fread($fhandle, 8192));
			}
			fclose($fhandle);
	
		}catch(Exception $ex){
			echo "ERR: ".$ex->getMessage();
			throw $ex;
		}
	}		
}
?>

