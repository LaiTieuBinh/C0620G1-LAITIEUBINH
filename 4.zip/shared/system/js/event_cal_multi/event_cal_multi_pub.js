/**
 * イベントカレンダー用js
 */
(function($) {
	$(function(){
		var upcoming_path = '/cgi-bin/event_cal_multi/upcoming_event.cgi';
		var pickup_path = '/cgi-bin/event_cal_multi/pickup_event.cgi';
		var siteid = $('input[name="siteid"]:hidden').val();
		var param = {siteid: siteid};
		//直近のイベントの表示
		requestEventApi(upcoming_path,param,appendUpcomingEvent);
		//ピックアップイベントの表示
		requestEventApi(pickup_path,param,appendPickupEvent);
		
	});

	/**
	* 直近のイベントを表示する
	* @param {Object} data jsonデータ
	*/
	var appendUpcomingEvent = function(data) {
		//直近のイベントを追加する要素のID
		var target_id = 'tmp_event_recently_cnt';
		//開催日でソート
		data.sort(function (a, b) {
			return (a.start_date < b.start_date ? -1 : 1);
		});
		var elm = '';
		elm += '<ul>';
		if(data.length > 0) {
			$.each(data, function(idx, val){
				elm += '<li>';
				elm += '<p class="date"><span>開催日</span>';
				elm += getEvetDate(val.start_date ,val.end_date);
				elm += '</p>';
				elm += '<p><a href="' + val.path + '">';
				elm += val.page_title;
				elm += '</a></p>';
				elm += '</li>';
			})
		} else {
			elm += '近日開催予定のイベントはありません';
		} 
		elm += '</ul>';
		$('#' + target_id).prepend(elm);
	}
	
	/**
	* ピックアップイベントを表示する
	* @param {Object} data jsonデータ
	*/
	var appendPickupEvent = function(data) {
		//ピックアップイベントを追加する要素のID
		var target_id = 'tmp_pickup_event_slide';
		// 画像が登録されていないイベント用のNoImage画像パス
		var no_image_filepath = '/shared/templates/free/images/contents/event/pick_up_no_image.png';
		var pickup_event_img = '';
		//開催日でソート
		data.sort(function (a, b) {
			return (a.start_date < b.start_date ? -1 : 1);
		});
		var elm = '';
		if(data.length > 0) {
			$.each(data, function(idx, val){
				elm += '<div class="wrap_box_guide">';
				elm += '<div class="box_guide_outer">';
				elm += '<div class="box_guide">';
				if(typeof val.image != 'undefined' && val.image != '') {
					pickup_event_img = val.image;
				}else {
					pickup_event_img = no_image_filepath;
				}
				elm += '<p class="img"><img src="' + pickup_event_img + '" alt=""></p>';

				elm += '<div class="box_guide_date">';
				elm += '<p>';
				elm +=  getEvetDate(val.start_date ,val.end_date);
				elm +=  '</p>';
				elm += '</div>';
				elm += '<div class="box_guide_cnt">';
				elm += '<p><a href="' + val.path +'">' 
				elm +=  val.page_title + '</a></p>';
				elm += '</div>';
				elm += '</div></div></div>';
			})
		} else {
			elm += '';
		} 
		$('#' + target_id).append(elm);
		
		// スライダー
		if(typeof $.GFUNC.eventPickupSlider == 'function'){
			$.GFUNC.eventPickupSlider();
		}
		
	}
	
	/**
	* APIへのリクエストを行う
	* @param {string} path リクエストを行うパス
	* @param {Object} parama リクエストの際に使用するパラメータ
	* @param {Function} func リクエスト完了後に実行する関数
	*/
	var requestEventApi = function(path,param,func){
		var rep_data = [];
		$.ajax({
			url: path,
			type: 'POST',
			dataType: 'json',
			data: param,
        	}).done(function(data,textStatus,jqXHR) {
			rep_data = data;
		}).fail(function(data) {
			//console.log(data);
		}).always(function(date){ 
			func(rep_data); 
		});
	}

	/**
	* イベントの開催日を整形する
	* @param {string} start_date イベント開始日(YYYY/MM/DD)
	* @param {string} end_date イベント終了日(YYYY/MM/DD)
	* @param {boolean} start_only_flg 開始日と終了日が同じ時開始日のみ返すかのフラグ
	* @param {string} disp_format 開催日の表示形式
	* @param {string} date_format 日付の表示形式
	* @return {string} ret 整形済みイベント開催日
	*/
	var getEvetDate = function(start_date,end_date,start_only_flg,disp_format,date_format){
		if(typeof  start_only_flg == 'undefined') { start_only_flg = true; }
		if(typeof  disp_format == 'undefined') { disp_format = 'START_DATE～END_DATE'; }
		//if(typeof  date_format == 'undefined') { date_format = 'YYYY年MM月DD日(WW曜日)'; }
		// 時間が設定されている場合は時間も表示する
		if(typeof  date_format == 'undefined') { 
			if(start_date.match(/:/)) {
				date_format = 'YYYY年MM月DD日 (WW曜日) HH時mm分';
			}else{
				date_format = 'YYYY年MM月DD日 (WW曜日)';
			}
		}
		var _start_date = getFormatDate(new Date(start_date),date_format);
		var _end_date  =  getFormatDate(new Date(end_date),date_format);
		var ret = '';
		//開催日の整形を行う
		disp_format = disp_format.replace(/START_DATE/g, _start_date);
		disp_format = disp_format.replace(/END_DATE/g, _end_date);
		
		if (start_only_flg && (start_date == end_date)) {
			ret = _start_date;
		} else {
			ret = disp_format;
		}
		return ret;
	}

	
	/**
	* 日付を整形する
	* @param {date} date 日付
	* @param {string} format 日付の表示形式
	* @return {string} ret 整形済み日付
	*/
	var getFormatDate = function(date ,format) {
		if (typeof format == 'undefined') { 
			format = 'YYYY年MM月DD日(WW) HH時mm分'; 
		}
		var weekday = ['日', '月', '火', '水', '木', '金', '土'];
		var ret = format;
		//日付の整形を行う
		ret = ret.replace(/EEEE/g, date.toLocaleDateString('ja-JP-u-ca-japanese', {year:'numeric',era:'long'}));
		ret = ret.replace(/YYYY/g, date.getFullYear());
       	ret = ret.replace(/MM/g, (date.getMonth() + 1));
       	ret = ret.replace(/DD/g, date.getDate());
       	ret = ret.replace(/WW/g, weekday[date.getDay()]);
		ret = ret.replace(/HH/g, date.getHours());
		ret = ret.replace(/mm/g, ('0' + date.getMinutes()).slice(-2));
		return ret;
	}
})(jQuery);