/**
 * 自動リンク表示改修用js
 */
var MAX_ITEM = '5',
SHOW_MORE_TEXT = 'もっと見る',
SHOW_LESS_TEXT = '閉じる',
BUTTON_SHOW_MORE_CLASS = 'show_more_button',
BUTTON_SHOW_LESS_CLASS = 'hide_more_button',
TARGET_CLASS = 'show_more_',
TARGET_BUTTON_CLASS = 'show_more_btn_',
array_btn = document.querySelectorAll('[class^=' + TARGET_BUTTON_CLASS + ']');
for (var i = 0; i < array_btn.length; i++) {
	array_btn[i].addEventListener('click', toggleShowMore);
	autolink_value = array_btn[i].className;
	regex = new RegExp('.*' + TARGET_BUTTON_CLASS + '(\\d+)_?(\\d+)?', 'g')
	autolink_value = autolink_value.match(regex)[0];
	array_btn[i].innerHTML = SHOW_MORE_TEXT;
	autolink_value = autolink_value.replace(TARGET_BUTTON_CLASS, '');
	autolink_value = autolink_value.split('_');
	max_item = MAX_ITEM;
	if (typeof autolink_value[1] !== 'undefined') {
		max_item = autolink_value[1];
	}
	autolink_id = autolink_value[0];
	var element_list = document.querySelectorAll("." + TARGET_CLASS + autolink_id);
	if (element_list.length > max_item) {
		array_btn[i].classList.add(BUTTON_SHOW_MORE_CLASS);
		for (var j = 0; j < element_list.length; j++) {
			if (j + 1 > max_item) {
				element_list[j].style.display = 'none';
			}
		}
	}
	else {
		array_btn[i].style.display = 'none';
	}
}
function toggleShowMore(e) {
	var current_btn = e.target, btn_class = current_btn.className, regex = new RegExp('.*' + TARGET_BUTTON_CLASS + '(\\d+)_?(\\d+)?', 'g');
	var autolink_value = btn_class.match(regex);
	autolink_value = autolink_value[0].replace(TARGET_BUTTON_CLASS, '');
	autolink_value = autolink_value.split('_');
	max_item = MAX_ITEM;
	if (typeof autolink_value[1] !== 'undefined') {
		max_item = autolink_value[1];
	}
	autolink_id = autolink_value[0];
	var child_class = TARGET_CLASS + autolink_id, display = "";
	if (!current_btn.classList.contains(BUTTON_SHOW_MORE_CLASS)) {
		display = 'none';
		current_btn.innerText = SHOW_MORE_TEXT;
		current_btn.classList.remove(BUTTON_SHOW_LESS_CLASS);
		current_btn.classList.add(BUTTON_SHOW_MORE_CLASS);
	} else {
		current_btn.innerText = SHOW_LESS_TEXT;
		current_btn.classList.remove(BUTTON_SHOW_MORE_CLASS);
		current_btn.classList.add(BUTTON_SHOW_LESS_CLASS);
	}
	var tmp_child_list = document.getElementsByClassName(child_class);
	for (var j = 0; j < tmp_child_list.length; j++) {
		if (j + 1 > max_item && tmp_child_list[j] !== current_btn) {
			tmp_child_list[j].style.display = display;
		}
	}
}