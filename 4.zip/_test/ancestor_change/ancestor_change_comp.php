<?php
/*
 *
 */
/** 外部ページの取り込み **/
require ("../../admin/.htsetting");

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage2 = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
unset($_SESSION['csv_data']);

//csvファイル最大行
define("G_CSV_MAX_LINE", 20000);

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $objLogin->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}
if (!isset($_POST['cms_filename']) || $_POST['cms_filename'] == "") {
	user_error('不正アクセスです。');
}

if (isset($_SESSION['post'])) unset($_SESSION['post']);
$_SESSION['post'] = $_POST;
gd_errorhandler_ini_set("html0", './ancestor_change_index.php');

//---引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError("インポートをするcsvファイルを指定してください。", 2, "javascript:history.back()");
	exit();
}
//---ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError("csvファイルのファイルサイズが0バイトです。", 2, "javascript:history.back()");
	exit();
}
//---アップロード
$frmCsvFnm = DOCUMENT_ROOT . DIR_PATH_UPLOAD . "/temp/" . $frmCsvFnm;
if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $frmCsvFnm) == FALSE) {
	DispError("csvファイルのアップロードに失敗しました。", 2, "javascript:history.back()");
	exit();
}
//(念のため)ファイル存在チェック
if (file_exists($frmCsvFnm) == FALSE) {
	$wk_str = "指定されたファイル【" . $frmCsvFnm . "】が存在しません。";
	DispError($wk_str, 2, "javascript:history.back()");
	exit();
}

// 空ページの確認
$aryFiles = array();
//CSVファイルよりページ情報配列作成
_chk_files($frmCsvFnm, $aryFiles);
//公開・編集ページ情報更新
_up_files($aryFiles);

//最新のパンくず取得
foreach ((array) $aryFiles as $key => $value) {
	$aryFiles[$value['file_path']]['parent'] = $objTool->getpankuzu(FLAG_OFF, '', '', $value['ancestor_path'], '', '', FALSE);
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>外部ファイル取り込み</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="./ancestor_change.css" type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'ancestor_change';
include (APPLICATION_ROOT . "/common/inc/revision_menu.inc");
?>
<div align="center" id="cms8341-outerimport">
<div><img src="<?=RPW?>/admin/images/outerimport/bar_outerimport.jpg"
	alt="外部取り込み" width="920" height="30"></div>
<div class="cms8341-area-corner">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="150" align="left" valign="top" scope="row">取り込みファイル</th>
		<td><?=htmlDisplay($_POST['cms_filename'])?></td>
	</tr>
</table>
</div>
<form name="cms_fImport" class="cms8341-form" method="post" action="">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">結果</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">修正ページ</th>
	</tr>
<?php
foreach ($aryFiles as $ary) {
	if (!$ary['error']) {
		$result = "成功";
	}
	else {
		$result = "失敗";
	}
	print '<tr>' . "\n";
	print '<td align="center" valign="middle">' . $result . '</td>' . "\n";
	print '<td align="left" valign="top"><p>' . $ary['parent'] . '<br>' . htmlDisplay($ary['file_path']) . "\n";
	if ($ary['page_title'] != '') print '<br><strong>' . htmlDisplay($ary['page_title']) . '</strong>' . "\n";
	if ($ary['message'] != '') print '<br><span class="cms8341-error">' . $ary['message'] . '</span>' . "\n";
	print '</p></td>' . "\n";
	print '</tr>' . "\n";
}
?>
</table>
<p align="center"><a href="./ancestor_change_index.php"><img
	src="<?=RPW?>/admin/images/btn/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0" style="margin-left: 10px;"></a></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</body>
</html>
<?php
function _chk_files($frmCsvFnm, &$in_aryFiles) {
	global $objDac;
	global $objPage;
	// ** global 宣言 ---------------------------
	global $objCnc;
	
	$CsvDataAry = array();
	//ファイルを開く
	if (!($CsvFno = fopen($frmCsvFnm, 'r'))) {
		//エラーページの表示
		DispError("csvファイルのオープンに失敗しました。", 2, "javascript:history.back()");
		exit();
	}
	$buf = file_get_contents($frmCsvFnm);
	$CsvFno = tmpfile();
	fwrite($CsvFno, $buf);
	rewind($CsvFno);
	//EOFになるまで読み出し
	$fst_line = 0;
	$err_msg = "";
	while ($data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
		if ($data[0] != "") $entry = $data[0];
		else continue;
		if ($data[1] != "") $page_title = $data[1];
		else continue;
		if ($data[2] != "") $parent = $data[2];
		else continue;
		if (isset($data[3])) $h1 = $data[3];
		else $h1 = "";
		
		//拡張子チェック用
		$entryExt = substr($entry, (strrpos($entry, '.') + 1));
		$entryExt = strtolower($entryExt);
		$parentExt = substr($parent, (strrpos($parent, '.') + 1));
		$parentExt = strtolower($parentExt);
		
		// ファイル情報を格納
		$aryF = array(
				'file_path' => $entry, 
				'page_title' => $page_title, 
				'parent' => '', 
				'parent_path' => $parent, 
				'parent_id' => '', 
				'ancestor_path' => '', 
				'context' => '', 
				'error' => false, 
				'message' => '', 
				'status' => '', 
				'page_id' => ''
		);
		
		// 拡張子チェック
		if ($entryExt != "html") {
			$in_aryFiles[] = _set_error($aryF, '変更ページがHTMLではありません。');
			continue;
		}
		// 親ページ拡張子チェック
		if ($parentExt != "html") {
			$in_aryFiles[] = _set_error($aryF, '親ページがHTMLではありません。');
			continue;
		}
		// 既存チェック
		if (!file_exists(DOCUMENT_ROOT . RPW . $entry)) {
			$in_aryFiles[] = _set_error($aryF, '変更しようとしているページ【' . $entry . '】は存在しないパスです。');
			continue;
		}
		// 親ページ
		$objPage->selectFromPath($parent);
		if ($objPage->getRowCount() == 0) {
			$ancestor_path = "";
			foreach ($in_aryFiles as $en => $ary) {
				if ($parent == $ary['file_path']) {
					$ancestor_path = $ary['ancestor_path'];
					$file_path = $ary['file_path'];
					$page_title = $ary['page_title'];
				}
			}
			if (!isset($ancestor_path) || $ancestor_path == "") {
				$in_aryFiles[] = _set_error($aryF, '親ページ【' . $parent . '】が存在しません。');
				continue;
			}
		}
		else {
			$ancestor_path = $objPage->fld['ancestor_path'];
			$page_title = $objPage->fld['page_title'];
			$file_path = $objPage->fld['file_path'];
			$aryF['parent_id'] = $objPage->fld['page_id'];
		}
		$aryF['parent'] = getPankuzu($ancestor_path, $page_title, $in_aryFiles);
		//ancestor_path取得
		//		$aryF['ancestor_path'] = $ancestor_path.",".$file_path;
		if ($ancestor_path == "") {
			$aryF['ancestor_path'] = $file_path;
		}
		else {
			$aryF['ancestor_path'] = $ancestor_path . "," . $file_path;
		}
		
		// ページ情報の取得
		if ($objPage->selectFromPath($entry) !== FALSE) {
			$aryF['page_id'] = $objPage->fld['page_id'];
			$aryF['status'] = $objPage->fld['status'];
			//親ページパス内に自分が含まれていたらエラー
			if (preg_match('/(^|,)' . _reg_replace($objPage->fld['file_path']) . '(,|$)/', $aryF['ancestor_path'])) {
				$in_aryFiles[] = _set_error($aryF, '変更しようとしている親ページのパンくずに自分を含んでいます。');
				continue;
			}
			if ($objPage->fld['status'] != STATUS_PUBLISH) {
				$objPage->selectFromPath($entry, WORK_TABLE);
				if ($h1 != "") {
					$aryF['work_context'] = "<h1>" . $h1 . "</h1>" . $objPage->fld['context'];
				}
			}
			if ($h1 != "") {
				$aryF['pub_context'] = "<h1>" . $h1 . "</h1>" . $objPage->fld['context'];
			}
		}
		else {
			$in_aryFiles[] = _set_error($aryF, '変更を行うページ情報の取得に失敗しました。');
			continue;
		}
		$in_aryFiles[$entry] = $aryF;
	}
}

function _set_error($aryF, $msg) {
	$aryF['error'] = true;
	$aryF['message'] = $msg;
	return $aryF;
}
// get pankuzu
function getPankuzu($pAncestor = '', $pLastTitle = '', $in_aryFiles) {
	global $objPage;
	$pankuzu = '';
	$title = '';
	if ($pAncestor != '') {
		foreach (explode(',', $pAncestor) as $ancestor_path) {
			$objPage->selectFromPath($ancestor_path);
			if ($objPage->getRowCount() == 0) {
				foreach ($in_aryFiles as $en => $ary) {
					if (isset($in_aryFiles[$ancestor_path])) {
						$title = $in_aryFiles[$ancestor_path]['page_title'];
					}
				}
			}
			else {
				$title = $objPage->fld['page_title'];
			}
			if ($title == '') continue;
			if ($pankuzu != '') $pankuzu .= PANKUZU_DELIMITER;
			$pankuzu .= htmlDisplay($title);
		}
	}
	if ($pLastTitle != '') {
		if ($pankuzu != '') $pankuzu .= PANKUZU_DELIMITER;
		$pankuzu .= htmlDisplay($pLastTitle);
	}
	return $pankuzu;
}

//upload
function _up_files(&$up_aryFiles) {
	global $objPage;
	global $objPage2;
	// ** global 宣言 ---------------------------
	global $objCnc;
	$ary_pub = "";
	$ary_work = "";
	
	$objCnc->begin();
	
	foreach ((array) $up_aryFiles as $key) {
		$ary_pub = array();
		$ary_work = array();
		if ($key['error']) continue;
		$objPage->selectFromID($key['page_id'], PUBLISH_TABLE);
		$objPage2->selectFromPath($key['parent_path']);
		//親ページパス内に自分が含まれていたらエラー
		if (preg_match('/(^|,)' . _reg_replace($key['file_path']) . '(,|$)/', $objPage2->fld['ancestor_path'])) {
			$up_aryFiles[$key['file_path']] = _set_error($up_aryFiles[$key['file_path']], '変更しようとしている親ページのパンくずに自分を含んでいます。');
			continue;
		}
		
		// パンくず再取得
		$key['ancestor_path'] = $objPage2->fld['ancestor_path'];
		// 親ページのパンくずが空の場合「,」で連結しない
		if (strlen($key['ancestor_path']) > 0) {
			$key['ancestor_path'] .= ',';
		}
		$key['ancestor_path'] .= $objPage2->fld['file_path'];
		
		$up_aryFiles[$key['file_path']]['ancestor_path'] = $key['ancestor_path'];
		
		//tbl_work_page更新用配列作成
		if ($key['status'] != STATUS_PUBLISH) {
			$ary_work['page_id'] = $key['page_id'];
			$ary_work['parent_id'] = $key['parent_id'];
			$ary_work['page_title'] = $key['page_title'];
			if (isset($key['work_context'])) $ary_work['context'] = $key['work_context'];
			if (!$objPage->update($ary_work, WORK_TABLE)) {
				DispError("編集ページ情報の更新に失敗しました。", 2, "javascript:history.back()");
				exit();
			}
		}
		//tbl_publish_page更新用配列作成
		$ary_pub['page_id'] = $key['page_id'];
		$ary_pub['parent_id'] = $key['parent_id'];
		$ary_pub['ancestor_path'] = $key['ancestor_path'];
		$ary_pub['page_title'] = $key['page_title'];
		if (isset($key['pub_context'])) $ary_pub['context'] = $key['pub_context'];
		//tbl_publish_page更新処理※「parent_id」「ancestor_path」	
		if (!$objPage->update($ary_pub, PUBLISH_TABLE)) {
			DispError("公開ページ情報の更新に失敗しました。", 2, "javascript:history.back()");
			exit();
		}
	}
	
	// コミット
	$objCnc->commit();
}
// 正規表現パターン用の文字列にする
function _reg_replace($pStr) {
	$ary1 = array(
			'/', 
			'.', 
			'*', 
			'+', 
			'-', 
			'?', 
			'(', 
			')', 
			'[', 
			']', 
			'\\'
	);
	$ary2 = array(
			'\/', 
			'\.', 
			'\*', 
			'\+', 
			'\-', 
			'\?', 
			'\(', 
			'\)', 
			'\[', 
			'\]', 
			'\\'
	);
	return str_replace($ary1, $ary2, $pStr);
}

?>