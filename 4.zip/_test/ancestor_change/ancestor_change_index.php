<?php
/*
 *
 */
require ("../../admin/.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$objDept = new tbl_department($objCnc);

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $objLogin->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}

// 初期表示値
$def = array();
$def['cms_filename'] = '';

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ページ情報変更</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="./ancestor_change.css" type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--

//外部ページの取り込み
function cxSubmit() {
	var msg = new Array();
	if (!$('FrmCsvnm').value) {
		msg.push('取り込みファイルを入力してください。');
	} else {
		var filetype = $('FrmCsvnm').value.replace(/^.*\.([^\.]+$)/, '$1');
		filetype = filetype.toLowerCase();
		if (filetype != 'csv') msg.push('取り込みファイルはcsv形式でアップロードしてください。');
		//
		// 「[a-z]:\～」または「\\～」で始まるパスの指定のみを許容する
		var filepath = $('FrmCsvnm').value.match(/^([a-z]:\\|\\\\).+/i);		
		if(!filepath) {
			msg.push('取り込みファイルの参照先を正しく指定してください。');
		}
	}
	// エラー表示
	if (msg.length > 0) {
		$('cms8341-errormsg').innerHTML = msg.join("<br>");
		cxLayer('cms8341-error',1,500,500);
		return false;
	}
	if (!confirm("ページ情報の変更を行います。\nよろしいですか？")) {
		return false;
	}
	$('cms_filename').value = $('FrmCsvnm').value;
	document.cms_fImport.submit();
	return false;
}

function cxErrorClose() {
	cxComboVisible();
	cxLayer('cms8341-error',0);
}
//-->
</script>

</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'ancestor_change';
include (APPLICATION_ROOT . "/common/inc/revision_menu.inc");
?>
<div align="center" id="cms8341-outerimport">
<form name="cms_fImport" class="cms8341-form" method="post"
	action="ancestor_change_comp.php" enctype="multipart/form-data"><input
	type="hidden" id="cms_filename" name="cms_filename" value="">
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="150" align="left" valign="top" scope="row">取り込みファイル<br>
		<span class="cms_require">（必須）</span></th>
		<td><input type="file" id="FrmCsvnm" name="FrmCsvnm"
			style="width: 500px;"><br>
		※csv形式の圧縮ファイルを指定してください</td>
	</tr>
</table>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center" id="cms_submit"><a href="javascript:"
	onClick="return cxSubmit()"><img
	src="<?=RPW?>/admin/images/btn/btn_start.jpg" alt="取り込み開始" width="150"
	height="20" border="0" style="margin-right: 10px;"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</form>
</div>
<!--***エラーメッセージレイヤー　　ここから***********-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxErrorClose();"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー　　ここまで***********-->
</body>
</html>
