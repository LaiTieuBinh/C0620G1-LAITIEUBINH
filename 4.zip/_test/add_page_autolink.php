<?php
/*
 * すべてのページに自分のカテゴリの自動リンクをつける
 */
require ("../admin/.htsetting");

$objCnc->begin();

// page
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objPage = new tbl_page($objCnc);
$objHandler = new tbl_handler($objCnc);
$objCate = new tbl_category($objCnc);
$objPage->select("", "*", "page_id");
while ($objPage->fetch()) {
	$fld = $objPage->fld;
	if ($fld['cate_code'] == "") continue;
	$cate_code = $fld['cate_code'];
	
	$aFld = getAutolinkDbDataFromCateCode($cate_code, AUTOLINK_CONDITION_PAGE);
	foreach ($aFld as $values) {
		$insAry = array();
		$insAry['class'] = HANDLER_CLASS_INDEX_CHK1;
		$insAry['item1'] = $fld['page_id'];
		$insAry['item2'] = $values['a_link_id'];
		$objHandler->insert($insAry);
	}
}

//	$objCnc->rollback();
$objCnc->commit();

?>