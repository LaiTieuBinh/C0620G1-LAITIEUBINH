<?php
/*
 *
 */
/*--- 設定ファイル読み込み ---*/
require ("../admin/.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/commands.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);

$objCnc->begin();
$where = $objHandler->_addslashesC("class", HANDLER_CLASS_DEF_DIR1);
$objHandler->select($where);
while ($objHandler->fetch()) {
	$fld = $objHandler->fld;
	$authDir = $fld['item2'];
	if ($authDir == "") continue;
	$deptCode = $fld['item1'];
	
	$dirList = array();
	$dirList = cxGetDirList(DOCUMENT_ROOT . RPW . $authDir, $dirList);
	foreach ($dirList as $dir) {
		$insAry = array();
		$objHandlerTran = new tbl_handler($objCnc);
		$dir = str_replace(DOCUMENT_ROOT . RPW, "", $dir);
		if ($objHandlerTran->IsEditableDir($deptCode, $dir)) continue;
		$insAry['class'] = HANDLER_CLASS_DIRECTORY;
		$insAry['item1'] = $deptCode;
		$insAry['item2'] = $dir;
		$objHandlerTran->insert($insAry);
	}
}
$objCnc->commit();
//    $objCnc->rollback();    


?>
