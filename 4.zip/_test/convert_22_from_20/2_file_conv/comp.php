<?php
/*
 * 画像・ファイルのコンバートプログラム(実行)
 */
// 設定ファイル読み込み
require ("../../../admin/.htsetting");
// コンバートプログラム用設定ファイル読み込み
require ("../setting.inc");

// ウェブマスター以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	user_error('不正アクセスです。【 user 】');
}

// 引数が不正
if (!isset($_POST['exec']) || $_POST['exec'] != FLAG_ON) {
	user_error('不正アクセスです。【 exec 】');
}

// コンバートプログラム情報配列
$_CONV_ARRAY = getDefineArray('_CONV_ARRAY');
$menu_info = $_CONV_ARRAY[_FILE_CONV];

// DB
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage2 = new tbl_page($objCnc);
$objPage_w = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$objLinks = new tbl_links($objCnc);
$objLinks2 = new tbl_links($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
$objImages2 = new tbl_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInquiry = new tbl_inquiry($objCnc);
// オープンデータ
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_open_data.inc');
$obj_open_data = new tbl_open_data($obj_cnc);

// 変数の宣言
$end_page_data = array(); // 終了したページの情報
$end_file_data = array(); // 終了したファイルの情報
$sql = ""; // SQL文（全文）
$where = ""; // SQL文（WHERE句）
$result_cnt = 0; // 処理対象件数


// ページ情報の抽出（全ページ）
$objPage->setTableName(PUBLISH_TABLE);
$objPage->select();

// 件数
$max_cnt = $objPage->getRowCount();
// 成功　用配列
$ok_ary = array();
// 失敗　用配列
$ng_ary = array();
// 対象外用配列
$no_ary = array();
// ページ数分
$page_ary = array();

$page_cnt = 0;

// 処理する件数を出力
if (_FLUSH_FLG) {
	_print_flush(date('H:i:s') . " | 全" . $max_cnt . "件 <br />" . "\n");
}

// 処理開始時間
$start_time = microtime(true);

// 取得したページ数分ループ
while ($objPage->fetch()) {
	// 変数の初期化
	$err_msg = "";
	
	$PID = $objPage->fld['page_id'];
	$page_title = $objPage->fld['page_title'];
	$inquiry_id = $objPage->fld['inquiry_id'];
	
	$page_ary[$PID]['title'] = $page_title . "【" . $PID . "】[" . $objPage->fld['file_path'] . "]";
	$page_ary[$PID]['exec'] = FLAG_OFF;
	
	// 現在処理中の件数
	$cnt = $objPage->fetchrow;
	
	// 指定件数処理したら件数を表示
	if (_FLUSH_FLG && $cnt % _FLUSH_CNT == 0) {
		// 
		$t = _time_left_check($start_time, $max_cnt, $cnt);
		_print_flush("" . date('H:i:s') . " | " . $cnt . "件目 | E " . date('H:i:s', $t['end']) . " ( " . $t['his'] . " ) <br />" . "\n");
	}
	
	// ページの状態をチェックし、作業を行う必要があるかチェック
	if (!check_page($objPage->fld, $err_msg)) {
		// 対象外ページ
		$no_ary[$PID][] = $err_msg;
		_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, -1);
		continue;
	}
	
	// トランザクション 開始
	$objCnc->begin();
	
	$p_status = $objPage->fld['status'];
	$p_close_flg = $objPage->fld['close_flg'];
	
	// 公開中のページ
	if ($p_status == STATUS_PUBLISH && $p_close_flg != FLAG_ON) {
		// 公開待ちにする
		$ary = array(
				'page_id' => $PID, 
				'bak_status' => $objPage->fld['status'], 
				'status' => STATUS_PUBLISH_WAIT
		);
		// 公開ページ情報
		if (!$objPage2->update($ary, PUBLISH_TABLE)) {
			// ロールバック
			$objCnc->rollback();
			// エラー
			$err_msg = '公開ページ情報の更新に失敗しました。';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// 編集ページ情報
		if (!$objPage2->insertWorkFromPublish($PID, $objLogin->login)) {
			// ロールバック
			$objCnc->rollback();
			// エラー
			$err_msg = '編集ページ情報の作成に失敗しました。';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// リンク情報
		if (!$objLinks->insertWorkFromPublish($PID)) {
			// ロールバック
			$objCnc->rollback();
			// エラー
			$err_msg = '編集リンク情報の作成に失敗しました。';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// 画像情報
		if (!$objImages->insertWorkFromPublish($PID)) {
			// ロールバック
			$objCnc->rollback();
			// エラー
			$err_msg = '編集画像情報の作成に失敗しました。';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// 自動リンク情報
		if (!$objHandler->insertAutoLinkWfromP($PID)) {
			// ロールバック
			$objCnc->rollback();
			// エラー
			$err_msg = '編集自動リンク情報の作成に失敗しました。';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// ライブラリ情報
		if (!$objHandler->insertLibraryWfromP($PID)) {
			// ロールバック
			$objCnc->rollback();
			// エラー
			$err_msg = '編集ライブラリ情報の作成に失敗しました。';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		//問合せ先情報
		if ($inquiry_id != "") {
			// 編集問い合わせ先情報の取得
			$sql = "SELECT * FROM tbl_work_inquiry";
			$sql .= " WHERE " . $objInquiry->_addslashesC('inquiry_id', $inquiry_id, '=', 'INT');
			if (!$objInquiry->execute($sql)) {
				// ロールバック
				$objCnc->rollback();
				// エラー
				$err_msg = '編集問い合わせ情報の取得に失敗しました。( ' . $inquiry_id . ' )';
				$ng_ary[$PID][] = $err_msg;
				_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
				continue;
			}
			// 問い合わせ情報が一件以上ある場合
			if ($objInquiry->getRowCount() > 0) {
				// 編集ページの情報を取得
				$sql = "SELECT * FROM tbl_work_page";
				$sql .= " WHERE " . $objPage2->_addslashesC('inquiry_id', $inquiry_id, '=', 'INT');
				$sql .= " AND " . $objPage2->_addslashesC('page_id', $PID, '!=', 'INT');
				if (!$objPage2->execute($sql)) {
					// ロールバック
					$objCnc->rollback();
					// エラー
					$err_msg = '編集ページ情報の取得に失敗しました。';
					$ng_ary[$PID][] = $err_msg;
					_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
					continue;
				}
				// 一件以上ある場合
				if ($objPage2->getRowCount() > 0) {
					// ロールバック
					$objCnc->rollback();
					// エラー
					$err_msg = '編集問い合わせ情報に異常なデータが入っています。【' . $inquiry_id . '】';
					$ng_ary[$PID][] = $err_msg;
					_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
					continue;
				}
				// 削除する
				if (!$objInquiry->deleteFromID($inquiry_id, WORK_TABLE)) {
					// ロールバック
					$objCnc->rollback();
					// エラー
					$err_msg = '編集問い合わせ情報の削除に失敗しました。【' . $inquiry_id . '】';
					$ng_ary[$PID][] = $err_msg;
					_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
					continue;
				}
			}
			// 問合せ先情報をコピー
			if (!$objInquiry->insertWorkFromPublish($inquiry_id)) {
				// ロールバック
				$objCnc->rollback();
				// エラー
				$err_msg = '編集問い合わせ情報の作成に失敗しました。【' . $inquiry_id . '】';
				$ng_ary[$PID][] = $err_msg;
				_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
				continue;
			}
		}
		// オープンデータ
		if ($obj_open_data->insertWorkFromPublish($PID) === FALSE) {
			// ロールバック
			$objCnc->rollback();
			// エラー
			$err_msg = 'オープンデータ編集情報の作成に失敗しました。';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		$page_ary[$PID]['exec'] = FLAG_ON;
	}
	$p_tbl = WORK_TABLE;
	$p_str = "編集";
	
	// 非公開中の場合は公開ページ情報
	if ($p_status == STATUS_PUBLISH && $p_close_flg == FLAG_ON) {
		$p_tbl = PUBLISH_TABLE;
		$p_str = "公開";
	}
	// 編集ページ情報を取得
	if (!$objPage_w->selectFromID($PID, $p_tbl)) {
		// ロールバック
		$objCnc->rollback();
		// エラー
		$err_msg = $p_str . 'ページ情報の取得に失敗しました。';
		$ng_ary[$PID][] = $err_msg;
		_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
		continue;
	}
	
	// 取得結果代入
	$fld_w = $objPage_w->fld;
	
	// 画像の移動処理
	if (!move_images($fld_w, $p_tbl, $p_str)) {
		// ロールバック
		$objCnc->rollback();
		continue;
	}
	// ファイルの移動処理
	if (!move_links($fld_w, $p_tbl, $p_str)) {
		// ロールバック
		$objCnc->rollback();
		continue;
	}
	
	// ページ情報の更新処理
	$ary = array(
			'page_id' => $PID, 
			'context' => $fld_w['context']
	);
	//公開テーブルの更新
	if (!$objPage2->update($ary, $p_tbl)) {
		// ロールバック
		$objCnc->rollback();
		// エラー
		$err_msg = '編集ページ情報の更新に失敗しました。';
		$ng_ary[$PID][] = $err_msg;
		_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
		continue;
	}
	
	//コミット
	$objCnc->commit();
	
	$page_cnt++;
}

// 処理終了を出力
if (_FLUSH_FLG) {
	_print_flush(date('H:i:s') . " | 全" . $max_cnt . "件 全ての処理が終了しました。 <br />" . "\n");
}

// 結果文章を作成
traceWrite($max_cnt . "件 全ての処理が終了しました。");

$result = $max_cnt . "件中 ";
$result .= "【 N  G 】" . count($ng_ary) . "件 ";

// 結果を trace.log に出力
traceWrite("( RESULT ) " . $result);

//----------------------------------------//
//			関数				//
//----------------------------------------//


/**
 * ページの状態をチェック
 *
 * @param $page_fld 対象ページ情報
 * @param $err_msg エラーメッセージ
 * @return 処理対象のページの場合は、TRUE。そうでない場合は、FALSEを返す。
 */
function check_page($page_fld, &$err_msg) {
	// グローバル宣言
	global $objLinks;
	global $objImages;
	
	$_NOT_COPY_DIR = getDefineArray('_NOT_COPY_DIR');
	$ALLOWED_EXTENSIONS_IMAGE_ARY = explode(",", ALLOWED_EXTENSIONS_IMAGE);
	$DENIED_EXTENSIONS_FILE_ARY = explode(",", DENIED_EXTENSIONS_FILE);
	
	// 変数の宣言
	$sql = "";
	
	// ページの存在チェック
	if (!isset($page_fld['page_id'])) {
		$err_msg = "ページ情報の取得に失敗しました。";
		return FALSE;
	}
	
	// ページID
	$PID = $page_fld['page_id'];
	
	// 画像・リンクテーブルで使用されていないかチェック
	

	// 編集情報
	$objImages->selectFromPageID($PID, WORK_TABLE);
	$objLinks->selectRelated($PID, WORK_TABLE);
	if ($objImages->getRowCount() <= 0 && $objLinks->getRowCount() <= 0) {
		// 使用されていない場合
		// 公開情報
		$objImages->selectFromPageID($PID, PUBLISH_TABLE);
		$objLinks->selectRelated($PID, PUBLISH_TABLE);
		if ($objImages->getRowCount() <= 0 && $objLinks->getRowCount() <= 0) {
			// 使用されていない場合
			$err_msg = "画像・ファイルを使用していないページです。コンバートの必要はありません。";
			return FALSE;
		}
	}
	
	// 画像・ファイルパスがver2.2仕様のパスかチェック
	$cnt = 0;
	
	// ページの保存先パス
	$dir_path = preg_replace("/\/+$/", "", preg_replace("/\\\\/", "/", $page_fld['dir_path']));
	// 正規表現用 画像パス
	$preg_image_dir = "(" . reg_replace($dir_path . FCK_IMAGES_FORDER) . "|" . reg_replace(FCK_IMAGES_FORDER_SHARED) . ")";
	// 正規表現用 ファイルパス
	$preg_file_dir = "(" . reg_replace($dir_path . FCK_FILELINK_FORDER) . "|" . reg_replace(FCK_FILELINK_FORDER_SHARED) . ")";
	
	$dir_path_flg = FLAG_OFF;
	$lower_nm_flg = FLAG_OFF;
	
	// 画像
	while ($objImages->fetch()) {
		// 拡張子をチェック
		$exte = @getExtension($objImages->fld['src']);
		if (!@is_file(DOCUMENT_ROOT . RPW . $objImages->fld['src']) || !in_array($exte, $ALLOWED_EXTENSIONS_IMAGE_ARY)) {
			continue;
		}
		// 初期化
		$dir_path_flg = FLAG_OFF;
		$lower_nm_flg = FLAG_OFF;
		// 保存先ディレクトリのチェック
		if (preg_match('/^' . $preg_image_dir . '\/[^\/]*$/i', $objImages->fld['src'])) {
			$dir_path_flg = FLAG_ON;
		}
		// 移動対象外ディレクトリかチェック
		foreach ((array) $_NOT_COPY_DIR as $key => $dir) {
			if (preg_match('/^' . reg_replace($dir) . '/', $objImages->fld['src'])) {
				$dir_path_flg = FLAG_ON;
				break;
			}
		}
		// ファイル名の大文字チェック
		$file_name = basename($objImages->fld['src']);
		if ($file_name == strtolower($file_name)) {
			$lower_nm_flg = FLAG_ON;
		}
		// 保存先・ファイル名とも問題ない場合はスキップ
		if ($dir_path_flg == FLAG_ON && $lower_nm_flg == FLAG_ON) {
			continue;
		}
		$cnt++;
	}
	// ファイル
	while ($objLinks->fetch()) {
		// 拡張子をチェック
		$exte = @getExtension($objLinks->fld['path']);
		if (!@is_file(DOCUMENT_ROOT . RPW . $objLinks->fld['path']) || in_array($exte, $DENIED_EXTENSIONS_FILE_ARY)) {
			continue;
		}
		// 初期化
		$dir_path_flg = FLAG_OFF;
		$lower_nm_flg = FLAG_OFF;
		// 保存先ディレクトリのチェック
		if (preg_match('/^' . $preg_file_dir . '\/[^\/]*$/i', $objLinks->fld['path'])) {
			$dir_path_flg = FLAG_ON;
		}
		// 移動対象外ディレクトリかチェック
		foreach ((array) $_NOT_COPY_DIR as $key => $dir) {
			if (preg_match('/^' . reg_replace($dir) . '/', $objLinks->fld['path'])) {
				$dir_path_flg = FLAG_ON;
				break;
			}
		}
		// ファイル名の大文字チェック
		$file_name = basename($objLinks->fld['path']);
		if ($file_name == strtolower($file_name)) {
			$lower_nm_flg = FLAG_ON;
		}
		// 保存先・ファイル名とも問題ない場合はスキップ
		if ($dir_path_flg == FLAG_ON && $lower_nm_flg == FLAG_ON) {
			continue;
		}
		$cnt++;
	}
	
	// 全てのパスがver2.2仕様の場合
	if ($cnt == 0) {
		// 拡張子が不正
		$err_msg = "使用されている画像・ファイルのコンバートをする必要はありませんでした。";
		return FALSE;
	}
	
	//
	return TRUE;
}

/**
 * 依存ファイル（画像）を処理
 *
 * @param $page_fld 対象ページ情報
 * @return 成功した場合は、TRUE。そうでない場合は、FALSEを返す。
 */
function move_images(&$page_fld, $p_tbl, $p_str) {
	// グローバル宣言
	global $objDac;
	global $objImages;
	global $objImages2;
	
	global $ok_ary;
	global $ng_ary;
	global $no_ary;
	
	global $max_cnt;
	global $cnt;
	
	global $page_title;
	
	$_NOT_COPY_DIR = getDefineArray('_NOT_COPY_DIR');
	$ALLOWED_EXTENSIONS_IMAGE_ARY = explode(",", ALLOWED_EXTENSIONS_IMAGE);
	
	// 変数の宣言
	$sql = ""; // SQL文（全文）
	$where = ""; // SQL文（WHERE句）
	$err_flg = FLAG_OFF; // エラーフラグ
	

	// ページID
	$PID = $page_fld['page_id'];
	// ファイルパス
	$file_path = $page_fld['file_path'];
	// ユーザーID
	$user_id = $page_fld['user_id'];
	
	// ページの保存先パス
	$dir_path = preg_replace('/^(\/\/|\.\/)/i', '/', preg_replace("/\\\\/", "/", cms_dirname($file_path)));
	// 正規表現用 画像パス
	$preg_image_dir = "(" . reg_replace($dir_path . FCK_IMAGES_FORDER) . "|" . reg_replace(FCK_IMAGES_FORDER_SHARED) . ")";
	
	$dir_path_flg = FLAG_OFF;
	$lower_nm_flg = FLAG_OFF;
	
	// 画像情報の取得
	$objImages->selectFromPageID($PID, $p_tbl);
	
	while ($objImages->fetch()) {
		// 初期化
		$err_msg = "";
		
		// 取得結果代入
		$src = $objImages->fld['src'];
		
		// ファイル実在チェック
		if (!@file_exists(DOCUMENT_ROOT . RPW . $src)) {
			// 未処理
			$err_msg = '画像ファイルが存在しません。[' . $src . ']';
			$no_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, -1);
			continue;
		}
		// フラグ初期化
		$dir_path_flg = FLAG_OFF;
		$lower_nm_flg = FLAG_OFF;
		// パスが修正されているかチェック
		if (preg_match('/^' . $preg_image_dir . '\/[^\/]*$/i', $src)) {
			$dir_path_flg = FLAG_ON;
		}
		// 移動対象外ディレクトリかチェック
		foreach ((array) $_NOT_COPY_DIR as $key => $dir) {
			if (preg_match('/^' . reg_replace($dir) . '/', $src)) {
				$dir_path_flg = FLAG_ON;
				break;
			}
		}
		// ファイル名の大文字チェック
		$file_name = basename($src);
		if ($file_name == strtolower($file_name)) {
			$lower_nm_flg = FLAG_ON;
		}
		// パス・ファイル名ともに問題ない場合
		if ($dir_path_flg == FLAG_ON && $lower_nm_flg == FLAG_ON) {
			// 未処理
			$err_msg = 'コンバートする必要のない画像です。[' . $src . ']';
			$no_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, -1);
			continue;
		}
		// 拡張子をチェック
		$exte = @getExtension($src);
		if (!@is_file(DOCUMENT_ROOT . RPW . $src) || !in_array($exte, $ALLOWED_EXTENSIONS_IMAGE_ARY)) {
			// 未処理
			$err_msg = 'コンバート対象外のファイルです。[' . $src . ']';
			$no_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, -1);
			continue;
		}
		
		// ファイル名の取得
		$file_name = strtolower(basename($src));
		// ファイル移動先ディレクトリの取得
		$file_dir = cms_dirname($file_path) . FCK_IMAGES_FORDER;
		$file_dir = preg_replace('/^(\/\/|\.\/)/i', '/', $file_dir);
		// 移動先の同名ファイルチェック
		while (@file_exists(DOCUMENT_ROOT . RPW . $file_dir . '/' . $file_name)) {
			preg_match('/(.*?)(_(\d*))?(\.[^\.]*)/i', $file_name, $ret);
			$file_name = $ret[1] . "_" . ($ret[3] + 1) . $ret[4];
		}
		
		// 画像テーブルを更新
		$sql = "UPDATE " . ($p_tbl == WORK_TABLE ? "tbl_work_images" : "tbl_publish_images");
		$sql .= " SET " . $objImages2->_addslashesC('src', $file_dir . '/' . $file_name, '=', 'TEXT');
		$sql .= " WHERE " . $objImages2->_addslashesC('page_id', $PID, '=', 'INT');
		$sql .= " AND " . $objImages2->_addslashesC('src', $src, 'LIKE', 'TEXT');
		if (!$objImages2->execute($sql)) {
			// エラー
			$err_flg = FLAG_ON;
			$err_msg = $p_str . '画像情報の更新に失敗しました。[' . $src . ']';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// 削除対象となるテーブルにパスを記入
		$sql = "INSERT INTO tbl_tmp_deletes (file_path)";
		$sql .= " VALUES (" . $objDac->_addslashes($src, 'TEXT') . ")";
		if (!$objDac->execute($sql)) {
			// エラー
			$err_flg = FLAG_ON;
			$err_msg = '画像削除情報の登録に失敗しました。[' . $src . ']';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// 対象ページの作成ユーザーが所属する組織のフォルダ権限を追加する
		// 対象のページ作成者の組織コードを取得する
		$where = $objDac->_addslashesC('user_id', $user_id, '=', 'INT');
		$objDac->setTableName('tbl_user');
		$objDac->select($where, 'dept_code,class');
		if (!$objDac->fetch()) {
			// エラー
			$err_flg = FLAG_ON;
			$err_msg = 'ユーザー情報の取得に失敗しました。[' . $user_id . ']';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// ウェブマスター以外の場合
		if ($objDac->fld['class'] != USER_CLASS_WEBMASTER) {
			// 組織コード
			$dept_code = $objDac->fld['dept_code'];
			// すでに登録されていないかチェック
			if (!checkHandlerDirectory($dept_code, $file_dir)) {
				// フォルダに対するアクセス権限を追加
				$sql = "INSERT INTO tbl_handler (class, item1, item2)";
				$sql .= " VALUES (" . HANDLER_CLASS_DIRECTORY . ", ";
				$sql .= $objDac->_addslashes($dept_code, 'TEXT') . ", ";
				$sql .= $objDac->_addslashes($file_dir . '/', 'TEXT') . ")";
				if (!$objDac->execute($sql)) {
					// エラー
					$err_flg = FLAG_ON;
					$err_msg = '組織情報の登録に失敗しました。[' . $dept_code . ']';
					$ng_ary[$PID][] = $err_msg;
					_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
					continue;
				}
			}
		}
		
		// context を置換
		$page_fld['context'] = str_replace($src, $file_dir . '/' . $file_name, $page_fld['context']);
		
		// 画像ファイルのコピー処理
		

		// フォルダの作成
		if (!mkNewDirectory(DOCUMENT_ROOT . RPW . $file_dir . '/' . $file_name)) {
			// エラー
			$err_flg = FLAG_ON;
			$err_msg = 'ファイルのコピー先フォルダの作成に失敗しました。[' . $file_dir . ']';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// 画像ファイルのコピー
		if (!@copy(DOCUMENT_ROOT . RPW . $src, DOCUMENT_ROOT . RPW . $file_dir . '/' . $file_name)) {
			// エラー
			$err_flg = FLAG_ON;
			$err_msg = 'ファイルのコピーに失敗しました。[' . $src . ' => ' . $file_dir . '/' . $file_name . ' ]';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// 権限変更
		@chmod(DOCUMENT_ROOT . RPW . $file_dir . '/' . $file_name, 0777);
		
		$err_msg = 'ファイルのコピーに成功しました。[' . $src . ' => ' . $file_dir . '/' . $file_name . ']';
		$ok_ary[$PID][] = $err_msg;
		_trace_write_conv($err_msg . "[" . $src . "=>" . $file_dir . "/" . $file_name . "]【" . $PID . "】", $max_cnt, $cnt, FLAG_ON);
	}
	
	// エラーがある場合
	if ($err_flg == FLAG_ON) {
		return FALSE;
	}
	// 
	return TRUE;
}

/**
 * 依存ファイル（リンク）を処理
 *
 * @param $page_fld 対象ページ情報
 * @return 成功した場合は、TRUE。そうでない場合は、FALSEを返す。
 */
function move_links(&$page_fld, $p_tbl, $p_str) {
	// グローバル宣言
	global $objDac;
	global $objLinks;
	global $objLinks2;
	
	global $ok_ary;
	global $ng_ary;
	global $no_ary;
	
	global $max_cnt;
	global $cnt;
	
	global $page_title;
	
	$_NOT_COPY_DIR = getDefineArray('_NOT_COPY_DIR');
	$DENIED_EXTENSIONS_FILE_ARY = explode(",", DENIED_EXTENSIONS_FILE);
	
	// 変数の宣言
	$sql = ""; // SQL文（全文）
	$where = ""; // SQL文（WHERE句）
	$err_flg = FLAG_OFF; // エラーフラグ
	

	// ページID
	$PID = $page_fld['page_id'];
	// ファイルパス
	$file_path = $page_fld['file_path'];
	// ユーザーID
	$user_id = $page_fld['user_id'];
	
	// ページの保存先パス
	$dir_path = preg_replace('/^(\/\/|\.\/)/i', '/', preg_replace("/\\\\/", "/", cms_dirname($file_path)));
	// 正規表現用 ファイルパス
	$preg_file_dir = "(" . reg_replace($dir_path . FCK_FILELINK_FORDER) . "|" . reg_replace(FCK_FILELINK_FORDER_SHARED) . ")";
	
	$dir_path_flg = FLAG_OFF;
	$lower_nm_flg = FLAG_OFF;
	
	//依存情報（リンク）の取得
	$objLinks->selectRelated($PID, $p_tbl);
	
	// 取得したパスの数分ループ
	while ($objLinks->fetch()) {
		// 初期化
		$err_msg = "";
		
		// 取得結果代入
		$path = $objLinks->fld['path'];
		
		// ファイル実在チェック
		if (!@file_exists(DOCUMENT_ROOT . RPW . $path)) {
			// 未処理
			$err_msg = 'リンクファイルが存在しません。[' . $path . ']';
			$no_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, -1);
			continue;
		}
		// フラグ初期化
		$dir_path_flg = FLAG_OFF;
		$lower_nm_flg = FLAG_OFF;
		// パスが修正されているかチェック
		if (preg_match('/^' . $preg_file_dir . '\/[^\/]*$/i', $path)) {
			$dir_path_flg = FLAG_ON;
		}
		// 移動対象外ディレクトリかチェック
		foreach ((array) $_NOT_COPY_DIR as $key => $dir) {
			if (preg_match('/^' . reg_replace($dir) . '/', $path)) {
				$dir_path_flg = FLAG_ON;
				break;
			}
		}
		// ファイル名の大文字チェック
		$file_name = basename($path);
		if ($file_name == strtolower($file_name)) {
			$lower_nm_flg = FLAG_ON;
		}
		//
		if ($dir_path_flg == FLAG_ON && $lower_nm_flg == FLAG_ON) {
			// 未処理
			$err_msg = 'コンバートする必要のないファイルです。[' . $path . ']';
			$no_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, -1);
			continue;
		}
		// 拡張子をチェック
		$exte = @getExtension($path);
		if (!@is_file(DOCUMENT_ROOT . RPW . $path) || in_array($exte, $DENIED_EXTENSIONS_FILE_ARY)) {
			// 未処理
			$err_msg = 'コンバート対象外のファイルです。[' . $path . ']';
			$no_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, -1);
			continue;
		}
		
		//ファイル名の取得
		$file_name = strtolower(basename($path));
		//ファイル移動先ディレクトリの取得
		$file_dir = cms_dirname($file_path) . FCK_FILELINK_FORDER;
		$file_dir = preg_replace('/^(\/\/|\.\/)/i', '/', $file_dir);
		//移動先の同名ファイルチェック
		while (@file_exists(DOCUMENT_ROOT . RPW . $file_dir . '/' . $file_name)) {
			preg_match('/(.*?)(_(\d*))?(\.[^\.]*)/i', $file_name, $ret);
			$file_name = $ret[1] . "_" . ($ret[3] + 1) . $ret[4];
		}
		
		// リンクテーブルを更新
		$sql = "UPDATE " . ($p_tbl == WORK_TABLE ? "tbl_work_links" : "tbl_publish_links");
		$sql .= " SET " . $objLinks2->_addslashesC('path', $file_dir . '/' . $file_name, '=', 'TEXT');
		$sql .= " WHERE " . $objLinks2->_addslashesC('page_id', $PID, '=', 'INT');
		$sql .= " AND " . $objLinks2->_addslashesC('path', $path, 'LIKE', 'TEXT');
		if (!$objLinks2->execute($sql)) {
			// エラー
			$err_flg = FLAG_ON;
			$err_msg = $p_str . 'リンク情報の更新に失敗しました。[' . $path . ']';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// 削除対象となるテーブルにパスを記入
		$sql = "INSERT INTO tbl_tmp_deletes (file_path)";
		$sql .= " VALUES (" . $objDac->_addslashes($path, 'TEXT') . ")";
		if (!$objDac->execute($sql)) {
			// エラー
			$err_flg = FLAG_ON;
			$err_msg = '削除情報の登録に失敗しました。[' . $path . ']';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// 対象ページの作成ユーザーが所属する組織のフォルダ権限を追加する
		// 対象のページ作成者の組織コードを取得する
		$where = $objDac->_addslashesC('user_id', $user_id, '=', 'INT');
		$objDac->setTableName('tbl_user');
		$objDac->select($where, 'dept_code,class');
		if (!$objDac->fetch()) {
			// エラー
			$err_flg = FLAG_ON;
			$err_msg = 'ユーザー情報の取得に失敗しました。[' . $user_id . ']';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		//ウェブマスター以外の場合
		if ($objDac->fld['class'] != USER_CLASS_WEBMASTER) {
			$dept_code = $objDac->fld['dept_code'];
			//すでに登録されていないかチェック
			if (!checkHandlerDirectory($dept_code, $file_dir)) {
				//フォルダに対するアクセス権限を追加
				$sql = "INSERT INTO tbl_handler (class, item1, item2) ";
				$sql .= " VALUES (" . HANDLER_CLASS_DIRECTORY . ", ";
				$sql .= $objDac->_addslashes($dept_code, 'TEXT') . ", ";
				$sql .= $objDac->_addslashes($file_dir . '/', 'TEXT') . ")";
				if (!$objDac->execute($sql)) {
					// エラー
					$err_flg = FLAG_ON;
					$err_msg = '組織情報の登録に失敗しました。[' . $dept_code . ']';
					$ng_ary[$PID][] = $err_msg;
					_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
					continue;
				}
			}
		}
		
		//contextの中を置換
		$page_fld['context'] = str_replace($path, $file_dir . '/' . $file_name, $page_fld['context']);
		
		// リンクファイルのコピー処理
		

		// フォルダの作成
		if (!mkNewDirectory(DOCUMENT_ROOT . RPW . $file_dir . '/' . $file_name)) {
			// エラー
			$err_flg = FLAG_ON;
			$err_msg = 'ファイルのコピー先フォルダの作成に失敗しました。[' . $file_dir . ']';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// ファイルのコピー
		if (!@copy(DOCUMENT_ROOT . RPW . $path, DOCUMENT_ROOT . RPW . $file_dir . '/' . $file_name)) {
			// エラー
			$err_flg = FLAG_ON;
			$err_msg = 'ファイルのコピーに失敗しました。[' . $path . ' => ' . $file_dir . '/' . $file_name . ']';
			$ng_ary[$PID][] = $err_msg;
			_trace_write_conv($err_msg . "【" . $PID . "】", $max_cnt, $cnt, FLAG_OFF);
			continue;
		}
		// 権限変更
		@chmod(DOCUMENT_ROOT . RPW . $file_dir . '/' . $file_name, 0777);
		
		$err_msg = 'ファイルのコピーに成功しました。[' . $path . ' => ' . $file_dir . '/' . $file_name . ']';
		$ok_ary[$PID][] = $err_msg;
		_trace_write_conv($err_msg . "[" . $path . "=>" . $file_dir . "/" . $file_name . "]【" . $PID . "】", $max_cnt, $cnt, FLAG_ON);
	}
	
	// エラーがある場合
	if ($err_flg == FLAG_ON) {
		return FALSE;
	}
	//
	return TRUE;
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>／version2.0 ⇒ 2.2</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
</head>
<body id="cms8341-mainbg">

<div align="center">

<div class="cms8341-area-corner">

<p><a href="../index.php">ホーム</a> &gt; <?=htmlDisplay($menu_info['label'])?> &gt; 完了</p>

<p id="cms8341-pankuzu">version2.0 ⇒ 2.2 コンバートプログラム</p>

<p><strong><?=htmlDisplay($menu_info['label'])?></strong></p>

<?=htmlDisplay($result)?>

<a
	href="<?=str_replace(DOCUMENT_ROOT, "", TRACE_LOG_DIR . TRACE_LOG_FILE)?>"
	target="_blank">トレースログを見る</a>

<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable" style="font-size: small">
	<tr>
		<th>結果</th>
	</tr>
<?php
if (count($page_ary) <= 0) {
	?>
<tr>
		<td align="center">ページが存在しません。</td>
	</tr>
<?php
}
else {
	// 結果
	foreach ($page_ary as $PID => $info) {
		?>
<tr>
		<td>
		<p><?=htmlDisplay($info['title'])?></p>
		<p>
<?php
		if (isset($ng_ary[$PID])) {
			foreach ($ng_ary[$PID] as $err) {
				print '<span style="color: red;">' . htmlDisplay($err) . '</span><br />';
			}
		}
		elseif ($info['exec'] == FLAG_ON) {
			print '<span style="color: blue;">情報を更新しました。</span><br />';
		}
		?>
</p>
		<p>
<?php
		//			if (isset($no_ary[$PID] ) ) {
		//				foreach ($no_ary[$PID] as $non ) {
		//					print '<span style="color: gray;">'.htmlDisplay($non ).'</span><br />';
		//				}
		//			}
		?>
</p>
		</td>
	</tr>
<?php
	}
}
?>
</table>

<br />

</div>
</div>

</body>
</html>