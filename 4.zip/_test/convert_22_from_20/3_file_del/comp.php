<?php
/*
 * 不要な画像・ファイルの削除(実行)
 */
// 設定ファイル読み込み
require ("../../../admin/.htsetting");
// コンバートプログラム用設定ファイル読み込み
require ("../setting.inc");

// ウェブマスター以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	user_error('不正アクセスです。【 user 】');
}

// 引数が不正
if (!isset($_POST['exec']) || $_POST['exec'] != FLAG_ON) {
	user_error('不正アクセスです。【 exec 】');
}

// コンバートプログラム情報配列
$_CONV_ARRAY = getDefineArray('_CONV_ARRAY');
$menu_info = $_CONV_ARRAY[_FILE_DEL];

// DB
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
$objDac2 = new dac($objCnc);

// 削除対象外ディレクトリ
$NOT_DEL_DIR = getDefineArray('_NOT_DEL_DIR');

$del_file_path_ary = array();

// FTP接続
if (FTP_UPLOAD_FLG) {
	$ftpCnc = connectFTP("cms");
}

// 画像・ファイルパスを全件取得(重複無視)
$objDac->setTableName('tbl_tmp_deletes GROUP BY file_path');
$objDac->select();

// 件数
$max_cnt = $objDac->getRowCount();
// 成功用配列
$ok_ary = array();
// 失敗用配列
$ng_ary = array();
// 対象外用配列
$no_ary = array();

// 処理する件数を出力
if (_FLUSH_FLG) {
	_print_flush(date('H:i:s') . " | 全" . $max_cnt . "件 <br />" . "\n");
}

// 処理開始時間
$start_time = microtime(true);

while ($objDac->fetch()) {
	// 削除ファイルパス
	$file_path = $objDac->fld['file_path'];
	
	// 現在処理中の件数
	$cnt = $objDac->fetchrow;
	
	// 指定件数処理したら件数を表示
	if (_FLUSH_FLG && $cnt % _FLUSH_CNT == 0) {
		// 
		$t = _time_left_check($start_time, $max_cnt, $cnt);
		_print_flush("" . date('H:i:s') . " | " . $cnt . "件目 | E " . date('H:i:s', $t['end']) . " ( " . $t['his'] . " ) <br />" . "\n");
	}
	
	/* 削除チェック */
	$err_msg = "";
	$suc_msg = "";
	
	// 拡張子チェック
	if (preg_match('/[\.htm|\.html]$/', $file_path)) {
		$err_msg = "拡張子が[.htm]または[.html]であるファイルは削除することはできません。";
		$no_ary[] = $file_path . "\n" . $err_msg;
		_trace_write_conv($err_msg . "【" . $file_path . "】", $max_cnt, $cnt, -1);
		continue;
	}
	
	// 他のページで参照されているかチェック
	// 大文字小文字を区別して検索
	foreach (array(
			'tbl_publish_images' => 'src', 
			'tbl_work_images' => 'src', 
			'tbl_publish_links' => 'path', 
			'tbl_work_links' => 'path'
	) as $tbl => $column) {
		$sql = "SELECT * FROM " . $tbl . " WHERE " . $objDac2->_addslashesC("BINARY " . $column, $file_path, 'LIKE');
		$objDac2->execute($sql);
		$$tbl = $objDac2->getRowCount();
	}
	if ($tbl_publish_images > 0 || $tbl_work_images > 0 || $tbl_publish_links > 0 || $tbl_work_links > 0) {
		$err_msg = "このファイルを参照しているページが存在するため削除できませんでした。";
		$no_ary[] = $file_path . "\n" . $err_msg;
		_trace_write_conv($err_msg . "【" . $file_path . "】", $max_cnt, $cnt, -1);
		continue;
	}
	
	// 削除禁止ディレクトリチェック
	$dir_check_flg = FLAG_OFF;
	foreach ((array) $NOT_DEL_DIR as $key => $dir) {
		if (preg_match('/^' . reg_replace($dir) . '/', $file_path)) {
			$dir_check_flg = FLAG_ON;
			break;
		}
	}
	if ($dir_check_flg == FLAG_ON) {
		$err_msg = "削除対象となっているパスの中に削除禁止ディレクトリが含まれているため削除できませんでした。";
		$no_ary[] = $file_path . "\n" . $err_msg;
		_trace_write_conv($err_msg . "【" . $file_path . "】", $max_cnt, $cnt, -1);
		continue;
	}
	
	/* ファイルの削除処理 */
	
	// CMS8341削除対象ファイル削除
	if (@file_exists(DOCUMENT_ROOT . RPW . $file_path)) {
		// 削除失敗
		if (!@unlink(DOCUMENT_ROOT . RPW . $file_path)) {
			$err_msg = "[cms8341]より削除対象ファイルの削除に失敗しました。";
			$ng_ary[] = $file_path . "\n" . $err_msg;
			_trace_write_conv($err_msg . "【" . $file_path . "】", $max_cnt, $cnt, FLAG_OFF);
		} // 削除成功
		else {
			$suc_msg = "[cms8341]より削除対象ファイルの削除に成功しました。";
			$ok_ary[] = $file_path . "\n" . $suc_msg;
			_trace_write_conv($suc_msg . "【" . $file_path . "】", $max_cnt, $cnt, FLAG_ON);
		}
	}
	// CMS8341_real削除対象ファイル削除
	if (@file_exists(DOCUMENT_ROOT . RPR . $file_path)) {
		// 削除失敗
		if (!@unlink(DOCUMENT_ROOT . RPR . $file_path)) {
			$err_msg = "[cms8341_real]より削除対象ファイルの削除に失敗しました。";
			$ng_ary[] = $file_path . "\n" . $err_msg;
			_trace_write_conv($err_msg . "【" . $file_path . "】", $max_cnt, $cnt, FLAG_OFF);
		} // 削除成功
		else {
			$suc_msg = "[cms8341_real]より削除対象ファイルの削除に成功しました。";
			$ok_ary[] = $file_path . "\n" . $suc_msg;
			_trace_write_conv($suc_msg . "【" . $file_path . "】", $max_cnt, $cnt, FLAG_ON);
		}
	}
	// 公開側削除対象ファイル削除
	if (FTP_UPLOAD_FLG) {
		if (cx_ftp_size($ftpCnc, FTP_ROOT_DIR . $file_path) >= 0) {
			// 削除失敗
			if (!cx_ftp_delete($ftpCnc, FTP_ROOT_DIR . $file_path)) {
				$err_msg = "[公開側]より削除対象ファイルの削除に失敗しました。";
				$ng_ary[] = $file_path . "\n" . $err_msg;
				_trace_write_conv($err_msg . "【" . $file_path . "】", $max_cnt, $cnt, FLAG_OFF);
			} // 削除成功
			else {
				$suc_msg = "[公開側]より削除対象ファイルの削除に成功しました。";
				$ok_ary[] = $file_path . "\n" . $suc_msg;
				_trace_write_conv($suc_msg . "【" . $file_path . "】", $max_cnt, $cnt, FLAG_ON);
			}
		}
	}
	
	// 処理を実行できなかった場合は現在処理中の件数を trace.log に出力
	if ($err_msg == "" && $suc_msg == "") {
		$suc_msg = "削除を行う必要はありませんでした。";
		$no_ary[] = $file_path . "\n" . $suc_msg;
		_trace_write_conv($suc_msg . "【" . $file_path . "】", $max_cnt, $cnt, -1);
	}
	
	/* フォルダの削除処理 */
	
	$dir_path = cms_dirname($file_path);
	$entry = "";
	$delete_dir = array();
	$delete_flg = FLAG_ON;
	
	// 対象ファイルのフォルダにファイルが存在するかチェック
	do {
		if (@file_exists(DOCUMENT_ROOT . RPW . $dir_path)) {
			if ($dh = opendir(DOCUMENT_ROOT . RPW . $dir_path)) {
				while (($entry = readdir($dh)) !== FALSE) {
					// ドットは無視
					if ($entry == "." || $entry == "..") continue;
					// 他にファイルがある場合は削除できない
					$delete_flg = FLAG_OFF;
					break;
				}
				closedir($dh);
			}
		}
		// 削除可能ディレクトリの場合
		if ($delete_flg == FLAG_ON) {
			// 配列に格納
			$delete_dir[] = $dir_path;
			// チェックフォルダを変更
			$dir_path = preg_replace("/\/([^\/]+)?$/", "", $dir_path);
		}
	} while ($delete_flg == FLAG_ON && $dir_path != "" && $dir_path != "/");
	
	foreach ((array) $delete_dir as $dir_path) {
		// CMS8341に存在しない場合はスキップ
		if (!@file_exists(DOCUMENT_ROOT . RPW . $dir_path)) continue;
		
		// CMS8341削除対象ファイルのフォルダ削除
		if (!@rmdir(DOCUMENT_ROOT . RPW . $dir_path)) {
			// 削除失敗
			$err_msg = "[cms8341]よりフォルダの削除に失敗しました。";
			$ng_ary[] = $file_path . "\n" . $err_msg;
			_trace_write_conv($err_msg . "【" . $dir_path . "】", $max_cnt, $cnt, FLAG_OFF);
		}
		else {
			// 削除成功
			$suc_msg = "[cms8341]よりフォルダの削除に成功しました。";
			$ok_ary[] = $file_path . "\n" . $suc_msg;
			_trace_write_conv($suc_msg . "【" . $dir_path . "】", $max_cnt, $cnt, FLAG_ON);
		}
		// CMS8341_real削除対象ファイルのフォルダ削除
		if (!@rmdir(DOCUMENT_ROOT . RPR . $dir_path)) {
			// 削除失敗
			$err_msg = "[cms8341_real]よりフォルダの削除に失敗しました。";
			$ng_ary[] = $file_path . "\n" . $err_msg;
			_trace_write_conv($err_msg . "【" . $dir_path . "】", $max_cnt, $cnt, FLAG_OFF);
		}
		else {
			// 削除成功
			$suc_msg = "[cms8341_real]よりフォルダの削除に成功しました。";
			$ok_ary[] = $file_path . "\n" . $suc_msg;
			_trace_write_conv($suc_msg . "【" . $dir_path . "】", $max_cnt, $cnt, FLAG_ON);
		}
		// 公開側削除対象ファイルのフォルダ削除
		if (!deleteFolder_ftp($ftpCnc, FTP_ROOT_DIR . $dir_path)) {
			// 削除失敗
			$err_msg = "[公開側]よりフォルダの削除に失敗しました。";
			$ng_ary[] = $file_path . "\n" . $err_msg;
			_trace_write_conv($err_msg . "【" . $dir_path . "】", $max_cnt, $cnt, FLAG_OFF);
		}
		else {
			// 削除成功
			$suc_msg = "[公開側]よりフォルダの削除に成功しました。";
			$ok_ary[] = $file_path . "\n" . $suc_msg;
			_trace_write_conv($suc_msg . "【" . $dir_path . "】", $max_cnt, $cnt, FLAG_ON);
		}
	}
}

if (FTP_UPLOAD_FLG && $ftpCnc != "") {
	ftp_close($ftpCnc);
}

// 処理終了を出力
if (_FLUSH_FLG) {
	_print_flush(date('H:i:s') . " | 全" . $max_cnt . "件 全ての処理が終了しました。 <br />" . "\n");
}

// 結果を trace.log に出力
traceWrite($max_cnt . "件 全ての処理が終了しました。");

$result = "削除対象ファイル削除処理終了";
traceWrite("( RESULT ) " . $result);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>／version2.0 ⇒ 2.2</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
</head>
<body id="cms8341-mainbg">

<div align="center">

<div class="cms8341-area-corner">

<p><a href="../index.php">ホーム</a> &gt; <?=htmlDisplay($menu_info['label'])?> &gt; 完了</p>

<p id="cms8341-pankuzu">version2.0 ⇒ 2.2 コンバートプログラム</p>

<p><strong><?=htmlDisplay($menu_info['label'])?></strong></p>

<?=htmlDisplay($result)?>

<a
	href="<?=str_replace(DOCUMENT_ROOT, "", TRACE_LOG_DIR . TRACE_LOG_FILE)?>"
	target="_blank">トレースログを見る</a>

<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable" style="font-size: small">
	<tr>
		<th>削除したファイル</th>
	</tr>
<?php
if (count($ok_ary) <= 0) {
	?>
<tr>
		<td align="center">削除したファイルはありません。</td>
	</tr>
<?php
}
else {
	// 成功結果
	foreach ($ok_ary as $msg) {
		?>
<tr>
		<td><?=htmlDisplay($msg)?></td>
	</tr>
<?php
	}
}
?>
</table>

<br />

<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable" style="font-size: small">
	<tr>
		<th>削除に失敗したファイル</th>
	</tr>
<?php
if (count($ng_ary) <= 0) {
	?>
<tr>
		<td align="center">削除に失敗したファイルはありません。</td>
	</tr>
<?php
}
else {
	// 失敗結果
	foreach ($ng_ary as $msg) {
		?>
<tr>
		<td><?=htmlDisplay($msg)?></td>
	</tr>
<?php
	}
}
?>
</table>

<br />

<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable" style="font-size: small">
	<tr>
		<th>未処理のファイル</th>
	</tr>
<?php
if (count($no_ary) <= 0) {
	?>
<tr>
		<td align="center">未処理のファイルはありません。</td>
	</tr>
<?php
}
else {
	// 失敗結果
	foreach ($no_ary as $msg) {
		?>
<tr>
		<td><?=htmlDisplay($msg)?></td>
	</tr>
<?php
	}
}
?>
</table>

<br />

</div>
</div>

</body>
</html>