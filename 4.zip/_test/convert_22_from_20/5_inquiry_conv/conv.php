<?php
/* 
 * 
 */
// -------------------------------------------
// 設定ファイル
// -----------------------


// 共通
require ("../../../admin/.htsetting");
// 問い合わせ領域コンバート
require_once ("./setting.inc");

// -------------------------------------------
// DB
// -----------------------


require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$objDept = new tbl_department($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPageExec = new tbl_page($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInquiry = new tbl_inquiry($objCnc);

// -------------------------------------------
// 定数
// -----------------------


// 問い合わせ領域に設定する組織コード
$SET_INQUIRY_DEPT_ARY = getDefineArray('SET_INQUIRY_DEPT_ARY');

// -------------------------------------------
// 初期化
// -----------------------


// 結果格納配列
$result_ary = array();
$page_result = array();

// テンプレート情報取得結果代入用
$template_ary = array();

// 組織情報取得結果代入用
$dept_ary = array();

// 総ページ数取得結果代入用
$page_ary = array();

// -------------------------------------------
// コンバート
// -----------------------


foreach ($SET_INQUIRY_DEPT_ARY as $template_id => $dept_code) {
	
	// 結果出力用メッセージ
	$result_ary[$template_id] = array(
			"result" => TRUE, 
			"msg" => ''
	);
	
	// テンプレート情報取得
	if ($objTool->selectTemplate($template_id) === FALSE) {
		// 失敗
		$result_ary[$template_id]["result"] = FALSE;
		$result_ary[$template_id]["msg"] = 'テンプレート情報の取得に失敗しました。';
		continue;
	}
	// テンプレート情報格納
	$template_ary[$template_id] = $objTool->fld;
	
	// 組織情報取得
	if ($objDept->selectFromCode($dept_code) === FALSE) {
		// 失敗
		$result_ary[$template_id]["result"] = FALSE;
		$result_ary[$template_id]["msg"] = '組織情報の取得に失敗しました。';
		continue;
	}
	// 組織情報格納
	$dept_ary[$template_id] = $objDept->fld;
	
	// ページ情報取得
	$where = $objPage->_addslashesC("template_id", $template_id);
	
	// 公開
	$objPage->setTableName(PUBLISH_TABLE);
	$objPage->select($where);
	$page_ary[$template_id]['p'] = $objPage->getRowCount();
	
	if (isset($_GET['go'])) {
		
		$err_msg = '';
		$page_result[$template_id]['p'] = array();
		
		while ($objPage->fetch()) {
			
			$objCnc->begin();
			
			$page_id = $objPage->fld['page_id'];
			
			$page_result[$template_id]['p'][$page_id]['fld'] = $objPage->fld;
			$page_result[$template_id]['p'][$page_id]['result'] = TRUE;
			$page_result[$template_id]['p'][$page_id]['msg'] = '';
			
			if (_reg_inquiry($objPage->fld, $dept_ary[$template_id], PUBLISH_TABLE, $err_msg) === FALSE) {
				$objCnc->rollback;
				$page_result[$template_id]['p'][$page_id]['result'] = FALSE;
				$page_result[$template_id]['p'][$page_id]['msg'] = $err_msg;
			}
			else {
				$objCnc->commit();
			}
		}
	}
	
	// 編集
	$objPage->setTableName(WORK_TABLE);
	$objPage->select($where);
	$page_ary[$template_id]['w'] = $objPage->getRowCount();
	
	if (isset($_GET['go'])) {
		
		$err_msg = '';
		$page_result[$template_id]['w'] = array();
		
		while ($objPage->fetch()) {
			
			$objCnc->begin();
			
			$page_id = $objPage->fld['page_id'];
			
			$page_result[$template_id]['w'][$page_id]['fld'] = $objPage->fld;
			$page_result[$template_id]['w'][$page_id]['result'] = TRUE;
			$page_result[$template_id]['w'][$page_id]['msg'] = '';
			
			if (_reg_inquiry($objPage->fld, $dept_ary[$template_id], WORK_TABLE, $err_msg) === FALSE) {
				$objCnc->rollback();
				$page_result[$template_id]['w'][$page_id]['result'] = FALSE;
				$page_result[$template_id]['w'][$page_id]['msg'] = $err_msg;
			}
			else {
				$objCnc->commit();
			}
		}
	}
}

function _reg_inquiry($pfld, $dfld, $tbl, &$err_msg) {
	
	global $objInquiry;
	global $objPageExec;
	
	$err_msg = '';
	
	$inquiry_id = $objInquiry->getSeqNextval();
	
	$ary = array(
			'inquiry_id' => $inquiry_id, 
			'inquiry_no' => 1, 
			'dept_code' => $dfld['dept_code'], 
			'name' => '', 
			'anex_number' => '', 
			'drxt_number' => $dfld['tel'], 
			'fax' => $dfld['fax'], 
			'email' => $dfld['email']
	);
	
	if ($pfld['inquiry_id'] != "" && $objInquiry->deleteFromID($pfld['inquiry_id'], $tbl) === FALSE) {
		$err_msg = "問い合わせ先情報の削除に失敗しました。";
		return FALSE;
	}
	
	if ($objInquiry->insert($ary, $tbl) === FALSE) {
		$err_msg = "問い合わせ先情報の登録に失敗しました。";
		return FALSE;
	}
	
	$ary = array(
			'page_id' => $pfld['page_id'], 
			'inquiry_flg' => FLAG_ON, 
			'inquiry_id' => $inquiry_id
	);
	
	if ($objPageExec->update($ary, $tbl) === FALSE) {
		$err_msg = "ページ情報への問い合わせ先情報の登録に失敗しました。";
		return FALSE;
	}
	
	return TRUE;
}

// -------------------------------------------
// HTML出力
// -----------------------
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>問い合わせ領域コンバート／version2.0 ⇒ 2.2</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
</head>

<body id="cms8341-mainbg">

<div align="center">

<div class="cms8341-area-corner">

<p id="cms8341-pankuzu">問い合わせ領域コンバート</p>

<?php
if (!isset($_GET['go'])) {
	?>

<p><a href="conv.php?go">下記内容にてコンバート開始</a></p>

<?php
}
?>

<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable" style="font-size: small">
	<tr>
		<th width="30%">テンプレート</th>
		<th width="30%">設定組織</th>
		<th width="10%">結果</th>
		<th width="30%">詳細</th>
	</tr>
<?php
foreach ($SET_INQUIRY_DEPT_ARY as $template_id => $dept_code) {
	?>
<td>
<?php
	// テンプレート
	print htmlDisplay($template_id) . "<br />";
	
	if (isset($template_ary[$template_id])) {
		print htmlDisplay($template_ary[$template_id]['name']);
	}
	?>
</td>
	<td>
<?php
	// 設定組織
	print htmlDisplay($dept_code) . "<br />";
	
	if (isset($dept_ary[$template_id])) {
		print htmlDisplay($dept_ary[$template_id]['dept_name']);
	}
	?>
</td>
	<td>
<?php
	// 結果
	if ($result_ary[$template_id]['result']) {
		print "○";
	}
	else {
		print "×";
	}
	?>
</td>
	<td>
<?php
	// 詳細
	if ($result_ary[$template_id]['result']) {
		print "公開中ページ数：" . $page_ary[$template_id]['p'] . "<br />";
		print "編集中ページ数：" . $page_ary[$template_id]['w'] . "<br />";
	}
	else {
		print '<span style="color: red;">' . $result_ary[$template_id]['msg'] . "</span><br />";
	}
	?>
</td>
	</tr>

<?php
	// 実行結果
	if (isset($_GET['go']) && $result_ary[$template_id]['result']) {
		print '<tr>';
		print '<td colspan="4" style="background-color: #FFFFaa">更新した公開ページ情報</th>';
		print '</tr>';
		if (count($page_result[$template_id]['p']) <= 0) {
			print '<tr>';
			print '<td colspan="4">対象ページが存在しませんでした。</td>';
			print '</tr>';
		}
		else {
			foreach ($page_result[$template_id]['p'] as $page_id => $pinfo) {
				print '<tr>';
				print '<td colspan="4">';
				
				print htmlDisplay($pinfo['fld']['page_title']) . "<br />";
				print htmlDisplay($pinfo['fld']['file_path']) . "<br />";
				
				if (!$pinfo['result']) {
					print '<span style="color: red;">' . $pinfo['msg'] . "</span><br />";
				}
				
				print '</td>';
				print '</tr>';
			}
		}
		
		print '<tr>';
		print '<td colspan="4" style="background-color: #FFFFaa">更新した編集ページ情報</th>';
		print '</tr>';
		if (count($page_result[$template_id]['w']) <= 0) {
			print '<tr>';
			print '<td colspan="4">対象ページが存在しませんでした。</td>';
			print '</tr>';
		}
		else {
			foreach ($page_result[$template_id]['w'] as $page_id => $pinfo) {
				print '<tr>';
				print '<td colspan="4">';
				
				print htmlDisplay($pinfo['fld']['page_title']) . "<br />";
				print htmlDisplay($pinfo['fld']['file_path']) . "<br />";
				
				if (!$pinfo['result']) {
					print '<span style="color: red;">' . $pinfo['msg'] . "</span><br />";
				}
				
				print '</td>';
				print '</tr>';
			}
		}
	}
	?>

<?php
}
?>
</table>

<br />

<?php
if (!isset($_GET['go'])) {
	?>

<p><a href="conv.php?go">上記内容にてコンバート開始</a></p>

<?php
}
?>

</div>
</div>

</body>
</html>