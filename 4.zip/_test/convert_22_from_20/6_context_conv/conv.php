<?php
/* 
 * 
 */
// -------------------------------------------
// 設定ファイル
// -----------------------


// 共通
require ("../../../admin/.htsetting");

// -------------------------------------------
// DB
// -----------------------


require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPageExec = new tbl_page($objCnc);

// -------------------------------------------
// 初期化
// -----------------------


// 結果格納配列
$result_ary = array();
$page_result = array();

// テンプレート情報取得結果代入用
$template_ary = array();

// 組織情報取得結果代入用
$dept_ary = array();

// 総ページ数取得結果代入用
$page_ary = array();

// -------------------------------------------
// コンバート
// -----------------------


$target_id = 'contents';
$replace_id = 'tmp_contents';

$where = $objPage->_addslashesC('context', '%id="' . $target_id . '"%', 'LIKE');

// 公開ページ情報


$objPage->setTableName(PUBLISH_TABLE);
$objPage->select($where);

while ($objPage->fetch()) {
	$page_id = $objPage->fld['page_id'];
	$page_ary['p'][$page_id]['fld'] = $objPage->fld;
	$page_ary['p'][$page_id]['result'] = TRUE;
	$page_ary['p'][$page_id]['msg'] = '';
	
	if (isset($_GET['go'])) {
		$objCnc->begin();
		if (_replace_context_id($objPage->fld, PUBLISH_TABLE, $target_id, $replace_id) === FALSE) {
			$objCnc->rollback();
			$page_ary['p'][$page_id]['msg'] = 'ページ情報の更新に失敗しました。';
		}
		else {
			$objCnc->commit();
		}
	}
}

// 編集ページ情報


$objPage->setTableName(WORK_TABLE);
$objPage->select($where);

while ($objPage->fetch()) {
	$page_id = $objPage->fld['page_id'];
	$page_ary['w'][$page_id]['fld'] = $objPage->fld;
	$page_ary['w'][$page_id]['result'] = TRUE;
	$page_ary['w'][$page_id]['msg'] = '';
	
	if (isset($_GET['go'])) {
		$objCnc->begin();
		if (_replace_context_id($objPage->fld, WORK_TABLE, $target_id, $replace_id) === FALSE) {
			$objCnc->rollback();
			$page_ary['w'][$page_id]['msg'] = 'ページ情報の更新に失敗しました。';
		}
		else {
			$objCnc->commit();
		}
	}
}

function _replace_context_id($fld, $tbl, $target, $replace) {
	
	global $objPageExec;
	
	$page_id = $fld['page_id'];
	$context = $fld['context'];
	
	$tmp_context = str_replace('id="' . $target . '"', 'id="' . $replace . '"', $context);
	
	$ary = array(
			'page_id' => $page_id, 
			'context' => $tmp_context
	);
	
	return $objPageExec->update($ary, $tbl);
}

// -------------------------------------------
// HTML出力
// -----------------------
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>編集領域コンバート／version2.0 ⇒ 2.2</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
</head>

<body id="cms8341-mainbg">

<div align="center">

<div class="cms8341-area-corner">

<p id="cms8341-pankuzu">編集領域コンバート</p>

<?php
if (!isset($_GET['go'])) {
	?>

<p><a href="conv.php?go">下記内容にてコンバート開始</a></p>

<?php
}
?>

<p>公開ページ：<?=(!isset($page_ary['p']) ? "0" : count($page_ary['p']))?>件<br />
編集ページ：<?=(!isset($page_ary['w']) ? "0" : count($page_ary['w']))?>件</p>

<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable" style="font-size: small">
	<tr>
		<th width="40%">ページ</th>
		<th width="10%">結果</th>
		<th width="40%">詳細</th>
	</tr>
<?php
print '<tr>';
print '<td colspan="4" style="background-color: #FFFFaa">公開ページ</th>';
print '</tr>';

if (!isset($page_ary['p']) || count($page_ary['p']) <= 0) {
	print '<tr>';
	print '<td colspan="4">対象ページが存在しませんでした。</th>';
	print '</tr>';
}
else {
	foreach ($page_ary['p'] as $page_id => $info) {
		?>
<tr>
		<td>
<?php
		// ページ
		print '<strong>' . htmlDisplay($info['fld']['page_title'] . "（" . $page_id . "）") . "</strong><br />";
		print htmlDisplay($info['fld']['file_path']);
		?>
</td>
		<td>
<?php
		// 結果
		if ($info['result']) {
			print(isset($_GET['go']) ? "○" : "&nbsp;");
		}
		else {
			print "×";
		}
		?>
</td>
		<td>
<?php
		// 詳細
		print $info['msg'];
		?>
</td>
	</tr>
<?php
	}
}
?>
<?php

print '<tr>';
print '<td colspan="4" style="background-color: #FFFFaa">編集ページ</th>';
print '</tr>';

if (!isset($page_ary['w']) || count($page_ary['w']) <= 0) {
	print '<tr>';
	print '<td colspan="4">対象ページが存在しませんでした。</th>';
	print '</tr>';
}
else {
	foreach ($page_ary['w'] as $page_id => $info) {
		?>
<td>
<?php
		// ページ
		print '<strong>' . htmlDisplay($info['fld']['page_title'] . "（" . $page_id . "）") . "</strong><br />";
		print htmlDisplay($info['fld']['file_path']);
		?>
</td>
	<td>
<?php
		// 結果
		if ($info['result']) {
			print(isset($_GET['go']) ? "○" : "&nbsp;");
		}
		else {
			print "×";
		}
		?>
</td>
	<td>
<?php
		// 詳細
		print $info['msg'];
		?>
</td>
	</tr>
<?php
	}
}
?>
</table>

<br />

<?php
if (!isset($_GET['go'])) {
	?>

<p><a href="conv.php?go">上記内容にてコンバート開始</a></p>

<?php
}
?>

</div>
</div>

</body>
</html>