<?php
/*
 * 各種コンバートプログラムのインデックスページ
 */
// 設定ファイル読み込み
require ("../../admin/.htsetting");
// コンバートプログラム用設定ファイル読み込み
require ("./setting.inc");

// ウェブマスター以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	user_error('不正アクセスです。');
}

// コンバートプログラム情報配列
$_CONV_ARRAY = getDefineArray('_CONV_ARRAY');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>インデックスページ／version2.0 ⇒ 2.2</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
</head>
<body id="cms8341-mainbg">

<div align="center">
<div class="cms8341-area-corner">

<p id="cms8341-pankuzu">version2.0 ⇒ 2.2 コンバートプログラム</p>

<?php
foreach ($_CONV_ARRAY as $cnt => $menu_info) {
	?>
<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable" style="font-size: small">
	<tr>
		<th>
<?=htmlDisplay($menu_info['label'])?>
</th>
	</tr>
	<tr>
		<td>
		<p><?=htmlDisplay($menu_info['explanation'])?></p>
		<form name="cms_exec_<?=$cnt?>" id="cms_exec_<?=$cnt?>" method="POST"
			action="<?=$menu_info['exec_page']?>"><input type="submit"
			name="cms_submit" id="cms_submit_<?=$cnt?>" value="実行" /> <input
			type="hidden" name="exec" id="exec_<?=$cnt?>" value="<?=FLAG_ON?>" />
		</form>
		</td>
	</tr>
</table>
<br />
<?php
}
?>
<?php

// CMS で管理しているものの情報を表示
$CMS_INFO = array();

// ページ総数取得( tbl_publish_page )
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage->setTableName(PUBLISH_TABLE);
$objPage->select();

$CMS_INFO['CMS_PAGE_CNT'] = $objPage->getRowCount();
?>
<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable" style="font-size: small">
	<tr>
		<th width="120">ページ総数</th>
		<td><?=$CMS_INFO['CMS_PAGE_CNT']?> 件</td>
	</tr>
</table>
</div>
</div>

</body>
</html>