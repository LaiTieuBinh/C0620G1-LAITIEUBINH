<?php
/*
 * tbl_publish_page, tbl_work_pageに登録されているv2.0の自動リンクコメントをv2.2の自動リンクコメントに変換する
 */
// 設定ファイル読み込み
require ("../../../admin/.htsetting");

$conv_table_ary = array(
		PUBLISH_TABLE, 
		WORK_TABLE
);
$auto_link_div_start = '<div class="cms8341-autolink-div">';
$auto_link_div_end = '</div>';
$conv_data_file_path = './conv_files';
$conv_data_file_suffix = '.txt';
$conv_result_ary = array(); // 自動リンクコメントの変換を行ったページ一覧
$err_multi_comment_ary = array(); // 自動リンクコメントが複数存在したページ一覧
$err_no_comment_ary = array(); // index_flgが1でcontextに自動リンクコメントがなかったページ一覧
$err_no_conv_file_ary = array(); // 変換データがなかったページ一覧
$err_no_use_file_ary = array(); // 使用されなかった変換データファイル一覧
$err_no_open_file_ary = array(); // openできない または、データが空ファイル一覧


// ウェブマスター以外からのアクセスはエラー
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	user_error('不正アクセスです。【 user 】');
}

//「実行」ボタンが押下されて遷移したときには変換処理を実行
if (isset($_POST['exec']) && $_POST['exec'] == 'exec_conv') {
	
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
	$objPage = new tbl_page($objCnc);
	
	// 変換データファイルの一覧を取得
	$hd_dir = opendir($conv_data_file_path);
	while ($file_name = readdir($hd_dir)) {
		if (strpos($file_name, $conv_data_file_suffix) !== false) {
			$err_no_use_file_ary[$file_name] = false;
		}
	}
	closedir($hd_dir);
	$page_cnt = 0;
	
	foreach ($conv_table_ary as $tmp_table) {
		// テーブルからindex_flg=1のページデータを取得
		$where = 'index_flg = 1';
		$objPage->setTableName($tmp_table);
		$objPage->select($where);
		
		while ($objPage->fetch()) {
			$context = $context_conv = $objPage->fld['context'];
			// 自動リンクコメントの数を数える
			$comment_cnt = 0;
			while (($autoLink_def = getMidString($context, $auto_link_div_start, $auto_link_div_end)) !== FALSE) {
				$context = str_replace($auto_link_div_start . $autoLink_def . $auto_link_div_end, '', $context);
				$comment_cnt++;
			}
			
			// 複数の自動リンクタグコメントが存在したらエラー配列にセット
			if ($comment_cnt > 1) {
				$err_multi_comment_ary[] = array(
						'table' => $tmp_table, 
						'page_id' => $objPage->fld['page_id'], 
						'page_title' => htmlspecialchars($objPage->fld['page_title']), 
						'file_path' => htmlspecialchars($objPage->fld['file_path'])
				);
				continue;
			}
			// 自動リンクタグコメントが存在しなかったらエラー配列にセット
			if ($comment_cnt == 0) {
				$err_no_comment_ary[] = array(
						'table' => $tmp_table, 
						'page_id' => $objPage->fld['page_id'], 
						'page_title' => htmlspecialchars($objPage->fld['page_title']), 
						'file_path' => htmlspecialchars($objPage->fld['file_path'])
				);
				continue;
			}
			$conv_data_file_name = $conv_data_file_path . '/' . $objPage->fld['page_id'] . $conv_data_file_suffix;
			// 変換データが存在しなかったらエラー配列にセット
			if (!file_exists($conv_data_file_name)) {
				$err_no_conv_file_ary[] = array(
						'table' => $tmp_table, 
						'page_id' => $objPage->fld['page_id'], 
						'page_title' => htmlspecialchars($objPage->fld['page_title']), 
						'file_path' => htmlspecialchars($objPage->fld['file_path'])
				);
				continue;
			}
			
			// 自動リンクコメントの数が1つのとき
			// 変換データファイルの内容を取得して、自動リンクコメントを変換
			if ($conv_data = file_get_contents($conv_data_file_name)) {
				
				$pt = "/" . reg_replace($auto_link_div_start) . ".*" . reg_replace($auto_link_div_end) . "/Uis";
				$res = preg_replace($pt, $conv_data, $context_conv);
				
				// 変換後のテキストをDBに登録
				$update_ary = array();
				$update_ary['page_id'] = $objPage->fld['page_id'];
				$update_ary['context'] = $res;
				$objPage_update = new tbl_page($objCnc);
				$objPage_update->update($update_ary, $tmp_table);
				
				// 処理結果を配列にセット
				$conv_result_ary[] = array(
						'table' => $tmp_table, 
						'page_id' => $objPage->fld['page_id'], 
						'page_title' => htmlspecialchars($objPage->fld['page_title']), 
						'file_path' => htmlspecialchars($objPage->fld['file_path'])
				);
				unset($err_no_use_file_ary[$objPage->fld['page_id'] . $conv_data_file_suffix]);
				$page_cnt++;
			
			}
			else {
				// ファイルが開けない または、ファイル内のデータが空
				$err_no_open_file_ary[] = $objPage->fld['page_id'] . $conv_data_file_suffix;
				unset($err_no_use_file_ary[$objPage->fld['page_id'] . $conv_data_file_suffix]);
			}
		}
	}
	
	//結果ページを作成
	$contents = '';
	$contents .= '';
	$contents .= '<p id="cms8341-pankuzu">version2.0 ⇒ 2.2 自動リンクコメント変換プログラム 実行結果</p>';
	$contents .= '<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable" style="font-size: small">';
	$contents .= '<tr><th colspan="4">変換実行画面(変換したページ数:' . $page_cnt . ')</th></tr>';
	
	if (empty($conv_result_ary)) {
		$contents .= '<tr><td><p>変換されたページはありませんでした。</p></td></tr>';
		$contents .= '</table>';
	}
	else {
		$contents .= '<tr>';
		$contents .= '<th>テーブル名</th><th>ページID</th><th>ページタイトル<th>ページ保存先</th>';
		$contents .= '</tr>' . "\r\n";
		
		foreach ($conv_result_ary as $tmp_ary) {
			$contents .= make_result_table_row($tmp_ary);
		}
	}
	$contents .= '</table>' . "\r\n";
	$contents .= '<br />' . "\r\n";
	
	if (!empty($err_multi_comment_ary)) {
		$contents .= '<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable" style="font-size: small">';
		$contents .= '<tr><th colspan="4"><span style="color:#ff0000">【ERROR】</span>複数の自動リンクコメントが設定されていたページ</th></tr>';
		$contents .= '<tr>';
		$contents .= '<th>テーブル名</th><th>ページID</th><th>ページタイトル<th>ページ保存先</th>';
		$contents .= '</tr>' . "\r\n";
		foreach ($err_multi_comment_ary as $tmp_ary) {
			$contents .= make_result_table_row($tmp_ary);
		}
		$contents .= '</table>' . "\r\n";
		$contents .= '<br />' . "\r\n";
	}
	
	if (!empty($err_no_comment_ary)) {
		$contents .= '<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable" style="font-size: small">';
		$contents .= '<tr><th colspan="4"><span style="color:#ff0000">【ERROR】</span>index_flg=1となっていたが自動リンクコメントが設定されていないページ</th></tr>';
		$contents .= '<tr>';
		$contents .= '<th>テーブル名</th><th>ページID</th><th>ページタイトル<th>ページ保存先</th>';
		$contents .= '</tr>' . "\r\n";
		foreach ($err_no_comment_ary as $tmp_ary) {
			$contents .= make_result_table_row($tmp_ary);
		}
		$contents .= '</table>' . "\r\n";
		$contents .= '<br />' . "\r\n";
	}
	
	if (!empty($err_no_conv_file_ary)) {
		$contents .= '<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable" style="font-size: small">';
		$contents .= '<tr><th colspan="4"><span style="color:#ff0000">【ERROR】</span>変換データファイル(PAGE_ID.txt)が存在しないページ</th></tr>';
		$contents .= '<tr>';
		$contents .= '<th>テーブル名</th><th>ページID</th><th>ページタイトル<th>ページ保存先</th>';
		$contents .= '</tr>' . "\r\n";
		foreach ($err_no_conv_file_ary as $tmp_ary) {
			$contents .= make_result_table_row($tmp_ary);
		}
		$contents .= '</table>' . "\r\n";
		$contents .= '<br />' . "\r\n";
	}
	
	if (!empty($err_no_open_file_ary)) {
		$contents .= '<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable" style="font-size: small">';
		$contents .= '<tr><th colspan="4"><span style="color:#ff0000">【ERROR】</span>ファイルが開けない または、ファイル内のデータが空</th></tr>';
		foreach ($err_no_open_file_ary as $val) {
			$contents .= '<tr><td colspan="4">' . $val . '</td></tr>' . "\r\n";
		}
		$contents .= '</table>' . "\r\n";
		$contents .= '<br />' . "\r\n";
	}
	
	if (!empty($err_no_use_file_ary)) {
		$contents .= '<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable" style="font-size: small">';
		$contents .= '<tr><th colspan="4"><span style="color:#0000ff">【INFO】</span>使用されなかった変換データファイル</th></tr>';
		foreach ($err_no_use_file_ary as $key => $val) {
			$contents .= '<tr><td colspan="4">' . $key . '</td></tr>' . "\r\n";
		}
		$contents .= '</table>' . "\r\n";
		$contents .= '<br />' . "\r\n";
	}
	
// 初期画面を作成
}
else {
	// CMS で管理しているものの情報を表示
	$CMS_INFO = array();
	// ページ総数取得( tbl_publish_page )
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
	$objPage = new tbl_page($objCnc);
	$objPage->setTableName(PUBLISH_TABLE);
	$objPage->select();
	
	$CMS_INFO['CMS_PAGE_CNT'] = $objPage->getRowCount();
	
	$contents = <<< EOF
			<p id="cms8341-pankuzu">version2.0 ⇒ 2.2 自動リンクコメント変換プログラム</p>
			<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable" style="font-size: small">
				<tr>
					<th>変換処理実行ボタン</th>
				</tr>
				<tr>
					<td>
						<p>
							このボタンをクリックすると各ページに設定されている、version2.0の自動リンクコメントが<br />
							version2.2の自動リンクコメントに変換されます。
						</p>
						<form name="cms_exec_autolink_conv" id="cms_exec_autolink_conv" method="POST" onSubmit="return check()">
							<input type="submit" name="cms_submit" id="cms_submit_autolink_conv" value="実行" />
							<input type="hidden" name="exec" id="exec_autolink_conv" value="exec_conv" />
						</form>
					</td>
				</tr>
			</table>
			<br />
			<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable" style="font-size: small">
				<tr>
EOF;
	$contents .= '						<th width="120">ページ総数</th>';
	$contents .= '						<td>' . $CMS_INFO['CMS_PAGE_CNT'] . '件</td>';
	$contents .= '					</tr>';
	$contents .= '				</table>';
}

function make_result_table_row($row_data) {
	$res = '';
	$res .= '<tr>';
	$res .= '<td>';
	$res .= $row_data['table'] == PUBLISH_TABLE ? "tbl_publish_page" : "tbl_work_page";
	$res .= '</td>';
	$res .= '<td>' . $row_data['page_id'] . '</td>';
	$res .= '<td>' . $row_data['page_title'] . '</td>';
	$res .= '<td>' . $row_data['file_path'] . '</td>';
	$res .= '</tr>' . "\r\n";
	return $res;
}

// 初期画面出力
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>CMS-8341 自動リンクコメント 変換ページ(v2.0 → v2.2)</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<script type="text/javascript"> 
<!-- 
function check(){
	if(window.confirm('変換処理を実行しますか？')){
		return true;
	}else{
		return false;
	}
}
// -->
</script>
</head>
<body id="cms8341-mainbg">

<div align="center">
<div class="cms8341-area-corner">
<?=$contents?>
		</div>
</div>

</body>
</html>