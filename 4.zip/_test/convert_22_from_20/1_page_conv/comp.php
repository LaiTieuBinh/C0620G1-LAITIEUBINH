<?php
/*
 * CMS管理ページの物理ファイルのコンバート(実行)
 */
// 設定ファイル読み込み
require ("../../../admin/.htsetting");
// コンバートプログラム用設定ファイル読み込み
require ("../setting.inc");

// ウェブマスター以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	user_error('不正アクセスです。【 user 】');
}

// 引数が不正
if (!isset($_POST['exec']) || $_POST['exec'] != FLAG_ON) {
	user_error('不正アクセスです。【 exec 】');
}

// コンバートプログラム情報配列
$_CONV_ARRAY = getDefineArray('_CONV_ARRAY');
$menu_info = $_CONV_ARRAY[_PAGE_CONV];

// DB
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

// 公開ページ情報を全て取得
$objPage->setTableName(PUBLISH_TABLE);
$objPage->select();

// 件数
$max_cnt = $objPage->getRowCount();
// 成功用配列
$ok_ary = array();
// 失敗用配列
$ng_ary = array();

// 処理する件数を出力
if (_FLUSH_FLG) {
	_print_flush(date('H:i:s') . " | 全" . $max_cnt . "件 <br />" . "\n");
}

// 処理開始時間
$start_time = time(true);

// 新規ページファイルを2.2用に作り直す
while ($objPage->fetch()) {
	// 情報格納
	$fld = $objPage->fld;
	
	$PID = $fld['page_id'];
	$file_path = $fld['file_path'];
	$page_title = $fld['page_title'];
	
	// 現在処理中の件数
	$cnt = $objPage->fetchrow;
	
	// 指定件数処理したら件数を表示
	if (_FLUSH_FLG && $cnt % _FLUSH_CNT == 0) {
		// 
		$t = _time_left_check($start_time, $max_cnt, $cnt);
		_print_flush("" . date('H:i:s') . " | " . $cnt . "件目 | E " . date('H:i:s', $t['end']) . " ( " . $t['his'] . " ) <br />" . "\n");
	}
	
	// 新規ページファイルの作成
	if (mkNewPage($PID, $file_path)) {
		$ok_ary[] = $page_title . "【" . $PID . "】" . "\n" . $file_path;
		_trace_write_conv("ページの作成に成功しました。【" . $PID . "】【" . $file_path . "】", $max_cnt, $cnt, FLAG_ON);
	}
	else {
		$ng_ary[] = $page_title . "【" . $PID . "】" . "\n" . $file_path;
		_trace_write_conv("ページの作成に失敗しました。【" . $PID . "】【" . $file_path . "】", $max_cnt, $cnt, FLAG_OFF);
	}
}

// 処理終了を出力
if (_FLUSH_FLG) {
	_print_flush(date('H:i:s') . " | 全" . $max_cnt . "件 全ての処理が終了しました。 <br />" . "\n");
}

// 結果文章を作成
traceWrite($max_cnt . "件 全ての処理が終了しました。");

$result = $max_cnt . "件中 ";
$result .= "【 O  K 】" . count($ok_ary) . "件 ";
$result .= "【 N  G 】" . count($ng_ary) . "件 ";

// 結果を trace.log に出力
traceWrite("( RESULT ) " . $result);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>／version2.0 ⇒ 2.2</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
</head>
<body id="cms8341-mainbg">

<div align="center">

<div class="cms8341-area-corner">

<p><a href="../index.php">ホーム</a> &gt; <?=htmlDisplay($menu_info['label'])?> &gt; 完了</p>

<p id="cms8341-pankuzu">version2.0 ⇒ 2.2 コンバートプログラム</p>

<p><strong><?=htmlDisplay($menu_info['label'])?></strong></p>

<?=htmlDisplay($result)?>

<a
	href="<?=str_replace(DOCUMENT_ROOT, "", TRACE_LOG_DIR . TRACE_LOG_FILE)?>"
	target="_blank">トレースログを見る</a>

<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable" style="font-size: small">
	<tr>
		<th>成功</th>
	</tr>
<?php
if (count($ok_ary) <= 0) {
	?>
<tr>
		<td align="center">成功したページはありません。</td>
	</tr>
<?php
}
else {
	// 成功結果
	foreach ($ok_ary as $msg) {
		?>
<tr>
		<td><?=htmlDisplay($msg)?></td>
	</tr>
<?php
	}
}
?>
</table>

<br />

<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable" style="font-size: small">
	<tr>
		<th>失敗</th>
	</tr>
<?php
if (count($ng_ary) <= 0) {
	?>
<tr>
		<td align="center">失敗したページはありません。</td>
	</tr>
<?php
}
else {
	// 失敗結果
	foreach ($ng_ary as $msg) {
		?>
<tr>
		<td><?=htmlDisplay($msg)?></td>
	</tr>
<?php
	}
}
?>
</table>

<br />

</div>
</div>

</body>
</html>