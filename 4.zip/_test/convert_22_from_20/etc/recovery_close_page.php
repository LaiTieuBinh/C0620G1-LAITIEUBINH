<?php
/*
 * 対象ページが非公開の場合は公開ページを削除
 */
// -------------------------------------------
// 設定ファイル
// -----------------------


require ("../../../admin/.htsetting");

// -------------------------------------------
// DB
// -----------------------


require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPageExec = new tbl_page($objCnc);

// -------------------------------------------
// ※ 対象ページID
// -----------------------


$CLOSE_PAGE_LIST = array(
		"2832", 
		"2683", 
		"914", 
		"4251", 
		"2601", 
		"4169", 
		"3040", 
		"4386", 
		"3840", 
		"769", 
		"770", 
		"771", 
		"3847", 
		"2568", 
		"3080", 
		"3848", 
		"3082", 
		"2827", 
		"3083", 
		"3851", 
		"780", 
		"3340", 
		"3341", 
		"3086", 
		"3342", 
		"2575", 
		"3087", 
		"4111", 
		"3088", 
		"2833", 
		"2834", 
		"3090", 
		"3859", 
		"276", 
		"2581", 
		"1048", 
		"281", 
		"1051", 
		"540", 
		"3356", 
		"541", 
		"3101", 
		"542", 
		"1566", 
		"3871", 
		"3616", 
		"1057", 
		"3106", 
		"3362", 
		"3874", 
		"3107", 
		"2597", 
		"3109", 
		"3621", 
		"3877", 
		"4135", 
		"3880", 
		"4136", 
		"1065", 
		"2604", 
		"3116", 
		"3374", 
		"1071", 
		"4143", 
		"1584", 
		"4145", 
		"1074", 
		"1586", 
		"1075", 
		"3635", 
		"1076", 
		"2868", 
		"3636", 
		"1848", 
		"313", 
		"3641", 
		"1595", 
		"4155", 
		"1596", 
		"3645", 
		"318", 
		"1598", 
		"3134", 
		"2368", 
		"321", 
		"2369", 
		"2881", 
		"3907", 
		"4163", 
		"324", 
		"2884", 
		"3908", 
		"2885", 
		"1094", 
		"584", 
		"3400", 
		"4168", 
		"585", 
		"333", 
		"3149", 
		"4173", 
		"4174", 
		"3919", 
		"337", 
		"3155", 
		"4179", 
		"3163", 
		"3164", 
		"3676", 
		"3677", 
		"2658", 
		"3683", 
		"3172", 
		"3685", 
		"3177", 
		"3178", 
		"4202", 
		"3179", 
		"2672", 
		"4208", 
		"2418", 
		"2674", 
		"2420", 
		"2932", 
		"4212", 
		"2423", 
		"2679", 
		"3191", 
		"2424", 
		"2680", 
		"3192", 
		"2681", 
		"3961", 
		"2682", 
		"3962", 
		"3966", 
		"639", 
		"3711", 
		"3712", 
		"641", 
		"3969", 
		"642", 
		"2434", 
		"3715", 
		"644", 
		"3716", 
		"3717", 
		"3978", 
		"2700", 
		"397", 
		"2701", 
		"3726", 
		"2703", 
		"2704", 
		"2705", 
		"2706", 
		"3730", 
		"2707", 
		"2453", 
		"2454", 
		"2966", 
		"2967", 
		"4247", 
		"3992", 
		"2458", 
		"2715", 
		"3996", 
		"2464", 
		"417", 
		"2465", 
		"163", 
		"2723", 
		"676", 
		"1956", 
		"3237", 
		"2472", 
		"2728", 
		"1452", 
		"3244", 
		"1453", 
		"1454", 
		"1455", 
		"2991", 
		"3247", 
		"3248", 
		"1457", 
		"3250", 
		"3251", 
		"4277", 
		"4023", 
		"3003", 
		"3259", 
		"3263", 
		"3776", 
		"3011", 
		"4042", 
		"4043", 
		"3022", 
		"1487", 
		"3281", 
		"2770", 
		"3282", 
		"723", 
		"1492", 
		"3028", 
		"1493", 
		"2773", 
		"3029", 
		"726", 
		"1494", 
		"2774", 
		"3287", 
		"4055", 
		"4056", 
		"4057", 
		"2522", 
		"4058", 
		"2523", 
		"4059", 
		"732", 
		"2524", 
		"733", 
		"4061", 
		"734", 
		"735", 
		"3296", 
		"3297", 
		"2530", 
		"3298", 
		"4066", 
		"3043", 
		"4323", 
		"3300", 
		"2533", 
		"3045", 
		"486", 
		"3302", 
		"487", 
		"999", 
		"2535", 
		"1256", 
		"1001", 
		"3305", 
		"3051", 
		"3565", 
		"2542", 
		"4078", 
		"3567", 
		"3312", 
		"4081", 
		"499", 
		"500", 
		"3060", 
		"2549", 
		"3317", 
		"502", 
		"2551", 
		"3831", 
		"2552", 
		"3832", 
		"4344", 
		"505", 
		"3065", 
		"506", 
		"3322", 
		"3323", 
		"508", 
		"2556", 
		"509", 
		"3325", 
		"3326", 
		"3582"
);

// -------------------------------------------
// アクセス制限
// -----------------------


if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	user_error('不正アクセスです。');
}

// -------------------------------------------
// 非公開
// -----------------------


$result = array();

if (!SFTP_FLG) {
	$ftpCnc = connectFTP("cms");
}

foreach ($CLOSE_PAGE_LIST as $page_id) {
	
	if (SFTP_FLG) {
		$ftpCnc = connectFTP("cms");
	}
	
	$result[$page_id] = array(
			"result" => TRUE, 
			"title" => '', 
			"path" => '', 
			"msg" => ''
	);
	
	// ページ情報取得
	if ($objPage->selectFromID($page_id, PUBLISH_TABLE) === FALSE) {
		$result[$page_id]['result'] = FALSE;
		$result[$page_id]['msg'] = '<span style="color: red;">ページ情報の取得に失敗しました。</span>';
		
		if (SFTP_FLG) {
			@cx_ftp_close($ftpCnc);
		}
		
		continue;
	}
	
	$title = $objPage->fld['page_title'];
	$path = $objPage->fld['file_path'];
	
	$result[$page_id]['title'] = htmlDisplay($title);
	$result[$page_id]['path'] = htmlDisplay($path);
	
	// 非公開ページかチェック
	if ($objPage->fld['close_flg'] != FLAG_ON) {
		$result[$page_id]['msg'] = '公開中のページですが、ページを非公開にします。';
	}
	
	// 実行モードでない場合は処理しない
	if (!isset($_GET['go'])) {
		
		if (SFTP_FLG) {
			@cx_ftp_close($ftpCnc);
		}
		
		continue;
	}
	
	$objCnc->begin();
	
	// 公開ページ情報の非公開フラグをOnに変更
	if ($objPage->fld['close_flg'] != FLAG_ON) {
		
		$ary = array(
				'page_id' => $page_id, 
				'close_flg' => FLAG_ON
		);
		
		if ($objPageExec->update($ary, PUBLISH_TABLE) === FALSE) {
			
			$objCnc->rollback();
			
			$result[$page_id]['result'] = FALSE;
			$result[$page_id]['msg'] = '<span style="color: red;">ページの非公開に失敗しました。</span>';
			
			if (SFTP_FLG) {
				@cx_ftp_close($ftpCnc);
			}
			
			continue;
		}
	}
	
	$real_path = DOCUMENT_ROOT . RPR . $path;
	$ftp_path = FTP_ROOT_DIR . $path;
	
	// realフォルダから削除
	if (@file_exists($real_path) && !@unlink($real_path)) {
		
		$objCnc->rollback();
		
		$result[$page_id]['result'] = FALSE;
		$result[$page_id]['msg'] = '<span style="color: red;">公開用HTMLファイルの削除に失敗しました。</span>';
		
		if (SFTP_FLG) {
			@cx_ftp_close($ftpCnc);
		}
		
		continue;
	}
	
	// 公開側から削除
	if (FTP_UPLOAD_FLG) deleteFile_ftp($ftpCnc, $ftp_path);
	
	$result[$page_id]['msg'] = 'ページのリカバリーを実行しました。';
	
	$objCnc->commit();
}

if (!SFTP_FLG) {
	@cx_ftp_close($ftpCnc);
}

// -------------------------------------------
// HTML出力
// -----------------------


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ページの非公開</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
</head>
<body id="cms8341-mainbg">

<div align="center">
<div class="cms8341-area-corner">

<p id="cms8341-pankuzu">ページの非公開</p>

<?php
if (!isset($_GET['go'])) {
	?><p><a href="recovery_close_page.php?go">下記内容にてコンバート開始</a></p><?php
}
?>

<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable" style="font-size: small">
	<tr>
		<th width="40%">ページ</th>
		<th width="10%">結果</th>
		<th width="50%">情報</th>
	</tr>
<?php
foreach ($result as $page_id => $info) {
	?>
<tr>
		<td><strong><?=$info['title']?></strong>（<?=$page_id?>）<br /><?=$info['path']?></td>
		<td><?=($info['result'] ? (isset($_GET['go']) ? "○" : "") : "×")?></td>
		<td><?=$info['msg']?></td>
	</tr>
<?php
}
?>
</table>

<br />

<?php
if (!isset($_GET['go'])) {
	?><p><a href="recovery_close_page.php?go">上記内容にてコンバート開始</a></p><?php
}
?>

</div>
</div>

</body>
</html>