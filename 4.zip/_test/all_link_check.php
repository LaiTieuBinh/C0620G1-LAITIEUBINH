<?php
/*
 * リンクチェック
 */
require ("../admin/.htsetting");

// 別ウィンドウ用
gd_errorhandler_ini_set("template_user_error", "template_user_error_win");
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>リンクチェック</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/linkcheck.css"
	type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="top">
		<p><img src="<?=RPW?>/admin/images/linkcheck/bar_tolink.jpg"
			alt="リンクしているページ" width="430" height="20"></p>
<?php
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

require (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
require (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');

/*---公開ページを確認---*/
$sql = "SELECT * " . "FROM tbl_publish_page ";
//取得
$objDac->execute($sql);

link_check($objDac, "", "公開中ページ");

/*---未公開ページを確認---*/
$sql = "SELECT * " . "FROM tbl_work_page ";
//取得
$objDac->execute($sql);

link_check($objDac, "edit", "作業中（または承認中）ページ");

?>
</td>
	</tr>
</table>
</body>
</html>
<?php
function link_check($i_objDac, $i_strDispMode, $i_strTitle) {
	global $objCnc;
	
	print '<font color="#D50000"><strong>--------------------' . $i_strTitle . '--------------------</strong></font><br>';
	
	$_POST['cms_dispMode'] = $i_strDispMode;
	//データ作成
	while ($i_objDac->fetch()) {
		$temp = "";
		$_POST['cms_page_id'] = $i_objDac->fld['page_id'];
		
		$objLinks = new tbl_links($objCnc);
		
		// 公開情報の取得
		$objPage = new tbl_page($objCnc);
		$fields = "file_path, dir_path";
		if ($objPage->selectFromID($_POST['cms_page_id'], 1, $fields) === FALSE) {
			user_error("dac execute error. <br>tbl_page->selectFromID(" . $_POST['cms_page_id'] . ", 1, " . $fields . ");", E_USER_ERROR);
		}
		$page_fld = $objPage->fld;
		
		// 閲覧モードのときは編集ページのリンク情報を取得
		if ($_POST['cms_dispMode'] == 'edit') {
			$objLinks->selectLinks($_POST['cms_page_id'], 2);
			// リストからのときは公開ページのリンク情報を取得
		}
		else {
			$objLinks->selectLinks($_POST['cms_page_id'], 1);
		}
		if ($objLinks->getRowCount() == 0) {
			//			print '<p class="cms8341-normal">リンクしているページはありません。</p>'."\n";
		}
		else {
			// DBに登録されたリンク情報を見ていく
			while ($objLinks->fetch()) {
				$msg = '';
				$err = 'normal';
				$title = '';
				// 外部リンク：outer_flg==1
				if ($objLinks->fld['outer_flg'] == 1) {
					$err = 'error';
					$res = get_http_header($objLinks->fld['path']); // httpヘッダを取得
					$title = $objLinks->fld['path'] . ' [' . $objLinks->fld['text'] . ']';
					// Status-Codeの一文字目が1か2のときはリンク切れ
					if (in_array(substr($res['Status-Code'], 0, 1), array(
							1, 
							2
					))) {
						$err = 'normal';
					}
					else {
						$temp .= '<p class="cms8341-' . $err . '"><img src="' . RPW . '/admin/images/icon/link_' . $err . '.jpg" alt="" width="12" height="12">' . $title . $msg . '</p>' . "\n";
					}
					
				// 内部リンク
				}
				else {
					// 拡張子が取れなければリンク切れ
					if ($objLinks->fld['file_exte'] == '') $err = 'error';
					// HTMLファイルの場合
					elseif ($objLinks->fld['file_exte'] == 'htm') {
						// 公開ページ情報に登録されてなければリンク切れ：あればlink_page_idとして取得される
						if ($objLinks->fld['linkpage_id'] == '') $err = 'error';
						// パスのHTMLファイルが存在しなければリンク切れ
						elseif (!file_exists(DOCUMENT_ROOT . RPW . $objLinks->fld['path'])) $err = 'error';
						// 新規作成中のページ
						elseif ($objLinks->fld['work_class'] == 1) $msg = '&nbsp;<font color="#009900">（新規作成中）</font>';
						// 削除処理中のページ
						elseif ($objLinks->fld['work_class'] == 3) $msg = '&nbsp;<font color="#D50000">（削除処理中）</font>';
						if ($err == 'normal') $title = htmlDisplay($objLinks->fld['page_title']) . '&nbsp;&nbsp;';
						
					// HTMLファイル以外の場合
					}
					else {
						// ファイルが存在しなければリンク切れ
						if (!file_exists(DOCUMENT_ROOT . RPW . $objLinks->fld['path'])) $err = 'error';
						$title = htmlDisplay($objLinks->fld['path']) . '&nbsp;&nbsp;';
					}
					$title .= '[' . $objLinks->fld['text'] . ']';
				}
				if ($err == 'error') {
					// $title内のパス（画像リンクなど）は絶対パスにする
					$title = setAbsolutePath($title, $page_fld['dir_path'], RPW);
					$temp .= '<p class="cms8341-' . $err . '"><img src="' . RPW . '/admin/images/icon/link_' . $err . '.jpg" alt="" width="12" height="12">' . $title . $msg . '</p>' . "\n";
				}
			}
			
			if ($temp != '') {
				print '<font color="#009900"><strong>【' . $i_objDac->fld['page_title'] . '】（' . $i_objDac->fld['file_path'] . '）</strong></font><br>';
				print $temp;
			}
		}
	}
}
?>