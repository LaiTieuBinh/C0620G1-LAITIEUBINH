<?php
/*
 *
 */
/** 外部ページの取り込み **/
require ("../../admin/.htsetting");
global $objCnc;

require_once ('./csvtodbSettingFunc.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

//csvファイル最大行
define("G_CSV_MAX_LINE", 20000);

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $objLogin->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}
if (!isset($_POST['cms_filename']) || $_POST['cms_filename'] == "") {
	user_error('不正アクセスです。');
}

if (isset($_SESSION['post'])) unset($_SESSION['post']);
$_SESSION['post'] = $_POST;
gd_errorhandler_ini_set("html0", './ancestor_change_index.php');

//---引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError("インポートをするcsvファイルを指定してください。", 2, "javascript:history.back()");
	exit();
}
//---ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError("csvファイルのファイルサイズが0バイトです。", 2, "javascript:history.back()");
	exit();
}
//---アップロード
$frmCsvFnm = DOCUMENT_ROOT . DIR_PATH_UPLOAD . "/temp/" . $frmCsvFnm;
if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $frmCsvFnm) == FALSE) {
	DispError("csvファイルのアップロードに失敗しました。", 2, "javascript:history.back()");
	exit();
}
//(念のため)ファイル存在チェック
if (file_exists($frmCsvFnm) == FALSE) {
	$wk_str = "指定されたファイル【" . $frmCsvFnm . "】が存在しません。";
	DispError($wk_str, 2, "javascript:history.back()");
	exit();
}

$aryFiles = array();
$msg = "";

//CSVファイルよりページ情報配列作成
$dbFunc = new csvtodbSettingFunc($frmCsvFnm);
$dbFunc->chk_files($aryFiles);

// トランザクション開始
$objCnc->begin();

// エラーがなければ更新
if (count($dbFunc->err_ary) == 0) {
	if ($dbFunc->update($aryFiles) === FALSE) {
		$objCnc->rollback();
	}
}

// エラーがなければコミット
if (count($dbFunc->err_ary) == 0) {
	$objCnc->commit();
	$msg = "正常に終了しました";
}
else {
	foreach ($dbFunc->err_ary as $err) {
		$msg .= $err . "<br>";
	}
	$objCnc->rollback();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>公開DB同期処理</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="./ancestor_change.css" type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<div align="center">
<div class="cms8341-area-corner">
<?php
echo $msg;
?>
<p align="center" id="cms_submit"><a href="javascript:history.back();"><img
	src="<?=RPW?>/admin/images/btn/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</form>

</body>
</html>

