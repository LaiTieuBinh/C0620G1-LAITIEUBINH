<?php
/*
 *
 */
require ("../admin/.htsetting");

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

$objPage->setTableName(PUBLISH_TABLE);
$objPage->select();

while ($objPage->fetch()) {
	$fld = $objPage->fld;
	mkNewPage($fld['page_id'], $fld['file_path']);
}

?>