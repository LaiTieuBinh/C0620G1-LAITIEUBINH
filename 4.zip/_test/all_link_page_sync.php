<?php
/*
 * 自動リンクのタグの同期
 */
require ("../admin/.htsetting");
global $objCnc;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');

$objPage = new tbl_page($objCnc);

$objCnc->begin();
$success_list = array();
foreach (array(
		PUBLISH_TABLE, 
		WORK_TABLE
) as $tbl) {
	$objPage->setTableName($tbl);
	$objPage->select();
	while ($objPage->fetch()) {
		$is_update = FALSE;
		$fld = $objPage->fld;
		$total_str = create_page_check_context($fld['page_id'], $tbl);
		// ページで使用する自動リンク情報を登録
		if (entryAutolinkPage($total_str, $fld['page_id'], $tbl) === FALSE) continue;
		$success_list[] = $fld['page_id'] . "：" . $fld['file_path'] . "【" . $tbl . "】";
	}
}
echo count($success_list) . "件 更新しました<br>";
if (isset($_GET['go'])) {
	$objCnc->commit();
	echo "コミットしました<br>";
}
else {
	$objCnc->rollback();
	echo "ロールバックしました<br>";
}

foreach ($success_list as $list) {
	echo $list . "<br>";
}

?>
