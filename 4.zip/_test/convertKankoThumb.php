<?php
/*
 *
 */
require ("../admin/.htsetting");

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);

$objImages->setTableName(PUBLISH_TABLE);
$objImages->select();

while ($objImages->fetch()) {
	$fld = $objImages->fld;
	$page_id = $fld['page_id'];
	$file_path = $fld['src'];
	$file_name = basename($file_path);
	$pos = strrpos($file_name, ".");
	$file = substr($file_name, 0, $pos);
	if (file_exists(DOCUMENT_ROOT . RPR . FTP_ROOT_DIR . KANKO_THUMBNAIL_DIR . "/" . $file . ".jpg")) {
		rename(DOCUMENT_ROOT . RPR . FTP_ROOT_DIR . KANKO_THUMBNAIL_DIR . "/" . $file . ".jpg", DOCUMENT_ROOT . RPR . FTP_ROOT_DIR . KANKO_THUMBNAIL_DIR . "/" . $page_id . ".jpg");
	}
	else if (file_exists(DOCUMENT_ROOT . RPR . FTP_ROOT_DIR . KANKO_THUMBNAIL_DIR . "/" . $file . "_1.jpg")) {
		rename(DOCUMENT_ROOT . RPR . FTP_ROOT_DIR . KANKO_THUMBNAIL_DIR . "/" . $file . "_1.jpg", DOCUMENT_ROOT . RPR . FTP_ROOT_DIR . KANKO_THUMBNAIL_DIR . "/" . $page_id . ".jpg");
	}
}

?>