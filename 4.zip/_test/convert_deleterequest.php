<?php
/*
 * テンプレートIDごとのページを削除公開待ちにする
 */
require ("../admin/.htsetting");

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage2 = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInq = new tbl_inquiry($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
$objKanko = new tbl_kanko($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output_handler.inc');
$objOpHndl = new tbl_output_handler($objCnc);
// イベントカレンダー複数日
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_event.inc');
$obj_event = new tbl_event($objCnc);
// オープンデータ
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_open_data.inc');
$obj_open_data = new tbl_open_data($obj_cnc);

// 対象テンプレートを使用しているページを取得
$where = 'template_id = 14';
$objPage->setTableName(PUBLISH_TABLE);
$objPage->select($where);

while ($objPage->fetch()) {
	$PID = $objPage->fld['page_id'];
	$work_class = $objPage->fld['work_class'];
	$bak_status = $objPage->fld['status'];
	$file_path = $objPage->fld['file_path'];
	
	// 新規作成ページおよび公開待ち状態になっていないページは削除できない
	if ($work_class != 2 || $bak_status < 401) {
		print_dp('このページは公開待ち、もしくは公開中でないため、削除できません。');
		print_dp($file_path);
		print_dp('------------------------------------------------------------------');
	}
	
	// work_pageに情報をコピー
	$ary = array();
	$ary['page_id'] = $PID;
	$ary['work_class'] = 3;
	// ウェブマスターの場合は公開待ち状態にする
	$ary['status'] = 401;
	// 公開済みだったページ
	if ($bak_status == 402) {
		$ary['bak_status'] = 402;
		// 公開ページ情報の更新（UPDATE tbl_publish_page）
		$objPage2->update($ary, 1);
		// 編集ページ情報の登録（INSERT INT tbl_work_page SELECT FROM tbl_publish_page）
		$objPage2->insertWorkFromPublish($PID, $objLogin->login);
		$objInq->insertWorkFromPublish($objPage->fld['inquiry_id']);
		$objKanko->insertWorkFromPublish($PID);
		// イベントカレンダー複数日
		if (EVENT_CAL_MULTI_FLAG) {
			$obj_event->insertWorkFromPublish($PID);
		}
		// 外部連携データ設定の登録
		if (ENABLE_OPTION_OUTPUT) $objOpHndl->insertWorkFromPublish($PID);
		// オープンデータ
		if ($obj_open_data->insertWorkFromPublish($PID) === FALSE) {
			return FALSE;
		}
		// 編集ページ情報の更新（UPDATE tbl_work_page）
		unset($ary['bak_status']);
		$ary['close_flg'] = 0;
		$objPage2->update($ary, 2);
		// 公開待ちだったページ
	}
	else {
		// 公開ページ情報の更新（UPDATE tbl_publish_page）
		$objPage2->update($ary, 1);
		// 編集ページ情報の更新（UPDATE tbl_work_page）
		$ary['close_flg'] = 0;
		$objPage2->update($ary, 2);
	}
}
?>