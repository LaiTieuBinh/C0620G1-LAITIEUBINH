<?php
/*
 *
 */
require ("../admin/.htsetting");

define("KANKO_TEMPLATE_ID", "6");
define("STAY_TEMPLATE_ID", "7");
define("EVENT_TEMPLATE_ID", "8");
define("SEASON_TEMPLATE_ID", "14");
// 開発環境
/*	define("KANKO_TEMPLATE_ID","12");
define("STAY_TEMPLATE_ID","13");
define("EVENT_TEMPLATE_ID","14");
define("SEASON_TEMPLATE_ID","11");*/
$colum2 = array(
		'purpose', 
		'area_code', 
		'cate_1st', 
		'cate_2nd', 
		'cate_3rd', 
		'sightseeing_time', 
		'sightseeing_name', 
		'sightseeing_kana', 
		'city_code', 
		'address', 
		'latitude', 
		'longitude', 
		'outline', 
		'content', 
		'related_information', 
		'note', 
		'tel', 
		'fax', 
		'mail', 
		'url', 
		'inquiry_name', 
		'inquiry_tel', 
		'inquiry_fax', 
		'inquiry_mail', 
		'closest_station', 
		'closest_ic', 
		'other_accesses', 
		'relatedsite_name', 
		'relatedsite_url', 
		'standard_car', 
		'largesized_car', 
		'charge', 
		'corresponds_card', 
		'cultural_asset', 
		'natural_monument', 
		'scenic_beauty', 
		'experience', 
		'training_use', 
		'communal_facilities', 
		'suckle_room', 
		'day_nursery', 
		'health_tourism', 
		'visiting_facility', 
		'souvenir_sales', 
		'local_guide', 
		'facilities_guide', 
		'barrier_free', 
		'lending_wheelchair', 
		'restroom_handicapped', 
		'braille_guide', 
		'sign_language', 
		'', 
		'corresponds_language', 
		'img_name1', 
		'img_text1', 
		'img_name2', 
		'img_text2', 
		'img_name3', 
		'img_text3', 
		'img_name4', 
		'img_text4', 
		'open_lib', 
		'open_lib2', 
		'reg_holiday', 
		'nece_time', 
		'field_area', 
		'altitude', 
		'total_length', 
		'stay_possible', 
		'check_in', 
		'check_out', 
		'hotel_charge', 
		'meal', 
		'location', 
		'room', 
		'hotspring_flg', 
		'hotspring_placename', 
		'hotspring_bathes', 
		'hotspring_feature', 
		'hotspring_outdoor', 
		'hotspring_outdoor_room', 
		'chartered_bath', 
		'bathing_24h', 
		'hotspring_large', 
		'day_trip', 
		'show_snow', 
		'hotspring_cure', 
		'sauna', 
		'pet_going', 
		'staying_1p', 
		'nosmoking_room', 
		'it_corresponds', 
		'sending', 
		'shower_restroom', 
		'equipment_indoor', 
		'equipment_outdoor', 
		'show_eveningsun', 
		'show_sea', 
		'hotspring_introduction', 
		'event_bigin_date', 
		'event_end_date', 
		'holding_time', 
		'acceptance_num', 
		'sponsor', 
		'season', 
		'season_situation', 
		'flower_num', 
		'flower_kind', 
		'lightup', 
		'lightup_bigin_date', 
		'lightup_end_date', 
		'season_holding_time', 
		'stall', 
		'event', 
		'snowfall', 
		'mail_name',  //
		'url_name',  //
		'inquiry_mail_name',  //
		'template_id', 
		'cms_dir'
);

$cateInfo = array();
$cateInfo[KANKO_TEMPLATE_ID]["category"] = array(
		1, 
		2, 
		3, 
		4, 
		6, 
		7, 
		10
);
$cateInfo[EVENT_TEMPLATE_ID]["category"] = array(
		8
);
$cateInfo[STAY_TEMPLATE_ID]["category"] = array(
		5, 
		9
);
$cateInfo[SEASON_TEMPLATE_ID]["category"] = array(
		11
);
$cateInfo[KANKO_TEMPLATE_ID]["dir"] = "/institution";
$cateInfo[EVENT_TEMPLATE_ID]["dir"] = "/event";
$cateInfo[STAY_TEMPLATE_ID]["dir"] = "/stay";
$cateInfo[SEASON_TEMPLATE_ID]["dir"] = "/season";

$dect_ary = array(
		'（社）新潟県観光協会' => '/ken/kyoukai', 
		'新潟県観光協会' => '/ken/kyoukai', 
		'新潟県観光振興課' => '/ken/kanko', 
		'粟島浦村産業建設課' => '/awashima/kanko', 
		'粟島観光協会' => '/awashima/kyoukai', 
		'村上市商工観光課' => '/murakami/kanko', 
		'村上市観光協会' => '/murakami/kyoukai', 
		'村上市朝日地区観光協会' => '/murakami/asahikyoukai', 
		'関川村農政観光課' => '/sekikawa/kanko', 
		'関川村観光協会' => '/sekikawa/kyoukai', 
		'胎内市観光課・胎内川観光協会' => '/tainai/kanko', 
		'胎内市・胎内川観光協会' => '/tainai/kanko', 
		'新発田市観光振興課' => '/shibata/kanko', 
		'（財）新発田まちづくり観光協会' => '/shibata/machikyoukai', 
		'月岡温泉観光協会' => '/shibata/tsukioka', 
		'新発田市紫雲寺観光協会' => '/shibata/shiunji', 
		'聖籠町産業観光課' => '/seiro/kanko', 
		'聖籠町観光協会' => '/seiro/kyoukai', 
		'阿賀野市商工観光課' => '/agano/kanko', 
		'阿賀野市観光協会' => '/agano/kyoukai', 
		'新潟市観光交流課' => '/niigata-city/kanko', 
		'新潟市北区産業振興課' => '/niigata-city/kitaku', 
		'新潟市東区政策企画課' => '/niigata-city/higashiku', 
		'新潟市中央区政策企画課' => '/niigata-city/tyuoku', 
		'新潟市江南区産業振興課' => '/niigata-city/kounanku', 
		'新潟市秋葉区産業振興課' => '/niigata-city/akihaku', 
		'新潟市南区産業振興課' => '/niigata-city/minamiku', 
		'新潟市西区農政商工課' => '/niigata-city/nishiku', 
		'新潟市西蒲区産業観光課' => '/niigata-city/nishikanku', 
		'（財）新潟観光コンベンション協会' => '/niigata-city/convention', 
		'(財)新潟観光コンベンション協会' => '/niigata-city/convention', 
		'新津観光協会' => '/niigata-city/niitsukyoukai', 
		'新潟市南区観光協会' => '/niigata-city/minami-kyoukai', 
		'観光協会とよさか２１' => '/niigata-city/toyosaka21', 
		'観光協会とよさか21' => '/niigata-city/toyosaka21', 
		'観光協会とよさｋ21' => '/niigata-city/toyosaka21', 
		'岩室温泉観光協会' => '/niigata-city/iwamuro', 
		'巻観光協会' => '/niigata-city/makikyoukai', 
		'五泉市商工観光課' => '/gosen/kanko', 
		'五泉市咲花観光協会' => '/gosen/sakihana', 
		'村松観光協会' => '/gosen/muramatsu', 
		'阿賀町（阿賀町観光協会）' => '/aga/kanko_kyoukai', 
		'田上町産業振興課' => '/tagami/kanko', 
		'田上町観光協会' => '/tagami/kyoukai', 
		'加茂市商工観光課' => '/kamo/kanko', 
		'加茂市観光協会' => '/kamo/kyoukai', 
		'三条市商工観光課' => '/sangyo/kanko', 
		'三条観光協会' => '/sangyo/kyoukai', 
		'下田郷観光協会' => '/sangyo/shitada', 
		'燕市商工観光課' => '/tsubame/kanko', 
		'燕市燕地区観光協会' => '/tsubame/tsubame-kyoukai', 
		'燕市分水地区観光協会' => '/tsubame/bunsui-kyoukai', 
		'弥彦村産業振興課' => '/yahiko/kanko', 
		'弥彦観光協会' => '/yahiko/kyoukai', 
		'見附市産業振興課' => '/mitsuke/kanko', 
		'見附市観光物産協会' => '/mitsuke/kyoukai', 
		'長岡市観光課' => '/nagaoka/kanko', 
		'長岡観光・コンベンション協会' => '/nagaoka/convention', 
		'長岡市越路支所産業課' => '/nagaoka/koshiji-kanko', 
		'越路観光協会' => '/nagaoka/koshiji-kyoukai', 
		'栃尾観光協会' => '/nagaoka/tochio-kyoukai', 
		'与板観光協会' => '/nagaoka/yoita-kyoukai', 
		'中之島観光協会' => '/nagaoka/nakanoshima-kyoukai', 
		'和島観光協会' => '/nagaoka/washima-kyoukai', 
		'寺泊観光協会' => '/nagaoka/tera-kyoukai', 
		'山古志観光協会' => '/nagaoka/yamakoshi-kyoukai', 
		'出雲崎町産業観光課' => '/izumozaki/kanko', 
		'出雲崎町観光協会' => '/izumozaki/kyoukai', 
		'刈羽村農政商工課' => '/kariwa/kanko', 
		'柏崎市観光交流課' => '/kashiwazaki/kanko', 
		'高柳町観光協会' => '/kashiwazaki/takayanagi', 
		'西山町観光協会' => '/kashiwazaki/nishiyama', 
		'小千谷市商工観光課' => '/ojiya/kanko', 
		'小千谷観光協会' => '/ojiya/kyoukai', 
		'川口町産業振興課' => '/kawaguchi/kanko', 
		'川口町観光協会' => '/kawaguchi/kyoukai', 
		'魚沼市商工観光課' => '/uonuma/kanko', 
		'魚沼市観光協会' => '/uonuma/kyoukai', 
		'南魚沼市商工観光課' => '/minamiuonuma/kanko', 
		'南魚沼市観光協会' => '/minamiuonuma/kyoukai', 
		'湯沢町産業観光課' => '/yuzawa/kanko', 
		'湯沢町観光協会' => '/yuzawa/kyoukai', 
		'十日町市観光交流課' => '/tokamachi/kanko', 
		'十日町市観光協会' => '/tokamachi/kyoukai', 
		'十日町市川西支所' => '/tokamachi/kawanishi', 
		'十日町市中里支所' => '/tokamachi/nakasato', 
		'十日町市松代支所' => '/tokamachi/matsudai', 
		'十日町市松之山支所' => '/tokamachi/matsunoyama', 
		'津南町地域振興課' => '/tunan/kanko', 
		'津南町観光協会' => '/tunan/kyoukai', 
		'上越市観光企画課' => '/joetsu/kanko', 
		'上越観光コンベンション協会' => '/joetsu/convention', 
		'（社）上越市観光コンベンション協会' => '/joetsu/convention', 
		'安塚観光協会' => '/joetsu/yasuzuka-kyoukai', 
		'柿崎観光協会' => '/joetsu/kakizaki-kyoukai', 
		'大潟観光協会' => '/joetsu/ogata-kyoukai', 
		'吉川観光協会' => '/joetsu/yoshi-kyoukai', 
		'中郷観光協会' => '/joetsu/nakago-kyoukai', 
		'名立観光協会' => '/joetsu/nadachikyoukai', 
		'妙高市観光商工課' => '/myoko/kanko', 
		'妙高市観光協会' => '/myoko/kyoukai', 
		'糸魚川市商工観光課' => '/itoigawa/kanko', 
		'糸魚川市能生事務所' => '/itoigawa/nouoffice', 
		'糸魚川市青海事務所' => '/itoigawa/oumioffice', 
		'糸魚川市観光協会' => '/itoigawa/kyoukai', 
		'能生町観光協会' => '/itoigawa/nou-kyoukai', 
		'青海町観光協会' => '/itoigawa/oumi-kyoukai', 
		'佐渡市観光課' => '/sado/kanko', 
		'佐渡観光協会' => '/sado/kyoukai', 
		'（社）佐渡観光協会' => '/sado/kyoukai'
);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_search_detail.inc');
$objSchDtl = new tbl_search_detail($objCnc);

//csvファイルupload先
define("CSV_UPLOAD", "./tmp/");
//csvファイル最大行
define("G_CSV_MAX_LINE", 50000);

//---引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError("インポートをするcsvファイルを指定してください。", 2, "javascript:history.back()");
	exit();
}
//---ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError("csvファイルのファイルサイズが0バイトです。", 2, "javascript:history.back()");
	exit();
}

//---アップロード
$frmCsvFnm = CSV_UPLOAD . $frmCsvFnm;
if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $frmCsvFnm) == FALSE) {
	DispError("csvファイルのアップロードに失敗しました。", 2, "javascript:history.back()");
	exit();
}

//ファイルを開く
if (!($CsvFno = fopen($frmCsvFnm, 'r'))) {
	//エラーページの表示
	DispError("csvファイルのオープンに失敗しました。", 2, "javascript:history.back()");
	exit();
}
$buf = SJIStoUTF8(file_get_contents($frmCsvFnm));
$CsvFno = tmpfile();
fwrite($CsvFno, $buf);
rewind($CsvFno);

//１～２行目は飛ばす
$data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE);
//EOFになるまで読み出し
$readData = array();
$err_msg = "";
while ($data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
	$readData[] = $data;
}
//ファイルClose
fclose($CsvFno);
//ファイルを削除
if (unlink($frmCsvFnm) == FALSE) {
	//エラーページの表示
	DispError("csvファイルの削除に失敗しました。", 2, "");
	exit();
}

$cnt = 0;
$ExpCavData = "";
$ExpCavData = implode(",", $colum2) . "\n";

//	対応するディレクトリチェック
/*	$errAry = array();
foreach ($readData as $no=>$line) {
	$no = $no + 3;
	if(!isset($max)){
		$max = count($line)-1;
	}
	$deptName = $line[$max];
	$id = $line[$max-1];
	if($id == ""){
		$id = "A".sprintf("%04d",$cnt);
		$cnt++;
	}
	$cateKey = array_search("cate_1st",$colum2);
	if(!isset($dect_ary[$deptName])){
		if(!isset($errAry[$deptName])){
			$errAry[$deptName] = "　対応するディレクトリが見つかりませんでした。【".$deptName."】";
		}
	}
}	
foreach ($errAry as $mes) {
	echo $mes."<br>";
}
exit;*/

foreach ($readData as $no => $line) {
	$imgCnt = 1;
	$isExist = FALSE;
	$no = $no + 3;
	if (!isset($max)) {
		$max = count($line) - 1;
	}
	$deptName = $line[$max - 1];
	$img_id = $line[$max - 2];
	$id = $line[$max];
	if ($id == "") {
		$id = "A" . sprintf("%04d", $cnt);
		$cnt++;
	}
	$cateKey = array_search("cate_1st", $colum2);
	if (!isset($dect_ary[$deptName])) {
		continue;
	}
	$dept_dir = $dect_ary[$deptName];
	foreach ($cateInfo as $key => $cate) {
		if (in_array($line[$cateKey], $cate["category"])) {
			$template_id = $key;
			break;
		}
	}
	if (!isset($template_id)) user_error($no . "行目：テンプレートIDが見つかりませんでした。");
	$cate_dir = $cateInfo[$template_id]["dir"];
	foreach ($line as $key => $data) {
		if ($key > $max - 3) continue;
		if ($key > 0) $ExpCavData .= ",";
		if (!isset($colum2[$key])) {
			user_error($no . "行目：存在しない【" . var_dump($line) . "】");
		}
		switch ($colum2[$key]) {
			// image
			case "img_name1" :
			case "img_name2" :
			case "img_name3" :
			case "img_name4" :
				if ($isExist == FALSE && file_exists(DOCUMENT_ROOT . RPW . "/_test/images/" . $img_id . ".jpg")) {
					$path = $dept_dir . $cate_dir . "/images/" . $img_id . ".jpg";
					$ExpCavData .= csvWrite($path);
					mkNewDirectory(DOCUMENT_ROOT . RPW . "/_test/convKanko" . $path);
					@copy(DOCUMENT_ROOT . RPW . "/_test/images/" . $img_id . ".jpg", DOCUMENT_ROOT . RPW . "/_test/convKanko" . $path);
					
					mkNewDirectory(DOCUMENT_ROOT . RPW . "/_test/convKanko" . FTP_ROOT_DIR . KANKO_THUMBNAIL_DIR . "/dummy.txt");
					if (file_exists(DOCUMENT_ROOT . RPW . "/_test/thumb/" . $img_id . ".jpg")) {
						@copy(DOCUMENT_ROOT . RPW . "/_test/thumb/" . $img_id . ".jpg", DOCUMENT_ROOT . RPW . "/_test/convKanko" . FTP_ROOT_DIR . KANKO_THUMBNAIL_DIR . "/" . $img_id . ".jpg");
					}
					$isExist = TRUE;
				}
				else if (file_exists(DOCUMENT_ROOT . RPW . "/_test/images/" . $img_id . "_" . $imgCnt . ".jpg")) {
					$path = $dept_dir . $cate_dir . "/images/" . $img_id . "_" . $imgCnt . ".jpg";
					$ExpCavData .= csvWrite($path);
					mkNewDirectory(DOCUMENT_ROOT . RPW . "/_test/convKanko" . $path);
					@copy(DOCUMENT_ROOT . RPW . "/_test/images/" . $img_id . "_" . $imgCnt . ".jpg", DOCUMENT_ROOT . RPW . "/_test/convKanko" . $path);
					mkNewDirectory(DOCUMENT_ROOT . RPW . "/_test/convKanko" . FTP_ROOT_DIR . KANKO_THUMBNAIL_DIR . "/dummy.txt");
					if (file_exists(DOCUMENT_ROOT . RPW . "/_test/thumb/" . $img_id . "_" . $imgCnt . ".jpg")) {
						@copy(DOCUMENT_ROOT . RPW . "/_test/thumb/" . $img_id . "_" . $imgCnt . ".jpg", DOCUMENT_ROOT . RPW . "/_test/convKanko" . FTP_ROOT_DIR . KANKO_THUMBNAIL_DIR . "/" . $img_id . "_" . $imgCnt . ".jpg");
					}
					$imgCnt++;
				}
				else {
					$ExpCavData .= csvWrite("");
				}
				break;
			default :
				$ExpCavData .= csvWrite($data);
				break;
		}
	}
	// mail_name
	$mailKey = array_search("mail", $colum2);
	if ($line[$mailKey] != "") {
		$ExpCavData .= "," . csvWrite($line[$mailKey]);
	}
	else {
		$ExpCavData .= "," . csvWrite("");
	}
	// url_name
	$urlKey = array_search("url", $colum2);
	if ($line[$urlKey] != "") {
		$ExpCavData .= "," . csvWrite($line[$urlKey]);
	}
	else {
		$ExpCavData .= "," . csvWrite("");
	}
	// inquiry_mail_name
	$inquiryMailKey = array_search("inquiry_mail", $colum2);
	if ($line[$inquiryMailKey] != "") {
		$ExpCavData .= "," . csvWrite($line[$inquiryMailKey]);
	}
	else {
		$ExpCavData .= "," . csvWrite("");
	}
	// template_id
	$ExpCavData .= "," . csvWrite($template_id);
	// cms_dir
	$ExpCavData .= "," . csvWrite($dept_dir . $cate_dir . "/" . $id . ".html");
	$ExpCavData .= "\n";
}

/*---一覧画面へと戻る---*/
header("Content-Disposition: attachment; filename=kankoCsv.csv");
header('Content-type: text/comma-separated-values');

print mb_convert_encoding($ExpCavData, "sjis", "utf-8");

?>