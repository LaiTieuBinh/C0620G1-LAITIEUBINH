<?php
/**
 * ユーザIDの変更用プログラム(確認画面)
 */

// 設定ファイル
require ('../../admin/.htsetting');

global $objCnc;
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$obj_page = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_contents_group.inc');
$obj_contents_group = new tbl_contents_group($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$obj_dac = new dac($objCnc);

// HTML出力情報 
// タイトル
$title_html = 'ユーザIDの変更用プログラム';
$title_image = '<img src="./images/bar_change_userid.jpg" alt="ユーザID変更プログラム" width="920" height="30" />';

// エラーメッセージ格納用変数
$error_msg = '';

// 対象ページ情報格納用配列
$tbl_page_data_ary = array(
	PUBLISH_TABLE	=>	array(),
	WORK_TABLE		=>	array()
);

// 対象ページID格納用配列
$target_page_id_ary = array(
	PUBLISH_TABLE	=>	array(),
	WORK_TABLE		=>	array()
);

// 処理対象外ページID格納用配列
$not_target_page_id_ary = array();

// POST値チェック
// 変更前ユーザIDが存在していることを確認
if (!isset($_POST['def_user_id']) || $_POST['def_user_id'] == '') {
	$error_msg = '変更前ウェブマスターユーザIDを入力して下さい。';
}
// 変更後ユーザIDが存在していることを確認
else if (!isset($_POST['aft_user_id']) || $_POST['aft_user_id'] == '') {
	$error_msg = '変更後ウェブマスターユーザIDを入力して下さい。';
}
// 変更前ユーザID半角数値チェック
else if (!preg_match('/^[0-9]+$/', $_POST['def_user_id'])) {
	$error_msg = '変更前ウェブマスターユーザIDは半角数値で入力して下さい。';
}
// 変更後ユーザID半角数値チェック
else if (!preg_match('/^[0-9]+$/', $_POST['aft_user_id'])) {
	$error_msg = '変更後ウェブマスターユーザIDは半角数値で入力して下さい。';
}
// 処理除外対象ページIDが存在する場合、半角数値チェック
else if (isset($_POST['not_target_page_id_ary']) && $_POST['not_target_page_id_ary'] != '') {
	if (!preg_match('/^[0-9\,]+$/', $_POST['aft_user_id'])) {
		$error_msg = '本処理対象外ページIDは半角数値および半角カンマで入力して下さい。';
	}
	else {
		//　渡ってきた値をtrimし、カンマ区切り分ける
		$not_target_page_id_ary = explode(',', trim($_POST['not_target_page_id_ary']));
	}
}
// 変更前と変更後のユーザID同値チェック
else if ($_POST['def_user_id'] == $_POST['aft_user_id']) {
	$error_msg = 'ウェブマスターユーザIDは変更前と変更後で異なる値を入力して下さい。';
}

// エラーメッセージが空の場合、以下を処理
if ($error_msg == '') {
	// ユーザID存在チェック
	$select_userid_sql = 'SELECT COUNT(user_id) AS cnt FROM tbl_user';
	$select_userid_sql .= ' WHERE ' . $obj_dac->_addslashesC('user_id', $_POST['def_user_id'] . ',' . $_POST['aft_user_id'], 'IN', 'INT');
	$select_userid_sql .= ' AND ' . $obj_dac->_addslashesC('class', USER_CLASS_WEBMASTER, '=', 'INT');
	
	$obj_dac->execute($select_userid_sql);
	
	if (!$obj_dac->fetch() || $obj_dac->fld['cnt'] != 2) {
		$error_msg = '入力されたユーザIDは存在していないもしくは、ウェブマスター権限ではない可能性があります。';
	}
	
	// 公開責任者チェック
	$select_userid_pub_sql  = 'SELECT COUNT(item1) AS cnt FROM tbl_handler';
	$select_userid_pub_sql  .= ' WHERE ' . $obj_dac->_addslashesC('item1', $_POST['def_user_id'] . ',' . $_POST['aft_user_id'], 'IN', 'INT');
	$select_userid_pub_sql  .= ' AND ' . $obj_dac->_addslashesC('class', HANDLER_CLASS_OEPN_FLG, '=', 'INT');
	
	$obj_dac->execute($select_userid_pub_sql);
	
	if (!$obj_dac->fetch() || $obj_dac->fld['cnt'] != 0) {
		$error_msg = '入力されたユーザIDは公開責任者権限の可能性があります。';
	}
}

// エラーメッセージが空の場合、以下を処理
if ($error_msg == '') {
	// 承認依頼存在チェック
	$where = $obj_contents_group->_addslashesC('user_id', $_POST['def_user_id'], '=', 'INT');
	$obj_contents_group->setTableName('tbl_contents_group');
	$obj_contents_group->select($where);
	if ($obj_contents_group->getRowCount() != 0) {
		$error_msg = '承認依頼に対象情報があります。';
	}
}

// エラーメッセージが空の場合、以下を処理
if ($error_msg == '') {
	// 変更前ユーザの所持ページの存在チェック
	foreach ($tbl_page_data_ary as $tbl_page_data_key => $tbl_page_data_val) {
		$obj_page->setTableName($tbl_page_data_key);
		$where = $obj_page->_addslashesC('user_id', $_POST['def_user_id'], '=', 'INT');
		$obj_page->select($where);
		
		while ($obj_page->fetch()) {
			// 処理対象外ページIDでなければ、対象ページ情報格納用配列に格納
			if (!in_array($obj_page->fld['page_id'], $not_target_page_id_ary)) {
				$tbl_page_data_ary[$tbl_page_data_key][$obj_page->fld['page_id']] = $obj_page->fld;
				$target_page_id_ary[$tbl_page_data_key][] = $obj_page->fld['page_id'];
			}
		}
	}	
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?php echo($title_html); ?></title>
<link rel="stylesheet" href="<?php echo(RPW);?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="<?php echo(RPW);?>/admin/style/outerimport.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?php echo(RPW);?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?php echo(RPW);?>/admin/js/library/scriptaculous.js" type="text/javascript"></script>
<script src="<?php echo(RPW);?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?php echo(RPW);?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cx_Submit(){
	if(window.confirm('ページの所有変更を行います。\nよろしいですか？')){
		$('form').submit();
		return false;
	}
}
//-->
</script>
</head>
<body id="cms8341-mainbg">
<div id="cms8341-contents">
<div align="center" id="cms8341-change_userid">
<div><?php echo($title_image);?></div>
<div class="cms8341-area-corner">
<?php
// エラーメッセージが存在する場合、エラーメッセージ表示
if ($error_msg != '') {
	echo('<p>エラーメッセージ</p>');
	echo('<br />' . "\n");
	echo('<p>' . $error_msg . '</p>');
	echo('<br />' . "\n");
	echo('<div align="center">');
	echo('<a href="javascript:history.back();">');
	echo('<img src="./images/btn_back.jpg" width="150" height="20"alt="戻る" border="0" style="margin: 10px">');
	echo('</a>');
	echo('</div>');
}
// エラーメッセージが存在しない場合、変更対象のページ情報等表示
else {
?>
<form id="form" name="change_userid_form" action="./execute_change_userid.php" method="post">
<input type="hidden" value="<?php echo($_POST['def_user_id']); ?>" name="def_user_id" id="def_user_id">
<input type="hidden" value="<?php echo($_POST['aft_user_id']); ?>" name="aft_user_id" id="aft_user_id">
<input type="hidden" value="<?php echo(implode(',', $not_target_page_id_ary)); ?>" name="not_target_page_id_ary" id="not_target_page_id_ary">
<div align="center">
<p>ページ所有変更のリカバリプログラムを実行する場合は、以下の実行ボタンを押下して下さい。</p>
<?php
if (count($target_page_id_ary[PUBLISH_TABLE]) < 1 && count($target_page_id_ary[WORK_TABLE]) < 1) {
	echo ('<p>※対象のページが存在しないため、実行することができません。</p>' . "\n");
}
else {
	echo ('<a href="javascript:void(0)" onClick="return cx_Submit()">' . "\n");
	echo ('<img src="./images/btn_execution.jpg" width="150" height="20" alt="実行する" border="0" style="margin: 10px"></a>' . "\n");
}
?>
<a href="javascript:history.back();">
<img src="./images/btn_back.jpg" width="150" height="20" alt="戻る" border="0" style="margin: 10px"></a>
</div>
</form>
<br />
<br />
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
<caption>変更前、変更後ウェブマスターユーザID</caption>
<tr>
<th>変更前ウェブマスターユーザID</th>
<th>変更後ウェブマスターユーザID</th>
</tr>
<tr>
<td><?php echo($_POST['def_user_id']); ?></td>
<td><?php echo($_POST['aft_user_id']); ?></td>
</tr>
</table>
<br />
<br />
<?php
	echo ('<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">' . "\n");
	echo ('<caption>変更対象ページ情報リスト</caption>' . "\n");
	echo ('<tr>' . "\n");
	echo ('<th>ページID</th>' . "\n");
	echo ('<th>タイトル</th>' . "\n");
	echo ('<th>ファイルパス</th>' . "\n");
	echo ('<th>PUB / WORK</th>' . "\n");
	echo ('</tr>' . "\n");

	// 対象ページ情報格納用配列分以下ループ処理
	foreach ($tbl_page_data_ary as $tbl_page_data_key => $tbl_page_data_val) {
		$pub_or_work = 'PUB';
		if ($tbl_page_data_key != PUBLISH_TABLE) {
			$pub_or_work = 'WORK';
		}
		
		if (count($tbl_page_data_val) < 1) {
			echo ('<tr>' . "\n");
			echo ('<td colspan="3">対象ページ情報がありません。</td>' . "\n");
			echo ('<td>' . $pub_or_work . '</td>' . "\n");
			echo ('</tr>' . "\n");
		}
		else {
			foreach ($tbl_page_data_val as $tbl_page_id => $tbl_page_data) {
				if (isset($tbl_page_data['page_id']) && isset($tbl_page_data['page_title']) && isset($tbl_page_data['file_path'])) {
					echo ('<tr>' . "\n");
					echo ('<td>' . $tbl_page_data['page_id'] . '</td>' . "\n");
					echo ('<td>' . $tbl_page_data['page_title'] . '</td>' . "\n");
					echo ('<td>' . $tbl_page_data['file_path'] . '</td>' . "\n");
					echo ('<td>' . $pub_or_work . '</td>' . "\n");
					echo ('</tr>' . "\n");
				}
			}
		}
	}
	echo ('</table>' . "\n");
}	
?>
</div>
<div>
<img src="<?php echo(RPW);?>/admin/images/area920_bottom.jpg" alt=""width="920" height="10">
</div>
</div>
</div>
</body>
</html>