<?php
/**
 * ユーザIDの変更用プログラム(実行画面)
 */

// 設定ファイル
require ('../../admin/.htsetting');

global $objCnc;
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$obj_page = new tbl_page($objCnc);

// HTML出力情報
// タイトル
$title_html = 'ユーザIDの変更用プログラム';
$title_image = '<img src="./images/bar_change_userid.jpg" alt="ユーザID変更プログラム" width="920" height="30" />';

// エラーメッセージ格納用変数
$error_msg = '';

// リカバリ対象テーブル配列
$target_table_array = array(
	PUBLISH_TABLE	=>	'tbl_publish_page',
	WORK_TABLE		=>	'tbl_work_page'
);

// 対象ページID格納用配列
$target_page_id_ary = array(
	PUBLISH_TABLE	=>	array(),
	WORK_TABLE		=>	array()
);

// 処理対象ページ格納用変数
$target_page_id = '';

// 処理対象外ページID格納用配列
$not_target_page_id_ary = array();

// POST値チェック
// 変更前ユーザIDが存在していることを確認
if (!isset($_POST['def_user_id']) || $_POST['def_user_id'] == '') {
	$error_msg = '変更前ウェブマスターユーザIDを入力して下さい。';
}
// 変更後ユーザIDが存在していることを確認
else if (!isset($_POST['aft_user_id']) || $_POST['aft_user_id'] == '') {
	$error_msg = '変更後ウェブマスターユーザIDを入力して下さい。';
}
// 変更前ユーザID半角数値チェック
else if (!preg_match('/^[0-9]+$/', $_POST['def_user_id'])) {
	$error_msg = '変更前ウェブマスターユーザIDは半角数値で入力して下さい。';
}
// 変更後ユーザID半角数値チェック
else if (!preg_match('/^[0-9]+$/', $_POST['aft_user_id'])) {
	$error_msg = '変更後ウェブマスターユーザIDは半角数値で入力して下さい。';
}
// 処理除外対象ページIDが存在する場合、半角数値チェック
else if (isset($_POST['not_target_page_id_ary']) && $_POST['not_target_page_id_ary'] != '') {
	if (!preg_match('/^[0-9\,]+$/', $_POST['aft_user_id'])) {
		$error_msg = '本処理対象外ページIDは半角数値および半角カンマで入力して下さい。';
	}
	else {
		//　渡ってきた値をtrimし、カンマ区切り分ける
		$not_target_page_id_ary = explode(',', trim($_POST['not_target_page_id_ary']));
	}
}
// 変更前と変更後のユーザID同値チェック
else if ($_POST['def_user_id'] == $_POST['aft_user_id']) {
	$error_msg = 'ウェブマスターユーザIDは変更前と変更後で異なる値を入力して下さい。';
}

// コネクション開始
$objCnc->begin();

// 対象テーブル分、以下、ページ所有者変更
foreach ($target_table_array as $target_table_key => $target_table_name) {
	// 変更対象ページID取得
	$obj_page->setTableName($target_table_key);
	$where = $obj_page->_addslashesC('user_id', $_POST['def_user_id'], '=', 'INT');
	$obj_page->select($where);
	
	while ($obj_page->fetch()) {
		// 処理対象外ページIDでなければ、対象ページ情報格納用配列に格納
		if (!in_array($obj_page->fld['page_id'], $not_target_page_id_ary)) {
			// リカバリ対象ページID格納
			$target_page_id_ary[$target_table_key][] = $obj_page->fld['page_id'];
		}
	}
	
	// リカバリ実行
	$tbl_update_sql = 'UPDATE ' . $target_table_name . ' SET user_id = ' . $_POST['aft_user_id'];
	$tbl_update_sql .= ' WHERE user_id = ' . $_POST['def_user_id'];
	if (count($target_page_id_ary[$target_table_key]) > 0) {
		$tbl_update_sql .= ' AND page_id IN (' . implode(',', $target_page_id_ary[$target_table_key]) . ')';
	}
	if (!$obj_page->execute($tbl_update_sql)) {
		$error_msg = 'ページ所有者変更に失敗しました。[対象テーブル名：' . $target_table_name . ']';
		break;
	}
}

// エラーメッセージが空ではない場合、ロールバック
if ($error_msg != '') {
	// ロールバック
	$objCnc->rollback();
}
else {
	// コミット
	$objCnc->commit();
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?php echo($title_html); ?></title>
<link rel="stylesheet" href="<?php echo(RPW);?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="<?php echo(RPW);?>/admin/style/outerimport.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?php echo(RPW);?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?php echo (RPW);?>/admin/js/library/scriptaculous.js" type="text/javascript"></script>
<script src="<?php echo (RPW);?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?php echo (RPW);?>/admin/js/common_action.js" type="text/javascript"></script>
</head>
<body id="cms8341-mainbg">
<div id="cms8341-contents">
<div align="center" id="cms8341-change_userid">
<div><?php echo ($title_image);?></div>
<div class="cms8341-area-corner">
<?php
	// エラーメッセージが空ではない場合
	if ($error_msg != '') {
		echo ('<p>エラーメッセージ</p>' . "\n");
		echo ('<br />' . "\n");
		echo ('<p>' . $error_msg . '</p>' . "\n");
		echo ('<br />' . "\n");
		echo ('<div align="center">' . "\n");
		echo ('<a href="javascript:history.back();">' . "\n");
		echo ('<img src="./images/btn_back.jpg" width="150" height="20"alt="戻る" border="0" style="margin: 10px">' . "\n");
		echo ('</a>' . "\n");
		echo ('</div>' . "\n");
	}
	else 
	{
		echo ('<p>ページ所有変更リカバリが完了しました。</p>' . "\n");
		echo ('<div align="center">' . "\n");
		echo ('<a href="#" onClick="window.close(); return false;">' . "\n");
		echo ('<img src="./images/btn_shuts.jpg" width="100" height="20"alt="閉じる" border="0" style="margin: 10px">' . "\n");
		echo ('</a>' . "\n");
		echo ('</div>' . "\n");
	}
?>
</div>
<div>
<img src="<?php echo (RPW);?>/admin/images/area920_bottom.jpg" alt=""width="920" height="10">
</div>
</div>
</div>
</body>
</html>