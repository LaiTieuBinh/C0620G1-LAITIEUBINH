<?php
/**
 * ユーザIDの変更用プログラム(入力画面)
 */

// 設定ファイル
require ('../../admin/.htsetting');

global $objCnc;
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$obj_page = new tbl_page($objCnc);

// HTML出力情報 
// タイトル
$title_html = 'ユーザIDの変更用プログラム';
$title_image = '<img src="./images/bar_change_userid.jpg" alt="ユーザID変更プログラム" width="920" height="30" />';

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?php echo($title_html); ?></title>
<link rel="stylesheet" href="<?php echo(RPW);?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="<?php echo(RPW);?>/admin/style/outerimport.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?php echo(RPW);?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?php echo(RPW);?>/admin/js/library/scriptaculous.js" type="text/javascript"></script>
<script src="<?php echo(RPW);?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?php echo(RPW);?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--

/**
 * 設定ボタンを押した時のフォーム内チェック処理
 */
function cx_Submit(){
	// エラーメッセージ格納用変数
	var error_msg = '';
	// 各フォームのvalue値を取得
	var def_user_id = $('def_user_id').value;
	var aft_user_id = $('aft_user_id').value;
	var not_target_page_id = $('not_target_page_id_ary').value;

	// 必須チェック
	if (def_user_id == '') {
		error_msg = '変更前ウェブマスターユーザIDを入力して下さい。';
	}
	else if (aft_user_id == '') {
		error_msg = '変更後ウェブマスターユーザIDを入力して下さい。';
	}
	// 半角チェック
	else if (def_user_id.match(/[^0-9]+/)) {
		error_msg = '変更前ウェブマスターユーザIDは半角数値で入力して下さい。';
	}
	else if (aft_user_id.match(/[^0-9]+/)) {
		error_msg = '変更後ウェブマスターユーザIDは半角数値で入力して下さい。';
	}
	else if (not_target_page_id.match(/[^0-9\,]+/)) {
		error_msg = '本処理対象外ページIDは半角数値および半角カンマで入力して下さい。';
	}
	// 変更前と変更後のユーザID同値チェック
	else if (def_user_id == aft_user_id) {
		error_msg = 'ウェブマスターユーザIDは変更前と変更後で異なる値を入力して下さい。';
	}

	// エラーメッセージ内が存在した場合、アラート表示
	if (error_msg != '') {
		alert(error_msg);
		return false;
	}
	// エラーメッセージ内が存在しない場合、submit処理
	else {
		$('form').submit();
		return false;
	}
}

//-->
</script>
</head>
<body id="cms8341-mainbg">
<div id="cms8341-contents">
<div align="center" id="cms8341-change_userid">
<div><?php echo($title_image);?></div>
<div class="cms8341-area-corner">
<form id="form" name="change_userid_form" action="./confirm_change_userid.php" method="post">
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
<tr>
<th>変更前ウェブマスターユーザID</th>
<td><input type="text" value="" name="def_user_id" id="def_user_id" maxlength="10"></td>
</tr>
<tr>
<th>変更後ウェブマスターユーザID</th>
<td><input type="text" value="" name="aft_user_id" id="aft_user_id" maxlength="10"></td>
</tr>
<tr>
<th>
本処理対象外ページID
<br />
★カンマ区切りで複数指定可能★
</th>
<td><input type="text" value="" name="not_target_page_id_ary" id="not_target_page_id_ary" maxlength="255" size="80"></td>
</tr>
</table>
<div align="center">
<a href="javascript:void(0)" onClick="return cx_Submit()">
<img src="./images/btn_conf.jpg" width="150" height="20"alt="確認する" border="0" style="margin: 10px">
</a>
</div>
</form>
</div>
<div>
<img src="<?php echo(RPW);?>/admin/images/area920_bottom.jpg" alt=""width="920" height="10">
</div>
</div>
</div>
</body>
</html>
