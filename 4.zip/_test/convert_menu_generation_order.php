<?php
/*
 *
 * $Rev: 539 $
 * $Date: 2010-02-03 10:43:51 +0900 (水, 03 2 2010) $
 * $Author: kawarazaki $
 */
?>
<?php

require ("../admin/.htsetting");

//DB
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage->setTableName(PUBLISH_TABLE);

//変数
$data_ary = array();

//トラン
$objCnc->begin();
//一旦すべてNULLにする
$sql = 'UPDATE tbl_publish_page SET menu_generation_order = NULL';
if ($objPage->execute($sql) === FALSE) {
	$objCnc->rollback();
	DispError("公開ページの更新に失敗しました。", 2, "javascript:history.back()");
	exit();
}
$objPage->select('', 'page_id,parent_id,ancestor_path,menu_generation_order', 'page_id');
while ($objPage->fetch()) {
	$fld = $objPage->fld;
	if (!Isset($fld['ancestor_path']) || $fld['ancestor_path'] == "") $key = 0;
	else $key = count(explode(',', $fld['ancestor_path']));
	$data_ary[$key][] = array(
			'page_id' => $fld['page_id'], 
			'parent_id' => $fld['parent_id']
	);
}
ksort($data_ary);
foreach ($data_ary as $ary) {
	foreach ($ary as $val) {
		$upd_ary = array(
				'page_id' => $val['page_id'], 
				'menu_generation_order' => $objPage->getNextMenuGenerationOrder($val['parent_id'])
		);
		if ($upd_ary['menu_generation_order'] === FALSE || $objPage->update($upd_ary) === FALSE) {
			$objCnc->rollback();
			DispError("公開ページの更新に失敗しました。", 2, "javascript:history.back()");
			exit();
		}
	}
}
//公開ページ情報のメニュー生成順を編集ページ情報にコピーする
$sql = 'UPDATE tbl_work_page AS w INNER JOIN tbl_publish_page AS p ON w.page_id = p.page_id SET w.menu_generation_order = p.menu_generation_order';
if ($objPage->execute($sql) === FALSE) {
	$objCnc->rollback();
	DispError("編集ページの更新に失敗しました。", 2, "javascript:history.back()");
	exit();
}
//コミット
$objCnc->commit();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>メニュー生成順更新完了</title>
</head>
<body>
<p>更新完了しました。</p>
</body>
</html>