<?php
/*
 *
 */
require ("../admin/.htsetting");

$objCnc->begin();

// page
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
$objCate2 = new tbl_category($objCnc);
$objCate->select("", "*", "cate_code");
while ($objCate->fetch()) {
	$cateFld = $objCate->fld;
	$cate_code = $cateFld['cate_code'];
	$level = $cateFld['level'];
	$name = $cateFld['name'];
	$target_cate_code = substr($cate_code, 0, $level * CODE_DIGIT_DEPT) . "%";
	$where = $objCate2->_addslashesC("cate_code", $target_cate_code, "LIKE");
	$where .= " AND " . $objCate2->_addslashesC("level", $level + 1);
	$objCate2->select($where);
	if ($objCate2->getRowCount() > 0) continue;
	$insAry = array();
	if ($level == 4) {
		$target_cate_code = substr($cate_code, 0, 3 * CODE_DIGIT_DEPT) . "%";
		$where = $objCate2->_addslashesC("cate_code", $target_cate_code, "LIKE");
		$where .= " AND " . $objCate2->_addslashesC("level", 3);
		$objCate2->select($where);
		if ($objCate2->getRowCount() == 0) continue;
		$objCate2->fetch();
		$insAry['name'] = $objCate2->fld['name'] . "＞" . $name . "メニュー";
	}
	else {
		$insAry['name'] = $name . "メニュー";
	}
	$insAry['cate_code'] = $cate_code;
	$insAry['link_target'] = AUTOLINK_CONDITION_PAGE;
	$insAry['rss_flg'] = FLAG_OFF;
	$insAry['use_group'] = "0,1,2";
	insertAutolink($insAry);
}

//	$objCnc->rollback();
$objCnc->commit();

?>