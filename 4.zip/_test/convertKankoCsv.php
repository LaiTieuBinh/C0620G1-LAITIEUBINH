<?php
/*
 *
 */
/*--- 設定ファイル読み込み ---*/
require ("../admin/.htsetting");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>観光CSVファイル作成</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="department.css" type="text/css">
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<div align="center" id="cms8341-department">
<div class="cms8341-area-corner">
<div align="center">
<table border="0" cellspacing="0" cellpadding="5">
	<tr>
		<td>
		<p align="left">変換対象のCSVファイルを指定してください。</p>
		<p align="left">
		
		
		<form method="POST" class="cms8341-form"
			action="./convertKankoCsvExec.php" enctype="multipart/form-data"><input
			name="FrmCsvnm" type="file" style="width: 540px">
		</p>
		
		</td>
	</tr>
</table>
</div>
<p align="center"><input type="image"
	src="../admin/master/images/btn_start.jpg" alt="取り込み開始" width="150"
	height="20" border="0" style="margin-right: 10px"> <a
	href="./index.php"><img src="../admin/images/btn/btn_cansel_large.jpg"
	alt="キャンセル" width="150" height="20" border="0"
	style="margin-left: 10px"></a></p>
</form>
</div>
</div>
</body>
</html>
