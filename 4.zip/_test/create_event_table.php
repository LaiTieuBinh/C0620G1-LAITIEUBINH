<?php
/*
 * eventテーブル作るよ（´Д｀）
 */
require ("../admin/.htsetting");

// 引数取得
$go = (isset($_GET['go']) ? TRUE : FALSE);

// DB
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac  = new dac($objCnc);
$objDac2 = new dac($objCnc);

// チェック配列
$event_table_arys = array(
	'tbl_publish_event',
	'tbl_work_event'
);

//CreateのSQLの元
$create_table = "
CREATE TABLE IF NOT EXISTS #TABLE_NAME# (
 `page_id` int(11) NOT NULL,
 `no` int(11) NOT NULL,
 `open_start` datetime DEFAULT NULL,
 `open_end` datetime DEFAULT NULL,
 PRIMARY KEY (`page_id`,`no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
";

$tblAry = array();
$sql = "SHOW TABLES FROM " . SET_DBNAME;
if ($objDac->execute($sql)) {
	while ($objDac->fetch()) {
		$table_in_key = '';
		foreach($objDac->fld as $key => $vale){
			$table_in_key = $key;
			break;
		}
		$tblAry[] = $objDac->fld[$table_in_key];
	}
}
$table_cnt=0;
foreach( $event_table_arys as $table_value ) {
	if( in_array($table_value, $tblAry) ) {
		echo $table_value . '->○<br />';
		$table_cnt++;
	}
	else {
		echo $table_value . '->×<br />';
		if ($go) {
			//SQLの実行
			//テーブルが無いからCreateを実行
			$create_sql = str_replace('#TABLE_NAME#', $table_value, $create_table);
			$objDac2->execute($create_sql);
		}
	}
}

?>