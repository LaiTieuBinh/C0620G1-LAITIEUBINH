<?php
/*
 *
 */
require ("../admin/.htsetting");

$dept_ary = array(
		'/ken/kyoukai' => '116', 
		'/ken/kanko' => '119', 
		'/awashima/kanko' => '120', 
		'/awashima/kyoukai' => '121', 
		'/murakami/kanko' => '122', 
		'/murakami/kyoukai' => '123', 
		'/murakami/asahikyoukai' => '124', 
		'/sekikawa/kanko' => '125', 
		'/sekikawa/kyoukai' => '126', 
		'/tainai/kanko' => '127', 
		'/shibata/kanko' => '128', 
		'/shibata/machikyoukai' => '129', 
		'/shibata/tsukioka' => '130', 
		'/shibata/shiunji' => '131', 
		'/seiro/kanko' => '132', 
		'/seiro/kyoukai' => '133', 
		'/agano/kanko' => '134', 
		'/agano/kyoukai' => '135', 
		'/niigata-city/kanko' => '136', 
		'/niigata-city/kitaku' => '137', 
		'/niigata-city/higashiku' => '138', 
		'/niigata-city/tyuoku' => '139', 
		'/niigata-city/kounanku' => '140', 
		'/niigata-city/akihaku' => '141', 
		'/niigata-city/minamiku' => '142', 
		'/niigata-city/nishiku' => '143', 
		'/niigata-city/nishikanku' => '144', 
		'/niigata-city/convention' => '145', 
		'/niigata-city/niitsukyoukai' => '146', 
		'/niigata-city/minami-kyoukai' => '147', 
		'/niigata-city/toyosaka21' => '148', 
		'/niigata-city/iwamuro' => '149', 
		'/niigata-city/makikyoukai' => '150', 
		'/gosen/kanko' => '151', 
		'/gosen/sakihana' => '153', 
		'/gosen/muramatsu' => '154', 
		'/aga/kanko_kyoukai' => '', 
		'/tagami/kanko' => '159', 
		'/tagami/kyoukai' => '160', 
		'/kamo/kanko' => '161', 
		'/kamo/kyoukai' => '162', 
		'/sangyo/kanko' => '163', 
		'/sangyo/kyoukai' => '164', 
		'/sangyo/shitada' => '165', 
		'/tsubame/kanko' => '166', 
		'/tsubame/tsubame-kyoukai' => '167', 
		'/tsubame/bunsui-kyoukai' => '168', 
		'/yahiko/kanko' => '169', 
		'/yahiko/kyoukai' => '170', 
		'/mitsuke/kanko' => '171', 
		'/mitsuke/kyoukai' => '172', 
		'/nagaoka/kanko' => '173', 
		'/nagaoka/convention' => '174', 
		'/nagaoka/koshiji-kanko' => '175', 
		'/nagaoka/koshiji-kyoukai' => '176', 
		'/nagaoka/tochio-kyoukai' => '177', 
		'/nagaoka/yoita-kyoukai' => '178', 
		'/nagaoka/nakanoshima-kyoukai' => '179', 
		'/nagaoka/washima-kyoukai' => '180', 
		'/nagaoka/tera-kyoukai' => '181', 
		'/nagaoka/yamakoshi-kyoukai' => '182', 
		'/izumozaki/kanko' => '183', 
		'/izumozaki/kyoukai' => '186', 
		'/kariwa/kanko' => '187', 
		'/kashiwazaki/kanko' => '188', 
		'/kashiwazaki/takayanagi' => '190', 
		'/kashiwazaki/nishiyama' => '191', 
		'/ojiya/kanko' => '192', 
		'/ojiya/kyoukai' => '193', 
		'/kawaguchi/kanko' => '194', 
		'/kawaguchi/kyoukai' => '195', 
		'/uonuma/kanko' => '196', 
		'/uonuma/kyoukai' => '197', 
		'/minamiuonuma/kanko' => '198', 
		'/minamiuonuma/kyoukai' => '199', 
		'/yuzawa/kanko' => '200', 
		'/yuzawa/kyoukai' => '201', 
		'/tokamachi/kanko' => '202', 
		'/tokamachi/kyoukai' => '207', 
		'/tokamachi/kawanishi' => '203', 
		'/tokamachi/nakasato' => '204', 
		'/tokamachi/matsudai' => '205', 
		'/tokamachi/matsunoyama' => '206', 
		'/tunan/kanko' => '208', 
		'/tunan/kyoukai' => '209', 
		'/joetsu/kanko' => '210', 
		'/joetsu/convention' => '211', 
		'/joetsu/yasuzuka-kyoukai' => '212', 
		'/joetsu/kakizaki-kyoukai' => '213', 
		'/joetsu/ogata-kyoukai' => '214', 
		'/joetsu/yoshi-kyoukai' => '215', 
		'/joetsu/nakago-kyoukai' => '216', 
		'/joetsu/nadachikyoukai' => '217', 
		'/myoko/kanko' => '218', 
		'/myoko/kyoukai' => '219', 
		'/itoigawa/kanko' => '220', 
		'/itoigawa/nouoffice' => '221', 
		'/itoigawa/oumioffice' => '222', 
		'/itoigawa/kyoukai' => '223', 
		'/itoigawa/nou-kyoukai' => '224', 
		'/itoigawa/oumi-kyoukai' => '225', 
		'/sado/kanko' => '226', 
		'/sado/kyoukai' => '227'
);

$cnt = 0;
$objCnc->begin();
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

$where = $objPage->_addslashesC("template_kind", TEMPLATE_KIND_FIXED);
foreach (array(
		PUBLISH_TABLE, 
		WORK_TABLE
) as $tbl) {
	$objPage->setTableName($tbl);
	$objPage->select($where);
	while ($objPage->fetch()) {
		$fld = $objPage->fld;
		$file_path = $fld['file_path'];
		foreach ($dept_ary as $deptDir => $user_id) {
			$p = strpos($file_path, $deptDir);
			if ($p !== FALSE && $p == 0) {
				$change_user = $user_id;
				break;
			}
		}
		if (!isset($change_user)) continue;
		$objPageTran = new tbl_page($objCnc);
		$uAry = array();
		$uAry['page_id'] = $fld['page_id'];
		$uAry['user_id'] = $change_user;
		$objPageTran->update($uAry, $tbl);
		unset($change_user);
		$cnt++;
	}

}
$objCnc->commit();
//    $objCnc->rollback();


echo $cnt . "件更新";
?>