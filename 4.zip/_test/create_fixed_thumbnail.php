<?php
	/**
	 * 定型のサムネイル画像を再生成する
	 */

	// 外部ファイルの読み込み
	require ("../admin/.htsetting");
	require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
	$obj_dac = new dac($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
	$obj_page = new tbl_page($objCnc);
	
	// 変数の宣言
	$sql = '';
	$items = array();
	$create_thumbnail_item = array();
	
	// 定型を使用しているテンプレートの抽出
	$sql = 'SELECT template_id, MAX(template_ver) AS template_ver, template_kind, kanko_xml FROM tbl_template WHERE kanko_xml IS NOT NULL AND kanko_xml <> \'\' GROUP BY template_id';
	$obj_dac->execute($sql);
	
	// 定型項目の中からサムネイル指定されている項目を抽出
	while ($obj_dac->fetch()) {
		// 定型項目の取得
		$items = getItem($obj_dac->fld['template_id'], '', 'edit');
		
		// 定型項目の数分ループ
		foreach ($items as $item) {
			$fixed_id = $item['id'];
			if (!isset($item['ctrl']) || $item['ctrl'] == '') {
				continue;
			}
			foreach ($item['ctrl'] as $ctrl) {
				// 定型項目が画像の場合
				if ($ctrl['type'] == 'image') {
					//サムネイルの有無
					$thumbnail_flg = getFixedItemValue($items, $fixed_id, 'thumbnail');
					if ($thumbnail_flg !== FALSE && $thumbnail_flg == FLAG_ON) {
						$create_thumbnail_item[$obj_dac->fld['template_id']] = $fixed_id;
						break 2;
					}
				}
			}
		}
	}
	
	// 定型項目が設定されているページを抽出
	$where_pk = '';
	$where_wk = '';
	foreach ($create_thumbnail_item AS $template_id => $fixed_id) {
		// 公開
		if ($where_pk != '') {
			$where_pk .= ' OR ';
		}
		$where_pk .= '(';
		$where_pk .= $obj_page->_addslashesC('p.template_id', $template_id);
		$where_pk .= ' AND ' . $obj_page->_addslashesC('k.item', $fixed_id);
		$where_pk .= ')';
		
		// 編集
		if ($where_wk != '') {
			$where_wk .= ' OR ';
		}
		$where_wk .= '(';
		$where_wk .= $obj_page->_addslashesC('p.template_id', $template_id);
		$where_wk .= ' AND ' . $obj_page->_addslashesC('wk.item', $fixed_id);
		$where_wk .= ')';
	}
	$sql = 'SELECT '
		 . 'p.page_id, p.template_id, p.work_class, p.status, p.close_flg, p.output_html_flg, k.item, k.context, wk.item AS wk_item, wk.context AS wk_context'
		 . ' FROM tbl_publish_page AS p LEFT JOIN tbl_publish_kanko AS k ON (p.page_id = k.page_id) LEFT JOIN tbl_work_kanko AS wk ON (p.page_id = wk.page_id AND (k.item IS NULL OR wk.item IS NULL OR k.item = wk.item))'
		 . ' WHERE ((' . $where_pk . ') AND k.type = \'image\') OR ((' . $where_wk . ') AND wk.type = \'image\')';
	$obj_page->execute($sql);
	
	// FTPを接続する
	if (FTP_UPLOAD_FLG) {
		$ftp_cnc = connectFTP("cms");
	}
	
	// 定型ページの数分ループ
	while ($obj_page->fetch()) {
		$page_fld = $obj_page->fld;
		try {
			// 画像URLの取得（公開側の情報で作成）
			$context = $page_fld['context'];
			$pos = strpos($context, KANKO_LINK_DELIMITER);
			$url = substr($context, 0, $pos);
			if ($url == '') {
				throw new Exception('Error');
			}
			// サムネイルの作成
			if (!createFixedThumbnail($page_fld['page_id'], DOCUMENT_ROOT . RPW . $url)) {
				user_error('サムネイル画像の作成に失敗しました。【' . $page_fld['page_id'] . '】', E_USER_ERROR);
				throw new Exception('Error');
			}
			// ページが公開されている場合
			if ($page_fld['work_class'] != WORK_CLASS_NEW && $page_fld['close_flg'] == FLAG_OFF && $page_fld['output_html_flg'] == FLAG_ON) {
				// サムネイル画像の削除
				if (syncThumbnail(2, $page_fld, $ftp_cnc) === FALSE) {
					// エラー処理
					user_error('サムネイル削除処理に失敗しました。【' . $page_fld['page_id'] . '】', E_USER_ERROR);
					throw new Exception('Error');
				}
				// サムネイル画像の公開
				if (syncThumbnail(1, $page_fld, $ftp_cnc) === FALSE) {
					// エラー処理
					user_error('サムネイル更新処理に失敗しました。【' . $page_fld['page_id'] . '】', E_USER_ERROR);
					throw new Exception('Error');
				}
			}
		} catch (Exception $e) {}
		// 画像URLの取得（編集側の情報で作成）
		if ($page_fld['wk_context'] != NULL) {
			$context = $page_fld['wk_context'];
			$pos = strpos($context, KANKO_LINK_DELIMITER);
			$url = substr($context, 0, $pos);
			if ($url == '') {
				continue;
			}
			// サムネイルの作成
			if (!createFixedThumbnail($page_fld['page_id'], DOCUMENT_ROOT . RPW . $url)) {
				user_error('サムネイル画像の作成に失敗しました。【' . $page_fld['page_id'] . '】', E_USER_ERROR);
				continue;
			}
		}
	}
	// FTPを切断する
	if (FTP_UPLOAD_FLG) {
		cx_ftp_close($ftp_cnc);
	}
	
	// 成功
	echo "サムネイル作成完了";
?>
