function GetSelectedElement() {
    var ele = CKEDITOR.currentInstance.getSelection().getSelectedElement();
    if (ele == null)
        return null;
    var C = ele.$;
    if (C.nodeType != 1)
        return null;
    return C;
}
;

function MoveToAncestorNode(A) {
    var oEditorWin = CKEDITOR.currentInstance.window.$;
    if (typeof oEditorWin.document.selection != "undefined") {
        var B = oEditorWin.document.selection.createRange();
        var C = B.parentElement();
        while (C && C.nodeName != A)
            C = C.parentNode;
        return C;
    } else { //FF and GC
        var B = CKEDITOR.currentInstance.document.getSelection().getRanges(0)[0];
        var C;
        if (B.startContainer != B.endContainer || B.startContainer.$.nodeType != 1 || B.startOffset != B.endOffset - 1) {
            C = null;
        } else {
            if (B.startContainer.$.childNodes[B.startOffset] != undefined) {
                C = B.startContainer.$.childNodes[B.startOffset];
                if (C.$.nodeType != 1) {
                    C = null;
                }
            }
        }
        if (!C)
            C = B.startContainer;
        while (C) {
            if (C.$.nodeName.Equals(A))
                return C.$;

            C = C.getParent();
        }
        return null;
    }
}

function getInnerHTML(A) {
    // if element is a html comment
    if (A.nodeType == 8) {
        return "<!--" + A.textContent + "-->";
    }
    if (A.innerHTML == "&nbsp;" || A.innerHTML == 'undefined') {
        return "";
    }
    return A.innerHTML.replace('<br type="_moz">', "");
}

function getCells(A) {
    var B = "";
    for (var i = 0; i < A.childNodes.length; i++) {
        B += getInnerHTML(A.childNodes[i])
    }
    return B;
}

function getRows(A) {
    var B = "";
    for (var i = 0; i < A.childNodes.length; i++) {
        B += getCells(A.childNodes[i], B);
    }
    return B;
}

function getNonTableHTML(A) {
    switch (A.tagName) {
        case "CAPTION":
            return '<p>' + getInnerHTML(A) + '</p>';
            break;
        case "THEAD":
        case "TBODY":
        case "TFOOT":
            return getRows(A);
            break;
        case "TR":
            return getCells(A);
            break;
        case "TH":
            return getInnerHTML(A);
            break;
        case "TD":
            return getInnerHTML(A);
            break;
        default:
            return "";
            break;
    }
}


CKEDITOR.plugins.add('gd_table_deletelayout', {
    icons: "gd_table_deletelayout",
    lang: 'ja,en',
    requires: 'contextmenu',
    init: function (editor) {
        editor.addCommand('gd_table_deletelayout', {
            exec: function (b) {

                var a = b.elementPath().contains("table", 1);

                if (a) {
                    var A = GetSelectedElement();
                    if (!A || A.tagName != 'TABLE')
                        A = MoveToAncestorNode("TABLE");
                    var output = "";
                    var B = A.childNodes;
                    for (var i = 0; i < B.length; i++) {
                        output += getNonTableHTML(B[i], output);
                    }
                    A.outerHTML = output;
                }
            }
        });


        editor.addMenuItems && editor.addMenuItems({
            tablelayout: {
                label: editor.lang.gd_table_deletelayout.contextbutton,
                command: "gd_table_deletelayout",
                group: "table",
                order: 1
            }
        });

        editor.contextMenu.addListener(function (element) {
            if (element.getAscendant('table', true)) {
                return {
                    tablelayout: CKEDITOR.TRISTATE_OFF
                };
            }
        });


//         Do not making sense - but will leave commented - Sergei  17/10/2017
//        if (!window.parent.IKOU_MODE) {
//            editor.contextMenu && editor.contextMenu.addListener(function () {
//                return {
//                    tablelayout: CKEDITOR.TRISTATE_OFF
//                }
//            })
//        }
    }
});
