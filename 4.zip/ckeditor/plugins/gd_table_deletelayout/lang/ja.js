CKEDITOR.plugins.setLang('gd_table_deletelayout', 'ja', {
    contextbutton: 'レイアウトテーブル解除'
});
