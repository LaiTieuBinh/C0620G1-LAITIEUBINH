CKEDITOR.plugins.setLang('gd_table_deletelayout', 'en', {
    contextbutton: 'Delete Table Layout'
});
