CKEDITOR.plugins.setLang('gd_image', 'en', {
    button: "Image",
    title: "Image",
});
