CKEDITOR.plugins.setLang('gd_image', 'ja', {
    button: "画像設定",
    title: "画像設定",
});
