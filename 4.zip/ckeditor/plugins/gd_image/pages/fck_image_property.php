<?php
/**
 * 画像プロパティ
 */
// -- 設定ファイル -- //
require (".htsetting");

// -- エラー画面設定 -- //
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

// -- インクルード -- //
global $objCnc;
global $objLogin;

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);

// -- 初期化 -- //


$submitFlg = FLAG_OFF;

// GET値取得


// ID
$id = (isset($_GET['id'])) ? $_GET['id'] : "";

// POST値がある場合
if (isset($_POST['cms_fck_image_id']) && isset($_POST['cms_fck_image_name'])) {
	// ID 代入
	$id = $_POST['cms_fck_image_id'];
	// 登録するID
	$updAry['id'] = $id;
	// ファイル名称
	$updAry['name'] = $_POST['cms_fck_image_name'];
	// 更新日 -> 現在日付
	$updAry['update_datetime'] = "NOW";
	// プロパティ登録処理
	$objCnc->begin();
	if ($objFCKImages->update($updAry) === FALSE) {
		// エラー
		$objCnc->rollback();
		user_error("ファイル情報の設定に失敗しました。ファイル情報が削除された可能性があります。", E_USER_ERROR);
	}
	$objCnc->commit();
	$submitFlg = FLAG_ON;
}

// 検索
if ($objFCKImages->selectFCKImageID($id) !== FALSE) {
	$property = $objFCKImages->fld;
}
else {
	// エラー
	user_error("ファイル情報の取得に失敗しました。ファイル情報が削除された可能性があります。", E_USER_ERROR);
}

// 編集権限
$writeFlg = FLAG_ON;
if (strpos($property['path'], FCK_IMAGES_FORDER_SHARED . "/") !== FALSE && $objLogin->get('class') != USER_CLASS_WEBMASTER) $writeFlg = FLAG_OFF;

// -- HTML 出力 -- //
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Expires" content="Thu, 01 Dec 1994 16:00:00 GMT">
<title>画像プロパティ</title>
<link rel="stylesheet" href="<?=RPW?>/ckeditor/gd_files/css/dialog.css" type="text/css">
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script
	src="js/fck_image_property.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script type="text/javascript">
	<!--
		// CMS内 定数
		<?php
		echo loadSettingVars();
		?>
		// 決定フラグ
		var submitFlg = <?=$submitFlg?>;
		// 戻値
		var retObj = new Object();
		retObj["id"]              = "<?=$property['id']?>";
		retObj["name"]            = "<?=htmlspecialchars(javaStringEscape($property['name']))?>";
		retObj["update_datetime"] = '<?=dtFormat($property['update_datetime'], "Y年m月d日 H時i分s秒")?>';

		// ディスプレイの画面サイズ
		var SCREEN_WIDTH = screen.width;
		var SCREEN_HEIGHT = screen.height;

		// ダイアログサイズ
		var windowSizeX = 495;	// 
		var windowSizeY = 360;	// 

		// ウィンドウサイズ変更
		window.dialogWidth  = windowSizeX + "px";
		window.dialogHeight = windowSizeY + "px";

		// ウィンドウ位置調整(スクリーンの中心)
		window.dialogLeft = (SCREEN_WIDTH)/2 - (windowSizeX/2);
		window.dialogTop = (SCREEN_HEIGHT)/2 - (windowSizeY/2);

	// -->
</script>
<base target="_self" />
</head>
<body>
<div class="cke_dialog_title">画像プロパティ<a href="javascript:cxIframeLayerCallback()" id="header_close" style="float: right; margin-top: 2px;"><img src="<?=RPW?>/ckeditor/skins/moono-lisa/images/close.png" alt="閉じる"></a></div>
<form name="cms_fck_image_property" id="cms_fck_image_property" action="fck_image_property.php?id=<?=$property['id']?>" method="post" onsubmit="return cxSubmit()">
		<fieldset><legend></legend>
	<input type="hidden" name="cms_fck_image_id" id="cms_fck_image_id" value="<?=$property['id']?>">
	<table border="0" cellspacing="0" cellpadding="5" width="100%">

	
	<tr>										
	<td width="30%">

	<label class="cke_dialog_ui_labeled_label" for="cms_fck_image_name">画像名称</label></td>
	<td width="70%">
		<?php
		if ($writeFlg == FLAG_ON) {
			echo '<input type="text" name="cms_fck_image_name" id="cms_fck_image_name" class="cke_dialog_ui_input_text" value="' . htmlspecialchars($property['name']) . '" style="width:200px;" maxlength="64">';
		}
		else {
			echo htmlDisplay($property['name']);
		}
		?>
	</td>
	</tr>
	<tr>
		<td width="30%"><label class="cke_dialog_ui_labeled_label" for="cms_fck_image_path">ファイルパス</label></td>
		<td width="70%"><?=htmlDisplay($property['path'])?></td>
	</tr>
	<tr>
		<td width="30%"><label class="cke_dialog_ui_labeled_label" for="cms_fck_image_regist">登録日</label></td>
		<td width="70%"><?=htmlDisplay(dtFormat($property['regist_datetime'], "Y年m月d日 H時i分s秒"))?></td>
	</tr>
	<tr>
		<td width="30%"><label class="cke_dialog_ui_labeled_label" for="cms_fck_image_update">更新日</label></td>
		<td width="70%"><?=htmlDisplay(dtFormat($property['update_datetime'], "Y年m月d日 H時i分s秒"))?>	</td>
												
	</tr>
	<?php
		if ($writeFlg == FLAG_ON) {
			echo '<tr><td></td><td style="float: right;">';
			echo '<a href="javascript:void(0)" onClick="return cxSubmit()" class="cke_dialog_ui_button cke_dialog_ui_button_grey cke_dialog_ui_button_padding" tabindex ="1">設定</a>&nbsp;&nbsp;';
			echo '<a onClick="cxIframeLayerCallback();"  class="cke_dialog_ui_button" id="header_close">キャンセル</a>';
			echo '</td><tr>';
		}
	?>
		
</table>
	</fieldset>	
</form>	

													


<?php
echo $objTool->setAccessibility();
?>
	</body>
</html>
