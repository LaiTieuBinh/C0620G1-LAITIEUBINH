<?php
/*
 * 画像編集フォルダ削除PHP
 */
// -- 共通設定ファイル ----------------------------------------------------------- //
require (".htsetting");
// -- 読み込み -- //
require_once (dirname(__FILE__) . '/fck_image_controll.inc');

if (isset($_POST['edit_id'])) {
	
	$editID = $_POST['edit_id'];
	
	// 編集に使用したファイル、フォルダを削除
	tempfolder_delete($objLogin->get('user_id'), $editID);
}

/**
 * 画像編集に使用した フォルダの削除
 *
 *【引数】
 *	string	$originalfilename	画像編集元画像ファイルパス
 *	string	$user_id			ユーザーID
 *	string	$edit_id			編集ID(ユーザーIDの下に作成されるフォルダ名)
 *
 *【戻値】
 *	TRUE
 *
 *【備考】
 *	画像編集に使用したフォルダを削除し、ユーザーIDフォルダ内が空であれば
 *	ユーザーIDフォルダも削除する
 *
 */
function tempfolder_delete($user_id, $edit_id) {
	
	// ユーザーIDフォルダのパス
	$userdir = DOCUMENT_ROOT . DIR_PATH_UPLOAD . "/temp/" . $user_id;
	// ユーザーIDフォルダ存在フラグ
	$dirFlg = FLAG_OFF;
	
	// -- 画像編集に使用したフォルダの削除 -- //
	if (@is_dir($userdir . "/" . $edit_id)) {
		removeDir($userdir . "/" . $edit_id);
	}
	
	// -- ユーザーIDフォルダ削除 -- //
	if (is_dir($userdir)) {
		// ユーザーIDフォルダのオープン
		if ($handle = opendir($userdir)) {
			// ファイル取得
			while (FALSE !== ($file = readdir($handle))) {
				if ($file == "." || $file == "..") continue;
				// 取得できればフラグON
				$dirFlg = FLAG_ON;
				break;
			}
			// ユーザーIDフォルダのクローズ
			closedir($handle);
		}
		
		// ユーザーIDフォルダ削除
		if ($dirFlg == FLAG_OFF) removeDir($userdir);
	
	}
	return TRUE;
}

?>
