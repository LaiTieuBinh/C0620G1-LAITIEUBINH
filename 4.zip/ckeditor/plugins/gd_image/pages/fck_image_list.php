<?php
/*
 * 画像のリスト表示を行なう
 */
// -- 共通設定ファイル -- //
require (".htsetting");

// -- エラー画面設定 -- //
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

// -- インクルード -- //
global $objCnc;
global $objLogin;
require_once (APPLICATION_ROOT . "/common/dbcontrol/commands.inc");
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/page_control.inc');
$objP = new page_control();
require_once (APPLICATION_ROOT . '/common/dbcontrol/b_dac.inc');

// ページ内定数
define("FCK_IMAGE_CATE_NOW", 0); // 分類条件用(現在の場所)
define("FCK_IMAGE_CATE_SHARED", 1); // 分類条件用(共通画像)
$MAXROW_LIST = getDefineArray("MAXROW_LIST"); //1ページに表示される最大表示件数配列


// CMSで使用するPOSTのプレフィックス
define("CMS_POST", "cms_fck_image_");

// リスト表示時の画像の縦横幅
define("FCK_IMAGE_LIST_WIDTH", "64");
define("FCK_IMAGE_LIST_HEIGHT", "64");

//変数の宣言
$page = 0; //ページ番号
$maxRow = 0; //1ページに表示される最大表示件数


// 検索条件配列
$search = array(
		"category" => FCK_IMAGE_CATE_NOW, 
		"keyword" => "", 
		"path" => "", 
		"update_datetime" => FLAG_OFF, 
		//検索条件ではなく、画像の表示・非表示フラグだが、他のものと取り扱いが同じためここに記載
		"thumbnail_flg" => FLAG_OFF
);

// POST値取得
foreach ($_POST as $k => $v) {
	if (substr($k, 0, strlen(CMS_POST)) != CMS_POST) continue;
	$k = str_replace(CMS_POST, "", $k);
	$search[$k] = $v;
}
$page = (isset($_POST['cms_page']) && is_numeric($_POST['cms_page']) ? floor($_POST['cms_page']) : 1);
$maxRow = (isset($_POST['maxrow']) && is_numeric($_POST['maxrow']) ? floor($_POST['maxrow']) : key($MAXROW_LIST));

// SESSION取得
$search['path'] = "";
// SESSIONを取得できる場合
if (isset($_SESSION['cms_page_id'])) {
	// 作業テーブルよりパス取得
	if ($objPage->selectFromID($_SESSION['cms_page_id'], WORK_TABLE, "file_path") !== FALSE) {
		$search['path'] = cms_dirname($objPage->fld['file_path']);
	}
	// 公開テーブルよりパス取得
	else if ($objPage->selectFromID($_SESSION['cms_page_id'], PUBLISH_TABLE, "dir_path") !== FALSE) {
		$search['path'] = ($objPage->fld['dir_path'] == "/" ? "" : $objPage->fld['dir_path']);
	}
	//ページ情報を取得できない場合、エラー
	else {
		user_error("ページ情報の取得に失敗しました。", E_USER_ERROR);
	}
}

// -- 検索条件作成 -- //
$where = "";

// 分類
$search_path = "";
switch ($search['category']) {
	// 現在の場所
	case FCK_IMAGE_CATE_NOW :
		//現在の場所のパス
		if (isset($_SESSION['cms_page_id'])) {
			$search_path = $search['path'] . FCK_IMAGES_FORDER;
		}
		else {
			$search_path = FCK_IMAGES_FORDER_LIBRARY;
		}
		$search_path = str_replace('//', '/', $search_path);
		break;
	// 共通画像
	case FCK_IMAGE_CATE_SHARED :
		$search_path = FCK_IMAGES_FORDER_SHARED;
		$search_path = str_replace('//', '/', $search_path);
		break;
}
$where .= " AND " . $objFCKImages->_addslashesC("path", $search_path . "/%", "LIKE");

// キーワード --
// 文字列が存在すれば検索条件セット
if (strlen($search['keyword']) > 0) {
	$keyword = explode(" ", str_replace("　", " ", $search['keyword']));
	foreach ($keyword as $k => $v) {
		if (strlen($v) > 0) {
			$v = javaStringEscape($v);
			$where .= ' AND (' . $objFCKImages->_addslashesC("name", "%" . $v . "%", "LIKE");
			$where .= ' OR ' . $objFCKImages->_addslashesC("path", "%" . $v . "%", "LIKE") . ")";
		}
	}
}

// 条件文に付加されている最初の AND を除去
$where = preg_replace("/^( AND )+/i", "", $where);

//一時検索
$objFCKImages->select($objFCKImages->_addslashesC("path", $search_path . "/%", "LIKE"), "*");
//検索結果全件抽出
$flds = array();
while ($objFCKImages->fetch()) {
	if (!@file_exists(DOCUMENT_ROOT . RPW . $objFCKImages->fld['path'])) {
		$objFCKImages_tmp = new tbl_fck_images($objCnc);
		//トランザクション処理
		$objCnc->begin();
		//削除処理
		if ($objFCKImages_tmp->deleteFromImageID($objFCKImages->fld['id']) === FALSE) {
			//エラー
			$objCnc->rollback();
			user_error("データの更新処理に失敗しました。", E_USER_ERROR);
		}
		//コミット
		$objCnc->commit();
		$objFCKImages_tmp = null;
	}
	else
		$flds[] = $objFCKImages->fld;
}

//フォルダ内の全てのファイルを読み込む
$real_file_path = array();
$dirList = array(
		DOCUMENT_ROOT . RPW . $search_path
);
//取り込み可能拡張子の取得
$exp_ary = explode(",", ALLOWED_EXTENSIONS_IMAGE);
foreach ((array) $exp_ary as $key => $val) {
	$exp_ary[$key] = "." . $val;
}
//フォルダの一覧を取得
$dirList = cxGetDirList(DOCUMENT_ROOT . RPW . $search_path, $dirList);
//フォルダ数分ループ
foreach ((array) $dirList as $dir) {
	$dir = str_replace(DOCUMENT_ROOT . RPW, "", $dir);
	//フォルダ内にあるファイル一覧を取得
	$fileList = array();
	$fileList = cxGetFileList(DOCUMENT_ROOT . RPW . $dir, $fileList, implode(",", $exp_ary));
	//ファイル数分ループ
	foreach ((array) $fileList as $file) {
		//一覧に表示するためファイル名を保持
		$real_file_path[] = $dir . '/' . substr($file, (strrpos($file, '/') + 1));
	}
}

//DBに情報の無いファイルの情報を登録する
//実ファイル分ループ
foreach ((array) $real_file_path as $num => $file) {
	$no_db_file_path_flg = true; //DB登録済み判定フラグ
	//DBに登録されている数分ループ
	foreach ((array) $flds as $fld) {
		//DBにパスがある場合
		if ($file == $fld['path']) {
			$no_db_file_path_flg = false;
			break;
		}
	}
	//DBに登録されていない場合
	if ($no_db_file_path_flg) {
		//トランザクション処理
		$objCnc->begin();
		//登録処理
		$temp_ary = array(
				'name' => $file, 
				'path' => $file
		);
		if ($objFCKImages->insert($temp_ary) === FALSE) {
			//エラー
			$objCnc->rollback();
			user_error("データの一覧登録処理に失敗しました。", E_USER_ERROR);
		}
		//コミット
		$objCnc->commit();
	}
}

//更新日
if ($search['update_datetime'] == FLAG_ON) $order = "update_datetime ASC";
else $order = "update_datetime DESC";

//ページ管理
$row_cnt = $objFCKImages->getCount($where, $objFCKImages->table_name);
$objP->limit = $maxRow;
$objP->set($page, $row_cnt);
//検索
$objFCKImages->select($where, "*", $order, $objP->getOffset(), $objP->getLimit());
//検索結果全件抽出
$drawHTML = "";
while ($objFCKImages->fetch()) {
	$fld = $objFCKImages->fld;
	// 実ファイルが存在していない場合は表示しない
	if (!@file_exists(DOCUMENT_ROOT . RPW . $fld['path'])) continue;
	
	// 画像サイズの取得
	$size = @getimagesize(DOCUMENT_ROOT . RPW . $fld['path']);
	$witdh = $size[0];
	$height = $size[1];
	// サイズ判定処理
	$isResizeWitdh = ($witdh > FCK_IMAGE_LIST_WIDTH) ? true : false;
	$isResizeHeight = ($height > FCK_IMAGE_LIST_HEIGHT) ? true : false;
	// 縦横ともに指定サイズを超えていた場合
	if ($isResizeWitdh && $isResizeHeight) {
		// 横のサイズの方が大きい場合、縦を横に合わせる
		if ($witdh > $height) {
			$witdhDisp = FCK_IMAGE_LIST_WIDTH;
			$heightDisp = $height / ($witdh / FCK_IMAGE_LIST_WIDTH);
			// 縦のサイズの方が大きい場合、横を縦にあわせる
		}
		else {
			$witdhDisp = $witdh / ($height / FCK_IMAGE_LIST_HEIGHT);
			$heightDisp = FCK_IMAGE_LIST_HEIGHT;
		}
		// 縦のサイズが指定のサイズを超えていた場合、横を縦にあわせる
	}
	else if (!$isResizeWitdh && $isResizeHeight) {
		$witdhDisp = $witdh / ($height / FCK_IMAGE_LIST_HEIGHT);
		$heightDisp = FCK_IMAGE_LIST_HEIGHT;
		// 横のサイズが指定のサイズを超えていた場合、縦を横に合わせる
	}
	else if ($isResizeWitdh && !$isResizeHeight) {
		$witdhDisp = FCK_IMAGE_LIST_WIDTH;
		$heightDisp = $height / ($witdh / FCK_IMAGE_LIST_WIDTH);
		// 縦横どちらも指定サイズを超えていない場合
	}
	else if (!$isResizeWitdh && !$isResizeHeight) {
		$witdhDisp = $witdh;
		$heightDisp = $height;
	}
	
	//削除可能かチェックする
	if (isset($_SESSION['cms_page_id'])) {
		$chk_tbl = array(
				'tbl_work_images', 
				'tbl_publish_images'
		);
		$Delete_Flg = true;
		foreach ($chk_tbl as $tbl) {
			$sql = "SELECT page_id FROM " . $tbl . " WHERE (" . $objImages->_addslashesC('src', $fld['path'], 'LIKE', 'TEXT') . ")";
			$objImages->execute($sql);
			if ($objImages->getRowCount() > 0) $Delete_Flg = false;
		}
	}
	else {
		$Delete_Flg = true;
		$objDac = new b_dac($objCnc, "tbl_library AS l");
		$objDac->add_where("l.library_ver", "(SELECT MAX(library_ver ) FROM tbl_library WHERE library_id = l.library_id)", "=", "JOIN");
		$objDac->add_where('l.context', 'src="' . RPW . $fld['path'] . '[^"]*"', 'REGEXP');
		$objDac->select();
		if ($objDac->getRowCount() > 0) $Delete_Flg = false;
	}
	
	// HTML 作成
	$drawHTML .= '<tr id="cms_image_tr_' . $fld['id'] . '">';
	$drawHTML .= '<td style="margin:0px;padding:5px ">';
	$drawHTML .= '<table border="0" cellspacing="0px" cellpadding="0" margin="0" padding="0" width="100%"style="margin:0px;padding:0px;border-collapse:collapse;">';
	$drawHTML .= '<tr style="margin:0px;padding:0px;">';
	//POSTする値
	$drawHTML .= '<input type="hidden" name="cms_url_' . $fld['id'] . '" id="cms_url_' . $fld['id'] . '" value="' . $fld['path'] . '">';
	$drawHTML .= '<input type="hidden" name="cms_width_' . $fld['id'] . '" id="cms_width_' . $fld['id'] . '" value="' . $witdh . '">';
	$drawHTML .= '<input type="hidden" name="cms_height_' . $fld['id'] . '" id="cms_height_' . $fld['id'] . '" value="' . $height . '">';
	$drawHTML .= '<input type="hidden" name="cms_alt_' . $fld['id'] . '" id="cms_alt_' . $fld['id'] . '" value="' . htmlDisplay($fld['name']) . '">';
	//サムネイルフラグがONの場合
	if ($search['thumbnail_flg'] == FLAG_ON) {
		//左
		$drawHTML .= '<td width="20%" align="center" style="margin:0px;padding:0px;border-right:solid 1px #999999;background-color:#FFFFFF;">';
		//サムネイル画像
		$drawHTML .= '<img src="' . RPW . $fld['path'] . '?rnd=' . rand() . '" width="' . $witdhDisp . '" height="' . $heightDisp . '" alt="' . htmlDisplay($fld['name']) . '" border="0">';
		$drawHTML .= '</td>';
	}
	//中
	$drawHTML .= '<td width="' . ($search['thumbnail_flg'] == FLAG_ON ? "70%" : "90%") . '" height="80px" align="left" style="padding-left: 10px;">';
	$drawHTML .= '<table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" style="margin:0px;padding:0px;border-collapse:collapse;">';
	//ファイル情報
	$drawHTML .= '<tr style="margin:0px;padding:0px;">';
	$drawHTML .= '<td style="margin:0px;padding:0px;padding-left:3px;background-color:#FFFFFF;">';
	$drawHTML .= '<div id="cms_image_name_' . $fld['id'] . '" style="font-weight:bold;font-size:15px;">' . htmlDisplay($fld['name']) . '</div>';
	$drawHTML .= htmlDisplay($fld['path']) . '<br>';
	$drawHTML .= '<div id="cms_image_update_datetime_' . $fld['id'] . '">更新日：' . dtFormat($fld['update_datetime'], "Y年m月d日 H時i分s秒") . '</div>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
	//操作ボタン
	$drawHTML .= '<tr>';
	$drawHTML .= '<td align="left" valign="middle" style="margin:0px;padding:0px;padding-top:3px;">';
	$drawHTML .= '&nbsp;';
	//編集
	if ($search['category'] == FCK_IMAGE_CATE_NOW || $objLogin->get('class') == USER_CLASS_WEBMASTER) {
		$drawHTML .= '<a class="cke_dialog_ui_button cke_dialog_ui_button_padding" href="javascript:void(0)" onclick="cxEdit(' . $fld['id'] . '); return false;">編集</a>';
	}
	else
		$drawHTML .= '<a class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_inactive">編集</a>';
	$drawHTML .= '&nbsp;';
	$drawHTML .= '&nbsp;';
	//削除
	if ($Delete_Flg && ($search['category'] == FCK_IMAGE_CATE_NOW || $objLogin->get('class') == USER_CLASS_WEBMASTER)) {
		$drawHTML .= '<a class="cke_dialog_ui_button cke_dialog_ui_button_padding" href="javascript:void(0)" onclick="cxDeleteImage(' . $fld['id'] . ',\'' . javaStringEscape(htmlDisplay($fld['name'])) . '\'); return false;">削除</a>';
	}
	//削除_OFF
	else
		$drawHTML .= '<a class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_inactive">削除</a>';
	$drawHTML .= '&nbsp;';
	$drawHTML .= '&nbsp;';
	//プロパティ
	$drawHTML .= '<a href="javascript:void(0)"  class="cke_dialog_ui_button"  onclick="cxShowProperty(' . $fld['id'] . '); return false;">プロパティ</a>';
	$drawHTML .= '&nbsp;';
	$drawHTML .= '&nbsp;';
	//プレビュー
	$drawHTML .= '<a href="' . RPW . $fld['path'] . '"  class="cke_dialog_ui_button" target="_blank">プレビュー</a>';
	//画像挿入ボタンの表示
	$drawHTML .= '&nbsp;';
	$drawHTML .= '&nbsp;';
	$drawHTML .= '<a href="javascript:void(0)" style="float: right;" class="cke_dialog_ui_button cke_dialog_ui_button_grey" onclick="cxReturn(' . $fld['id'] . '); return false;">画像挿入</a>';
	$drawHTML .= '&nbsp;';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
	$drawHTML .= '</table>';
	$drawHTML .= '</td>';
	//右
	$drawHTML .= '</tr>';
	$drawHTML .= '</table>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
	$drawHTML .= '<tr>';
	$drawHTML .= '<td>';
	$drawHTML .= '<hr>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
}

// -- HTML 出力 -- //


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ファイルにリンク</title>
<link href="<?=RPW?>/ckeditor/gd_files/css/grid.css" type="text/css" rel="stylesheet">
<link href="<?=RPW?>/ckeditor/gd_files/css/dialog.css" type="text/css" rel="stylesheet">
	<script>
	<?php
	echo loadSettingVars();
	?>
	</script>
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script  src="js/fck_image_list.js"  type="text/javascript"></script>
<script src="js/com_func.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
	var mode = '<?=(isset($_GET['mode']) && $_GET['mode'] == "library" ? "library" : "")?>';
	<?php
	//上書きがあった場合、編集画面に表示されている画像を差し替える
	if (isset($_SESSION["updata_file"]) && count($_SESSION["updata_file"]) > 0) {
		$script = 'var targetArea = CKEDITOR.currentInstance.document.$;' . "\n";
		$script .= 'var img_ary = targetArea.getElementsByTagName(\'img\');' . "\n";
		$script .= 'var updata_ary = [' . "\n";
		foreach ((array) $_SESSION["updata_file"] as $val) {
			$script .= '"' . $val . '",' . "\n";
		}
		$script = substr($script, 0, strrpos($script, ",")) . "\n";
		$script .= ']' . "\n";
		//FCKeditor部分の画像差し替え
		$script .= 'for(var i = 0;i < updata_ary.length;i++){' . "\n";
		$script .= 'for(var j = 0;j < img_ary.length;j++){' . "\n";
		$script .= 'if(updata_ary[i] == img_ary[j].src.substring(img_ary[j].src.indexOf(baseUrl),(img_ary[j].src.indexOf(\'?\') > 0 ? img_ary[j].src.indexOf(\'?\') : img_ary[j].src.length))){' . "\n";
		$rnd = rand();
		$script .= 'cxPreImages(updata_ary[i] + "?rnd=' . $rnd . '");' . "\n";
		$script .= 'img_ary[j].src = updata_ary[i] + "?rnd=' . $rnd . '";' . "\n";
		$script .= '}' . "\n";
		$script .= '}' . "\n";
		$script .= '}' . "\n";
		//編集ページの画像差し替え
		$script .= 'window.dialogArguments = window.frameElement.args; var edit_area = window.dialogArguments.Editor.frames.frameElement.parentElement;' . "\n";
		$script .= 'while(edit_area.tagName.toLowerCase() != "body"){ edit_area = edit_area.parentElement; }' . "\n";
		$script .= 'var img_ary = edit_area.document.body.getElementsByTagName(\'img\');' . "\n";
		$script .= 'for(var i = 0;i < updata_ary.length;i++){' . "\n";
		$script .= 'for(var j = 0;j < img_ary.length;j++){' . "\n";
		$script .= 'if(updata_ary[i] == img_ary[j].src.substring(img_ary[j].src.indexOf(baseUrl),(img_ary[j].src.indexOf(\'?\') > 0 ? img_ary[j].src.indexOf(\'?\') : img_ary[j].src.length))){' . "\n";
		$rnd = rand();
		$script .= 'cxPreImages(updata_ary[i] + "?rnd=' . $rnd . '");' . "\n";
		$script .= 'img_ary[j].src = updata_ary[i] + "?rnd=' . $rnd . '";' . "\n";
		$script .= '}' . "\n";
		$script .= '}' . "\n";
		$script .= '}' . "\n";
		print($script);
		unset($_SESSION["updata_file"]);
	}
	?>

//-->
</script>
<base target="_self" />
</head>
<body class="cke_reset_all">
<div id="cms8341-headareaZero">
		<div id="cms8341-tab" class="cke_dialog_tabs">
		<table border="0" cellspacing="0" cellpadding="0"
			style="border-collapse: collapse;">
			<tr>
				<td><a href="fck_image.php?mode=upload" class="cke_dialog_tab" ><span> PCから選んで登録 </span></a></td>
				<td><a class="cke_dialog_tab cke_dialog_tab_selected" ><span> 登録済画像から選択 </span></a></td>
			</tr>
		</table>
		</div>
<div class="cke_dialog_contents">

 <form name="cms_fck_image_list" id="cms_fck_image_list"  action="fck_image_list.php" method="post">
<fieldset id="search_fieldset">
<legend  style="margin-left: 10px;">検索オプション</legend>
<div class="lay640">
 <div class="size2">
<label class="cke_dialog_ui_labeled_label" for="cms_fck_image_category">ファイル分類</label></div>
<div class="size10 suf3">
<select class="cke_dialog_ui_input_text" name="cms_fck_image_category" id="cms_fck_image_category">
<option value="<?=FCK_IMAGE_CATE_NOW?>"
 <?=(($search['category'] == FCK_IMAGE_CATE_NOW) ? 'selected' : '');?>>現在の場所</option>
<option value="<?=FCK_IMAGE_CATE_SHARED?>"
<?=(($search['category'] == FCK_IMAGE_CATE_SHARED) ? 'selected' : '');?>>共通画像</option>
</select>
</div>
</div>
    
 <div class="lay640">
 <div class="size2">   
<label class="cke_dialog_ui_labeled_label"  for="cms_fck_image_keyword">キーワード</label></div>
<div class="size10 ">
<input type="text" name="cms_fck_image_keyword" id="cms_fck_image_keyword" class="cke_dialog_ui_input_text"
value="<?=htmlspecialchars($search['keyword'])?>">
</div>
<div class="size3 "><a href="javascript:void(0)" class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_grey" onClick="return cxSearch()" style="float: right;"
tabindex="1">検索</a></div>
</div>

<div class="lay640">
 <div class="size2">
<label  class="cke_dialog_ui_labeled_label" for="cms_fck_image_update">表示順</label></div>
<div class="size10 suf3">
<span class="cke_dialog_ui_labeled_label">更新日の</span>&nbsp; 
<input id="upd_asc" type="radio" name="cms_fck_image_update_datetime" value="0" <?=($search['update_datetime'] == FLAG_OFF) ? "checked" : "";?>>
<label for="upd_asc"  class="cke_dialog_ui_labeled_label">降順</label> 
<input id="upd_dsc" type="radio" name="cms_fck_image_update_datetime" value="1" <?=($search['update_datetime'] == FLAG_ON) ? "checked" : "";?>>
<label for="upd_dsc"  class="cke_dialog_ui_labeled_label">昇順</label>
</div>
</div>

<div class="lay640">
 <div class="size2">
<label  class="cke_dialog_ui_labeled_label" for="cms_fck_image_thumbnail">サムネイル</label></div>
<div class="size10 suf3">
<?php
$temp_ary = array(
               '非表示', 
               '表示'
);
print(mkradiobutton($temp_ary, "cms_fck_image_thumbnail_flg", $search['thumbnail_flg'], 0));
?>
</div>
</div>
</fieldset>

						<input type="hidden" name="maxrow" id="search_maxrow"
							value="<?=$maxRow?>"></form>
         <div class="lay640"><div class="pre12 size4">
                                                                                                                 <span><?=mkcombobox($MAXROW_LIST, "dispNum", $maxRow, "cxDispNum(this.value)")?></span>
     </div>
</div>
    
						<fieldset>
						<legend>画像ファイルリスト</legend>
						<table width="100%" border="0" cellspacing="0" cellpadding="0"
							style="margin-top: 0px; margin-bottom: 0px; padding: 1px">
						</table>
						<table width="100%" border="0" cellspacing="0" cellpadding="0"
							align="center">
							<tr>
								<td>
								<div
									style="height: 350px; overflow-y: scroll; overflow-x: hidden;"
									nowrap scope="row">
								<table width="100%" border="0" cellspacing="0" cellpadding="0"
									class="cms8341-dataTable"
									>
																		<?=$drawHTML?>
																	</table>
								</div>
								</td>
							</tr>
						</table>
						</td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
								</fieldset>
		</div>
		<div class="cms8341-area-corner-page-count"
			style="width: 97%; margin-bottom: 5px; text-align: center;"><span
			style="float: left; width: 20%;"><?=$objP->getBackLink();?></span> <span
			style="float: right; width: 20%;"><?=$objP->getNextLink();?></span> <span
			style="width: 60%;"><?=$objP->getViewCount();?></span></div>
		</td>
	</tr>
</table>
</div>
<form name="cms_fck_image_select" id="cms_fck_image_select"
	action="fck_image.php" method="post"><input type="hidden" name="url"
	id="url" value=""> <input type="hidden" name="width" id="width"
	value=""> <input type="hidden" name="height" id="height" value=""> <input
	type="hidden" name="alt" id="alt" value=""></form>
<form name="cms_page_post" id="cms_page_post" method="post" action=""><input
	type="hidden" name="cms_page" value=""> <input type="hidden"
	name="maxrow" id="maxrow" value=""> <input type="hidden"
	name="cms_fck_image_category" id="cms_fck_image_category"
	value="<?=$search['category']?>"> <input type="hidden"
	name="cms_fck_image_keyword" id="cms_fck_image_keyword"
	value="<?=$search['keyword']?>"> <input type="hidden"
	name="cms_fck_image_update_datetime" id="cms_fck_image_update_datetime"
	value="<?=$search['update_datetime']?>"> <input type="hidden"
	name="cms_fck_image_thumbnail_flg" id="cms_fck_image_thumbnail_flg"
	value="<?=$search['thumbnail_flg']?>"></form>
</body>
</html>
