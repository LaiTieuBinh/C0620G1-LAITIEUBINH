<?php
/**
 * 画像プロパティ
 */
//外部ファイル読み込み
require_once (".htsetting");

//DBアクセス用ファイルの読み込み
global $objCnc;
global $objLogin;
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);

//変数の設定
$err_msg = "";
$updAry = array();

//引数の取得
$updAry['id'] = (isset($_POST['cms_fck_image_id']) ? $_POST['cms_fck_image_id'] : ""); //ID
$updAry['name'] = (isset($_POST['cms_fck_image_name']) ? $_POST['cms_fck_image_name'] : ""); //ファイル名称
$updAry['update_datetime'] = "NOW"; //更新日 -> 現在日付
//引数のチェック
if ($updAry['id'] == "" || $updAry['name'] == "") {
	$err_msg = "引数の値が不正です";
}
//引数チェックでエラーがあった場合は、ここで終了する
if ($err_msg != "") {
	print($err_msg);
	exit();
}

//トランザクション処理開始
$objCnc->begin();
//アップデート処理
if (!$objFCKImages->update($updAry)) {
	$objCnc->rollback();
	$err_msg = "ファイル情報の設定に失敗しました";
}
if ($err_msg == "") $objCnc->commit();
else print($err_msg);
exit();
?>
