<?php
/**
 * 画像削除処理
 */
//外部ファイル読み込み
require_once (".htsetting");

//DBアクセス用ファイルの読み込み
global $objCnc;
global $objLogin;
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_shared_upload.inc');
$objShared = new tbl_shared_upload($objCnc);

//変数の設定
$err_msg = "";
$file_path = "";
$image_id = "";

//引数の取得
$image_id = (isset($_POST['cms_image_id']) && $_POST['cms_image_id'] != "" ? $_POST['cms_image_id'] : "");

//引数のチェック
if (!isset($image_id) || $image_id == "") {
	$err_msg = "引数の値が不正です";
}
//引数チェックでエラーがあった場合は、ここで終了する
if ($err_msg != "") {
	print($err_msg);
	exit();
}

//トランザクション処理開始
$objCnc->begin();
//ファイル情報の取得
$objFCKImages->selectFCKImageID($image_id);
$file_path = $objFCKImages->fld['path'];
//削除の実行
if (!$objFCKImages->deleteFromImagePath($file_path)) {
	$objCnc->rollback();
	$err_msg = "ファイルの削除に失敗しました";
}
// handle tbl_shared_upload
if (preg_match('/^(' . reg_replace(FCK_IMAGES_FORDER_SHARED) . '|' . reg_replace(FCK_IMAGES_FORDER_LIBRARY) . ')/i', $file_path)) {
	$err_msg = $objShared->add_data($file_path, $objShared::SHARED_DELETE_DB);
	if ($err_msg != '') {
		$objCnc->rollback();
	}
}
//ファイルの削除
if (@file_exists(DOCUMENT_ROOT . RPW . $file_path) && !@unlink(DOCUMENT_ROOT . RPW . $file_path)) {
	$objCnc->rollback();
	$err_msg = "ファイルの削除に失敗しました";
}
if ($err_msg == "") $objCnc->commit();
else print($err_msg);
exit();
?>
