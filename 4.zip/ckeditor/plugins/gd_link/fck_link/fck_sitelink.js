/*
 *
 */
// 検索処理
function cxSearch() {
	// 検索前チェック
	if (cxSearchCheck() == false) {
		return false;
	}

	// パラメータ作成
	prm = 'cms_search_page_title=' + $F('cms_search_page_title');
	// ページID検索
	prm = prm + '&cms_search_page_id=' + $F('cms_search_page_id');
	prm = prm + '&cms_search_keywords=' + $F('cms_search_keywords');
	prm = prm + '&cms_file_path=' + $F('cms_file_path');
	prm = prm + '&cms_upsy=' + $F('cms_upsy');
	prm = prm + '&cms_upsm=' + $F('cms_upsm');
	prm = prm + '&cms_upsd=' + $F('cms_upsd');
	prm = prm + '&cms_upey=' + $F('cms_upey');
	prm = prm + '&cms_upem=' + $F('cms_upem');
	prm = prm + '&cms_uped=' + $F('cms_uped');
	if ($('cms_department1'))
		prm = prm + '&cms_department1=' + $('cms_department1').value;
	if ($('cms_department2'))
		prm = prm + '&cms_department2=' + $('cms_department2').value;
	if ($('cms_department3'))
		prm = prm + '&cms_department3=' + $('cms_department3').value;
	// 自分で作成したページ／全てのページ
	if ($('cms_target_0').checked == true) {
		prm = prm + '&cms_target=' + $F('cms_target_0');
	} else {
		prm = prm + '&cms_target=' + $F('cms_target_1');
	}
	// 公開中ページ／作業中ページ
	if ($('cms_table_0').checked == true) {
		prm = prm + '&cms_table=' + $F('cms_table_0');
	} else {
		prm = prm + '&cms_table=' + $F('cms_table_1');
	}
	// タグを対象とするかどうか
	if($('cms_is_tag_search_0').checked == true){
		prm = prm + '&cms_is_tag_search=' + $F('cms_is_tag_search_0');
	}
	else{
		prm = prm + '&cms_is_tag_search=' + $F('cms_is_tag_search_1');
	}
	if ($('cms_page_no'))
		prm = prm + '&cms_page_no=' + $F('cms_page_no');
	if ($('cms_disp_num'))
		prm = prm + '&cms_disp_num=' + $F('cms_disp_num');

	cxComboHidden();

	// 検索実行PHPの呼び出し(Ajax)
	var a = new Ajax.Updater(
			'data_area',
			baseUrl + 'ckeditor/plugins/gd_link/fck_link/fck_sitelink_search.php',
			{
				method : 'post',
				postBody : prm,
				// 成功した場合
				onSuccess : function(request) {
					// 検索中レイヤーを閉じる
				cxLayer('cms8341-progress', 0);
				cxComboVisible();
			},
			// 失敗した場合
				onFailure : function(request) {
					alert('検索に失敗しました');
					cxComboVisible();
				}
			});
}

// 検索前チェック
function cxSearchCheck() {
	// 更新日チェック
	isEmptyUps = false;
	isEmptyUpe = false;

	// 更新期間開始：空の場合はtrueをセット
	if ($F('cms_upsy') == "" && $F('cms_upsm') == "" && $F('cms_upsd') == "") {
		isEmptyUps = true;
	}
	// 更新期間終了：空の場合はtrueをセット
	if ($F('cms_upey') == "" && $F('cms_upem') == "" && $F('cms_uped') == "") {
		isEmptyUpe = true;
	}

	// 更新日チェック
	var dc = new Array();
	if (isEmptyUps == false && isEmptyUpe == false) {
		dc = cxDateCheckNew('cms_up', 'ymd', 1, '更新期間');
	} else if (isEmptyUps == false && isEmptyUpe == true) {
		dc = cxDateCheckNew('cms_up', 'ymd', 2, '更新期間');
	} else if (isEmptyUps == true && isEmptyUpe == false) {
		dc = cxDateCheckNew('cms_up', 'ymd', 3, '更新期間');
	}

	var msg = new Array();
	msg = msg.concat(dc);
	// エラー表示
	if (msg.length > 0) {
		$('cms8341-errormsg').innerHTML = msg.join("<br>");
		cxLayer('cms8341-error', 1, 500, 500);
		return false;
	}
	return true;
}

// リンク設定
function cxSetParent(file_path) {
	// 親画面返却用オブジェクトを作成

	var retObj = new Object();
	// URLの加工
	retObj["url"] = file_path;
	// アンカーが選択されていた場合はアンカーも返却
	if (checkAnchor) {
		retObj["anchor"] = checkAnchor;
	}
	// 親画面へ返すオブジェクトをセット
	cxIframeLayerCallback(retObj);
}

// アンカーの状態をセットする
var checkAnchor;
function setAnchor(anchor) {
	checkAnchor = anchor;
	$('cms_anchor_' + anchor).checked = true;
}

//自分の作成したページ／全てのページ切り替え時の処理
function cxChangeTarget() {
	//自分の作成したページにチェックされた場合
	if ($('cms_target_0').checked == true) {
		if (!$('cms_user_class')
				|| $F('cms_user_class') != USER_CLASS_WEBMASTER) {
			$('cms_table_0').disabled = false;
			$('cms_table_label_0').style.color = "#000000";
			$('cms_table_1').disabled = false;
			$('cms_table_label_1').style.color = "#000000";
		}
		if ($('cms_department1'))
			$('cms_department1').disabled = true;
		if ($('cms_department2'))
			$('cms_department2').disabled = true;
		if ($('cms_department3'))
			$('cms_department3').disabled = true;
	}
	//全てのページにチェックされた場合
	if ($('cms_target_1').checked == true) {
		//公開中／作業中ラジオ 選択不能
		if (!$('cms_user_class')
				|| $F('cms_user_class') != USER_CLASS_WEBMASTER) {
			$('cms_table_0').checked = true;
			$('cms_table_0').disabled = true;
			$('cms_table_label_0').style.color = "#CCCCCC";
			$('cms_table_1').disabled = true;
			$('cms_table_label_1').style.color = "#CCCCCC";
		}
		if ($('cms_department1'))
			$('cms_department1').disabled = false;
		if ($('cms_department2'))
			$('cms_department2').disabled = false;
		if ($('cms_department3'))
			$('cms_department3').disabled = false;
	}
	return false;
}

// 組織変更プルダウン処理
function cxChangeDept(lv, val, num) {
	//reset
	if (val == "") {
		var t = lv + 1;
		for ( var i = t; i <= 3; i++) {
			var obj = $('cms_department' + i);
			while (obj.length > 1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "";
		}
	} else {
		//get data
		lv++;
		var prm = 'level=' + lv + '&code=' + val;
		cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
	}
}
function cxGetDeptComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Department') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    for (var i = level; i <= 3; i++) {
        var obj = $('cms_department' + i);
        while (obj.length > 1) {
            obj.options[1] = null;
        }
        if (i == level) {
            obj.options[0].text = "指定なし";
        } else {
            obj.options[0].text = "";
        }
    }
    var obj = $('cms_department' + level);
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i = 0; i < xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        obj.length++;
        obj.options[i + 1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        obj.options[i + 1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}

//通信失敗処理
function cxFailure() {
	alert('情報取得中に通信エラーが発生しました');
}

function cxDispNum(max_val) {
	$('cms_page_no').value = "1";
	cxSearch();
	return false;
}

// page sending
function cxPageSet(page_no) {
	$('cms_page_no').value = page_no;
	cxSearch();
	return false;
}
