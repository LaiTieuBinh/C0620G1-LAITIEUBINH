/*
 * ファイルリンク：画面切り替え処理　fck_filelink_property.js
 */
if (!window.cxIframeLayerCallback) {
	window.cxIframeLayerCallback = window.frameElement.cxIframeLayerCallback;
}

// イメージ読み込み
cxPreImages(cms8341admin_path + '/images/fcklink/title_filelinkset.jpg',
		cms8341admin_path + '/images/fcklink/btn_close.jpg',
		cms8341admin_path + '/images/fcklink/btn_setting.jpg');

// プロパティ設定後閉じる
window.onload = function() {
	//モードが1なら、returnする
	if (submitFlg && submitFlg == 1) {

		// 親画面に値を渡す
		cxIframeLayerCallback(retObj);

	}
}

// 設定ボタン押下後入力チェック、サブミット
function cxSubmit() {

	// ファイル名称チェック
	if ($('cms_filelink_name')) {
		// 必須
		if ($F('cms_filelink_name') == "") {
			alert("ファイル名称を入力してください。");
			$('cms_filelink_name').focus();
			return false;
		}
		// 機種依存
		var info = new Array();
		info = fckCheck('ファイル名称', $F('cms_filelink_name'), info);
		if (!info)
			return false;
		if (info.length > 0) {
			var msg = info.join('\n') + '\nよろしいですか？';
			if (!confirm(msg)) {
				$('cms_filelink_name').focus();
				return false;
			}
		}
	}

	document.cms_fck_link_property.submit();

	return false;

}
