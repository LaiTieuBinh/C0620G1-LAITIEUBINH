<?php
/**
 * ファイルリンク：画面切り替え処理　fck_filelink.php
 */
// -- 共通設定ファイル -- //
require ("../.htsetting");

// -- エラー画面設定 -- //
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

// ロケーションフラグ
$locationFlg = FLAG_OFF;

// 現在のページパス取得(GET値)
$get['path'] = "";
if (isset($_GET['path'])) {
	$get['path'] = $_GET['path'];
}

// URL パラメーター
$get['url'] = "";
if (isset($_GET['url'])) {
	$get['url'] = $_GET['url'];
	$locationFlg = FLAG_ON;
}

// -- GET値作成 -- //
$urlGet = "";
foreach ($get as $k => $v) {
	if (strlen($v) > 0) {
		if (strlen($urlGet) > 0) $urlGet .= "&";
		$urlGet .= $k . "=" . urlencode($v);
	}
}
if (strlen($urlGet) > 0) $urlGet = "?" . $urlGet;

// -- ページ遷移 -- //


if ($locationFlg == FLAG_ON) {
	// FLAG_ON の場合 リスト(検索)ページ
	header('Location: ' . HTTP_ROOT . RPW . '/ckeditor/plugins/gd_link/fck_link/fck_filelink_list.php' . $urlGet);
}
else {
	// FLAG_OFF の場合 アップロードページ
	header('Location: ' . HTTP_ROOT . RPW . '/ckeditor/plugins/gd_link/fck_link/fck_filelink_upload.php' . $urlGet);
}

exit();

?>