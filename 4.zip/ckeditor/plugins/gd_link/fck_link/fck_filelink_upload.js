/*
 * ファイルアップロード処理用javascript
 */
if (!window.cxIframeLayerCallback) {
	window.cxIframeLayerCallback = window.frameElement.cxIframeLayerCallback;
}

//-------------------------------------------------
//	ロード時に実行される
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
window.onload = function() {
	//エラーメッセージがあれば、アラート表示
	if (err_msg)
		alert(err_msg);
	// モードが1なら、returnする
	if (mode && mode == 1)
		cxReturn(ofile);
}

//-------------------------------------------------
// 戻り値を設定し、ウィンドウを閉じる
// 【引数】
// ofile : ファイル情報オブジェクト
// 【戻値】
// なし
// -------------------------------------------------
function cxReturn(ofile) {
	//オブジェクト作成
	var retObj = new Object();

	// 戻り値の設定
	retObj['url'] = ofile['path'];
	retObj['exp'] = ofile['exp'];
	retObj['size'] = ofile['size'];
	cxIframeLayerCallback(retObj);
}

//-------------------------------------------------
// 決定ボタンを押された際の処理
// 【引数】
// now_file_path : 編集中のフォルダパス
// 【戻値】
// false : 処理終了
// -------------------------------------------------
function cxSubmit(now_file_path) {
	var err_msg = '';

	// ファイル名の取得
	new_file_name = $('cms_filelink_path').value
			.slice($('cms_filelink_path').value.lastIndexOf('\\') + 1);
	// チェック用ファイル名取得
	check_file_name = new_file_name;
	// ファイル名を小文字に変換
	new_file_name = new_file_name.toLowerCase();

	// 必須チェック
	if ($F('cms_filelink_name').length <= 0)
		err_msg += "ファイル名称を入力してください。\n";
	if ($('cms_filelink_path').value.length <= 0)
		err_msg += "ファイルを選択してください。\n";
	// ファイル名称チェック
	// 機種依存文字チェック
	var info = new Array();
	info = fckCheck('ファイル名称', $F('cms_filelink_name'), info);
	if (!info)
		return false;
	if (info.length > 0) {
		var msg = info.join('\n') + '\nよろしいですか？';
		if (!confirm(msg)) {
			return false;
			$('cms_filelink_name').focus();
		}
	}
	//ファイルチェック
	// 拡張子チェック
	var File_Exte = DENIED_EXTENSIONS_FILE.split(",");
	for ( var i = 0; i < File_Exte.length; i++) {
		var ExteRegEx = new RegExp("(\\." + File_Exte[i] + ")$");
		var asFileExte = ExteRegEx.exec($('cms_filelink_path').value);
		if (asFileExte != null)
			err_msg += "指定されたファイルはアップロードすることが出来ません。\n";
	}

	// エラーが存在すれば、returnする
	if (err_msg) {
		alert(err_msg);
		return false;
	}

	//同名のファイルが存在するか確認
	cxAjaxCommand('cxFCKRenameSpecialFile_Check', 'now_file_path=' + now_file_path
			+ '&new_file_name=' + encodeURIComponent(new_file_name), RenameCheck_Success);

	return false;
}

//-------------------------------------------------
// 通信成功処理
// 【引数】
// r : ファイルパス 同名のファイルが存在する場合
// : 空文字 同名のファイルが存在しない場合
// 【戻値】
// false : 処理終了
// -------------------------------------------------
function RenameCheck_Success(r) {
	//リネームをする必要があるか確認	
	fileinfo = JSON.parse(r.responseText);
	if (fileinfo.length > 0) {
		//ファイル名の取得
		file_name = fileinfo[0].slice(fileinfo[0].lastIndexOf('/') + 1);
		// ダイアログを表示し、リネームを行うか確認する
		/*
		 * if(confirm("同名のファイルが存在します。\n" + file_name + "に変更します。よろしいですか？")){
		 * $('rename_file_path').value = r.responseText;
		 * $('cms_fck_link_upload').submit(); return false; } return false;
		 */
		if (fileinfo[1] != '') {
			rename_msg = fileinfo[1];
			rename_msg += "アップロードするファイルの名称を、以下の名称に変更してアップロードを行います。\n\n";
			rename_msg += "ファイル1 : "
					+ file_name
					+ "\n";
			if(confirm(rename_msg)) {
				$('rename_file_path').value = fileinfo[0];
			}
			else {
				return false;
			}
		} else if (fileinfo[0] != '' && !confirm("同名のファイルが存在します。\n上書きしますか？\nキャンセルを押すと" + file_name
				+ "に変更して登録されます。")) {
			$('rename_file_path').value = fileinfo[0];
		}
		$('cms_fck_link_upload').submit();
		return false;
	}
	//リネーム無しの場合
	$('cms_fck_link_upload').submit();
	return false;
}

//-------------------------------------------------
// 通信失敗処理
// 【引数】
// なし
// 【戻値】
// false : 処理終了
// -------------------------------------------------
function cxFailure() {
	alert("ファイルのアップロードに失敗しました。");
	return false;
}
