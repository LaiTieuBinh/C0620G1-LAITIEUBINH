<?php
/**
 * サイト内リンク ページ表示画面
 */
require ("../.htsetting");
global $objCnc;
if (isset($_SESSION['fck']['sitelink'])) unset($_SESSION['fck']['sitelink']);
//エラー画面設定 別ウィンドウ用
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

//リンクをクリックしてきた場合は、そのページを表示
if (isset($_GET['pid']) && $_GET['pid'] != '') {
	if ($objPage->selectFromID($_GET['pid']) === FALSE) user_error("ページが見つかりません", E_USER_ERROR);
} //サイト内URLが入力された場合
else if (isset($_GET['url']) && $_GET['url'] != '') {
	$url = str_replace(RPW, "", $_GET['url']);
	if ($objPage->selectFromPath($url) === FALSE) {
		//サイト内URLのURLが見つからなかった場合はサイトトップページを表示
		if ($objPage->selectFromPath(SITE_TOP_PAGE) === FALSE) user_error("ページが見つかりません", E_USER_ERROR);
	}
} //サイトトップページを表示
else {
	if ($objPage->selectFromPath(SITE_TOP_PAGE) === FALSE) user_error("ページが見つかりません", E_USER_ERROR);
}
$fld = $objPage->fld;

//新規以外は、公開中の情報を表示
if ($fld['work_class'] != WORK_CLASS_NEW) $dispMode = PUBLISH_TABLE;
//新規の場合
else {
	//ページ作成者 or ウェブマスターの場合
	if ($fld['user_id'] == $objLogin->get('user_id') || $objLogin->get('class') == USER_CLASS_WEBMASTER) $dispMode = WORK_TABLE;
	//他のページ作成者
	else {
		//サイトトップページを表示
		if ($objPage->selectFromPath(SITE_TOP_PAGE) === FALSE) user_error("ページが見つかりません", E_USER_ERROR);
		$fld = $objPage->fld;
		//サイトトップページが公開されている場合
		if ($fld['work_class'] != WORK_CLASS_NEW) $dispMode = PUBLISH_TABLE;
		//サイトトップページが公開されていない場合
		else user_error('ページを表示できません', E_USER_ERROR);
	}
}

//プレビュー情報をセットする
$post['cms_dispMode'] = $dispMode;
$post['cms_page_id'] = $fld['page_id'];
include (APPLICATION_ROOT . "/common/inc/set_preview.inc");
//イベントを無効化する
$event_flg = FLAG_ON;
//プレビューを生成する
include (APPLICATION_ROOT . "/common/inc/set_preview_htmlStr.inc");
global $htmlStr;

//サイト内リンク用のインクルードファイルを読み込み
require_once ('./fck_sitelink_common.inc');
if (isset($_GET['fcklink']) && $_GET['fcklink'] == 2) addAuchor($htmlStr);

// file_pathで初期化する
$link_path_arg = $fld['file_path'];
// アンケートテンプレート且つ、公開側SSL対応の場合は、SSL対応ドメインを付加する
if(isPubSslTpl($fld['template_kind']) == TRUE){
	// SSL対応ドメインを付加する
	$link_path_arg = pubSslDomainPuls($fld['file_path']);
}

// ONLOADを消去
$htmlStr = preg_replace('/onload="[^"]*"/i', '', $htmlStr);
$htmlStr = preg_replace('/.*\.onload.*/i', '', $htmlStr);
$htmlStr = preg_replace('/<script.*<\/script>/i', '', $htmlStr);
//HTMLの作成
createHtml($htmlStr, $link_path_arg);
$htmlStr = preg_replace('/(<body[^>]*>)/i', '${1}' . '<span style="width:100%;height:100%;margin-bottom:1px;">' . "\n", $htmlStr);
$htmlStr = preg_replace('/(<\/body>)/i', '</span>' . '${1}' . "\n", $htmlStr);
print $htmlStr;
?>
