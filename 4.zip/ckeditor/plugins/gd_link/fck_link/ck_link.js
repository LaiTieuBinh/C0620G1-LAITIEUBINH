/*
 * リンク設定用javascript
 */

//定数の設定
//var oEditor = window.parent.InnerDialogLoaded();
//var FCK = oEditor.FCK;
//var FCKLang = oEditor.FCKLang;
//var FCKConfig = oEditor.FCKConfig;

var CKEDITOR = window.top.CKEDITOR;
var oEditorWin = CKEDITOR.currentInstance.window.$;
IKOU_MOBILE = CKEDITOR.currentInstance.config.Mobile;
function getFocusedWidget( editor ) {
	var widget = editor.widgets.focused;

	if (widget && widget.name == 'gd_image') {
		return widget;
	}
	return null;
}

var selHtml = CKEDITOR.currentInstance.document.$.createElement('span');
selHtml.appendChild(oEditorWin.getSelection().getRangeAt(0).cloneContents().cloneNode(true));
selHtml = selHtml.innerHTML;

// 正規表現の作成
var oRegex = new Object();
// ロード時のプロトコル解析用正規表現
oRegex.UriProtocol = new RegExp('');
oRegex.UriProtocol.compile('^((((http|https):)?\/\/)|mailto:|tel:)', 'gi');
// 入力時のプロトコル解析用正規表現
oRegex.UrlOnChangeProtocol = new RegExp('');
oRegex.UrlOnChangeProtocol.compile('^(http|https)://(?=.)', 'gi');
// その他のプロトコル解析用正規表現
oRegex.UrlOnChangeTestOther = new RegExp('');
oRegex.UrlOnChangeTestOther.compile('^((javascript:)|[#/\.]|((ftp|news)://))',
	'gi');
// ターゲット解析用正規表現
oRegex.ReserveTarget = new RegExp('');
oRegex.ReserveTarget.compile('^_(blank|self|top|parent)$', 'i');
//オープンデータ
//オープンデータリンク判別用
oRegex.isOpenDataLink = new RegExp('');
oRegex.isOpenDataLink.compile('openDataFile', 'i');

// 定義済テキストの削除用
var delRepText = '';
// 配列を作成
var ADD_FILE_DETAIL_EXP_ARY = getAddFileDetailExp();
for (i in ADD_FILE_DETAIL_EXP_ARY) {
	//定義用テキスト削除用の正規表現作成
	if (acc_flg == 0)
		delRepText += (delRepText != '' ? '|' : '')
				+ ADD_FILE_DETAIL_EXP_ARY[i]['JP']; // 日本語
	else if (acc_flg == 1)
		delRepText += (delRepText != '' ? '|' : '')
				+ ADD_FILE_DETAIL_EXP_ARY[i]['EN']; // 外国語
}

//ファイルサイズ（単位：KB）
var FSize;
// ファイル拡張子
var FExp;
// リンクされている場合のリンク元
var oldHref;

// ダイアログ下部のボタンを消す
//window.parent.SetButton(false);

// 選択されているリンクオブジェクトの取得
//var oLink = FCK.Selection.MoveToAncestorNode('A');
var oLink = CKEDITOR.plugins.link.getSelectedLink(CKEDITOR.currentInstance);
var oLinkChecked = true;
// リンクがあれば、リンクを設定
if (oLink) {
//	FCK.Selection.SelectNode(oLink);
	CKEDITOR.currentInstance.getSelection().selectElement(oLink);
	oldHref = oLink.$.href.replace(HTTP_ROOT, '');
}
//リンクが無ければ、選択されている文字列をチェック
else {
	//選択されている文字列が無ければ、ダイアログを出しウィンドウを閉じる
	if (typeof oEditorWin.document.selection != "undefined") {
		if (oEditorWin.document.selection.type == "None") {
			alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoSelTxt);
//			CKEDITOR.dialog.getCurrent().parts.close.$.click();
			oLinkChecked = false;
		}
	} else if (typeof oEditorWin.getSelection != "undefined") {
		if (oEditorWin.getSelection().isCollapsed == true) {
			alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoSelTxt);
//			CKEDITOR.dialog.getCurrent().parts.close.$.click();
			oLinkChecked = false;
		}
	}
//	if (FCK.EditorDocument.selection.type == 'None') {
//		alert(FCKLang.DlnLnkMsgNoSelTxt);
//		parent.window.Cancel();
//	}
//	if (oEditorWin.getSelection().type != 'Range') {
//		alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoSelTxt);
//		CKEDITOR.dialog.getCurrent().parts.close.$.click();
//	}
}

//-------------------------------------------------
// ロード時に実行される
// 【引数】
// なし
// 【戻値】
// なし
// -------------------------------------------------
window.onload = function () {
	//携帯テンプレートの場合
	if (IKOU_MOBILE == true) {
		//別ウィンドウで表示を非表示
		GetE('mode_set_normal_InUrl').style.display = 'none';
		GetE('mode_set_normal_Url').style.display = 'none';
		GetE('mode_set_normal_File').style.display = 'none';
		// アクセスキー用コントロールを表示
		GetE('mode_set_mobile_InUrl').style.display = 'block';
		GetE('mode_set_mobile_Url').style.display = 'block';
		GetE('mode_set_mobile_File').style.display = 'block';
	}
	//Translate the dialog box texts.
	CKEDITOR.FCKLanguageManager.TranslatePage(document);
	// アンカー選択用の表示作成
	LoadAnchorNamesAndIds();
	// リンクに設定されている値の取得
	LoadSelection();
	// リンクタイプの切り替え
	SetLinkType(Get_Sel_Item());
}

//-------------------------------------------------
// アンカー用の表示作成
// 【引数】
// なし
// 【戻値】
// なし
// -------------------------------------------------
var bHasAnchors;
function LoadAnchorNamesAndIds() {
	// Since version 2.0, the anchors are replaced in the DOM by IMGs so the user see the icon 
	// to edit them. So, we must look for that images now.
	var aAnchors = new Array();

	// ページ内アンカーの取得
	var oImages = oEditorWin.document.getElementsByTagName('IMG');
	var fakeAchorExists = false;
	for ( var i = 0; i < oImages.length; i++) {
	    if(oImages[i].hasAttribute('data-cke-real-element-type')) {
	    if(oImages[i].getAttribute('data-cke-real-element-type') == 'anchor') {
		  var div = document.createElement('div');
		  div.innerHTML =  decodeURIComponent(oImages[i].getAttribute('data-cke-realelement'));
		  var sName = div.firstChild.getAttribute('name');
		  AddSelectOption(GetE('cmbAnchorName'), sName, sName);
		  fakeAchorExists = true;
	      } 
	   }
	}
	//nameの取得
	var aNames = GetAnchorNames(oEditorWin.document.body);
	// ページ内アンカーのセレクト追加
	for (var i = 0; i < aAnchors.length; i++) {
		var sName = aAnchors[i].id;
		if (sName && sName.length > 0)
			AddSelectOption(GetE('cmbAnchorName'), sName,
					sName);
	}
	//エレメントIDのセレクト追加
	for (var i = 0; i < aNames.length; i++) {
		AddSelectOption(GetE('cmbAnchorName'), aNames[i],
				aNames[i]);
	}
	//表示の設定
	bHasAnchors = (aAnchors.length > 0 || aNames.length > 0 || fakeAchorExists);
	ShowE('divSelAnchor', bHasAnchors);
	ShowE('divNoAnchor', !bHasAnchors);
}

function GetAllChildrenIds(A) {
	var B = [];
	var C = function (parent) {
		for (var i = 0; i < parent.childNodes.length; i++) {
			var D = parent.childNodes[i].id;
			if (D && D.length > 0)
				B[B.length] = D;
			C(parent.childNodes[i]);
		}
	};
	C(A);
	return B;
}
;

function GetAnchorNames(A) {
	var B = [];
	var links = A.getElementsByTagName("a");
	for (var i = 0; i < links.length; i++) {
		var D = links[i].getAttribute("name");
		if (D && D.length > 0) {
			B[B.length] = D;
		}
	}
	return B;
}
;

function AddSelectOption(A, B, C) {
	var D = GetElementDocument(A).createElement("OPTION");
	D.text = B;
	D.value = C;
	A.options.add(D);
	return D;
}
;

function GetElementDocument(A) {
	return A.ownerDocument || A.document;
}
;
//-------------------------------------------------
// 現在設定されている値を取得する
// 【引数】
// なし
// 【戻値】
// なし
// -------------------------------------------------
var sType = "";
var sHRef = "";
function LoadSelection() {
	// 設定されているリンク先を取得
	var widget = getFocusedWidget(CKEDITOR.currentInstance);
	if (widget && ( widget.inline ? !widget.wrapper.getAscendant( 'a' ) : 1 )) {
		if(widget.data.gd_link)
			var sHRef = widget.data.gd_link.url.href;
	}
	//リンクが無ければ、returnする	
	if (!oLink && !sHRef) {
		return;
	}

	// 初期値設定
	sType = GetE('chkLinkType_InUrl').value;
	if(!sHRef) {
		sHRef = oLink.getAttribute('_fcksavedurl');
		if (!sHRef || sHRef.length == 0) {
			sHRef = oLink.getAttribute('href', 2) + '';
		}
	}
	// ローカルサーバのパスならば、その部分を取り除く
	sHRef = sHRef.replace(HTTP_ROOT, '');

	// プロトコルを取得
	var sProtocol = oRegex.UriProtocol.exec(sHRef);
	// プロトコルにより処理を分ける
	if (sProtocol) {
		sProtocol = sProtocol[0].toLowerCase();
		// URLよりプロトコル部分を取り除く
		var sUrl = sHRef.replace(oRegex.UriProtocol, '');
		// mailto: E-Mail
		if (sProtocol == 'mailto:') {
			sType = GetE('chkLinkType_Email').value;
			var oEMailInfo = ParseEMailUrl(sUrl);
			GetE('txtEMailAddress').value = oEMailInfo.Address;
		}
		//携帯対応
		// tel: 携帯電話
		else if (sProtocol == 'tel:' && IKOU_MOBILE == true) {
			sType = GetE('chkLinkType_Tel').value;
			GetE('txtTelNumber').value = sUrl;
		}
		//http:// 外部リンク
		else if (sProtocol == 'http://' || sProtocol == 'https://') {
			sType = GetE('chkLinkType_Url').value;
			GetE('txtUrl').value = sUrl;
			GetE('cmbLinkProtocol').value = sProtocol;
		}
		//その他
		else {
			sType = GetE('chkLinkType_Url').value;
			GetE('txtUrl').value = sProtocol + sUrl;
			GetE('cmbLinkProtocol').value = '';
		}
		afterLoadSelection();
	}
	//アンカー
	else if (sHRef.substr(0, 1) == '#' && sHRef.length > 1) {
		sType = GetE('chkLinkType_Anchor').value;
		GetE('cmbAnchorName').value = sHRef.substr(1);
		afterLoadSelection();
	}
	//その他
	else {
		//内部パスを消す
		if (sHRef.startsWith(RPW))
			sHRef = sHRef.remove(0, RPW.length);
		//携帯用テンプレートでない場合
		if (IKOU_MOBILE == false) {
			cxAjaxCommand('cxFCKGetFileInfo', 'file_path=' + sHRef, AjaxSuccess);
		} else {
			afterLoadSelection();
		}
	}
}

//-------------------------------------------------
// 通信成功処理
// 【引数】
// r : カンマ区切りの文字列(ファイルパス,拡張子,サイズ)
// 【戻値】
// なし
// -------------------------------------------------
function AjaxSuccess(r) {
	if (r.responseText != "") {
		fileinfo = r.responseText.split(",");
		// ファイル
		FExp = fileinfo[1];
		FSize = fileinfo[2];
		// オープンデータ
		// オープンデータ対応 ダイアログ内初期表示
		// リンクに設定されているクラスを取得
		var link_class = oLink.getAttribute('class');
		var isOpendata = false;
		if(link_class) {
			// 改行やタブをスペースに置換
			link_class = link_class.replace(/[\r\n\t]/g, ' ');
			// クラスにオープンデータのクラスが付与されているか判定
			isOpendata = oRegex.isOpenDataLink.exec(link_class);
		}
		if (isOpendata) {
			// オープンデータのクラスが付与されたリンクの場合はタイプにオープンデータをセット
			sType = GetE('chkLinkType_OpData').value;
			
			// 属性値として保持している各パラメータの値をセットする
			// 概要
			if (oLink.getAttribute('od_summary') != null) {
				GetE('opendata_summary').value = oLink.getAttribute('od_summary');
			}
			// ライセンス
			if (oLink.getAttribute('od_license') != null) {
				// 選択項目を取得し、パラメータと一致した選択項目のselectedを有効にする
				pulldown_option = document.getElementById("opendata_license").getElementsByTagName('option');
				for(i=0 ; i < pulldown_option.length ; i++){
					if (pulldown_option[i].value == oLink.getAttribute('od_license')) {
						pulldown_option[i].selected = true;
					}
				}
			}
			// データ時点
			if (oLink.getAttribute('od_ptsy') != null && 
				oLink.getAttribute('od_ptsm') != null && 
				oLink.getAttribute('od_ptsd') != null) {
				GetE('ptsy').value = oLink.getAttribute('od_ptsy');
				GetE('ptsm').value = oLink.getAttribute('od_ptsm');
				GetE('ptsd').value = oLink.getAttribute('od_ptsd');
			}
			// 掲載日
			if (oLink.getAttribute('od_pssy') != null && 
				oLink.getAttribute('od_pssm') != null && 
				oLink.getAttribute('od_pssd') != null) {
				GetE('pssy').value = oLink.getAttribute('od_pssy');
				GetE('pssm').value = oLink.getAttribute('od_pssm');
				GetE('pssd').value = oLink.getAttribute('od_pssd');
			}
			// カテゴリ
			if (oLink.getAttribute('od_category') != null) {
				// 選択項目を取得し、パラメータと一致した選択項目のcheckedを有効にする
				var category_check_box_ele = document.getElementsByName("opendata_category[]");
				var check_param = oLink.getAttribute('od_category').split(',');
				for (var j=0 ; j < check_param.length ; j++) {
					for(var i=0 ; i < category_check_box_ele.length ; i++){
						if (category_check_box_ele[i].value == check_param[j]) {
							category_check_box_ele[i].checked = true;
						}
					}
				}
			}
			
			// データタイプ
			if (oLink.getAttribute('od_od_data_type') != null) {
				// 選択項目を取得し、パラメータと一致した選択項目のselectedを有効にする
				pulldown_option = document.getElementById("od_data_type").getElementsByTagName('option');
				for(i=0 ; i < pulldown_option.length ; i++){
					if (pulldown_option[i].value == oLink.getAttribute('od_od_data_type')) {
						pulldown_option[i].selected = true;
					}
				}
			}
			// キーワード
			if (oLink.getAttribute('od_keywords') != null) {
				GetE('opendata_keywords').value = oLink.getAttribute('od_keywords');
			}
		}
		else {
			// 無い場合はファイル(この処理が呼ばれるのはファイルかオープンデータのみであることを前提)
			sType = GetE('chkLinkType_File').value;
		}
		GetE('txtFile').value = fileinfo[0];
	}
	afterLoadSelection();
}

//-------------------------------------------------
// 通信失敗処理
// 【引数】
// なし
// 【戻値】
// なし
// -------------------------------------------------
function cxFailure() {
	afterLoadSelection();
}

//-------------------------------------------------
// ロード後処理
// 【引数】
// なし
// 【戻値】
// なし
// -------------------------------------------------
function afterLoadSelection() {
	// 設定されているリンク先を取得
	var widget = getFocusedWidget(CKEDITOR.currentInstance);
	var sTarget = "";
	if ( widget && ( widget.inline ? !widget.wrapper.getAscendant( 'a' ) : 1 ) ) {
		if(widget.data.gd_link.target != 'notSet' ) {
			var sTarget = widget.data.gd_link.target.name;
		}
	}
	if(!widget) {
		//どの条件にも当てはまらない場合
		if (sType == GetE('chkLinkType_InUrl').value) {
		    	    
			sHRef = CKEDITOR.plugins.link.getSelectedLink(CKEDITOR.currentInstance).getAttribute('href', 2).replace(RPW, '');
			//サイト内リンク
			if (sHRef.match(/^\/[\-\_\.!~\*\'\(\)a-zA-Z0-9;\/\?:\@&=+\$,%#]+$/)) {
				GetE('txtInUrl').value = sHRef;
			}
			// 外部リンク(その他)
			else {
				sType = GetE('chkLinkType_Url').value;
				GetE('txtUrl').value = sHRef;
				GetE('cmbLinkProtocol').value = '';
			}
		}
		//リンクに設定されているtarget属性を取得する
		var sTarget = oLink.$.target;
		if (sTarget && sTarget.length > 0) {
			if (oRegex.ReserveTarget.test(sTarget)) {
				sTarget = sTarget.toLowerCase();
			}
		}
	}
	//target属性に_blankが指定されていた場合、対応するチェックボックスにチェックをつける
	if (sTarget == "_blank") {
		if (sType == GetE('chkLinkType_InUrl').value && GetE('setBlank_InUrl'))
			GetE('setBlank_InUrl').checked = true;
		else if (sType == GetE('chkLinkType_Url').value && GetE('setBlank_Url'))
			GetE('setBlank_Url').checked = true;
		else if (sType == GetE('chkLinkType_File').value
				&& GetE('setBlank_File'))
			GetE('setBlank_File').checked = true;
		// オープンデータ
		else if (sType == GetE('chkLinkType_OpData').value && GetE('setBlank_File')) {
			GetE('setBlank_File').checked = true;
		}
	}

	//携帯テンプレートの場合
	if (IKOU_MOBILE == true) {
		//アクセスキーを取得し、設定する
		getAccesskey = oLink.$.accessKey;
		if (getAccesskey && getAccesskey.match(/[0-9]/)) {
			if (sType == GetE('chkLinkType_InUrl').value)
				GetE('setAccessKey_InUrl').value = getAccesskey;
			else if (sType == GetE('chkLinkType_Url').value)
				GetE('setAccessKey_Url').value = getAccesskey;
			else if (sType == GetE('chkLinkType_File').value)
				GetE('setAccessKey_File').value = getAccesskey;
			// オープンデータ
			else if (sType == GetE('chkLinkType_File').value || sType == GetE('chkLinkType_OpData').value) {
				GetE('setAccessKey_File').value = getAccesskey;
			}
		}
	}

	//リンクタイプによりチェックボックスの切り替え
	if (sType == GetE('chkLinkType_InUrl').value)
		GetE('chkLinkType_InUrl').checked = true;
	else if (sType == GetE('chkLinkType_Url').value)
		GetE('chkLinkType_Url').checked = true;
	else if (sType == GetE('chkLinkType_Email').value)
		GetE('chkLinkType_Email').checked = true;
	else if (sType == GetE('chkLinkType_File').value)
		GetE('chkLinkType_File').checked = true;
	// オープンデータ
	// オープンデータのチェックボックスを有効にする
	else if (sType == GetE('chkLinkType_OpData').value) {
		GetE('chkLinkType_OpData').checked = true;
	}
	else if (sType == GetE('chkLinkType_Anchor').value)
		GetE('chkLinkType_Anchor').checked = true;
	else if (sType == GetE('chkLinkType_Tel').value)
		GetE('chkLinkType_Tel').checked = true;

	// リンクタイプの切り替え(Ajaxが非同期のため、予備)
	SetLinkType(Get_Sel_Item());
}

//-------------------------------------------------
// リンクタイプの切り替え
// 【引数】
// linkType : 現在選択されているリンクタイプ
// 【戻値】
// なし
// -------------------------------------------------
function SetLinkType(linkType) {
	//内部リンク
	ShowE('divLinkTypeInUrl_name',
			(linkType == GetE('chkLinkType_InUrl').value));
	ShowE('divLinkTypeInUrl', (linkType == GetE('chkLinkType_InUrl').value));
	// 外部リンク
	ShowE('divLinkTypeUrl_name', (linkType == GetE('chkLinkType_Url').value));
	ShowE('divLinkTypeUrl', (linkType == GetE('chkLinkType_Url').value));
	// E-Mail
	ShowE('divLinkTypeEMail_name',
			(linkType == GetE('chkLinkType_Email').value));
	ShowE('divLinkTypeEMail', (linkType == GetE('chkLinkType_Email').value));
	
	// 携帯テンプレートでない場合
	if (IKOU_MOBILE == false) {
		// オープンデータ
		// オープンデータ対応 ファイル設定の領域表示及びオープンデータ詳細入力エリアの表示切替
		if (linkType != GetE('chkLinkType_OpData').value) {
			// ファイル
			ShowE('divLinkTypeFile_name', (linkType == GetE('chkLinkType_File').value));
			ShowE('divLinkTypeFile', (linkType == GetE('chkLinkType_File').value));
		}
		else if (linkType == GetE('chkLinkType_OpData').value) {
			
			ShowE('divLinkTypeFile_name', (linkType == GetE('chkLinkType_OpData').value));
			ShowE('divLinkTypeFile', (linkType == GetE('chkLinkType_OpData').value));
		}
		// オープンデータの詳細表示切替
		ShowE('divLinkTypeOpData', (linkType == GetE('chkLinkType_OpData').value));
	}
	
	// ページ内アンカー
	ShowE('divLinkTypeAnchor_name',
			(linkType == GetE('chkLinkType_Anchor').value));
	ShowE('divLinkTypeAnchor', (linkType == GetE('chkLinkType_Anchor').value));
	ShowE('divLinkTypeOpData', (linkType == GetE('chkLinkType_OpData').value));
	// 携帯テンプレートの場合
	if (IKOU_MOBILE == true) {
		//携帯電話
		ShowE('divLinkTypeTel_name',
				(linkType == GetE('chkLinkType_Tel').value));
		ShowE('divLinkTypeTel', (linkType == GetE('chkLinkType_Tel').value));
	}

	//E-Mailが選択されていた場合、ウィンドウサイズを設定し直す
//	if (linkType == GetE('chkLinkType_Email').value)
//		window.parent.SetAutoSize(true);

	// ページ内リンク以外なら、ボタンを無効にする
	if (linkType != GetE('chkLinkType_InUrl').value)
		GetE('divSiteLink').innerHTML = '<a id="aSiteLink"  class="cke_dialog_ui_button cke_dialog_ui_button_inactive">サイト内リンク設定</a>';
	// ページ内リンクなら有効にする
	else
		GetE('divSiteLink').innerHTML = '<a id="aSiteLink"  class="cke_dialog_ui_button" href="javascript:void(0)" onclick="showModal(1);">サイト内リンク設定</a>';
	//携帯テンプレートでない場合
	if (IKOU_MOBILE == false) {
		// オープンデータ
		// ファイル、オープンデータファイル以外なら、ボタンを無効にする
		if (linkType != GetE('chkLinkType_File').value && linkType != GetE('chkLinkType_OpData').value) {
			GetE('divFileLink').innerHTML = '<a id="aFileLink"  class="cke_dialog_ui_button cke_dialog_ui_button_inactive" >ファイルリンク設定</a>';
		}
		// ファイル、またはオープンデータであれば有効にする
		else
			GetE('divFileLink').innerHTML = '<a id="aFileLink"  class="cke_dialog_ui_button"  href="javascript:void(0)" onclick="showModal(2);">ファイルリンク設定</a>';
	} else {
		GetE('divFileLink').innerHTML = '';
	}
}

//-------------------------------------------------
// URLを入力した際に動的にプロトコルをチェックする
// 【引数】
// なし
// 【戻値】
// なし
// -------------------------------------------------
function OnUrlChange() {
	var sUrl = GetE('txtUrl').value;
	var sProtocol = oRegex.UrlOnChangeProtocol.exec(sUrl);

	if (sProtocol) {
		sUrl = sUrl.substr(sProtocol[0].length);
		GetE('txtUrl').value = sUrl;
		GetE('cmbLinkProtocol').value = sProtocol[0].toLowerCase();
	} else if (oRegex.UrlOnChangeTestOther.test(sUrl))
		GetE('cmbLinkProtocol').value = '';
}

function showObject(elm, type) {
	var str = '「' + typeof elm + "」の中身";
	var cnt = 0;
	for (i in elm) {
		if (type == 'html') {
			str += '<br />\n' + "[" + cnt + "] " + i.bold() + ' = ' + elm[i];
		} else {
			str += '\n' + "[" + cnt + "] " + i + ' = ' + elm[i];
		}
		cnt++;
		status = cnt;
	}
	return str;
}

//-------------------------------------------------
// 決定ボタンが押された際の処理
// 【引数】
// なし
// 【戻値】
// true : 成功時
// false : 失敗時
// -------------------------------------------------
function Ok() {
	var sUri, sInnerHtml;

	var selected_item = Get_Sel_Item();
	// サイト内リンクフォーマットチェック用正規表現
	var osUriRegEx = new RegExp(
			"^(s?https?:\/)?\/[-_.!~*'()a-zA-Z0-9;\/?:\@&=+\$,%#]+$");

// リンクテキストチェック
//	if (oEditor.FCK.EditorDocument.selection.createRange()) {
//		var alt_arys = new Array();
//		var info = new Array();
//		var alt_text = "";
//		
//		if (oEditor.FCK.EditorDocument.selection.createRange().htmlText != undefined) {
//			var link_text = oEditor.FCK.EditorDocument.selection.createRange().htmlText;
//			var link_dom = String2DOM(link_text);
//			var link_img_arys = link_dom.getElementsByTagName("img");
//			
//			for (i = 0; i < link_img_arys.length; i++) {
//				alt_arys.push(link_img_arys[i].alt);
//				link_img_arys[i].alt = "";
//			}
//			
//			var link_text2 = link_dom.innerHTML;
//			link_text2 = link_text2.replace(/<[^>]*?(>)/g, "@@CMS_TAG@@");
//			var split_texts = new Array();
//			split_texts = link_text2.split("@@CMS_TAG@@");
//			
//			for (i = 0; i < split_texts.length; i++) {
//				alt_text += split_texts[i];
//				info = accItemCheck('リンクタイトル',split_texts[i],info,'file');
//			}
//			for (i = 0; i < alt_arys.length; i++) {
//				alt_text += alt_arys[i];
//				info = accItemCheck('リンクタイトル',alt_arys[i],info,'file');
//			}
//		} else {
//			var link_text = oEditor.FCK.EditorDocument.selection.createRange();
//			
//			for (i = 0; i < link_text.length; i++) {
//				if (link_text.item(i).alt != undefined && link_text.item(i).alt != null) {
//					alt_arys.push(link_text.item(i).alt);
//				}
//			}
//			for (i = 0; i < alt_arys.length; i++) {
//				alt_text += alt_arys[i];
//				info = accItemCheck('リンクタイトル',alt_arys[i],info,'file');
//			}
//		}
//		
//		if (info.length > 0) {
//			alert("リンクテキストに推奨されない文字が指定されています。");
//		} else {
//			// 「&nbsp;(文字参照スペース)」を「 (半角スペース)」に変換
//			alt_text = alt_text.replace(/&nbsp;/g, " ");
//			// 「　(文字参照全角スペース)」を「 (半角スペース)」に変換
//			alt_text = alt_text.replace(/　/g, " ");
//			// 「 (半角スペース)」を削除
//			alt_text = alt_text.replace(/ /g, "");
//			if (alt_text.length < 1) {
//				alert("リンクテキストに画面に表示されない文言のみ指定されています。");
//			}
//		}
//	}


	switch (selected_item) {
		//内部リンク
		case GetE('chkLinkType_InUrl').value:
			//URLの取得
			sUri = trim(GetE('txtInUrl').value);
			// ローカルサーバのパスならば、その部分を取り除く
			sUri = sUri.replace(HTTP_ROOT, '')
			if (sUri.startsWith(RPW))
				sUri = sUri.remove(0, RPW.length);
			// 必須チェック
			if (sUri.length == 0) {
				alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoUrl);
				GetE('txtInUrl').focus();
				return false;
			}
			//URLフォーマットチェック
			var asUriPath = osUriRegEx.exec(sUri);
			if (asUriPath == null) {
				alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgErrUrl);
				GetE('txtInUrl').focus();
				return false;
			}
			//プロトコルを取得
			oRegex.UriProtocol.lastIndex = 0;
			var sProtocol = oRegex.UriProtocol.exec(sUri);
			// プロトコルが存在しない場合
			if (sProtocol == null) {
				//内部パスを足す
				sUri = RPW + sUri;
			}
			FExp = null;
			break;
			// 外部リンク
		case GetE('chkLinkType_Url').value:
			//URLの取得
			sUri = trim(GetE('txtUrl').value);
			// 必須チェック
			if (sUri.length == 0) {
				alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoUrl);
				GetE('txtUrl').focus();
				return false;
			}
			//プロトコルを取得
			oRegex.UriProtocol.lastIndex = 0;
			var sProtocol = oRegex.UriProtocol.exec(sUri);
			// プロトコルが存在しない場合
			if (sProtocol == null) {
				//プロトコルを足す
				sUri = GetE('cmbLinkProtocol').value + sUri;
			}
			//URLフォーマットチェック
			if (GetE('cmbLinkProtocol').value != "") {
				osUriRegEx = URLRegEx;
				var asUriPath = osUriRegEx.exec(sUri);
				if (asUriPath == null) {
					alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgErrUrl);
					GetE('txtUrl').focus();
					return false;
				}
			}
			//ローカルサーバのパスならば、その部分を取り除く
			sUri = sUri.replace(HTTP_ROOT, '')
			if (sUri.startsWith(RPW))
				sUri = sUri.remove(0, RPW.length);
			//プロトコルを取得
			oRegex.UriProtocol.lastIndex = 0;
			sProtocol = oRegex.UriProtocol.exec(sUri);
			// プロトコルが存在しない場合
			if (sProtocol == null) {
				//内部パスを足す
				sUri = RPW + sUri;
			}
			FExp = null;
			break;
			// E-Mail
		case GetE('chkLinkType_Email').value:
			//メールアドレスの取得
			sUri = trim(GetE('txtEMailAddress').value);
			// 必須チェック
			if (sUri.length == 0) {
				alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoEMail);
				GetE('txtEMailAddress').focus();
				return false;
			}
			//メールアドレスフォーマットチェック
			var asUriPath = EMailRegEx.exec(sUri);
			if (asUriPath == null) {
				alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgErrEMail);
				GetE('txtEMailAddress').focus();
				return false;
			}
			//プロトコルを取得
			oRegex.UriProtocol.lastIndex = 0;
			var sProtocol = oRegex.UriProtocol.exec(sUri);
			// プロトコルが存在しない場合
			if (sProtocol == null) {
				//設定値の作成
				sUri = CreateEMailUri(sUri, "", "");
			}
			FExp = null;
			break;
			// ファイル
		case GetE('chkLinkType_File').value:
			//ファイルパスの取得
			sUri = trim(GetE('txtFile').value);
			// ローカルサーバのパスならば、その部分を取り除く
			sUri = sUri.replace(HTTP_ROOT, '')
			if (sUri.startsWith(RPW))
				sUri = sUri.remove(0, RPW.length);
			// 必須チェック
			if (sUri.length == 0) {
				alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoFile);
				GetE('txtFile').focus();
				return false;
			}
			//ファイル拡張子のチェック
			var File_Exte = DENIED_EXTENSIONS_FILE.split(",");
			for (var i = 0; i < File_Exte.length; i++) {
				var ExteRegEx = new RegExp("(\\." + File_Exte[i] + ")$");
				var asFileExte = ExteRegEx.exec(sUri);
				if (asFileExte != null) {
					alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgErrExpFile);
					GetE('txtFile').focus();
					return false;
				}
			}
			//プロトコルを取得
			oRegex.UriProtocol.lastIndex = 0;
			var sProtocol = oRegex.UriProtocol.exec(sUri);
			// プロトコルが存在しない場合
			if (sProtocol == null) {
				//内部パスを足す
				sUri = RPW + sUri;
			}
			break;
		// オープンデータ
		// オープンデータファイル
		case GetE('chkLinkType_OpData').value:
			//ファイルパスの取得
			sUri = trim(GetE('txtFile').value);
			// ローカルサーバのパスならば、その部分を取り除く
			sUri = sUri.replace(HTTP_ROOT, '');
			if (sUri.startsWith(RPW))
				sUri = sUri.remove(0, RPW.length);
			// 必須チェック
			if (sUri.length == 0) {
				alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoFile);
				GetE('txtFile').focus();
				return false;
			}
			//ファイル拡張子のチェック
			var File_Exte = DENIED_EXTENSIONS_FILE.split(",");
			for ( var i = 0; i < File_Exte.length; i++) {
				var ExteRegEx = new RegExp("(\\." + File_Exte[i] + ")$");
				var asFileExte = ExteRegEx.exec(sUri);
				if (asFileExte != null) {
					alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgErrExpFile);
					GetE('txtFile').focus();
					return false;
				}
			}
			//プロトコルを取得
			oRegex.UriProtocol.lastIndex = 0;
			var sProtocol = oRegex.UriProtocol.exec(sUri);
			// プロトコルが存在しない場合
			if (sProtocol == null) {
				//内部パスを足す
				sUri = RPW + sUri;
			}
			
			// その他オープンデータ関連の入力値をチェック
			// オープンデータ概要
			var summary_txt = trim(GetE('opendata_summary').value);
			// 必須チェック
			if(summary_txt.length == 0){
				alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoSummary);
				GetE('opendata_summary').focus();
				return false;
			}
			// 機種依存文字チェック
			info = new Array();
			info = fckCheck('概要',summary_txt,info);
			info = accItemCheck('概要',summary_txt,info,'file');
			if (!info) {
				alert("[概要]入力値チェックエラー");
				return false;
			}
			if(info.length > 0){
				var msg = info.join('\n') + '\nよろしいですか？';
				if(!confirm(msg)){
					$('txtFile_txt').focus();
					return false;
				}
			}
			// ライセンス必須チェック
			var license_txt = trim(GetE('opendata_license').value);
			if(license_txt.length == 0){
				alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoLicense);
				GetE('opendata_license').focus();
				return false;
			}
			// データ時点入力日付チェック
			if (!($F('ptsy') == "" && $F('ptsm') == "" && $F('ptsd') == "")) {
				var date_check_result = cxDateCheckNew("pt", "ymd", 2, "データ時点");
				if (!disp_date_error(date_check_result, "ptsy")) {
					return false;
				}
			} else {
				alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoPointOfTime);
				GetE('ptsy').focus();
				return false;
			}
			// 掲載日
			if (!($F('pssy') == "" && $F('pssm') == "" && $F('pssd') == "")) {
				var date_check_result = cxDateCheckNew("ps", "ymd", 2, "掲載日");
				if (!disp_date_error(date_check_result, "pssy")) {
					return false;
				}
			} else {
				alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoPublicationDate);
				GetE('pssy').focus();
				return false;
			}
			// カテゴリ必須チェック
			var category_check_box_ele = document.getElementsByName('opendata_category[]');
			var category_check_box_flg = false;
			for (var i=0; i<category_check_box_ele.length; i++) {
				if(category_check_box_ele.item(i).checked) {
					category_check_box_flg = true;
				}
			}
			if (!category_check_box_flg) {
				alert("カテゴリを選択してください。");
				return false;
			}
			// データタイプ必須チェック
			var od_data_type_txt = trim(GetE('od_data_type').value);
			if(od_data_type_txt.length == 0){
				alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoDataType);
				GetE('od_data_type').focus();
				return false;
			}
			// キーワード検索タグ
			var keyword_search_txt = trim(GetE('opendata_keywords').value);
			// 機種依存文字チェック
			info = new Array();
			info = fckCheck('キーワード検索タグ',keyword_search_txt,info);
			info = accItemCheck('キーワード検索タグ',keyword_search_txt,info,'file');
			if (!info) {
				alert("[キーワード検索タグ]入力値チェックエラー");
				return false;
			}
			if(info.length > 0){
				var msg = info.join('\n') + '\nよろしいですか？';
				if(!confirm(msg)){
					$('txtFile_txt').focus();
					return false;
				}
			}
			
			break;
			// アンカー
		case GetE('chkLinkType_Anchor').value:
			//アンカーの取得
			var sAnchor = GetE('cmbAnchorName').value;
			// 必須チェック
			if (sAnchor.length == 0) {
				alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoAnchor);
				return false;
			}
			sUri = '#' + sAnchor;
			FExp = null;
			break;
			// 電話番号
		case GetE('chkLinkType_Tel').value:
			// 携帯テンプレートの場合
			if (IKOU_MOBILE == true) {
				//電話番号の取得
				sUri = trim(GetE('txtTelNumber').value);
				// 必須チェック
				if (sUri.length == 0) {
					alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgNoTel);
					GetE('txtTelNumber').focus();
					return false;
				}
				//数値チェック
				if (sUri.match(/[^0-9]+/)) {
					alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgErrTel);
					GetE('txtTelNumber').focus();
					return false;
				}
				//プロトコルを取得
				oRegex.UriProtocol.lastIndex = 0;
				var sProtocol = oRegex.UriProtocol.exec(sUri);
				// プロトコルが存在しない場合
				if (sProtocol == null) {
					//プロトコルを足す
					sUri = 'tel:' + sUri;
				}
				FExp = null;
				break;
			}
	}

	//携帯テンプレートの場合
	if (IKOU_MOBILE == true) {
		//アクセスキーの取得
		var sAkey = "";
		if (selected_item == GetE('chkLinkType_InUrl').value)
			sAkey = GetE('setAccessKey_InUrl').value;
		else if (selected_item == GetE('chkLinkType_Url').value)
			sAkey = GetE('setAccessKey_Url').value;
		else if (selected_item == GetE('chkLinkType_File').value)
			sAkey = GetE('setAccessKey_File').value;
		// オープンデータ
		// オープンデータファイル
		else if (selected_item == GetE('chkLinkType_File').value || selected_item == GetE('chkLinkType_OpData').value) {
			sAkey = GetE('setAccessKey_File').value;
		}
		// アクセスキーが入力されていた場合
		if (sAkey.length == 1) {
			//FCKeditor内のチェック
			var selectedLink = CKEDITOR.plugins.link.getSelectedLink(CKEDITOR.currentInstance);
			var aTags = oEditorWin.document.getElementsByTagName('A');
			for (var i = 0; i < aTags.length; i++) {
				if (selectedLink && selectedLink.$ == aTags[i]){
					continue;
				}
				if (sAkey == aTags[i].accessKey) {
					alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgExistAKey);
					return false;
				}
			}
			//ドキュメント全体のチェック
			aTags = oEditorWin.parent.document.getElementsByTagName('A');
			for (var i = 0; i < aTags.length; i++) {
				if (selectedLink && selectedLink.$ == aTags[i]){
					continue;
				}
				if (sAkey == aTags[i].accessKey) {
					alert(CKEDITOR.FCKLanguageManager.FCKLang.DlnLnkMsgExistAKey);
					return false;
				}
			}
		}
	}

	var widget = getFocusedWidget(CKEDITOR.currentInstance);
	if (widget && ( widget.inline ? !widget.wrapper.getAscendant( 'a' ) : 1 )) {
		selected_item = Get_Sel_Item();
		var data = { 'type': 'url', 'url' : { 'href' : sUri }};
		var target = false;
		
		if (selected_item == GetE('chkLinkType_InUrl').value
			&& GetE('setBlank_InUrl') && GetE('setBlank_InUrl').checked) {
			target = true;
		}
		else if (selected_item == GetE('chkLinkType_Url').value
				&& GetE('setBlank_Url') && GetE('setBlank_Url').checked) {
			target = true;
		}
		else if (selected_item == GetE('chkLinkType_File').value
				&& GetE('setBlank_File') && GetE('setBlank_File').checked) {
			target = true;
		}
		else if (selected_item == GetE('chkLinkType_OpData').value
				&& GetE('setBlank_File') && GetE('setBlank_File').checked) {
			target = true;
		}
		if (target) {
			data.target = { 'name' : "_blank", 'type' : 'set' };					
		}
		else {
			data.target = { 'name' : "", 'type' : 'notSet' };
		}

		widget.setData('gd_link', data );
		
		CKEDITOR.dialog.getCurrent().parts.close.$.click();
		return true;		
	}
	// No link selected, so try to create one.
	// 2007.07.04 start
	if (!oLink) {
		CKEDITOR.currentInstance.fire('saveSnapshot');

		oLinks = new CKEDITOR.dom.element('a');
		oLinks.setHtml(selHtml);

		// delete selected html
		range = CKEDITOR.currentInstance.getSelection().getRanges()[ 0 ];
		range.deleteContents();
		range.select();

		// insert link
		CKEDITOR.currentInstance.fire('lockSnapshot');
		CKEDITOR.currentInstance.insertElement(oLinks);
		settingLink(oLinks, sUri);
		CKEDITOR.currentInstance.fire('unlockSnapshot');

		CKEDITOR.currentInstance.fire('saveSnapshot');
//		oLinks = oEditor.FCK.CreateLink(sUri);
//		for ( var i = 0; i < oLinks.length; i++) {
//			settingLink(oLinks[i], sUri);
//		}
	} else {
		CKEDITOR.currentInstance.fire('saveSnapshot');
		settingLink(oLink, sUri);
	}

	// 2007.07.04 end

	CKEDITOR.dialog.getCurrent().parts.close.$.click();

	return true;
}

//-------------------------------------------------
// FCKeditorの選択部分に入力した値をセットする
// 【引数】
// oLink : リンクオブジェクト
// sUri : 入力したURI
// 【戻値】
// なし
// -------------------------------------------------
function settingLink(oLink, sUri) {
	//選択している項目を取得
	var selected_item = Get_Sel_Item();

	// Save the innerHTML (IE changes it if it is like a URL).
	if (oLink)
		sInnerHtml = oLink.$.innerHTML;
	// If no selection, use the uri as the link text (by dom, 2006-05-26)
	else {
		sInnerHtml = sUri;
		// try to built better text for empty link
		switch (selected_item) {
			//ページ内リンク
			case GetE('chkLinkType_InUrl').value:
				break;
				// 外部リンク
			case GetE('chkLinkType_Url').value:
				var oLinkPathRegEx = new RegExp("//?([^?\"']+)([?].*)?$");
				var asLinkPath = oLinkPathRegEx.exec(sUri);
				// use matched path
				if (asLinkPath != null)
					sInnerHtml = asLinkPath[1];
				break;
				// E-Mail
			case GetE('chkLinkType_Email').value:
				sInnerHtml = GetE('txtEMailAddress').value;
				break;
				// ファイル
			case GetE('chkLinkType_File').value:
				sInnerHtml = GetE('txtFile').value;
				break;
			// オープンデータ
			// オープンデータファイル
			case GetE('chkLinkType_OpData').value:
				sInnerHtml = GetE('txtFile').value;
				break;
			// ページ内アンカー
				// ページ内アンカー
			case GetE('chkLinkType_Anchor').value:
				sInnerHtml = sInnerHtml.replace(/^#/, '');
				break;
				// 携帯電話
			case GetE('chkLinkType_Tel').value:
				// 携帯テンプレートの場合
				if (IKOU_MOBILE == true)
					sInnerHtml = GetE('txtTelNumber').value;
				break;
		}
		// built new anchor and add link text
		oLink = CKEDITOR.dom.element.createFromHtml('a');
		CKEDITOR.currentInstance.insertElement(oLink);
	}


	oLink.$.href = sUri;
	SetAttribute(oLink.$, 'data-cke-saved-href', sUri);
	
	// 別ウィンドウで開くリンク文字列の削除
	// 日本語の場合
	if (acc_flg == 0) {
		sInnerHtml = sInnerHtml.replace(new RegExp(reg_replace(OTHER_WINDOW_STR_JP) + '$', 'ig'), '');
	}
	// 外国語の場合
	else if (acc_flg == 1) {
		sInnerHtml = sInnerHtml.replace(new RegExp(reg_replace(OTHER_WINDOW_STR_EN) + '$', 'ig'), '');
	}


	// 外部リンク文字列の削除
	if (OUT_SITE_FLG == true) {
		if (acc_flg == 0)
			sInnerHtml = sInnerHtml.replace(new RegExp(
					reg_replace(OUT_SITE_STR_JP) + '$', 'ig'), ''); // 日本語
		else if (acc_flg == 1)
			sInnerHtml = sInnerHtml.replace(new RegExp(
					reg_replace(OUT_SITE_STR_EN) + '$', 'ig'), ''); // 外国語
	}

	//元のリンクに外部サイト以外のリンクが指定されており、現在外部リンク以外のリンクが指定されている場合
	if (!(oldHref && oldHref.match(/^(https?:)?\/\//ig) && oLink.$.href.match(/^(https?:)?\/\//ig))) {
		//定義済みテキストの削除
		sInnerHtml = sInnerHtml
				.replace(
						new RegExp(
								'(（|\\\()(' + delRepText + ')((：|:)[0-9,]+KB)?(）|\\\))$',
								'gi'), '');
		// オープンデータ
		// ファイル種別やサイズが付与される前の文字列を保持
		var link_text_base = sInnerHtml;
		
		// クラス指定の削除
		if (oLink.$.getAttribute('className', '0') != undefined) {
			for (i in ADD_FILE_DETAIL_EXP_ARY) {
				//クラスの指定が拡張子の指定の場合
				if (oLink.$.getAttribute('className') == ADD_FILE_DETAIL_EXP_ARY[i]['CLASS']) {
					oLink.$.removeAttribute('className', '0');
					break;
				}
			}
		}
		//ファイル形式/ファイルサイズ自動取得
		// 関連リンクファイルのファイル種別とファイルサイズの挿入
		if (FExp) {
			//配列とマッチングさせるため、小文字に変更
			FExp = FExp.toLowerCase();
			// 配列に存在する場合
			if (ADD_FILE_DETAIL_EXP_ARY[FExp]) {
				//ファイル種別の指定
				if (acc_flg == 0)
					sInnerHtml += "（" + ADD_FILE_DETAIL_EXP_ARY[FExp]['JP']; // 日本語
				else if (acc_flg == 1)
					sInnerHtml += "(" + ADD_FILE_DETAIL_EXP_ARY[FExp]['EN']; // 外国語
				// クラスの指定
				if (ADD_FILE_DETAIL_EXP_ARY[FExp]['CLASS'] != "")
					//▼IE9対応
//					SetAttribute(oLink, 'class',
//							ADD_FILE_DETAIL_EXP_ARY[FExp]['CLASS']);
					oLink.$.className = ADD_FILE_DETAIL_EXP_ARY[FExp]['CLASS'];
				//▲IE9対応
				// ファイルサイズの指定
				if (FSize)
					sInnerHtml += (acc_flg == 0 ? "：" : ":")
							+ numEdit(Math.ceil(FSize / 1024)) + "KB";
				sInnerHtml += (acc_flg == 0 ? "）" : ")");
			}
		}
	}

	//外部リンクの場合
	if (OUT_SITE_FLG == true && oLink.$.href.match(/^(https?:)?\/\//ig)) {
		//サイト内定義リストのチェック
		var out_site_domain_ary = OUT_SITE_DOMAIN.split(',');
		var out_site_flg = true;
		for (var i = 0; i < out_site_domain_ary.length; i++) {
			if (oLink.$.href
					.match(new RegExp('^' + out_site_domain_ary[i], 'ig'))) {
				out_site_flg = false;
				break;
			}
		}
		//サイト内定義リストに無かった場合
		if (out_site_flg) {
			if (acc_flg == 0)
				sInnerHtml += OUT_SITE_STR_JP; // 日本語
			else if (acc_flg == 1)
				sInnerHtml += OUT_SITE_STR_EN; // 外国語
		}
	}
	
	// オープンデータ
	// オープンデータ リンクターゲットの初期値に_selfをセット
	var od_link_target = '_self';
	
	// 属性設定
	if (selected_item == GetE('chkLinkType_InUrl').value && GetE('setBlank_InUrl') && GetE('setBlank_InUrl').checked) {
		    		// 日本語テンプレートの場合
		if (acc_flg == 0) {
			sInnerHtml += OTHER_WINDOW_STR_JP;
		}
		// 外国語テンプレートの場合
		else if (acc_flg == 1) {
			sInnerHtml += OTHER_WINDOW_STR_EN;
		}

		SetAttribute(oLink.$, 'target', '_blank');
	    } else if (selected_item == GetE('chkLinkType_Url').value && GetE('setBlank_Url') && GetE('setBlank_Url').checked) {
		    		// 日本語テンプレートの場合
		if (acc_flg == 0) {
			sInnerHtml += OTHER_WINDOW_STR_JP;
		}
		// 外国語テンプレートの場合
		else if (acc_flg == 1) {
			sInnerHtml += OTHER_WINDOW_STR_EN;
		}

		SetAttribute(oLink.$, 'target', '_blank');
	    } else if (selected_item == GetE('chkLinkType_File').value && GetE('setBlank_File') && GetE('setBlank_File').checked) {
		    		// 日本語テンプレートの場合
		if (acc_flg == 0) {
			sInnerHtml += OTHER_WINDOW_STR_JP;
		}
		// 外国語テンプレートの場合
		else if (acc_flg == 1) {
			sInnerHtml += OTHER_WINDOW_STR_EN;
		}

		SetAttribute(oLink.$, 'target', '_blank');
	// オープンデータ
	  } else if (selected_item == GetE('chkLinkType_OpData').value && GetE('setBlank_File') && GetE('setBlank_File').checked) {
	    		// 日本語テンプレートの場合
		if (acc_flg == 0) {
			sInnerHtml += OTHER_WINDOW_STR_JP;
		}
		// 外国語テンプレートの場合
		else if (acc_flg == 1) {
			sInnerHtml += OTHER_WINDOW_STR_EN;
		}

		SetAttribute(oLink, 'target', '_blank');
		// リンクターゲットの値をブランクに更新
		od_link_target = '_blank';
	} else {
		SetAttribute(oLink.$, 'target', '');
	}
	// 携帯テンプレートの場合
	if (IKOU_MOBILE == true) {
		//アクセスキーの取得
		var sAkey = "";
		if (selected_item == GetE('chkLinkType_InUrl').value)
			sAkey = GetE('setAccessKey_InUrl').value;
		else if (selected_item == GetE('chkLinkType_Url').value)
			sAkey = GetE('setAccessKey_Url').value;
		else if (selected_item == GetE('chkLinkType_File').value)
			sAkey = GetE('setAccessKey_File').value;
		// オープンデータ
		else if (selected_item == GetE('chkLinkType_File').value || selected_item == GetE('chkLinkType_OpData').value) {
			sAkey = GetE('setAccessKey_File').value;
		}
		// アクセスキーが入力されていた場合
		if (sAkey.length == 1 || sAkey == "")
			SetAttribute(oLink.$, 'accesskey', sAkey);
	}   	
	// オープンデータ
	if (selected_item == GetE('chkLinkType_OpData').value) {
		// オープンデータ情報を属性値としてContextに保持し、編集完了時にPOST値としてセットする
		// オープンデータクラスが付与されているかチェック
		var tmp_class = oLink.$.getAttribute('class', '0');
		if(tmp_class == null){
			tmp_class = '';
		}
		if (tmp_class.match(/openDataFile/) == null) {
			if (tmp_class != '') {
				// 既に別のクラスが付与されている場合はスペースを入れる
				tmp_class += ' ';
			}
			// オープンデータのクラスを付与
			SetAttribute(oLink, 'class',  tmp_class + 'openDataFile');
		}
		SetAttribute(oLink, 'od_file_path', sUri);
		SetAttribute(oLink, 'od_link_target', od_link_target);
		SetAttribute(oLink, 'od_link_text', link_text_base);
		var category_check_box_ele = document.getElementsByName('opendata_category[]');
		var category_check_box_val = '';
		for (var i=0; i<category_check_box_ele.length; i++) {
			if (category_check_box_ele.item(i).checked) {
				category_check_box_val += category_check_box_ele.item(i).value + ',';
			}
		}
		category_check_box_val = category_check_box_val.substr(0, category_check_box_val.length-1);
		SetAttribute(oLink, 'od_category', category_check_box_val);
		SetAttribute(oLink, 'od_od_data_type', GetE('od_data_type').value);
		SetAttribute(oLink, 'od_keywords', GetE('opendata_keywords').value);
		SetAttribute(oLink, 'od_license', GetE('opendata_license').value);
		SetAttribute(oLink, 'od_pssy', GetE('pssy').value);
		SetAttribute(oLink, 'od_pssm', GetE('pssm').value);
		SetAttribute(oLink, 'od_pssd', GetE('pssd').value);
		SetAttribute(oLink, 'od_ptsy', GetE('ptsy').value);
		SetAttribute(oLink, 'od_ptsm', GetE('ptsm').value);
		SetAttribute(oLink, 'od_ptsd', GetE('ptsd').value);
		SetAttribute(oLink, 'od_summary', GetE('opendata_summary').value);
		SetAttribute(oLink, 'od_file_ext', FExp);
		SetAttribute(oLink, 'od_file_size', FSize);
	}
	else {
		// オープンデータのクラスを削除
		oLink.removeClass("openDataFile");

		// オープンデータ以外が選択されて完了の場合は、オープンデータのクラス、属性を削除する
		oLink.removeAttribute('od_file_path');
		oLink.removeAttribute('od_link_target');
		oLink.removeAttribute('od_link_text');
		oLink.removeAttribute('od_category');
		oLink.removeAttribute('od_od_data_type');
		oLink.removeAttribute('od_keywords');
		oLink.removeAttribute('od_license');
		oLink.removeAttribute('od_pssy');
		oLink.removeAttribute('od_pssm');
		oLink.removeAttribute('od_pssd');
		oLink.removeAttribute('od_ptsy');
		oLink.removeAttribute('od_ptsm');
		oLink.removeAttribute('od_ptsd');
		oLink.removeAttribute('od_summary');
		oLink.removeAttribute('od_file_ext');
		oLink.removeAttribute('od_file_size');
	}
	//Set (or restore) the innerHTML
	oLink.$.innerHTML = sInnerHtml;
	// Select the link.
	CKEDITOR.currentInstance.getSelection().selectElement(oLink);
}

//-------------------------------------------------
// モーダルダイアログを表示する
// 【引数】
// open_dlg : オープンするダイアログのID
// : 1 サイト内にリンク
// : 2 ファイルにリンク
// 【戻値】
// なし
// -------------------------------------------------
function showModal(open_dlg) {
	var newDlg;
	var Open_URL;
	var Open_Title;
	var Open_Width;
	var Open_Height;
	// サイト内リンク
	if (open_dlg == 1) {
		Open_URL = RPW + "/ckeditor/plugins/gd_link/fck_link/fck_sitelink.php"
				+ ((GetE('txtInUrl').value != "") ? ("?url=" + GetE('txtInUrl').value)
						: (""));
		Open_Title = "サイト内にリンク";
		Open_Width = 940;
		Open_Height = 680;
		Open_resize = 0;

	}
	//ファイルリンク
	else if (open_dlg == 2) {
		Open_URL = RPW + "/ckeditor/plugins/gd_link/fck_link/fck_filelink.php"
				+ ((GetE('txtFile').value != "") ? ("?url=" + encodeURL(GetE('txtFile').value))
						: (""));
		Open_Title = "ファイルにリンク";
		Open_Width = 660;
		Open_Height = 780;
		Open_resize = 0;
	}
	//ダイアログ表示
	cxIframeLayer(
		Open_URL,
		Open_Width,
		Open_Height,
		COVER_SETTING.COLOR,
		'',
		function (newURL) {
			//戻り値がundefined以外ならvalueにセット
			if (newURL != undefined) {
				$sel_item = Get_Sel_Item();
				if ($sel_item == GetE('chkLinkType_InUrl').value) {
					GetE('txtInUrl').value = newURL["url"]
							+ (newURL["anchor"] ? ("#" + newURL["anchor"]) : "");
				// オープンデータ
				} else if ($sel_item == GetE('chkLinkType_File').value || $sel_item == GetE('chkLinkType_OpData').value) {
					GetE('txtFile').value = newURL["url"];
					FExp = newURL["exp"];
					FSize = newURL["size"];
				}
			}
		}
	);
}

//-------------------------------------------------
// 現在選択されているリンクタイプを取得する
// 【引数】
// なし
// 【戻値】
// 現在選択されているリンクタイプのvalue名
// -------------------------------------------------
function Get_Sel_Item() {
	var ret;
	if (GetE('chkLinkType_Url').checked)
		ret = GetE('chkLinkType_Url').value;
	else if (GetE('chkLinkType_Email').checked)
		ret = GetE('chkLinkType_Email').value;
	else if (GetE('chkLinkType_File').checked)
		ret = GetE('chkLinkType_File').value;
	// オープンデータ
	else if (GetE('chkLinkType_OpData').checked) {
		ret = GetE('chkLinkType_OpData').value;
	}
	else if (GetE('chkLinkType_Anchor').checked)
		ret = GetE('chkLinkType_Anchor').value;
	else if (GetE('chkLinkType_Tel').checked)
		ret = GetE('chkLinkType_Tel').value;
	else
		ret = GetE('chkLinkType_InUrl').value;
	return ret;
}

//-------------------------------------------------
// E-Mailを含んだURLを分割する
// 【引数】
// emailUrl : E-Mailを含んだURL
// 【戻値】
// 分割したEMailオブジェクト
// -------------------------------------------------
function ParseEMailUrl(emailUrl) {
	//Initializes the EMailInfo object.
	var oEMailInfo = new Object();
	oEMailInfo.Address = '';
	oEMailInfo.Subject = '';
	oEMailInfo.Body = '';

	var oParts = emailUrl.match(/^([^\?]+)\??(.+)?/);
	if (oParts) {
		//Set the e-mail address.
		oEMailInfo.Address = oParts[1];
		// Look for the optional e-mail parameters.
		if (oParts[2]) {
			var oMatch = oParts[2].match(/(^|&)subject=([^&]+)/i);
			if (oMatch)
				oEMailInfo.Subject = unescape(oMatch[2]);
			oMatch = oParts[2].match(/(^|&)body=([^&]+)/i);
			if (oMatch)
				oEMailInfo.Body = unescape(oMatch[2]);
		}
	}
	return oEMailInfo;
}

//-------------------------------------------------
// E-Mailを含んだURLを作成する
// 【引数】
// address : メールアドレス
// subject : 題名
// body : 本文
// 【戻値】
// E-Mailを含んだURL
// -------------------------------------------------
function CreateEMailUri(address, subject, body) {
	var sBaseUri = 'mailto:' + address;
	var sParams = '';

	if (subject.length > 0)
		sParams = '?subject=' + escape(subject);

	if (body.length > 0) {
		sParams += (sParams.length == 0 ? '?' : '&');
		sParams += 'body=' + escape(body);
	}
	return sBaseUri + sParams;
}

//-------------------------------------------------
// 文字列をURLエンコードする(UTF-8)
// 【引数】
// str : エンコードしたい文字列
// 【戻値】
// エンコードした文字列
// -------------------------------------------------
function encodeURL(str) {
	var character = '';
	var unicode = '';
	var string = '';
	var i = 0;
	for (i = 0; i < str.length; i++) {
		character = str.charAt(i);
		unicode = str.charCodeAt(i);
		if (character == ' ')
			string += '+';
		else {
			if (unicode == 0x2a || unicode == 0x2d || unicode == 0x2e
					|| unicode == 0x5f
					|| ((unicode >= 0x30) && (unicode <= 0x39))
					|| ((unicode >= 0x41) && (unicode <= 0x5a))
					|| ((unicode >= 0x61) && (unicode <= 0x7a))) {
				string = string + character;
			} else {
				if ((unicode >= 0x0) && (unicode <= 0x7f)) {
					character = '0' + unicode.toString(16);
					string += '%' + character.substr(character.length - 2);
				} else if (unicode > 0x1fffff) {
					string += '%' + (oxf0 + ((unicode & 0x1c0000) >> 18))
							.toString(16);
					string += '%' + (0x80 + ((unicode & 0x3f000) >> 12))
							.toString(16);
					string += '%' + (0x80 + ((unicode & 0xfc0) >> 6))
							.toString(16);
					string += '%' + (0x80 + (unicode & 0x3f)).toString(16);
				} else if (unicode > 0x7ff) {
					string += '%' + (0xe0 + ((unicode & 0xf000) >> 12))
							.toString(16);
					string += '%' + (0x80 + ((unicode & 0xfc0) >> 6))
							.toString(16);
					string += '%' + (0x80 + (unicode & 0x3f)).toString(16);
				} else {
					string += '%' + (0xc0 + ((unicode & 0x7c0) >> 6))
							.toString(16);
					string += '%' + (0x80 + (unicode & 0x3f)).toString(16);
				}
			}
		}
	}
	return string;
}
