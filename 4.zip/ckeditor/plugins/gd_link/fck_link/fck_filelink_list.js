/*
 * ファイルリンク：登録ファイル検索画面　fck_filelink_list.js
 */

// イメージ読み込み
cxPreImages(cms8341admin_path + '/images/fcklink/title_filelinkset.jpg',
		cms8341admin_path + '/images/fcklink/btn_close.jpg',
		cms8341admin_path + '/images/fcklink/tab_pc_off.jpg',
		cms8341admin_path + '/images/fcklink/tab_server_on.jpg',
		cms8341admin_path + '/images/fcklink/bar_filesearch.jpg',
		cms8341admin_path + '/images/fcklink/btn_search.jpg',
		cms8341admin_path + '/images/fcklink/bar_filelist.jpg',
		cms8341admin_path + '/images/fcklink/btn_setup_on.jpg');

// 親画面にオブジェクトを返す
function cxReturn(id) {
	// オブジェクト作成
	var retObj = new Object();

	// 代入
	retObj['url'] = $F('cms_ffl_url_' + id);
	retObj['exp'] = $F('cms_ffl_exp_' + id);
	retObj['size'] = $F('cms_ffl_size_' + id);

	// 親画面に値を渡す
	cxIframeLayerCallback(retObj);
}

// プロパティを開く
function cxShowProperty(id) {
	cxIframeLayer(
		RPW + "/ckeditor/plugins/gd_link/fck_link/fck_filelink_property.php?id=" + id,
		460,
		320,
		COVER_SETTING.COLOR,
		'',
		function (pObj) {
			// 戻り値がundefined以外なら再検索
			if (pObj != undefined)
				cxSearch();
		}
	);
}

// 検索ボタン押下後サブミット
function cxSearch() {
	document.cms_fck_link_list.submit();
	return false;
}

/**
 * 指定されたファイルを削除する
 * @param id ファイルのID
 * @param name ファイルの名称
 * @return false
 */
function cxDeleteFile(id, name) {
	//確認用ダイアログを表示
	if (confirm(name + "を削除します。よろしいですか？")) {
		//削除実行PHPを呼び出す(Ajax)
		var a = new Ajax.Request(
				baseUrl + 'ckeditor/plugins/gd_link/fck_link/fck_filelink_delete.php',
				{
					method : 'post',
					postBody : 'cms_file_id=' + id,
					//成功した場合
					onComplete : function(originalRequest) {
						if (originalRequest.responseText != "")
							alert(originalRequest.responseText);
						else
							cxSearch();
					},
					//失敗した場合
					onFailure : function(request) {
						alert(name + 'の削除に失敗しました');
					}
				});
	}
	return false;
}

/**
 * ページ番号をPOSTする
 * @param page ページ番号
 * @return false
 */
function cxPageSet(page) {
	$('cms_page_post').cms_page.value = page;
	$('cms_page_post').maxrow.value = $('dispNum').value;
	$('cms_page_post').submit();
	return false;
}

/**
 * 表示件数を変える
 * @param prev_num 表示件数
 * @return false
 */
function cxDispNum(prev_num) {
	$('cms_page_post').cms_page.value = 1;
	$('cms_page_post').maxrow.value = prev_num;
	$('cms_page_post').submit();
	return false;
}
