<?php
/**
 * サイト内リンク 検索結果画面
 */
require ("../.htsetting");
global $objCnc;
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/page_control.inc');
$objPage = new tbl_page($objCnc);
$objP = new page_control();

//
$user_class = $objLogin->get('class');

//	//非公開のページは対象外
//作業区分が削除 or 非公開のページは対象外
$where = $objPage->_addslashesC("p.work_class", WORK_CLASS_DELETE, "<>", "INT") . " AND " . $objPage->_addslashesC("p.close_flg", FLAG_ON, "<>", "INT");
//HTML出力フラグがOFFのページは対象外
$where .= " AND NOT(" . $objPage->_addslashesC("p.output_html_flg", FLAG_OFF, "<=>", "INT") . ')';
$where .= " AND NOT(" . $objPage->_addslashesC("sub.output_html_flg", FLAG_OFF, "<=>", "INT") . ')';
// ページID検索
if (!empty($_POST['cms_search_page_id'])) {
	$search_page_id = explode(' ', preg_replace('/\s+/', ' ', $_POST['cms_search_page_id']));
	$where .= " AND " . $objPage->_addslashesC('p.page_id', implode(',', $search_page_id), 'IN', 'INT');
}
// ページタイトル
if (isset($_POST['cms_search_page_title']) && $_POST['cms_search_page_title'] != "") {
	foreach (explode(' ', preg_replace('/[\\s]+/', ' ', preg_replace('/^[\\s]+|[\\s]+$/', '', str_replace('　', ' ', $_POST['cms_search_page_title'])))) as $val) {
		$where .= " AND " . $objPage->_addslashesC("p.page_title", "%" . $val . "%", "LIKE");
	}
}
//フィイルパス
if (isset($_POST['cms_file_path']) && $_POST['cms_file_path'] != "") $where .= " AND " . $objPage->_addslashesC("p.file_path", "%" . $_POST['cms_file_path'] . "%", "LIKE");
//更新期間（開始）
if (isset($_POST['cms_upsy']) && $_POST['cms_upsy'] != "" && isset($_POST['cms_upsm']) && $_POST['cms_upsm'] != "" && isset($_POST['cms_upsd']) && $_POST['cms_upsd'] != "") {
	$update = $_POST['cms_upsy'] . "/" . $_POST['cms_upsm'] . "/" . $_POST['cms_upsd'] . " 00:00:00";
	$where .= " AND " . $objPage->_addslashesC("p.update_datetime", $update, ">=");
}
//更新期間（終了）
if (isset($_POST['cms_upey']) && $_POST['cms_upey'] != "" && isset($_POST['cms_upem']) && $_POST['cms_upem'] != "" && isset($_POST['cms_uped']) && $_POST['cms_uped'] != "") {
	$update = $_POST['cms_upey'] . "/" . $_POST['cms_upem'] . "/" . $_POST['cms_uped'] . " 23:59:59";
	$where .= " AND " . $objPage->_addslashesC("p.update_datetime", $update, "<=");
}
//自分が作成したページ／全てのページ
if (isset($_POST['cms_target']) && $_POST['cms_target'] == 0) $where .= " AND " . $objPage->_addslashesC("p.user_id", $objLogin->get("user_id"));
//公開済みのページ／新規作成中のページ
if (isset($_POST['cms_table']) && $_POST['cms_table'] != "") $table = $_POST['cms_table'];
if (!isset($table) || $table == "") $table = PUBLISH_TABLE;
//ウェブマスター以外／全てのページ 新規作成中のページは対象外
if ($user_class != USER_CLASS_WEBMASTER && isset($_POST['cms_target']) && $_POST['cms_target'] == 1) {
	$table = PUBLISH_TABLE;
	$where .= " AND " . $objPage->_addslashesC("p.work_class", WORK_CLASS_PUBLISH, '=', 'INT');
} //公開済みのページ／新規作成中のページ
else if (isset($table) && in_array($table, array(
		PUBLISH_TABLE, 
		WORK_TABLE
))) {
	if ($table == PUBLISH_TABLE) $where .= " AND " . $objPage->_addslashesC("p.work_class", WORK_CLASS_PUBLISH . ',' . WORK_CLASS_DELETE, 'IN', 'INT');
	else $where .= " AND " . $objPage->_addslashesC("p.work_class", WORK_CLASS_NEW, '=', 'INT');
} //その他
else
	$where .= " AND " . $objPage->_addslashesC("p.work_class", WORK_CLASS_PUBLISH, '=', 'INT');
	// 組織検索
if (isset($_POST['cms_target']) && $_POST['cms_target'] == 1) {
	if ($_POST['cms_department3'] != "") $where .= " AND " . $objPage->_addslashesC("u.dept_code", $_POST['cms_department3'], "LIKE", "TEXT");
	elseif ($_POST['cms_department2'] != "") $where .= " AND " . $objPage->_addslashesC("u.dept_code", substr($_POST['cms_department2'], 0, CODE_DIGIT_DEPT * 2) . "%", "LIKE", "TEXT");
	elseif ($_POST['cms_department1'] != "") $where .= " AND " . $objPage->_addslashesC("u.dept_code", substr($_POST['cms_department1'], 0, CODE_DIGIT_DEPT) . "%", "LIKE", "TEXT");
}
// キーワード検索
if (isset($_POST['cms_search_keywords']) && $_POST['cms_search_keywords'] != ""){
	// タグを対象にするかどうか
	$is_tag_search = (isset($_POST['cms_is_tag_search']) && $_POST['cms_is_tag_search'] == FLAG_ON) ? TRUE : FALSE;
	foreach (explode(' ', preg_replace('/[\\s]+/', ' ', preg_replace('/^[\\s]+|[\\s]+$/', '', str_replace('　', ' ', $_POST['cms_search_keywords'])))) as $val) {
		$where .= " AND " . $objPage->_addslashesC('p.page_id', $objPage->mk_sql_kewords($table, 'DISTINCT page.page_id', $val, $is_tag_search), "IN");
	}
}
//「公開済みのページ」検索用情報の作成
if ($table == PUBLISH_TABLE) {
	$filed = "p.*";
	$table = "tbl_publish_page AS p LEFT JOIN tbl_work_page AS sub ON (p.page_id = sub.page_id)";
} //「新規作成中のページ」検索用情報の作成
else {
	$filed = "p.*, sub.file_path";
	$table = "tbl_work_page AS p LEFT JOIN tbl_publish_page AS sub ON (p.page_id = sub.page_id)";
}

$filed .= ",d.*";
$table .= " LEFT JOIN tbl_user AS u ON (p.user_id = u.user_id)";
$table .= " LEFT JOIN tbl_department AS d ON (u.dept_code = d.dept_code)";

$cnt = $objPage->getCount($where, $table);
$disp_num = (isset($_POST['cms_disp_num'])) ? $_POST['cms_disp_num'] : "10";
$objP->limit = $disp_num;
$page_no = (isset($_POST['cms_page_no'])) ? $_POST['cms_page_no'] : "1";
$objP->set($page_no, $cnt);
$offset = $objP->getOffset();
$limit = $objP->getLimit();
//検索実行
$objPage->select($where, $filed, '', $offset, $limit, $table);

//結果の作成
$data = "";
$tmp_data = "";
//検索結果が0件の場合
if ($objPage->getRowCount() == 0) $tmp_data .= '<tr><td style="padding:5px; border-bottom: solid 1px #000000;">対象ページはありません。</td>';
//検索結果が0件でない場合
else {
	//指定件数以上の場合は、エラーを表示
	if ($objPage->getRowCount() >= FCK_SITELINK_SEARCH_MAX_COUNT) $data .= '<div style="margin:0px;padding:5px;border:solid 1px #000000;color:#FF0000;font-size:14px;">検索結果が多すぎます。検索条件を追加して、検索しなおしてください。</div>';
	//検索結果部分の作成
	$loop_cnt = 0;
	while ($loop_cnt < FCK_SITELINK_SEARCH_MAX_COUNT && $objPage->fetch()) {
		$fld = $objPage->fld;
		$tmp_data .= '<tr style=""><td style="padding:5px; border-bottom: solid 1px #000000;">';
		//アイコン情報を取得
		$ret_ary = get_status_icon($fld);
		$tmp_data .= '<img src="' . RPW . '/admin/images/treelist/' . $ret_ary['wc_img'] . '" alt="' . $ret_ary['wc_alt'] . '" width="59" height="16" class="icon">&nbsp;';
		//タイトルを表示
		$tmp_data .= '<a href="' . RPW . $objPage->fld['file_path'] . '"><strong>' . htmlDisplay($fld['page_title']) . '</strong></a><br>';
		//組織を表示
		if ($user_class == USER_CLASS_WEBMASTER) {
			$tmp_data .= '組織：' . htmlDisplay($objPage->fld['dept_name']) . '<br>';
		}
		//新規作成中のページは、公開期間&公開中ページへのパス表示しない
		//大規模災害状態でない場合は大規模災害用ページが公開されていないため表示しない
		if ($fld['work_class'] != WORK_CLASS_NEW && (isDisasterFlg() || !isDisasterPage($fld['page_id']))) {
			//公開期間の表示なし
			$tmp_data .= '公開期間：' . htmlDisplay(dtFormat($fld['publish_start'])) . 'から' . htmlDisplay(get_publish_end_date($fld['publish_end'])) . "まで<br>";
			//公開ページへのパスなし
			$tmp_data .= '<img src="' . RPW . '/admin/images/btn/btn_pubpage.jpg" alt="公開中ページ" width="80" height="20" class="cms8341-verticalMiddle">&nbsp;&nbsp;<a href="' . HTTP_REAL_ROOT . $fld['file_path'] . '" target="_blank">' . HTTP_REAL_ROOT . $fld['file_path'] . "</a><br>";
		}
		$tmp_data .= '</td></tr>';
		$loop_cnt++;
	}
}

if ($objPage->getRowCount() > 0) {
	$data .= '<hr><br>';
	$data .= '<input type="hidden" name="cms_page_no" id="cms_page_no" value="' . $page_no . '">';
	$data .= '<table align = "center" width="97%" border="0" cellspacing="0" cellpadding="0" style="margin-bottom:10px;padding:1px">';
	$data .= '<tr valign="top">';
	$data .= '<td colspan="3" align="right">';
	$data .= mkcombobox($MAXROW_LIST, "cms_disp_num", $disp_num, "cxDispNum(this.value)");
	$data .= '</td>';
	$data .= '</tr>';
	$data .= '<tr>';
	$data .= '<td width="30%" align="left" valign="middle" scope="row">' . $objP->getBackLink() . '</td>';
	$data .= '<td width="40%" align="center" valign="middle">' . $objP->getViewCount() . '</td>';
	$data .= '<td width="30%" align="right" valign="middle">' . $objP->getNextLink() . '</td>';
	$data .= '</tr>';
	$data .= '</table>';
}
//検索結果部分のヘッダの作成
$data .= '<table width="97%" align = "center" border="0" cellpadding="0" cellspacing="0" class="cms8341-dataTable" style="margin: 10px;font-size:12px; border-left:solid 1px #000000; border-top:solid 1px #000000; border-right:solid 1px #000000;">' . $tmp_data . '</table>';
if ($objPage->getRowCount() > 0) {
	$data .= '<table align = "center" width="97%" border="0" cellspacing="0" cellpadding="0" style="margin-bottom:10px;padding:1px">';
	$data .= '<tr>';
	$data .= '<td width="30%" align="left" valign="middle" scope="row">' . $objP->getBackLink() . '</td>';
	$data .= '<td width="40%" align="center" valign="middle">' . $objP->getViewCount() . '</td>';
	$data .= '<td width="30%" align="right" valign="middle">' . $objP->getNextLink() . '</td>';                    
	$data .= '</tr>';
	$data .= '</table>';
	$data .= '<br>';
}
//HTMLの作成
$htmlStr = '<html><head></head><body><div style="width:99%;height:100%;margin-bottom:1px;">' . $data . '</div></body></html>';

// サイト内リンク用のインクルードファイルを読み込み
require_once ('./fck_sitelink_common.inc');
// 検索条件をセッションに登録
setSession($_POST);
// HTMLの作成
createHtml($htmlStr);
print $htmlStr;
?>	
