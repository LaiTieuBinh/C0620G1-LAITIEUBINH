<?php
/*
 * ファイルのアップロードを行う
 */
//設定ファイル読み込み
require_once ("../.htsetting");

//エラー画面設定 別ウィンドウ用
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

//DBアクセス用ファイルの読み込み
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_links.inc');
$objFCKLinks = new tbl_fck_links($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_shared_upload.inc');
$objShared = new tbl_shared_upload($objCnc);

//変数の初期化
//処理モード 0:画面表示 1:設定して画面を閉じる
$Mode = 0;
$Html = "";
$err_msg = "";
$base_path = ""; //フォルダパス
$real_base_path = DOCUMENT_ROOT . RPW;
$file_path = ""; //ファイルパス
$real_file_path = DOCUMENT_ROOT . RPW;

//フォルダパスの取得
//SESSIONを取得できる場合
if (isset($_SESSION['cms_page_id']) && $_SESSION['cms_page_id'] != "") {
	//パス取得
	if ($objPage->selectFromID($_SESSION['cms_page_id'], WORK_TABLE, "file_path") !== FALSE) {
	}
	else if ($objPage->selectFromID($_SESSION['cms_page_id'], PUBLISH_TABLE, "file_path") !== FALSE) {
	}
	else
		user_error('ページ情報を取得できませんでした。', E_USER_ERROR);
	$base_path = cms_dirname($objPage->fld['file_path']) . FCK_FILELINK_FORDER;
	$real_base_path .= $base_path;
}
elseif (isset($_SESSION['cms_sitemap_linkset'])) {
	$real_base_path .= FCK_FILELINK_FORDER_SITEMAP;
}
else {
	$real_base_path .= FCK_FILELINK_FORDER_LIBRARY;
}

//モード切替
if (!isset($_POST['cms_filelink_name']) || (isset($_POST['cms_filelink_name']) && $_POST['cms_filelink_name'] == "")) $Mode = 0;
else if (!isset($_FILES['cms_filelink_path']) || (isset($_FILES['cms_filelink_path']) && $_FILES['cms_filelink_path'] == NULL)) $Mode = 0;
else $Mode = 1;

//処理モードが1なら設定
if ($Mode == 1) {
	//アップロードファイル
	$Up_File = $_FILES['cms_filelink_path'];
	$file_name = "";
	
	//ファイルパスの設定
	//リネームが存在した場合、リネームされたファイル名を使用する
	if (isset($_POST['rename_file_path']) && $_POST['rename_file_path'] != "") $file_name = strtolower(basename($_POST['rename_file_path']));
	else $file_name = strtolower($Up_File['name']);
	if (isset($_SESSION['cms_page_id']) && $_SESSION['cms_page_id'] != "") {
		$file_path = $base_path . "/" . $file_name;
		$real_file_path .= $file_path;
	}
	elseif (isset($_SESSION['cms_sitemap_linkset'])) {
		$file_path = FCK_FILELINK_FORDER_SITEMAP . "/" . $file_name;
		$real_file_path .= $file_path;
	}
	else {
		$file_path = FCK_FILELINK_FORDER_LIBRARY . "/" . $file_name;
		$real_file_path .= $file_path;
	}
	if (file_exists($real_file_path)) {
		$overwrite = TRUE;
	} else {
		$overwrite = FALSE;
	}
	//エラー処理を行うため、whileを使用
	while (true) {
		//同名ファイルの確認
		//リネームか上書きか選択できるようにしたためコメント化
		/*if(@file_exists($real_file_path)){
				$err_msg = "保存先フォルダに同名のファイルが存在します。";
				$real_file_path = "";
			}
			//エラーがあれば、抜ける
			if($err_msg != "") break;*/
		
		//ファイルチェック
		if (!is_uploaded_file($Up_File["tmp_name"])) $err_msg = "不正なファイルが選択されています。";
		//ファイルエラーチェック
		if ($Up_File["error"] != UPLOAD_ERR_OK) $err_msg = "ファイルのアップロードに失敗しました。";
		//拡張子チェック
		$File_Exte = explode(",", DENIED_EXTENSIONS_FILE);
		foreach ($File_Exte as $exte) {
			if (preg_match('/(\.' . $exte . ')$/i', $file_name)) $err_msg = "指定されたファイルはアップロードすることが出来ません。";
		}
		//ファイル名チェック
		//使用不可の記号チェック
		if (preg_match('/[^\w\-_\.~]/i', $file_name)) $err_msg = "アップロードできないファイル名です。ファイル名に使用できるのは半角英数字と - _ . ~ です。";
		//「.」が複数含まれているかチェック
		if (strpos($file_name, '.') != strrpos($file_name, '.')) $err_msg = "ファイル名に「.」が二つ以上ついているファイルはアップロードすることが出来ません。";
		//「.」がファイル名の先頭に含まれているかチェック
		if (strpos($file_name, '.') == 0) $err_msg = "ファイル名にの先頭に「.」がついているファイルはアップロードすることが出来ません。";
		//ファイルサイズチェック
		//0byte以下のファイルチェック
		if ($Up_File["size"] <= 0) $err_msg = "ファイルサイズが0バイトのファイルは取り込めません。";
		//ファイルMAXサイズチェック
		if (is_none_check_dir($real_file_path) === FALSE && $Up_File["size"] > FCK_UPLOAD_MAX_FILE * 1024) $err_msg = "ファイルサイズが大き過ぎます。";
		//エラーがあれば、抜ける
		if ($err_msg != "") break;
		
		//ファイルの移動処理
		//フォルダが存在しなければ、フォルダを作成
		if (!is_dir($real_base_path)) {
			if (!@mkdir($real_base_path, 0777)) $err_msg = "ファイルのアップロードに失敗しました。";
		}
		//エラーがあれば、抜ける
		if ($err_msg != "") break;
		
		//ファイルの移動
		if (@move_uploaded_file($Up_File["tmp_name"], ($real_file_path))) chmod($real_file_path, 0777);
		else $err_msg = "ファイルのアップロードに失敗しました。";
		//エラーがあれば、抜ける
		if ($err_msg != "") break;
		
		//登録処理
		$Up_File_Info = pathinfo($real_file_path);
		//登録用配列の設定
		$filedtl_ary = array();
		$filedtl_ary["name"] = $_POST['cms_filelink_name']; //ファイル名称
		$filedtl_ary["path"] = $file_path; //ファイルパス
		$filedtl_ary["file_exte"] = $Up_File_Info['extension']; //ファイル拡張子
		$filedtl_ary["file_size"] = $Up_File['size']; //ファイルサイズ
		//登録処理
		$objCnc->begin();
		//「tbl_fck_links」に同じパスが存在する場合、削除する
		if ($objFCKLinks->selectFCKFileLink($file_path)) {
			if (!$objFCKLinks->deleteFromPageID($file_path)) $err_msg = "データベースの更新に失敗しました。";
		}
		//「tbl_fck_links」にアップロードしたファイル情報の登録
		if (!$objFCKLinks->insert($filedtl_ary)) $err_msg = "データベースへの登録に失敗しました。";
		// handle tbl_shared_upload
		if (preg_match('/^(' . reg_replace(FCK_FILELINK_FORDER_SITEMAP) . '|' . reg_replace(FCK_FILELINK_FORDER_LIBRARY) . ')/i', $file_path)) {
			$upload_class = ($overwrite) ? $objShared::SHARED_OVERWRITE : $objShared::SHARED_NEW;
			$err_msg = $objShared->add_data($file_path, $upload_class);
		}
		//エラーが無ければ、登録する
		if ($err_msg == "") {
			// アップロードしたファイルリストに追加
			if (!isset($_SESSION['depend']['uplist']) || !in_array($file_path, $_SESSION['depend']['uplist'])) $_SESSION['depend']['uplist'][] = $file_path;
			$objCnc->commit();
		}
		//エラーがあれば元に戻す
		else
			$objCnc->rollback();
		break;
	}
	
	//エラーメッセージがあれば、通常表示
	if ($err_msg != "") {
		if (@file_exists($real_file_path)) @unlink($real_file_path);
		$Mode = 0;
	}
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ファイルにリンク</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/normalize.css" type="text/css">
<link rel="stylesheet" href="<?=RPW?>/ckeditor/gd_files/css/grid.css" type="text/css">
<link rel="stylesheet" href="<?=RPW?>/ckeditor/gd_files/css/dialog.css" type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
			<!--
				var mode = <?=$Mode?>;
				var err_msg = '<?php
				print((isset($err_msg) ? $err_msg : ""));
				?>';
				var ofile = new Object();
				ofile["name"] = '<?php
				print((isset($_POST["cms_filelink_name"]) ? javaStringEscape($_POST["cms_filelink_name"]) : ""));
				?>';
				ofile["path"] = '<?php
				print((isset($file_path) ? javaStringEscape($file_path) : ""));
				?>';
				ofile["exp"] = '<?php
				print((isset($Up_File_Info["extension"]) ? javaStringEscape($Up_File_Info["extension"]) : ""));
				?>';
				ofile["size"] = '<?php
				print((isset($Up_File["size"]) ? javaStringEscape($Up_File["size"]) : ""));
				?>';
				<?php
				echo loadSettingVars();
				?>
			// -->
		</script>
<script src="fck_filelink_upload.js" type="text/javascript"></script>
<base target="_self" />
</head>
<body>
<div class="cke_dialog_title">ファイルにリンク<a	href="javascript:cxIframeLayerCallback()" id="header_close" style="float: right; margin-top: 2px;"><img src="<?=RPW?>/ckeditor/skins/moono-lisa/images/close.png" alt="閉じる"></a></div>
<div id="cms8341-headareaZero" style="margin-bottom: 0px !important">
<table width="100%" height="100%" border="0" cellspacing="0"
	cellpadding="0">
	<tr>
		<td width="100%">
		<div id="cms8341-tab"  class="cke_dialog_tabs">
		<table border="0" cellspacing="0" cellpadding="0"
			style="border-collapse: collapse;">
			<tr>
				<td><a  class="cke_dialog_tab cke_dialog_tab_selected"><span>PCから選んで登録</span></a></td>
				<td><a class="cke_dialog_tab" href="fck_filelink_list.php"><span>登録済ファイルから選択</span></a></td>
			</tr>
		</table>
		</div>
		<table width="100%" height="93%" cellspacing="0" cellpadding="0" class="cke_dialog_contents">
			<tr>
				<td valign="top">
				<form name="cms_fck_link_upload" id="cms_fck_link_upload"
					action="fck_filelink_upload.php" method="post"
					enctype="multipart/form-data"
					onsubmit="cxSubmit('<?=$real_base_path?>'); return false;">
				<table width="90%" border="0" cellspacing="0" cellpadding="5"
					align="center" class="cms8341-dataTable"
					style="border-collapse: collapse; margin-top: 20px;">
					<tr>
						<th width="30%" align="left" valign="top"
							style="border-top: none; border-left: none;" nowrap><span  class="cke_dialog_ui_labeled_label" >ファイル名称</span>
						
						
						</td>
						<td width="70%" valign="top" style="border-left: none;"><input
							id="cms_filelink_name" name="cms_filelink_name"
							style="WIDTH: 98%;" type="text" maxlength="64"  class="cke_dialog_ui_input_text" 
							value="<?php
							print((isset($_POST['cms_filelink_name']) ? htmlDisplay($_POST['cms_filelink_name']) : ""));
							?>">
						</td>
					</tr>
					<tr>
						<th width="30%" align="left" valign="top"
							style="border-top: none;" nowrap><span  class="cke_dialog_ui_labeled_label" >ファイル</span>
						
						
						</td>
						<td style="border-top: none; border-left: none;">
							<label width="10%" for="cms_filelink_path" class="cke_dialog_ui_button cke_dialog_ui_button_padding" style="margin-left: 1px;">参照</label><input
							id="cms_filelink_path" name="cms_filelink_path"  style="visibility:hidden; display: none;"  type="file"
							style="WIDTH: 98%;"> <span type="text"id="file-selected"></span></td>
							<script> var filetype = document.getElementById("cms_filelink_path"); filetype.onchange = function(){ var fileName = ""; fileName = filetype.value; document.getElementById("file-selected").innerHTML = fileName.replace(/^.*[\\\/]/, ""); };</script>
					</tr>
				</table>
				<br />
				<br />
				<div align="center">
				<input  type="submit" class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_grey"
					value="設定"></div>
				<input type="hidden" id="rename_file_path" name="rename_file_path">
											<?php
											print($objTool->setAccessibility());
											?>
										</form>
				</td>
			</tr>
		</table>
		</div>
		</td>
	</tr>
</table>
</div>
</body>
</html>
