<?php
/**
 * ファイルリンク：登録ファイル検索画面　fck_filelink_list.php
 */
// -- 設定ファイル -- //
require ("../.htsetting");

// -- エラー画面設定 -- //
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

// -- インクルード -- //
global $objCnc;
global $objLogin;

require_once (APPLICATION_ROOT . "/common/dbcontrol/commands.inc");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_links.inc');
$objFCKLinks = new tbl_fck_links($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/page_control.inc');
$objP = new page_control();
require_once (APPLICATION_ROOT . '/common/dbcontrol/b_dac.inc');

// -- 初期化 -- //


// ページ内定数
define("FCK_LINK_CATE_NOW", 0); // 分類条件用(現在の場所)
define("FCK_LINK_CATE_SHARED", 1); // 分類条件用(共通ファイル)
$MAXROW_LIST = getDefineArray("MAXROW_LIST");

// 拡張子
$IMGDIR = RPW . "/admin/images/fcklink/";
$aryIcon = array(
	'ai', 
	'avi', 
	'bmp', 
	'cs', 
	'dll', 
	'doc', 
	'exe', 
	'fla', 
	'gif', 
	'htm', 
	'html', 
	'jpg', 
	'js', 
	'mdb', 
	'mp3', 
	'pdf', 
	'ppt', 
	'rdp', 
	'swf', 
	'txt', 
	'vsd', 
	'xls', 
	'xml', 
	'zip', 
	'docx', 
	'xlsx', 
	'pptx'
);

define("CMS_POST", "cms_fck_link_");

//変数の宣言
$page = 0; //ページ番号
$maxRow = 0; //1ページに表示される最大表示件数


$search = array(
		"path" => "", 
		"category" => FCK_LINK_CATE_NOW, 
		"keyword" => "", 
		"exte_pdf" => FLAG_OFF, 
		"exte_doc" => FLAG_OFF, 
		"exte_xls" => FLAG_OFF, 
		"exte_etc" => FLAG_OFF, 
		"update_datetime" => FLAG_OFF
);

// POST値取得
foreach ($_POST as $k => $v) {
	$k = str_replace(CMS_POST, "", $k);
	$search[$k] = $v;
}
$page = (isset($_POST['cms_page']) && is_numeric($_POST['cms_page']) ? floor($_POST['cms_page']) : 1);
$maxRow = (isset($_POST['maxrow']) && is_numeric($_POST['maxrow']) ? floor($_POST['maxrow']) : key($MAXROW_LIST));

// SESSION取得
$search['path'] = "";
// SESSIONを取得できる場合
if (isset($_SESSION['cms_page_id'])) {
	// 作業テーブルよりパス取得
	if ($objPage->selectFromID($_SESSION['cms_page_id'], WORK_TABLE, "file_path") !== FALSE) {
		$search['path'] = cms_dirname($objPage->fld['file_path']);
	}
	// 公開テーブルよりパス取得
	else if ($objPage->selectFromID($_SESSION['cms_page_id'], PUBLISH_TABLE, "dir_path") !== FALSE) {
		$search['path'] = ($objPage->fld['dir_path'] == "/" ? "" : $objPage->fld['dir_path']);
	}
	//ページ情報を取得できない場合、エラー
	else
		user_error("ページ情報の取得に失敗しました。", E_USER_ERROR);
}

// -- 検索条件作成 -- //
$where = "";

// 分類
$search_path = "";
switch ($search['category']) {
	// 現在の場所
	case FCK_LINK_CATE_NOW :
		if (isset($_SESSION['cms_page_id'])) {
			$search_path = $search['path'] . FCK_FILELINK_FORDER;
		}
		elseif (isset($_SESSION['cms_sitemap_linkset'])) {
			$search_path = FCK_FILELINK_FORDER_SITEMAP;
		}
		else {
			$search_path = FCK_FILELINK_FORDER_LIBRARY;
		}
		$search_path = str_replace('//', '/', $search_path);
		break;
	// 共通ファイル
	case FCK_LINK_CATE_SHARED :
		$search_path = FCK_FILELINK_FORDER_SHARED;
		$search_path = str_replace('//', '/', $search_path);
		break;
}
$where .= " AND " . $objFCKLinks->_addslashesC("path", $search_path . "/%", "LIKE");

// GETを取得できる場合
if (isset($_GET['url'])) {
	// パスで検索
	$search['path'] = preg_replace('/^' . preg_quote(RPW, "/") . '/', '', $_GET['url']);
	$where = " AND " . $objFCKLinks->_addslashesC("path", $search['path']);
}

// キーワード --
// 文字列が存在すれば検索条件セット
if (strlen($search['keyword']) > 0) {
	$keyword = explode(" ", str_replace("　", " ", $search['keyword']));
	foreach ($keyword as $k => $v) {
		if (strlen($v) > 0) {
			$v = javaStringEscape($v);
			$where .= ' AND (' . $objFCKLinks->_addslashesC("name", "%" . $v . "%", "LIKE");
			$where .= ' OR ' . $objFCKLinks->_addslashesC("path", "%" . $v . "%", "LIKE") . ")";
		}
	}
}

// ファイル形式 --
$exte_where = "";
if ($search['exte_etc'] != $search['exte_doc'] || $search['exte_etc'] != $search['exte_xls'] || $search['exte_etc'] != $search['exte_pdf']) {
	// その他チェックあり
	if ($search['exte_etc'] == FLAG_ON) {
		// PDF
		if ($search['exte_pdf'] == FLAG_OFF) {
			$exte_where .= " AND " . $objFCKLinks->_addslashesC("file_exte", "pdf", "!=");
		}
		// ワード
		if ($search['exte_doc'] == FLAG_OFF) {
			$exte_where .= " AND " . $objFCKLinks->_addslashesC("file_exte", "doc", "!=");
			$exte_where .= " AND " . $objFCKLinks->_addslashesC("file_exte", "docx", "!=");
		}
		// エクセル
		if ($search['exte_xls'] == FLAG_OFF) {
			$exte_where .= " AND " . $objFCKLinks->_addslashesC("file_exte", "xls", "!=");
			$exte_where .= " AND " . $objFCKLinks->_addslashesC("file_exte", "xlsx", "!=");
		}
	}
	// その他チェックなし
	else {
		// PDF
		if ($search['exte_pdf'] == FLAG_ON) {
			$exte_where .= " OR " . $objFCKLinks->_addslashesC("file_exte", "pdf", "=");
		}
		// ワード
		if ($search['exte_doc'] == FLAG_ON) {
			$exte_where .= " OR " . $objFCKLinks->_addslashesC("file_exte", "doc", "=");
			$exte_where .= " OR " . $objFCKLinks->_addslashesC("file_exte", "docx", "=");
		}
		// エクセル
		if ($search['exte_xls'] == FLAG_ON) {
			$exte_where .= " OR " . $objFCKLinks->_addslashesC("file_exte", "xls", "=");
			$exte_where .= " OR " . $objFCKLinks->_addslashesC("file_exte", "xlsx", "=");
		}
		$exte_where = " AND (" . preg_replace("/^( OR )+/", "", $exte_where) . ")";
	}
	// 拡張子用のwhere句を条件文に追加
	$where .= $exte_where;
}

// 条件文に付加されている最初の AND を除去
$where = preg_replace("/^( AND )+/", "", $where);

//一時検索
$objFCKLinks->select($objFCKLinks->_addslashesC("path", $search_path . "/%", "LIKE"), "*");
//検索結果全件抽出
$flds = array();
while ($objFCKLinks->fetch()) {
	if (!@file_exists(DOCUMENT_ROOT . RPW . $objFCKLinks->fld['path'])) {
		$objFCKLinks_tmp = new tbl_fck_links($objCnc);
		//トランザクション処理
		$objCnc->begin();
		//削除処理
		if ($objFCKLinks_tmp->deleteFromFileLinkID($objFCKLinks->fld['id']) === FALSE) {
			//エラー
			$objCnc->rollback();
			user_error("データの更新処理に失敗しました。", E_USER_ERROR);
		}
		//コミット
		$objCnc->commit();
		$objFCKLinks_tmp = null;
	}
	else
		$flds[] = $objFCKLinks->fld;
}

//フォルダ内の全てのファイルを読み込む
$real_file_path = array();
$dirList = array(
		DOCUMENT_ROOT . RPW . $search_path
);
//取り込み不可能拡張子の取得
$DENIED_EXTENSIONS_FILE = explode(',', DENIED_EXTENSIONS_FILE);
//フォルダの一覧を取得
$dirList = cxGetDirList(DOCUMENT_ROOT . RPW . $search_path, $dirList);
//フォルダ数分ループ
foreach ((array) $dirList as $dir) {
	$dir = str_replace(DOCUMENT_ROOT . RPW, "", $dir);
	//フォルダ内にあるファイル一覧を取得
	$fileList = array();
	$fileList = cxGetFileList(DOCUMENT_ROOT . RPW . $dir, $fileList, "");
	//ファイル数分ループ
	foreach ((array) $fileList as $file) {
		//拡張子の取得
		if (!preg_match('/.*?\.(.*?)$/i', $file, $matches)) continue;
		$file_ext = strtolower($matches['1']);
		//拡張子がアップロード出来ないファイル以外の場合
		if (!in_array($file_ext, $DENIED_EXTENSIONS_FILE)) {
			//一覧に表示するためファイル名を保持
			$real_file_path[] = $dir . '/' . substr($file, (strrpos($file, '/') + 1));
		}
	}
}

//DBに情報の無いファイルの情報を登録する
//実ファイル分ループ
foreach ((array) $real_file_path as $num => $file) {
	$no_db_file_path_flg = true; //DB登録済み判定フラグ
	//DBに登録されている数分ループ
	foreach ((array) $flds as $fld) {
		//DBにパスがある場合
		if ($file == $fld['path']) {
			$no_db_file_path_flg = false;
			break;
		}
	}
	//DBに登録されていない場合
	if ($no_db_file_path_flg) {
		//ファイル拡張子の取得
		preg_match('/.*?\.(.*?)$/i', $file, $matches);
		$file_ext = strtolower($matches['1']);
		//ファイルサイズの取得
		$size = @filesize(DOCUMENT_ROOT . RPW . $file);
		//トランザクション処理
		$objCnc->begin();
		//登録処理
		$temp_ary = array(
				'name' => $file, 
				'path' => $file, 
				'file_exte' => $file_ext, 
				'file_size' => $size
		);
		if ($objFCKLinks->insert($temp_ary) === FALSE) {
			//エラー
			$objCnc->rollback();
			user_error("データの一覧登録処理に失敗しました。", E_USER_ERROR);
		}
		//コミット
		$objCnc->commit();
	}
}

// 更新日 --
if ($search['update_datetime'] == FLAG_ON) $order = "update_datetime ASC";
else $order = "update_datetime DESC";

//ページ管理
$row_cnt = $objFCKLinks->getCount($where, $objFCKLinks->table_name);
$objP->limit = $maxRow;
$objP->set($page, $row_cnt);
// 検索
$objFCKLinks->select($where, "*", $order, $objP->getOffset(), $objP->getLimit());
// 検索結果全件抽出
$drawHTML = "";
while ($objFCKLinks->fetch()) {
	$fld = $objFCKLinks->fld;
	// 実ファイルが存在していない場合は表示しない
	if (!@file_exists(DOCUMENT_ROOT . RPW . $fld['path'])) continue;
	
	//削除可能かチェックする
	if (isset($_SESSION['cms_page_id'])) {
		$chk_tbl = array(
				'tbl_work_images', 
				'tbl_publish_images', 
				'tbl_work_links', 
				'tbl_publish_links'
		);
		$Delete_Flg = true;
		foreach ($chk_tbl as $tbl) {
			if (in_array($tbl, array(
					'tbl_work_images', 
					'tbl_publish_images'
			))) $clm_name = 'src';
			else $clm_name = 'path';
			$sql = "SELECT page_id FROM " . $tbl . " WHERE (" . $objDac->_addslashesC($clm_name, $fld['path'], 'LIKE', 'TEXT') . ")";
			$objDac->execute($sql);
			if ($objDac->getRowCount() > 0) $Delete_Flg = false;
		}
	}
	else {
		$Delete_Flg = true;
		$objDac = new b_dac($objCnc, "tbl_library AS l");
		$objDac->add_where("l.library_ver", "(SELECT MAX(library_ver ) FROM tbl_library WHERE library_id = l.library_id)", "=", "JOIN");
		$objDac->add_where('l.context', '(src|href)="' . RPW . $fld['path'] . '[^"]*"', 'REGEXP');
		$objDac->select();
		if ($objDac->getRowCount() > 0) $Delete_Flg = false;
	}
	
	// HTML 作成
	$drawHTML .= '<tr id="cms_ffl_tr_' . $fld['id'] . '">';
	$drawHTML .= '<td>';
	$drawHTML .= '<table width="100%" border="0" cellspacing="0" cellpadding="0" margin="0" padding="0" style="margin:0px;padding:0px;border-collapse:collapse;">';
	$drawHTML .= '<tr style="margin:0px;padding:0px;">';
	//POSTする値
	$drawHTML .= '<input type="hidden" name="cms_ffl_url_' . $fld['id'] . '" id="cms_ffl_url_' . $fld['id'] . '" value="' . htmlDisplay($fld['path']) . '">';
	$drawHTML .= '<input type="hidden" name="cms_ffl_exp_' . $fld['id'] . '" id="cms_ffl_exp_' . $fld['id'] . '" value="' . htmlDisplay($fld['file_exte']) . '">';
	$drawHTML .= '<input type="hidden" name="cms_ffl_size_' . $fld['id'] . '" id="cms_ffl_size_' . $fld['id'] . '" value="' . htmlDisplay($fld['file_size']) . '">';
	$file_icon = $IMGDIR . "/icons/";
	if (in_array(strtolower($fld['file_exte']), $aryIcon)) $file_icon .= strtolower($fld['file_exte']) . ".gif";
	else $file_icon .= 'default.icon.gif';
	//左
	$drawHTML .= '<td width="20%" align="center" style="margin:0px;padding:0px;border-right:solid 1px #999999;background-color:#FFFFFF;">';
	//アイコン画像
	$drawHTML .= '<img src="' . $file_icon . '" width="32" height="32" alt="' . htmlDisplay($fld['name']) . '" border="0">';
	$drawHTML .= '</td>';
	//中
	$drawHTML .= '<td width="70%" height="80px" align="left" style="margin:0px;padding:0px;padding-left:3px">';
	$drawHTML .= '<table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" style="margin:0px;padding:0px;border-collapse:collapse;">';
	//ファイル情報
	$drawHTML .= '<tr style="margin:0px;padding:0px;">';
	$drawHTML .= '<td style="margin:0px;padding:0px;padding-left:3px;">';
	$drawHTML .= '<div id="cms_ffl_name_' . $fld['id'] . '" style="font-weight:bold;font-size:15px;">' . htmlDisplay($fld['name']) . '</div>';
	$drawHTML .= htmlDisplay($fld['path']) . '<br>';
	$drawHTML .= '<div id="cms_ffl_update_datetime_' . $fld['id'] . '">更新日：' . dtFormat($fld['update_datetime'], "Y年m月d日 H時i分s秒") . '</div>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
	//操作ボタン
	$drawHTML .= '<tr>';
	$drawHTML .= '<td align="left" valign="middle" style="margin:0px;padding:0px;padding-top:3px;">';
	$drawHTML .= '&nbsp;';
	//削除
	if ($Delete_Flg && ($search['category'] == FCK_LINK_CATE_NOW || $objLogin->get('class') == USER_CLASS_WEBMASTER)) {
		$drawHTML .= '<a href="javascript:void(0)"  class="cke_dialog_ui_button cke_dialog_ui_button_padding"  onclick="cxDeleteFile(' . $fld['id'] . ',\'' . javaStringEscape(htmlDisplay($fld['name'])) . '\'); return false;">削除</a>';
	}
	//削除_OFF
	else
		$drawHTML .= '<a class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_inactive">削除</a>';
	$drawHTML .= '&nbsp;';
	$drawHTML .= '&nbsp;';
	//プロパティ
	$drawHTML .= '<a href="javascript:void(0)"   class="cke_dialog_ui_button"  onclick="cxShowProperty(' . $fld['id'] . '); return false;">プロパティ</a>';
	$drawHTML .= '&nbsp;';
	//ファイル挿入ボタンの表示
	$drawHTML .= '<a href="javascript:void(0)"  style="float: right;" class="cke_dialog_ui_button cke_dialog_ui_button_grey"  onclick="cxReturn(' . $fld['id'] . '); return false;">ファイル挿入</a>';
	$drawHTML .= '&nbsp;';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
	$drawHTML .= '</table>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
	$drawHTML .= '</table>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
	$drawHTML .= '<tr>';
	$drawHTML .= '<td style="border:none;padding-left:5px;padding-right:5px;">';
	$drawHTML .= '<hr>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
}

// -- HTML 出力 -- //


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ファイルにリンク</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/normalize.css" type="text/css">
<link rel="stylesheet" href="<?=RPW?>/ckeditor/gd_files/css/grid.css" type="text/css">
<link rel="stylesheet" href="<?=RPW?>/ckeditor/gd_files/css/dialog.css" type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="fck_filelink_list.js"  type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>
<base target="_self" />
</head>
<body class="cke_reset_all">
<div class="cke_dialog_title">ファイルにリンク<a	href="javascript:cxIframeLayerCallback()" id="header_close" style="float: right; margin-top: 2px;"><img src="<?=RPW?>/ckeditor/skins/moono-lisa/images/close.png" alt="閉じる"></a></div>
<div id="cms8341-headareaZero">
<table width="100%" border="0" cellspacing="0"
	cellpadding="0">
	<tr>
		<td width="100%">
		<div id="cms8341-tab"  class="cke_dialog_tabs">
		<table border="0" cellspacing="0" cellpadding="0"
			style="border-collapse: collapse;">
			<tr>
				<td><a href="fck_filelink_upload.php" class="cke_dialog_tab" ><span>PCから選んで登録 </span></a></td>
				<td><a class="cke_dialog_tab cke_dialog_tab_selected" ><span>登録済ファイルから選択 </span></a></td>
			</tr>
		</table>
		</div>
  </table>
 <div class="cke_dialog_contents">
<form name="cms_fck_link_list" id="cms_fck_link_list" action="fck_filelink_list.php" method="post">
<fieldset id="search_fieldset">
<legend style="margin-left: 10px;">ファイル検索</legend>
<div class="lay640">
 <div class="size2"><label class="cke_dialog_ui_labeled_label" for="cms_fck_link_category">ファイル分類</label></div>
 <div class="size10 suf3">
 <select class="cke_dialog_ui_input_text" name="cms_fck_link_category" id="cms_fck_link_category">
<option value="<?=FCK_LINK_CATE_NOW?>"
<?=(($search['category'] == FCK_LINK_CATE_NOW) ? 'selected' : '');?>>現在の場所</option>
<!--
																					<option value="<?=FCK_LINK_CATE_SHARED?>" <?=(($search['category'] == FCK_LINK_CATE_SHARED) ? 'selected' : '');?>>共通ファイル</option>
-->
</select>
</div>
</div>
     
<div class="lay640">
<div class="size2"> <label class="cke_dialog_ui_labeled_label" for="cms_fck_link_keyword">キーワード</label></div>
<div class="size10">
<input type="text" class="cke_dialog_ui_input_text" name="cms_fck_link_keyword" id="cms_fck_link_keyword" value="<?=htmlspecialchars($search['keyword'])?>">
</div>
<div class="size3"><a style="float: right;" href="javascript:void(0)" onClick="return cxSearch()"  class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_grey" 
tabindex="1">検索</a></div>
</div>
 
<div class="lay640">
<div class="size2">
<label class="cke_dialog_ui_labeled_label" for="cms_fck_link_exte">ファイル形式</label></div>
<div class="size10 suf3">
<input id="cms_pdf" type="checkbox" name="cms_fck_link_exte_pdf" value="1"  <?=($search['exte_pdf'] == FLAG_ON) ? "checked" : "";?>> 
<label class="cke_dialog_ui_labeled_label" for="cms_pdf">PDF</label> 
<input id="cms_doc" type="checkbox" name="cms_fck_link_exte_doc" value="1" <?=($search['exte_doc'] == FLAG_ON) ? "checked" : "";?>>
<label class="cke_dialog_ui_labeled_label" for="cms_doc">Word</label> 
<input id="cms_xls" type="checkbox" name="cms_fck_link_exte_xls" value="1" <?=($search['exte_xls'] == FLAG_ON) ? "checked" : "";?>> 
<label class="cke_dialog_ui_labeled_label" for="cms_xls">Excel</label> 
<input id="cms_etc" type="checkbox" name="cms_fck_link_exte_etc" value="1" <?=($search['exte_etc'] == FLAG_ON) ? "checked" : "";?>> 
<label class="cke_dialog_ui_labeled_label" for="cms_etc">その他</label>
</div>
</div>

<div class="lay640">
<div class="size2">
<label class="cke_dialog_ui_labeled_label" for="cms_fck_link_update">表示順</label></div>
<div class="size10 suf3">
<span  class="cke_dialog_ui_labeled_label" >更新日の </span>
<input id="upd_asc" type="radio" name="cms_fck_link_update_datetime" value="0" <?=($search['update_datetime'] == FLAG_OFF) ? "checked" : "";?>>
<label for="upd_asc" class="cke_dialog_ui_labeled_label" >降順</label> 
<input id="upd_dsc" type="radio" name="cms_fck_link_update_datetime" value="1" <?=($search['update_datetime'] == FLAG_ON) ? "checked" : "";?>>
<label for="upd_dsc" class="cke_dialog_ui_labeled_label" >昇順</label>
</div>
</div>
</fieldset>
				

	
						<input type="hidden" name="maxrow" id="search_maxrow"
							value="<?=$maxRow?>"></form>
     <div class="lay640"><div class="pre12 size4">
                                                                                                                 <span><?=mkcombobox($MAXROW_LIST, "dispNum", $maxRow, "cxDispNum(this.value)")?></span>
     </div>
</div>
							<fieldset>
						<legend>ファイルリスト</legend>
						<table width="100%" border="0" cellspacing="0" cellpadding="0"
							style="margin-top: 0px; margin-bottom: 0px; padding: 1px">
							<tr valign="top">
								<td align="right">
																
															</td>
							</tr>
						</table>
						
									
	
						<table width="100%" border="0" cellspacing="0" align="center"
							valign="top">
							<tr>
								<td>
								<div
									style="width: 100%; height: 350px; overflow-y: scroll; overflow-x: hidden;"
									nowrap scope="row">
								<table width="97%" border="0" cellspacing="0" cellpadding="0"
									class="cms8341-dataTable"
									style="border-collapse: collapse;">
																		<?=$drawHTML?>
																	</table>
								</div>
								</td>
							</tr>
							
						</table>
						</td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</fieldset>			
		</div>
		<div class="cms8341-area-corner-page-count"
			style="width: 97%; margin-bottom: 12px; text-align: center;"><span
			style="float: left; width: 20%;"><?=$objP->getBackLink();?></span> <span
			style="float: right; width: 20%;"><?=$objP->getNextLink();?></span> <span
			style="width: 60%;"><?=$objP->getViewCount();?></span></div>
		</td>
	</tr>
</table>
</div>
<form name="cms_page_post" id="cms_page_post" method="post" action=""><input
	type="hidden" name="cms_page" id="cms_page" value=""> <input
	type="hidden" name="maxrow" id="maxrow" value=""> <input type="hidden"
	name="cms_fck_link_category" id="cms_fck_link_category"
	value="<?=$search['category']?>"> <input type="hidden"
	name="cms_fck_link_keyword" id="cms_fck_link_keyword"
	value="<?=$search['keyword']?>"> <input type="hidden"
	name="cms_fck_link_update_datetime" id="cms_fck_link_update_datetime"
	value="<?=$search['update_datetime']?>"> <input type="hidden"
	name="cms_fck_link_exte_pdf" id="cms_fck_link_exte_pdf"
	value="<?=$search['exte_pdf']?>"> <input type="hidden"
	name="cms_fck_link_exte_doc" id="cms_fck_link_exte_doc"
	value="<?=$search['exte_doc']?>"> <input type="hidden"
	name="cms_fck_link_exte_xls" id="cms_fck_link_exte_xls"
	value="<?=$search['exte_xls']?>"> <input type="hidden"
	name="cms_fck_link_exte_etc" id="cms_fck_link_exte_etc"
	value="<?=$search['exte_etc']?>"></form>
</body>
</html>
