<?php
/**
 * ファイルリンク：登録ファイルプロパティ画面　fck_filelink_property.php
 */
// -- 設定ファイル -- //
require ("../.htsetting");

// -- エラー画面設定 -- //
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

// -- インクルード -- //
global $objCnc;
global $objLogin;

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_links.inc');
$objFCKLinks = new tbl_fck_links($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);

// -- 初期化 -- //


$submitFlg = FLAG_OFF;

// GET値取得


// ID
$id = (isset($_GET['id'])) ? $_GET['id'] : "";

// POST値がある場合
if (isset($_POST['cms_filelink_id']) && isset($_POST['cms_filelink_name'])) {
	// ID 代入
	$id = $_POST['cms_filelink_id'];
	// 登録するID
	$updAry['id'] = $id;
	// ファイル名称
	$updAry['name'] = $_POST['cms_filelink_name'];
	// 更新日 -> 現在日付
	$updAry['update_datetime'] = "NOW";
	// プロパティ登録処理
	$objCnc->begin();
	if ($objFCKLinks->update($updAry) === FALSE) {
		// エラー
		$objCnc->rollback();
		user_error("ファイル情報の設定に失敗しました。ファイル情報が削除された可能性があります。", E_USER_ERROR);
	}
	$objCnc->commit();
	$submitFlg = FLAG_ON;
}

// 検索
if ($objFCKLinks->selectFCKFileLinkID($id) !== FALSE) {
	$property = $objFCKLinks->fld;
}
else {
	// エラー
	user_error("ファイル情報の取得に失敗しました。ファイル情報が削除された可能性があります。", E_USER_ERROR);
}

//編集権限
$writeFlg = FLAG_ON;
//共有フォルダのパスを含んでおり、ウェブマスタでなければ編集不可
if (strpos($property['path'], FCK_FILELINK_FORDER_SHARED . "/") !== FALSE && $objLogin->get('class') != USER_CLASS_WEBMASTER) $writeFlg = FLAG_OFF;

// -- HTML 出力 -- //


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Expires" content="Thu, 01 Dec 1994 16:00:00 GMT">
<title>ファイルにリンク</title>
<link rel="stylesheet" href="<?=RPW?>/ckeditor/gd_files/css/grid.css" type="text/css">
<link rel="stylesheet" href="<?=RPW?>/ckeditor/gd_files/css/dialog.css" type="text/css">
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script
	src="<?=RPW?>/ckeditor/plugins/gd_link/fck_link/fck_filelink_property.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script type="text/javascript">
	<!--
		var submitFlg = <?=$submitFlg?>;
		var retObj = new Object();
		retObj["id"] = '<?=$property['id']?>';
		// \のエスケープ、'のエスケープ
		retObj["name"] = '<?=htmlspecialchars(javaStringEscape($property['name']))?>';
		retObj["update_datetime"] = '<?=dtFormat($property['update_datetime'], "Y年m月d日 H時i分s秒")?>';
		<?php
		echo loadSettingVars();
		?>

		// ディスプレイの画面サイズ
		var SCREEN_WIDTH = screen.width;
		var SCREEN_HEIGHT = screen.height;

		// ダイアログサイズ
		var windowSizeX = 495;
		var windowSizeY = <?=($writeFlg == FLAG_ON ? 355 : 322)?>;

		// ウィンドウサイズ変更
		window.dialogWidth  = windowSizeX + "px";
		window.dialogHeight = windowSizeY + "px";

		// ウィンドウ位置調整(スクリーンの中心)
		window.dialogLeft = (SCREEN_WIDTH)/2 - (windowSizeX/2);
		window.dialogTop = (SCREEN_HEIGHT)/2 - (windowSizeY/2);

	// -->
</script>
<base target="_self" />
</head>
<body>
<div class="cke_dialog_title">ファイルプロパティ<a href="javascript:cxIframeLayerCallback()" id="header_close" style="float: right; margin-top: 2px;"><img src="<?=RPW?>/ckeditor/skins/moono-lisa/images/close.png" alt="閉じる"></a></div>
<form name="cms_fck_link_property" id="cms_fck_link_property"
	action="fck_filelink_property.php?id=<?=$property['id']?>"
	method="post" onsubmit="return cxSubmit()"><input type="hidden"
	name="cms_filelink_id" id="cms_filelink_id"
	value="<?=$property['id']?>">
<div id="cms8341-headareaZero" style="margin-bottom: 0px !important">
<table width="100%"  border="0" cellspacing="0"
	cellpadding="0" style="border-collapse: collapse;">
	<tr>
		<td width="100%">
		<div id="cms8341-searcharea"
			style="text-align: left; padding: 7px 7px 0px 7px;">
		<table width="100%" align="center" valign="top"
			border="0" cellspacing="0" cellpadding="10" >
			<tr>
				<td><fieldset>
				<div style="width: 100%; height: 150px; overflow: auto;" nowrap
					scope="row">
				<table border="0" cellspacing="0" cellpadding="5" align="center"
					width="100%" class="cms8341-dataTable"
					style="border-collapse: collapse;">
					<tr>
						<th align="left" valign="top" widtn="30%"><label class="cke_dialog_ui_labeled_label" 
							for="cms_filelink_name">ファイル名称</label></th>
						<td widtn="70%">
														<?php
														if ($writeFlg == FLAG_ON) {
															echo '<input type="text" name="cms_filelink_name"  class="cke_dialog_ui_input_text" id="cms_filelink_name" value="' . htmlspecialchars($property['name']) . '" style="width:200px;" maxlength="64">';
														}
														else {
															echo htmlDisplay($property['name']);
														}
														?>
													</td>
					</tr>
					<tr>
						<th align="left" valign="top" widtn="30%"><label class="cke_dialog_ui_labeled_label" 
							for="cms_filelink_path">ファイルパス</label></th>
						<td widtn="70%"><?=htmlDisplay($property['path'])?></td>
					</tr>
					<tr>
						<th align="left" valign="top" widtn="30%"><label class="cke_dialog_ui_labeled_label" 
							for="cms_filelink_regist">登録日</label></th>
						<td widtn="70%"><?=htmlDisplay(dtFormat($property['regist_datetime'], "Y年m月d日 H時i分s秒"))?></td>
					</tr>
					<tr>
						<th align="left" valign="top" widtn="30%"><label class="cke_dialog_ui_labeled_label" 
							for="cms_filelink_update">更新日</label></th>
						<td widtn="70%"><?=htmlDisplay(dtFormat($property['update_datetime'], "Y年m月d日 H時i分s秒"))?></td>
					</tr>
				</table>
				</div>
				<div style="margin: 10px 0px;" align="center">
										<?php
										if ($writeFlg == FLAG_ON) {
											echo '<a   class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_grey" href="javascript:void(0)" onClick="return cxSubmit()" tabindex ="1">設定</a>';
										}
										?>
										</div>
				</td>
			</tr>
		</table>
		</div>
		</td>
	</tr>
</table>
</div>
</form>
<?php
echo $objTool->setAccessibility();
?>
	</body>
</html>
