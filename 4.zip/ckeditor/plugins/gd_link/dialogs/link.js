CKEDITOR.dialog.add('gd_link_dialog', function (editor) {
        return {
                title: editor.lang.gd_link.title,
                minWidth:       625,
                minHeight:      625,
                contents: [{
                                id: 'tab-basic',
                                label: 'Basic Settings',
                                elements: [{
                                                type: 'text',
                                                id: 'src',
                                                label: 'Source',
                                                validate: CKEDITOR.dialog.validate.notEmpty("Image source field cannot be empty"),
                                        }, {
                                                type: 'text',
                                                id: 'alt',
                                                label: 'Alternative'
                                        }
                                ]
                        }
                ],
                onShow: function () {

            var href = CKEDITOR.plugins.getPath('gd_link') + 'fck_link.php?file_path=' + window.location.href;
            var minHeight = CKEDITOR.env.ie ? 620 : 630
            show_iframe_dialog(editor, href, '435', minHeight);

                },
                onOk: function () {
                }
        }
});