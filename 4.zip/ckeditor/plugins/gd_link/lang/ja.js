CKEDITOR.plugins.setLang( 'gd_link', 'ja', {
	button	: "リンク挿入/編集",
                  title	: "リンク設定",
	} );
