CKEDITOR.plugins.setLang( 'gd_link', 'en', {
	button	: "Decrease Indent",
                  title		: "Indent",
	} );
