CKEDITOR.dialog.add('gd_youtube', function (editor) {

    return {
        title: editor.lang.gd_youtube.title,
        minWidth: 510,
        minHeight: 200,
        onShow: function () {
            var href = CKEDITOR.plugins.getPath('gd_youtube') + 'pages/youtube.php';
            show_iframe_dialog(editor, href, '380', '380');
        },
        contents:
            [{
                id: 'youtubePlugin',
                expand: true,
                elements:
                    [
                        {
                            type: 'html',
                            html: editor.lang.gd_youtube.or + '<hr>'
                        }
                    ]
            }
            ],
        onOk: function ()
        {
        }
    };
});