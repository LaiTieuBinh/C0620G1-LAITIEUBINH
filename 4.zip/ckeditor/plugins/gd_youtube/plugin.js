/*
 * Youtube Embed Plugin
 *
 * @author Jonnas Fonini <jonnasfonini@gmail.com>
 * @version 2.1.5
 */
CKEDITOR.plugins.add('gd_youtube', {
        lang: "en,ja",
        init: function (editor) {
            editor.addCommand('gd_youtube', new CKEDITOR.dialogCommand('gd_youtube', {
                allowedContent: 'div{*}(*); iframe{*}[!width,!height,!src,!frameborder,!allowfullscreen]; object param[*]; a[*]; img[*]'
            }));

            editor.ui.addButton('GdYoutube', {
                label: editor.lang.gd_youtube.button,
                toolbar: 'insert',
                command: 'gd_youtube',
                icon: this.path + 'icons/youtube.png'
            });
            CKEDITOR.dialog.add('gd_youtube', this.path + 'dialogs/youtube.js')
        }
    });
