<?php

//設定ファイル読み込み
require_once (dirname( dirname ( dirname ( dirname (dirname ( __FILE__ ) ) ) )). "/.htsetting");

//エラー画面設定 別ウィンドウ用
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

//定数の読み込み
$YOUTUBE_PATTERN_ARY = getDefineArray('YOUTUBE_PATTERN_ARY');
$YOUTUBE_OPTION_ARY = getDefineArray('YOUTUBE_OPTION_ARY');
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow"/>
    <title>Image Properties</title>
    <link rel="stylesheet" href="<?= RPW ?>/ckeditor/gd_files/css/grid.css" type="text/css">
    <link rel="stylesheet" href="<?= RPW ?>/ckeditor/gd_files/css/dialog.css" type="text/css">
    <script src="<?= RPW ?>/admin/js/library/jquery.js" type="text/javascript"></script>
    <script src="<?= RPW ?>/admin/js/shared.js" type="text/javascript"></script>
    <script src="<?= RPW ?>/admin/js/common_action.js" type="text/javascript"></script>
    <script type="text/javascript">
        //オプションの値を作成
        var option_ary = new Array();
        <?php
        foreach ($YOUTUBE_OPTION_ARY as $option_name => $option_value) {
            print('option_ary[\'' . $option_name . '\'] = new Array();' . "\n");
            foreach ($option_value as $name => $key) {
                print('option_ary[\'' . $option_name . '\'][\'' . $name . '\'] = \'' . $key . '\';' . "\n");
            }
        }
        ?>
        var YOUTUBE_PATTERN_ARY = "<?=implode(',', $YOUTUBE_PATTERN_ARY);?>";

    </script>
    <script src="youtube.js" type="text/javascript"></script>
</head>
<body>

<div class="lay360">
    <div class="size8">
        <a href="<?= YOUTUBE_DEFAULT_URL ?>" class="cke_dialog_ui_button" target="_blank">YouTubeへ</a>
    </div>
</div>

<div class="lay360">
    <div class="size8">
        <label class="cke_dialog_ui_labeled_label">タイトル:</label>
        <input type="text" class="cke_dialog_ui_input_text" id="youtube_title" name="youtube_title" value="">
    </div>
</div>
<div class="lay360">
    <div class="size8">
        <span class="cke_dialog_ui_labeled_label">URL:</span>
        <input type="text" class="cke_dialog_ui_input_text" id="youtube_url" name="youtube_url" value="">
    </div>
</div>
<div class="lay360">
    <div class="size4">
        <span class="cke_dialog_ui_labeled_label">横幅:</span>
        <input type="text" class="cke_dialog_ui_input_text" id="youtube_width" name="youtube_width"
               value="<?= YOUTUBE_WIDTH ?>">
    </div>
    <div class="size4">
        <span class="cke_dialog_ui_labeled_label">高さ:</span>
        <input type="text" class="cke_dialog_ui_input_text" id="youtube_height" name="youtube_height"
               value="<?= YOUTUBE_HEIGHT ?>">
    </div>
</div>
<div class="lay360">
    <div class="size8">
        <fieldset>
            <legend class="cke_dialog_ui_labeled_label">オプション</legend>
            <br>
            <?php
            foreach ($YOUTUBE_OPTION_ARY as $option_name => $option_value) {
                print('<input type="checkbox" id="youtube_op_' . $option_name . '" name="youtube_op_' . $option_name . '" value="1"' . ($option_value['defult'] == 1 ? ' checked' : '') . '><label  class="cke_dialog_ui_labeled_label" for="youtube_op_' . $option_name . '">' . $option_value['name'] . '</label><br>');
            }
            ?>
        </fieldset>
    </div>
</div>
<div class="lay360">
    <div class="pre2 size4 suf2">
        <a href="javascript:void(0)" onclick="cxSubmit_Property();return false;"
           class="cke_dialog_ui_button cke_dialog_ui_button_grey">設定する</a>
        <a href="javascript:void(0)" class="cke_dialog_ui_button"
           onclick="CKEDITOR.dialog.getCurrent().parts.close.$.click();">キャンセル</a>
    </div>
</div>

</body>
</html>
