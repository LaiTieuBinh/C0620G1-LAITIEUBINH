var CKEDITOR = window.top.CKEDITOR;
var oEditorWin = CKEDITOR.currentInstance.window.$;


function cxAjaxCommand(json, SuccessFunc) {
    $.ajax({
        method: 'POST',
        url: cms8341admin_path+'/connector.php',
        data: json,
        success: SuccessFunc,
        error: cxFailure
        // error: function(jqXHR, textStatus, errorThrown) {
        //     console.log(textStatus, errorThrown);
        // }
    });
}
/**
 * キーを押したときの処理
 */
window.document.onkeydown = function(e){
    e = e || event || this.parentWindow.event;
    switch(e.keyCode){
        //ENTER
        case 13:
            var oTarget = e.srcElement || e.target;
            if(oTarget.tagName == 'TEXTAREA') return;
            if(oTarget.tagName == 'INPUT' && (oTarget.type == 'text' || oTarget.type == 'file')) cxSubmit_Property();
            return false;
            break;
        // 20/09/2017 - to delete
        //ESC
//						case 27:
//							window.parent.Cancel();
//							return false;
//							break;
    }
    return true;
}

/**
 * ページ表示完了時に呼ばれるイベント
 */
window.onload = function(){
    //設定されている値の取得
    LoadSelection();
}

/**
 * 現在設定されている値を取得する
 */
function LoadSelection(){
    //コントロール以外の場合は、タイトルに代入して終了
//					if(FCK.EditorDocument.selection.type != "Control"){
    if(CKEDITOR.currentInstance.getSelection().getSelectedElement() == null){
        $('youtube_title').value = CKEDITOR.currentInstance.getSelection().getSelectedText();
        return;
    }

    //最初のオブジェクトを取得
    var caret = CKEDITOR.currentInstance.getSelection().getSelectedElement().$;
    //値の取得
    var title = (caret.getAttribute('alt') ? caret.getAttribute('alt') : '');
    var url = caret.getAttribute('url');
    var width = caret.getAttribute('width');
    var height = caret.getAttribute('height');

    //値の設定
    //タイトル
    if(title  && title != '') $('#youtube_title').val(title);
    //URL
    if(url && url != ''){
        //URLの取得
        var url_tmp = url.substring(0,url.lastIndexOf('?'));
        //設定値の取得
        var get_ary = url.substring(url.lastIndexOf('?')).split('&');
        //GET数分ループ
        for(var i = 0;i < get_ary.length;i++){
            //キーと値を分割
            ary = get_ary[i].split('=');
            //配列にキーが存在する場合
            if(option_ary[ary[0]]){
                //設定が1（TRUE）の場合は設定する
                if(ary[1] == 1) $('#youtube_op_' + ary[0]).prop('checked', true);
            }
            //配列にキーが存在しない場合は、URLへ戻す
            else url_tmp += (get_ary[i].match(/^(https?:)?\/\//i) || get_ary[i].substr(0,1).match(/(&|\?)/) ? '' : '&') + get_ary[i];
        }
        //URLを取得
        $('#youtube_url').val(url_tmp);
    }
    //横幅
    if(width && width != '') $('#youtube_width').val(width);
    //高さ
    if(height && height != '') $('#youtube_height').val(height);
}

/**
 * 決定ボタンが押された際の処理
 * @return false
 */
function cxSubmit_Property(){
    //値のチェック
    var errMsg = '';
    //タイトル
    if(!$('#youtube_title').val() || $('#youtube_title').val() == '') errMsg = 'タイトルが入力されていません。';
    //URL
    else if(!$('#youtube_url').val() || $('#youtube_url').val() == '') errMsg = 'URLが入力されていません。';
    else if($('#youtube_url').val().match(/^(https?)(:\/\/[-_.!~*\'\(\)a-zA-Z0-9;\/?:\@&=+\$,%#]+)$/i) == null) errMsg = 'URLとして認められないURLが指定されています。';
    else if(!in_array($('#youtube_url').val().match(/^https?:\/\/[^\/]*?(\/|$)/i)[0],(YOUTUBE_PATTERN_ARY).split(','))) errMsg = 'YouTube以外のURLが指定されています。';
    //横幅
    else if($('#youtube_width').val() != "" && $('#youtube_width').val() <= 0) errMsg = '横幅に0以下が入力されています。';
    else if($('#youtube_width').val() != "" && !$('#youtube_width').val().match(/^[0-9]*$/)) errMsg = '横幅に数字以外が入力されています。';
    //高さ
    else if($('#youtube_height').val() != "" && $('#youtube_height').val() <= 0) errMsg = '高さに0以下が入力されています。';
    else if($('#youtube_height').val() != "" && !$('#youtube_height').val().match(/^[0-9]*$/)) errMsg = '高さに数字以外が入力されています。';

    //エラーが存在する場合
    if(errMsg != ''){
        alert(errMsg);
        return false;
    }

    //セーブ
    CKEDITOR.currentInstance.fire('saveSnapshot');

    //パラメータの作成
    var paramStr = '';
    for(var key in option_ary){

        paramStr += '&' + key + '=' + ($('#youtube_op_' + key).is(':checked') ? '1' : '0');
    }
    // .replace() will replace only first occurrence
    var post_data = {};
    post_data.Command = 'cxConvertYoutubeCMS';
    post_data.url = encodeURI($('#youtube_url').val()) + encodeURI(paramStr);
    post_data.title = encodeURIComponent($('#youtube_title').val());
    post_data.width =$('#youtube_width').val();
    post_data.height = $('#youtube_height').val();
    //YouTubeのタグを作成
    cxAjaxCommand(post_data,cxSubmit_Property_Success);
}

/**
 * タグの取得に成功
 * @param r Ajax結果
 */
function cxSubmit_Property_Success(r){
    // console.log(r);
    var setHtml = r;
    // console.log(setHtml);
    //コントロールの場合は、選択している箇所を削除
    // if(CKEDITOR.currentInstance.getSelection().getSelectedElement() != null) CKEDITOR.currentInstance.getSelection().getSelectedElement().$.remove();
    //タグの追加
    CKEDITOR.currentInstance.insertHtml(setHtml);
    //クローズ
    CKEDITOR.dialog.getCurrent().parts.close.$.click();
}

/**
 * タグの取得に失敗
 */
function cxFailure(){
    alert('タグの作成に失敗しました。');
    return false;
}

