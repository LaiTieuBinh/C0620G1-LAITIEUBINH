CKEDITOR.plugins.setLang( 'gd_table_tools', 'en', {
	button	: "テーブルの整形",
                  title	: "テーブルの整形"
	} );
