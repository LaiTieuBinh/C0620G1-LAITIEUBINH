CKEDITOR.plugins.setLang( 'gd_table_tools', 'ja', {
	button	: "テーブルの整形",
                  title	: "テーブルの整形"
	} );