<?php
//設定ファイル読み込み
require_once("../../../gd_files/.htsetting");

?>
<!DOCTYPE html>
<html>
<head>
    <title>Table Cell Properties</title>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow"/>
    <link rel="stylesheet" href="<?= RPW ?>/admin/style/normalize.css?v=1" type="text/css">
    <link href="<?= RPW ?>/ckeditor/gd_files/css/grid.css" type="text/css" rel="stylesheet">
    <link href="<?= RPW ?>/ckeditor/gd_files/css/dialog.css" type="text/css" rel="stylesheet">
    <script type='text/javascript' src="tablecell.js"></script>
    <script src="<?= RPW ?>/ckeditor/gd_files/js/dialog_common.js" type="text/javascript"></script>
    <script src="<?= RPW ?>/admin/js/library/prototype.js" type="text/javascript"></script>
</head>
<body>
<div class="dialog_body">

    <div class="lay360">

        <div class="size2 ">
            <span class="cke_dialog_ui_labeled_label" fcklang="DlgCellWidth">Width</span>:
            <input onkeypress="return IsDigit();" id="txtWidth" type="text" class="cke_dialog_ui_input_text" name="txtWidth"/>
        </div>
        <div class="size3 ">
            <span class="cke_dialog_ui_labeled_label" fckLang="DlgCellWidthMsr">Units</span>:
            <select class="cke_dialog_ui_input_select" id="selWidthType" name="selWidthType">
                <option fcklang="DlgCellWidthPx" value="pixels">pixels</option>
                <option fcklang="DlgCellWidthPc" value="percent">percent</option>
            </select>
        </div>
        <div class="size3 ">
            <span class="cke_dialog_ui_labeled_label" fcklang="DlgCellHeight">Height</span>(<span
                    class="cke_dialog_ui_labeled_label" fcklang="DlgCellWidthPx">pixels</span>):
            <input id="txtHeight" type="text" class="cke_dialog_ui_input_text" name="txtHeight"
                   onkeypress="return IsDigit();"/>
        </div>
    </div>

    <div class="lay360">
        <div class="size4">
            <span class="cke_dialog_ui_labeled_label" fcklang="DlgCellHorAlign">Horizontal Alignment</span>:
            <select class="cke_dialog_ui_input_select" id="selHAlign" name="selAlignment">
                <option fcklang="DlgCellHorAlignNotSet" value="" selected>&lt;Not set&gt;</option>
                <option fcklang="DlgCellHorAlignLeft" value="left">Left</option>
                <option fcklang="DlgCellHorAlignCenter" value="center">Center</option>
                <option fcklang="DlgCellHorAlignRight" value="right">Right</option>
            </select>
        </div>

        <div class="size4">
            <span class="cke_dialog_ui_labeled_label" fcklang="DlgCellVerAlign">Vertical Alignment</span>:
            <select class="cke_dialog_ui_input_select" id="selVAlign" name="selAlignment">
                <option fcklang="DlgCellVerAlignNotSet" value="" selected>&lt;Not set&gt;</option>
                <option fcklang="DlgCellVerAlignTop" value="top">Top</option>
                <option fcklang="DlgCellVerAlignMiddle" value="middle">Middle</option>
                <option fcklang="DlgCellVerAlignBottom" value="bottom">Bottom</option>
                <option fcklang="DlgCellVerAlignBaseline" value="baseline">Baseline</option>
            </select>
        </div>
    </div>

    <div class="lay360">
        <div class="size4 ">
            <span class="cke_dialog_ui_labeled_label" fcklang="DlgCellWordWrap">Word Wrap</span>:
            <select class="cke_dialog_ui_input_select" id="selWordWrap" name="selAlignment">
                <option fcklang="DlgCellWordWrapYes" value="true" selected="selected">Yes</option>
                <option fcklang="DlgCellWordWrapNo" value="false">No</option>
            </select>
        </div>
        <div class="size4 ">
            <input name="txtBackColor_hidden" id="txtBackColor_hidden" type="hidden" value="">
            <span class="cke_dialog_ui_labeled_label" fcklang="DlgCellBackColor">Background Color</span><span
                    id="txtBackColorPreview" style="margin-left: 5px; margin-right: 2px; border: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>:</br>

            <select class="cke_dialog_ui_input_select" name="txtCellSpacing" id="txtBackColor" onChange="cxSelectColor()">
                <?php
                $BACKGRAUND_CELL_COLOR = getDefineArray("BACKGRAUND_CELL_COLOR");
                foreach ($BACKGRAUND_CELL_COLOR as $name => $color) { ?>
                    <option id="<?php echo $color['color']; ?>" name="<?php echo $color['color']; ?>" value="<?php echo $color['color']; ?>">
                        <?php echo $name; ?>
                    </option>
                <?php }; ?>
            </select>
        </div>
    </div>

    <div class="lay360">
        <div class="size4">
            <span class="cke_dialog_ui_labeled_label" fcklang="DlgCellRowSpan">Rows Span</span>:
            <input onkeypress="return IsDigit();" id="txtRowSpan" type="text" class="cke_dialog_ui_input_text"
                   name="txtRows">
        </div>
        <div class="size4 ">
            <span class="cke_dialog_ui_labeled_label" fcklang="DlgCellCollSpan">Columns Span</span>:
            <input onkeypress="return IsDigit();" id="txtCollSpan" type="text" class="cke_dialog_ui_input_text"
                   name="txtColumns">
        </div>


    </div>

    <div class="lay360">
        <div class="size8">
            <input type="checkbox" id="th_flg" onclick="return selScopeChange();">
            <label for="th_flg" class="cke_dialog_ui_labeled_label">見出しセルとする</label>
            <!-- 070518 ADD 見出しセル対応 -->
            <?php // スコープ属性の選択selectボックス  ?>
            <select class="cke_dialog_ui_input_select" id="selScope" name="selScope">
                <option fcklang="DlgCellScopeUnSelected" value="unselected">Unselected</option>
                <option fcklang="DlgCellScopeRow" value="row">Row</option>
                <option fcklang="DlgCellScopeCol" value="col">Col</option>
            </select>
        </div>
        <input id="txtBorderColor" type="hidden" vlaue="">
    </div>

    <div class="lay360  button_layer">
        <div class="pre4 size4">
            <input id="btnOk" class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_grey"
                   type="button" value="Ok" onclick="Ok();" fckLang="DlgBtnOK"/>
            <input class="cke_dialog_ui_button" id="btnCancel" type="button" value="Cancel"
                   onclick="CKEDITOR.dialog.getCurrent().parts.close.$.click();" fckLang="DlgBtnCancel"/>
        </div>
    </div>

</div>
</body>
</html>
