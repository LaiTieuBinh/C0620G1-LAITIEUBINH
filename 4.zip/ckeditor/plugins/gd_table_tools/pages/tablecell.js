//var oEditor = window.parent.InnerDialogLoaded() ;
//// Gets the document DOM
//var oDOM = oEditor.FCK.EditorDocument ;

            var CKEDITOR = window.top.CKEDITOR;
            var oEditorWin = CKEDITOR.currentInstance.window.$;
            var oDOM = oEditorWin.document;
// Array of selected Cells
//var aCells = oEditor.FCKTableHandler.GetSelectedCells() ;
            var aCells = CKEDITOR.plugins.tabletools.getSelectedCells(CKEDITOR.currentInstance.getSelection());

            window.onload = function ()
            {
                // First of all, translate the dialog box texts
//	oEditor.FCKLanguageManager.TranslatePage( document ) ;
                CKEDITOR.FCKLanguageManager.TranslatePage(document);

                SetStartupValue();

//	window.parent.SetOkButton( true ) ;
//	window.parent.SetAutoSize( true ) ;
                cxSelectColorInit();
            }

            function SetStartupValue()
            {
                if (aCells.length > 0)
                {
                    var oCell = aCells[0].$;
                    var iWidth = GetAttribute(oCell, 'width');

                    if (iWidth.indexOf && iWidth.indexOf('%') >= 0)
                    {
                        iWidth = iWidth.substr(0, iWidth.length - 1);
                        GetE('selWidthType').value = 'percent';
                    } else if (!iWidth) {
                        //* 070518 ADD　セルのWIDTH属性値の単位のデフォルトをパーセントとする
                        GetE('selWidthType').value = 'percent';
                    }

                    if (oCell.attributes['noWrap'] != null && oCell.attributes['noWrap'].specified)
                        GetE('selWordWrap').value = !oCell.noWrap;

                    GetE('txtWidth').value = iWidth;
                    GetE('txtHeight').value = GetAttribute(oCell, 'height');
                    GetE('selHAlign').value = GetAttribute(oCell, 'align');
                    GetE('selVAlign').value = GetAttribute(oCell, 'vAlign');
                    GetE('txtRowSpan').value = GetAttribute(oCell, 'rowSpan');
                    GetE('txtCollSpan').value = GetAttribute(oCell, 'colSpan');
                    GetE('txtBackColor').value = GetAttribute(oCell, 'bgColor');
                    GetE('txtBorderColor').value = GetAttribute(oCell, 'borderColor');
                    $('txtBackColor_hidden').value = GetAttribute(oCell, 'bgColor');
					// スコープ属性の指定を取得する
					GetE('selScope').value = 'unselected';
					if (GetAttribute(oCell, 'scope') == 'row' || GetAttribute(oCell, 'scope') == 'col') {
						GetE('selScope').value = GetAttribute(oCell, 'scope');
					}

//		GetE('cmbFontStyle').value		= oCell.className ;
//(GetAttribute( oCell, 'bgColor' ));
                    //* 2008.01.12 複数セルが選択されている場合、rowspan,colspanは変更不可とする
                    if (aCells.length > 1) {
                        GetE('txtRowSpan').disabled = 'disabled';
                        GetE('txtCollSpan').disabled = 'disabled';
                    }

                    if (oCell.tagName == 'TH') {
                        GetE('th_flg').checked = true;
                    }

					selScopeChange();
                }
            }

// Fired when the user press the OK button
            function Ok()
            {
                // 見出しセルのチェックが有効で、scopeの指定が無い場合はalertを表示して終了
                var flg = GetE('th_flg').checked;
                if (flg && GetE('selScope').value == 'unselected') {
                    alert('見出しセル設定時は、' + "\n「" + CKEDITOR.FCKLanguageManager.FCKLang.DlgCellScopeRow + '」又は、' + "\n「" + CKEDITOR.FCKLanguageManager.FCKLang.DlgCellScopeCol + '」を選択して下さい。');
                    return false;
                }

                var temp_w = GetE('txtWidth').value;
                if (temp_w != "" && temp_w == 0) {
                    document.getElementById('txtWidth').value = '';
                }

                for (i = 0; i < aCells.length; i++)
                {

                    if (GetE('txtWidth').value.length > 0)
                        aCells[i].$.width = GetE('txtWidth').value + (GetE('selWidthType').value == 'percent' ? '%' : '');
                    else
                        aCells[i].$.removeAttribute('width', 0);

                    if (GetE('selWordWrap').value == 'false')
                        aCells[i].$.noWrap = true;
                    else
                        aCells[i].$.removeAttribute('noWrap');

                    SetAttribute(aCells[i].$, 'height', GetE('txtHeight').value);
                    SetAttribute(aCells[i].$, 'align', GetE('selHAlign').value);
                    SetAttribute(aCells[i].$, 'vAlign', GetE('selVAlign').value);
                    // 2008.01.11 複数セルが選択されている場合、rowspan,colspanは変更不可とする
                    if (aCells.length < 2) {
                        SetAttribute(aCells[i].$, 'rowSpan', GetE('txtRowSpan').value);
                        SetAttribute(aCells[i].$, 'colSpan', GetE('txtCollSpan').value);
                    }
                    SetAttribute(aCells[i].$, 'bgColor', GetE('txtBackColor').value);
                    SetAttribute(aCells[i].$, 'borderColor', GetE('txtBorderColor').value);

					if (flg) {
						SetAttribute(aCells[i].$, "scope", GetE('selScope').value);
						if (aCells[i].$.tagName == 'TH') {
							continue;
						}
						var th = document.createElement('th');
						th.innerHTML = aCells[i].$.innerHTML;
						settingAttr(th, aCells[i].$);
						aCells[i].$.parentNode.replaceChild(th, aCells[i].$);

					} else {
						SetAttribute(aCells[i].$, "scope", "");
						if (aCells[i].$.tagName == 'TD') {
							continue;
						}
						var td = document.createElement('td');
						td.innerHTML = aCells[i].$.innerHTML;
						settingAttr(td, aCells[i].$);
						aCells[i].$.parentNode.replaceChild(td, aCells[i].$);
					}
                    // SetAttribute( aCells[i].$, 'className'	, GetE('cmbFontStyle').value ) ;
                    // 070518 ADD 見出しセル対応
                //     if (flg) {
                //         // 読み上げ方向「scope」属性を設定
                //         SetAttribute(aCells[i].$, "scope", GetE('selScope').value);
                //         if (aCells[i].$.tagName == 'TH')
                //             continue;
                //         SetAttribute(aCells[i].$, "_gdthcell", "TRUE");
                //     } else {
                //         // 読み上げ方向「scope」属性を削除
                //         SetAttribute(aCells[i].$, "scope", "");
                //         if (aCells[i].$.tagName == 'TD')
                //             continue;
                //         SetAttribute(aCells[i].$, "_gdthcell", "FALSE");
                //     }
                //     // 070518 ADD 見出しセル対応
                // }
                // // 070518 ADD 見出しセル対応
                // // TD -->> TH
                // var td = oDOM.getElementsByTagName('TD');
                // for (i = 0; i < td.length; i++) {
                //     // TD -->> THに変換されていなかったための修正(非標準属性への参照を修正)
                //     if (td[i].getAttribute('_gdthcell') == "TRUE") {
                //         //var tr=oEditor.FCKSelection.MoveToAncestorNode("TR");
                //         var tr = td[i].parentNode;
                //         if (!tr)
                //             continue;
                //         var a = new Array();
                //         // TD -->> THに変換されていなかったための修正(非標準属性への参照を修正およびホワイトスペースノード対応)
                //         for (j = 0; j < tr.children.length; j++) {
                //             if (tr.children[j].getAttribute('_gdthcell') == "TRUE") {
                //                 temp = oDOM.createElement('TH');
                //                 temp.innerHTML = tr.children[j].innerHTML;
                //                 temp = settingAttr(temp, tr.children[j]);
                //                 a.push(temp);
                //             } else {
                //                 a.push(tr.children[j]);
                //             }
                //         }
                //         while (tr.children.length) {
                //             tr.removeChild(tr.children[0]);
                //         }
                //         for (j = 0; j < a.length; j++) {
                //             tr.appendChild(a[j]);
                //         }
                //     }
                // }
                // // TH -->> TD
                // var th = oDOM.getElementsByTagName('TH');
                // for (i = 0; i < th.length; i++) {
                //     // TH -->> TDに変換されていなかったための修正(非標準属性への参照を修正)
                //     if (th[i].getAttribute('_gdthcell') == "FALSE") {
                //         //var tr=oEditor.FCKSelection.MoveToAncestorNode("TR");
                //         var tr = th[i].parentNode;
                //         if (!tr)
                //             continue;
                //         var a = new Array();
                //         // TH -->> TDに変換されていなかったための修正(非標準属性への参照を修正およびホワイトスペースノード対応)
                //         for (j = 0; j < tr.children.length; j++) {
                //             if (tr.children[j].getAttribute('_gdthcell') == "FALSE") {
                //                 temp = oDOM.createElement('TD');
                //                 temp.innerHTML = tr.children[j].innerHTML;
                //                 temp = settingAttr(temp, tr.children[j]);
                //                 a.push(temp);
                //             } else {
                //                 a.push(tr.children[j]);
                //             }
                //         }
                //         while (tr.children.length) {
                //             tr.removeChild(tr.children[0]);
                //         }
                //         for (j = 0; j < a.length; j++) {
                //             tr.appendChild(a[j]);
                //         }
                //     }
                }
                
                CKEDITOR.dialog.getCurrent().parts.close.$.click();
                
                // 070518 ADD 見出しセル対応
                return true;
            }

            function settingAttr(A, B) {
                SetAttribute(A, 'width', GetAttribute(B, 'width'));
                SetAttribute(A, 'height', GetAttribute(B, 'height'));
                SetAttribute(A, 'align', GetAttribute(B, 'align'));
                SetAttribute(A, 'vAlign', GetAttribute(B, 'vAlign'));
                SetAttribute(A, 'rowSpan', GetAttribute(B, 'rowSpan'));
                SetAttribute(A, 'colSpan', GetAttribute(B, 'colSpan'));
                SetAttribute(A, 'bgColor', GetAttribute(B, 'bgColor'));
                SetAttribute(A, 'borderColor', GetAttribute(B, 'borderColor'));
                // スコープ属性追加
                SetAttribute(A, 'scope', GetAttribute(B, 'scope'));
                return A;
            }

            function SelectBackColor(color)
            {
                if (color && color.length > 0)
                    GetE('txtBackColor').value = color;
            }

            function SelectBorderColor(color)
            {
                if (color && color.length > 0)
                    GetE('txtBorderColor').value = color;
            }

            // 22/09/2017 TO DELETE ?  @ Sergei
            // function SelectColor(wich)
            // {
            //     oEditor.FCKDialog.OpenDialog('FCKDialog_Color', CKEDITOR.FCKLanguageManager.FCKLang.DlgColorTitle, 'dialog/fck_colorselector.html', 400, 330, wich == 'Back' ? SelectBackColor : SelectBorderColor, window);
            // }

// 
            function cxSelectColor() {
                Element.setStyle($('txtBackColorPreview'), {'background-color': $('txtBackColor').value});
            }
            function cxSelectColorInit() {
                if ($('txtBackColor_hidden').value != "" && $($('txtBackColor_hidden').value)) {
                    Element.setStyle($('txtBackColorPreview'), {'background-color': $('txtBackColor_hidden').value});
                    $($('txtBackColor_hidden').value).selected = true;
                }
            }

            /**
             * 読み上げ方向セレクトボックスの活性・非活性切り替え用関数
             */
            function selScopeChange() {
                var flg = GetE('th_flg').checked;
                if (flg) {
                    GetE('selScope').disabled = false;
                }
                else {
                    GetE('selScope').disabled = true;
                }
                return true;
            }
