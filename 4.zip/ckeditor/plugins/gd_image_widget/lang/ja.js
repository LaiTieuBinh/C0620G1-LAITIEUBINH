CKEDITOR.plugins.setLang('gd_image_widget', 'ja', {
    button: "画像設定",
    title: "画像設定",
    alt: '代替テキスト',
    btnUpload: 'サーバーに送信',
    captioned: 'キャプションを付ける',
    captionPlaceholder: 'キャプション',
    infoTab: '画像情報',
    lockRatio: '比率を固定',
    menu: '画像のプロパティ',
    pathName: 'gd_image_widget',
    pathNameCaption: 'caption',
    resetSize: 'サイズをリセット',
    resizer: 'ドラッグしてリサイズ',
    uploadTab: 'アップロード',
    urlMissing: '画像のURLを入力してください。',
    altMissing: '代替テキストを入力してください。'
});
