<?php
/*
 * 画像の設定を行う
 */
//設定ファイル読み込み
require_once(".htsetting");

//エラー画面設定 別ウィンドウ用
// gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
// gd_errorhandler_ini_set("html9", '<base target="_self">');

//DBアクセス用ファイルの読み込み
require_once(APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once(APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

if (isset($_SESSION['post']) && $_SESSION['post'] != "") {
	$POST = $_SESSION['post'];
	unset($_SESSION['post']);
}

//ライブラリの場合
if (isset($_GET['file_path']) && $_GET['file_path'] == HTTP_ROOT . RPW . "/admin/master/library/form.php") unset($_SESSION['cms_page_id']);

//変数の初期化
//フォルダパス(絶対パス)
$real_base_path = DOCUMENT_ROOT . RPW;

//フォルダパスの取得
//SESSIONを取得できる場合
if (isset($_SESSION['cms_page_id']) && $_SESSION['cms_page_id'] != "") {
	//パス取得
	if ($objPage->selectFromID($_SESSION['cms_page_id'], WORK_TABLE, "file_path") !== FALSE) {
	}
	else if ($objPage->selectFromID($_SESSION['cms_page_id'], PUBLISH_TABLE, "file_path") !== FALSE) {
	}
	else {
		user_error('ページ情報を取得できませんでした。', E_USER_ERROR);
	}
	$real_base_path .= FCK_IMAGES_FORDER . '/' . $_SESSION['cms_page_id'];
}
else {
	if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
		user_error('ログイン情報を取得できませんでした。現在の開いている全てのブラウザを閉じて再度実行してください。', E_USER_ERROR);
	}
	else {
		$real_base_path .= FCK_IMAGES_FORDER_LIBRARY;
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta name="robots" content="noindex, nofollow"/>
	<meta http-equiv="Content-Style-Type" content="text/css">
	<meta http-equiv="Content-Script-Type" content="text/javascript">
	<title>Image Properties</title>
	<link rel="stylesheet" href="<?= RPW ?>/admin/style/normalize.css" type="text/css">
	<link rel="stylesheet" href="<?= RPW ?>/ckeditor/gd_files/css/dialog.css" type="text/css">
	<script src="<?= RPW ?>/admin/js/library/prototype.js" type="text/javascript"></script>
	<script src="<?= RPW ?>/admin/js/shared.js" type="text/javascript"></script>
	<script src="<?= RPW ?>/admin/js/common_action.js" type="text/javascript"></script>
	<script src="<?= RPW ?>/ckeditor/gd_files/js/dialog_common.js" type="text/javascript"></script>
	<script src="js/com_func.js" type="text/javascript"></script>
	<script src="js/fck_image.js" type="text/javascript"></script>
	<script src="js/fck_image_upload.js" type="text/javascript"></script>
	<script type="text/javascript">
		<!--
		var get_mode = '<?php
			print((isset($get_mode) && $get_mode != "" ? $get_mode : (isset($_GET["mode"]) && $_GET["mode"] == "upload" ? "upload" : "property")));
			?>';
		var select_upload = '<?php
			print((isset($_GET["mode"]) && $_GET["mode"] == "upload" ? FLAG_ON : FLAG_OFF));
			?>';
		var err_msg = '<?php
			print((isset($_SESSION["err_msg"]) ? $_SESSION["err_msg"] : ""));
			?>';
		var template_kind = '<?php
			print((isset($_SESSION["use_template_kind"]) ? $_SESSION["use_template_kind"] : ""));
			?>';
		<?php
		unset($_SESSION["err_msg"]);
		?>
		var POST = new Object();
		POST["url"] = '<?php
			print((isset($_POST["url"]) ? javaStringEscape($_POST["url"]) : ""));
			?>';
		POST["width"] = '<?php
			print((isset($_POST["width"]) ? javaStringEscape($_POST["width"]) : ""));
			?>';
		POST["height"] = '<?php
			print((isset($_POST["height"]) ? javaStringEscape($_POST["height"]) : ""));
			?>';
		POST["alt"] = '<?php
			print((isset($_POST["alt"]) ? javaStringEscape($_POST["alt"]) : ""));
			?>';
		<?php
		//上書きがあった場合、編集画面に表示されている画像を差し替える
		if (isset($_SESSION["updata_file"]) && count($_SESSION["updata_file"]) > 0) {
			$script = 'var targetArea = window.top.CKEDITOR.currentInstance.window.$.document.body;' . "\n";
			$script .= 'var img_ary = targetArea.getElementsByTagName(\'img\');' . "\n";
			$script .= 'var updata_ary = [' . "\n";
			foreach ((array)$_SESSION["updata_file"] as $val) {
				$script .= '"' . $val . '",' . "\n";
			}
			$script = substr($script, 0, strrpos($script, ",")) . "\n";
			$script .= ']' . "\n";
			//FCKeditor部分の画像差し替え
			$script .= 'for(var i = 0;i < updata_ary.length;i++){' . "\n";
			$script .= 'for(var j = 0;j < img_ary.length;j++){' . "\n";
			$script .= 'if(updata_ary[i] == img_ary[j].src.substring(img_ary[j].src.indexOf(baseUrl),(img_ary[j].src.indexOf(\'?\') > 0 ? img_ary[j].src.indexOf(\'?\') : img_ary[j].src.length))){' . "\n";
			$rnd = rand();
			$script .= 'cxPreImages(updata_ary[i] + "?rnd=' . $rnd . '");' . "\n";
			$script .= 'img_ary[j].src = updata_ary[i] + "?rnd=' . $rnd . '";' . "\n";
			$script .= '}' . "\n";
			$script .= '}' . "\n";
			$script .= '}' . "\n";
			//編集ページの画像差し替え
			$script .= 'var edit_area = window.top.CKEDITOR.currentInstance.window.$.frameElement.parentElement;' . "\n";
			$script .= 'while(edit_area.tagName.toLowerCase() != "body"){ edit_area = edit_area.parentElement; }' . "\n";
			$script .= 'var img_ary = edit_area.document.body.getElementsByTagName(\'img\');' . "\n";
			$script .= 'for(var i = 0;i < updata_ary.length;i++){' . "\n";
			$script .= 'for(var j = 0;j < img_ary.length;j++){' . "\n";
			$script .= 'if(updata_ary[i] == img_ary[j].src.substring(img_ary[j].src.indexOf(baseUrl),(img_ary[j].src.indexOf(\'?\') > 0 ? img_ary[j].src.indexOf(\'?\') : img_ary[j].src.length))){' . "\n";
			$rnd = rand();
			$script .= 'cxPreImages(updata_ary[i] + "?rnd=' . $rnd . '");' . "\n";
			$script .= 'img_ary[j].src = updata_ary[i] + "?rnd=' . $rnd . '";' . "\n";
			$script .= '}' . "\n";
			$script .= '}' . "\n";
			$script .= '}' . "\n";
			print($script);
			unset($_SESSION["updata_file"]);
		}
		?>
		<?php
		echo loadSettingVars();
		?>
		//ライブラリ
		if (get_mode == "library") {
			if (!window.top.CKEDITOR.currentInstance.getSelection().getSelectedElement() && POST['url'] == "" || window.top.CKEDITOR.currentInstance.getSelection().getSelectedElement() && select_upload == FLAG_ON) {
				location.href = HTTP_ROOT + RPW + "/ckeditor/plugins/gd_image_widget/pages/fck_image_list.php?mode=library";
			}
		}
		//-->
	</script>
</head>
<body>
<div id="cms8341-headareaZero" style="margin-bottom: 0px !important">
	<div id="divProperty">
		<div id="cms8341-tab" class="cke_dialog_tabs">
			<table border="0" cellspacing="0" cellpadding="0"
				 style="border-collapse: collapse;">
				<tr>
					<td><a href="fck_image.php?mode=upload" class="cke_dialog_tab"><span> PCから選んで登録 </span></a></td>
					<td><a class="cke_dialog_tab cke_dialog_tab_selected"><span> 登録済画像から選択 </span></a></td>
				</tr>
			</table>
		</div>
		<table width="100%" height="520px" cellspacing="0" cellpadding="5" class="cke_dialog_contents"
			 style="background-color: #FFFFFF; border-top: solid 1px #999999;">
			<tr>
				<td valign="top">
					<div
							style="border-collapse: collapse; text-align: left; padding: 15px 2px 10px 2px; align: center">
						<form name="cms_fck_image_property" id="cms_fck_image_property"
							 action="javascript:void(0)" method="post"
							 enctype="multipart/form-data"
							 onsubmit="cxSubmit_Property(); return false;">
							<table width="100%" border="0" cellspacing="0" align="center"
								 style="border: solid 1px #999999;">
								<tr>
									<td width="30%" align="center" valign="top" rowspan="3"
										style="padding-top: 20px;"><img id="imgPreview"
																		src="<?= RPW ?>/admin/images/spacer.gif" alt=""
																		width="0"
																		height="0"></td>
									<td width="70%" align="center" valign="top"
										style="border-left: solid 1px #999999; border-bottom: solid 1px #999999; padding-left: 5px; padding-top: 5px; padding-bottom: 5px;"
										nowrap>
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr style="padding-top: 10px;">
												<td
														style="font-size: 15px; font-weight: bold;"><span
															class="cke_dialog_ui_labeled_label"
															fckLang="DlgImgAlt">Short Description</span></td>
											</tr>
											<tr>
												<td><input id="txtAlt" class="cke_dialog_ui_input_text"
														 style="WIDTH: 90%" type="text" maxlength="64"></td>
											</tr>
											<tr style="padding-bottom: 10px;">
												<td style="padding-left: 1px;"><input id="chkAlt"
																					 type="checkbox"
																					 onClick="setAlt();"><label
															for="chkAlt"><span class="cke_dialog_ui_labeled_label"
																			 fckLang="DlgImgAlt_Check">CheckBox Label</span></label>
												</td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td style="border-left: solid 1px #999999; border-bottom: solid 1px #999999; margin: 0px; padding-left: 5px; padding-top: 5px; padding-bottom: 5px;">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr style="padding-left: 5px;">
												<td style="width: 20px;"><label for="txtWidth"><span
																class="cke_dialog_ui_labeled_label"
																fckLang="DlgImgWidth">Width</span>&nbsp;</label></td>
												<td style="width: 50px;"><input name="txtWidth" type="text"
																				id="txtWidth"
																				class="cke_dialog_ui_input_text"
																				onkeyup="OnSizeChanged('WIDTH');"
																				style="width: 50px;"
																				style="ime-mode: disabled"
																				onkeypress="return IsDigit();"></td>
												<td nowrap rowspan="2" style="width: 20px;">
													<div id="btnLockSizes" class="BtnLocked"
														 onmouseover="this.className = (bLockRatio ? 'BtnLocked' : 'BtnUnlocked' ) + ' BtnOver';"
														 onmouseout="this.className = (bLockRatio ? 'BtnLocked' : 'BtnUnlocked' );"
														 title="Size Locked" onclick="SwitchLock(this);"></div>
												</td>
												<td nowrap rowspan="2">
													<div id="btnResetSize" class="BtnReset"
														 onmouseover="this.className='BtnReset BtnOver';"
														 onmouseout="this.className='BtnReset';" title="Size Reset"
														 onclick="ResetSizes();"></div>
												</td>
											</tr>
											<tr>
												<td style="width: 20px;"><label for="txtHeight"><span
																class="cke_dialog_ui_labeled_label"
																fckLang="DlgImgHeight">Height</span>&nbsp;</label></td>
												<td><input name="txtHeight" type="text" id="txtHeight"
														 class="cke_dialog_ui_input_text"
														 onkeyup="OnSizeChanged('HEIGHT');" style="width: 50px;"
														 style="ime-mode: disabled" onkeypress="return IsDigit();">
												</td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td style="border-left: solid 1px #999999; padding-left: 5px; padding-top: 5px; padding-bottom: 5px;">
										<input type="hidden"
											 id="cmbAlign" value="">
										<table width="100%" border="0" cellspacing="0" cellpadding="0"
											 style="margin: 0px;">
											<tr style="padding-top: 5px; padding-bottom: 5px;">
												<td align="left" valign="top"><span
															fckLang="DlgImgAlign"
															class="cke_dialog_ui_labeled_label">Image Align</span></br>
												</td>
											</tr>
											<tr style="padding-top: 5px; padding-left: 5px;">
												<td width="120" align="left" valign="top"
													style="padding-left: 10px;"><a href="#" onClick="alignSet('')"><img
																src="<?=RPW?>/ckeditor/gd_files/image/icon_normal.gif" alt=""
																width="80" height="40"
																border="0"></a>
													<div style="margin: 5px 0px;"><input type="radio" name="align"
																						 id="align01" value=""
																						 onClick="alignSet(this.value)">
														<label
																for="align01"><span fckLang="DlgImgAlignNo"
																					class="cke_dialog_ui_labeled_label">No Specification</span></label>
													</div>
												</td>
												<td width="120" align="left" valign="top"
													style="padding-left: 10px;"><a href="#"
																				 onClick="alignSet('left')"><img
																src="<?=RPW?>/ckeditor/gd_files/image/icon_left.gif"
																alt="" width="80" height="40" border="0"></a>
													<div style="margin: 5px 0px;"><input type="radio" name="align"
																						 id="align02" value="left"
																						 onClick="alignSet(this.value)">
														<label
																for="align02"><span fckLang="DlgImgAlignLeft"
																					class="cke_dialog_ui_labeled_label">Left</span></label>
													</div>
												</td>
												<td width="120" align="left" valign="top"
													style="padding-left: 10px;"><a href="#"
																				 onClick="alignSet('right')"><img
																src="<?=RPW?>/ckeditor/gd_files/image/icon_right.gif"
																alt="" width="80" height="40" border="0"></a>
													<div style="margin: 5px 0px;"><input type="radio" name="align"
																						 id="align03" value="right"
																						 onClick="alignSet(this.value)">
														<label
																for="align03"><span fckLang="DlgImgAlignRight"
																					class="cke_dialog_ui_labeled_label">Right</span></label>
													</div>
												</td>
											</tr>
											<tr style="padding-top: 5px; padding-bottom: 10px;">
												<td width="120" align="left" valign="top"
													style="padding-left: 10px;"><a href="#"
																				 onClick="alignSet('middle')"><img
																src="<?=RPW?>/ckeditor/gd_files/image/icon_center.gif"
																alt="" width="80" height="40" border="0"></a>
													<div style="margin: 5px 0px;"><input type="radio" name="align"
																						 id="align04" value="middle"
																						 onClick="alignSet(this.value)">
														<label
																for="align04"><span fckLang="DlgImgAlignMiddle"
																					class="cke_dialog_ui_labeled_label">Middle</span></label>
													</div>
												</td>
												<td width="120" align="left" valign="top"
													style="padding-left: 10px;"><a href="#"
																				 onClick="alignSet('top')"><img
																src="<?=RPW?>/ckeditor/gd_files/image/icon_top.gif"
																alt="" width="80" height="40" border="0"></a>
													<div style="margin: 5px 0px;"><input type="radio" name="align"
																						 id="align05" value="top"
																						 onClick="alignSet(this.value)">
														<label
																for="align05"><span fckLang="DlgImgAlignTop"
																					class="cke_dialog_ui_labeled_label">Top</span></label>
													</div>
												</td>
												<td width="120" align="left" valign="top"
													style="padding-left: 10px;"><a href="#"
																				 onClick="alignSet('bottom')"><img
																src="<?=RPW?>/ckeditor/gd_files/image/icon_bottom.gif"
																alt="" width="80" height="40" border="0"></a>
													<div style="margin: 5px 0px;"><input type="radio" name="align"
																						 id="align06" value="bottom"
																						 onClick="alignSet(this.value)">
														<label
																for="align06"><span fckLang="DlgImgAlignBottom"
																					class="cke_dialog_ui_labeled_label">Bottom</span></label>
													</div>
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							<div align="center" style="margin: 15px 0px;"><input type="submit"
																				 name="submit_property"
																				 id="submit_property"
																				 value="設定"
																				 class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_grey">
								&nbsp; &nbsp; &nbsp; <a
										href="fck_image_list.php" class="cke_dialog_ui_button">一覧画面へ</a></div>
						</form>
				</td>
			</tr>
		</table>
	</div>
	<div id="divUpload" style="DISPLAY: none">
		<div id="cms8341-tab" class="cke_dialog_tabs">
			<table border="0" cellspacing="0" cellpadding="0"
				 style="border-collapse: collapse;">
				<tr>
					<td><a href="fck_image.php?mode=upload" class="cke_dialog_tab cke_dialog_tab_selected"><span> PCから選んで登録 </span></a>
					</td>
					<td><a class="cke_dialog_tab" href="fck_image_list.php"><span> 登録済画像から選択 </span></a></td>
				</tr>
			</table>
		</div>
		<table width="100%" height="510px" cellspacing="0" cellpadding="0" class="cke_dialog_contents">
			<tr>
				<td valign="top">
					<form name="cms_fck_image_upload" id="cms_fck_image_upload"
						 action="fck_image_upload.php" method="post"
						 enctype="multipart/form-data"
						 onsubmit="cxSubmit_Upload('<?= $real_base_path ?>'); return false;">
						<?php
						for ($i = 0; $i < 5; $i++) {
							print('<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center" class="cms8341-dataTable" style="border-collapse:collapse;margin-top: 10px;">');
							print('<tr>');
							print('<th width="15%" align="left" valign="top" class="cke_dialog_ui_labeled_label">画像名称' . ($i + 1) . '</th>');
							print('<td width="85%" valign="top">');
							print('<input id="cms_image_name_' . $i . '" name="cms_image_name_' . $i . '" style="WIDTH: 98%;" type="text" class="cke_dialog_ui_input_text" maxlength="64" value="' . (isset($POST['cms_image_name_' . $i]) ? htmlDisplay($POST['cms_image_name_' . $i]) : "") . '">');
							print('</td>');
							print('</tr>');
							print('<tr>');
							print('<th width="15%" align="left" valign="top" class="cke_dialog_ui_labeled_label">ファイル' . ($i + 1) . '</th>');
							print('<td width="85%">');
							print('<label width="10%" for="cms_image_path_' . $i . '" class="cke_dialog_ui_button cke_dialog_ui_button_padding" style="margin-left: 1px;">参照</label> <span type="text"id="file-selected_' . $i . '"></span>');
							print('</td>');
							print('<input id="cms_image_path_' . $i . '" style="visibility:hidden; display: none;" name="cms_image_path_' . $i . '" type="file">');
							print('<script> var filetype_' . $i . ' = document.getElementById("cms_image_path_' . $i . '"); filetype_' . $i . '.onchange = function(){ var fileName = ""; fileName = filetype_' . $i . '.value; document.getElementById("file-selected_' . $i . '").innerHTML = fileName.replace(/^.*[\\\/]/, ""); };</script>');
							print('</tr>');
							print('</table>');
							print('<input type="hidden" id="cms_rename_file_path_' . $i . '" name="cms_rename_file_path_' . $i . '">');

						}
						?>
						<br/>
						<br/>
						<div align="center"><input type="submit" class="cke_dialog_ui_button cke_dialog_ui_button_grey"
												 name="submit_upload"
												 id="submit_upload" style="padding-right: 30px; padding-left: 30px;"

												 value="登録"></div>
					</form>
				</td>
			</tr>
		</table>
	</div>
	<?php
	print($objTool->setAccessibility());
	?>
</div>
</td>
</tr>
</table>
</body>
</html>
