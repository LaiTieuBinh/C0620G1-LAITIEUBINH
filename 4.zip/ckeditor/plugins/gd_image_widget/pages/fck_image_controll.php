<?php
/*
 * 画像編集
 */
// -- 共通設定ファイル ----------------------------------------------------------- //
require(".htsetting");
// -- ページ内専用 関数ファイル -- //
require_once(dirname(__FILE__) . '/fck_image_controll.inc');

// -- エラー画面設定 -- //
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

// -- インクルード -- //
global $objCnc;
global $objLogin;

require_once(APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once(APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once(APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once(APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);
require_once(APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_shared_upload.inc');
$objShared = new tbl_shared_upload($objCnc);

// -- ページ内定数 --------------------------------------------------------------- //


define("RESIZE_MODE", "RESIZE"); // リサイズ
define("TRIMMING_MODE", "TRIMMING"); // トリミング
define("CANCEL_MODE", "CANCEL"); // キャンセル
define("DECISION_MODE", "DECISION"); // 決定


// -- 初期化 --------------------------------------------------------------------- //


// 画像情報格納配列
$image = array(
    "name" => "",  // 画像名称
    "path" => "",  // 画像パス
    "width" => 0,  // X
    "height" => 0,  // Y
    "picture" => "" // 表示する画像パス
);

// 画像編集情報格納配列
$editImage = array(
    "width" => 0,  // リサイズX
    "height" => 0,  // リサイズY
    "x1" => 0,  // トリミング左上座標X
    "y1" => 0,  // トリミング左上座標Y
    "y2" => 0,  // トリミング右下座標X
    "y2" => 0 // トリミング右下座標Y
);

// DBへ書き込む値
$db_value = array(
    "name" => "",  // 画像名称
    "path" => "" // 画像パス
);

// 現在のページパス
$page_path = "";

// エラーメッセージ
$errMsg = "";
$exitFlg = FLAG_OFF;

// 各種フラグ
$resizeFlg = FLAG_OFF; // リサイズフラグ
$trimmingFlg = FLAG_OFF; // トリミングフラグ
$cancelFlg = FLAG_OFF; // キャンセルフラグ
$decisionFlg = FLAG_OFF; // 決定フラグ
$rewriteFlg = FLAG_OFF; // 上書きフラグ
$endFlg = FLAG_OFF; // 処理終了フラグ
$rewriteEnable = FLAG_OFF; // 上書き可能フラグ
$imgUseFlg = FLAG_OFF; // 画像使用フラグ


// -- 作業ID(ユニークフォルダ名に使用)の取得 ----------------------------------- //


if (!isset($_POST['cms_fckimage_edit_id'])) {
    // 現在時間で新規作成
    $editID = uniqid(TRUE);
    //強制フラグON
    $rewriteFlg = FLAG_ON;
} else {
    // POST値がある場合は引き継ぐ
    $editID = $_POST['cms_fckimage_edit_id'];
}

// -- 画像IDの取得 -------------------------------------------------------------- //


// GET値より取得
if (isset($_GET['id'])) {
    $imageID = $_GET['id'];
}

// POST値より取得
if (isset($_POST['cms_fckimage_id'])) {
    $imageID = $_POST['cms_fckimage_id'];
}

// IDを取得できない場合はエラー
if (!isset($imageID)) {
    user_error("編集を行う画像が選択されていません。", E_USER_ERROR);
}

// -- 登録情報の取得 ------------------------------------------------------------- //


if ($objFCKImages->selectFCKImageID($imageID) !== FALSE) {
    // DB情報取得 --------------------------------------------- //


    // パスの取得
    $page_path = cms_dirname($objFCKImages->fld['path']);
    $image['path'] = $objFCKImages->fld['path'];
    $image['picture'] = $image['path'];
    // フルパスの作成
    $image['filename'] = DOCUMENT_ROOT . RPW . $objFCKImages->fld['path'];

    // DB登録用のデータを作成 --------------------------------- //
    $db_value['id'] = $objFCKImages->fld['id'];
    $db_value['name'] = $objFCKImages->fld['name'];
    $db_value['path'] = $objFCKImages->fld['path'];

    // -- 画像の存在チェック ---------------------------------- //
    if (!@file_exists($image['filename'])) {
        user_error("指定した画像は存在しません。削除された可能性があります。", E_USER_ERROR);
    }

    // 画像情報取得(GD) --------------------------------------- //
    $imgData = getimagesize($image['filename']);
    // 画像サイズ
    $image['width'] = $imgData[0];
    $image['height'] = $imgData[1];

    $retWidth = $imgData[0];
    $retHeight = $imgData[1];

    // 画像の使用状況 ----------------------------------------- //


    //前のモードが通常ページの場合
    if (isset($_SESSION['cms_page_id'])) {
        if (!isset($_GET['prev_page']) || !in_array($_GET['prev_page'], array(
                "autolink",
                "library"
            ))) {
            // 公開テーブルより取得
            $objImages->selectFromPageID($_SESSION['cms_page_id'], PUBLISH_TABLE);
            while ($objImages->fetch()) {
                if ($image['path'] == $objImages->fld['src']) {
                    $imgUseFlg = FLAG_ON;
                    break;
                }
            }
            // 作業テーブルより情報取得
            if ($imgUseFlg == FLAG_OFF) {
                $objImages->selectFromPageID($_SESSION['cms_page_id'], WORK_TABLE);
                while ($objImages->fetch()) {
                    if ($image['path'] == $objImages->fld['src']) {
                        $imgUseFlg = FLAG_ON;
                        break;
                    }
                }
            }
        }
    }
} else {
    // DB より情報を取得できない場合はエラー ------------------ //
    user_error("ファイル情報の取得に失敗しました。ファイル情報が削除された可能性があります。", E_USER_ERROR);
}

// -- 編集権限のチェック ---------------------------------------------------------- //
$chk_image_path = FCK_IMAGES_FORDER_SHARED;
$chk_image_path .= (preg_match("/\/$/i", $chk_image_path)) ? "" : "/";
$edit_image_path = $db_value['path'];

if (preg_match("/^" . reg_replace($chk_image_path) . "/i", $edit_image_path)) {
    if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
        // 編集不可能
        user_error("指定した画像に対する編集権限がありません。", E_USER_ERROR);
    }
}

// 上書きフラグオン
if (isset($_GET['prev_page']) && in_array($_GET['prev_page'], array(
        "autolink",
        "library"
    ))) {
    $rewriteEnable = FLAG_OFF;
    $rewriteFlg = FLAG_OFF;
} else
    $rewriteEnable = FLAG_ON;

// -- 編集フラグを取得 ------------------------------------------------------------ //


if (isset($_POST['cms_fckimage_edit_mode'])) {

    if ($_POST['cms_fckimage_edit_mode'] == RESIZE_MODE) {

        // リサイズフラグセット ------------------------------- //
        $resizeFlg = FLAG_ON;

    } elseif ($_POST['cms_fckimage_edit_mode'] == TRIMMING_MODE) {

        // トリミングフラグセット ----------------------------- //
        $trimmingFlg = FLAG_ON;

    } elseif ($_POST['cms_fckimage_edit_mode'] == CANCEL_MODE) {

        // キャンセルフラグセット ----------------------------- //
        $cancelFlg = FLAG_ON;

    } elseif ($_POST['cms_fckimage_edit_mode'] == DECISION_MODE) {

        // 決定フラグセット ----------------------------------- //
        $decisionFlg = FLAG_ON;
    }

}
// 上書きフラグ
if (isset($_POST['cms_fckimage_rewrite_flg'])) $rewriteFlg = $_POST['cms_fckimage_rewrite_flg'];

// -- コピー先画像名を決定 -------------------------------------------------------- //


if (in_array(FLAG_ON, array(
    $resizeFlg,
    $trimmingFlg,
    $cancelFlg,
    $decisionFlg
))) {

    // tempフォルダ内にユーザーIDのフォルダを作成 ------------- //
    $tmpDir = DOCUMENT_ROOT . DIR_PATH_UPLOAD . "/temp/" . $objLogin->get('user_id');
    if (!@is_dir($tmpDir)) {
        if (!@mkdir($tmpDir)) {
            user_error('画像編集用フォルダの作成に失敗しました。', E_USER_ERROR);
        }
        chmod($tmpDir, 0777);
    }

    // ユーザーIDフォルダ内にユニークIDフォルダを作成 --------- //
    $tmpDir .= "/" . $editID;
    if (!@is_dir($tmpDir)) {
        if (!@mkdir($tmpDir)) {
            user_error('画像編集用フォルダの作成に失敗しました。', E_USER_ERROR);
        }
        chmod($tmpDir, 0777);
    }

    // コピー先画像パスの決定 --------------------------------- //
    $image['copyfile'] = copyfilename_create($image['filename'], $objLogin->get('user_id'), $tmpDir . "/");

}

while (1) {

    // -- 画像編集処理 ---------------------------------------------------------------- //


    if ($resizeFlg == FLAG_ON) {

        // -- リサイズ -------------------------------------------- //


        // POSTのチェック
        if (!isset($_POST['cms_fckimage_rs_x']) || !isset($_POST['cms_fckimage_rs_y'])) {
            // POSTを取得できない場合エラー
            $errMsg = "画像のサイズ変更に失敗しました。";
            $exitFlg = FLAG_ON;
            break;
        }

        // POST取得
        if (isset($_POST['cms_fckimage_edit_picture'])) $image['filename'] = DOCUMENT_ROOT . RPW . $_POST['cms_fckimage_edit_picture'];
        $resize['width'] = $_POST['cms_fckimage_rs_x'];
        $resize['height'] = $_POST['cms_fckimage_rs_y'];

        // リサイズ
        if (fck_image_resize($image['filename'], $image['copyfile'], $resize['width'], $resize['height']) === FALSE) {
            $errMsg = "画像のサイズ変更に失敗しました。";
            $exitFlg = FLAG_ON;
            break;
        }
        chmod($image['copyfile'], 0777);

    } elseif ($trimmingFlg == FLAG_ON) {

        // -- トリミング ----------------------------------------- //


        // POSTのチェック
        if (!isset($_POST['cms_fckimage_tm_x1']) || !isset($_POST['cms_fckimage_tm_y1']) || !isset($_POST['cms_fckimage_tm_x2']) || !isset($_POST['cms_fckimage_tm_y2'])) {
            // POSTを取得できない場合エラー
            $errMsg = "画像の切り抜きに失敗しました。";
            $exitFlg = FLAG_ON;
            break;
        }

        // POST取得
        if (isset($_POST['cms_fckimage_edit_picture'])) $image['filename'] = DOCUMENT_ROOT . RPW . $_POST['cms_fckimage_edit_picture'];
        $trimming['x1'] = $_POST['cms_fckimage_tm_x1'];
        $trimming['y1'] = $_POST['cms_fckimage_tm_y1'];
        $trimming['x2'] = $_POST['cms_fckimage_tm_x2'];
        $trimming['y2'] = $_POST['cms_fckimage_tm_y2'];

        // トリミング
        if (fck_image_trimming($image['filename'], $image['copyfile'], $trimming['x1'], $trimming['y1'], $trimming['x2'], $trimming['y2']) === FALSE) {
            $errMsg = "画像の切り抜きに失敗しました。";
            $exitFlg = FLAG_ON;
            break;
        }
        chmod($image['copyfile'], 0777);

    } elseif ($cancelFlg == FLAG_ON) {

        // -- キャンセル ------------------------------------------ //


        // 一つ前の編集画像取得＆最新の編集削除
        $image['copyfile'] = imageeditcancel($image['filename'], $objLogin->get('user_id'), $tmpDir . "/");
        // 一つ前の編集がなければ元画像をセット
        if ($image['copyfile'] == "") {
            $image['copyfile'] = $image['filename'];
        }

    } elseif ($decisionFlg == FLAG_ON) {

        // -- 決定 ----------------------------------------------- //


        // 編集した画像の最新を取得
        $image['copyfile'] = getcopyfilename($image['filename'], $objLogin->get('user_id'), $tmpDir . "/");
        // 編集した画像がない場合は登録されている画像
        if (!@file_exists($image['copyfile'])) {
            $image['copyfile'] = $image['filename'];
        }

        // トランザクション開始
        $objCnc->begin();

        if ($rewriteFlg == FLAG_ON) {

            // -- 上書き ----------------- //


            // DB 情報の追加
            $db_value['update_datetime'] = "NOW";

            if ($objFCKImages->update($db_value) === FALSE) {
                // 編集失敗
                $objCnc->rollback();
                $errMsg = "画像の登録に失敗しました。";
                $exitFlg = FLAG_ON;
                break;
            }

        } else {

            // -- 新規追加 --------------- //


            // FCK_IMAGES_FORDERを作成
            if (!@is_dir(DOCUMENT_ROOT . RPW . $page_path)) {
                if (!@mkdir(DOCUMENT_ROOT . RPW . $page_path)) {
                    $objCnc->rollback();
                    $errMsg = "画像の登録に失敗しました。";
                    $exitFlg = FLAG_ON;
                    break;
                }
                chmod(DOCUMENT_ROOT . RPW . $page_path, 0777);
            }

            // 登録するファイル名
            //				$image['filename'] = copyfilename_create( $db_value['path'], $objLogin->get('user_id'), DOCUMENT_ROOT . RPW . $page_path . "/" );
            $image['filename'] = DOCUMENT_ROOT . RPW . $page_path . "/" . $_POST['cms_filelink_path'] . substr($db_value['path'], strrpos($db_value['path'], "."));
            $db_value['path'] = str_replace(DOCUMENT_ROOT . RPW, "", $image['filename']);
            $db_value['name'] = $_POST['cms_filelink_name'];

            // DB情報の削除
            if (isset($db_value['id'])) unset($db_value['id']); // IDは自動付加


            // 画像が存在する場合はエラー
            if (@file_exists($image['filename'])) {
                // 編集失敗
                $objCnc->rollback();
                $errMsg = "既に同名のファイルが存在しています。";
                break;
            }
            //「tbl_fck_images」に同じパスが存在する場合、削除する
            if ($objFCKImages->selectFCKImage($db_value['path'])) {
                if (!$objFCKImages->deleteFromImagePath($db_value['path'])) {
                    // 編集失敗
                    $err_msg = "データベースの更新に失敗しました。";
                    $objCnc->rollback();
                    break;
                }
            }
            //「tbl_fck_images」に作成した画像情報の登録
            if ($objFCKImages->insert($db_value) === FALSE) {
                // 編集失敗
                $objCnc->rollback();
                $errMsg = "画像の登録に失敗しました。";
                $exitFlg = FLAG_ON;
                break;
            }
        }

        // -- 画像コピー ----------------- //


        if (fck_image_copy($image['copyfile'], $image['filename']) === FALSE) {
            // コピー失敗
            $objCnc->rollback();
            $errMsg = "画像の登録に失敗しました。";
            break;
        }
        chmod($image['filename'], 0777);
		
		$file_path = str_replace(DOCUMENT_ROOT . RPW, "", $image['filename']);
		// handle tbl_shared_upload
		if (preg_match('/^(' . reg_replace(FCK_IMAGES_FORDER_SHARED) . '|' . reg_replace(FCK_IMAGES_FORDER_LIBRARY) . ')/i', $file_path)) {
			$upload_class = ($rewriteFlg == FLAG_ON) ? $objShared::SHARED_OVERWRITE : $objShared::SHARED_NEW;
			$errMsg = $objShared->add_data($file_path, $upload_class);
			if ($errMsg != '') {
				$objCnc->rollback();
				break;
			}
		}
        // コミット
        $objCnc->commit();

        // 画像情報取得用に
        $image['copyfile'] = $image['filename'];

        // 処理終了フラグオン
        $endFlg = FLAG_ON;
        // エラーが無ければ終了
        if ($errMsg == "") $exitFlg = FLAG_ON;
    }

    // 処理を行った場合 画像情報の再取得 ---------------------------------------------- //


    if (in_array(FLAG_ON, array(
        $resizeFlg,
        $trimmingFlg,
        $cancelFlg,
        $decisionFlg
    ))) {
        // 画像情報取得(GD)
        $imgData = getimagesize($image['copyfile']);
        // 画像サイズ
        $image['width'] = $imgData[0];
        $image['height'] = $imgData[1];
        // 表示画像
        $image['picture'] = str_replace(DOCUMENT_ROOT . RPW, "", $image['copyfile']);

        // 上書きの場合は更新
        if (!in_array(FLAG_OFF, array(
            $rewriteFlg,
            $decisionFlg
        ))) {
            $retWidth = $imgData[0];
            $retHeight = $imgData[1];
        }
    }

    break;
}

// -- エラーメッセージが存在すれば終了 ------------------------------------------- //
if (strlen($errMsg) > 0) {
    $endFlg = FLAG_ON;
}

// -- HTML 出力 ------------------------------------------------------------------ //


// ;


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <meta http-equiv="Content-Script-Type" content="text/javascript">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Expires" content="Thu, 01 Dec 1994 16:00:00 GMT">
    <title>画像編集</title>
    <base target="_self"/>
    <link rel="stylesheet" href="<?=RPW?>/ckeditor/gd_files/css/dialog.css" type="text/css">
    <link rel="stylesheet" href="<?= RPW ?>/admin/style/cropper.css" type="text/css">
    <script src="<?= RPW ?>/admin/js/shared.js" type="text/javascript"></script>
    <script src="<?= RPW ?>/admin/js/library/prototype.js" type="text/javascript"></script>
    <script src="<?= RPW ?>/admin/js/library/scriptaculous.js?load=builder,dragdrop" type="text/javascript"></script>
    <script src="<?= RPW ?>/admin/js/library/cropper.js" type="text/javascript"></script>
    <script src="<?= RPW ?>/ckeditor/gd_files/js/dialog_common.js" type="text/javascript"></script>
    <script src="<?= RPW ?>/ckeditor/plugins/gd_image_widget/pages/js/com_func.js" type="text/javascript"></script>
    <script src="<?= RPW ?>/ckeditor/plugins/gd_image_widget/pages/js/fck_image_controll.js" type="text/javascript"></script>
    <script type="text/javascript">
        <!--
        // -- CMS 定数のロード -- //

        <?php
        echo loadSettingVars();
        ?>

        // -- ページ内 定数 -- //

        // 編集モード
        var RESIZE_MODE = "<?=RESIZE_MODE?>";		// リサイズ
        var TRIMMING_MODE = "<?=TRIMMING_MODE?>";	// トリミング
        var CANCEL_MODE = "<?=CANCEL_MODE?>";		// キャンセル
        var DECISION_MODE = "<?=DECISION_MODE?>";	// 決定

        // 編集画像情報
        var IMAGE_MAX_X = <?=$image['width']?>;	// 横幅の最大値
        var IMAGE_MAX_Y = <?=$image['height']?>;// 高さの最大値

        // ディスプレイの画面サイズ
        var SCREEN_WIDTH = screen.width;
        var SCREEN_HEIGHT = screen.height;

        // 表示するダイアログサイズ
        var WINDOW_X_MIN = 560;		// 横幅	最小
        var WINDOW_X_MAX = 980;		// 		最大
        var WINDOW_Y_MIN = 570;		// 高さ	最小
        var WINDOW_Y_MAX = 690;		// 		最大

        var windowSizeX = (IMAGE_MAX_X + 217);	// 画像サイズに合わせて
        var windowSizeY = (IMAGE_MAX_Y + 137);	// ダイアログの大きさを調整

        // -- ウィンドウサイズの調整 -- //

        // 横幅の調整
        if (windowSizeX < WINDOW_X_MIN) {
            windowSizeX = WINDOW_X_MIN;
        }
        if (windowSizeX > WINDOW_X_MAX) {
            windowSizeX = WINDOW_X_MAX;
        }
        // 縦幅の調整
        if (windowSizeY < WINDOW_Y_MIN) {
            windowSizeY = WINDOW_Y_MIN;
        }
        if (windowSizeY > WINDOW_Y_MAX) {
            windowSizeY = WINDOW_Y_MAX;
        }

        // ウィンドウサイズ変更
        window.dialogWidth = windowSizeX + "px";
        window.dialogHeight = windowSizeY + "px";
        // ウィンドウ位置調整(スクリーンの中心)
        window.dialogLeft = (SCREEN_WIDTH) / 2 - (windowSizeX / 2);
        window.dialogTop = (SCREEN_HEIGHT) / 2 - (windowSizeY / 2);

        // 処理終了フラグ
        var endFlg = <?=$endFlg?>;
        var exitFlg = <?=$exitFlg?>;
        // エラーメッセージ
        var errMsg = '<?=$errMsg?>';
        // 画像使用フラグ
        var imgUseFlg = <?=$imgUseFlg?>;

        // 戻値をセット
        var retObj = new Object();
        retObj['id'] = <?=$imageID?>;
        retObj['path'] = "<?=javaStringEscape($image['path'])?>";
        retObj['edit_id'] = "<?=javaStringEscape($editID)?>";
        retObj['width'] = "<?=$retWidth?>";
        retObj['height'] = "<?=$retHeight?>";

        //リセット用に画像名称とファイル名を保持
        var olg_file_name = '<?=javaStringEscape($db_value['name'])?>';
        var olg_file_path = '<?=htmlspecialchars(substr(basename($db_value['path']), 0, strrpos(basename($db_value['path']), ".")))?>';
        // -->
        function applyRatio() {
                cropperObject.remove()
                var r = document.getElementById("ratio");
                var selectedValue = r.options[r.selectedIndex].value;
                 if ( selectedValue == "free" ) { 
                	cropperObject = new Cropper.Img( 'cms_fckimage_picture', 
                        {onEndCrop: onEndCrop,
                                ratioDim: {
                                    x: 1, y: 1
                                },
                        }); 
                } else {
                slv = selectedValue.split(":");
                                	cropperObject = new Cropper.Img( 'cms_fckimage_picture', 
                        {onEndCrop: onEndCrop,
                                ratioDim: {
                                    x: slv[0], y: slv[1]
                                },
                        }); 
                }   
        }
    </script>
</head>
<body>
<div class="cke_dialog_title">画像編集<a href="javascript:cxIframeLayerCallback()" id="header_close" style="float: right; margin-top: 2px;"><img src="<?=RPW?>/ckeditor/skins/moono-lisa/images/close.png" alt="閉じる"></a></div>
<form name="cms_fck_image_controll" id="cms_fck_image_controll"
      action="fck_image_controll.php<?= (isset($_GET['prev_page']) ? "?prev_page=" . $_GET['prev_page'] : "") ?>"
      method="post" onSubmit="return cxResize()"><input type="hidden"
                                                        name="cms_fckimage_id" id="cms_filelink_id" value="<?= $imageID ?>"> <input
            type="hidden" name="cms_fckimage_tm_x1" id="cms_fckimage_tm_x1"
            value="0"> <input type="hidden" name="cms_fckimage_tm_y1"
                              id="cms_fckimage_tm_y1" value="0"> <input type="hidden"
                                                                        name="cms_fckimage_tm_x2" id="cms_fckimage_tm_x2" value="0"> <input
            type="hidden" name="cms_fckimage_tm_y2" id="cms_fckimage_tm_y2"
            value="0"> <input type="hidden" name="cms_fckimage_tm_width"
                              id="cms_fckimage_tm_width" value="0"> <input type="hidden"
                                                                           name="cms_fckimage_tm_height" id="cms_fckimage_tm_height" value="0"> <input
            type="hidden" name="cms_fckimage_edit_mode" id="cms_fckimage_edit_mode"
            value=""> <input type="hidden" name="cms_fckimage_edit_picture"
                             id="cms_fckimage_edit_picture" value="<?= $image['picture'] ?>"> <input
            type="hidden" name="cms_fckimage_edit_id" id="cms_fckimage_edit_id"
            value="<?= $editID ?>">
    <div style="cke_dialog_title">
        <table width="100%" height="307px" border="0" cellspacing="0"
               cellpadding="0" style="border-collapse: collapse;">
            <tr>
                <td width="100%" align="center" valign="top">
                    <div id="cms8341-searcharea"
                         style="text-align: center; padding: 7px 7px 7px 7px;">

                        <table width="536px" height="472px" align="left" border="0"
                               cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">

                            <tr align="center">

                                <td align="center">
                                        <table width="100%" align="left" valign="top" border="0">
                                            <tr>
                                                <td width="100%" rowspan="2">
                                                    <table border="0" cellspacing="0" cellpadding="5" align="center"
                                                           class="cms8341-dataTable"
                                                           style="border-collapse: collapse; border: solid 1px #CCCCCC; border-top: none">
                                                        <tr>
                                                            <th align="center" valign="middle">
                                                                <img src="<?= RPW . $image['picture'] ?>?rnd=<?= rand() ?>" alt="test image"
                                                                     id="cms_fckimage_picture" onload="imgOnLoadComp();">
                                                            </th>
                                                        </tr>
                                                    </table>
                                                </td>
                                                <td align="right" valign="top" border="0">

                                                    <table width="150px" border="0" cellspacing="0" cellpadding="5"
                                                           align="center" valign="top"
                                                           style="border-collapse: collapse;">
                                                        <tr>
                                                               <div style="padding: 20px 0px 10px 0px;">
                                                                   <label class="cke_dialog_ui_labeled_label">サイズ変更</label> 
                                                                   <select id="ratio" onchange="applyRatio()">
                                                                        <option value="free">自由</option>
                                                                        <option value="1:1">正方形</option>
                                                                        <option value="2:3">2:3</option>
                                                                        <option value="3:5">3:5</option>
                                                                         <option value="3:4">3:4</option>
                                                                        <option value="4:5">4:5</option>
                                                                        <option value="5:7">5:7</option>
                                                                        <option value="9:16">9:16</option>
                                                                  </select>                                                                 
                                                                </div>
                                                    </tr>
                                                        <tr>
                                                            <td width="50%"><label class="cke_dialog_ui_labeled_label"
                                                                                   for="cms_fckimage_rs_x">横幅</label></td>
                                                            <td width="50%"><input type="text" class="cke_dialog_ui_input_text"
                                                                                   name="cms_fckimage_rs_x" id="cms_fckimage_rs_x"
                                                                                   value="<?= $image['width'] ?>" size="3"
                                                                                   style="ime-mode: disabled" onKeyPress="return IsDigit();"
                                                                                   onChange="return cxAspect( $('cms_fckimage_rs_x'), $('cms_fckimage_rs_y'), IMAGE_MAX_X, IMAGE_MAX_Y, 0 );"
                                                                                   onKeyUp="return cxAspect( $('cms_fckimage_rs_x'), $('cms_fckimage_rs_y'), IMAGE_MAX_X, IMAGE_MAX_Y, 0 );"
                                                                                   tabindex="1"></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="50%"><label class="cke_dialog_ui_labeled_label"
                                                                                   for="cms_fckimage_rs_y">高さ</label></td>
                                                            <td width="50%"><input type="text"
                                                                                   name="cms_fckimage_rs_y" id="cms_fckimage_rs_y"
                                                                                   class="cke_dialog_ui_input_text"
                                                                                   value="<?= $image['height'] ?>" size="3"
                                                                                   style="ime-mode: disabled" onKeyPress="return IsDigit();"
                                                                                   onChange="return cxAspect( $('cms_fckimage_rs_x'), $('cms_fckimage_rs_y'), IMAGE_MAX_X, IMAGE_MAX_Y, 1 );"
                                                                                   onKeyUp="return cxAspect( $('cms_fckimage_rs_x'), $('cms_fckimage_rs_y'), IMAGE_MAX_X, IMAGE_MAX_Y, 1 );"
                                                                                   tabindex="2"></td>
                                                        </tr>
                                                    </table>
                                                    <table width="150px" height="376px">
                                                        <tr>
                                                            <td>

                                                   <div><a class="cke_dialog_ui_button"
                                                                        href="javascript:void(0)" onClick="return cxResize()">サイズ変更</a> <br><br>
                                                                    <div class="cke_dialog_ui_labeled_label ck_cms_required"
                                                                    >※横幅・高さの比率は<br>
                                                                        自動で調整されます。
                                                                    </div>
                                                                </div>
                                                                <div style="padding: 20px 0px 10px 0px;"><a class="cke_dialog_ui_button"
                                                                                                            href="javascript:void(0)"
                                                                                                            onClick="return cxTrimming()">切り抜き</a>
                                                                    <br> <br>
                                                                    <div class="cke_dialog_ui_labeled_label ck_cms_required"
                                                                    >※切り抜き範囲は画像を<br>
                                                                        ドラッグすることで<br>
                                                                        選択できます。
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td valign="bottom" align="center">
                                                                <div style="padding: 25px 0px 20px 0px;" align="center"
                                                                     valign="top"><a href="javascript:void(0)" class="cke_dialog_ui_button"
                                                                                     onClick="return cxCancel()">一つ前に戻す</a>
                                                                </div>
                                                                <div style="padding: 20px 0px 10px 0px;" align="center"><span
                                                                            style="<?= ($rewriteEnable == FLAG_OFF) ? 'display:none;' : ''; ?>"
                                                                            align="center">
								<input type="checkbox" name="cms_fckimage_rewrite_flg"
                                       id="cms_fckimage_rewrite_flg" value="<?= FLAG_ON ?>"
                                    <?= ($rewriteFlg == FLAG_ON) ? 'checked' : ''; ?>
                                       onClick="return cxRewriteChk('cms_fckimage_rewrite_flg')">&nbsp;<label class="cke_dialog_ui_labeled_label"
                                                                                                              for="cms_fckimage_rewrite_flg">上書き保存する</label> </span>
                                                                </div>
                                                                <div align="center"><a
                                                                            class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_grey"
                                                                            href="javascript:void(0)" onClick="return cxDecision()">決定</a></div>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                </td>
                            </tr>
                        </table>

                    </div>
                </td>

            </tr>

        </table>

    </div>
    <!--***ファイル保存先設定レイヤー　ここから***********-->
    <div id="cms8341-fck_image_reffer" class="cms8341-layer"
         style="width: 70%;">
        <table width="340" border="0" cellspacing="0" cellpadding="0">
            <tr>
                <td width="100%" align="center" valign="top" bgcolor="#DFDFDF"
                    style="border: solid 1px #343434;">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0"
                           class="cms8341-layerheader">
                        <tr>
                            <td align="left" valign="middle"><img
                                        src="<?= RPW ?>/admin/images/fckimage/title_setting_name.jpg"
                                        alt="名前を付けて保存" width="200" height="20" style="margin: 4px 10px;"></td>
                            <td width="78" align="right" valign="middle"><a href="javascript:"
                                                                            onClick="return cxLayer('cms8341-fck_image_reffer',0)"><img
                                            src="<?= RPW ?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
                                            height="19" border="0" style="margin: 4px 10px;"></a></td>
                        </tr>
                    </table>
                    <div
                            style="width: 300px; height: 75px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: center; vertical-align: middle; border: solid 1px #999999">
                        <table width="100%" border="0" cellpadding="5" cellspacing="0"
                               class="cms8341-dataTable"
                               style="border-collapse: collapse; border: solid 1px #CCCCCC;">
                            <tr>
                                <th align="left" valign="middle"><label for="cms_filelink_name">画像名称</label>


                                </td>
                                <td align="left" valign="middle"><input type="text"
                                                                        name="cms_filelink_name" id="cms_filelink_name"
                                                                        value="<?= htmlspecialchars($db_value['name']) ?>"
                                                                        style="width: 200px;" maxlength="64"></td>
                            </tr>
                            <tr>
                                <th align="left" valign="middle"><label for="cms_filelink_path">ファイル名</label>


                                </td>
                                <td align="left" valign="middle"><input type="text"
                                                                        name="cms_filelink_path" id="cms_filelink_path"
                                                                        value="<?= htmlspecialchars(substr(basename($db_value['path']), 0, strrpos(basename($db_value['path']), "."))) ?>"
                                                                        style="width: 150px; ime-mode: disabled;"><?= substr($db_value['path'], strrpos($db_value['path'], ".")) ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <p style="margin: 10px 0px;"><a href="javascript:void(0)"
                                                    onClick="return cxRefferSubmit('<?= htmlspecialchars(DOCUMENT_ROOT . RPW . cms_dirname($db_value['path'])) ?>')"><img
                                    src="<?= RPW ?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
                                    height="21" border="0"></a></p>
                </td>
            </tr>
        </table>
        <?php print($objTool->setAccessibility()); ?>
    </div>
    <!--***ファイル保存先設定レイヤー　ここまで***********--></form>
</body>
</html>
