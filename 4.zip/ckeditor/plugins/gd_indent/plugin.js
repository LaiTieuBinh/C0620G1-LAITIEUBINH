(function () {
//Section 1 : Code to execute when the toolbar button is pressed
    var outdent = {
        exec: function (editor) {
            var selection = editor.getSelection().getCommonAncestor();
            if(selection != null) {
                var element = selection.$.parentNode.tagName;
                if(element == "LI" || element == "OL" || element == "UL") {
                CKEDITOR.currentInstance.execCommand('outdent');
                    return;     
                }}
        var d = editor.window.$.document;
        d.execCommand('outdent');
        startDisabled: false 
    }};
    
    var indent = {
        exec: function (editor) {
            var d = editor.window.$.document;
           var selection = editor.getSelection();
            var ancestor = selection.getCommonAncestor();
            if(ancestor != null) {
            var element = ancestor.$.parentNode.tagName;
            if(element == "LI" || element == "OL" || element == "UL") {
                    CKEDITOR.currentInstance.execCommand('indent');
                    return;     			
            }}
            d.execCommand('indent');	   		
            var b = d.getElementsByTagName('blockquote');
            for (var i = 0; i < b.length; ++i) {
                b[i].removeAttribute("style");
                b[i].removeAttribute("dir");
            }        
        },
        startDisabled: false 
    };
    
//Section 2 : Create the button and add the functionality to it
    CKEDITOR.plugins.add('gd_indent', {
        lang: "en,ja",
        init: function (editor) {
            editor.addCommand('gd_indent', indent);
            editor.ui.addButton('GdIndent', {
                // icon: CKEDITOR.plugins.getPath('gd_indent') + 'logo_ckeditor.png',
                icon: this.path + 'icons/indent.png',
                label: editor.lang.gd_indent.indent,
                command: 'gd_indent'
        });
           editor.addCommand('gd_outdent', outdent);
           editor.ui.addButton('GdOutdent', {
                icon: this.path + 'icons/outdent.png',
                label: editor.lang.gd_indent.decrease_indent,
                command: 'gd_outdent'
            });
        }
    });
})();