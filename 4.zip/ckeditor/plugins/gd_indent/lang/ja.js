CKEDITOR.plugins.setLang( 'gd_indent', 'ja', {
	decrease_indent	: "インデント解除",
                  indent		: "インデント"
	} );