CKEDITOR.plugins.setLang( 'gd_indent', 'en', {
	decrease_indent	: "Decrease Indent",
                  indent		: "Indent",
	} );
