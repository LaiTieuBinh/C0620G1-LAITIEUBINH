            var CKEDITOR = window.top.CKEDITOR;
            var oEditorWin = CKEDITOR.currentInstance.window.$;

// Gets the document DOM
            var oDOM = oEditorWin.document;

//var oActiveEl = oEditor.FCKSelection.MoveToAncestorNode( 'UL' ) ;	// 070521 Comment Out
// 070521 STYLE対応
            var flg;
            var oActiveEl = window.top.FCKCsutomSelectionElement();
            if (window.location.search == '?ul') {
                flg = 'UL';
            } else {
                flg = 'OL';
            }

            while (oActiveEl) {
                var A = oActiveEl.tagName;
                if (A == flg) {
                    break;
                }
                if (A == 'BODY') {
                    oActiveEl = null;
                    break;
                }
                oActiveEl = oActiveEl.parentNode;
            }
// 070521 STYLE対応

            var oActiveSel;

            window.onload = function ()
            {
// First of all, translate the dialog box texts
                CKEDITOR.FCKLanguageManager.TranslatePage(document);

                /*	// 070521 STYLE対応 Comment Out
                 if ( oActiveEl ) {
                 oActiveSel = GetE('selBulleted') ;
                 } else	{
                 oActiveEl = oEditor.FCKSelection.MoveToAncestorNode( 'OL' ) ;
                 if ( oActiveEl )
                 oActiveSel = GetE('selNumbered') ;
                 }
                 
                 oActiveSel.style.display = '' ;
                 */

// 070521 STYLE対応
                if (flg == 'UL') {
                    oActiveSel = GetE('selBulleted');
                } else if (flg == 'OL') {
                    oActiveSel = GetE('selNumbered');
                }
                if (oActiveSel)
                    oActiveSel.style.display = ''
// 070521 STYLE対応

                if (oActiveEl)
                {
                    if (oActiveEl.getAttribute('type'))
                        oActiveSel.value = oActiveEl.getAttribute('type').toLowerCase();
                }

// 070521 STYLE対応
                A = new window.top.FCKStylesLoader();
                    var path_file_xml = '/cms8341/ckeditor/gd_files/styles.xml';
                    if (window.top.urlXml && window.top.urlXml != '') {
                        path_file_xml = window.top.urlXml
                    }

                A.Load(path_file_xml);

                Styles = A.Styles;
                for (id in Styles) {
                    var Name = Styles[id]["Name"];
                    var Element = Styles[id]["Element"];
                    var Class = Styles[id]["Attributes"]["class"];
                    if (flg == Element && Class) {
                        var opt = document.createElement('option');
                        opt.value = Class;
                        opt.innerHTML = Name;
                        if (oActiveEl.className) {
                            if (oActiveEl.className == Class)
                                opt.selected = 'selected';
                        }
                        GetE('styleclass').appendChild(opt);
                    }
                }
// 070521 STYLE対応

                SetOkButton(true);
            }

            function SetOkButton(showIt)
            {
                document.getElementById('btnOk').style.visibility = (showIt ? '' : 'hidden');
            }

            function Ok()
            {
                if (oActiveEl) {
                    SetAttribute(oActiveEl, 'type', oActiveSel.value);
                    if (GetE('styleclass').value) {
                        oActiveEl.className = GetE('styleclass').value;
                    } else {
                        oActiveEl.removeAttribute('className', 0);
                    }

                }
                CKEDITOR.dialog.getCurrent().parts.close.$.click();

                return true;
            }