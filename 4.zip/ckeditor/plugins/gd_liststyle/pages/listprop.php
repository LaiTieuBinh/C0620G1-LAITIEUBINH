<?php
//設定ファイル読み込み
require_once("../../../gd_files/.htsetting");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Bulleted List Properties</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta content="noindex, nofollow" name="robots">
    <link href="<?= RPW ?>/admin/style/normalize.css" type="text/css" rel="stylesheet">
    <link href="<?= RPW ?>/ckeditor/gd_files/css/grid.css" type="text/css" rel="stylesheet">
    <link href="<?= RPW ?>/ckeditor/gd_files/css/dialog.css" type="text/css" rel="stylesheet">
    <script src="<?=RPW?>/ckeditor/gd_files/js/dialog_common.js" type="text/javascript"></script>
    <script src="listprop.js" type="text/javascript"></script>
</head>
<body style="overflow: hidden" scroll="no">
<div class="lay360">
    <div class="size4">
        <span class="cke_dialog_ui_labeled_label" fckLang="DlgLstType">List Type</span>
        <select class="cke_dialog_ui_input_select" id="selBulleted" style="DISPLAY: none;">
            <option value="" selected></option>
            <option value="circle" fckLang="DlgLstTypeCircle">Circle</option>
            <option value="disc" fckLang="DlgLstTypeDisc">Disc</option>
            <option value="square" fckLang="DlgLstTypeSquare">Square</option>
        </select>
        <select class="cke_dialog_ui_input_select" id="selNumbered" style="DISPLAY: none;">
            <option value="" selected></option>
            <option value="1" fckLang="DlgLstTypeNumbers">Numbers (1, 2, 3)</option>
            <option value="a" fckLang="DlgLstTypeLCase">Lowercase Letters (a, b, c)</option>
            <option value="A" fckLang="DlgLstTypeUCase">Uppercase Letters (A, B, C)</option>
            <!--<option value="i" fckLang="DlgLstTypeSRoman">Small Roman Numerals (i, ii, iii)</option>	//GD Customize -->
            <!--<option value="I" fckLang="DlgLstTypeLRoman">Large Roman Numerals (I, II, III)</option>	//GD Customize -->
        </select>
    </div>
    <div class="size4">
        <span class="cke_dialog_ui_labeled_label">スタイル</span>
        <select class="cke_dialog_ui_input_select" id="styleclass">
            <option value="">---- 設定しない ----</option>
        </select>
        <div id="test"></div>
    </div>
</div>
<div class="lay360">
    <div class="pre4 size4">
        <a id="btnOk" class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_grey" style="VISIBILITY: hidden;"
           onclick="Ok();" fckLang="DlgBtnOK"/> OK </a>
        <a class="cke_dialog_ui_button" id="btnCancel" onclick="CKEDITOR.dialog.getCurrent().parts.close.$.click();"
           fckLang="DlgBtnCancel"> キャンセル </a>
    </div>
</body>
</html>
