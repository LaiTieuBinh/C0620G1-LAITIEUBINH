CKEDITOR.plugins.setLang('gd_liststyle', 'en', {
    title_ul: "箇条書き プロパティ",
    title_ol: "番号付きリスト プロパティ"
});