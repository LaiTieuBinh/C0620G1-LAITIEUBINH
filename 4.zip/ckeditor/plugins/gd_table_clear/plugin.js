String.prototype.Equals = function () {
    var A = this.toUpperCase();
    var B = arguments;
    if (B.length == 1 && B[0].pop)
        B = B[0];
    for (var i = 0; i < B.length; i++) {
        if (A == B[i].toUpperCase())
            return true;
    }
    ;
    return false;
};

function GetSelectedElement() {
    var ele = CKEDITOR.currentInstance.getSelection().getSelectedElement();
    if (ele == null)
        return null;
    var C = ele.$;
    if (C.nodeType != 1)
        return null;
    return C;
}
;

function MoveToAncestorNode(A) {
    // IE
    var oEditorWin = CKEDITOR.currentInstance.window.$;
    if (typeof oEditorWin.document.selection != "undefined") {
        var B = oEditorWin.document.selection.createRange();
        var C = B.parentElement();
        while (C && C.nodeName != A)
            C = C.parentNode;
        return C;
    } else { //FF and GC
        var B = CKEDITOR.currentInstance.document.getSelection().getRanges(0)[0];
        var C;
        if (B.startContainer != B.endContainer || B.startContainer.$.nodeType != 1 || B.startOffset != B.endOffset - 1) {
            C = null;
        } else {
            if (B.startContainer.$.childNodes[B.startOffset] != undefined) {
                C = B.startContainer.$.childNodes[B.startOffset];
                if (C.$.nodeType != 1) {
                    C = null;
                }
            }
        }
        if (!C)
            C = B.startContainer;
        while (C) {
            if (C.$.nodeName.Equals(A))
                return C.$;

            C = C.getParent();
        }
        return null;
    }
}

(function () {
//Section 1 : Code to execute when the toolbar button is pressed
    var a = {
        exec: function (editor) {
            var A = GetSelectedElement();
            if (!A || A.tagName != 'TABLE')
                A = MoveToAncestorNode("TABLE");
            // TODO write in file config 
            var width = CKEDITOR.currentInstance.config.TableWidth;		
            var border = CKEDITOR.currentInstance.config.TableBorder;			
            var padding = CKEDITOR.currentInstance.config.TablePadding;			
            var spacing = CKEDITOR.currentInstance.config.TableSpacing;			
            if(!A) return true;
            var table = A;
            var th = table.getElementsByTagName('th');
            var td = table.getElementsByTagName('td');
            table.width = width + '%';
            table.border = border;
            table.cellPadding = padding;
            table.cellSpacing = spacing;
            table.removeAttribute('height');
            table.removeAttribute('align');
            table.removeAttribute('style');
            table.removeAttribute('id');
            table.removeAttribute('class');
            for (i = 0; i < th.length; i++) {
                th[i].removeAttribute('width');
                th[i].removeAttribute('height');
                th[i].removeAttribute('style');
                th[i].removeAttribute('id');
                th[i].removeAttribute('class');
                th[i].removeAttribute('align');
                th[i].removeAttribute('valign');
                th[i].removeAttribute('nowrap');
            }
            for (i = 0; i < td.length; i++) {
                td[i].removeAttribute('width');
                td[i].removeAttribute('height');
                td[i].removeAttribute('style');
                td[i].removeAttribute('id');
                td[i].removeAttribute('class');
                td[i].removeAttribute('align');
                td[i].removeAttribute('valign');
                td[i].removeAttribute('nowrap');
            }
        },
        startDisabled: true 
    };
//Section 2 : Create the button and add the functionality to it
    CKEDITOR.plugins.add('gd_table_clear', {
        lang: "en,ja",
        init: function (editor) {
            editor.addCommand('gd_table_clear', a);
            editor.ui.addButton('GdClearTable', {
                icon: this.path + 'icons/gd_table_clear.png',
                label: editor.lang.gd_table_clear.contextbutton,
                command: 'gd_table_clear'
            });
        }
    });
})();