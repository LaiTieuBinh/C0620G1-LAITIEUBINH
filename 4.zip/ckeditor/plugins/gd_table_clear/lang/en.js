CKEDITOR.plugins.setLang( 'gd_table_clear', 'en', {
	contextbutton: 'Clear Table Style'
	} );
