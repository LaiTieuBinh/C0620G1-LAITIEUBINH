CKEDITOR.plugins.setLang( 'gd_table_clear', 'ja', {
	contextbutton: 'テーブルクリーンアップ'
	} );
