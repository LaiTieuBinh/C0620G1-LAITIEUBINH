CKEDITOR.plugins.setLang('gd_save', 'en', {
    button: 'Save',
    save_question: 'Do you want to save changes in library?',
    rollback_question: 'Do you want to rollback changes in library?',
    no_change_in_library: 'No changes in library',
    ajax_operaton_failed: 'Unable to get library information',
    library_not_editable: 'This library locked for editing from another page',
});
