CKEDITOR.plugins.setLang('gd_save', 'ja', {
    button: '保存',
    save_question: '編集内容を保存しますか？',
    rollback_question: '変更内容を破棄してよろしいですか？',
    no_change_in_library: 'ライブラリの内容は変更されていません',
    ajax_operaton_failed: '保存に失敗しました',
    unable_to_get_library_info: 'データの取得に失敗しました',
    library_not_editable: '他のページで変更されているため、現在このライブラリは編集できません。',
});
