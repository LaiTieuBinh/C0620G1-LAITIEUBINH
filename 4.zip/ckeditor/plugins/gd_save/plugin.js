// Adds save button for library editing
CKEDITOR.plugins.add('gd_save', {
    lang: "en,ja",
    init: function (editor) {
        editor.addCommand('gd_save',
                {
                    exec: function (editor) {
                        // check if library has changes
                        if (editor.checkDirty()) {
                            try {
                                // getting library info and content
                                var areaName = editor.name.replace("cms8341-library-", "");
                                var library_id = document.getElementById('cms_library[' + areaName + ']').value;
                                var page_id = document.getElementById('cms_page_id').value;
                                var context = encodeURIComponent(editor.getData());
                                var regAjax = new Ajax.Request(cms8341admin_path + '/master/library/submit.php',
                                        {
                                            method: 'post',
                                            parameters: "ajax=true&library_id=" + library_id + "&page_id=" + page_id + "&context=" + context,
                                            onSuccess: function (result) {
                                                // make ckeditor think that were were no changes in content                                                      
                                                editor.resetDirty();
                                                 editor.resetUndo();
                                            },
                                            onFailure: function (result) {
                                                alert(result);
                                                alert(editor.lang.gd_save.ajax_operation_failed);
                                            },
                                        })
                            } catch (err) {
                                alert(editor.lang.gd_save.unable_to_get_library_info);
                                alert(err);
                            }
                        } else {
                            alert(editor.lang.gd_save.no_change_in_library);
                        }
                    }
                });
                
           editor.addCommand('gd_rollback', {
                    exec: function (editor) {
                         while (editor.checkDirty()) {
                            editor.execCommand('undo');
                        }
                    }
                });

        editor.ui.addButton('GdSave', {
            label: editor.lang.gd_save.button,
            command: 'gd_save',
            // need new icon
            icon: this.path + 'icons/templates.png'
        });

        // check on focusing ckeditor library
        editor.on('focus', function (evt) {
            // check if there were changes in library content 
            try {
                // if ckeditor readonly and but user has permission to edit libraries show this tip
                // CKEDITOR.libraryEditable is setup on set_edit page
                if (this.readOnly && CKEDITOR.libraryEditable) {
                    alert(editor.lang.gd_save.library_not_editable);
                }
                if (this.readOnly) {
                    evt.stop();
                }
            } catch (err) {
                alert(err);
            }
        })

        // check on unfocusing ckeditor library
        editor.on('blur', function (evt) {
            // check if there were changes in library content 
            if (this.checkDirty()) {
                 if(confirm(editor.lang.gd_save.save_question)) {
                         this.execCommand('gd_save');
                }  else {
                      if(confirm(editor.lang.gd_save.rollback_question)) {
                          this.execCommand('gd_rollback');
                      }                     
                }         
        }})
    
        // this code uses together with tag conversion in php - from `form ` to cke-form
        // it made to preserve library content, while browser try to strip form tag which located inside another form tag
       // after CKEDITOR initialized it's safe to use form tag, so we convert it back from cke-form       
        editor.on('instanceReady', function () {
        var dataProcessor = this.dataProcessor,
                dataFilter = dataProcessor && dataProcessor.dataFilter;
         // it is inline editor and it wrapped in form tag
        if (!this.editable().isInline() || !this.editable().getAscendant('form')) {
            return;
        }
        if (dataFilter) {
            dataFilter.addRules({
                elements: {
                    form: function (element) {
                        element.name = 'cke-form';
                    }
                }
            }, {applyToAll: true});

                var elemsToUpdate = this.editable().find('cke-form');

                for (var i = 0; i < elemsToUpdate.count(); ++i) {
                    var element = elemsToUpdate.getItem(i),
                            form = new CKEDITOR.dom.element('form');

                    element.copyAttributes(form);
                    element.moveChildren(form);

                    form.replace(element);
                }
        }

       //  IE8 has problems with unknown elements without that line.
        if (CKEDITOR.env.ie && CKEDITOR.env.version == 8) {
            this.document.$.createElement('form');
        }
            this.resetDirty();
            this.resetUndo();
    });

   }
});
