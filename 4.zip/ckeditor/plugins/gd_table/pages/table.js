var CKEDITOR = window.top.CKEDITOR;
var oEditorWin = CKEDITOR.currentInstance.window.$;

// Gets the table if there is one selected.
// get selected table
var table = CKEDITOR.currentInstance.selTbl;;

// Fired when the window loading process is finished. It sets the fields with the
// actual values if a table is selected in the editor.
window.onload = function()
{
	// First of all, translate the dialog box texts
//	oEditor.FCKLanguageManager.TranslatePage(document) ;
        CKEDITOR.FCKLanguageManager.TranslatePage(document);

	if (table)
	{
		document.getElementById('txtRows').value    = table.rows.length ;
		document.getElementById('txtColumns').value = table.rows[0].cells.length ;

		// Gets the value from the Width or the Style attribute
		var iWidth  = (table.style.width  ? table.style.width  : table.width ) ;
		var iHeight = (table.style.height ? table.style.height : table.height ) ;

		if (iWidth.indexOf('%') >= 0)			// Percentual = %
		{
			iWidth = parseInt( iWidth.substr(0,iWidth.length - 1) ) ;
			document.getElementById('selWidthType').value = "percent" ;
		}
		else if (iWidth.indexOf('px') >= 0)		// Style Pixel = px
		{																										  //
			iWidth = iWidth.substr(0,iWidth.length - 2);
			//document.getElementById('selWidthType').value = "pixels" ;
		}
		if(!iWidth) document.getElementById('selWidthType').value = "percent" ;
		
		if (iHeight && iHeight.indexOf('px') >= 0)		// Style Pixel = px
			iHeight = iHeight.substr(0,iHeight.length - 2);
		
		document.getElementById('txtWidth').value		= iWidth ;
		document.getElementById('txtHeight').value		= iHeight ;
		document.getElementById('txtBorder').value		= table.border ;
		document.getElementById('selAlignment').value	= table.align ;
		document.getElementById('txtCellPadding').value	= table.cellPadding	;
		document.getElementById('txtCellSpacing').value	= table.cellSpacing	;
		document.getElementById('txtSummary').value     = table.summary;
//		document.getElementById('cmbFontStyle').value	= table.className ;

		if (table.caption) document.getElementById('txtCaption').value = table.caption.innerHTML ;

		// テーブルタイプ
		// 属性table_typeの値を取得する
		var table_type = table.getAttribute("table_type");
		if (table_type && table_type == 2) {
			document.getElementById('table-layout').checked = true;
			document.getElementById('txtCaption').disabled = true;
			document.getElementById('txtSummary').disabled = true;
			document.getElementById('txtCaption').style.backgroundColor = "#e6e6e6";
			document.getElementById('txtSummary').style.backgroundColor = "#e6e6e6";
		} else {
			document.getElementById('table-data').checked = true;
			document.getElementById('txtCaption').style.backgroundColor = "#FFFFFF";
			document.getElementById('txtSummary').style.backgroundColor = "#FFFFFF";
		}

		//クラス名の取得
		var attrClass = table.className;
		//項目制御
		//判定クラス名称のチェック
		//* outline,col2,col3,img_cap,box_info,box_link,box_menuの時、項目を制御する
		var check;
		if(attrClass) {
			check = (attrClass.match(/(\s+)?(outline|col2|col3|img_cap|box_info|box_link|box_menu)(\s+)?/));
		} else {
			attrClass = false;
		}
		//項目制御
		if(check) {
			//value
			document.getElementById('txtWidth').value		= '';
			document.getElementById('txtHeight').value		= '';
			document.getElementById('txtBorder').value		= '';
			document.getElementById('selAlignment').value	= '';
			document.getElementById('txtCellPadding').value	= '';
			document.getElementById('txtCellSpacing').value	= '';
			document.getElementById('txtCaption').value     = '';
			document.getElementById('txtSummary').value     = '';
			document.getElementById('table-layout').checked = true;
			
			//disable
			document.getElementById('txtWidth').disabled       = true ;
			document.getElementById('txtHeight').disabled      = true ;
			document.getElementById('txtBorder').disabled      = true ;
			document.getElementById('selAlignment').disabled   = true ;
			document.getElementById('txtCellPadding').disabled = true ;
			document.getElementById('txtCellSpacing').disabled = true ;
			document.getElementById('txtCaption').disabled     = true ;
			document.getElementById('txtSummary').disabled     = true ;
			document.getElementById('table-data').disabled     = true ;
			document.getElementById('table-layout').disabled     = true ;
			//
			if(check[0].match(/img_cap/)) {
				document.getElementById('txtWidth').value   	= iWidth;
				document.getElementById('txtWidth').disabled    = false ;
			}
		}

		document.getElementById('txtRows').disabled    = true ;
		document.getElementById('txtColumns').disabled = true ;
	} else {
		//070518 ADD 新規作成の場合は、テーブル幅：単位パーセントをデフォルト
		document.getElementById('selWidthType').value = "percent" ;

		// 新規作成の場合はテーブルタイプをデータテーブルに設定
		document.getElementById('table-data').checked = true;

		// Set form's default values by configured values in the setting file
		var config = CKEDITOR.currentInstance.config;
		document.getElementById('txtWidth').value		= config.TableWidth;
		document.getElementById('txtBorder').value		= config.TableBorder;
		document.getElementById('txtCellPadding').value	= config.TablePadding;
		document.getElementById('txtCellSpacing').value	= config.TableSpacing;
	}
	
//	window.parent.SetOkButton( true ) ;	
//	window.parent.SetAutoSize( true ) ;	
}

// Fired when the user press the OK button
function Ok()
{
	var bExists = ( table != null ) ;
	
	if ( ! bExists )
	{
//		table = oEditor.FCK.EditorDocument.createElement( "TABLE" ) ;
		eTable = new CKEDITOR.dom.element('TABLE');
                table = eTable.$;
	}

	// Removes the Width and Height styles
	if ( bExists && table.style.width )		table.style.width = null ; //.removeAttribute("width") ;
	if ( bExists && table.style.height )	table.style.height = null ; //.removeAttribute("height") ;
	
	var temp_r = document.getElementById('txtRows').value;
	var temp_c = document.getElementById('txtColumns').value;
	var temp_w = document.getElementById('txtWidth').value;


	if(temp_r=="") {
		//alert("行数が指定されていません。\n");
//		window.parent.Cancel();
                CKEDITOR.dialog.getCurrent().parts.close.$.click();
		return;
	} else if(temp_r==0) {
		//alert("行に「0」を指定することはできません。");
//		window.parent.Cancel();
                CKEDITOR.dialog.getCurrent().parts.close.$.click();
		return;
	}
	if(temp_c=="") {
		//alert("列数が指定されていません。");
//		window.parent.Cancel();
                CKEDITOR.dialog.getCurrent().parts.close.$.click();
		return;
	} else if(temp_c==0) {
		//alert("列に「0」を指定することはできません。");
//		window.parent.Cancel();
                CKEDITOR.dialog.getCurrent().parts.close.$.click();
		return;
	}
	if(temp_w!="" && temp_w==0) {
		//alert("幅に「0」を指定することはできません。");
		document.getElementById('txtWidth').value = '';
	}
	

	// テーブル構造チェック対応
	if (document.getElementById('table-layout').checked == true) {
		// レイアウトテーブルの場合
		table.table_type       = 2;
		table.summary = "";
		
		if ( bExists && table.caption ) {
			if ( document.all )
				table.caption.innerHTML = '' ;	// TODO: It causes an IE internal error if using removeChild.
			else
				table.caption.parentNode.removeChild( table.caption ) ;
		}
	} else {
		// データテーブルの場合

		// 「キャプション」及び「テーブル目的/構造」の値が同じだった場合エラーを表示
		if (document.getElementById('txtCaption').value != '' && document.getElementById('txtSummary').value != "") {
			if (document.getElementById('txtCaption').value == document.getElementById('txtSummary').value) {
				alert("「キャプション」及び「テーブル目的/構造」に" + "\n" + "同様の文言が指定されています。");
				window.parent.Cancel();
				return;
			}
		}
		
		table.table_type       = 1;
		
		if(document.getElementById('txtSummary').value != '') {
			table.summary       = document.getElementById('txtSummary').value ;
		}
		else {
			table.summary       = '';
		}
//		table.className		= cmbFontStyle.value ;
		
		if ( document.getElementById('txtCaption').value != '') {
			if (! table.caption) table.createCaption() ;
			table.caption.innerHTML = document.getElementById('txtCaption').value ;
		}
		else if ( bExists && table.caption )
		{
			if ( document.all )
				table.caption.innerHTML = '' ;	// TODO: It causes an IE internal error if using removeChild.
			else
				table.caption.parentNode.removeChild( table.caption ) ;
		}
	}
	
	
	if(document.getElementById('txtWidth').value) {
		table.width			= document.getElementById('txtWidth').value + ( document.getElementById('selWidthType').value == "percent" ? "%" : "") ;
	} else {
		table.removeAttribute("width") ;
	}
	if(document.getElementById('txtHeight').value) {
		table.height		= document.getElementById('txtHeight').value ;
	} else {
		table.removeAttribute("height") ;
	}
	if(document.getElementById('txtBorder').value) {
		table.border		= document.getElementById('txtBorder').value ;
	} else {
		table.removeAttribute("border") ;
	}
	table.align			= document.getElementById('selAlignment').value ;
	if(document.getElementById('txtCellPadding').value) {
		table.cellPadding	= document.getElementById('txtCellPadding').value ;
	} else {
		table.removeAttribute("cellPadding") ;
	}
	if(document.getElementById('txtCellSpacing').value) {
		table.cellSpacing	= document.getElementById('txtCellSpacing').value ;
	} else {
		table.removeAttribute("cellSpacing") ;
	}
	
	// テーブル新規作成の場合、下記を処理
	if (! bExists)
	{
		var iRows = document.getElementById('txtRows').value ;
		var iCols = document.getElementById('txtColumns').value ;
		
		// <caption>タグが<tbody>タグの閉じタグの下に入ってしまうの問題修正
		if(iRows > 0) {
			table.appendChild(document.createElement('tbody'));
		}

		for ( var r = 0 ; r < iRows ; r++ )
		{
			var oRow = table.insertRow(-1) ;
			for ( var c = 0 ; c < iCols ; c++ )
			{
				var oCell = oRow.insertCell(-1) ;
                                // if ( CKEDITOR.env.gecko )
                                    oCell.innerHTML = '<br type="_moz">' ;
//				if ( oEditor.FCKBrowserInfo.IsGecko )
//					oCell.innerHTML = '<br _moz_editor_bogus_node="TRUE">' ;
				//oCell.innerHTML = "&nbsp;" ;
			}
		}
		
//		oEditor.FCKUndo.SaveUndoStep() ;
		CKEDITOR.currentInstance.fire('saveSnapshot');
                
		// START iCM MODIFICATIONS	
		// Amended to ensure that newly inserted tables are not incorrectly nested in P tags, etc
		// We insert the table first and then rectify any nestings afterwards so we can re-use the
		// FCKTablesProcessor function that corrects tables on SetHTML()
		/*
		table = oEditor.FCK.InsertElementAndGetIt( table ) ;
		if ( !oEditor.FCKConfig.UseBROnCarriageReturn )
		{
			oEditor.FCKTablesProcessor.CheckTableNesting( table ) ;
		}
		*/
		// END iCM MODIFICATIONS	
		// ▼IE9対応▼
		// tableの属性にtable_typeを追加する
		table.setAttribute("table_type", table.table_type);
		// ▲IE9対応▲
//		oEditor.FCK.InsertElement( table , true ) ;
                CKEDITOR.currentInstance.insertElement(eTable);
	}
	// 更新の場合、下記を処理
	else {
		// ▼IE9対応▼
		// tableの属性にtable_typeを追加する
		table.setAttribute("table_type", table.table_type);
		// ▲IE9対応▲
	}
        CKEDITOR.dialog.getCurrent().parts.close.$.click();
	return true ;
}

function IsDigit( e )
{
	e = e || event ;
	var iCode = ( e.keyCode || e.charCode ) ;

	event.returnValue =
		(
			( iCode >= 48 && iCode <= 57 )		// Numbers
			|| (iCode >= 37 && iCode <= 40)		// Arrows
			|| iCode == 8						// Backspace
			|| iCode == 46						// Delete
		) ;

	return event.returnValue ;
}

function cxInitialize() {
	if (document.getElementById('table-layout').checked == true) {
		document.getElementById('txtCaption').style.backgroundColor = "#e6e6e6";
		document.getElementById('txtSummary').style.backgroundColor = "#e6e6e6";
		document.getElementById('txtCaption').disabled = true;
		document.getElementById('txtSummary').disabled = true;
	} else {
		document.getElementById('txtCaption').style.backgroundColor = "#FFFFFF";
		document.getElementById('txtSummary').style.backgroundColor = "#FFFFFF";
		document.getElementById('txtCaption').disabled = false;
		document.getElementById('txtSummary').disabled = false;
	}
}