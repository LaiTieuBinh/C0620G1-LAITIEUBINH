<?php
//設定ファイル読み込み
require_once("../../../gd_files/.htsetting");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Table Properties </title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="robots" content="noindex, nofollow"/>
    <link href="<?= RPW ?>/ckeditor/gd_files/css/normalize.css" type="text/css" rel="stylesheet">
    <link href="<?= RPW ?>/ckeditor/gd_files/css/grid.css" type="text/css" rel="stylesheet">
    <link href="<?= RPW ?>/ckeditor/gd_files/css/dialog.css" type="text/css" rel="stylesheet">
    <script type='text/javascript' src="table.js"></script>
</head>
<body class="cke_reset_all">
<div class="dialog_body">
    <div class="lay360">
        <div class="size3 ">
            <label class="cke_dialog_ui_labeled_label" for="txtRows" fckLang="DlgTableRows">Rows</label>:
            <input class="cke_dialog_ui_input_text" id="txtRows" type="text" value="3" name="txtRows" onkeypress="return IsDigit(event);">
        </div>


        <div class="size2">
            <label class="cke_dialog_ui_labeled_label" fckLang="DlgTableAlign">Alignment</label>:
            <select id="selAlignment" class="cke_dialog_ui_input_select" name="selAlignment">
                <option fckLang="DlgTableAlignNotSet" value="" selected>&lt;Not set&gt;</option>
                <option fckLang="DlgTableAlignLeft" value="left">Left</option>
                <option fckLang="DlgTableAlignCenter" value="center">Center</option>
                <option fckLang="DlgTableAlignRight" value="right">Right</option>
            </select>
        </div>
        <div class="size3">
            <label class="cke_dialog_ui_labeled_label" fckLang="DlgTableBorder">Border size</label>:
            <input class="cke_dialog_ui_input_text" id="txtBorder" type="text" value="1" name="txtBorder" onkeypress="return IsDigit(event);">
        </div>
    </div>

    <div class="lay360">

        <div class="size3 ">
            <label class="cke_dialog_ui_labeled_label" fckLang="DlgTableColumns">Columns</label>:
            <input class="cke_dialog_ui_input_text" id="txtColumns" type="text" value="2" name="txtColumns" onkeypress="return IsDigit(event);">
        </div>

        <input id="txtHeight" type="hidden" value="">

        <div class="size2">
            <span class="cke_dialog_ui_labeled_label" fckLang="DlgTableWidth">Width</span>:
            <input class="cke_dialog_ui_input_text" id="txtWidth" type="number" maxLength="3" max="999" value="100" name="txtWidth"
                   onkeypress="return IsDigit(event);">
        </div>
        <div class="size3">
            <span class="cke_dialog_ui_labeled_label" fckLang="DlgTableWidthMsr">Units</span>:
            <select class="cke_dialog_ui_input_text" id="selWidthType" name="selWidthType">
                <option fckLang="DlgTableWidthPx" value="pixels">pixels</option>
                <option fckLang="DlgTableWidthPc" value="percent">percent</option>
            </select>
        </div>
    </div>

    <div class="lay360">
        <div class="size4">
            <span class="cke_dialog_ui_labeled_label" fckLang="DlgTableCellSpace">Cell spacing</span>:
            <input id="txtCellSpacing" class="cke_dialog_ui_input_text" type="text" maxLength="2" size="2" value="1" name="txtCellSpacing"
                   onkeypress="return IsDigit(event);" style="ime-mode: disabled">
        </div>
        <div class="size4">
            <span class="cke_dialog_ui_labeled_label" fckLang="DlgTableCellPad">Cell padding</span>:
            <input id="txtCellPadding" class="cke_dialog_ui_input_text" type="text" maxLength="2" size="2" value="3" name="txtCellPadding"
                   onkeypress="return IsDigit(event);" style="ime-mode: disabled">
        </div>
    </div>

    <div class="lay360">
        <div class="size8">
            <span class="cke_dialog_ui_labeled_label" fckLang="DlgTableType">Table Type</span>:<br>
            <input class="cke_dialog_ui_radio_input" type="radio" name="table_type" id="table-data" value="1" onclick="javascript:cxInitialize();">
            <label class="cke_dialog_ui_labeled_label" for="table-data">データテーブル</label>
            <input class="cke_dialog_ui_radio_input" type="radio" name="table_type" id="table-layout" value="2" onclick="javascript:cxInitialize();">
            <label class="cke_dialog_ui_labeled_label" for="table-layout">レイアウトテーブル</label>
        </div>
    </div>

    <div class="lay360">
        <div class="size8">
            <span class="cke_dialog_ui_hbox_first cke_dialog_ui_labeled_label" fckLang="DlgTableCaption">Caption</span>:
            <input class="cke_dialog_ui_input_text" id="txtCaption" type="text">
        </div>
    </div>

    <div class="lay360">
        <div class="size8">
            <span class="cke_dialog_ui_hbox_first cke_dialog_ui_labeled_label" fckLang="DlgTableSummary">Summary</span>:
            <input class="cke_dialog_ui_input_text" id="txtSummary" type="text">
        </div>
    </div>

    <div class="lay360 button_layer">
        <div class="pre4 size4">
            <input class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_grey" type="button" value="Ok" class="Button"
                   onclick="Ok();" fckLang="DlgBtnOK"/>
            <input class="cke_dialog_ui_button" type="button" value="Cancel" class="Button"
                   onclick="CKEDITOR.dialog.getCurrent().parts.close.$.click();" fckLang="DlgBtnCancel"/>
        </div>
    </div>

</div>
</body>
</html>
