CKEDITOR.plugins.setLang( 'gd_table', 'en', {
	title	: "箇条書き プロパティ",
	} );