CKEDITOR.plugins.setLang( 'gd_table', 'ja', {
	title	: "テーブル　プロパティ",
	} );