CKEDITOR.plugins.setLang( 'gd_templates', 'ja', {
	button :   "パーツ",
                  title  :  "パーツ設定",
	} );