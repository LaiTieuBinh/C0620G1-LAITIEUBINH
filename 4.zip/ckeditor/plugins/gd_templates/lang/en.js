CKEDITOR.plugins.setLang( 'gd_templates', 'en', {
	button	: "Templates",
                  title  :  "Templates List",
	} );