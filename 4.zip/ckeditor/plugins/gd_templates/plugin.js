CKEDITOR.plugins.add('gd_templates', {
                  lang: "en,ja",
	init: function (editor) {

                           editor.addCommand('gd_templates', new CKEDITOR.dialogCommand('gd_templates_dialog'));
                           editor.ui.addButton('GdTemplates', {
                                  icon: this.path + 'icons/templates.png',
                                  label: editor.lang.gd_templates.button,
                                  command: 'gd_templates',
                            });
                            CKEDITOR.dialog.add('gd_templates_dialog', this.path + 'dialogs/templates.js')
                            
                }
});
