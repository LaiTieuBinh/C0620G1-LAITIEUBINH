﻿CKEDITOR.dialog.add('gd_templates_dialog', function (editor) {
    return {
        title: editor.lang.gd_templates.title,
        contents: [{
                id: 'tab-basic',
                label: 'Basic Settings',
                icon: CKEDITOR.plugins.getPath('gd_templates') + 'logo_ckeditor.png',
                elements: [ {
                        type: 'text',
                        id: 'alt',
                        label: 'Alternative'
                    }
                ]
            }
        ],
        onShow: function () {
            var href = CKEDITOR.plugins.getPath('gd_templates') + 'pages/template.php';
            show_iframe_dialog(editor, href, '680', '420');
        },
        onOk: function () {
        }
    }
});