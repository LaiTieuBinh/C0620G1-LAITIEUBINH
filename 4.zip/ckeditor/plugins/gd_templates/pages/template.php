<?php require_once("../../../gd_files/.htsetting"); ?>
<!DOCTYPE html>
<html>
	<head>
        <meta charset="utf-8">
		<meta name="robots" content="noindex, nofollow">
        <link rel="stylesheet" href="<?= RPW ?>/admin/style/normalize.css?v=1" type="text/css">
        <link rel="stylesheet" href="templates.css" type="text/css">
        <link rel="stylesheet" href="<?= RPW ?>/ckeditor/gd_files/css/dialog.css" type="text/css">
		<script src="<?= RPW ?>/ckeditor/gd_files/js/dialog_common.js" type="text/javascript"></script>
        <script src="<?= RPW ?>/admin/js/library/prototype.js" type="text/javascript"></script>
        <script src="templates.js" type="text/javascript"></script>
	</head>
	<body scroll="no">
		<table width="100%" height="90%">
			<tr>
				<td width="50%" height="100%" align="center">
					<div id="eList" align="left" class="cke_tpl_list">
						<div id="eLoading" align="center" style="DISPLAY: none">
							<br>
							<span fckLang="DlgTemplatesLoading">Loading templates list. Please wait...</span>
						</div>
						<div id="eEmpty" align="center" style="DISPLAY: none">
							<br>
							<span fckLang="DlgTemplatesNoTpl">(No templates defined)</span>
						</div>
					</div>
				</td>
				<td width="50%" height="100%" align="center">
					<div id="tList" align="left" class="cke_tpl_list">
						<div id="thumbParts" onClick="return false;">
						</div>
					</div>
				</td>
			</tr>
                        

		</table>
            <div width="100%" id="set_button_tr" style="height: 20px; margin-top: 5px;">
                <input id="btnCancel" class="cke_dialog_ui_button" style="float: right; margin-right: 20px;" type="button" value="Cancel" class="Button" onclick="CKEDITOR.dialog.getCurrent().parts.close.$.click();" fckLang="DlgBtnCancel" />
            </div>
	</body>
</html>
