function createHttpRequest(){
	//Win ie用
	if(window.ActiveXObject){
		try {
			//MSXML2以降用
			return new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try {
				//旧MSXML用
				return new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e2) {
				return null;
			}
		}
	} else if(window.XMLHttpRequest){
		//Win ie以外のXMLHttpRequestオブジェクト実装ブラウザ用
		return new XMLHttpRequest();
	} else {
		return null;
	}
}
function do_Ajax( data , method , url , async ) {
	//XMLHttpRequestオブジェクト生成
	var httpoj = createHttpRequest();
	//open メソッド
	httpoj.open( method , url , async ); //
	if(method=='POST') {
		httpoj.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	}
	//httpoj.setRequestHeader('User-Agent', 'XMLHttpRequest');	/* UserAgentを書き換える */
    httpoj.setRequestHeader("If-Modified-Since", "Thu, 01 Jun 1970 00:00:00 GMT");		/* キャッシュを見に行かないようにする */
	//受信時に起動するイベント
	httpoj.onreadystatechange = function()	{ 
		//readyState値は4で受信完了
		if (httpoj.readyState==4) {
			if (httpoj.status == 200) {
				//コールバック
				on_loaded(httpoj);
			} else {
				//通信エラー
				on_failure(httpoj.status);
			}
		}
	}
	//send メソッド
	httpoj.send( data ); //data=引数1=値&引数2=値
}
function on_loaded(rObj) {
	GetE('eLoading').style.display = 'none' ;
	GetE('eList').innerHTML = rObj.responseText;
}
function on_failure(err_code) {
	GetE('eList').innerHTML = '<p style="color:red">通信エラー</p><p>ステータスコード：'+err_code+'</p>';
}
/* GD ADDING */

var CKEDITOR = window.top.CKEDITOR;
var oEditorWin = CKEDITOR.currentInstance.window.$;


window.onload = function()
{
	// Set the right box height (browser dependent).
	GetE('eList').style.height = '350px' ;
	GetE('tList').style.height = '350px' ;
    GetE('tList').style.width = '300px' ;

	// Translate the dialog box texts.
//	 oEditor.FCKLanguageManager.TranslatePage(document) ;
        CKEDITOR.FCKLanguageManager.TranslatePage(document);
	// window.parent.SetAutoSize( true ) ;

	LoadTemplatesXml() ;
}

function LoadTemplatesXml()
{	
	GetE('eLoading').style.display = '' ;
	data   = '';
	url    = 'library.php';
	method = 'POST';
	async  = true;
	do_Ajax(data,method,url,async);
}

var partsThumb;
function ItemDiv_OnMouseOver(e)
{
	e.className += ' PopupSelectionBox' ;
    // 201610 fix bug No4 
//	if ( partsThumb != e.TplIndex ) {
	if ( partsThumb != e.getAttribute('tplindex') ) {
		partsThumb = e.getAttribute('tplindex');
		cxSelectParts( );
	}
}

function ItemDiv_OnMouseOut(e)
{
	e.className = e.className.replace( /\s*PopupSelectionBox\s*/, '' ) ;
	partsThumbCnt = 0;
}

function ItemDiv_OnClick(e)
{
	SelectTemplate( e.getAttribute('tplindex') ) ;
}

function SelectTemplate( index )
{
    CKEDITOR.currentInstance.fire('saveSnapshot');
    
	//++ 2007.03.10 ohishi add start++//
	//ライブラリにページ内アンカーが使用されていた場合の処置
	//
	//++ 2007.03.14 ohishi fix start++//
	var e = GetE("lib_"+index);
	var a = e.getElementsByTagName('A');
	for(var i=0;i<a.length;i++) {
		var h = a[i].href;
		if(h != ""){
			// 07 09 2017 sergei - reduce regexp code
                                                        // h = h.replace(/https?:\/\/.*\/ckeditor\/plugins\/gd_templates\/pages\/template.html/,'');
                                                      h = h.replace(/.*\/template.php/,'');
			a[i].href = h;
		}
	}
	//++ 2007.03.14 ohishi fix end  ++//
	var temp = GetE("lib_"+index).innerHTML;
    CKEDITOR.currentInstance.insertHtml(temp);
	//temp = temp.replace(/http:\/\/.*\/FCKeditor\/editor\/dialog\/fck_template.html/,'');
	// FCK.InsertHtml( temp , true );
	//++ 2007.03.10 ohishi add end  ++//
	//FCK.InsertHtml( GetE("lib_"+index).innerHTML , true );
    CKEDITOR.dialog.getCurrent().parts.close.$.click();
	// window.parent.Cancel();
}

function cxSelectParts() {
	if ( document.getElementById("lib_"+partsThumb) ) {
		document.getElementById("thumbParts").innerHTML = document.getElementById("lib_"+partsThumb).innerHTML;
	}
}
		