<?php
/*
 *
 */
require_once("../../../../.htsetting");
// session
require_once (APPLICATION_ROOT . "/common/session/session.inc");
require_once (APPLICATION_ROOT . "/common/dbcontrol/login.inc");
$objLogin = new login();
$login = $objLogin->login;
$user_class = $login["class"];
$dept_code = $login["dept_code"];
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);

$template_id = "";
if (isset($_SESSION['use_template_id'])) {
	$template_id = $_SESSION['use_template_id'];
}

if (!isset($user_class) || !$user_class) {
	print "<p>ログインしていないか、セッションが切れているためパーツ情報を取得できませんでした。<br>\n";
	print "作業を終了し、ログインしなおしてください。</p>\n";
	exit();
}

/** return HTML Format **/
$html = "<div class=\"cke_tpl_item\" onmouseover=\"ItemDiv_OnMouseOver(this)\" onmouseout=\"ItemDiv_OnMouseOut(this)\" onclick=\"ItemDiv_OnClick(this)\" TplIndex=\"{@ID}\">\n" . "<table>\n" . "<tr>\n" . "<td align=\"left\" valign=\"top\">\n" . "<div class=\"TplTitle\">\n" . "{@TITLE}\n" . "</div>\n" . "<div style=\"display:none\" id=\"lib_{@ID}\">\n" . "{@CONTEXT}\n" . "</div>\n" . "</td>\n" . "</tr>\n" . "</table>\n" . "</div>";

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
$objTool->selectTemplate($template_id);
$nonuse_library_id = $objTool->fld['nonuse_library_id'];
$nonuse_library_id_ary = explode(",", $nonuse_library_id);

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
$pm = ($user_class == 5) ? 2 : 1;
$sql = "SELECT library_id,name,context,is_open_autolink FROM tbl_library L1";
$sql .= " WHERE area='2'";
if ($pm == 1) $sql .= " and user_parmission=" . $pm;
$sql .= "  and library_ver=(SELECT MAX(L2.library_ver) from tbl_library L2 WHERE L1.library_id=L2.library_id)";
$sql .= " order by L1.user_parmission desc, L1.area, L1.sort_order, L1.library_id";
$objDac->execute($sql);
$cnt = $objDac->getRowCount();
$res = '';
if ($cnt > 0) {
	$d = 0;
	while ($objDac->fetch()) {
		if (in_array($objDac->fld['library_id'], $nonuse_library_id_ary)) continue;
		$name = htmlDisplay($objDac->fld['name']);
		$context = $objDac->fld['context'];
		if ($objDac->fld['is_open_autolink'] == FLAG_ON) {
			$context = setAutoLink($context);
		}
		$tmp = $html;
		$tmp = str_replace('{@ID}', $d, $tmp);
		$tmp = str_replace('{@TITLE}', $name, $tmp);
		$tmp = str_replace('{@DESCRIPTION}', '', $tmp);
		$tmp = str_replace('{@CONTEXT}', $context, $tmp);
		$res .= $tmp;
		$d++;
	}
}
else {
	$res = 'パーツは登録されていません。';
}

print $res;
?>

