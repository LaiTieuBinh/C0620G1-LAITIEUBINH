CKEDITOR.plugins.setLang('gd_table_property', 'en', {
    button: "Table Property",
    title: "Table Property"
});
