CKEDITOR.plugins.setLang('gd_table_property', 'ja', {
    button: "テーブルの整形",
    title: "テーブルの整形"
});