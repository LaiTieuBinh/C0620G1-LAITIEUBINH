<?php
//設定ファイル読み込み
require_once("../../../gd_files/.htsetting");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow"/>
    <title>テーブルの整形</title>
    <link rel="stylesheet" href="<?= RPW ?>/admin/style/normalize.css?v=1" type="text/css">
    <link href="<?= RPW ?>/ckeditor/gd_files/css/grid.css" type="text/css" rel="stylesheet">
    <script type='text/javascript' src="table_property.js"></script>
    <link href="<?= RPW ?>/ckeditor/gd_files/css/dialog.css" type="text/css" rel="stylesheet">
</head>
<body class="cke_reset_all">
<div class="dialog_body">

    <div class="lay360">
        <div class="size4">
            <span class="cke_dialog_ui_labeled_label">テーブル幅 (パーセント)：</span>
            <input type="text" id="width" class="cke_dialog_ui_input_text" name="width" value="100"/>
        </div>
        <div class="size4">
            <span class="cke_dialog_ui_labeled_label">セルの余白：</span>
            <input class="cke_dialog_ui_input_text" type="text" id="padding" name="padding" value="5"/>
        </div>
    </div>

    <div class="lay360">
        <div class="size8">
            <label for="b1" class="cke_dialog_ui_labeled_label"> 枠線の太さ：
                <input type="radio" id="b1" name="border" value="0">なし</label>　
            <input type="radio" id="b2" name="border" value="1" checked="checked"/> <label for="b2" class="cke_dialog_ui_labeled_label">細</label>　
            <input type="radio" id="b3" name="border" value="3"> <label for="b3" class="cke_dialog_ui_labeled_label">中</label>　
            <input type="radio" id="b4" name="border" value="5"> <label for="b4" class="cke_dialog_ui_labeled_label">太</label>
        </div>
    </div>

    <div class="lay360">
        <div class="pre4 size4">
            <input id="btnOk" type="button" value="OK" class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_grey"
                   onclick="Ok();"/>
            <input type="button" value="キャンセル" class="cke_dialog_ui_button" onclick="Cancel();"/>
        </div>
    </div>

</div>
</body>
</html>