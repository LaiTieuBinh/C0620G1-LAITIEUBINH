var CKEDITOR = window.top.CKEDITOR;
var oEditorWin = CKEDITOR.currentInstance.window.$;

function SetOnKeyDown( targetDocument ){
	targetDocument.onkeydown = function ( e ){
		e = e || event || this.parentWindow.event ;
		switch ( e.keyCode ){
			case 13 :		// ENTER
				var oTarget = e.srcElement || e.target ;
				if ( oTarget.tagName == 'TEXTAREA' ) return ;
				Ok() ;
				return false ;
			// case 27 :		// ESC
				// Cancel() ;
				// return false ;
				// break ;
		}
		return true ;
	}
}
SetOnKeyDown( document );

function check(val) {
	return (val.match(/[^0-9]/))? false : true;
}
function Ok() {
	var wObj = document.getElementById('width');
	var pObj = document.getElementById('padding');
	var b1Obj = document.getElementById('b1');
	var b2Obj = document.getElementById('b2');
	var b3Obj = document.getElementById('b3');
	var b4Obj = document.getElementById('b4');
	var w = wObj.value;
	var p = pObj.value;
	var b;
	if(b1Obj.checked) b = b1Obj.value;
	if(b2Obj.checked) b = b2Obj.value;
	if(b3Obj.checked) b = b3Obj.value;
	if(b4Obj.checked) b = b4Obj.value;
	
	if(w=="" || w.length=="0") {
		alert('テーブル幅が入力されていません');
		wObj.focus();
		return;
	}
	if(p=="" || p.length==0) {
		alert('セルの余白が入力されていません');
		pObj.focus();
		return;
	}
	
	if(!check(w)) {
		alert('テーブル幅に数字以外の文字が入力されています');
		wObj.focus();
		return;
	}
	if(!check(p)) {
		alert('セルの余白に数字以外の文字が入力されています');
		pObj.focus();
		return;
	}
	
	var retObj = new Object();
	retObj['width'] = w;
	retObj['padding'] = p;
	retObj['border'] = b;
	
	// window.returnValue = retObj;
    var obj = retObj;
    
    var width   = obj['width'];
	var border  = obj['border'];
	var padding = obj['padding'];
	var spacing = CKEDITOR.currentInstance.config.TableCellSpacing;
	
    var table = CKEDITOR.currentInstance.selTbl;
	var th    = table.getElementsByTagName('th');
	var td    = table.getElementsByTagName('td');
	table.width = width+'%';
	table.border = border;
	table.cellPadding = padding;
	table.cellSpacing = spacing;
	table.removeAttribute('height');
	table.removeAttribute('align');
	table.removeAttribute('style');
	table.removeAttribute('id');
	table.removeAttribute('class');
	for(i=0;i<th.length;i++) {
		th[i].removeAttribute('width');
		th[i].removeAttribute('height');
		th[i].removeAttribute('style');
		th[i].removeAttribute('id');
		th[i].removeAttribute('class');
		th[i].removeAttribute('align');
		th[i].removeAttribute('valign');
		th[i].removeAttribute('nowrap');
	}
	for(i=0;i<td.length;i++) {
		td[i].removeAttribute('width');
		td[i].removeAttribute('height');
		td[i].removeAttribute('style');
		td[i].removeAttribute('id');
		td[i].removeAttribute('class');
		td[i].removeAttribute('align');
		td[i].removeAttribute('valign');
		td[i].removeAttribute('nowrap');
	}
    
	CKEDITOR.dialog.getCurrent().parts.close.$.click();
}
window.onload = function() {
	arg = new Object();
    arg['width'] = CKEDITOR.currentInstance.config.TableWidth;
    arg['border'] = CKEDITOR.currentInstance.config.TableBorder;
    arg['padding'] = CKEDITOR.currentInstance.config.TableCellPadding;
            
	if(arg['width'])   document.getElementById('width').value = arg['width'];
	if(arg['padding']) document.getElementById('padding').value = arg['padding'];
	if(arg['border']) {
		switch(arg['border']) {
			case 0:
				document.getElementById('b1').checked = true;
				document.getElementById('b2').checked = false;
				document.getElementById('b3').checked = false;
				document.getElementById('b4').checked = false;
				break;
			case 3:
				document.getElementById('b1').checked = false;
				document.getElementById('b2').checked = false;
				document.getElementById('b3').checked = true;
				document.getElementById('b4').checked = false;
				break;
			case 5:
				document.getElementById('b1').checked = false;
				document.getElementById('b2').checked = false;
				document.getElementById('b3').checked = false;
				document.getElementById('b4').checked = true;
				break;
			default:
				document.getElementById('b1').checked = false;
				document.getElementById('b2').checked = true;
				document.getElementById('b3').checked = false;
				document.getElementById('b4').checked = false;
				break;
		}
	}
}
function Cancel() {
    CKEDITOR.dialog.getCurrent().parts.close.$.click();
}
