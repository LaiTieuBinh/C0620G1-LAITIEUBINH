CKEDITOR.plugins.add('gd_table_property', {
                  lang: "en,ja",
	init: function (editor) {
		editor.addCommand('gd_table_property', new CKEDITOR.dialogCommand('gd_table_property', {startDisabled: true}));
		editor.ui.addButton('GdTableProperty', {
            icon: this.path + 'icons/table_property.png',
			label: editor.lang.gd_table_property.button,
			command: 'gd_table_property',
		});
		CKEDITOR.dialog.add('gd_table_property', this.path + 'dialogs/table_property.js')
	}
});
