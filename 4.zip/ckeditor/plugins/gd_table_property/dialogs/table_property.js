﻿CKEDITOR.dialog.add('gd_table_property', function (editor) {
    return {
        title: editor.lang.gd_table_property.title,
        minWidth:       625,
        minHeight:      200,
        contents: [{
                id: 'tab-basic',
                label: 'Basic Settings',
                elements: [
                    {
                        type: 'text',
                        id: 'alt',
                        label: 'Alternative'
                    }
                ]
            }
        ],
        onShow: function () {
            var href = CKEDITOR.plugins.getPath('gd_table_property') + 'pages/table_property.php';
            show_iframe_dialog(editor, href, '380', '140');
        },
		startDisabled: true
    }
});