/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
         // disable default filter
        config.allowedContent = true;
        
        // config paste text, word, ... (paste_clean_word.js)
        config.Validation = window.parent.IKOU_VALIDATION;    //バリデーション対策 true:有効 false:無効
        config.ShiftOver = window.parent.IKOU_MODE;		    //移行専用機能       true:有効 false:無効
        config.Rep_Tag_Ary = Array(
        //	{tag:'*1',			mode:'*2',	rep_tag:'*3',		del_attr:'*4',	target:'*5'},
        //  ブロック要素 Pタグに変更（最後はPタグ）
            {tag:'h1',			mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            {tag:'h2',			mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            {tag:'h3',			mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            {tag:'h4',			mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            {tag:'h5',			mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            {tag:'h6',			mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            {tag:'div',			mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            {tag:'address',		mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            {tag:'pre',			mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            {tag:'blockquote',	mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            {tag:'li',			mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            {tag:'dt',			mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            {tag:'dd',			mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            {tag:'p',			mode:'0',	rep_tag:'p',		del_attr:'1',	target:'0'},
            //その他の要素
            {tag:'hr',			mode:'0',	rep_tag:'hr',		del_attr:'1',	target:'1'},
            {tag:'ul',			mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'ol',			mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'dl',			mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'b',			mode:'0',	rep_tag:'strong',	del_attr:'1',	target:'0'},
            {tag:'i',			mode:'0',	rep_tag:'em',		del_attr:'1',	target:'0'},
            {tag:'font',		mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'span',		mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'u',			mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'s',			mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'strike',		mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'del',			mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'big',			mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'small',		mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'sub',			mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'sup',			mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'colgroup',	mode:'1',	rep_tag:'',			del_attr:'1',	target:'2'},
            {tag:'col',			mode:'1',	rep_tag:'',			del_attr:'1',	target:'2'},
            {tag:'ruby',		mode:'1',	rep_tag:'',			del_attr:'1',	target:'2'},
            {tag:'rb',			mode:'1',	rep_tag:'',			del_attr:'1',	target:'2'},
            {tag:'rp',			mode:'1',	rep_tag:'',			del_attr:'1',	target:'2'},
            {tag:'rt',			mode:'1',	rep_tag:'',			del_attr:'1',	target:'2'},
            {tag:'center',		mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'frameset',	mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'frame',		mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'noframes',	mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'iframe',		mode:'1',	rep_tag:'',			del_attr:'1',	target:'0'},
            {tag:'tbody',		mode:'0',	rep_tag:'tbody',	del_attr:'1',	target:'0'},
            {tag:'tr',			mode:'0',	rep_tag:'tr',		del_attr:'1',	target:'0'},
            {tag:'caption',		mode:'0',	rep_tag:'caption',	del_attr:'1',	target:'0'},
            {tag:'strong',		mode:'0',	rep_tag:'strong',	del_attr:'1',	target:'0'},
            {tag:'em',			mode:'0',	rep_tag:'em',		del_attr:'1',	target:'0'},
            {tag:'br',			mode:'0',	rep_tag:'br',		del_attr:'1',	target:'1'}
        );
        if(window.parent.IKOU_DRESSUPPATH != ""){
            config.DressupPath   = window.parent.IKOU_DRESSUPPATH.split(","); //型：配列
        } else {
            config.DressupPath   = []; //型：配列
        }	
        config.HTMtoHTML = window.parent.IKOU_HTMTOHTML;              //リンクパス ***.htm を ***.htmlに変換 true:有効 false:無効
        config.i_city_url = window.parent.IKOU_I_CITY_URL;
        config.ReplacePath = window.parent.IKOU_REPLACEPATH;            //パス修正対象の置換文字列
        config.Del_Target_Attribute = {
        //	要素:属性の配列
            //A要素に付与されていたら削除する属性名
            a:window.parent.IKOU_DEL_TARGET_ATTRIBUTE_A.split(","),
            //IMG要素に付与されていたら削除する属性名
            img:window.parent.IKOU_DEL_TARGET_ATTRIBUTE_IMG.split(","),
            //TABLE要素に付与されていたら削除する属性名
            table:window.parent.IKOU_DEL_TARGET_ATTRIBUTE_TABLE.split(","),
            //TH要素に付与されていたら削除する属性名
            th:window.parent.IKOU_DEL_TARGET_ATTRIBUTE_TH.split(","),
            //TD要素に付与されていたら削除する属性名
            td:window.parent.IKOU_DEL_TARGET_ATTRIBUTE_TD.split(","),
            //THEAD要素に付与されていたら削除する属性名
            thead:window.parent.IKOU_DEL_TARGET_ATTRIBUTE_THEAD.split(","),
            //TFOOT要素に付与されていたら削除する属性名
            tfoot:window.parent.IKOU_DEL_TARGET_ATTRIBUTE_TFOOT.split(",")
        };
        config.dataTableClass = window.parent.IKOU_DATATABLECLASS;        //データテーブル要素に付与するクラス名(CLASS属性値)
        config.disabledClass = {
            //TABLE要素に付与されていても消去しないCLASS属性値
            table:window.parent.IKOU_DISABLEDCLASS_TABLE.split(","),
            //TD要素に付与されていても消去しないCLASS属性値
            td:window.parent.IKOU_DISABLEDCLASS_TD.split(","),
            //A要素に付与されていても消去しないCLASS属性値
            a:window.parent.IKOU_DISABLEDCLASS_A.split(","),
            //IMG要素に付与されていても消去しないCLASS属性値
            img:window.parent.IKOU_DISABLEDCLASS_IMG.split(","),
            //P要素に付与されていても消去しないCLASS属性値
            p:window.parent.IKOU_DISABLEDCLASS_P.split(",")
        };
        config.classCheckTableElement = {
            table:window.parent.IKOU_CLASSCHECKTABLEELEMENT_TABLE.split(","),
            th:window.parent.IKOU_CLASSCHECKTABLEELEMENT_TH.split(","),
            td:window.parent.IKOU_CLASSCHECKTABLEELEMENT_TD.split(",")
        };
        config.classCheckTableClass = {
            table:window.parent.IKOU_CLASSCHECKTABLECLASS_TABLE.split(","),
            th:window.parent.IKOU_CLASSCHECKTABLECLASS_TH.split(","),
            td:window.parent.IKOU_CLASSCHECKTABLECLASS_TD.split(",")
        };
        
        // set editor height
        config.height = 500;  
};
