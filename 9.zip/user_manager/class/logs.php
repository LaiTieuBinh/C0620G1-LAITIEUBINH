<?php
// session_start();
require('./include/config.php');

class Logs extends DbConfig {
    // define private variables
    protected $unique_id;
    protected $location;
    protected $file_name;
    protected $full_path;
    protected $type;
    protected $logs;
    protected $concatenator;
    protected $end_of_entry;
    protected $retry_interval;


    // log types
    const DB = "Database";
    const File = "File";
    const FileAndDB = "File and database";

    function __construct() {
        $this->create_unique_id();
        // $this->retry_interval = 10;
        $this->concatenator = PHP_EOL;
        $this->end_of_entry = PHP_EOL . '---------------------------------------------------------------------------' . PHP_EOL;
    }

    // set location 
    public function set_location($location) {
        if (!is_dir($location))
            mkdir($location);

        $this->location = $location;
    }

    // set type of logging required, coulde be database, logging or both
    public function set_type($type) {
        $this->type = $type;
    }

    // set file name
    public function set_file_name($prefix, $postfix) {
		$stamp = date("Ymd");
		$this->file_name = $prefix . '_' . $stamp . $postfix;

        // create full path
        $this->full_path = $this->location . '/' . $this->file_name;
        // create file if not exists
        if (!file_exists($this->full_path)) {
            $fh = fopen($this->full_path, 'w');
            if (!is_resource($fh)) {
                trigger_error("Unable to create file for logging");
            }
            fclose($fh);
        }
    }

    //set concatenator, used to concatenate message together
    public function set_concatenator($concatenator) {
        $this->concatenator = $concatenator;
    }

    // set end of entry, this is kind or marker that logs are finished here for singal transaction
    public function set_end_of_entry($end_of_entry) {
        $this->end_of_entry = $end_of_entry;
    }

    // public method to add messages in logs array
    public function write($message) {
            $current_date = date('Y-m-d H:i:s');

            $this->logs[] = array('date' => $current_date, "message" => $message);
    }

    // write data
    public function flush($clear, $end_of_entry) {
        // if any logs are written
        if (count($this->logs) > 0) {

            // if user wants file based log
            if ($this->type == self::File   || $this->type == self::FileAndDB) {
                $values = array();
                
                // create singal enrty
                foreach ($this->logs as $val) {
                    $dt_string = $val['date'];
                    $values[] .= __FILE__ . ' :: ' . $dt_string . ' :: ' . $val['message'];
                }

                
                if (count($values) > 0) {
                    // create complete log for all entries
                    $message = implode($this->concatenator, $values);

                    // if TRUE, append end of entry as marker
                    if ($end_of_entry) {
                        $message .= $this->end_of_entry;
                    }

                    // write to file
                    $this->write_file($message);
                }
            }

            // if user wants database log
            if ($this->type == self::DB || $this->type == self::FileAndDB) {

                $que = 'INSERT INTO ' . $this->logsTable . '(log_date, log_details, log_location) VALUES ';
                
                $values = array();

                // create insert values string for all entries
                foreach ($this->logs as $val) {
                    $dt_string = $val['date'];
                    $values[] = "('" . $dt_string . "','" . $val['message'] . "','" . __FILE__ . "')";
                }

                if (count($values) > 0) {
                    // create complete query 
                    $que .= implode(',', $values);

                    // write to db
                    $this->write_db($que);
                }
            }
        }

        // if TRUE, removes logs and clear logs array
        if ($clear) {
            $this->logs = array();
        }
    }

    // write to file
    public function write_file($message) {

        // if logginf file exists, else raise notice
        if (file_exists($this->full_path)) {
            $has_written = FALSE;

            // while logs have been written
            while ($has_written === FALSE) {

                try {
                    // try to get file handle
                    $fh = fopen($this->full_path, 'a');

                    // do not get handle, throw excpetion
                    if (!is_resource($fh)) {
                        throw new Exception('Unable to get file handler');
                    }

                    // write to file
                    $result = fwrite($fh, $message);

                    // unable to write, throw exception
                    if ($result === FALSE) {
                        throw new Exception('Unable to append file');
                    }
                    fclose($fh);
                    $has_written = TRUE;
                } catch (Exception $exc) {
                    trigger_error("Exception case", E_USER_ERROR);

                    // something went wrong, means logs were not written
                    $has_written = FALSE;
                }
            }

            // if all retries spent and still messages has not written, raise notice
            if (!$has_written)
                trigger_error("Unable to do file logging", E_USER_ERROR);
        } else {
            // raise notice
            trigger_error("Unable to find logging file", E_USER_ERROR);
        }
    }

    // execute query, write to the database
    public function write_db($query) {
		$res = mysqli_query(parent::connect(), $query);
		if (!$res) {
			trigger_error('error query !!!', E_USER_ERROR);
		} 

        // $this->close_database();

		return TRUE;
    }

    // create unique id to identify all logs from singal instance
    public function create_unique_id() {
        $rand = 0;
        for ($i = 0; $i < 3; $i++) {
            $rand .= rand(0, 99);
        }
        $this->unique_id = uniqid($rand . '-');
    }

	public function logs_info ($location, $type, $prefix, $postfix, $message) {

        $this->connect();
		// set location 
		$this->set_location($location);

		// set type file or database or both
		$this->set_type($type);

		// set file name 
		$this->set_file_name($prefix, $postfix);

		$this->write($message);

		$this->flush(true, true);

		return 'successfull';
	}
}
?>


