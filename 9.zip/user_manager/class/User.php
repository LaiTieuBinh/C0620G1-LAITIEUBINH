<?php
session_start();
require('../include/config.php');
require('validate.php');
require('common.php');
require('logs.php');

class User extends DbConfig {	
	// status 
	const ACTIVE = '1';
	const LOCKED = '2';
	const DELETED = '3';
	// gender
	const MALE = '1';
	const FEMALE = '2';
	// role
	const ADMIN = '1';
	const GENERAL = '2';

	const CLOSE_DB = 'Close database';

	// check login admin 
	public function adminLoginStatus() {
		if (empty($_SESSION["adminUserid"])) {
			header("Location: index.php");
		}
	}		

	// login admin page 
	public function adminLogin() {		
		$errorMessage = '';
		if (!empty($_POST["login"]) && $_POST["email"] != '' && $_POST["password"] != '') {	

			// handle input 
			$email = Validate::handle_input($_POST['email']);
			$password = Validate::handle_input($_POST['password']);

			// validate email 
			$errorMessage = Validate::validate_email($email);
			if ($errorMessage) {
				return $errorMessage;
			}

			// get data from db 
			$sqlQuery = 'SELECT * FROM ' . $this->userTable . ' WHERE email = %s AND password = %s AND status = %s 
			AND count_login_fail < 4';
			$row = $this->get_one_row($sqlQuery , [$email, md5($password), self::ACTIVE]);

			
			if ($row) {	
				$this->log_handle($sqlQuery);
				$_SESSION["adminUserid"] = $row['id'];
				$_SESSION["role"] = $row['role'];
				$_SESSION["admin"] = $row['first_name'] . " " . $row['last_name'];

				// log info into history table 
				$historyName = $_SESSION["admin"];
				$historyEmail = $row['email'];

				// $this->set_time_zone();
				$date = date('Y-m-d H:i:s');
				$ip = Common::get_client_ip();

				// count numbers user login 
				$insertQuery = "INSERT INTO " . $this->historyTable . "(name, email, date, ip, user_id) VALUES (%s, %s, %s, %s, %s)";
				$this->insert_data($insertQuery , [$historyName, $historyEmail, $date, $ip, $_SESSION["adminUserid"]]);
				$this->log_handle($insertQuery);

				// redirect to dashboard page 
				$this->log_handle(self::CLOSE_DB);
				$this->close_database();
				header("location: dashboard.php"); 	
			} else {
				$sqlQuery = 'SELECT * FROM ' . $this->userTable . ' WHERE email = %s';
				$rows = $this->get_one_row($sqlQuery, $email);
				$this->log_handle($sqlQuery);

				if ($rows) {
					$count_login_fail = $rows['count_login_fail'];
						
					if ($count_login_fail >= 3) {
						$updateQuery = 'UPDATE ' . $this->userTable . ' SET status = %s WHERE email = %s';
						$this->update_data($updateQuery, [self::LOCKED ,$email]);
						$this->log_handle($updateQuery);
						$errorMessage = 'Your account was blocked because login failed more than ' . $count_login_fail . ' times!';	
					} else if ($count_login_fail == 2) {
						Common::count_login_fail($email);
						$errorMessage = "Password was wrong, your account is loging failed 3 times, if you fail login one more,
						your account will be block!";	
					} else {
						Common::count_login_fail($email);
						$errorMessage = "Password was wrong!";	
					}
				}
			}	
		} else if (!empty($_POST["login"]) && $_POST["email"] == '' && $_POST["password"] == '') {
			$errorMessage = "Enter Both user and password!";	
		} else if (!empty($_POST["login"]) && $_POST["email"] == '') {
			$errorMessage = "Email isn't blank!";	
		} else if (!empty($_POST["login"]) && $_POST["email"] != '' && $_POST["password"] == '') {
			$errorMessage = "Password isn't blank!";
		}

		return $errorMessage; 		
	}			

	public function log_handle($handle) {
		$logs = new Logs();
		
		return $logs->logs_info("../folder_logs", 'File', 'logs', '.txt', $handle);
	}
	// list user 
	public function get_user_list() {		
		$sqlQuery = 'SELECT * FROM ' . $this->userTable . ' WHERE id != %s AND status != %s' ;
		// if (!empty($_POST["search"]["value"])) {
			// $sqlQuery .= ' WHERE first_name = "kaka"';
			// $sqlQuery .= ' OR first_name LIKE "%' . $_POST["search"]["value"] .'%" ';
			// $sqlQuery .= ' OR last_name LIKE "%' . $_POST["search"]["value"] . '%" ';
			// $sqlQuery .= ' OR designation LIKE "%' . $_POST["search"]["value"] . '%" ';
			// $sqlQuery .= ' OR status LIKE "%' . $_POST["search"]["value"] . '%" ';
			// $sqlQuery .= ' OR mobile LIKE "%' . $_POST["search"]["value"] . '%") ';			
		// }
		// if (!empty($_POST["order"])) {
		// 	$sqlQuery .= ' ORDER BY ' . $_POST['order']['0']['column'] . ' ' . $_POST['order']['0']['dir'] . ' ';
		// } else {
		// 	$sqlQuery .= ' ORDER BY id DESC ';
		// }
		// if ($_POST["length"] != -1) {
		// 	$sqlQuery .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		// }	
		
		$data = $this->get_data($sqlQuery, [$_SESSION['adminUserid'], self::DELETED]);
		// $this->log_handle($sqlQuery);

		$numRows = count($data);
		$userData = array();	
		foreach ($data as $rows) {
			$userRows = array();
			$disabled = 'disabled';

			// update status 
			if($rows['status'] == self::ACTIVE) {
				$status = '<span class="label label-success">Active</span>';
			} else if($rows['status'] == self::LOCKED) {
				$status = '<span class="label label-warning">Locked</span>';
			} else if($rows['status'] == self::DELETED) {
				$status = '<span class="label label-danger">Deleted</span>';
			}

			// update gender 
			if ($rows['gender'] == self::MALE) {
				$gender = '<span>Male</span>';
			} else if($rows['gender'] == self::FEMALE) {
				$gender = '<span>Female</span>';
			}

			// update role 
			if($rows['role'] == self::ADMIN) {
				$role = 'Admin';
			} else if($rows['role'] == self::GENERAL) {
				$role = 'General';
			}
			$userRows[] = $rows['id'];
			$userRows[] = ucfirst($rows['first_name']." ".$rows['last_name']);
			$userRows[] = $gender;			
			$userRows[] = $rows['email'];	
			$userRows[] = $rows['mobile'];	
			$userRows[] = $role;
			$userRows[] = $status;		
			if ($_SESSION['role'] != 1) {
				$userRows[] = '<button type="button" name="update" id="'. $rows["id"] .'" class="btn btn-warning btn-xs update" '. $disabled .'>Update</button>';
				$userRows[] = '<button type="button" name="delete" id="'. $rows["id"] .'" class="btn btn-danger btn-xs delete" '. $disabled .'>Delete</button>';
			} else {
				$userRows[] = '<button type="button" name="update" id="'. $rows["id"] .'" class="btn btn-warning btn-xs update" >Update</button>';
				$userRows[] = '<button type="button" name="delete" id="'. $rows["id"] .'" class="btn btn-danger btn-xs delete" >Delete</button>';
			}
			$userData[] = $userRows;
		}
		$output = array(
			"draw"				=>	intval($_POST["draw"]),
			"recordsTotal"  	=>  $numRows,
			"recordsFiltered" 	=> 	$numRows,
			"data"    			=> 	$userData
		);
		echo json_encode($output);

		// $this->close_database(self::CLOSE_DB);
	}

	// delete user 
	public function delete_user() {
		if ($_POST['userId']) {
			$userId = Validate::handle_input($_POST['userId']);
			$sqlUpdate = 'UPDATE ' . $this->userTable . ' SET status = %s WHERE id = %s';	
			$this->update_data($sqlUpdate, self::DELETED ,$userId);	
			$this->log_handle($sqlUpdate);
			$this->close_database(self::CLOSE_DB);
		}

		return 'Deleted successfull !';
	}
	// get user from db 
	public function get_user() {
		if ($_POST['userId']) {
			$userId = Validate::handle_input($_POST['userId']);
			$sqlQuery = 'SELECT * FROM ' . $this->userTable . ' WHERE id = %s';
			$rows = $this->get_one_row($sqlQuery, $userId);
			if ($rows) {
				echo json_encode($rows);
			}	
		}
		$this->log_handle($sqlQuery);
		$this->close_database(self::CLOSE_DB);
		return 'Get user successfull !';
	}

	// update data 
	public function update_user() {
		$respond = array();
		if ($_POST['userid']) {	
			$userId = Validate::handle_input($_POST['userid']);
			$firstName = Validate::handle_input($_POST['firstname']);
			$lastName = Validate::handle_input($_POST['lastname']);
			$email = Validate::handle_input($_POST['email']);
			$mobile = Validate::handle_input($_POST['mobile']);
			$designation = Validate::handle_input($_POST['designation']);
			$gender = Validate::handle_input($_POST['gender']);
			$status = Validate::handle_input($_POST['status']);
			$userType = Validate::handle_input($_POST['role']);

			// validate email 
			$errorMessage = Validate::validate_email($email);
			if (!empty($errorMessage)) {
				$respond['message'] = $errorMessage;

				echo json_encode($respond);
			} else {
				$updateQuery = 'UPDATE ' . $this->userTable . ' SET first_name = %s, last_name = %s, email = %s, mobile = %s , designation = %s, gender = %s, 
				status = %s, role = %s WHERE id = %s';
				$this->update_data($updateQuery, [$firstName, $lastName, $email, $mobile, $designation, $gender, $status, $userType, $userId]);
				// $this->log_handle($updateQuery);
				// $this->close_database(self::CLOSE_DB);

				$respond['message'] = 'Update successfully!';

				echo json_encode($respond);
			}
		}	
	}	

	// save password
	public function save_admin_password() {
		$message = '';
		$password = Validate::handle_input($_POST['password']);
		if ($_POST['password'] && $_POST['password'] != $_POST['cpassword']) {
			$message = "Password does not match the confirm password.";
		} else {			
			$sqlUpdate = 'UPDATE '. $this->userTable . ' SET password = %s WHERE id =%s';	
			$this->log_handle($sqlUpdate);
			$this->close_database(self::CLOSE_DB);
			$isUpdated = $this->update_data($sqlUpdate, [md5($password), $_SESSION['adminUserid']]);
			if ($isUpdated) {
				$message = "Password saved successfully.";
			}				
		}

		return $message;
	}

	// show admin details in profile
	public function admin_details() {
		$sqlQuery = 'SELECT * FROM ' . $this->userTable . ' WHERE id = %s';
		$rows = $this->get_one_row($sqlQuery, $_SESSION['adminUserid']);
		if ($rows) {
			$userDetails = $rows;

			$this->log_handle($sqlQuery);
			$this->close_database(self::CLOSE_DB);
		}

		return $userDetails;
	}	

	// add user 
	public function add_user() {
		$respond = array();

		$firstName = Validate::handle_input($_POST['firstname']);
		$lastName = Validate::handle_input($_POST['lastname']);
		$email = Validate::handle_input($_POST['email']);
		$password = Validate::handle_input($_POST['password']);
		$mobile = Validate::handle_input($_POST['mobile']);
		$designation = Validate::handle_input($_POST['designation']);
		$gender = Validate::handle_input($_POST['gender']);
		$status = Validate::handle_input($_POST['status']);
		$role = Validate::handle_input($_POST['role']);
		$date = date('Y-m-d');

		// validate email 
		$errorMessage = Validate::validate_email($email);
		if (!empty($errorMessage)) {
			$respond['message'] = $errorMessage;

			echo json_encode($respond);
		} else {
			$insertQuery = 'INSERT INTO ' . $this->userTable . '(first_name, last_name, email, gender, password, mobile, designation, role, status, date) 
			VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)';
			$this->insert_data($insertQuery, [$firstName, $lastName, $email, $gender, md5($password), $mobile, $designation, $role, $status, $date]);	
			$this->log_handle($insertQuery);
			$this->close_database(self::CLOSE_DB);

			$respond['message'] = 'Add user successfully!';
			echo json_encode($respond);
		}

		return 'Add user successfull !!!';
		
	}

	// statistical user 
	public function totalUsers($status) {
		if ($status) {
			$sqlQuery = 'SELECT status FROM ' . $this->userTable . ' WHERE status = %s';
		} else {
			$sqlQuery = 'SELECT status FROM ' . $this->userTable . '';
		}
		$data = $this->get_data($sqlQuery, $status);
		$numRows = count($data);
		$this->log_handle($sqlQuery);
		$this->close_database(self::CLOSE_DB);

		return $numRows;
	}

	// statistical user login 
	// public function dashboard_filter() {
	// 	$data = $_POST['dashboard_value'];

	// 	$first_day_this_month = date('Y-m-01');
	// 	$last_day_this_month = date('Y-m-t');
	// 	$first_day_previous_month = date('Y-m-d', strtotime(date('Y-m-01').' -1 MONTH'));

	// 	$seven_days = date('Y-m-d', strtotime(' - 1 week'));
	// 	$one_year = date('Y-m-d', strtotime(' - 1 year'));
		
	// 	$today = date('Y-m-d');

	// 	$ar = [];
	// 	$a = array(array());
	// 	echo $seven_days;

	// 	if ($data == "sevenDays") {
	// 		$sqlQuery = "SELECT * FROM ". $this->historyTable ." 
	// 		WHERE email = '". $email ."'";
	// 	}
	// }
}
?>
