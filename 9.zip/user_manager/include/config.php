<?php

class DbConfig {
    protected $serverName;
    protected $userName;
    protected $password;
    protected $dbName;
    protected $timeZone;
    protected $dbConnect;
    // table
    public $userTable = 'tbl_users';
	public $historyTable = 'tbl_histories';
    public $logsTable = 'tbl_logs';

    public function __construct() {	
		$this->dbConnect = $this->connect();
    }

    // connect with db 
    public function connect() {
        $this->serverName = 'localhost';
        $this->userName = 'root';
        $this->password = 'cms-8341';
        $this->dbName = 'my_database';
        
        if (empty($conn)) {
            $conn = new mysqli($this->serverName, $this->userName, $this->password, $this->dbName);
            if ($conn->connect_error) {
                die("Error failed to connect to MySQL: " . $conn->connect_error);
            } 
        } 
        return $conn;
    }

    public function close_database() {
        if ($this->dbConnect) {
            $this->dbConnect->close();
        }
    }

    // set time zone 
    // public function set_time_zone() {
    //     date_default_timezone_set('Asia/Ho_Chi_Minh');
    // }

    // handle data 
    function handle_data($args, $query) {
        foreach ($args as $key => $val) {
            $args[$key] = $this->dbConnect->real_escape_string($val);
        }

        $query = str_replace("%s", "'%s'", $query); 
        $query = vsprintf($query, $args);
		
		$res = mysqli_query($this->dbConnect, $query);

        if (!$res) {
			trigger_error('error !!!');
		} 

        return $res;
    }

	// get data 
    function get_data($query, $args) {

        $res = $this->handle_data($args, $query);

        $data = array();
        if ($res) {
			while ($row = mysqli_fetch_array($res, MYSQLI_ASSOC)) {
				$data[] = $row;            
			}
        } else {
            $data = NULL;
        }

        return $data;
    }

    // get one row 
    function get_one_row($query, $args) {

        $res = $this->handle_data($args, $query);

        return $res ? mysqli_fetch_assoc($res) : null;
    }

	// update data 
	function update_data($query, $args) {
        $args  = func_get_args();
        $query = array_shift($args);

        $this->handle_data($args, $query);

        return TRUE;
    }

	// insert data 
	function insert_data($query, $args) {
        $this->handle_data($args, $query);

        return TRUE;
    }
}
?>
