-- phpMyAdmin SQL Dump
-- version 4.0.10.20
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 26, 2022 at 03:10 AM
-- Server version: 5.5.60-MariaDB
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `my_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_histories`
--

CREATE TABLE IF NOT EXISTS `tbl_histories` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=50 ;

--
-- Dumping data for table `tbl_histories`
--

INSERT INTO `tbl_histories` (`id`, `name`, `email`, `date`, `ip`, `user_id`) VALUES
(1, 'web damn', 'admin@webdamn.com', '2022-05-24 20:25:27', '192.168.1.132', 1),
(2, 'web damn', 'admin@webdamn.com', '2022-05-24 21:01:32', '192.168.1.132', 1),
(3, 'Andy Flower', 'andy@wd.com', '2022-05-24 21:02:44', '192.168.1.132', 7),
(4, 'Andy Flower', 'andy@wd.com', '2022-05-25 03:31:09', '192.168.1.132', 7),
(5, 'ronaldo jr', 'ronaldo@gmail.com', '2022-05-25 03:31:30', '192.168.1.132', 8),
(6, 'Andy Flower', 'andy@wd.com', '2022-05-25 04:25:03', '192.168.1.132', 7),
(7, 'web damn', 'admin@webdamn.com', '2022-05-25 17:25:47', '192.168.1.132', 1),
(8, 'ronaldo jr', 'ronaldo@gmail.com', '2022-05-25 18:07:05', '192.168.1.132', 8),
(9, 'messi lione', 'messi@gmail.com', '2022-05-25 18:14:30', '192.168.1.132', 9),
(10, 'web damn', 'admin@webdamn.com', '2022-05-25 18:19:08', '192.168.1.132', 1),
(11, 'Andy Flower', 'andy@wd.com', '2022-05-25 18:21:29', '192.168.1.132', 7),
(12, 'Andy Flower', 'andy@wd.com', '2022-05-25 18:25:24', '192.168.1.132', 7),
(13, 'Andy Flower', 'andy@wd.com', '2022-05-25 18:26:23', '192.168.1.132', 7),
(14, 'web damn', 'admin@webdamn.com', '2022-05-25 18:30:08', '192.168.1.132', 1),
(15, 'messi lione', 'messi@gmail.com', '2022-05-25 18:30:23', '192.168.1.132', 9),
(16, 'web damn', 'admin@webdamn.com', '2022-05-25 20:34:33', '192.168.1.132', 1),
(17, 'web damn', 'admin@webdamn.com', '2022-05-25 20:35:34', '192.168.1.132', 1),
(18, 'ronaldo jr', 'ronaldo@gmail.com', '2022-05-25 20:36:32', '192.168.1.132', 8),
(19, 'web damn', 'admin@webdamn.com', '2022-05-25 20:42:40', '192.168.1.132', 1),
(20, 'messi lione', 'messi@gmail.com', '2022-05-25 20:50:14', '192.168.1.132', 9),
(21, 'ronaldo jr', 'ronaldo@gmail.com', '2022-05-25 20:54:20', '192.168.1.132', 8),
(22, 'web damn', 'admin@webdamn.com', '2022-05-25 20:55:38', '192.168.1.132', 1),
(23, 'messi lione', 'messi@gmail.com', '2022-05-25 21:02:08', '192.168.1.132', 9),
(24, 'web damn', 'admin@webdamn.com', '2022-05-25 21:04:31', '192.168.1.132', 1),
(25, 'Andy Flower', 'andy@wd.com', '2022-05-25 21:07:56', '192.168.1.132', 7),
(26, 'Andy Flower', 'andy@wd.com', '2022-05-25 21:08:53', '192.168.1.132', 7),
(27, 'web damn', 'admin@webdamn.com', '2022-05-25 23:02:11', '192.168.1.132', 1),
(28, 'web damn', 'admin@webdamn.com', '2022-05-25 23:04:36', '192.168.1.132', 1),
(29, 'ronaldo jr', 'ronaldo@gmail.com', '2022-05-25 23:09:52', '192.168.1.132', 8),
(30, 'web damn', 'admin@webdamn.com', '2022-05-25 23:12:46', '192.168.1.132', 1),
(31, 'messi lione', 'messi@gmail.com', '2022-05-25 23:13:50', '192.168.1.132', 9),
(32, 'ronaldo jr', 'ronaldo@gmail.com', '2022-05-25 23:22:50', '192.168.1.132', 8),
(33, 'Andy Flower', 'andy@wd.com', '2022-05-25 23:23:44', '192.168.1.132', 7),
(34, 'messi lione', 'messi@gmail.com', '2022-05-25 23:27:18', '192.168.1.132', 9),
(35, 'web damn', 'admin@webdamn.com', '2022-05-25 23:39:13', '192.168.1.132', 1),
(36, 'Andy Flower', 'andy@wd.com', '2022-05-25 23:41:38', '192.168.1.132', 7),
(37, 'ronaldo jr', 'ronaldo@gmail.com', '2022-05-25 23:46:29', '192.168.1.132', 8),
(38, 'web damn', 'admin@webdamn.com', '2022-05-26 00:01:20', '192.168.1.132', 1),
(39, 'web damn', 'admin@webdamn.com', '2022-05-26 00:06:12', '192.168.1.132', 1),
(40, 'web damn', 'admin@webdamn.com', '2022-05-26 00:07:33', '192.168.1.132', 1),
(41, 'web damn', 'admin@webdamn.com', '2022-05-26 00:09:13', '192.168.1.132', 1),
(42, 'web damn', 'admin@webdamn.com', '2022-05-26 00:13:10', '192.168.1.132', 1),
(43, 'web damn', 'admin@webdamn.com', '2022-05-26 00:15:28', '192.168.1.132', 1),
(44, 'web damn', 'admin@webdamn.com', '2022-05-26 00:17:02', '192.168.1.132', 1),
(45, 'web damn', 'admin@webdamn.com', '2022-05-26 00:17:33', '192.168.1.132', 1),
(46, 'web damn', 'admin@webdamn.com', '2022-05-26 00:19:33', '192.168.1.132', 1),
(47, 'web damn', 'admin@webdamn.com', '2022-05-26 02:26:12', '192.168.1.132', 1),
(48, 'web damn', 'admin@webdamn.com', '2022-05-26 02:29:12', '192.168.1.132', 1),
(49, 'Andy Flower', 'andy@wd.com', '2022-05-26 02:48:01', '192.168.1.132', 7);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_logs`
--

CREATE TABLE IF NOT EXISTS `tbl_logs` (
  `auto_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `log_date` datetime NOT NULL,
  `log_details` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`auto_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_logs`
--

INSERT INTO `tbl_logs` (`auto_id`, `log_location`, `log_date`, `log_details`) VALUES
(1, '0857558-628e0dd98138d', '2022-05-25 20:07:05', 'successfull !!!'),
(2, '0857558-628e0dd98138d', '2022-05-25 18:07:05', 'close database'),
(3, '030717-628e13b11e700', '2022-05-25 20:32:01', 'this is error !!!'),
(4, '060018-628e14494cde6', '2022-05-25 20:34:33', 'successfull !!!'),
(5, '0434487-628e148672866', '2022-05-25 20:35:34', 'successfull !!!'),
(6, '092843-628e3cc6d8e9f', '2022-05-25 23:27:18', 'successfull'),
(7, 'folder_logs/logs_2705_20220525.txt', '2022-05-25 23:39:13', 'SELECT * FROM tbl_users WHERE email = %s AND password = %s AND status = %s \n			AND count_login_fail < 4'),
(8, 'folder_logs/logs_2705_20220525.txt', '2022-05-25 23:41:38', 'SELECT * FROM tbl_users WHERE email = %s AND password = %s AND status = %s \r\n			AND count_login_fail < 4'),
(9, 'folder_logs/logs_2705_20220525.txt', '2022-05-25 23:41:38', 'INSERT INTO tbl_histories(name, email, date, ip, user_id) VALUES (%s, %s, %s, %s, %s)'),
(10, 'folder_logs/logs_2705_20220525.txt', '2022-05-25 23:41:38', 'close db'),
(11, 'folder_logs/logs_2705_20220525.txt', '2022-05-25 23:46:29', 'SELECT * FROM tbl_users WHERE email = %s AND password = %s AND status = %s \r\n			AND count_login_fail < 4'),
(12, 'folder_logs/logs_2705_20220525.txt', '2022-05-25 23:46:29', 'INSERT INTO tbl_histories(name, email, date, ip, user_id) VALUES (%s, %s, %s, %s, %s)'),
(13, 'folder_logs/logs_2705_20220525.txt', '2022-05-25 23:46:29', 'close database'),
(14, 'folder_logs/logs_2705_20220525.txt', '2022-05-25 23:56:38', 'SELECT * FROM tbl_users WHERE email = %s'),
(15, 'folder_logs/logs_2705_20220525.txt', '2022-05-25 23:56:38', 'SELECT count_login_fail FROM tbl_users WHERE email = %s'),
(16, 'folder_logs/logs_2705_20220525.txt', '2022-05-25 23:56:38', 'UPDATE tbl_users SET count_login_fail = %s WHERE email = %s'),
(17, 'folder_logs/logs_2705_20220525.txt', '2022-05-25 23:56:38', 'close database');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL DEFAULT '1',
  `mobile` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `designation` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `role` tinyint(2) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `date` date NOT NULL,
  `count_login_fail` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `first_name`, `last_name`, `email`, `password`, `gender`, `mobile`, `designation`, `role`, `status`, `date`, `count_login_fail`) VALUES
(1, 'web', 'damn', 'admin@webdamn.com', '202cb962ac59075b964b07152d234b70', 1, '123456789', 'Web developer', 1, 1, '0000-00-00', 3),
(5, 'john', 'smith', 'info@webdamn.com', '202cb962ac59075b964b07152d234b70', 1, '123456789', 'Web developer', 1, 1, '0000-00-00', 0),
(6, 'Jimmy', 'Anderson', 'jm@wd.com', '202cb962ac59075b964b07152d234b70', 2, '11111111111', 'PHP developer', 1, 3, '0000-00-00', 1),
(7, 'Andy', 'Flower', 'andy@wd.com', '202cb962ac59075b964b07152d234b70', 1, '11111111111', 'dfdsd', 1, 1, '0000-00-00', 1),
(8, 'ronaldo', 'jr', 'ronaldo@gmail.com', '202cb962ac59075b964b07152d234b70', 2, '1234345', 'dev', 2, 1, '0000-00-00', 2),
(9, 'messi', 'lione', 'messi@gmail.com', '202cb962ac59075b964b07152d234b70', 2, '3333', 'Web developer', 2, 1, '0000-00-00', 1),
(10, 'neymar', 'jr', 'neymar@gmail.com', '202cb962ac59075b964b07152d234b70', 1, '4444444', 'Web developer', 2, 2, '0000-00-00', 0),
(11, 'kaka', 'ricardo', 'kaka@gmail.com', '202cb962ac59075b964b07152d234b70', 1, '12121212', 'Web developer', 2, 1, '2022-05-02', 2),
(12, 'Jimmy', 'Anderson', 'himmy@gmail.com', '202cb962ac59075b964b07152d234b70', 2, '4444444', 'Web developer', 2, 1, '2022-05-02', 0),
(13, 'obama', 'smith', 'obama@gmail.com', '202cb962ac59075b964b07152d234b70', 1, '3333333333', 'Web developer', 1, 1, '2022-05-02', 0),
(14, 'john', 'Flower', 'himmy11@gmail.com', '202cb962ac59075b964b07152d234b70', 1, '1234345', 'dev', 2, 1, '2022-05-26', 0);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_histories`
--
ALTER TABLE `tbl_histories`
  ADD CONSTRAINT `tbl_histories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
