<?php
/**
 * Zend FW application
 * (c)2015 a.ide
 */
require_once ABSTRACTZEND_PATH."/models/AbstractIndex.php";

class Index extends AbstractIndex {

	/** constructor */
	public function __construct($controller = null) {
		parent::__construct($controller);
	}

	/**
	 * exec
	 */
	public function exec($request = array()) {

		//get data
		$data = $this->getDataTable();
		$hitcnt = $data->count;
		$rows = $data->rows;

		//html
		$htmlrec = $this->createHtml($rows, $hitcnt);
		return $htmlrec;
	}

}
?>
