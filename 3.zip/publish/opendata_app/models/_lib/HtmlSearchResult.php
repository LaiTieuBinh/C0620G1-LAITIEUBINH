<?php
/**
 * Zend FW application
 * (c)2015 a.ide
 */
class HtmlSearchResult {

	static $PHTML = "searchResult.phtml";

	static $COLNAMES = array(
		"data_link_title",
		"data_link_url",
		"data_link_target",
		"summary",
		"license",
		"category",
		"od_data_type",
		"data_type",
		"data_upddt",
		"data_time",
		"dept_code",
	);

	public $html = null;

	/**
	 * constructor
	 * @param $view ZendFW View object
	 * @param $request request object
	 * @param $rows display data (max=maxDataCntPage)
	 * @param $hitcnt [optional] hit count
	 * @param $start [optional] startposition from hit data
	 * @param $config [optional] app.ini
	 */
	public function __construct($view, $request, $rows, $hitcnt = 0, $start = 1, $config = null) {

		$phtml = self::$PHTML;

		$query = $request->query;
	
		$end = $start + count($rows) - 1;
		$start = ($hitcnt == 0) ? 0 : $start;
		$baseurl = $config->application->baseurl;
		
		//result
		$htmlrec = null;

		//データ明細
		$view->setSearchPattern("searchresult_item");
		foreach ($rows as $row) {
			extract($row);

			//license image
			if (($license >= 1) && ($license <= 8)) {
				$view->setSearchPattern("license_image_{$license}");
				$license = $view->render(self::$PHTML);
			}
			
			if(!empty($data_link_target)){
				if (!empty($data_type) && $data_type != 'html') {
					//ダウンロード
					$view->setSearchPattern("data_link_url_download");
					$view->addColumnItems("filename", $data_link_url);
					$view->addColumnItems("page_url", $path);
					$link_download = $view->render(self::$PHTML);
				} else {
					//掲載ページ
					$view->setSearchPattern("data_link_url_page");
					$view->addColumnItems("href", $data_link_url);
					$view->addColumnItems("page_url", $path);
					$view->addColumnItems("target", "target='{$data_link_target}'");
					//形式がhtmlの場合、リンクボタンを表示しない
					//$link_download = $view->render(self::$PHTML);
					$link_download = '';
				}
			}
			
			//一覧表項目
			$view->setSearchPattern("searchresult_item");
			$view->addColumnItems("data_link_title", $data_link_title);
			$view->addColumnItems("summary", $summary);
			$view->addColumnItems("data_open", $data_open);
			$view->addColumnItems("license", $license);
			if (empty($category)) {
				$view->addColumnItems("category",'');
			}
			else {
				$category_str = '';
				$category_param_ary = explode(',', $category);
				foreach ($category_param_ary as $category_param) {
					$category_str .= Config_Const::$CATEGORY[$category_param] . '|';
				}
				// 文字列最後の区切り文字を削除
				$category_str = substr($category_str, 0 , -1);
				$view->addColumnItems("category", $category_str);
			}
			$view->addColumnItems("od_data_type", empty($od_data_type)?'':Config_Const::$DATA_TYPE[$od_data_type]);
			$view->addColumnItems("data_type", $data_type);
			$view->addColumnItems("data_time", $data_time);
			$view->addColumnItems("data_upddt", $data_upddt);
			$view->addColumnItems("link_download", $link_download);
			$view->addColumnItems("link_page", $path);
			$view->addColumnItems("dept_code", $dept_code);
			
			$htmlrec .= $view->render($phtml);
		}

		//sort用リンク
		$htmlsorts = $this->createHtmlSortLink($view, $request);
		
		// items
		$view->setSearchPattern("searchresult");
		$view->addColumnItems("item", $htmlrec);
		$view->addColumnItems("datacnt", $hitcnt);
		$view->addColumnItems("startcnt", $start);
		$view->addColumnItems("endcnt", $end);
		
		//無かった場合
		$view->addColumnItems('dispnone',empty($htmlrec)?' style="display:none;"':'');
		$view->addColumnItems('itemnone',empty($htmlrec)?Config_Const::$ITEM_NONE_MSG:'');
		
		//sort用リンク(カラム名とhtml埋込名が同じ)
		$view->addColumnItemsAll($htmlsorts);
		$htmlrec = $view->render($phtml);

		$this->html = $htmlrec;
	}

	private function createHtmlSortLink($view, $request) {
		$htmlsorts = array();
		foreach (self::$COLNAMES as $colname) {
			if ($colname == $request->sortcolname) {
				$sort = $request->sort;
			}else{
				$sort = Request::$SORT_DEFAULT;
			}
			$view->setSearchPattern("sort_{$sort}");
			$view->addColumnItems("page", $request->page);
			$view->addColumnItems("pagestart", $request->pagestart);
			$view->addColumnItems("sort", $sort);
			$view->addColumnItems("colname", $colname);
			$view->addColumnItems("query", $request->query);
			$htmlsorts[$colname] = $view->render(self::$PHTML);
		}
		return $htmlsorts;
	}

}
?>
