<?php
/**
 * Zend FW application
 * (c)2015 a.ide
 */
class HtmlPagenate {

	static $PHTML = "searchResult.phtml";

	public $html = null;

	/**
	 * constructor
	 * @param $view ZendFW View object
	 * @param $request request object
	 * @param $hitcnt data hit count
	 * @param $htmlinfo application.html object in app.ini, maxDataCntPage, maxPageNum
	 */
	public function __construct($view, $request, $hitcnt, $htmlinfo) {

		$phtml = self::$PHTML;

		//選択ページ
		$page = $request->page;
		
		//スタートページ
		$pagestart = $request->pagestart;
		
		//総ページ数(切り上げ)
		$pagecnt = ceil($hitcnt / $request->items['displayedresults']);
		
		//他情報
		$sort = $request->sort;
		$sortcolname = $request->sortcolname;
		$query = $request->query;
				
		//$htmlinfo->maxDataCntPage １ページの明細数
		//$htmlinfo->maxPageNum ページナビの表示件数
		
		// 現在全何件中、何件から何件を表示しているか
		$all_count = $hitcnt;
		if ($page == 1) {
			$start_count = 1;
			$end_count = $request->items['displayedresults'];
		}
		else {
			$start_count = (($page - 1) * $request->items['displayedresults']) + 1;
			$end_count = $page * $request->items['displayedresults'];
		}
		if ($end_count > $all_count) {
			$end_count = $all_count;
		}
		$disp_current_pages_str = $all_count . '件中&nbsp;' . $start_count . '～' . $end_count . '件表示';
		
		$htmlpage = null;
		
		if($pagecnt <= $htmlinfo->maxPageNum){
			//そのまま表示
			$htmlprev = "";
			$htmlnext = "";
			for ($i=1; $i<=$htmlinfo->maxPageNum; $i++) {
				if ($i == $page) {
					$view->setSearchPattern("pagenate_item_current");
					$view->addColumnItems("name", $i);
					$htmlpage .= $view->render($phtml);
	
				}else if ($i <= $pagecnt) {
					$view->setSearchPattern("pagenate_item");
					$view->addColumnItems("page", $i);
					$view->addColumnItems("pagestart", "d");
					$view->addColumnItems("name", $i);
					$view->addColumnItems("sort", $sort);
					$view->addColumnItems("colname", $sortcolname);
					$view->addColumnItems("query", $query);
					$htmlpage .= $view->render($phtml);
				}else{
					break;
				}		
			}
		} else {
			$htmlprev = "";
			$htmlnext = "";
			if($page!=1){
				//前へ
				$view->setSearchPattern("pagenate_item_prev");
				$view->addColumnItems("page", ($page - 1));
				$view->addColumnItems("pagestart", "p");
				$view->addColumnItems("sort", $sort);
				$view->addColumnItems("colname", $sortcolname);
				$view->addColumnItems("query", $query);
				$htmlprev = $view->render($phtml);
			}
			if($page!=$pagecnt){
				//次へ
				$view->setSearchPattern("pagenate_item_next");
				$view->addColumnItems("page", ($page + 1));
				$view->addColumnItems("pagestart", "n");
				$view->addColumnItems("sort", $sort);
				$view->addColumnItems("colname", $sortcolname);
				$view->addColumnItems("query", $query);
				$view->addColumnItems("pagemax",$pagecnt);
				$htmlnext = $view->render($phtml);				
			}
			if($pagestart=="p"){
				$f_cnt = ceil(($htmlinfo->maxPageNum - 1) / 2);
				$a_cnt = $htmlinfo->maxPageNum - $f_cnt;
			} else {
				$a_cnt = ceil(($htmlinfo->maxPageNum - 1) / 2);
				$f_cnt = $htmlinfo->maxPageNum - $a_cnt;
			}

			//スタートセット
			if($page <= $f_cnt){
				$st = 1;
			} else {
				$st = $page - $f_cnt;
			}
			if($pagecnt < ($page + $a_cnt)){
				$st = $pagecnt - $htmlinfo->maxPageNum + 1;
			}
			
			for ($i=$st; $i<($htmlinfo->maxPageNum+$st); $i++) {
				if ($i == $page) {
					$view->setSearchPattern("pagenate_item_current");
					$view->addColumnItems("name", $i);
					$htmlpage .= $view->render($phtml);
				}else if ($i <= $pagecnt) {
					$view->setSearchPattern("pagenate_item");
					$view->addColumnItems("page", $i);
					$view->addColumnItems("pagestart", $pagestart);
					$view->addColumnItems("name", $i);
					$view->addColumnItems("sort", $sort);
					$view->addColumnItems("colname", $sortcolname);
					$view->addColumnItems("query", $query);
					$htmlpage .= $view->render($phtml);
				}else{
					break;
				}		
			}
		}
		
			// ページナビのhtml作成
		$view->setSearchPattern("pagenate");
		$view->addColumnItems("pageitems", $htmlpage);
		$view->addColumnItems("pagecnt", $pagecnt);
		$view->addColumnItems("pageprev", $htmlprev);
		$view->addColumnItems("pagenext", $htmlnext);
		$view->addColumnItems("disp_current_page_no", $disp_current_pages_str);
		$htmlpage = $view->render($phtml);

		$this->html = $htmlpage;
	}
}

?>
