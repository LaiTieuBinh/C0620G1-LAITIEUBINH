<?php
/**
 * Zend FW application
 * (c)2015 a.ide
 */

class DummyData {

	public $count = 0;
	public $items = array();

/*
    data_id integer NOT NULL,
    data_num smallint NOT NULL,
    data_link_title character varying(256),
    data_link_url character varying(512),
    data_link_target character varying(8),
    summary text,
    license smallint NOT NULL,
    category character varying(256),
    data_type character varying(16),
    data_upddt date NOT NULL,
    data_open smallint,
    page_id integer,
    path character varying(256),
    title character varying(256),
    template_id smallint,
    cate_1st character varying(16),
    cate_2st character varying(16),
    cate_3st character varying(16),
    cate_4st character varying(16),
    publish_start timestamp without time zone,
    publish_end timestamp without time zone,
    dept_code character varying(16),
    adddt timestamp without time zone,
    upddt timestamp without time zone,
    data_hidden smallint,
    data_size integer
 */


	/** constructor */
	public function __construct($datacnt = 0) {
		for ($i = 0; $i < $datacnt; $i++) {
			$cols = array();
			for ($j = 0; $j < 11; $j++) {
				$cols[] = ($j + ($i * 1000));
			}
			/*
			$rec = array(
				"datatitle" => $cols[0],
				"gaiyo" => $cols[1],
				"opendata" => $cols[2],
				"license" => $cols[3],
				"category" => $cols[4],
				"keishiki" => $cols[5],
				"upddate" => $cols[6],
				"pubdate" => $cols[7],
				"link" => $cols[8],
				"pubpage" => $cols[9],
				"soshikiname" => $cols[10],
			);
			 *
			 */
			$this->items[] = $cols;
			$this->count++;
		}
		return;
	}

	public function getCount() {
		return count($this->items);
	}

	public function getData($datacnt = 0, $start = 1) {
		$recs = array();
		if ($this->count < $datacnt) {
			$datacnt = $this->count;
		}
		$offset = ($start - 1);
		for ($i = 0; $i < $datacnt; $i++) {
			$ii = $i + $offset;
			if ($ii < $this->count) {
				$recs[] = $this->items[$ii];
			}else{
				break;
			}
		}
		return $recs;
	}


}
?>
