<?php
/**
 * Zend FW application
 * (c)2015 a.ide
 */

class ApplicationException extends Zend_Exception {

	public $className = null;

	/**
	 * constructor
	 */
	public function __construct($msg = null, $classname = "ApplicationException") {
		parent::__construct($msg);

		$this->className = $classname;
	}
}
?>
