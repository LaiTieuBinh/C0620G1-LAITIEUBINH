#==============================================================================
# 緊急災害情報 共通関数群
#	緊急災害情報で使用する共通関数を記述します。
#==============================================================================

#==============================================================================
# パッケージの宣言
#==============================================================================
package pack_com_urgency;
#==============================================================================
# カンマ区切り配列に格納
#	【引数】
#			int $_csvStr csvのパス
#	【戻値】
#			
#==============================================================================

sub csvStrCut {
	# CSV 文字列( 1行 )
	my ( $_csvStr ) = @_;

	# 改行コード削除
	chomp($_csvStr);
	
	my @_ret = ();
	# カンマ区切り
	@_ret = split(/,/, $_csvStr);
	
	# 全角、半角空白の除去
	for (my $dCnt=0; $dCnt < @_ret; $dCnt++) {
		$_ret[$dCnt] =~ s/(　| )+//g;
	}
	
	return @_ret;
}

#==============================================================================
# ユーザ情報チェック
#	【引数】
#			TEXT $user_id ユーザID
#         	TEXT $password_sha256 パスワード 
#	【戻値】
#			NG:　0/OK:auth
#==============================================================================
sub userCheck {
	# 引数の取得
	my ($user_id, $password_sha256) = @_;
	
	# CSVのPath
	my $csv = $main::CONST_URGENCY_CSV_DIR_PATH . '/' . $main::CONST_URGENCY_USER_CSV_FILE_NAME;
	
	# 定義
	my $line_cnt = 0;
	my @csv_header_ary = ();
	my @csv_line = ();
	my @csv_line_ary = ();
	
	# CSVオープン
	if (sysopen(IN, $csv, O_RDONLY) == 0) {
		return 0;
	}
	
	# ファイル内容の取得
	while(<IN>){
		# カンマで区切って配列格納
		@csv_line = &csvStrCut($_);
		# CSV行分繰り返す
		for (my $csv_column_cnt = 0; $csv_column_cnt < @csv_line; $csv_column_cnt++) {
			# 1行目の場合はヘッダー取得
			if ($line_cnt == 0) {
				# ヘッダー文字列を配列に格納
				$csv_header_ary[$csv_column_cnt] = $csv_line[$csv_column_cnt];
			}
			# 1行目以外はデータを取得
			else {
				# 配列に格納
				$csv_line_ary[($line_cnt - 1)]->{$csv_header_ary[$csv_column_cnt]} = $csv_line[$csv_column_cnt];
			}
		}
		$line_cnt++;
	}
	close(IN);
	
	# 表示データ抽出
	# CSVが1行以上存在する場合
	if ($line_cnt > 1) {
		# CSVのデータ分繰り返す
		foreach my $csv_line(@csv_line_ary) {
			if ($csv_line->{'user_id'} eq $user_id && 
				 ($csv_line->{'password'} =~ /$password_sha256/i)) {
				return $csv_line->{'auth'};
			}
		}
	}
	return 0;
}

#==============================================================================
# ファイルリスト取得
#	【引数】
#			text $dir_path ディレクトリのパス
#			text $pub_dir 公開側のディレクトリパス
#	【戻値】
#			@ret_ary
#==============================================================================
sub getFileList {
	
	# パラメータを取得する
	my ( $dir_path, $pub_dir ) = @_;
	$dir_path =~ s/\/$//g;
	
	# 変数設定
	my @ret_ary = ();
	
	# 対象ディレクトリからファイルリストを取得する
	opendir(THIS, $dir_path);
	# ファイル名の降順(文字列比較)
	my @all = sort { $b cmp $a } grep(!/^\./, readdir(THIS));
	closedir(THIS);
	
	# ファイルを一つずつ読み込んでページタイトルを取得する
	foreach $file_name (@all) {
		# 拡張子が.htmlのものだけ
		if ($file_name =~ /.html$/i) {
			# ロックファイル作成・失敗したらそのページを飛ばす
			unless (&fileLock('ON', $main::DEFAULT_LOCK_FILE_DIR, $file_name)) {
				next;
			}
			
			# ファイルを読み込む
			if (sysopen(IN, $dir_path . '/' . $file_name, O_RDONLY) != 0) {
				my $file_str = '';
				while (<IN>) {
					$file_str .= $_;
				}
				close(IN);
				# ページタイトルを取得する
				if ($file_str =~ m#<span ([^>]*)>([^<]*)</span>#si) {
					my $title = $2;
					if ($pub_dir) {
						$file_name =  $main::CONST_URGENCY_HTTP_PUB_DIR .'/'. $file_name
					}
					if($1 =~m#$main::CONST_URGENCY_PUB_PAGE_PARAMETER_HASH{'title'}# ){
						push(@ret_ary, {'file_name' => $file_name, 'title' => $title});
					}
				}
			}
			# ロックファイル削除
			&fileLock('OFF', $main::DEFAULT_LOCK_FILE_DIR, $file_name);
		}
	}
	# 配列を返却する
	return @ret_ary;
}

#==============================================================================
# 新しいHTMLファイル名を作成する
#	【引数】
#			$type 拡張子
#			
#	【戻値】$ret_str
#			ファイル名：年月日時分秒+ランダム数字4桁+.html（yyyyMMddHHiiss[0-9][0-9][0-9][0-9].html）
#==============================================================================
sub makeNewFileName {
	# パラメータを取得する
	my ( $type ) = @_;
	if ($type eq '') {
		$type = '.html';
	}
	
	# 日時の取得
	my ($sec, $min, $hour, $mday, $mon, $year, $wday) = localtime();
	$mon++; # 月数には1を足す。
	$year = 1900+$year; # 年数には、1900を足す。
	# yyyyMMddHHmmssに整形
	my $ret_str = sprintf("%4d%02d%02d%02d%02d%02d", $year, $mon, $mday, $hour, $min, $sec);
	# 4桁の乱数とファイル拡張子を追加
	$ret_str .= int(rand(10)) . int(rand(10)) . int(rand(10)) . int(rand(10)) . $type; 
	return $ret_str;
}

#==============================================================================
# HTMLページファイルから編集領域を取得する
#	【引数】
#			$file_path ファイルパス
#			
#	【戻値】%ret_hash
#			編集領域連想配列{'title', 'context', 'image-path', 'link1-url', 'link1-title', 'link2-url', 'link2-title', 'link2-url', 'link2-title'}
#==============================================================================
sub getEditableItems {
	
	use File::Basename;
	# パラメータを取得する
	my ( $file_path ) = @_;
	
	# 変数設定
	my %ret_hash = ();
	my $file_str = '';
	
	# ロックファイル作成
	unless (&fileLock('ON', $main::DEFAULT_LOCK_FILE_DIR, basename($file_path))) {
		$ret_hash{'error_code'} = '104';
		return %ret_hash;
	}
	# HTMLファイルの読み込み
	if (sysopen(IN, $file_path, O_RDONLY) == 0) {
		# エラーが発生したら0を返す
		$ret_hash{'error_code'} = '102';
		return %ret_hash;
	}
	while (<IN>) {
		$file_str .= $_;
	}
	close(IN);
	
	# ロックファイル削除
	unless (&fileLock('OFF', $main::DEFAULT_LOCK_FILE_DIR, basename($file_path))) {
		$ret_hash{'error_code'} = '105';
		return %ret_hash;
	}
	# html中の改行を削除する(textarea中の改行を削除するため)
	$file_str =~ s/\r\n//g;

	# htmlファイルからspanタグを最短で抽出する(入力欄のものは事前にエスケープ)
	while ($file_str =~ m#<span ([^>]*)>(.*?)</span>#gi) {
		my $span_id = $1;
		my $value = $2;
		# 編集領域のパラメータ数分ループ
		foreach my $param(keys %main::CONST_URGENCY_PUB_PAGE_PARAMETER_HASH) {
			# spanからidをマッチする
			if ($span_id !~ m/id="$main::CONST_URGENCY_PUB_PAGE_PARAMETER_HASH{$param}"/) {
				next;
			}
			
			# 画像情報を取得する
			if ($value=~ m/<img [^>]*>/si) {
				if ($& =~ m/src="(.*\/)?([^\/"]+)"/si) {
					$ret_hash{'image-fname'} = $2;
				}
			}
			# リンク情報を取得する
			elsif ($value =~ m/<a href="([^"]*)"[^>]*>([^<]*)</si) {
				$ret_hash{$param.'-url'} = $1;
				$ret_hash{$param.'-title'} = $2;
			}
			# それ以外の情報を取得する(タイトル・コンテキスト)
			else{
				$ret_hash{$param} = $value;
				$ret_hash{$param} =~ s/<br( \/)?>/\r\n/g;
				$ret_hash{$param} = $ret_hash{$param};
			}
			last;
		}
	}
	
	# 連想配列を返却する
	return %ret_hash;

}

#==============================================================================
# ログ出力
#	【引数】
#			$file_name プログラムファイル名
#			$msg 記録するメッセージ
#			
#	【戻値】
#			1 / 0
#==============================================================================
sub writeLog {
	# パラメータを取得する
	my ( $file_name, $msg ) = @_;
	
	# 日時の取得
	my ($sec, $min, $hour, $mday, $mon, $year, $wday) = localtime();
	$mon++; # 月数には1を足す。
	$year = 1900+$year; # 年数には、1900を足す。
	# 書式（yyyy/mm/dd H:i:s \t ($file_name) \t $msg）
	my $log_str = sprintf("%4d/%02d/%02d/ %02d:%02d:%02d", $year, $mon, $mday, $hour, $min, $sec) . "\t(" . $file_name . ")\t" . $msg . "\n";
	
	# ログファイルに追記する
	if (open(FH, ">>".$main::CONST_URGENCY_LOG_FILE_PATH)) {
		print FH $log_str;
		close(FH);
		return 1;
	} else {
		return 0;
	}
}

#==============================================================================
# リンクURL表記チェック
#	【引数】
#			$url リンクURL
#			
#	【戻値】
#			1 / 0
#==============================================================================
sub checkURL {
	# パラメータを取得する
	my ( $url ) = @_;
	
	my $URL_REGREP = '^((?:https?):)?//(?:[a-zA-Z0-9-;/?|:@&=+$,_.!~*\'%#]+)';
	if ($url ne '' && $url !~ /($URL_REGREP)/o) {
		return 0;
	} else {
		return 1;
	}
}

#==============================================================================
# 渡されたsession_idが実在かつ期限内であるかをチェックする
# 
#	【引数】	$session_id
#	【戻値】
#			1 / 0
#==============================================================================
sub sessionCheck {
	# パラメータを取得する
	my $session_id = shift;
	
	# session_idから既存のセッションを開く
	my $session=CGI::Session->load("driver:File", $session_id, {Directory=>$main::CONST_URGENCY_SESSION_DIR});
	
	# セッションが存在しないか若しくは期限が過ぎている場合
	if ( $session->is_empty() || $session->is_expired()) {
		$session->delete;
		return 0;
	}
	
	return 1;
}

#==============================================================================
# セッションから値を取得する
#	【引数】	$session_id:	セッションID
#				@data_ary:	セッションから抽出する項目
#	【戻値】
#			%ret_hash	
#==============================================================================
sub getSessionData {
	my ($session_id, @data_ary) = @_;

	# セッションから取得する項目を指定されていなければ、デフォルトの項目を取得する
	if (@data_ary == 0) {
		@data_ary = @main::CONST_URGENCY_SESSION_HASH;
	}
	
	# session_idから既存のセッションを開く
	my $session=CGI::Session->load("driver:File", $session_id, {Directory=>$main::CONST_URGENCY_SESSION_DIR});	
	
	my %ret_hash;	
	foreach my $param(@data_ary) {
		$ret_hash{$param} = $session->param($param);
	}

	return %ret_hash;
}
#==============================================================================
# 指定されたセッションを削除する
#	【引数】	セッションID
#==============================================================================
sub deleteSession {
	# パラメータを取得する
	my $session_id = shift;
	
	# session_idから既存のセッションを開く
	my $session=CGI::Session->load("driver:File", $session_id, {Directory=>$main::CONST_URGENCY_SESSION_DIR});
	
	# セッションの削除
	$session->delete;
}

#==============================================================================
# セッションを新規作成する
# 引数が存在する時は、渡されたデーターをセッションに格納する
#	【引数】	ハッシュ配列
#	【戻値】
#			セッションID / 0
#==============================================================================
sub createSession {  
	my (%data_hash) = @_;
	
	# セッションを新規作成する
	my $session = CGI::Session->new("driver:File", undef , {Directory=>$main::CONST_URGENCY_SESSION_DIR});	
	# セッションの作成に失敗した場合
	
	if ($session->is_empty) {
		return 0;
	}
	
	# セッション期限を設定('m'：分を意味する)
	$session->expire($main::CONST_URGENCY_SESSION_TIME . 'm');
	
	# セッションIDを記録する
	my $new_session_id = $session->id();
	
	# 引数が渡されていればセッションに格納する
	if (keys(%data_hash) > 0) {
		foreach my $param(keys %data_hash) {
			if ($param ne 'session_id') {
				$session->param($param, $data_hash{$param});
			}
		}
	}
	
	return $new_session_id;
}


#==============================================================================
# cookie期限の日付文字列を生成
#	【引数】	期限(分)
#	【戻値】
#			cookieの期限用文字列(現時刻に期限(分)を足したもの)
#			「Thu, 01-Jan-2010 00:00:00 GMT」
#==============================================================================
sub makeExpiresDate{
	
	# 期限・(単位：分)
	my $expires = $_[0];
		
	# 0:秒,1:分,2:時,3:日,4:月(1を引いたもの),5:年(1900を引いたもの),6:曜日(日曜日が0)
	my @t = gmtime(time() + $expires * 60);
	my @m = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	my @w = ('Sun','Mon','Tue','Wed','Thu','Fri','Sat');
	
	# 「Thu, 01-Jan-2010 00:00:00 GMT」のような文字列になる
	my $str = sprintf("%s, %02d-%s-%04d %02d:%02d:%02d GMT",
			$w[$t[6]], $t[3], $m[$t[4]], $t[5]+1900, $t[2], $t[1], $t[0]);
			
	return $str;
}

#==============================================================================
# ロックファイル作成
#	【引数】
#			string $lock_flg ロックフラグ文字列 'ON' or 'OFF'
#			string $lock_file_hash{'dir'} ロックファイルディレクトリ文字列
#			string $lock_file_hash{'name'} ロックファイル名文字列
#			int $lock_file_hash{'retry'} ロックファイルリトライ回数
#			int $lock_file_hash{'timeout'} ロックファイルタイムアウト
#	【戻値】
#			int 0 何らかの理由で失敗をした
#			int 1 正常終了
#==============================================================================
sub fileLock {
	
	# 必要なモジュールを読み込む
	use Fcntl;
	
	# 引数の取得
	my $lock_flg = $_[0];
	my %lock_file_hash = (
		'dir' => ($_[1] ne '' ? $_[1] : $main::DEFAULT_LOCK_FILE_DIR),
		'name' => ($_[2] ne '' ? $_[2] : $main::DEFAULT_LOCK_FILE_NAME),
		'retry' => ($_[3] ne '' ? $_[3] : $main::DEFAULT_LOCK_FILE_RETRY_CNT),
		'timeout' => ($_[4] ne '' ? $_[4] : $main::DEFAULT_LOCK_FILE_TIMEOUT),
		'process_id' => ($_[5] ne '' ? $_[5] : $$),
	);
	
	# 変数の初期化
	my $lock_file_name = $lock_file_hash{'dir'} . '/' . $lock_file_hash{'name'};
	my $lock_exec_flg = 0;
	
	# ロックする
	if ($lock_flg eq 'ON') {
		# ファイルの作成日時を確認し、規定日時を超えているようなら削除する
		if ((-M $lock_file_name) * 86400 > $lock_file_hash{'timeout'}) {
			fileLock('OFF', $lock_file_hash{'dir'}, $lock_file_hash{'name'}, $lock_file_hash{'retry'}, $lock_file_hash{'timeout'}, '-');
		}
		# リトライ回数分ループ
		foreach (1..$lock_file_hash{'retry'}) {
			# ファイルが生成できない場合 
			if (!sysopen(FH, $lock_file_name, O_WRONLY| O_CREAT| O_EXCL)) {
				sleep($main::DEFAULT_LOCK_FILE_WAITTIME);
			}
			else {
				print (FH $lock_file_hash{'process_id'});
				$lock_exec_flg = 1;
				last;
			}
		}		
		# ロックファイルの作成に失敗した場合
		if ($lock_exec_flg == 0) {
			return 0;
		}
		close(FH);
		
		# シグナルハンドラをセット
		$SIG{HUP} = $SIG{INT} = $SIG{PIPE} = $SIG{QUIT} =$SIG{TERM} = \fileLock('OFF', $lock_file_hash{'dir'}, $lock_file_hash{'name'}, $lock_file_hash{'retry'}, $lock_file_hash{'timeout'}, $lock_file_hash{'process_id'});
	}
	# ロック解除
	else {
		# ファイルの存在をチェック
		if (-e $lock_file_name) {
			my $delete_flg = 0;
			# プロセスIDがある場合であり
			if ($lock_file_hash{'process_id'} ne '-' && sysopen(FH, $lock_file_name, O_READ)) {
				my @str = <FH>;
				if ($str[0] eq $lock_file_hash{'process_id'}) {
					$delete_flg = 1;
				}
				close(FH);
			}
			else {
				$delete_flg = 1;
			}
			# 削除フラグがONの場合は削除
			if ($delete_flg == 1) {
				unless (unlink($lock_file_name)) {
					return 0;
				}
				$SIG{HUP} = $SIG{INT} = $SIG{PIPE} = $SIG{QUIT} = $SIG{TERM} = '';
			}
		}
	}
	return 1;
}


#==============================================================================
# 指定したフォルダ内のある期間を過ぎたファイルを削除する
# (時間の長い一時的にアップロードされた画像を削除する)
#	【引数】]
# 			$dir_path	対象のディレクトリ
# 			$expires	保留期間(分)
#	【戻値】
#			0/1		失敗/成功
#==============================================================================
sub deleteOldFiles {
	my ($dir_path , $expires) = @_;
	
	# パラメータを取得する
	my ( $dir_path ) = @_;
	$dir_path =~ s/\/$//g;
	
	# 対象ディレクトリからファイルリストを取得する
	opendir(THIS, $dir_path);
	my @all = grep(!/^\./, readdir(THIS));
	closedir(THIS);
	
	# ファイル数分ループ
	foreach $file_name (@all) {
		my $file_path = $dir_path . '/' . $file_name;
		
		# 最後に修正(modify)された時刻から保留期間を超えたファイルを全て削除する
		if ((time-(stat $file_path)[9]) > $expires * 60) { 
			unless (unlink($file_path)) {
				return 0;
			}
		}
	}
	
	return 1;
}

#==============================================================================
#	緊急情報配信機能 ページ一覧取得（JSON)
#
#	【戻値】JSON形式でページの一覧
#
#==============================================================================
sub getlist {

	#==============================================================================
	# 共通パッケージの読み込み
	#==============================================================================
	use Data::Dumper;

	#==============================================================================
	#　プログラム開始
	#==============================================================================
	# -----------------------------------------
	# HTMLページファイルの作成ディレクトリから、ファイルリストを取得する
	# -----------------------------------------
	# Data::Dumperのオプションを設定する
	local $Data::Dumper::Indent = 1;	# インデントあり
	local $Data::Dumper::Useqq = 1;	# ハッシュのキーはダブルクォートでくくる
	local $Data::Dumper::Terse = 1;	# evalするための、最初の「$VAR =」は不要
	local $Data::Dumper::Pair = ":";	# ハッシュの区切り文字
	# qquoteを上書き
	{
		no warnings 'redefine';
		sub Data::Dumper::qquote {
			local($_) = shift;
			s/([\\\"])/\\$1/g;	# 記号関係をエスケープ。

			# タブや改行などをメタ文字に置き換え
			my %esc = (
				"\a" => '\a',
				"\b" => '\b',
				"\t" => '\t',
				"\n" => '\n',
				"\f" => '\f',
				"\r" => '\r',
				"\e" => '\e',
				"\$" => '&#36;',
				"\@" => '&#64;',
			);
			s/([\a\b\t\n\f\r\e\$\@])/$esc{$1}/g;

			return qq|"$_"|;	# 結果をダブルクオートでくくって返す
		}
	}

	# ページリストを取得
	my @file_list_ary = &getFileList($main::CONST_URGENCY_HTTP_DIR_PATH, $main::CONST_URGENCY_HTTP_PUB_DIR);
	my $count = @file_list_ary;
	my $json = Dumper({'count' => $count, 'html' => [@file_list_ary]});
	# 出来上がったデータを返す
	return $json;
}

1;
