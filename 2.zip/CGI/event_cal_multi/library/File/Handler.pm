#==============================================================================
# ファイル操作用クラス
#   ファイルを操作する際に使用する共通処理を記述する
#==============================================================================

#==============================================================================
# パッケージの宣言
#==============================================================================
package File::Handler;

#==============================================================================
# 共通パッケージの読み込み
#==============================================================================
# 「strict」プラグマを使用
use strict;
# 「warnings」プラグマを使用
use warnings;
no warnings qw (once);
# 「Data::Dumper」モジュールを指定
use Data::Dumper;
# 「Fcntl」モジュールを指定
use Fcntl;
# 「File::Basename」モジュールを指定
use File::Basename;
# 「File::Path」モジュールを指定
use File::Path;
#==============================================================================
# プログラム開始時に実行
#==============================================================================
BEGIN {
	# Dumperを日本語対応にする考慮
	# ※Perl標準機能のDumperをjson出力用として利用するための考慮
	no warnings 'redefine';
	sub Data::Dumper::qquote {
		local($_) = shift;
		# 記号関係をエスケープ
		s/([\\\"\@])/\\$1/g;
		# タブや改行などをメタ文字に置き換え
		my %esc = (
			"\a" => '\a',
			"\b" => '\b',
			"\t" => '\t',
			"\n" => '\n',
			"\f" => '\f',
			"\r" => '\r',
			"\e" => '\e',
			"\$" => '&#36;',
		);
		s/([\a\b\t\n\f\r\e\$])/$esc{$1}/g;
		# 結果をダブルクオートでくくって返す
		return qq|"$_"|;
	}
};

#==============================================================================
# コンストラクタ
#	【引数】
#			なし
#	【戻値】
#			自身のクラスのリファレンスを返す
#	【備考】
#			なし
#==============================================================================
sub new {
	# 引数の取得
	my $class = shift;
	my (%self) = @_;
	
	# クラスをリファレンスと紐づけて返す
	return bless \%self, $class;
}

#==============================================================================
# 外部ライブラリ等の環境不備チェック処理
#	【引数】
#			なし
#	【戻値】
#			hash エラー情報ハッシュ配列を返す
#	【備考】
#==============================================================================
sub checkEnvironmentStatus {
	# 引数の取得
	my $self = shift;
	# 変数の宣言
	my $package_name = __PACKAGE__;
	my %status;
	
	# 戻り値を返す
	return %status;
}

#==============================================================================
# ファイル作成処理（Json形式で保存）
#	【引数】
#			string $tmp_file_path 一時ファイルパス（フルパス）
#			string $save_file_path 保存パス（フルパス）
#			mixed 保存したいデータまたは配列のreference
#	【戻値】
#			正常に保存できた場合 : 1（TRUE）
#			正常に保存できなかった場合 : 空(undef)を返す（FALSE）
#	【備考】
#==============================================================================
sub createJsonFile {
	# 引数の取得
	my $self = shift;
	my ($tmp_file_path, $save_file_path, $hash_obj_ref) = @_;
	# 変数の宣言
	my $fh;
	#ディレクトリがなければつくる
	my $tmp_file_dir = dirname($tmp_file_path);
	my $save_file_dir = dirname ($save_file_path);
	if (! -d $tmp_file_dir) {
		mkpath($tmp_file_dir);
		chmod 0777,$tmp_file_dir;
	}
	if (! -d $save_file_dir) {
		mkpath($save_file_dir);
		chmod 0777,$save_file_dir;
	}
	
	# ファイルの保存処理
	if (!sysopen($fh, $tmp_file_path, O_WRONLY | O_CREAT | O_EXCL, 0777)) {
		return;
	}
	# ハッシュのキーをソートする
	local $Data::Dumper::Sortkeys = 1;
	# インデントなし
	local $Data::Dumper::Indent = 0;
  	# ハッシュのキーはダブルクォートでくくる
  	local $Data::Dumper::Useqq = 1;
  	# evalするための、最初の「$VAR =」は不要
  	local $Data::Dumper::Terse = 1;
  	# ハッシュの区切り文字
 	local $Data::Dumper::Pair = ': ';

	# 書込み
	print($fh Dumper($hash_obj_ref));
	# ファイルクローズ
	close($fh);
	# 一時保存ファイルのリネーム
	if (!rename($tmp_file_path, $save_file_path)) {
		if (-e $tmp_file_path) {
			unlink($tmp_file_path);
		}
		return;
	}
	# 戻り値を返す
	return 1;
}

#==============================================================================
# ファイル読み込み処理（Json形式のファイルを読み込む）
#	【引数】
#			string $read_file_path 読み込みパス（フルパス）
#	【戻値】
#			正常に読み込みできた場合 : mixed 読み込んだデータまたは配列のreferenceを返す
#			正常に読み込みできなかった場合 : 空(undef)を返す（FALSE）
#	【備考】
#==============================================================================
sub readJsonFile {
	# 引数の取得
	my $self = shift;
	my ($read_file_path) = @_;
	# 変数の宣言
	my $VAR1;
	my $fh;
	
	# ファイルを読み込む
	if (!sysopen($fh, $read_file_path, O_RDONLY)) {
		return;
	}
	my @data = <$fh>;
	# ファイルクローズ
	close($fh);
	# 戻り値を返す
	return join('', @data);
}

#==============================================================================
# objectをjson化する
#	【引数】
#			object $object json化対象のオブジェクト(リファレンス渡し)
#	【戻値】
#			string json文字列
#	【備考】
#			外部ライブラリを極力避けるため perl標準の Data::Dumperを利用
#==============================================================================
sub convertObjectToJson {
	# 引数の取得
	my $self = shift;
	my ($object) = @_;
	
	# インデントなし
	local $Data::Dumper::Indent = 1;
	# ハッシュのキーはダブルクォートでくくる
	local $Data::Dumper::Useqq = 1;
	# evalするための、最初の「$VAR =」は不要
	local $Data::Dumper::Terse = 1;
	# ハッシュの区切り文字
	local $Data::Dumper::Pair = ': ';
	# json文字列を作成
	my $json = Dumper($object);
	$json =~ s/:\s*undef/: null/g;
	# 戻り値を返す
	return $json;
}
1;
