#==============================================================================
# ファイル取得用クラス
#   取得したファイルをキャッシュファイルとして使用する共通処理を記述する
#==============================================================================

#==============================================================================
# パッケージの宣言
#==============================================================================
package GetFileToCache;

#==============================================================================
# 共通パッケージの読み込み
#==============================================================================
use strict;
use Data::Dumper;

#==============================================================================
# クラスを継承する
#==============================================================================
use base qw(File::Handler);

#==============================================================================
# プログラム開始時に実行
#==============================================================================
BEGIN {
	our $USE_FILEHANDLER = 1;
	# ファイル処理用パッケージ
	eval('use File::Handler;');
	if ($@) {
		$USE_FILEHANDLER = 0;
	};
};

#==============================================================================
# コンストラクタ
#	【引数】
#			なし
#	【戻値】
#			自身のクラスのリファレンスを返す
#	【備考】
#			なし
#==============================================================================
sub new {
	# 引数の取得
	my $class = shift;
	my (%this) = @_;
	
	# クラスをリファレンスと紐づけて返す
	return bless(\%this, $class);
}

#==============================================================================
# 外部ライブラリ等の環境不備チェック処理
#	【引数】
#			なし
#	【戻値】
#			hash エラー情報ハッシュ配列を返す
#	【備考】
#			なし
#==============================================================================
sub checkEnvironmentStatus {
	# 引数の取得
	my $this = shift;
	# 変数の宣言
	my %status;
	my $package_name = __PACKAGE__;
	
	# 「File::Handler.pm」読み込みエラー
	if ($GetFileToCache::USE_FILEHANDLER == 0) {
		my %err_hash = (
			'code' => -1001,
			'msg' => 'File::Handler loaded error.',
		);
		push(@{$status{$package_name}}, \%err_hash);
	}
	# 「File::Handler.pm」のエラー
	%status = (%status, $this->File::Handler::checkEnvironmentStatus());
	
	# 戻り値を返す
	return %status;
}

#==============================================================================
# 不要な一時ファイルの削除処理
#	【引数】
#			string $check_path チェック対象ファイルパス（「glob」関数による検索）
#			int $enabled_time ファイル有効時間（秒）
#	【戻値】
#			int 削除結果コード（0:エラー 1:全ファイル削除完了 2:作成中の一時ファイルあり）
#	【備考】
#			なし
#==============================================================================
sub deleteTmpCacheFiles {
	# 引数の取得
	my $this = shift;
	my ($check_path, $enabled_time) = @_;
	my $return_code = 0;
	
	# ファイルリストを取得
	my @tmp_file_ary = $this->checkEnabledFiles($check_path, $enabled_time);
	# 一時ファイルが存在する場合
	if (@tmp_file_ary != 0) {
		# ファイル数分ループ
		my $del_cnt = 0;
		foreach my $tmp_file_hash (@tmp_file_ary) {
			# ファイルが無効の場合は削除
			if (${$tmp_file_hash}{'file_enable_flg'} == 0) {
				if (!unlink(${$tmp_file_hash}{'file_path'})) {
					return 0;
				}
				$del_cnt++;
			}
		}
		# 一時ファイルを全て削除した場合
		if ($del_cnt == @tmp_file_ary) {
			$return_code = 1;
		}
		# すべてを削除しなかった（作成中の一時ファイルが存在した）場合
		else {
			$return_code = 2;
		}
	}
	# 一時ファイルが存在しない場合
	else {
		$return_code = 1;
	}
	# 戻り値を返す
	return $return_code;
}

#==============================================================================
# キャッシュファイルの存在および有効性のチェック処理
#	【引数】
#			string $check_path チェック対象ファイルパス（「glob」関数による検索）
#			int $enabled_time ファイル有効時間（秒）
#	【戻値】
#			有効なファイルがあった場合 : int 1（TRUE）
#			有効なファイルが無かった場合： int 0（FALSE）
#	【備考】
#			なし
#==============================================================================
sub checkCacheFile {
	# 引数の取得
	my $this = shift;
	my ($check_path, $enabled_time) = @_;
	my $return_code = 1;
	
	# ファイルリストを取得
	my @save_file_ary = $this->checkEnabledFiles($check_path, $enabled_time);
	# 既に作成されている解析済みファイルがある場合
	if (@save_file_ary != 0) {
		# ファイルが無効の場合は再生成する
		if ($save_file_ary[0]{'file_enable_flg'} == 0) {
			$return_code = 0;
		}
	}
	# 解析済みファイルが存在しない場合（初回時）は生成する
	else {
		$return_code = 0;
	}
	# 戻り値を返す
	return $return_code;
}

#==============================================================================
# ファイル有効チェック処理（有効期間内に作成されたファイルかチェック）
#	【引数】
#			string $check_path チェック対象ファイルパス（「glob」関数による検索）
#			int $enabled_time ファイル有効時間（秒）
#	【戻値】
#			array ファイルパスおよび有効フラグを設定したハッシュ配列
#	【備考】
#			なし
#==============================================================================
sub checkEnabledFiles {
	# 引数の取得
	my $this = shift;
	my ($check_path, $enabled_time) = @_;
	# 変数の宣言
	my @file_enable_flg_ary = ();
	# 現在時間を取得
	my $now_time = time;
	
	# 確認対象のファイルがある場合
	my @file_list_ary = glob($check_path);
	if (@file_list_ary != 0) {
		# ファイルの数分ループ
		foreach my $file_path (@file_list_ary) {
			# ファイルが実際には存在しない場合
			if (!-f $file_path) {
				next;
			}
			# 配列の要素数を取得
			my $num = @file_enable_flg_ary;
			# ファイル情報を取得
			my @file_info_ary = stat($file_path);
			# ファイルの更新日時を取得
			my $file_time = $file_info_ary[9];
			# ファイル名を設定する
			$file_enable_flg_ary[$num]{'file_path'} = $file_path;
			# 指定時間以内に更新したファイルの場合
			if ($now_time < ($file_time + $enabled_time)) {
				# ファイルを有効として設定する
				$file_enable_flg_ary[$num]{'file_enable_flg'} = 1;
			}
			# 当日更新したファイルでない場合
			else {
				# ファイルを有効時間切れとして設定する
				$file_enable_flg_ary[$num]{'file_enable_flg'} = 0;
			}
		}
	}
	# 戻り値を返す
	return @file_enable_flg_ary;
}

#==============================================================================
# ファイル有効チェック処理（当日作成されたファイルかチェック）
#	【引数】
#			string $check_path チェック対象ファイルパス（「glob」関数による検索）
#	【戻値】
#			array ファイルパスおよび有効フラグを設定したハッシュ配列
#	【備考】
#==============================================================================
sub checkEnabledFilesToday {
	# 引数の取得
	my $this = shift;
	my ($check_path) = @_;
	# 変数の宣言
	my @file_enable_flg_ary = ();
	# 現在時間を取得
	my ($now_sec, $now_min, $now_hour, $now_day, $now_month, $now_year) = localtime(time);
	
	# 確認対象のファイルがある場合
	my @file_list_ary = glob($check_path);
	if (@file_list_ary != 0) {
		# ファイルの数分ループ
		foreach my $file_path (@file_list_ary) {
			# ファイルが実際には存在しない場合
			if (!-f $file_path) {
				next;
			}
			# 配列の要素数を取得
			my $num = @file_enable_flg_ary;
			# ファイル情報を取得
			my @file_info_ary = stat($file_path);
			# ファイルの更新日時を取得
			my ($update_sec, $update_min, $update_hour, $update_day, $update_month, $update_year) = localtime($file_info_ary[9]);
			# ファイル名を設定する
			$file_enable_flg_ary[$num]{'file_path'} = $file_path;
			# 当日更新したファイルの場合
			if ($now_day == $update_day && $now_month == $update_month && $now_year == $update_year) {
				# ファイルを有効として設定する
				$file_enable_flg_ary[$num]{'file_enable_flg'} = 1;
			}
			# 当日更新したファイルでない場合
			else {
				# ファイルを有効時間切れとして設定する
				$file_enable_flg_ary[$num]{'file_enable_flg'} = 0;
			}
		}
	}
	# 戻り値を返す
	return @file_enable_flg_ary;
}

1;
