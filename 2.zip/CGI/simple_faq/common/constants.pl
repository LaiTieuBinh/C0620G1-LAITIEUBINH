# 簡易版FAQ用 問い合わせフォーム

#------------------------------------------------------------------------------
#---環境によっては古い Jcode.pm が使用されているためCGI付属のJcode.pmを使用
#------------------------------------------------------------------------------
	require $P_PrevApplicationRoot."/Jcode.pm";
	Jcode->import();

#------------------------------------------------------------------------------
#	モジュール
#------------------------------------------------------------------------------
	
	# 共通で使用するモジュール use ～
	# use strict;
	# use warnings;
	
	# 使用しないモジュール no ～
	# no strict;
	# no warnings;
	
#------------------------------------------------------------------------------
#	定数
#------------------------------------------------------------------------------
	
	# OS
	our $P_OS_LINUX = "/";    # Linux
	our $P_OS_WINDOWS = "\\"; # Windows
	
	#--- 改行コード
	our $BR_CODE      = '<br />';
	
	#--- HTTPルート置き換え用
	our $HTTP_ROOT    = '#%HTTP_ROOT%#';
	
	#--- FORM部分
	our $INNER_FORM   = '#%FORM%#';
	
	#--- エラー置き換え
	our $ERROR_MSG    = '#%ERROR_MSG%#';
	
	#--- 隠し項目（hidden）置き換え
	our $INNER_HIDDEN = '#%HIDDEN%#';
	
	# -- 宛先となるメールアドレス
	our $DEPT = 'dept';
	
	# -- このページのURL
	our $PAGE = 'page';
	
	# -- プルダウン初期値
	our $PULLDOWN_BASE = '選択してください';
	
	# -- 必須表示
	our $NEED_MESSAGE  = '<strong style="color:#990000;">(必須)</strong>';
	
	#--- 宛先となるメールアドレス登録カラム
	our $DEPT_CLM   = 'charge';
	
	#--- ページのURL
	our $PAGE_CLM   = 'referrer_url';
	
	#--- 値を比較する項目
	our @COMPARE = ();
	
	# メールの改行文字数
	our $MAIL_ENTER = 400;
	
	# 自動返信機能使用フラグ
	our $RETURN_MAIL = 'ENQ_RETURN_MAIL_SEND_FLG';
	
	# 公開側SSLフラグ
	our $PUBLISH_SSL_FLG = 'publish_ssl_flg';
	
#---end------------------------------------------------------------------------
1;
