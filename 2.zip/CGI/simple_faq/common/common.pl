#==================================================================================================#
# 共通関数ファイル                                                                                 #
#==================================================================================================#

#==============================================================================
#	機種依存文字をチェック
#
# 【引数】	チェックする文字列
#
# 【戻値】	0	機種依存文字がない場合
#			1	機種依存文字が含まれる場合
#
#==============================================================================
sub pdc_chk {

	# ** 引数を変数に代入 ** #
	# チェックする文字
	@_chk_Str = @_;

	# 機種依存文字
	@_pdc_Str = (
		#半角片仮名
		"｡" , "｢" , "｣" , "､" , "･" , "ｦ" ,
		"ｧ" , "ｨ" , "ｩ" , "ｪ" , "ｫ" , "ｬ" ,
		"ｭ" , "ｮ" , "ｯ" , "ｰ" , "ｱ" , "ｲ" ,
		"ｳ" , "ｴ" , "ｵ" , "ｶ" , "ｷ" , "ｸ" ,
		"ｹ" , "ｺ" , "ｻ" , "ｼ" , "ｽ" , "ｾ" ,
		"ｿ" , "ﾀ" , "ﾁ" , "ﾂ" , "ﾃ" , "ﾄ" ,
		"ﾅ" , "ﾆ" , "ﾇ" , "ﾈ" , "ﾉ" , "ﾊ" ,
		"ﾋ" , "ﾌ" , "ﾍ" , "ﾎ" , "ﾏ" , "ﾐ" ,
		"ﾑ" , "ﾒ" , "ﾓ" , "ﾔ" , "ﾕ" , "ﾖ" ,
		"ﾗ" , "ﾘ" , "ﾙ" , "ﾚ" , "ﾛ" , "ﾜ" ,
		"ﾝ" , "ﾞ" , "ﾟ" ,
		#Windowsの機種依存文字
		"①" , "②" , "③" , "④" , "⑤" , "⑥" ,
		"⑦" , "⑧" , "⑨" , "⑩" , "⑪" , "⑫" ,
		"⑬" , "⑭" , "⑮" , "⑯" , "⑰" , "⑱" ,
		"⑲" , "⑳" , 

		"㍉" , "㌔" , "㌢" , "㍍" , "㌘" , "㌧" ,
		"㌃" , "㌶" , "㍑" , "㍗" , "㌍" , "㌦" ,
		"㌣" , "㌫" , "㍊" , "㌻" , "㎜" , "㎝" ,
		"㎞" , "㎎" , "㎏" , "㏄" , "㎡" , "㍻" ,
		"〝" , "〟" , "№" , "㏍" , "℡" , "㊤" ,
		"㊥" , "㊦" , "㊧" , "㊨" , "㈱" , "㈲" ,
		"㈹" , "㍾" , "㍽" , "㍼" , "≒" , "≡" ,
		"∫" , "∮" , "∑" , "√" , "⊥" , "∠" ,
		"∟" , "⊿" , "∵" , "∩" , "∪" ,
		#NECのIBM拡張文字
		       "褜" , "鍈" , "銈" , "蓜" , "俉" ,
		"炻" , "昱" , "棈" , "鋹" , "曻" , "彅" ,
		"丨" , "仡" , "仼" , "伀" , "伃" , "伹" ,
		"佖" , "侒" , "侊" , "侚" , "侔" , "俍" ,
		"偀" , "倢" , "俿" , "倞" , "偆" , "偰" ,
		"偂" , "傔" , "僴" , "僘" , "兊" , "兤" ,
		"冝" , "冾" , "凬" , "刕" , "劜" , "劦" ,
		"勀" , "勛" , "匀" , "匇" , "匤" , "卲" ,
		"厓" , "厲" , "叝" , "﨎" , "咜" , "咊" ,
		"咩" , "哿" , "喆" , "坙" , "坥" , "垬" ,
		"埈" , "埇" , "﨏" , "塚" , "增" , "墲" ,
		"夋" , "奓" , "奛" , "奝" , "奣" , "妤" ,
		"妺" , "孖" , "寀" , "甯" , "寘" , "寬" ,
		"尞" , "岦" , "岺" , "峵" , "崧" , "嵓" ,
		"﨑" , "嵂" , "嵭" , "嶸" , "嶹" , "巐" ,
		"弡" , "弴" , "彧" , "德" ,
		"忞" , "恝" , "悅" , "悊" , "惞" , "惕" ,
		"愠" , "惲" , "愑" , "愷" , "愰" , "憘" ,
		"戓" , "抦" , "揵" , "摠" , "撝" , "擎" ,
		"敎" , "昀" , "昕" , "昻" , "昉" , "昮" ,
		"昞" , "昤" , "晥" , "晗" , "晙" , "晴" ,
		"晳" , "暙" , "暠" , "暲" , "暿" , "曺" ,
		"朎" , "朗" , "杦" , "枻" , "桒" , "柀" ,
		"栁" , "桄" , "棏" , "﨓" , "楨" , "﨔" ,
		"榘" , "槢" , "樰" , "橫" , "橆" , "橳" ,
		"橾" , "櫢" , "櫤" , "毖" , "氿" , "汜" ,
		"沆" , "汯" , "泚" , "洄" , "涇" , "浯" ,
		"涖" , "涬" , "淏" , "淸" , "淲" , "淼" ,
		"渹" , "湜" , "渧" , "渼" , "溿" , "澈" ,
		"澵" , "濵" , "瀅" , "瀇" , "瀨" , "炅" ,
		"炫" , "焏" , "焄" , "煜" , "煆" , "煇" ,
		"凞" , "燁" , "燾" , "犱" ,
		       "猤" , "猪" , "獷" , "玽" , "珉" ,
		"珖" , "珣" , "珒" , "琇" , "珵" , "琦" ,
		"琪" , "琩" , "琮" , "瑢" , "璉" , "璟" ,
		"甁" , "畯" , "皂" , "皜" , "皞" , "皛" ,
		"皦" , "益" , "睆" , "劯" , "砡" , "硎" ,
		"硤" , "硺" , "礰" , "礼" , "神" , "祥" ,
		"禔" , "福" , "禛" , "竑" , "竧" , "靖" ,
		"竫" , "箞" , "精" , "絈" , "絜" , "綷" ,
		"綠" , "緖" , "繒" , "罇" , "羡" , "羽" ,
		"茁" , "荢" , "荿" , "菇" , "菶" , "葈" ,
		"蒴" , "蕓" , "蕙" , "蕫" , "﨟" , "薰" ,
		"蘒" , "﨡" , "蠇" , "裵" , "訒" , "訷" ,
		"詹" , "誧" , "誾" , "諟" , "諸" , "諶" ,
		"譓" , "譿" , "賰" , "賴" , "贒" , "赶" ,
		"﨣" , "軏" , "﨤" , "逸" , "遧" , "郞" ,
		"都" , "鄕" , "鄧" , "釚" ,
		"釗" , "釞" , "釭" , "釮" , "釤" , "釥" ,
		"鈆" , "鈐" , "鈊" , "鈺" , "鉀" , "鈼" ,
		"鉎" , "鉙" , "鉑" , "鈹" , "鉧" , "銧" ,
		"鉷" , "鉸" , "鋧" , "鋗" , "鋙" , "鋐" ,
		"﨧" , "鋕" , "鋠" , "鋓" , "錥" , "錡" ,
		"鋻" , "﨨" , "錞" , "鋿" , "錝" , "錂" ,
		"鍰" , "鍗" , "鎤" , "鏆" , "鏞" , "鏸" ,
		"鐱" , "鑅" , "鑈" , "閒" , "隆" , "﨩" ,
		"隝" , "隯" , "霳" , "霻" , "靃" , "靍" ,
		"靏" , "靑" , "靕" , "顗" , "顥" , "飯" ,
		"飼" , "餧" , "館" , "馞" , "驎" , "髙" ,
		"髜" , "魵" , "魲" , "鮏" , "鮱" , "鮻" ,
		"鰀" , "鵰" , "鵫" , "鶴" , "鸙" , "黑" ,
		"ⅰ" , "ⅱ" , "ⅲ" , "ⅳ" , "ⅴ" , "ⅵ" ,
		"ⅶ" , "ⅷ" , "ⅸ" , "ⅹ" , "￢" , "￤" ,
		"＇" , "＂" ,

		#Shift_JIS 非対応記号 -----------------------------------------------------

		#Windowsの機種依存文字
		"Ⅰ" , "Ⅱ" , "Ⅲ" , "Ⅳ" , "Ⅴ" , "Ⅵ" , "Ⅶ" , "Ⅷ" , "Ⅸ" , "Ⅹ" ,
		#NECのIBM拡張文字
		"纊" , "犾" ,
		#その他
		"ℓ" , "®" ,"㎥" , "㎠" , "㎤" , "㎖" , "㏔" , "㎢" , "㎳" ,
	);

	# 機種依存文字のチェック
	for ($_i = 0 ; $_i < $#_pdc_Str+1 ; $_i ++ ) {
		for ($_j = 0 ; $_j < $#_chk_Str+1 ; $_j ++) {
			if ( $_chk_Str[$_j] =~ /$_pdc_Str[$_i]/ ) {
				# 機種依存文字が存在していれば 1
				return 1;
			}
		}
	}

	# 機種依存文字が存在していなければ 0
	return 0;

}

#==================================================================================================#
# メールアドレス形式チェック                                                                       #
#==================================================================================================#
sub mailInputChk {

	local ( $str ) = @_;

	# メールフォーマットチェック
	if ( $str ne "" ){
		if ( $str !~ /^([a-zA-Z0-9\.\-\/_\!\#\$\%\&\'\*\+\=\?\^\`\{\|\}\~\(\)\ \[\]\\\<\>\@\:\;\,]{1,})@([a-zA-Z0-9\.\-\/_]{1,})\.([a-zA-Z0-9\.\-\/_]{1,})$/ ) {
			return 1;
		}
	}
	return 0;
}

#==================================================================================================#
# 数字orハイフンチェック                                                                           #
#==================================================================================================#
sub numericInputChk {

	local ( $str ) = @_;

	# 数字orハイフンチェック
	if ( $str ne "" ){
		if ( $str !~ /^([\d\-]+)$/ ) {
			return 1;
		}
	}

	return 0;
}

#==============================================================================
#	ロックファイル作成
#
#	【引数】ファイルロック	"ON" or "OFF"
#			ロックファイル名
#
#	【戻値】n	何らかの理由で失敗をした
#			0	正常終了
#
#==============================================================================
sub file_lock
{

	#---ロックファイル名
	$strLookFnm = $_[1];

	$err_flg = 0;

	if($_[0] eq 'ON'){
		$flg = 0;
		foreach(1 .. 5){
			if(-e $strLookFnm){sleep(1);}
			else{
				if(!open(LOCK,">$strLookFnm")){
					$err_flg = 1;		#作成不可
					last;
				}
				close(LOCK);
				chmod 0777, $strLookFnm;
				$flg = 1;
				last;
			}
		}
		if(!$flg){
			$err_flg = 2;	#タイムオーバー
		}
	}
	else{
		if(-e $strLookFnm){
			unlink($strLookFnm);
		}
	}
	
	return $err_flg;
}

#==============================================================================
#	タグの無効化
#
#	【引数】無効化を行なう文字列
#
#	【戻値】タグが無効化された文字列
#
#	【備考】< > & " ' をそれぞれ文字列に変換する
#
#	【作成】06/11/09 表示文字、入力文字のタグを無効にするため
#
#==============================================================================
sub html_escapr
{
	local( $InStr ) = @_;

	$InStr =~ s/&/&amp;/g;		#& → &amp;
	$InStr =~ s/</&lt;/ig;		#< → &lt;
	$InStr =~ s/>/&gt;/ig;		#> → &gt;
	$InStr =~ s/"/&quot;/g;		#" → &quot;
	$InStr =~ s/'/&#39;/g;		#' → &#39;
	$InStr =~ s/\0/,/g;

	return $InStr;
}

#==============================================================================
#	改行コードのHTMLタグ化 \n → <BR>
#
#	【引数】タグ化を行なう文字列
#
#	【戻値】タグが無効化された文字列
#
#	【備考】改行コードを<BR>に変換する
#
#	【作成】06/11/09 表示文字、入力文字のタグを無効にするため
#
#==============================================================================
sub html_escapr_ret
{
	local( $InStr ) = @_;

	$InStr =~ s/\r\n/\n/g;
	$InStr =~ s/\r/\n/g;
	$InStr =~ s/\n/$BR_CODE/ig;

	return $InStr;

}

#==============================================================================
#	PHPの in_array
#
#	【引数】@_[1] チェックしたい文字
#			@_[2] 配列へのリファレンス
#
#	【戻値】1 有り | 0 なし
#
#==============================================================================
sub in_array
{
	my ( $val, $array_ref ) = @_;
	
	foreach my $elem( @$array_ref ) {
		if ( $val=~m/^[0-9]+$/ ){
			if ( $val == $elem ) { return 1; }
		}
		else{
			if ( $val eq $elem ) { return 1; }
		}
	}
	return 0;
}

# CSVの読み込み
sub csvStrCut
{
	# CSV 文字列( 1行 )
	local ( $_csvStr ) = @_;
	@_ret = ();

	$_csvStr =~ s/\r\n/\n/g;
	$_csvStr =~ s/\r/\n/g;

	while( $_csvStr =~ s/".*?"[\n,]// ) {
		$_sub = $&;
		$_sub =~ s/^"//;
		$_sub =~ s/"[\n,]$//;
		push( @_ret, $_sub );
	}

	return @_ret;
}

#==============================================================================
#	<input><textarea>などのインプットフォームの作成
#
#	【引数】連想配列
#		{'input'}  = text | textarea | radio | select | checkbox
#		{'label'}  = 項目名
#		{'name'}   = name値
#		{'need'}   = 必須フラグ
#		{'value'}  = value値
#       {'select'} = text : size | textarea : [0]cols [1]rows | else 選択項目
#		{'confirm'}= 確認画面用表示フラグ ( TRUE | FALSE )
#
#	【戻値】作成されたエリアのHTML文字列
#
#==============================================================================
sub formCreate
{

	local $_formInput = shift;
	local @_formStr = @_;
	local $_ret    = '';
	local $_label  = '';
	local $_input  = '';
	local $_hidden = '';
	local $_need   = '';

	# 文字列のエスケープ
	$$_formInput{'input'} = &html_escapr( $$_formInput{'input'} );
	$$_formInput{'name'}  = &html_escapr( $$_formInput{'name'} );
	$$_formInput{'label'} = &html_escapr( $$_formInput{'label'} );
	$$_formInput{'value'} = &html_escapr( &trim( $$_formInput{'value'} ) );

	# 確認フラグ代入
	local $_confirm = $$_formInput{'confirm'};

	if ( $$_formInput{'input'} eq "text" ) {
		# ** テキストボックス
		# -- ラベル(項目名)
		$_label  = '<label for="' . $$_formInput{'name'} . '">' . $$_formInput{'label'} . '</label>';
		# -- フォーム内容
		if ( $_confirm eq FALSE ) {
			$_input  = '<input type="text" id="' . $$_formInput{'name'} . '" name="' . $$_formInput{'name'} . '" value="' . $$_formInput{'value'} . '" size="' . $$_formInput{'select'} . '" />';
		} else {
			$_input  = $$_formInput{'value'};
			$_hidden = '<input type="hidden" name="' . $$_formInput{'name'} . '" value="' . $$_formInput{'value'} . '" />';
		}
	} elsif ( $$_formInput{'input'} eq "textarea" ) {
		# ** テキストボックス
		# -- 縦横指定を , で分割
		local @_widhgt = split(/,/, $$_formInput{'select'} );
		# -- ラベル(項目名)
		$_label  = '<label for="' . $$_formInput{'name'} . '">' . $$_formInput{'label'} . '</label>';
		# -- フォーム内容
		if ( $_confirm eq FALSE ) {
			$_input  = '<textarea id="' . $$_formInput{'name'} . '" name="' . $$_formInput{'name'} . '" cols="' . @_widhgt[0] . '" rows="' . @_widhgt[1] . '">' . $$_formInput{'value'} . '</textarea>';
		} else {
			$_hidden = '<input type="hidden" name="' . $$_formInput{'name'} . '" value="' . $$_formInput{'value'} . '" />';
			$$_formInput{'value'} = &html_escapr_ret($$_formInput{'value'});
			$_input  = $$_formInput{'value'};
		}
	} elsif ( $$_formInput{'input'} eq "radio" ) {
		# ** ラジオボタン
		# -- 選択項目を , で分割
		local @_select = split(/,/, $$_formInput{'select'} );
		# -- ラベル(項目名)
		$_label  = $$_formInput{'label'};
		# -- フォーム内容
		if ( $_confirm eq FALSE ) {
			# 要素をfieldsetタグで囲む
			$_input .= '<fieldset>';
			$_input .= '<legend style="display: none;">選択肢</legend>';
			for ( $_i = 0 ; $_i < @_select ; $_i ++ ) {
				$_input .= '<input type="radio" id="' . $$_formInput{'name'} . "_" . $_i . '" name="' . $$_formInput{'name'} . '" value="' . $_select[$_i] . '"';
				if ( $_select[$_i] eq $$_formInput{'value'} ) { $_input .= ' checked'; }
				$_input .= ' />';
				$_input .= '&nbsp;<label for="' . $$_formInput{'name'} . "_" . $_i . '">' . $_select[$_i] . '</label>';
			}
			# 要素をfieldsetタグで囲む
			$_input .= '</fieldset>';
		} else {
			$_input  = $$_formInput{'value'};
			$_hidden = '<input type="hidden" name="' . $$_formInput{'name'} . '" value="' . $$_formInput{'value'} . '" />';
		}
	} elsif ( $$_formInput{'input'} eq "select" ) {
		# ** プルダウン
		# -- 選択項目を , で分割
		local @_select = split(/,/, $$_formInput{'select'} );
		# -- ラベル(項目名)
		$_label  = '<label for="' . $$_formInput{'name'} . '">' . $$_formInput{'label'} . '</label>';
		# -- フォーム内容
		if ( $_confirm eq FALSE ) {
			$_input .= '<select id="' . $$_formInput{'name'} . '" name="' . $$_formInput{'name'} . '">';
			$_input .= '<option value="">' . $PULLDOWN_BASE . '</option>';
		}
		if ( $_confirm eq FALSE ) {
			for ( $_i = 0 ; $_i < @_select ; $_i ++ ) {
				$_input .= '<option value="' . $_select[$_i] . '"';
				if ( $_select[$_i] eq $$_formInput{'value'} ) { $_input .= ' selected'; }
				$_input .= '>' . $_select[$_i] . '</option>';
			}
			$_input .= '</select>';
		} else {
			$_input  = $$_formInput{'value'};
			$_hidden = '<input type="hidden" name="' . $$_formInput{'name'} . '" value="' . $$_formInput{'value'} . '" />';
		}
	} elsif ( $$_formInput{'input'} eq "checkbox" ) {
		# ** チェックボックス
		# -- 選択項目を , で分割
		local @_select = split(/,/, $$_formInput{'select'} );
		local @_value  = split(/,/, $$_formInput{'value'} );
		# -- ラベル(項目名)
		$_label  = $$_formInput{'label'};
		# -- フォーム内容
		if ( $_confirm eq FALSE ) {
			# 要素をfieldsetタグで囲む
			$_input .= '<fieldset>';
			$_input .= '<legend style="display: none;">選択肢</legend>';
			for ( $_i = 0 ; $_i < @_select ; $_i ++ ) {
				$_input .= '<input type="checkbox" id="' . $$_formInput{'name'} . "_" . $_i . '" name="' . $$_formInput{'name'} . "_" . $_i . '" value="' . $_select[$_i] . '"';
				for ( $_j = 0 ; $_j < @_value ; $_j ++ ) {
					if ( $_value[$j] eq $select[$_i] ) {
						$_input .= ' checked';
						last;
					}
				}
				$_input .= ' />';
				$_input .= '&nbsp;<label for="' . $$_formInput{'name'} . "_" . $_i . '">' . $_select[$_i] . '</label>';
			}
			# 要素をfieldsetタグで囲む
			$_input .= '</fieldset>';
		} else {
			$_hidden = '<input type="hidden" name="' . $$_formInput{'name'} . '" value="';
			for ( $_i = 0 ; $_i < @_value ; $_i ++ ) {
				$_input .= $_value[$_i] . $BR_CODE;
				if ( $_i > 0 ) {
					$_hidden.= ",";
				}
				$_hidden.= $_value[$_i];
			}
			$_hidden .= '" />';
		}
	}

	# 必須フラグ
	if ( $$_formInput{'need'} ne "" && $_confirm eq FALSE ) {
		if ( $_mode ne "confirm" ) { $_need = $NEED_MESSAGE; }
	}

	# インプットエリア作成
	for ( $_i = 0; $_i < @_formStr ; $_i ++ ) {
		$_sub = $_formStr[$_i];
		$_sub =~ s/\{\{label}}/$_label/g;
		$_sub =~ s/\{\{input}}/$_input/g;
		$_sub =~ s/\{\{hidden}}/$_hidden/g;
		$_sub =~ s/\{\{need}}/$_need/g;
		$_ret.= $_sub;
	}

	return $_ret;
}

#==============================================================================
#
#	メールアドレスの複合化
#
#	【引数】暗号化した文字列
#
#	【戻値】複合化した文字列
#
#==============================================================================
sub mailDecode
{
	local $_str = @_[0];
	local $_ret = '';
	local @_dec = split( /:/, $_str );

	for ( $_i = 0 ; $_i < @_dec ; $_i ++ ) {
		$_ret .= chr( ( $_dec[$_i] + 41 ) / 83 );
	}

	return $_ret;
}

#==============================================================================
#
#	エラー画面の表示を行う
#
#	【引数】$I_arrErr	エラーページを表示するための連想配列
#				key値	tmp_fnm		テンプレートファイル名
#						error		エラー内容
#
#	【戻値】1	正常に終了することができなかった
#
#==============================================================================
sub disp_error
{
	my $I_arrerr = shift;

	#---引数が指定されていた場合は、指定されたファイルの消去
	if(length($$I_arrerr{'del_fnm'}) > 0){ unlink($$I_arrerr{'del_fnm'}); }

	#---テンプレートの表示
	open(IN,$$I_arrerr{'tmp_fnm'}) || die &error($$I_arrerr{'error'});
		@Html_Lines = <IN>;
	close(IN);

	#---文字置き換え
	$_rep_str{$HTTP_ROOT} = $P_PrevHttpRoot;
	$_rep_str{$ERROR_MSG} = $$I_arrerr{'error'};
	for ( $_i = 0 ; $_i < @Html_Lines ; $_i ++ ) {
		$_subLine = $Html_Lines[$_i];
		# 置き換え
		while ( ( $_k, $_v ) = each ( %_rep_str ) ) {
			$_subLine =~ s/$_k/$_v/g;
		}
		$Html_Lines[$_i] = $_subLine;
	}

	#---エラー画面表示
	print "Content-type: text/html; charset=utf8\n\n";
	print @Html_Lines;

	exit;
}

# [エラー関連]
sub error {
	print "Content-type: text/html; charset=utf8\n\n";
	print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"'."\n";
	print '"http://www.w3.org/TR/html4/loose.dtd">'."\n";
	print '<html>'."\n";
	print '<head>'."\n";
	print '<title>共通問合せ先フォーム</title>'."\n";
	print '<meta http-equiv="content-type" content="text/html; charset=UTF-8">'."\n";
	print '</head>'."\n";
	print '<body>'."\n";
	print '<p>'."\n";
	print "$_[0]\n";
	print '</p>'."\n";
	print '</body>'."\n";
	print '</html>'."\n";

	exit;
}

# 文字列の前後の改行スペースを消す
sub trim {
	# 引数は文字列
	my $_str = $_[0];
	# 空白削除
	$_str =~ s/^(\s)+//ig;
	$_str =~ s/(\s)+$//ig;

	return $_str;
}

#==============================================================================
#	現在の時刻を取得する
#
#	【引数】フォーマット形式
#			1:	yyyy/mm/dd hh:mm:ss
#			2:	yyyy年mm月dd hh時mm分ss秒
#
#	【戻値】yyyy/mm/dd hh:mm:ss にフォーマットされた現在の日付時間
#			1	エラーあり
#
#==============================================================================
sub get_now_datetime
{
	local ($format_type) = @_;

	#---現在の日時を取得する
	#日時取得
	my ( @ltms )	= localtime(time);
	# 現在の年を取得する
	$NowYera  = sprintf( "%2.2d", $ltms[5]-100 );
	$NowYera += 2000;
	# 現在の月を取得する
	$NowMonth = sprintf( "%2.2d", $ltms[4]+1 );
	# 現在の日を取得する
	$NowDDay = sprintf( "%2.2d", $ltms[3] );
	# 現在の時を取得する
	$NowHour = sprintf( "%2.2d", $ltms[2] );
	# 現在の分を取得する
	$NowMin = sprintf( "%2.2d", $ltms[1] );
	# 現在の秒を取得する
	$NowSec = sprintf( "%2.2d", $ltms[0] );

	#フォーマット
	if( $format_type == 2 ){
		$NowDayTime = $NowYera . "年" . $NowMonth . "月" . $NowDDay . "日 " . $NowHour . "時" . $NowMin . "分" . $NowSec . "秒";
	}
	else{
		$NowDayTime = $NowYera . "/" . $NowMonth . "/" . $NowDDay . " " . $NowHour . ":" . $NowMin . ":" . $NowSec;
	}

	return $NowDayTime;

}

#==============================================================================
#	UTF-8からSJISへの文字コードの変換
#
#	【引数】$I_str		変換をする文字列
#
#	【戻値】変換された文字列
#
#
#==============================================================================
sub jcode_conv_utf82sjis
{
	local( $I_str ) = @_;
	
	Jcode::convert( \$I_str, "CP932", "utf8" );
	
	return $I_str;
}

#==============================================================================
#	メールの送信
#
#	【引数】$_mailTo		送信元アドレス
#			$_mailFrom		送信先アドレス
#			$_mailSubject	件名
#			$_mailBody		本文
#
#	【戻値】0 : 失敗
#			1 : 成功
#
#==============================================================================
sub funcSendMail
{
	require $P_PrevApplicationRoot.'/mimew.pl';
	
	my ( $_mailTo, $_mailFrom, $_mailSubject, $_mailBody ) = @_;
	
	Jcode::convert( \$_mailBody, "jis", "sjis" );
	
	#現在時間の作成
#	my($wday,$mon,$day,$now_time,$year) = split(/ /,localtime(time));
#	my($mail_now_datetime) = sprintf("%s, %2d %s %s %s +0900",$wday,$day,$mon,$year,$now_time);

	my @ta = localtime(time());
	my ($year, $mon, $mday, $hour, $min, $sec, $wday) = 
	   ($ta[5] + 1900, $ta[4] + 1, $ta[3], $ta[2], $ta[1], $ta[0], $ta[6]);
	my $wdayname = ("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")[$wday];
	my $monname  = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
	                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")[$mon - 1];
	my $mail_now_datetime = sprintf("$wdayname, $mday $monname $year %02d:%02d:%02d +0900",
	                       $hour, $min, $sec);

	if (-d $P_OS_WINDOWS) {
		#=====================================
		# Windows用
		#=====================================
		
		use Net::SMTP;
		
		#オブジェクトの作成 ---------------------------------------------------
		
		my $smtp = Net::SMTP->new(
			# SMTPサーバー
			$P_MailServer,
			# ドメイン
			Hello => $P_MyMailDomain,
		) || die return 0;
		
		# ヘッダー作成 --------------------------------------------------------
		
		# 送信元アドレス
		$smtp->mail( $_mailFrom );
		
		# 送信先アドレス
		my @mail_t_ary = split(/,/,$_mailTo);
		$smtp->to( @mail_t_ary );
		
		#データ部の組み立て ---------------------------------------------------
		
		$smtp->data();
		$smtp->datasend("From:".&mimeencode($_mailFrom)."\n");						#送信元
		$smtp->datasend("To:".$_mailTo."\n");										#宛先(データ部）
		$smtp->datasend("Subject:".&mimeencode($_mailSubject)."\n");				#件名
		$smtp->datasend("Reply-To:".&mimeencode($_mailFrom)."\n");					#返信先
		$smtp->datasend("Date: " . &main::mimeencode($mail_now_datetime) . "\n");	#現在日時
		$smtp->datasend("Content-Transfer-Encoding: 7bit\n");						#タイプ
		$smtp->datasend("Content-Type: text/plain; charset=ISO-2022-JP\n\n");		#タイプ
		$smtp->datasend($_mailBody);												#本文
		
		# データの終わり、メール送信 ------------------------------------------
		$smtp->dataend();
		
		# SMTP接続の終了 ------------------------------------------------------
		$smtp->quit; 
		
	} else {
		#=====================================
		# Linux用
		#=====================================
		
		# ヘッダの作成 --------------------------------------------------------
		
		my $str_head =	"To: $_mailTo\n" .
						"From: " . &mimeencode($_mailFrom) . "\n" .
						"Reply-To: " . &mimeencode($_mailFrom) . "\n" .
						"Date: " . &main::mimeencode($mail_now_datetime) . "\n" .
						"Subject: " . &mimeencode($_mailSubject) . "\n" .
						"Content-Type: text/plain; charset=ISO-2022-JP\n".
						"Content-Transfer-Encoding: 7bit\n\n";
		
		Jcode::convert( \$str_head, "jis", "sjis" );
		
		open(MAIL,"| $P_SendMail -t -i -f ".$_mailFrom) || die return 0;
		print MAIL $str_head;
		print MAIL $_mailBody;
		close(MAIL);
	}
	
	# 成功
	return 1;
}
#----------------------------------------------#
#■指定バイト数ごとに改行を入れる
#----------------------------------------------#
sub str_jfold{
	
	my $result = '';
	my @temp_ary = split(/\n/,$_[0]);
	
	foreach my $temp_data (@temp_ary) {
		
		my $cnt = 0;
		my $temp_jcode = new Jcode($temp_data,"sjis");
		
		foreach my $buff ( $temp_jcode->jfold($_[1]) ){
			$result .= "$buff\n";
			$cnt ++;
		}
		if ( $cnt == 0 ) { $result .= "\n"; }
	}
	
	return($result);
}

#==============================================================================
#
#	数値チェック
#
#==============================================================================
sub check_numeric
{
	return ( @_[0] =~ /^[0-9]+$/ );
}

#==============================================================================
#
#	半角英数チェック
#
#==============================================================================
sub check_h_alphanumeric
{
	return ( @_[0] =~ /^[a-zA-Z0-9]+$/ );
}

#==============================================================================
#
#	半角英数記号チェック
#		許可される記号
#		   # ! % & = @ ; : , _ " ' ~ ` < > 
#		   - + * / . ? { } ( ) [ ] ^ $ @ | \ 
#==============================================================================
sub check_h_alphanumeric
{
	return ( @_[0] =~ /^[a-zA-Z0-9#!%&=;:,_"'~`<>\-\+\*\/\.\?\{\}\(\)\[\]\^\@\|\\]+$/ );
}

#==============================================================================
#	アクセス制限をチェックする
#	【引数】 $remotoAddr	リモートアドレス
#	         *err_msg		エラーメッセージ
#	【戻値】 アクセス制限が無い場合はTRUE、そうでない場合はFALSEを返す
#==============================================================================
sub chkAccess{
	#引数の取得
	my($remotoAddr) = shift if @_;	#リモートアドレス
	local(*err_msg) = @_;			#エラーメッセージ

	#定数の宣言
	local(@P_LimitRemotoHost) = @P_LimitRemotoHost;	#アクセス制限リスト

	#変数の宣言
	my($remotoHost) = &getHostByAddr($remotoAddr);	#リモートホスト
	my($remotoDate) = "";							#リモートアクセスの日付
	my($remotoTime) = "";							#リモートアクセスの時間
	my($log_Count) = 0;								#ログ中の出現回数
	my($log_Date) = "";								#ログ中の最終アクセス日付
	my($log_Time) = "";								#ログ中の最終アクセス時間

	#指定アクセス制限のチェック
	for(my($i) = 0;$i < @P_LimitRemotoHost;$i++){
		if($remotoAddr eq $P_LimitRemotoHost[$i] || $remotoHost eq $P_LimitRemotoHost[$i]){
			$err_msg .= "アクセス制限により、お問い合わせを行なうことが出来ません。";
			return 0;
		}
	}
	
	# 現在日時の取得
	my($mday, $mon, $year) = (localtime(time))[3..5];
	# 日付の補正
	$year += 1900;
	$mon += 1;
	# 日付フォーマットの設定
	$year = sprintf('%04d', $year);
	$mon = sprintf('%02d', $mon);
	$mday = sprintf('%02d', $mday);
	
	# ログファイルの読み込み設定
	my($logFileName) = $P_LimitLogSaveDir . "/" . $year . $mon . $mday . ".log";
	#ファイルの存在チェック
	if(-f $logFileName){
		#ログファイルの読み込み
		unless(open(LOG_IN,"< " . $logFileName)){
			$err_msg .= "ログファイルの読み込みに失敗しました。";
			return 0;
		}
		#一行ごと読み込み&解析
		while($line = <LOG_IN>){
			#改行を消す
			chomp($line);
			#一行を分割する
			my($csv_date,$csv_time,$csv_remotoAddr,$csv_remotoHost) = split(/,/,$line);
			#リモートアドレス or リモートホストがある場合
			if($remotoAddr eq $csv_remotoAddr || $remotoHost eq $csv_remotoHost){
				$log_Date = $csv_date;
				$log_Time = $csv_time;
				$log_Count++;
			}
		}
		#ファイルクローズ
		close(LOG_IN);
		#同日中の送信制限チェック
		if($P_LimitDay != 0 && $log_Date ne ""){
			#設定ファイルと比較
			if($log_Count >= $P_LimitDay){
				$err_msg .= "お問い合わせ最大回数制限により、お問い合わせを行なうことが出来ません。<br />明日以降に、再度お試しください。";
				return 0;
			}
		}
		#時間制限チェック
		if($P_LimitTime != 0 && $log_Time ne ""){
			#ログにあった最終投稿時間を秒に変換
			if($log_Time =~ /(\d+?)時(\d+?)分(\d+?)秒/){ $log_Time = $1 * 3600 + $2 * 60 + $3; }
			my($s,$m,$h) = (localtime(time))[0..2];
			#現在の時刻を秒に変換
			$remotoTime = $h * 3600 + $m * 60 + $s;
			#設定ファイルと比較
			if($remotoTime - $log_Time <= $P_LimitTime){
				$err_msg .= "現在、お問い合わせを行なうことが出来ません。<br />しばらく時間を置いてから、再度お試しください。";
				return 0;
			}
		}
	}
	return 1;
}

#==============================================================================
#	ホスト名を逆引きする
#	【引数】 $ip	逆引きしたいリモートアドレス
#	【戻値】 逆引きした結果（逆引きできればホスト名、出来なければIPを返す）
#==============================================================================
sub getHostByAddr{
	#引数の取得
	my($ip) = @_;
	#IPアドレスの解析
	my @addr = split(/\./, $ip);
	if(@addr != 4){ return $ip; }
	#逆引き実行
	my($name) = gethostbyaddr(pack("C4",@addr),2);
	#結果を返す
	return $name ? $name : $ip;
}

#==============================================================================
#	ホスト名を正引きする
#	【引数】 $hostname	正引きしたいリモートホスト名
#	【戻値】 正引きした結果（正引きできればIPの配列、出来なければホスト名を返す）
#==============================================================================
sub getHostByName{
	#引数の取得
	my($hostname) = @_;
	#正引き実行
	my($name,$aliases,$addrtype,$length,@ipaddr) = gethostbyname($hostname);
	my(@ip) = ();
	foreach(@ipaddr){
		push(@ip,join('.',unpack('C4',$_)));
	}
	#結果を返す
	return @ip ? @ip : $hostname;
}

## 正規表現用に文字列をエスケープ
# 
# @param  $_[0] 文字列
# @return $ret  エスケープした文字列
# 
sub reg_replace {
	
	# 引数取得
	local $ret = $_[0];
	
	# 文字列のエスケープ
	$ret =~ s/[\\\*\+\.\?\{\}\(\)\[\]\^\$\-\|\/]/\\$&/g;
	
	return $ret;
}

## 設定ファイルに設定した有効ドメインかチェック
# 
# @param  $_[0] URL
# @return 1 (有効) | 0 (無効)
# 
sub is_valid_url {
	
	# 引数取得
	local $url = $_[0];
	# URLから付加情報を削除
	$url =~ s/\#.*//;
	$url =~ s/\?.*//;
	
	# 有効ドメイン
	local @chk_domain = @main::P_PrevValidHttpDomain;
	
	# 変数初期化
	local $valid_domain = "";
	local $valid_flg = 0;
	
	# チェック開始
	for (local $cnt = 0 ; $cnt < @chk_domain ; $cnt ++) {
		
		# 有効ドメインの設定値を補正
		$valid_domain = $chk_domain[$cnt];
		$valid_domain =~ s/^\s//;
		$valid_domain =~ s/\s$//;
		$valid_domain =~ s/\/$//;
		
		# 補正したドメインが空の場合はチェックなし
		if ($valid_domain eq "") {
			next;
		}
		
		# 正規表現用のエスケープ
		$valid_domain = &reg_replace($valid_domain);
		
		# チェック
		if ($url =~ /^$valid_domain(\/|$)/) {
			$valid_flg = 1;
			last;
		}
	}
	
	# 絶対パス指定と相対パス指定をチェック
	if ($valid_flg != 1 && ($url =~ /^\// || $url =~ /^\./)) {
		$valid_flg = 1;
	}
	
	# 結果を返す
	return $valid_flg;
}

## HTTPリファラのチェック
# 
# @return 1 (許可ドメイン) | 0 (無効ドメイン)
# 
sub is_valid_referer {
	# HTTPリファラ取得
	if (!exists $ENV{'HTTP_REFERER'} || $ENV{'HTTP_REFERER'} =~ /^\s*$/) {
		# 取得に失敗した場合はエラー
		return 0;
	}
	local $referer = $ENV{'HTTP_REFERER'};
	
	# チェック
	return &is_valid_url($referer);
}

# -- EOF ------------------------------------------------------------------------------------------#
1;