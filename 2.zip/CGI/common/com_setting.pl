#==============================================================================
# 共通設定ファイル
# 各CGIで使用する定数や設定を定義する
#==============================================================================

BEGIN {
	#------------------------------------------------------------------------------
	# 環境パス
	#------------------------------------------------------------------------------
	# 公開ディレクトリのパス（環境の存在する場所をフルパスで指定）
	our $CONST_PUBLIC_APPLICATION_ROOT_DIR_PATH = '/var/www/cgi-bin';
	our $CONST_APPLICATION_ROOT = $CONST_PUBLIC_APPLICATION_ROOT_DIR_PATH;
	# 非公開ディレクトリのパス
	our $CONST_PRIVATE_APPLICATION_ROOT_DIR_PATH = '/var/www/csv';
	# 公開ディレクトリのパス
	our $CONST_HTTP_ROOT_DIR_PATH = '/htdocs/public';
	
	# 公開ドメイン
	our $CONST_HTTP_ROOT_DOMAIN = 'http://www.glode.co.jp';
	# 公開ドメイン（SSL）
	our $CONST_HTTP_ROOT_DOMAIN_SSL = 'https://www.glode.co.jp';
	
	# 内部ドメインとして認識するURL
	our @CONST_VALID_HTTP_INNER_DOMAIN = (
		$CONST_HTTP_ROOT_DOMAIN,
		$CONST_HTTP_ROOT_DOMAIN_SSL
	);
	
	our @CONST_VALID_HTTP_DOMAIN = @CONST_VALID_HTTP_INNER_DOMAIN;
	
	# SendMailのパス
	our $CONST_SENDMAIL_PATH = '/usr/sbin/sendmail';
	# メールサーバーのドメイン
	our $CONST_MAIL_SERVER_DOMAIN = 'mail.glode.co.jp';
	# メールのドメイン
	our $CONST_MAIL_DOMAIN = 'glode.co.jp';
	
	our $CONST_JCODE_SJIS = "shift_jis";
	our $CONST_JCODE_UTF8 = "utf-8";
	
	# 内部エンコードの指定
	our $CONST_PERL_INNER_CHAR_CODE = 'UTF-8';
	# Perlバージョンの設定
	our $CONST_PERL_VERSION = sprintf('%d.%d.%d', $1, $2, $3) if ($] =~ /(\d+)\.(\d{1,3})\.?(\d{1,3})/);
	# デフォルトの言語コード指定
	our $CONST_DEFAULT_LANGUAGE = 'ja';
	# XHTMLの使用フラグ[0:未使用 1:使用]
	our $CONST_USE_XHTML_FLG = 1;
	
	# 文字コードリスト
	our %CONST_CHAR_CODE_LIST_HASH = (
		'utf8' => 'utf-8',
		'utf-8' => 'utf-8',
		'shift_jis' => 'shift_jis',
		'sjis' => 'shift_jis',
		'euc-jp' => 'euc-jp',
		'sjis-win' => 'cp932',
		'cp932' => 'cp932',
	);
	
	#------------------------------------------------------------------------------
	# ファイル読込み時に自動実行するプログラム
	#------------------------------------------------------------------------------
	# 付属のJcode.pmを指定（環境によっては古い Jcode.pm が使用されているため）
	require $CONST_PUBLIC_APPLICATION_ROOT_DIR_PATH . '/common/library/Jcode.pm';
	Jcode->import();
	# プログラムの初期に実行させる処理
	require $CONST_PUBLIC_APPLICATION_ROOT_DIR_PATH . '/common/autorun.pl';
	
	#------------------------------------------------------------------------------
	# ファイル読込み時に自動読み込みするファイル
	#------------------------------------------------------------------------------
	# エラーメッセージファイル
	require $CONST_PUBLIC_APPLICATION_ROOT_DIR_PATH . '/common/com_setting_msg.pl';
	# 共通関数ファイル
	require $CONST_PUBLIC_APPLICATION_ROOT_DIR_PATH . '/common/com_function.pl';

#------------------------------------------------------------------------------
#	文字コード・Perlバージョン設定ファイル名
#------------------------------------------------------------------------------
#$P_SystemDatPath = $CONST_PUBLIC_APPLICATION_ROOT_DIR_PATH . "/system.dat";

#------------------------------------------------------------------------------
#	設定ファイルに定義される値
#------------------------------------------------------------------------------
#$P_JcodeSJIS  = "shift_jis";
#$P_JcodeUTF8  = "utf-8";
#$P_Perlvar_50 = "5.0";
#$P_Perlvar_58 = "5.8";

## OS
#$P_OS_LINUX   = "/";         # Linux
#$P_OS_WINDOWS = "\\";        # Windows

}
1;
