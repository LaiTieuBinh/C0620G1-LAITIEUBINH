#==================================================================================================#
# 共通関数ファイル                                                                                 #
#==================================================================================================#

#==============================================================================
#	機種依存文字をチェック
#
# 【引数】	チェックする文字列
#
# 【戻値】	0	機種依存文字がない場合
#			1	機種依存文字が含まれる場合
#
#==============================================================================
sub pdc_chk {

	# ** 引数を変数に代入 ** #
	# チェックする文字
	@_chk_Str = @_;

	# 機種依存文字
	@_pdc_Str = (
		#半角片仮名
		"｡" , "｢" , "｣" , "､" , "･" , "ｦ" ,
		"ｧ" , "ｨ" , "ｩ" , "ｪ" , "ｫ" , "ｬ" ,
		"ｭ" , "ｮ" , "ｯ" , "ｰ" , "ｱ" , "ｲ" ,
		"ｳ" , "ｴ" , "ｵ" , "ｶ" , "ｷ" , "ｸ" ,
		"ｹ" , "ｺ" , "ｻ" , "ｼ" , "ｽ" , "ｾ" ,
		"ｿ" , "ﾀ" , "ﾁ" , "ﾂ" , "ﾃ" , "ﾄ" ,
		"ﾅ" , "ﾆ" , "ﾇ" , "ﾈ" , "ﾉ" , "ﾊ" ,
		"ﾋ" , "ﾌ" , "ﾍ" , "ﾎ" , "ﾏ" , "ﾐ" ,
		"ﾑ" , "ﾒ" , "ﾓ" , "ﾔ" , "ﾕ" , "ﾖ" ,
		"ﾗ" , "ﾘ" , "ﾙ" , "ﾚ" , "ﾛ" , "ﾜ" ,
		"ﾝ" , "ﾞ" , "ﾟ" ,
		#Windowsの機種依存文字
		"①" , "②" , "③" , "④" , "⑤" , "⑥" ,
		"⑦" , "⑧" , "⑨" , "⑩" , "⑪" , "⑫" ,
		"⑬" , "⑭" , "⑮" , "⑯" , "⑰" , "⑱" ,
		"⑲" , "⑳" , 

		"㍉" , "㌔" , "㌢" , "㍍" , "㌘" , "㌧" ,
		"㌃" , "㌶" , "㍑" , "㍗" , "㌍" , "㌦" ,
		"㌣" , "㌫" , "㍊" , "㌻" , "㎜" , "㎝" ,
		"㎞" , "㎎" , "㎏" , "㏄" , "㎡" , "㍻" ,
		"〝" , "〟" , "№" , "㏍" , "℡" , "㊤" ,
		"㊥" , "㊦" , "㊧" , "㊨" , "㈱" , "㈲" ,
		"㈹" , "㍾" , "㍽" , "㍼" , "≒" , "≡" ,
		"∫" , "∮" , "∑" , "√" , "⊥" , "∠" ,
		"∟" , "⊿" , "∵" , "∩" , "∪" ,
		#NECのIBM拡張文字
		       "褜" , "鍈" , "銈" , "蓜" , "俉" ,
		"炻" , "昱" , "棈" , "鋹" , "曻" , "彅" ,
		"丨" , "仡" , "仼" , "伀" , "伃" , "伹" ,
		"佖" , "侒" , "侊" , "侚" , "侔" , "俍" ,
		"偀" , "倢" , "俿" , "倞" , "偆" , "偰" ,
		"偂" , "傔" , "僴" , "僘" , "兊" , "兤" ,
		"冝" , "冾" , "凬" , "刕" , "劜" , "劦" ,
		"勀" , "勛" , "匀" , "匇" , "匤" , "卲" ,
		"厓" , "厲" , "叝" , "﨎" , "咜" , "咊" ,
		"咩" , "哿" , "喆" , "坙" , "坥" , "垬" ,
		"埈" , "埇" , "﨏" , "塚" , "增" , "墲" ,
		"夋" , "奓" , "奛" , "奝" , "奣" , "妤" ,
		"妺" , "孖" , "寀" , "甯" , "寘" , "寬" ,
		"尞" , "岦" , "岺" , "峵" , "崧" , "嵓" ,
		"﨑" , "嵂" , "嵭" , "嶸" , "嶹" , "巐" ,
		"弡" , "弴" , "彧" , "德" ,
		"忞" , "恝" , "悅" , "悊" , "惞" , "惕" ,
		"愠" , "惲" , "愑" , "愷" , "愰" , "憘" ,
		"戓" , "抦" , "揵" , "摠" , "撝" , "擎" ,
		"敎" , "昀" , "昕" , "昻" , "昉" , "昮" ,
		"昞" , "昤" , "晥" , "晗" , "晙" , "晴" ,
		"晳" , "暙" , "暠" , "暲" , "暿" , "曺" ,
		"朎" , "朗" , "杦" , "枻" , "桒" , "柀" ,
		"栁" , "桄" , "棏" , "﨓" , "楨" , "﨔" ,
		"榘" , "槢" , "樰" , "橫" , "橆" , "橳" ,
		"橾" , "櫢" , "櫤" , "毖" , "氿" , "汜" ,
		"沆" , "汯" , "泚" , "洄" , "涇" , "浯" ,
		"涖" , "涬" , "淏" , "淸" , "淲" , "淼" ,
		"渹" , "湜" , "渧" , "渼" , "溿" , "澈" ,
		"澵" , "濵" , "瀅" , "瀇" , "瀨" , "炅" ,
		"炫" , "焏" , "焄" , "煜" , "煆" , "煇" ,
		"凞" , "燁" , "燾" , "犱" ,
		       "猤" , "猪" , "獷" , "玽" , "珉" ,
		"珖" , "珣" , "珒" , "琇" , "珵" , "琦" ,
		"琪" , "琩" , "琮" , "瑢" , "璉" , "璟" ,
		"甁" , "畯" , "皂" , "皜" , "皞" , "皛" ,
		"皦" , "益" , "睆" , "劯" , "砡" , "硎" ,
		"硤" , "硺" , "礰" , "礼" , "神" , "祥" ,
		"禔" , "福" , "禛" , "竑" , "竧" , "靖" ,
		"竫" , "箞" , "精" , "絈" , "絜" , "綷" ,
		"綠" , "緖" , "繒" , "罇" , "羡" , "羽" ,
		"茁" , "荢" , "荿" , "菇" , "菶" , "葈" ,
		"蒴" , "蕓" , "蕙" , "蕫" , "﨟" , "薰" ,
		"蘒" , "﨡" , "蠇" , "裵" , "訒" , "訷" ,
		"詹" , "誧" , "誾" , "諟" , "諸" , "諶" ,
		"譓" , "譿" , "賰" , "賴" , "贒" , "赶" ,
		"﨣" , "軏" , "﨤" , "逸" , "遧" , "郞" ,
		"都" , "鄕" , "鄧" , "釚" ,
		"釗" , "釞" , "釭" , "釮" , "釤" , "釥" ,
		"鈆" , "鈐" , "鈊" , "鈺" , "鉀" , "鈼" ,
		"鉎" , "鉙" , "鉑" , "鈹" , "鉧" , "銧" ,
		"鉷" , "鉸" , "鋧" , "鋗" , "鋙" , "鋐" ,
		"﨧" , "鋕" , "鋠" , "鋓" , "錥" , "錡" ,
		"鋻" , "﨨" , "錞" , "鋿" , "錝" , "錂" ,
		"鍰" , "鍗" , "鎤" , "鏆" , "鏞" , "鏸" ,
		"鐱" , "鑅" , "鑈" , "閒" , "隆" , "﨩" ,
		"隝" , "隯" , "霳" , "霻" , "靃" , "靍" ,
		"靏" , "靑" , "靕" , "顗" , "顥" , "飯" ,
		"飼" , "餧" , "館" , "馞" , "驎" , "髙" ,
		"髜" , "魵" , "魲" , "鮏" , "鮱" , "鮻" ,
		"鰀" , "鵰" , "鵫" , "鶴" , "鸙" , "黑" ,
		"ⅰ" , "ⅱ" , "ⅲ" , "ⅳ" , "ⅴ" , "ⅵ" ,
		"ⅶ" , "ⅷ" , "ⅸ" , "ⅹ" , "￢" , "￤" ,
		"＇" , "＂" ,

		#Shift_JIS 非対応記号 -----------------------------------------------------

		#Windowsの機種依存文字
		"Ⅰ" , "Ⅱ" , "Ⅲ" , "Ⅳ" , "Ⅴ" , "Ⅵ" , "Ⅶ" , "Ⅷ" , "Ⅸ" , "Ⅹ" ,
		#NECのIBM拡張文字
		"纊" , "犾" ,
		#その他
		"ℓ" , "®" ,"㎥" , "㎠" , "㎤" , "㎖" , "㏔" , "㎢" , "㎳" ,
	);

	# 機種依存文字のチェック
	for ($_i = 0 ; $_i < $#_pdc_Str+1 ; $_i ++ ) {
		for ($_j = 0 ; $_j < $#_chk_Str+1 ; $_j ++) {
			if ( $_chk_Str[$_j] =~ /$_pdc_Str[$_i]/ ) {
				# 機種依存文字が存在していれば 1
				return 1;
			}
		}
	}

	# 機種依存文字が存在していなければ 0
	return 0;

}

#==================================================================================================#
# メールアドレス形式チェック                                                                       #
#==================================================================================================#
sub mailInputChk {

	local ( $str ) = @_;

	# メールフォーマットチェック
	if ( $str ne "" ){
		if ( $str !~ /^([a-zA-Z0-9\.\-\/_\!\#\$\%\&\'\*\+\=\?\^\`\{\|\}\~\(\)\ \[\]\\\<\>\@\:\;\,]{1,})@([a-zA-Z0-9\.\-\/_]{1,})\.([a-zA-Z0-9\.\-\/_]{1,})$/ ) {
			return 1;
		}
	}
	return 0;
}

#==================================================================================================#
# 数字orハイフンチェック                                                                           #
#==================================================================================================#
sub numericInputChk {

	local ( $str ) = @_;

	# 数字orハイフンチェック
	if ( $str ne "" ){
		if ( $str !~ /^([\d\-]+)$/ ) {
			return 1;
		}
	}

	return 0;
}

#==============================================================================
#	ロックファイル作成
#
#	【引数】ファイルロック	"ON" or "OFF"
#			ロックファイル名
#
#	【戻値】n	何らかの理由で失敗をした
#			0	正常終了
#
#==============================================================================
sub file_lock
{

	#---ロックファイル名
	$strLookFnm = $_[1];

	$err_flg = 0;

	if($_[0] eq 'ON'){
		$flg = 0;
		foreach(1 .. 5){
			if(-e $strLookFnm){sleep(1);}
			else{
				if(!open(LOCK,">$strLookFnm")){
					$err_flg = 1;		#作成不可
					last;
				}
				close(LOCK);
				chmod 0777, $strLookFnm;
				$flg = 1;
				last;
			}
		}
		if(!$flg){
			$err_flg = 2;	#タイムオーバー
		}
	}
	else{
		if(-e $strLookFnm){
			unlink($strLookFnm);
		}
	}
	
	return $err_flg;
}

#==============================================================================
#	タグの無効化
#
#	【引数】無効化を行なう文字列
#
#	【戻値】タグが無効化された文字列
#
#	【備考】< > & " ' をそれぞれ文字列に変換する
#
#	【作成】06/11/09 表示文字、入力文字のタグを無効にするため
#
#==============================================================================
sub html_escapr
{
	local( $InStr ) = @_;

	$InStr =~ s/&/&amp;/g;		#& → &amp;
	$InStr =~ s/</&lt;/ig;		#< → &lt;
	$InStr =~ s/>/&gt;/ig;		#> → &gt;
	$InStr =~ s/"/&quot;/g;		#" → &quot;
	$InStr =~ s/'/&#39;/g;		#' → &#39;
	$InStr =~ s/\0/,/g;

	return $InStr;
}

#==============================================================================
#	改行コードのHTMLタグ化 \n → <BR>
#
#	【引数】タグ化を行なう文字列
#
#	【戻値】タグが無効化された文字列
#
#	【備考】改行コードを<BR>に変換する
#
#	【作成】06/11/09 表示文字、入力文字のタグを無効にするため
#
#==============================================================================
sub html_escapr_ret
{
	local( $InStr ) = @_;

	$InStr =~ s/\r\n/\n/g;
	$InStr =~ s/\r/\n/g;
	$InStr =~ s/\n/$BR_CODE/ig;

	return $InStr;

}

#==============================================================================
#	PHPの in_array
#
#	【引数】@_[1] チェックしたい文字
#			@_[2] 配列へのリファレンス
#
#	【戻値】1 有り | 0 なし
#
#==============================================================================
sub in_array
{
	my ( $val, $array_ref ) = @_;
	
	foreach my $elem( @$array_ref ) {
		if ( $val=~m/^[0-9]+$/ ){
			if ( $val == $elem ) { return 1; }
		}
		else{
			if ( $val eq $elem ) { return 1; }
		}
	}
	return 0;
}

# CSVの読み込み
sub csvStrCut
{
	# CSV 文字列( 1行 )
	local ( $_csvStr ) = @_;
	@_ret = ();

	$_csvStr =~ s/\r\n/\n/g;
	$_csvStr =~ s/\r/\n/g;

	while( $_csvStr =~ s/".*?"[\n,]// ) {
		$_sub = $&;
		$_sub =~ s/^"//;
		$_sub =~ s/"[\n,]$//;
		push( @_ret, $_sub );
	}

	return @_ret;
}

#==============================================================================
#	<input><textarea>などのインプットフォームの作成
#
#	【引数】連想配列
#		{'input'}  = text | textarea | radio | select | checkbox
#		{'label'}  = 項目名
#		{'name'}   = name値
#		{'need'}   = 必須フラグ
#		{'value'}  = value値
#       {'select'} = text : size | textarea : [0]cols [1]rows | else 選択項目
#		{'confirm'}= 確認画面用表示フラグ ( TRUE | FALSE )
#
#	【戻値】作成されたエリアのHTML文字列
#
#==============================================================================
sub formCreate
{

	local $_formInput = shift;
	local @_formStr = @_;
	local $_ret    = '';
	local $_label  = '';
	local $_input  = '';
	local $_hidden = '';
	local $_need   = '';

	# 文字列のエスケープ
	$$_formInput{'input'} = &html_escapr( $$_formInput{'input'} );
	$$_formInput{'name'}  = &html_escapr( $$_formInput{'name'} );
	$$_formInput{'label'} = &html_escapr( $$_formInput{'label'} );
	$$_formInput{'value'} = &html_escapr( &trim( $$_formInput{'value'} ) );

	# 確認フラグ代入
	local $_confirm = $$_formInput{'confirm'};

	if ( $$_formInput{'input'} eq "text" ) {
		# ** テキストボックス
		# -- ラベル(項目名)
		$_label  = '<label for="' . $$_formInput{'name'} . '">' . $$_formInput{'label'} . '</label>';
		# -- フォーム内容
		if ( $_confirm eq FALSE ) {
			$_input  = '<input type="text" id="' . $$_formInput{'name'} . '" name="' . $$_formInput{'name'} . '" value="' . $$_formInput{'value'} . '" size="' . $$_formInput{'select'} . '" />';
		} else {
			$_input  = $$_formInput{'value'};
			$_hidden = '<input type="hidden" name="' . $$_formInput{'name'} . '" value="' . $$_formInput{'value'} . '" />';
		}
	} elsif ( $$_formInput{'input'} eq "textarea" ) {
		# ** テキストボックス
		# -- 縦横指定を , で分割
		local @_widhgt = split(/,/, $$_formInput{'select'} );
		# -- ラベル(項目名)
		$_label  = '<label for="' . $$_formInput{'name'} . '">' . $$_formInput{'label'} . '</label>';
		# -- フォーム内容
		if ( $_confirm eq FALSE ) {
			$_input  = '<textarea id="' . $$_formInput{'name'} . '" name="' . $$_formInput{'name'} . '" cols="' . @_widhgt[0] . '" rows="' . @_widhgt[1] . '">' . $$_formInput{'value'} . '</textarea>';
		} else {
			$_hidden = '<input type="hidden" name="' . $$_formInput{'name'} . '" value="' . $$_formInput{'value'} . '" />';
			$$_formInput{'value'} = &html_escapr_ret($$_formInput{'value'});
			$_input  = $$_formInput{'value'};
		}
	} elsif ( $$_formInput{'input'} eq "radio" ) {
		# ** ラジオボタン
		# -- 選択項目を , で分割
		local @_select = split(/,/, $$_formInput{'select'} );
		# -- ラベル(項目名)
		$_label  = $$_formInput{'label'};
		# -- フォーム内容
		if ( $_confirm eq FALSE ) {
			# 要素をfieldsetタグで囲む
			$_input .= '<fieldset>';
			$_input .= '<legend style="display: none;">選択肢</legend>';
			for ( $_i = 0 ; $_i < @_select ; $_i ++ ) {
				$_input .= '<input type="radio" id="' . $$_formInput{'name'} . "_" . $_i . '" name="' . $$_formInput{'name'} . '" value="' . $_select[$_i] . '"';
				if ( $_select[$_i] eq $$_formInput{'value'} ) { $_input .= ' checked'; }
				$_input .= ' />';
				$_input .= '&nbsp;<label for="' . $$_formInput{'name'} . "_" . $_i . '">' . $_select[$_i] . '</label>';
			}
			# 要素をfieldsetタグで囲む
			$_input .= '</fieldset>';
		} else {
			$_input  = $$_formInput{'value'};
			$_hidden = '<input type="hidden" name="' . $$_formInput{'name'} . '" value="' . $$_formInput{'value'} . '" />';
		}
	} elsif ( $$_formInput{'input'} eq "select" ) {
		# ** プルダウン
		# -- 選択項目を , で分割
		local @_select = split(/,/, $$_formInput{'select'} );
		# -- ラベル(項目名)
		$_label  = '<label for="' . $$_formInput{'name'} . '">' . $$_formInput{'label'} . '</label>';
		# -- フォーム内容
		if ( $_confirm eq FALSE ) {
			$_input .= '<select id="' . $$_formInput{'name'} . '" name="' . $$_formInput{'name'} . '">';
			$_input .= '<option value="">' . $PULLDOWN_BASE . '</option>';
		}
		if ( $_confirm eq FALSE ) {
			for ( $_i = 0 ; $_i < @_select ; $_i ++ ) {
				$_input .= '<option value="' . $_select[$_i] . '"';
				if ( $_select[$_i] eq $$_formInput{'value'} ) { $_input .= ' selected'; }
				$_input .= '>' . $_select[$_i] . '</option>';
			}
			$_input .= '</select>';
		} else {
			$_input  = $$_formInput{'value'};
			$_hidden = '<input type="hidden" name="' . $$_formInput{'name'} . '" value="' . $$_formInput{'value'} . '" />';
		}
	} elsif ( $$_formInput{'input'} eq "checkbox" ) {
		# ** チェックボックス
		# -- 選択項目を , で分割
		local @_select = split(/,/, $$_formInput{'select'} );
		local @_value  = split(/,/, $$_formInput{'value'} );
		# -- ラベル(項目名)
		$_label  = $$_formInput{'label'};
		# -- フォーム内容
		if ( $_confirm eq FALSE ) {
			# 要素をfieldsetタグで囲む
			$_input .= '<fieldset>';
			$_input .= '<legend style="display: none;">選択肢</legend>';
			for ( $_i = 0 ; $_i < @_select ; $_i ++ ) {
				$_input .= '<input type="checkbox" id="' . $$_formInput{'name'} . "_" . $_i . '" name="' . $$_formInput{'name'} . "_" . $_i . '" value="' . $_select[$_i] . '"';
				for ( $_j = 0 ; $_j < @_value ; $_j ++ ) {
					if ( $_value[$j] eq $select[$_i] ) {
						$_input .= ' checked';
						last;
					}
				}
				$_input .= ' />';
				$_input .= '&nbsp;<label for="' . $$_formInput{'name'} . "_" . $_i . '">' . $_select[$_i] . '</label>';
			}
			# 要素をfieldsetタグで囲む
			$_input .= '</fieldset>';
		} else {
			$_hidden = '<input type="hidden" name="' . $$_formInput{'name'} . '" value="';
			for ( $_i = 0 ; $_i < @_value ; $_i ++ ) {
				$_input .= $_value[$_i] . $BR_CODE;
				if ( $_i > 0 ) {
					$_hidden.= ",";
				}
				$_hidden.= $_value[$_i];
			}
			$_hidden .= '" />';
		}
	}

	# 必須フラグ
	if ( $$_formInput{'need'} ne "" && $_confirm eq FALSE ) {
		if ( $_mode ne "confirm" ) { $_need = $NEED_MESSAGE; }
	}

	# インプットエリア作成
	for ( $_i = 0; $_i < @_formStr ; $_i ++ ) {
		$_sub = $_formStr[$_i];
		$_sub =~ s/\{\{label}}/$_label/g;
		$_sub =~ s/\{\{input}}/$_input/g;
		$_sub =~ s/\{\{hidden}}/$_hidden/g;
		$_sub =~ s/\{\{need}}/$_need/g;
		$_ret.= $_sub;
	}

	return $_ret;
}

#==============================================================================
#
#	メールアドレスの複合化
#
#	【引数】暗号化した文字列
#
#	【戻値】複合化した文字列
#
#==============================================================================
sub mailDecode
{
	local $_str = @_[0];
	local $_ret = '';
	local @_dec = split( /:/, $_str );

	for ( $_i = 0 ; $_i < @_dec ; $_i ++ ) {
		$_ret .= chr( ( $_dec[$_i] + 41 ) / 83 );
	}

	return $_ret;
}

#==============================================================================
#
#	エラー画面の表示を行う
#
#	【引数】$I_arrErr	エラーページを表示するための連想配列
#				key値	tmp_fnm		テンプレートファイル名
#						error		エラー内容
#
#	【戻値】1	正常に終了することができなかった
#
#==============================================================================
sub disp_error
{
	my $I_arrerr = shift;

	#---テンプレートの表示
	open(IN,$$I_arrerr{'tmp_fnm'}) || die &error($$I_arrerr{'error'});
		@Html_Lines = <IN>;
	close(IN);

	#---文字置き換え
	$_rep_str{$HTTP_ROOT} = $P_PrevHttpRoot;
	$_rep_str{$ERROR_MSG} = $$I_arrerr{'error'};
	for ( $_i = 0 ; $_i < @Html_Lines ; $_i ++ ) {
		$_subLine = $Html_Lines[$_i];
		# 置き換え
		while ( ( $_k, $_v ) = each ( %_rep_str ) ) {
			$_subLine =~ s/$_k/$_v/g;
		}
		$Html_Lines[$_i] = $_subLine;
	}

	#---エラー画面表示
	print "Content-type: text/html; charset=utf8\n\n";
	print @Html_Lines;

	exit;
}

# [エラー関連]
sub error {
	print "Content-type: text/html; charset=utf8\n\n";
	print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"'."\n";
	print '"http://www.w3.org/TR/html4/loose.dtd">'."\n";
	print '<html>'."\n";
	print '<head>'."\n";
	print '<title>共通問合せ先フォーム</title>'."\n";
	print '<meta http-equiv="content-type" content="text/html; charset=UTF-8">'."\n";
	print '</head>'."\n";
	print '<body>'."\n";
	print '<p>'."\n";
	print "$_[0]\n";
	print '</p>'."\n";
	print '</body>'."\n";
	print '</html>'."\n";

	exit;
}

# 文字列の前後の改行スペースを消す
sub trim {
	# 引数は文字列
	my $_str = $_[0];
	# 空白削除
	$_str =~ s/^(\s)+//ig;
	$_str =~ s/(\s)+$//ig;

	return $_str;
}

#==============================================================================
#	現在の時刻を取得する
#
#	【引数】フォーマット形式
#			1:	yyyy/mm/dd hh:mm:ss
#			2:	yyyy年mm月dd hh時mm分ss秒
#
#	【戻値】yyyy/mm/dd hh:mm:ss にフォーマットされた現在の日付時間
#			1	エラーあり
#
#==============================================================================
sub get_now_datetime
{
	local ($format_type) = @_;

	#---現在の日時を取得する
	#日時取得
	my ( @ltms )	= localtime(time);
	# 現在の年を取得する
	$NowYera  = sprintf( "%2.2d", $ltms[5]-100 );
	$NowYera += 2000;
	# 現在の月を取得する
	$NowMonth = sprintf( "%2.2d", $ltms[4]+1 );
	# 現在の日を取得する
	$NowDDay = sprintf( "%2.2d", $ltms[3] );
	# 現在の時を取得する
	$NowHour = sprintf( "%2.2d", $ltms[2] );
	# 現在の分を取得する
	$NowMin = sprintf( "%2.2d", $ltms[1] );
	# 現在の秒を取得する
	$NowSec = sprintf( "%2.2d", $ltms[0] );

	#フォーマット
	if( $format_type == 2 ){
		$NowDayTime = $NowYera . "年" . $NowMonth . "月" . $NowDDay . "日 " . $NowHour . "時" . $NowMin . "分" . $NowSec . "秒";
	}
	else{
		$NowDayTime = $NowYera . "/" . $NowMonth . "/" . $NowDDay . " " . $NowHour . ":" . $NowMin . ":" . $NowSec;
	}

	return $NowDayTime;

}

#==============================================================================
#
#	数値チェック
#
#==============================================================================
sub check_numeric
{
	return ( @_[0] =~ /^[0-9]+$/ );
}

#==============================================================================
#
#	半角英数チェック
#
#==============================================================================
sub check_h_alphanumeric
{
	return ( @_[0] =~ /^[a-zA-Z0-9]+$/ );
}

#==============================================================================
#
#	半角英数記号チェック
#		許可される記号
#		   # ! % & = @ ; : , _ " ' ~ ` < > 
#		   - + * / . ? { } ( ) [ ] ^ $ @ | \ 
#==============================================================================
sub check_h_alphanumeric
{
	return ( @_[0] =~ /^[a-zA-Z0-9#!%&=;:,_"'~`<>\-\+\*\/\.\?\{\}\(\)\[\]\^\@\|\\]+$/ );
}

## 正規表現用に文字列をエスケープ
# 
# @param  $_[0] 文字列
# @return $ret  エスケープした文字列
# 
sub reg_replace {
	
	# 引数取得
	local $ret = $_[0];
	
	# 文字列のエスケープ
	$ret =~ s/[\\\*\+\.\?\{\}\(\)\[\]\^\$\-\|\/]/\\$&/g;
	
	return $ret;
}

## 設定ファイルに設定した有効ドメインかチェック
# 
# @param  $_[0] URL
# @return 1 (有効) | 0 (無効)
# 
sub is_valid_url {
	
	# 引数取得
	local $url = $_[0];
	# URLから付加情報を削除
	$url =~ s/\#.*//;
	$url =~ s/\?.*//;
	
	# 有効ドメイン
	local @chk_domain = @main::P_PrevValidHttpDomain;
	
	# 変数初期化
	local $valid_domain = "";
	local $valid_flg = 0;
	
	# チェック開始
	for (local $cnt = 0 ; $cnt < @chk_domain ; $cnt ++) {
		
		# 有効ドメインの設定値を補正
		$valid_domain = $chk_domain[$cnt];
		$valid_domain =~ s/^\s//;
		$valid_domain =~ s/\s$//;
		$valid_domain =~ s/\/$//;
		
		# 補正したドメインが空の場合はチェックなし
		if ($valid_domain eq "") {
			next;
		}
		
		# 正規表現用のエスケープ
		$valid_domain = &reg_replace($valid_domain);
		
		# チェック
		if ($url =~ /^$valid_domain(\/|$)/) {
			$valid_flg = 1;
			last;
		}
	}
	
	# 絶対パス指定と相対パス指定をチェック
	if ($valid_flg != 1 && ($url =~ /^\// || $url =~ /^\./)) {
		$valid_flg = 1;
	}
	
	# 結果を返す
	return $valid_flg;
}

## HTTPリファラのチェック
# 
# @return 1 (許可ドメイン) | 0 (無効ドメイン)
# 
sub is_valid_referer {
	# HTTPリファラ取得
	if (!exists $ENV{'HTTP_REFERER'} || $ENV{'HTTP_REFERER'} =~ /^\s*$/) {
		# 取得に失敗した場合はエラー
		return 0;
	}
	local $referer = $ENV{'HTTP_REFERER'};
	
	# チェック
	return &is_valid_url($referer);
}

# -- EOF ------------------------------------------------------------------------------------------#
1;