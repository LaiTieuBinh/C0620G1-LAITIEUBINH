package pack_eventcom;
#==============================================================================
#	event_calフォルダーPerl 共通処理
#
#
#	当フォルダー内から共通で呼ばれる処理を記述する。
#
#==============================================================================
use Time::Local;

#==============================================================================
#　固定項目
#==============================================================================
#---曜日テーブル ("日0","月1","火2","水3","木4","金5","土6");
@ArraWeekNm = ("日", "月", "火", "水", "木", "金", "土");

#--エリアテーブル
@ArrArea = ("神戸","阪神南","阪神北","東播磨","北播磨","中播磨","西播磨","但馬","丹波","淡路");
$ArrAreaCnt = 10;

#==============================================================================
#	エリアチェック
#
#	【引数】チェックをする文字列
#
#	【戻値】0	指定された文字列がエリアに存在した
#			1	指定された文字列はエリアに存在しなかった
#
#	【備考】引数で指定された文字列がエリアリストに存在しているかをチェックする
#
#	【作成】06/11/09	エリア引数に無効な文字列を指定された場合のチェック追加
#
#==============================================================================
sub P_ChkStrArea
{
	local( $InStr ) = @_;

	$area_flg = 1;
	for ($idx = 0; $idx < $ArrAreaCnt; $idx++) {
		if( $ArrArea[$idx]  eq $InStr ){
			$area_flg = 0;
			last;
		}
	}

	return $area_flg;

}

#==============================================================================
#	タグの無効化
#
#	【引数】無効化を行なう文字列
#
#	【戻値】タグが無効化された文字列
#
#	【備考】< > & " ' をそれぞれ文字列に変換する
#
#	【作成】06/11/09 表示文字、入力文字のタグを無効にするため
#
#==============================================================================
sub P_HTML_Escapr
{
	local( $InStr ) = @_;

	$InStr =~ s/&/&amp;/g;	#& → &amp;
	$InStr =~ s/</&lt;/ig;		#< → &lt;
	$InStr =~ s/>/&gt;/ig;		#> → &gt;
	$InStr =~ s/"/&quot;/g;	#" → &quot;
	$InStr =~ s/'/&#39;/g;	#' → &#39;

	return $InStr;

}

#==============================================================================
#	カレンダー生成
#
#	【引数】取得する年 西暦4桁
#			取得する月
#			格納先(二次元配列配列)
#			一ヶ月の月週数
#			一週間の日数
#
#	【戻値】0  成功
#			-1 失敗
#
#	【備考】指定された年月の一ヶ月のカレンダーを取得し、二次元配列に格納
#			週は、日曜日から0始まりで、土曜日が6
#
#==============================================================================
sub P_SetCalender
{
	local( $InYera, $InMonth, *AraCalTbl, $InMonthMax, $InWeekMax ) = @_;

	#---引数で指定されたInYera年InMonth月１日の曜日を求める
	$intFstDay = (localtime( timelocal(0, 0, 0, 1, $InMonth - 1, $InYera)))[6];	#曜日引数 ("日0","月1","火2","水3","木4","金5","土6");

	#---引数で指定されたInYera年InMonth月の末日を求める
	$intLastDay = &P_GetLastDay( $InYera, $InMonth);

	#---1日
	$intDays = 1;

	#---カレンダー配列にセット
	for( $idxWeek = 0; $idxWeek < $InMonthMax; $idxWeek++ ){
		for( $idxWday = $intFstDay; $idxWday < $InWeekMax; $idxWday++ ){
			if( $intLastDay >= $intDays ){	#末日チェック
				$AraCalTbl[$idxWeek][$idxWday] = $intDays;
				$intDays = $intDays + 1;
			}
			else{
				$AraCalTbl[$idxWeek][$idxWday] = "";
			}
		}
		$intFstDay = 0;
	}

	return 0;

}

#==============================================================================
#	カレンダーテーブル作成
#
#	【引数】
#			カレンダーデータが格納された配列(二次元配列配列)
#			一ヶ月の月週数
#			一週間の日数
#			現在選択中の年
#			現在選択中の月
#			現在選択中の日
#			現在選択中のエリア
#
#	【戻値】
#			$retStr	カレンダーテーブルタグ
#
#	【備考】
#
#==============================================================================
sub P_HTMLSetCalender{
	local(*AraCalTbl,$InMonthMax,$InWeekMax,$SelYear,$SelMonth,$SelDay,$SelArea) = @_;

	$retStr = "<table width=\"".$main'P_EVT_CAL_TBL_SIZE."\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"calendar\">";
	$retStr .= "<tr>";
	# default
	$retStr .= "<td align=\"center\" valign=\"middle\" class=\"bgcolor\">日</td>";
	$retStr .= "<td align=\"center\" valign=\"middle\" class=\"bgcolor\">月</td>";
	$retStr .= "<td align=\"center\" valign=\"middle\" class=\"bgcolor\">火</td>";
	$retStr .= "<td align=\"center\" valign=\"middle\" class=\"bgcolor\">水</td>";
	$retStr .= "<td align=\"center\" valign=\"middle\" class=\"bgcolor\">木</td>";
	$retStr .= "<td align=\"center\" valign=\"middle\" class=\"bgcolor\">金</td>";
	$retStr .= "<td align=\"center\" valign=\"middle\" class=\"bgcolor\">土</td>";
	# 山梨 ver
	# $retStr .= '<th><img src="/shared/templates/free/images/contents/event_cal_sun.gif" alt="日曜" width="25" height="21" />';
	# $retStr .= '<th><img src="/shared/templates/free/images/contents/event_cal_mon.gif" alt="月曜" width="25" height="21" /></th>';
	# $retStr .= '<th><img src="/shared/templates/free/images/contents/event_cal_tues.gif" alt="火曜" width="25" height="21" /></th>';
	# $retStr .= '<th><img src="/shared/templates/free/images/contents/ecent_cal_wednes.gif" alt="水曜" width="25" height="21" /></th>';
	# $retStr .= '<th><img src="/shared/templates/free/images/contents/ecent_cal_thurs.gif" alt="木曜" width="25" height="21" /></th>';
	# $retStr .= '<th><img src="/shared/templates/free/images/contents/ecent_cal_fri.gif" alt="金曜" width="25" height="21" /></th>';
	# $retStr .= '<th><img src="/shared/templates/free/images/contents/event_cal_satur.gif" alt="土曜" width="25" height="21" /></th>';
	$retStr .= "</tr>";

	#Areaをエンコードする
	$SelArea =~ s/(\W)/'%'.unpack("H2",$1)/ego;

	for($idxWeek = 0;$idxWeek < $InMonthMax;$idxWeek++){
		$retStr .= "<tr>\n";
		for($idxWday = 0;$idxWday < $InWeekMax;$idxWday++){
			#土日カラー
			$week_end_sel = "";
			#日曜
			if($idxWday == 0){$week_end_sel = " class=\"sun\"";}
			#土曜
			else{
				if($idxWday == 6){$week_end_sel = " class=\"sat\"";}
			}
			#カレンダーの選択日
			$today_css_class = "";
			if ( $SelDay == $AraCalTbl[$idxWeek][$idxWday] ) {
				$today_css_class = " class=\"today\"";
			}
			$AraCalTbl[$idxWeek][$idxWday] =~ s/\s*$//;
			#空白セル
			if(length($AraCalTbl[$idxWeek][$idxWday]) <= 0){
				$retStr .= "<td align=\"center\" valign=\"middle\"" . $week_end_sel . ">&nbsp;</td>\n";
			}
			else{
				$retStr .= "<td align=\"center\" valign=\"middle\"" . $week_end_sel . ">";
				if(length($SelArea) > 0){
					$retStr .= "<a href=\"cal_day.cgi?year=" . $SelYear . "&amp;month=" . ($SelMonth + 0) . "&amp;day=" . $AraCalTbl[$idxWeek][$idxWday] . "&amp;area=" . $SelArea . "\"" . $today_css_class . ">";
				}
				else{
					$retStr .= "<a href=\"cal_day.cgi?year=" . $SelYear . "&amp;month=" . ($SelMonth + 0) . "&amp;day=" . $AraCalTbl[$idxWeek][$idxWday] ."\"" . $today_css_class . ">";
				}
				$retStr .=  $AraCalTbl[$idxWeek][$idxWday];
				$retStr .= "</a>\n";
				$retStr .= "</td>\n";
			}
		}
		$retStr .= "</tr>\n";
	}
	$retStr .= "</table>\n";
	return $retStr;
}

#==============================================================================
#
#	カレンダーフッター：前の月リンクを吐き出す
#
#	【引数】遡る前月最高値
#			指定された年
#			指定された月
#
#	【戻値】成功 0
#
#==============================================================================
sub P_HTMLSetCalenderFoot_PreMonth()
{
	local( $PreMaxMonth, $DispYear, $DispMonth, $SelArea, $PreMonthStr ) = @_;
	$retStr = "";

#areaをエンコードする

$SelArea =~ s/(\W)/'%'.unpack("H2", $1)/ego;


	#---現在の年月を取得
	&P_GetNowYYYYMMDD(*NowYear,*NowMonth,*NowDay);

	#---現在の日付から$PreMaxMonthヶ月前を取得
	$PreMonth = ($NowMonth + 0) - $PreMaxMonth;
	$PreYera = $NowYear;
	while($PreMonth <= 0){
		$PreMonth += 12;
		$PreYera -= 1;
	}
	$PreMonth = sprintf( "%2.2d", $PreMonth );
	$PreYYYYMM = ($PreYera . $PreMonth) + 0;

	#---現在表示している年月から一ヶ月前の月を取得
	$OenPreMonth = ($DispMonth + 0) - 1;
	if( $OenPreMonth <= 0 ){
		$OenPreMonth = 12 + ($OenPreMonth);
		$OenPreYear = $DispYear - 1;
	}
	else{
		$OenPreYear = $DispYear;
	}
	$OenPreMonth = sprintf( "%2.2d", $OenPreMonth );
	$OneYYYYMM = ($OenPreYear . $OenPreMonth) + 0;

	#---現在から一ヶ月前の年月が、$PreMaxMonth前の年月を越している場合は、リンクを切る。
	if( $PreYYYYMM > $OneYYYYMM ){
		$retStr = $PreMonthStr."\n";
	}
	else{
		if( length( $SelArea ) > 0 ){
			$retStr = "<a href=\"cal_month.cgi?year=" . $OenPreYear . "&amp;month=" . ($OenPreMonth+0) . "&amp;area=" . $SelArea . "\">".$PreMonthStr."</a>";
		}
		else{
			$retStr = "<a href=\"cal_month.cgi?year=" . $OenPreYear . "&amp;month=" . ($OenPreMonth+0) . "\">".$PreMonthStr."</a>";
		}
	}

	return $retStr;
}


#==============================================================================
#
#	カレンダーフッター：次の月リンクを吐き出す
#
#	【引数】送る次の月最高値
#			指定された年
#			指定された月
#
#	【戻値】成功 0
#
#==============================================================================
sub P_HTMLSetCalenderFoot_NextMonth()
{
	local( $NextMaxMonth, $DispYear, $DispMonth, $SelArea, $NextMonthStr ) = @_;
	$retStr = "";

#areaをエンコードする

$SelArea =~ s/(\W)/'%'.unpack("H2", $1)/ego;

	#---現在の年月を取得
	&P_GetNowYYYYMMDD(*NowYear,*NowMonth,*NowDay);

	#---現在の日付から$NextMaxMonthヶ月後を取得
	$NextMonth = ($NowMonth + 0) + $NextMaxMonth;
	$NextYera = $NowYear;
	while($NextMonth > 12){
		$NextMonth -= 12;
		$NextYera += 1;
	}
	$NextMonth = sprintf( "%2.2d", $NextMonth );
	$NextYYYYMM = ($NextYera . $NextMonth) + 0;

	#---現在表示されている年月から一ヶ月後の月を取得
	$OenNextMonth = ($DispMonth + 0) + 1;
	if( $OenNextMonth > 12 ){
		$OenNextMonth = $OenNextMonth - 12;
		$OenNextYear = $DispYear + 1;
	}
	else{
		$OenNextYear = $DispYear;
	}
	$OenNextMonth = sprintf( "%2.2d", $OenNextMonth );
	$OneYYYYMM = ($OenNextYear . $OenNextMonth) + 0;


	#---現在から一ヶ月前の年月が、$PreMaxMonth前の年月を越している場合は、リンクを切る。
	if( $NextYYYYMM < $OneYYYYMM ){
		$retStr = $NextMonthStr."\n";
	}
	else{
		if( length( $SelArea ) > 0 ){
			$retStr = "<a href=\"cal_month.cgi?year=" . $OenNextYear . "&amp;month=" . ($OenNextMonth+0) . "&amp;area=" . $SelArea . "\">".$NextMonthStr."</a>";
		}
		else{
			$retStr = "<a href=\"cal_month.cgi?year=" . $OenNextYear . "&amp;month=" . ($OenNextMonth+0) . "\">".$NextMonthStr."</a>";
		}
	}

	return $retStr;
}

#==============================================================================
#
#	指定された年月の末日を取得する
#
#	【引数】取得する年
#			取得する月
#
#	【戻値】取得された日
#
#==============================================================================
sub P_GetLastDay()
{
	my $Year	= $_[0];
	my $Month	= $_[1];
	my $RefLastDay = 0;

	# 桁を整える
	$Month = $1 if( length( $Month ) == 2 && $Month =~ /^0(.)$/ );

	# ×年×月の末日を求める
	$RefLastDay = ( 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 )[$Month - 1] + ( $Month == 2 and $Year % 4 == 0 and ( $Year % 400 == 0 or $Year % 100 != 0 ) );

	return $RefLastDay;
}

#==============================================================================
#
#	現在の年月日を取得する
#
#	【引数】取得した年の格納先　西暦４桁
#			取得した月　99
#			取得した日　99
#
#	【戻値】成功 0
#
#==============================================================================
sub P_GetNowYYYYMMDD()
{
	local(*NowYear,*NowMonth,*NowDay) = @_;


	#---現在の年月を取得
	my ( @ltms )	= localtime(time);				# 日時取得
	# 現在の年を取得する
	$NowYear  = sprintf( "%2.2d", $ltms[5]-100 );
	$NowYear += 2000;
	# 現在の月を取得する
	$NowMonth = sprintf( "%2.2d", $ltms[4]+1 );
	#現在の日を取得する
	$NowDay = sprintf("%2.2d",$ltms[3]);

	return 0;
}

# CSVの読み込み
sub csvStrCut
{
	# CSV 文字列( 1行 )
	local ( $_csvStr ) = @_;
	@_ret = ();

	$_csvStr =~ s/\r\n/\n/g;
	$_csvStr =~ s/\r/\n/g;

	while( $_csvStr =~ s/"(.*?)"[\n,]// ) {
		push( @_ret, $1 );
	}

	return @_ret;
}

1;
