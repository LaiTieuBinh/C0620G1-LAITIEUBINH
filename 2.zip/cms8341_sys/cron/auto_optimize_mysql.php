<?php
/*
 *
 */
//外部ファイル読み込み
require (dirname(__FILE__) . "/.htsetting");
global $objCnc;
require_once (APPLICATION_ROOT . "/common/dbcontrol/dac.inc");
$objDac = new dac($objCnc);
?>
#!/usr/local/bin/php
<?php
//テーブル名を取得
$sql = 'SHOW TABLES FROM `' . SET_DBNAME . '`;';
if (!$objDac->execute($sql)) {
	$msg = 'テーブル名の取得に失敗しました。【' . $sql . '】';
	errorWrite($msg);
	echo $msg;
}

//テーブル数分ループ
$table_name = '';
while ($objDac->fetch()) {
	if ($table_name != '') $table_name .= ',';
	$table_name .= '`' . $objDac->fld['Tables_in_' . SET_DBNAME] . '`';
}

//最適化実行
$sql = 'OPTIMIZE TABLE ' . $table_name;
if (!$objDac->execute($sql)) {
	$msg = 'テーブルの最適化に失敗しました。【' . $sql . '】';
	errorWrite($msg);
	echo $msg;
}
?>
