<?php
/*
 * FAQ機能：お問い合わせ情報 集計CSVダウンロードプログラム(クーロン)
 */
//--- 設定ファイル読み込み
require (dirname(__FILE__) . "/.htsetting");

// ** global 宣言 ---------------------------
global $objCnc;
?>
#!/usr/local/bin/php
<?php
// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFaq = new tbl_faq($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$objDept = new tbl_department($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/* ** FTPフラグがOFFの場合は処理を行うことができない ** -------------------------------------------- ** */

if (!FTP_UPLOAD_FLG) _output_error("FTPフラグがオフなので処理を行えませんでした。", TRUE); // ERROR エラー


/* ** 変数・定数 ** -------------------------------------------------------------------------------- ** */

// DB新規登録フラグ
$DB_INSERT_FLG = FLAG_ON;

// ダウンロードしたCSVパス情報
$downloadCSV = array();

// 組織ごとの問い合わせ情報
$chargeData = array();
// 組織情報
$deptMail = array();

// ウェブマスターのメールアドレス
$deptMail[WEB_MASTER_CODE] = array(
		"email" => ""
);

/* ** ウェブマスター情報の取得 ** ------------------------------------------------------------------ ** */

// ウェブマスター検索条件
$objDac->setTableName("tbl_user AS u " . "LEFT JOIN (SELECT item1 FROM tbl_handler " . "WHERE class=" . HANDLER_CLASS_OEPN_FLG . ") AS h ON u.user_id = h.item1");
$where = $objDac->_addslashesC("dept_code", WEB_MASTER_CODE, "=", "TEXT");
$field = "u.*, h.item1";
$sort = "user_id";

// ウェブマスター検索
$objDac->select($where, $field, $sort);
while ($objDac->fetch()) {
	// handler に登録されている場合は公開責任者
	if (strlen($objDac->fld['item1']) > 0) continue;
	// ウェブマスターのアドレスを格納
	$deptMail[WEB_MASTER_CODE] = $objDac->fld;
	// 最初のウェブマスター情報のみ取得
	break;
}

/* ** FTP接続 ** ----------------------------------------------------------------------------------- ** */

// FAQ情報取得
$FTP_INFO = getDefineArray("FTP_INFO");
$FTP = $FTP_INFO["faq"];
$ftpCnc = connectFTP("faq", "nonmove");

// コネクト失敗
if (!$ftpCnc) _output_error("FTPの接続に失敗しました。", TRUE); // ERROR エラー


//	排他制御用フォルダ作成
cx_ftp_mkdir($ftpCnc, FTP_EXCLUSIVE_ROOT_DIR_FAQ);

// 公開サーバのcsvファイルを取得
$sv_file = cx_ftp_nlist($ftpCnc, $FTP['dir']);

// ファイルが取得できない場合は、処理終了
if ($sv_file === FALSE || !is_array($sv_file)) {
	// 排他制御用フォルダ削除
	cx_ftp_rmdir($ftpCnc, FTP_EXCLUSIVE_ROOT_DIR_FAQ);
	// FTP ストリームを閉じる
	cx_ftp_close($ftpCnc);
	// ログに記載
	traceWrite('FTP上のCSVファイルが取得できませんでした。【auto_faqcsv_download.php dir:' . $FTP['dir'] . '】');
	// 処理終了
	exit();
}

foreach ($sv_file as $ftp_path) {
	// CSV 以外のファイルは未処理
	if (!preg_match("/\.csv$/", $ftp_path)) continue;
	
	// CMS側CSV
	$local_path = DOCUMENT_ROOT . DIR_PATH_FAQCSV . basename($ftp_path);
	$local_path = str_replace("//", "/", $local_path);
	
	// FTPダウンロード( サーバー側 -> CMS側 )
	if (cx_ftp_get($ftpCnc, $ftp_path, $local_path, FTP_ASCII)) chmod($local_path, 0777);
	
	// csvファイル選択
	$csvFn = $local_path;
	
	// CSVファイルの存在チェック
	// CSVオープン
	if (($CsvFno = @fopen($csvFn, 'r'))) {
		// CSVの内容
		while ($data = fgetcsv($CsvFno, 4000)) {
			
			// CSVから取得したデータの最適化
			

			// DB登録用配列
			$arrAry = array();
			// 組織情報格納配列
			$d_fld = array();
			// 組織情報取得フラグ
			$dept_get = FLAG_OFF;
			
			// 公開側で行っている円マークのエスケープを解除
			for($i = 0; $i < count($data); $i++)
				$arrAry[$data[$i]] = str_replace("\\\\", "\\", $data[++$i]);
				
			// 登録日がCSV 項目にない場合は指定
			if (!isset($arrAry['regist_datatime'])) $arrAry['regist_datatime'] = 'NOW';
			
			// 組織コードの入力があるかチェック
			if (isset($arrAry['dept_code'])) {
				// 入力された組織コードで検索
				if ($objDept->selectFromCode($arrAry['dept_code']) !== FALSE && $objDept->fld['level'] == 3) {
					// 第３組織の場合は振分組織に指定
					$arrAry['charge'] = $arrAry['dept_code'];
					$d_fld = $objDept->fld;
					$dept_get = FLAG_ON;
				}
				// 登録を行わないため削除
				unset($arrAry['dept_code']);
			}
			// 振分先組織情報を取得していない場合は検索
			if ($dept_get == FLAG_OFF) {
				// 条件
				$where = $objDept->_addslashesC('email', $arrAry['charge']) . // メールアドレス
' AND ' . $objDept->_addslashesC('level', 3); // 第３組織
				// 検索
				$objDept->select($where);
				// 取得
				if ($objDept->fetch()) {
					$arrAry['charge'] = $objDept->fld['dept_code'];
					$d_fld = $objDept->fld;
					$dept_get = FLAG_ON;
				}
			}
			
			// 振分先ごとに登録する内容を保持
			

			// 組織
			if ($dept_get == FLAG_ON) {
				// FAQ情報を格納
				$chargeData[$d_fld['dept_code']][] = $arrAry;
				// 組織情報を格納
				if (!isset($deptMail[$d_fld['dept_code']])) $deptMail[$d_fld['dept_code']] = $d_fld;
			} // ウェブマスター
			else {
				// ウェブマスター用のデータに格納
				$chargeData[WEB_MASTER_CODE][] = $arrAry;
			}
		}
		// CSVクローズ
		@fclose($CsvFno);
		
		// 公開側CSVパス情報の保持
		$downloadCSV[] = $ftp_path;
		
		// CMSサーバに作成したCSVを削除
		@unlink($local_path);
	}
}

/* ** トランザクション開始 ************************************************************************* ** */

$objCnc->begin();

/* ** 登録処理開始 ** ------------------------------------------------------------------------------ ** */

// エラー用
$error_msg = "";

// 振り分け組織ごとに処理
if (count($chargeData) > 0) foreach ($chargeData as $dept_code => $faqFld) {
	
	// ウェブマスター管理フラグ
	$webmasterFlg = ($dept_code == WEB_MASTER_CODE) ? FLAG_ON : FLAG_OFF;
	// 登録日
	$regist_datatime = "";
	// メールに記載する問い合わせ件名
	$mail_question_title = array();
	
	/* ** データベースへの登録 ** ---------------------------------------------------------------------- ** */
	$cnt = 0;
	foreach ($faqFld as $fld) {
		
		// 登録
		

		if (_insert_faq($objFaq, $webmasterFlg, $fld) === FALSE) {
			// ERROR エラー
			$DB_INSERT_FLG = FLAG_OFF;
			$error_msg = "データベース更新登録に失敗しました。【" . $fld['question_title'] . "】";
			break;
		}
		
		// 登録内容でメールに使用する内容を保持
		

		// 登録日（ 初回のみ ）
		if ($cnt == 0) {
			$regist_datatime = $fld['regist_datatime'];
			if ($regist_datatime == "NOW") $regist_datatime = date("Y/m/j H:i:s", time());
			// フォーマット変換
			$regist_datatime = str_replace("/", "-", $regist_datatime);
		}
		// 問い合わせ件名
		$mail_question_title[]['question_title'] = $fld['question_title'];
		
		// カウントアップ
		$cnt++;
	}
	
	// エラーの場合は処理中断
	if ($DB_INSERT_FLG == FLAG_OFF) break;
	
	/* ** メール送信 ** -------------------------------------------------------------------------------- ** */
	
	if (!_send_mail_faq($webmasterFlg, $deptMail[$dept_code], $mail_question_title, $regist_datatime)) {
		// メールの送信に失敗した場合はトレースログに記録
		traceWrite("* MAIL ERROR -- メールの送信に失敗しました。【FROM:" . MAIL_ADDR_FROM . " /TO:" . trim($deptMail[$dept_code]['email']) . "】");
	}

}

/* ** DB登録 後処理 -------------------------------------------------------------------------------- ** */

// 成功
if ($DB_INSERT_FLG == FLAG_ON) {
	// 公開側CSVの削除
	foreach ($downloadCSV as $ftp_path)
		cx_ftp_delete($ftpCnc, $ftp_path);
		// コミット
	$objCnc->commit();
} // 失敗
else {
	// ロールバック
	_transaction_error($objCnc, $error_msg, FALSE); // ERROR エラー
}

/* ** トランザクション終了 ************************************************************************* ** */

// 排他制御用フォルダ削除
cx_ftp_rmdir($ftpCnc, FTP_EXCLUSIVE_ROOT_DIR_FAQ);

/* ** FTP ストリームを閉じる ** -------------------------------------------------------------------- ** */

cx_ftp_close($ftpCnc);

/* ** END ** --------------------------------------------------------------------------------------- ** */

exit();

/* ** ファイル内 関数 ** --------------------------------------------------------------------------- ** */

/** トランザクション中のエラー
 * 
 * @param	$objCnc		DBコネクトクラス
 * @param	$error_msg	エラーメッセージ
 * @param	$exit		プログラム終了フラグ（TRUE : FALSE ）
 * 
 * @return	なし
 */
function _transaction_error($objCnc, $error_msg, $exit = TRUE) {
	// ロールバック
	$objCnc->rollback();
	_output_error($error_msg, $exit);
}
function _output_error($error_msg, $exit = TRUE) {
	// エラー出力(画面)
	echo ("<br>" . $error_msg);
	// エラー出力(ログ)
	traceWrite("* CRON ERROR -- " . $error_msg);
	// 終了
	if ($exit) exit();
}

/** DBへの登録
 * 
 * @param	$objFaq		Faqクラス【DB】
 * @param	$webmaster	ウェブマスター用の登録の場合は【FLAG_ON】、組織振り分けの場合は【FLAG_OFF】
 * @param	$fld		登録する情報配列（ $fld[カラム名] = 値 ）
 * 
 * @return	$objFaq->update()
 */
function _insert_faq($objFaq, $webmaster, $fld) {
	
	// 更新用配列作成
	if ($webmaster == FLAG_ON) {
		// ウェブマスター
		$fld['status'] = FAQ_STATUS_ADMIN_CONTROL;
		$fld['charge'] = NULL;
	}
	else {
		// 組織
		$fld['status'] = FAQ_STATUS_NOT_READ;
		$fld['distribute'] = FAQ_DISTRIBUTE_CRON;
	}
	
	// 更新
	return $objFaq->insert($fld);
}

/** メールの送信
 * 
 * @param	$webmaster	ウェブマスター用の登録の場合は【FLAG_ON】、組織振り分けの場合は【FLAG_OFF】
 * @param	$dept		tbl_departmentから取得したデータ配列
 * @param	$q_title	問い合わせ件名の配列
 * @param	$regtime	tbl_faqより取得した登録日
 * 
 * @return	send_mail()【CMS】
 */
function _send_mail_faq($webmaster, $dept, $q_title, $regtime) {
	
	// メールアドレスが指定されていない場合はメール送信なし
	if (trim($dept['email']) == "") return TRUE;
	//メール本文作成
	$mail_fld = array();
	$mail_fld['url'] = HTTP_REAL_ROOT;
	$mail_fld['cms_url'] = HTTP_ROOT . RPW;
	$mail_fld['now_date'] = date('Y-m-d H:i:s');
	$mail_fld['dept_name'] = ($webmaster == FLAG_ON) ? "管理者" : $dept['dept_name'];
	$mail_fld['question_title_group'] = $q_title;
	$mail_fld['faq_regist_datatime'] = $regtime;
	$head = get_mail_str($mail_fld, MAIL_SUBJECT_FAQ);
	$body = get_mail_str($mail_fld, MAIL_BODY_FAQ);
	
	// メール送信
	return send_mail($dept['email'], MAIL_ADDR_FROM, $head, $body);
}
?>