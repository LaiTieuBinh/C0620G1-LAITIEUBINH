<?php
/*
 * お問い合わせ(アンケート) : サーバーに保存されているCSVの定期削除
 */
//--- 設定ファイル読み込み
require (dirname(__FILE__) . "/.htsetting");
// ** global 宣言 ---------------------------
global $objCnc;
?>
#!/usr/local/bin/php
<?php

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

// クーロンで削除するファイルの拡張子
$DELETE_FILES_EXTE = array(
		"csv"
);

// 設定値が空の場合は処理を行わない
if (strlen(AUTO_DELETE_FTP_DAY_MAIL) == 0 || AUTO_DELETE_FTP_DAY_MAIL < 0) exit();

// FTPが使用できる場合のみ処理
if (FTP_UPLOAD_FLG) {
	// アンケートのFTP接続
	$FTP_INFO = getDefineArray("FTP_INFO");
	$FTP = $FTP_INFO["enquete"];
	$ftpCnc = connectFTP("enquete", "nonmove");
	// FTP接続している
	if ($ftpCnc != "") {
		
		$objPage->setTableName(PUBLISH_TABLE);
		
		// 問い合わせページ情報の取得
		$where = $objPage->_addslashesC("template_kind", TEMPLATE_KIND_ENQUETE); // アンケート・問い合わせ
		$where .= " AND " . $objPage->_addslashesC("enquete_kind", ENQ_KIND_MAIL); // 問い合わせ
		$where .= " AND " . $objPage->_addslashesC("work_class", WORK_CLASS_NEW, "<>"); // 新規作成以外(非公開・削除待ちも対象)
		

		$objPage->select($where, "page_id");
		
		// プログラムで使用するために加工
		$ftp_files_detail = array();
		while ($objPage->fetch()) {
			// 公開サーバのcsvファイルを取得
			$ftp_files = cx_ftp_nlist($ftpCnc, FTP_MAIL_CSV_DIR_ENQUETE . "/" . $objPage->fld['page_id']);
			// ファイル一覧が取得できなかった場合は、continue;
			if($ftp_files === FALSE || !is_array($ftp_files)){
				// ログに記載
				traceWrite('FTP上のCSVファイルが取得できませんでした。【auto_delete_ftp_mail.php page_id:' . $objPage->fld['page_id'] . '】');
				continue;
			}
			foreach ($ftp_files as $ftp_path) {
				// 配列の作成
				$ftp_files_detail[] = array(
						// 保存日
						"date" => preg_replace("/\..*$/", "", basename($ftp_path)), 
						// ファイルパス
						"path" => $ftp_path, 
						// 拡張子
						"exte" => preg_replace("/^.*\.(.*)$/", "$1", basename($ftp_path))
				);
			}
		}
		
		// 現在時間
		$nowDateTime = time();
		
		// サーバ上から削除しないCSV(日付)
		$nonDeleteDate = array();
		$nonDeleteDate[] = date("Ymd", $nowDateTime);
		for($i = 1; $i <= AUTO_DELETE_FTP_DAY_MAIL; $i++) {
			$nonDeleteDate[] = date("Ymd", strtotime("-" . $i . " day", $nowDateTime));
		}
		
		foreach ($ftp_files_detail as $detail) {
			// 未削除日付のCSVでない場合のみ
			if (!in_array($detail['date'], $nonDeleteDate) && in_array($detail['exte'], $DELETE_FILES_EXTE)) {
				// 削除::削除に失敗した場合はトレースログに記録
				if (!cx_ftp_delete($ftpCnc, $detail['path'])) {
					traceWrite("ERROR::CSVファイルの削除に失敗しました。【" . $detail['path'] . "】");
				}
			}
		}
		
		// FTP ストリームを閉じる
		cx_ftp_close($ftpCnc);
	}
}
?>

