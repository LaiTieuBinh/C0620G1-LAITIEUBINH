<?php
/*
 * 広告掲載機能：フィードバック集計 集計CSVダウンロードプログラム(クーロン)
 */
//--- 設定ファイル読み込み
require (dirname(__FILE__) . "/.htsetting");
global $objCnc;
?>
#!/usr/local/bin/php
<?php

// FTP制御フラグ チェック true なら CSV ダウンロード
if (FTP_UPLOAD_FLG) {
	// フィードバック集計情報取得
	$FTP_INFO = getDefineArray("FTP_INFO");
	$FTP = $FTP_INFO["feedback"];
	$ftpCnc = connectFTP("feedback", "nonmove");
	if ($ftpCnc != "") {
		
		//CMS側にフォルダがなければ作成
		if (!@file_exists(DOCUMENT_ROOT . DIR_PATH_FEEDBACKCSV)) {
			mkdir(DOCUMENT_ROOT . DIR_PATH_FEEDBACKCSV, 0777);
		}
		
		// 公開サーバのcsvファイルを取得
		$sv_file = cx_ftp_nlist($ftpCnc, $FTP['dir']);
		
		// csvファイルがあった場合
		if (count($sv_file) != 0) {
			// ダウンロード
			foreach ($sv_file as $ftp_path) {
				// CMS側CSV
				$local_path = DOCUMENT_ROOT . DIR_PATH_FEEDBACKCSV . basename($ftp_path);
				$local_path = str_replace("//", "/", $local_path);
				// FTPダウンロード( サーバー側 -> CMS側 )
				if (cx_ftp_get($ftpCnc, $ftp_path, $local_path, FTP_ASCII)) {
					@chmod($local_path, 0777);
				}
				// 公開側CSV削除
				$target = reg_replace(".csv");
				if (preg_match("/" . $target . "$/i", $ftp_path)) {
					cx_ftp_delete($ftpCnc, $ftp_path);
				}
			}
			
			//ページID毎にCSVファイルを作成
			$csv_file = DOCUMENT_ROOT . DIR_PATH_FEEDBACKCSV . "feedback.csv";
			
			$csvstr = array();
			$ary = array();
			if (($CsvFno = fopen($csv_file, 'r'))) {
				while ($data = fgetcsv($CsvFno, 4000)) {
					if (preg_match("/^[0-9]+$/", $data[0])) {
						$csvstr[] = $data;
						if (!in_array($data[0], $ary)) {
							$ary[] = $data[0];
						}
					}
				}
				fclose($CsvFno);
			}
			//正しいデータが取れなかったら処理終了
			if (count($csvstr) == 0) {
				unlink(DOCUMENT_ROOT . DIR_PATH_FEEDBACKCSV . "feedback.csv");
				cx_ftp_close($ftpCnc);
				exit();
			}
			//ページIDの昇順で並び替え
			foreach ($csvstr as $key => $row) {
				$foo[$key] = $row[0];
			}
			array_multisort($foo, SORT_ASC, $csvstr);
			sort($ary);
			
			unlink(DOCUMENT_ROOT . DIR_PATH_FEEDBACKCSV . "feedback.csv");
			
			//CSV出力
			$cnt = 0;
			for($i = 0; $i < count($csvstr); $i++) {
				if ($ary[$cnt] == $csvstr[$i][0]) {
					$csvwrite[] = $csvstr[$i];
				}
				else {
					if (!feeb_create_Csv($ary[$cnt] . ".csv", $csvwrite, DIR_PATH_FEEDBACKCSV, $char_code = "utf-8", $escChar = "\"")) {
						echo ($ary[$cnt] . ".csvの出力に失敗しました。<br />");
					}
					$cnt++;
					$csvwrite = array();
					$csvwrite[] = $csvstr[$i];
				}
			}
			if (count($csvwrite) != 0) {
				feeb_create_Csv($ary[$cnt] . ".csv", $csvwrite, DIR_PATH_FEEDBACKCSV, $char_code = "utf-8", $escChar = "\"");
			}
		}
		//FTP ストリームを閉じる
		if ($ftpCnc != "") {
			cx_ftp_close($ftpCnc);
		}
	}
}
function feeb_create_Csv($file_name, $data_ary, $file_path, $char_code, $escChar = "") {
	//引数のチェック
	if (!isset($file_name) || $file_name == "") return false;
	if (!isset($data_ary) || !is_array($data_ary)) return false;
	//変数の指定
	$csv_str = "";
	//CSV作成処理
	//データ部分の作成
	foreach ($data_ary as $data) {
		foreach ($data as $val) {
			$csv_str .= csvWrite($val, $escChar) . ',';
		}
		$csv_str .= "\n";
	}
	//CSV出力処理
	$encode = mb_detect_encoding($csv_str, "ASCII,JIS,UTF-8,SJIS-WIN,SJIS,EUCJP-WIN,EUC_JP");
	if (strtoupper($char_code) != $encode) $csv_str = mb_convert_encoding($csv_str, $char_code, $encode);
	
	$to_csv_path = DOCUMENT_ROOT . $file_path . '/' . $file_name;
	$to_csv_path = str_replace('//', '/', $to_csv_path);
	if (!mkNewDirectory($to_csv_path)) return FALSE;
	$fp = fopen($to_csv_path, 'a', 0777);
	if (fwrite($fp, $csv_str) === false) {
		if (isset($fp) && $fp != "") @fclose($fp);
		return FALSE;
	}
	fclose($fp);
	return true;
}
?>
