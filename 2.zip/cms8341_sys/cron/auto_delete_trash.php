<?php
/*
 * periodic deletion of recycle bin
 */
// Read configuration file
require (dirname(__FILE__) . "/.htsetting");

?>
#!/usr/local/bin/php
<?php

// do not process when trash option is disabled 
if (ENABLE_OPTION_TRASH != true) {
	exit();
}

// If the setting value is empty, no processing is performed
if (strlen(DELETED_PAGE_KEEPING_TERM) == 0 || DELETED_PAGE_KEEPING_TERM < 0) {
	exit();
}

// current time
$nowDateTime = time();
$deleteDate = date("Ymd", strtotime("-" . DELETED_PAGE_KEEPING_TERM . " day", $nowDateTime));

// get array folder in trash
$folder_arr = getListZip(TRASH_ROOT);
// sort
array_multisort($folder_arr, SORT_ASC);

foreach ($folder_arr as $folder_name) {
	$folderDate = substr($folder_name, 0, 8);
	if ($folderDate <= $deleteDate) {
		// trace log
		$msg = date('Y/m/d H:i:s') . " " . $folder_name;
		trashWrite($msg);
		unlink(DOCUMENT_ROOT . TRASH_ROOT . "/" . $folder_name);
	} else {
		break;
	}
}

function trashWrite($msg) {
	// 定数の宣言
	// ログファイルのパス
	$LOG_FILE_PATH = TRASH_LOG_DIR . TRASH_LOG_FILE;
	
	// ログ用フォルダがない場合は作成
	if (!is_dir(TRASH_LOG_DIR)) {
		@mkdir(TRASH_LOG_DIR, 0777);
		@chmod(TRASH_LOG_DIR, 0777);
	}
	
	// ログファイルの確認
	if (@is_file($LOG_FILE_PATH)) {
		// ログファイルのサイズを取得
		$file_size = @filesize($LOG_FILE_PATH);
		// ログファイルのサイズがTRASH_LOG_MAXSIZE以上だった場合
		if ($file_size > TRASH_LOG_MAXSIZE) {
			// ログファイルをリネームし、新しいログファイルを作成する
			$bak_file = TRASH_LOG_DIR . '/trash' . @date('YmdHis') . '.log';
			@rename($LOG_FILE_PATH, $bak_file);
			@chmod($bak_file, 0777);
		}
	}
	
	// ファイルオープンして内容を書き込む
	$fp = @fopen($LOG_FILE_PATH, 'a', 0777);
	@fwrite($fp, $msg . "\n");
	@fclose($fp);
	@chmod($LOG_FILE_PATH, 0777);
	
	return TRUE;
}

function getListZip($current_dir) {
	$list_zip = array();
	if ($dh = @opendir(DOCUMENT_ROOT . $current_dir)) {
		//ファイル数分ループ
		while (($path = @readdir($dh)) !== false) {
			//「.」「..」は無視する
			if (in_array($path, array(
						".",
						".."
					))) {
				continue;
			}

			// get file which filename is a valid datetime format
			if (validateDate(substr($path, 0, 12))) {
				$list_zip[] = $path;
			}
		}
		//フォルダクローズ
		@closedir($dh);
	}

	return $list_zip;
}

?>

