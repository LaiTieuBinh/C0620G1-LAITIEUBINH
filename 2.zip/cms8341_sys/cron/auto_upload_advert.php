<?php
/*
 * 広告エリアを含むページの再公開処理
 */
//外部ファイル読み込み
require_once (dirname(__FILE__) . "/.htsetting");
global $objCnc;
?>
#!/usr/local/bin/php
<?php
require_once (APPLICATION_ROOT . "/common/dbcontrol/tbl_page.inc");
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . "/common/dbcontrol/tbl_advert_area.inc");
$objAdArea = new tbl_advert_area($objCnc);
require_once (APPLICATION_ROOT . "/common/dbcontrol/dac.inc");
$objDac = new dac($objCnc);
$upload_page = array();
$upload_csv = array();

// 排他制御 -----------------------------------------
if(lock_file_management('lock_retry') === FALSE) {
	//エラーログ出力
	errorWrite("自動アップロード : リトライ回数が上限に達しました");
	exit();
}
$where = $objDac->_addslashesC("class", HANDLER_CLASS_ADVERT_P1);
$objDac->setTableName("tbl_handler");
$objDac->select($where);
while ($objDac->fetch()) {
	if ($objPage->selectFromID($objDac->fld['item1']) === FALSE) continue;
	if ($objPage->fld['work_class'] != WORK_CLASS_PUBLISH) continue;
	if ($objPage->fld['close_flg'] == FLAG_ON) continue;
	if ($objAdArea->selectFromID($objDac->fld['item2']) === FALSE) continue;
	// ページ出力されていない公開中ページの場合
	if (isset($objPage->fld['output_html_flg']) && $objPage->fld['output_html_flg'] == FLAG_OFF) continue;
	// 配信形式がCSV形式の場合は定期公開しない
	if ($objAdArea->fld['delivery_from'] == ADVERT_DELIVERY_FROM_CSV) $upload_csv[$objAdArea->fld['area_id']] = $objPage->fld['page_id'];
	else $upload_page[$objPage->fld['page_id']] = $objPage->fld['file_path'];
}

//ページ生成+公開処理
if (!SFTP_FLG) {
	$ftpCnc = connectFTP("cms");
	if (ENABLE_OPTION_ADVERT) $ftpCgiCnc = connectFTP("click_cgi");
}
$out_errmsg = '';
//CSVの更新
foreach ($upload_csv as $area_id => $pid) {
	if (SFTP_FLG) {
		$ftpCnc = connectFTP("cms");
		if (ENABLE_OPTION_ADVERT) $ftpCgiCnc = connectFTP("click_cgi");
	}
	advert_Upload($ftpCnc, $pid, $out_errmsg);
	// FTP ストリームを閉じる
	if (SFTP_FLG && FTP_UPLOAD_FLG) {
		cx_ftp_close($ftpCnc);
		if (ENABLE_OPTION_ADVERT) cx_ftp_close($ftpCgiCnc);
	}
}
//ページの更新
foreach ($upload_page as $pid => $page_path) {
	if (SFTP_FLG) {
		$ftpCnc = connectFTP("cms");
		if (ENABLE_OPTION_ADVERT) $ftpCgiCnc = connectFTP("click_cgi");
	}
	create_html($pid, $page_path, $objCnc, $ftpCnc, $out_errmsg, true);
	// FTP ストリームを閉じる
	if (SFTP_FLG && FTP_UPLOAD_FLG) {
		cx_ftp_close($ftpCnc);
		if (ENABLE_OPTION_ADVERT) cx_ftp_close($ftpCgiCnc);
	}
}
// FTP ストリームを閉じる
if (!SFTP_FLG && FTP_UPLOAD_FLG) {
	cx_ftp_close($ftpCnc);
	if (ENABLE_OPTION_ADVERT) cx_ftp_close($ftpCgiCnc);
}
// 排他制御解除
lock_file_management('unlock');
?>
