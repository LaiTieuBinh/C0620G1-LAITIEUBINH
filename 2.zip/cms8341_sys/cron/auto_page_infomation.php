<?php
/*
 *
 */
//--- 設定ファイル読み込み
require (dirname(__FILE__) . "/.htsetting");
global $objCnc;
?>
#!/usr/local/bin/php
<?php
// メール送信フラグがoffなら終了
if (MAIL_FLG_CLOSEPAGE == false) exit();

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');

// 公開終了が近いページの検索
$objPage = new tbl_page($objCnc);
$fromDate = date("Y-m-d", strtotime("+" . MAIL_INFO_COLSEPAGE_DAYS . " day"));
$endDay = MAIL_INFO_COLSEPAGE_DAYS + 1;
$toDate = date("Y-m-d", strtotime("+" . $endDay . " day"));
$where = $objPage->_addslashesC("work_class", WORK_CLASS_PUBLISH);
$where .= " AND " . $objPage->_addslashesC("publish_end", $fromDate, ">=", "DATE");
$where .= " AND " . $objPage->_addslashesC("publish_end", $toDate, "<", "DATE");
$order = "user_id";
$objPage->setTableName(PUBLISH_TABLE);
$objPage->select($where, "*", $order);

// ユーザIDごとの配列を生成
if ($objPage->getRowCount() == 0) exit();
$pageAry = array();
while ($objPage->fetch()) {
	$fld = $objPage->fld;
	if (!isset($pageAry[$fld['user_id']]) || !is_array($pageAry[$fld['user_id']])) {
		$pageAry[$fld['user_id']] = array();
	}
	array_push($pageAry[$fld['user_id']], $fld);
}

// ユーザIDごとにメールを送信
foreach ($pageAry as $user_id => $pages) {
	$objDac = new dac($objCnc);
	$where = $objDac->_addslashesC("user_id", $user_id);
	$objDac->setTableName("tbl_user");
	$objDac->select($where);
	if ($objDac->getRowCount() == 0) {
		echo "ページ作成者が存在しないのでメール送信が出来ませんでした【user_id:" . $user_id . "】";
		continue;
	}
	$objDac->fetch();
	$mFld = $objDac->fld;
	
	$mail_fld = array();
	$mail_fld['cms_url'] = HTTP_ROOT . RPW;
	$mail_fld['url'] = HTTP_REAL_ROOT;
	$mail_fld['now_date'] = date('Y-m-d H:i:s');
	$mail_fld['dept_name'] = $mFld['dept_name'];
	$mail_fld['user_name'] = $mFld['name'];
	$mail_fld['page_group_info'] = $pages;
	$head = get_mail_str($mail_fld, MAIL_SUBJECT_CLOSEPAGE);
	$body = get_mail_str($mail_fld, MAIL_BODY_CLOSEPAGE);
	send_mail($mFld['email'], MAIL_ADDR_FROM, $head, $body);
}

?>
