<?php
/*
 * 広告掲載機能：クリック集計 集計CSVダウンロードプログラム(クーロン)
 */
//--- 設定ファイル読み込み
require (dirname(__FILE__) . "/.htsetting");
global $objCnc;
?>
#!/usr/local/bin/php
<?php

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_advert_area.inc'); // 広告エリアクラス
$objAdArea = new tbl_advert_area($objCnc);

// FTP制御フラグ チェック true なら CSV ダウンロード
if (FTP_UPLOAD_FLG) {
	// クリック集計情報取得
	$FTP_INFO = getDefineArray("FTP_INFO");
	$FTP = $FTP_INFO["clicktotal"];
	$ftpCnc = connectFTP("clicktotal", "nonmove");
	if ($ftpCnc != "") {
		// DBからエリア情報全件取得
		$objAdArea->select("", "area_id");
		// DBに登録されている 広告エリアID.csvをダウンロード
		$file = array();
		$sv_file = array();
		while ($objAdArea->fetch()) {
			// エリア ID 取得
			// csv名は エリアID.csv
			$file[] = $objAdArea->fld['area_id'] . '.csv';
			//「cx_ftp_nlist」が使えない場合は、エリア名のCSVを強制ダウンロード
			if (ADVERT_CSV_DOWNLOAD_NLIST_NONE) {
				// 公開サーバのcsvファイルを取得
				$sv_file[] = $objAdArea->fld['area_id'] . '.csv';
			}
		}
		
		if (!ADVERT_CSV_DOWNLOAD_NLIST_NONE) {
			// 公開サーバのcsvファイルを取得
			$sv_file = cx_ftp_nlist($ftpCnc, $FTP['dir']);
		}
		
		// ダウンロード
		foreach ($sv_file as $ftp_path) {
			
			if (ADVERT_CSV_DOWNLOAD_NLIST_NONE) $ftp_path = $FTP['dir'] . '/' . $ftp_path;
			// CMS側CSV
			$local_path = DOCUMENT_ROOT . DIR_PATH_CLICKTOTALCSV . basename($ftp_path);
			$local_path = str_replace("//", "/", $local_path);
			
			if (in_array(basename($ftp_path), $file)) {
				// FTPダウンロード( サーバー側 -> CMS側 )
				if (cx_ftp_get($ftpCnc, $ftp_path, $local_path, FTP_ASCII)) {
					@chmod($local_path, 0777);
				}
			}
			else {
				// 公開側CSV削除
				$target = reg_replace(".csv");
				if (preg_match("/" . $target . "$/i", $ftp_path)) {
					cx_ftp_delete($ftpCnc, $ftp_path);
					// CMS側にも存在するなら削除
					if (@file_exists($local_path)) {
						@unlink($local_path);
					}
				}
			}
		}
		// FTP ストリームを閉じる
		if (FTP_UPLOAD_FLG) cx_ftp_close($ftpCnc);
	}
}
?>
