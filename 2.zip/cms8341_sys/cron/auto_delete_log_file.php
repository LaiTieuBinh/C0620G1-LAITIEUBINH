#!/usr/local/bin/php
<?php
/*
 * 保存期間が経過したログファイルを削除する
 */
// 外部ファイル読み込み
require_once (dirname(__FILE__) . "/.htsetting");

// 保存期間が経過したログファイルを削除する
deleteOldTraceLogFile();
?>
