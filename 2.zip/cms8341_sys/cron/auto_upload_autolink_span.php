#!/usr/local/bin/php
<?php
/*
 * 自動リンクを掲載期間によって再公開する
 */

//外部ファイル読み込み
require_once (dirname(__FILE__) . "/.htsetting");
global $objCnc;
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
require_once (APPLICATION_ROOT . "/common/dbcontrol/tbl_page.inc");
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_auto_link.inc');
$objAutoLink = new tbl_auto_link($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
$objKanko = new tbl_kanko($objCnc);

// 排他制御 -----------------------------------------
if(lock_file_management('lock_retry') === FALSE) {
	//エラーログ出力
	errorWrite("自動アップロード : リトライ回数が上限に達しました");
	exit();
}

//変数の初期化
$ftpCnc = NULL;
$ftpCgiCnc = NULL;
$success_page_id_ary = array();
$allUploadPages = array();
$out_errmsg = "";

//FTP接続
if (!SFTP_FLG && FTP_UPLOAD_FLG) {
	set_ftp_state('connect');
}

//掲載期間が指定されている自動リンクを取得
$where = $objAutoLink->_addslashesC('`condition`', "%w_publish_span_type=%", 'LIKE');
$objAutoLink->select($where);
//取得した自動リンク数分ループ
while ($objAutoLink->fetch()) {
	//自動リンクが設定されているページの取得
	$objHandler->selectAutoLinkPageFromAlinkID($objAutoLink->fld['a_link_id']);
	//取得したページ数分ループ
	while ($objHandler->fetch()) {
		//変数の取得
		$page_id = $objHandler->fld['item1'];
		$limit = $objHandler->fld['item4'];
		
		//昨日の一覧内容
		//修正内容の作成
		$correction = array(
				'mode' => "public", 
				'prev_mode' => "", 
				'publish_span_to_days' => date('Y-m-d H:i:s', mktime(date('H'), date('i'), date('s'), date('m'), date('d') - 1, date('Y')))
		);
		//ページ取得
		$yesterday = getAutolinkPages($objAutoLink->fld['a_link_id'], $limit, $page_id, $correction);
		$temp_yesterday = array();
		foreach ($yesterday as $fld) {
			$temp_yesterday[] = $fld['page_id'];
		}
		$yesterday = $temp_yesterday;
		//本日の一覧内容
		//修正内容の作成
		$correction = array(
				'mode' => "public", 
				'prev_mode' => ""
		);
		//ページ取得
		$today = getAutolinkPages($objAutoLink->fld['a_link_id'], $limit, $page_id, $correction);
		$temp_today = array();
		foreach ($today as $fld) {
			$temp_today[] = $fld['page_id'];
		}
		$today = $temp_today;
		
		//リストの数が多い方を$array1とする
		if (count($yesterday) < count($today)) {
			$array1 = $today;
			$array2 = $yesterday;
		}
		else {
			$array1 = $yesterday;
			$array2 = $today;
		}
		//昨日のページ一覧と本日のページ一覧を比較する
		if (count(array_diff($array1, $array2)) != 0) {
			$success_page_id_ary[] = $page_id;
		}
	}
}

//キャッシュを消去
if (isset($_SESSION['temp']['l_navi'])) {
	unset($_SESSION['temp']['l_navi']);
}

//公開するページ数分ループ
foreach ($success_page_id_ary as $page_id) {
	//公開するページか確認
	if (!is_output_html($page_id)) {
		continue;
	}
	//ページ情報を取得
	if ($objPage->selectFromID($page_id, PUBLISH_TABLE)) {
		// 公開するページか確認
		if ($objPage->fld['work_class'] == WORK_CLASS_NEW) continue;
		if ($objPage->fld['close_flg'] == FLAG_ON) continue;
		//トランザクション処理開始
		$objCnc->begin();
		//更新日の更新
		$ary = array(
				'page_id' => $page_id, 
				'update_datetime' => 'NOW'
		);
		if (!$objPage->update($ary)) {
			$objCnc->rollback();
			traceWrite("自動リンクページの公開に失敗しました。【" . $page_id . "】");
			errorWrite("自動リンクページの公開に失敗しました。【" . $page_id . "】");
			continue;
		}
		
		//ページ情報の再生成
		$objPage->selectFromID($page_id, PUBLISH_TABLE);
		$_SESSION['temp']['publish_page'] = $objPage->fld;
		
		$objPage->selectFromID($page_id, WORK_TABLE);
		$_SESSION['temp']['work_page'] = (isset($objPage->fld)) ? $objPage->fld : "";
		
		$objKanko->selectFromPID($page_id, '', PUBLISH_TABLE);
		$_SESSION['temp']['publish_kanko'] = array();
		while ($objKanko->fetch()) {
			$_SESSION['temp']['publish_kanko'][$objKanko->fld['item']] = $objKanko->fld;
		}
		
		$objKanko->selectFromPID($page_id, '', WORK_TABLE);
		$_SESSION['temp']['work_kanko'] = array();
		while ($objKanko->fetch()) {
			$_SESSION['temp']['work_kanko'][$objKanko->fld['item']] = $objKanko->fld;
		}
		
		$objHandler->selectAutoLinkFromPID($fld['page_id'], PUBLISH_TABLE);
		$_SESSION['temp']['publish_page_a_link'] = array();
		while ($objHandler->fetch()) {
			$_SESSION['temp']['publish_page_a_link'] = $objHandler->fld['item2'];
		}
		
		$objHandler->selectAutoLinkFromPID($fld['page_id'], WORK_TABLE);
		$_SESSION['temp']['work_page_a_link'] = array();
		while ($objHandler->fetch()) {
			$_SESSION['temp']['work_page_a_link'] = $objHandler->fld['item2'];
		}
		
		//FTP接続
		if (SFTP_FLG && FTP_UPLOAD_FLG) {
			set_ftp_state('connect');
		}
		//ページの公開処理
		if (!create_html($page_id, $_SESSION['temp']['publish_page']['file_path'], $objCnc, $ftpCnc, $out_errmsg, true)) {
			traceWrite("自動リンクページの公開に失敗しました。【" . $page_id . "】");
			errorWrite("自動リンクページの公開に失敗しました。【" . $page_id . "】");
			//FTP切断
			if (SFTP_FLG && FTP_UPLOAD_FLG) {
				set_ftp_state('close');
			}
			continue;
		}
		//FTP切断
		if (SFTP_FLG && FTP_UPLOAD_FLG) {
			set_ftp_state('close');
		}
		
		//影響する自動リンクページを再公開する
		$allUploadPages = array();
		//影響する自動リンクページを取得
		get_autolink_related_pages((array) $page_id, FLAG_OFF, $allUploadPages, FLAG_ON);
		
		//キャッシュを消去
		if (isset($_SESSION['temp']['l_navi'])) {
			unset($_SESSION['temp']['l_navi']);
		}
		
		//関連するページの再公開
		foreach ($allUploadPages as $page_id) {
			//公開するページか確認
			if (!is_output_html($page_id)) {
				continue;
			}
			
			//ページ情報を取得
			if ($objPage->selectFromID($page_id, PUBLISH_TABLE)) {
				// 公開するページか確認
				if ($objPage->fld['work_class'] == WORK_CLASS_NEW) continue;
				if ($objPage->fld['close_flg'] == FLAG_ON) continue;
				
				$pFld = $objPage->fld;
				
				//更新日の更新
				$ary = array(
						'page_id' => $page_id, 
						'update_datetime' => 'NOW'
				);
				if (!$objPage->update($ary)) {
					$objCnc->rollback();
					traceWrite("自動リンクページの公開に失敗しました。【" . $page_id . "】");
					errorWrite("自動リンクページの公開に失敗しました。【" . $page_id . "】");
					continue;
				}
				
				//FTP接続
				if (SFTP_FLG && FTP_UPLOAD_FLG) {
					set_ftp_state('connect');
				}
				//ページの公開処理
				if (!create_html($page_id, $pFld['file_path'], $objCnc, $ftpCnc, $out_errmsg, true)) {
					traceWrite("自動リンク関連ページの公開に失敗しました。【" . $page_id . "】");
					errorWrite("自動リンク関連ページの公開に失敗しました。【" . $page_id . "】");
					//FTP切断
					if (SFTP_FLG && FTP_UPLOAD_FLG) {
						set_ftp_state('close');
					}
					continue;
				}
				//FTP切断
				if (SFTP_FLG && FTP_UPLOAD_FLG) {
					set_ftp_state('close');
				}
			}
		}
		//コミット
		$objCnc->commit();
	}
}

//FTP切断
if (!SFTP_FLG && FTP_UPLOAD_FLG) {
	set_ftp_state('close');
}
//排他制御終了
lock_file_management('unlock');
//処理終了
exit();

/**
 * FTPの接続、切断を行う
 * @param $mode 処理モード 'connect':接続を行う 'close':接続を切断する
 * @return 成功時にはTRUE、そうでない場合はFALSEを返す
 */
function set_ftp_state($mode) {
	//グローバル変数の読み込み
	global $ftpCnc;
	global $ftpCgiCnc;
	
	//FTP接続を行う
	if ($mode == 'connect') {
		if (($ftpCnc = connectFTP("cms")) === FALSE) {
			return FALSE;
		}
		//広告オプションがTRUEの場合
		if (ENABLE_OPTION_ADVERT) {
			if (($ftpCgiCnc = connectFTP("click_cgi")) === FALSE) {
				return FALSE;
			}
		}
	}
	//FTP接続を切断する
	else {
		cx_ftp_close($ftpCnc);
		if (ENABLE_OPTION_ADVERT) {
			//広告オプションがTRUEの場合
			cx_ftp_close($ftpCgiCnc);
		}
	}
	return TRUE;
}
?>
