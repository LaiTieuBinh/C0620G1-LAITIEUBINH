<?php
/*
 *
 */
//--- 設定ファイル読み込み
require (dirname(__FILE__) . "/.htsetting");
global $objCnc;
?>
#!/usr/local/bin/php
<?php
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

// FTPアップロード
if (FTP_UPLOAD_FLG) {
	$FTP_INFO = getDefineArray("FTP_INFO");
	$FTP = $FTP_INFO["enquete"];
	$ftpCnc = connectFTP("enquete", "nonmove");
	if ($ftpCnc != "") {
		$where = $objPage->_addslashesC("template_kind", TEMPLATE_KIND_ENQUETE);
		$where .= " AND " . $objPage->_addslashesC("work_class", WORK_CLASS_PUBLISH);
		$where .= " AND " . $objPage->_addslashesC("enquete_kind", ENQ_KIND_CGI);
		$objPage->select($where);
		while ($objPage->fetch()) {
			$fld = $objPage->fld;
			$file = $fld["page_id"] . ".csv";
			$ftp_path = FTP_ROOT_DIR_ENQUETE . "/" . $file;
			$ftp_path = str_replace("//", "/", $ftp_path);
			$local_path = DOCUMENT_ROOT . DIR_PATH_ENQUETECSV;
			// FTPダウンロード
			cx_ftp_get($ftpCnc, $ftp_path, $local_path . basename($file), FTP_ASCII);
		}
		cx_ftp_close($ftpCnc);
	}
}

?>
