#!/usr/local/bin/php
<?php
/*
 * 孤立ファイルチェック
 */
//外部ファイル読み込み
require_once (dirname(__FILE__) . "/.htsetting");
require_once (APPLICATION_ROOT . "/common/dbcontrol/tbl_handler.inc");
$objHandler = new tbl_handler($objCnc);
require_once (APPLICATION_ROOT . "/common/dbcontrol/tbl_page.inc");
$objPage = new tbl_page($objCnc);

//変数の宣言
$target_dept_code = ""; //対象の組織コード
$sql = ""; //SQL文（全文）
$result_pages_ary = array(); //CSV作成用配列


//処理済組織情報の取得
if (!$objHandler->selectAutoIsolationCheckDept()) {
	print('孤立ファイルチェック完了組織の取得に失敗しました。');
	exit();
}
//取得が出来る場合
if ($objHandler->fetch()) {
	// 次の組織情報取得
	$dept_fld = get_target_dept($objHandler->fld['item1'], AUTO_ISOLATION_CHECK_DEPT_LEVEL);
	$target_dept_code = $dept_fld['dept_code'];
}
//取得が出来ない場合(初回 or 異常事態)
else {
	$target_dept_code = WEB_MASTER_CODE;
}

// リンク情報に存在しない公開情報取得
$search_dept_code = substr($target_dept_code, 0, (3 * (int)AUTO_ISOLATION_CHECK_DEPT_LEVEL));
$exists = 'SELECT *';
$exists .= ' FROM tbl_publish_links AS l';
$exists .= ' WHERE l.path = p.file_path'; 
$exists .= ' AND ' . $objPage->_addslashesC('l.outer_flg', 0, '=', 'INT');
$exists .= ' AND ' . $objPage->_addslashesC('l.file_exte', 'html', '=');

$where = 'NOT EXISTS(' . $exists .')';
$where .= ' AND ' . $objPage->_addslashesC("u.dept_code", $search_dept_code . '%', 'LIKE', 'TEXT');
$where .= ' AND ' . create_common_public_sql();

$sql = 'SELECT p.*';
$sql .= ' FROM tbl_publish_page AS p INNER JOIN tbl_user AS u ON (p.user_id = u.user_id)';
$sql .= ' WHERE ' . $where;

if (!$objPage->execute($sql)) {
	print('チェック対象ページの情報が取得できませんでした。【' . $target_dept_code . '】');
	exit();
}

//見出し文字
$head_ary = array('ページタイトル', 'ファイルパス');
//取得したページ数分ループ
while ($objPage->fetch()) {
	//チェック結果の作成
	$result_pages_ary[$objPage->fld['page_id']]['title'] = $objPage->fld['page_title'];
	$result_pages_ary[$objPage->fld['page_id']]['file_path'] = $objPage->fld['file_path'];
}
//CSVの作成
$csv_file_name = 'auto_isolation_check_' . $target_dept_code . '.csv';
$csv_file_path = DIR_PATH_TEMP . 'auto_isolation_check';
$csv_file_full_path = DOCUMENT_ROOT . $csv_file_path . '/' . $csv_file_name;
if (!create_Csv($csv_file_name, $result_pages_ary, $head_ary, 1, $csv_file_path, 'SJIS-WIN', "\"")) {
	print('CSVの作成に失敗しました。');
	exit();
}

//メール送信
if (AUTO_ISOLATION_CHECK_TO != "") {
	//実ファイルチェック
	if (@file_exists($csv_file_full_path)) {
		//バウンダリー文字（パートの境界）
		$boundary = md5(uniqid(rand()));
		//ファイルの読み込み
		$contents = "";
		if (($fp = @fopen($csv_file_full_path, "r")) == TRUE) {
			$contents = @fread($fp, filesize($csv_file_full_path));
			@fclose($fp);
		}
		//エンコードして分割
		$f_encoded = chunk_split(base64_encode($contents));
		//Header部の作成
		$header = "MIME-version: 1.0\n";
		$header .= "Content-Type: multipart/mixed;\n";
		$header .= "\tboundary=\"" . $boundary . "\"\n";
		//Body部の作成
		

		$mail_fld = array();
		$mail_fld['url'] = HTTP_REAL_ROOT;
		$mail_fld['cms_url'] = HTTP_ROOT . RPW;
		$mail_fld['now_date'] = date('Y-m-d H:i:s');
		$mail_fld['target_dept_name'] = ($target_dept_code == WEB_MASTER_CODE ? "ウェブマスター" : $dept_fld['name']);
		$head = get_mail_str($mail_fld, MAIL_SUBJECT_ISOLATION_CHECK);
		$mail_body = get_mail_str($mail_fld, MAIL_BODY_ISOLATION_CHECK);
		
		$body = "This is a multi-part message in MIME format.\n\n";
		$body .= "--" . $boundary . "\n";
		$body .= "Content-Type: text/plain; charset=ISO-2022-JP\n";
		$body .= "Content-Transfer-Encoding: 7bit\n\n";
		$body .= $mail_body;
		$body .= "\n\n--" . $boundary . "\n";
		$body .= "Content-Type: text/csv;\n";
		$body .= "\tname=\"" . $csv_file_name . "\"\n";
		$body .= "Content-Transfer-Encoding: base64\n";
		$body .= "Content-Disposition: attachment;\n";
		$body .= "\tfilename=\"" . $csv_file_name . "\"\n\n";
		$body .= $f_encoded . "\n";
		$body .= "--" . $boundary . "--";
		//メール送信
		if (!send_mail(AUTO_ISOLATION_CHECK_TO, MAIL_ADDR_FROM, $head, $body, $header)) {
			print('メールの送信に失敗しました。');
			//CSVファイルの削除
			if (!removeDir(cms_dirname($csv_file_full_path))) {
				print('CSVファイルの削除に失敗しました。');
				exit();
			}
			exit();
		}
	} //実ファイルなし
	else {
		print('CSVファイルが存在しませんでした。');
		exit();
	}
}
//CSVファイルの削除
if (!removeDir(cms_dirname($csv_file_full_path))) {
	print('CSVファイルの削除に失敗しました。');
	exit();
}
//DB登録
$objCnc->begin();
//全て削除
if (!$objHandler->deleteAutoIsolationCheckDept()) {
	$objCnc->rollback();
	print('孤立ファイルチェック完了組織の削除に失敗しました。');
	exit();
}
//登録
if (!$objHandler->insertAutoIsolationCheckDept($target_dept_code)) {
	$objCnc->rollback();
	print('孤立ファイルチェック完了組織の登録に失敗しました。');
	exit();
}
$objCnc->commit();
?>
