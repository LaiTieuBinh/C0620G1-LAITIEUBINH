<?php
/*
 * 簡易FAQ : サーバーに保存されているCSVの定期削除
 */
//--- 設定ファイル読み込み
require (dirname(__FILE__) . "/.htsetting");
// ** global 宣言 ---------------------------
global $objCnc;
?>
#!/usr/local/bin/php
<?php

// クーロンで削除するファイルの拡張子
$DELETE_FILES_EXTE = array(
		"csv"
);

// FAQ機能が使用されている場合は処理を行わない
if (ENABLE_OPTION_FAQ == true) exit();

// 設定値が空の場合は処理を行わない
if (strlen(AUTO_DELETE_FTP_DAY_FAQ) == 0 || AUTO_DELETE_FTP_DAY_FAQ < 0) exit();

// FTPが使用できる場合のみ処理
if (FTP_UPLOAD_FLG) {
	// FAQのFTP接続
	$FTP_INFO = getDefineArray("FTP_INFO");
	$FTP = $FTP_INFO["faq"];
	$ftpCnc = connectFTP("faq", "nonmove");
	// 簡易FAQ CSV保存ディレクトリにFTP接続している
	if ($ftpCnc != "") {
		// 公開サーバのcsvファイルを取得
		$ftp_files = cx_ftp_nlist($ftpCnc, $FTP['dir']);
		// ファイル一覧が取得できなかった場合は、処理終了
		if($ftp_files === FALSE || !is_array($ftp_files)){
			// FTP ストリームを閉じる
			cx_ftp_close($ftpCnc);
			// ログに記載
			traceWrite('FTP上のCSVファイルが取得できませんでした。【auto_delete_ftp_faq.php dir:' . $FTP['dir'] . '】');
			exit;
		}
		// プログラムで使用するために加工
		$ftp_files_detail = array();
		foreach ($ftp_files as $ftp_path) {
			// 配列の作成
			$ftp_files_detail[] = array(
					// 保存日
					"date" => preg_replace("/\..*$/", "", basename($ftp_path)), 
					// ファイルパス
					"path" => $ftp_path, 
					// 拡張子
					"exte" => preg_replace("/^.*\.(.*)$/", "$1", basename($ftp_path))
			);
		}
		
		// 現在時間
		$nowDateTime = time();
		
		// サーバ上から削除しないCSV(日付)
		$nonDeleteDate = array();
		$nonDeleteDate[] = date("Ymd", $nowDateTime);
		for($i = 1; $i <= AUTO_DELETE_FTP_DAY_FAQ; $i++) {
			$nonDeleteDate[] = date("Ymd", strtotime("-" . $i . " day", $nowDateTime));
		}
		
		foreach ($ftp_files_detail as $detail) {
			// 未削除日付のCSVでない場合のみ
			if (!in_array($detail['date'], $nonDeleteDate) && in_array($detail['exte'], $DELETE_FILES_EXTE)) {
				// 削除::削除に失敗した場合はトレースログに記録
				if (!cx_ftp_delete($ftpCnc, $detail['path'])) {
					traceWrite("ERROR::CSVファイルの削除に失敗しました。【" . $detail['path'] . "】");
				}
			}
		}
		
		// FTP ストリームを閉じる
		cx_ftp_close($ftpCnc);
	}
}
?>

