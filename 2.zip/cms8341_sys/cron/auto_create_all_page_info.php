<?php
/*
 * ページ情報をエクスポートする
 */

// 設定ファイル読み込み
require_once (dirname(__FILE__) . "/.htsetting");

global $objCnc;
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$obj_dac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$obj_tools = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$obj_page = new tbl_page($objCnc);
$obj_page2 = new tbl_page($objCnc);

$go = false;
if(isset($_GET["go"]) && $_GET["go"] == 1){
	$go = true;
}
$toiawase_export_flg = false;
if(isset($_GET["toiawase"]) && $_GET["toiawase"] == 1){
	$toiawase_export_flg = true;
}

if (php_sapi_name() == "cli"){
	$go = true;
	$toiawase_export_flg = true;
}

if($go){
	// 見出し文字
	$G_HEADER_TITLE_ARY = array(
		'ページID', 
		'ページタイトル', 
		'ファイルパス', 
		'公開状態',
		'ステータス', 
		'ステータス（状態）', 
		'公開開始日', 
		'公開終了日', 
		'テンプレートID', 
		'テンプレート名称', 
		'分類コード', 
		'第一分類名称', 
		'第二分類名称', 
		'第三分類名称', 
		'第四分類名称', 
		'組織コード', 
		'第一組織名称', 
		'第二組織名称', 
		'第三組織名称', 
		'ユーザーID', 
		'ページ作成者', 
		'親ページID', 
		'親ページタイトル', 
		'親ページファイルパス', 
		'メニュー生成順', 
		'最終更新日'
	);

	// 変数の宣言

	// CSVデータ用配列
	$g_csv_line = 0;
	$g_search = array();
	$g_inquiry_flg = FLAG_OFF;
	$g_inq_max_cnt = 0;
	$g_inq_data_ary = array();
	$g_table_name = 'publish';


	//表示順
	$orderby = "p.page_id ASC, p.publish_start DESC, p.publish_end DESC";
	$whereAry = array();
	$table = "tbl_publish_page as p INNER JOIN tbl_user as u ON p.user_id = u.user_id " . "LEFT JOIN tbl_user AS u_lock on p.user_lock=u_lock.user_id " . "LEFT JOIN tbl_category AS c1 on LEFT(c1.cate_code,3)=LEFT(p.cate_code,3) AND c1.level=1 " . "LEFT JOIN tbl_category AS c2 on LEFT(c2.cate_code,6)=LEFT(p.cate_code,6) AND c2.level=2 " . "LEFT JOIN tbl_category AS c3 on LEFT(c3.cate_code,9)=LEFT(p.cate_code,9) AND c3.level=3 " . "LEFT JOIN tbl_category AS c4 on c4.cate_code=p.cate_code AND c4.level=4 " . "LEFT JOIN tbl_template AS t on t.template_id=p.template_id AND t.template_ver=p.template_ver";
	$obj_page->setTableName($table);

	// 検索条件の取得
	$g_table = $table;
	$g_where = implode(' AND ', $whereAry);
	$g_order = $orderby;
	// ページタイトル、お問い合わせ先メモに改行がある場合「|@@ENTER@@|」で置換して出力する
	$g_field = 'p.page_id, ';
	$g_field .= 'Replace(Replace(Replace(p.page_title, "\r\n", "|@@ENTER@@|"), "\n", "|@@ENTER@@|"), "\r", "|@@ENTER@@|") as page_title, ';
	$g_field .= 'p.file_path, ';
	$g_field .= 'p.status, ';
	$g_field .= 'p.work_class, ';
	$g_field .= 'p.close_flg, ';
	$g_field .= 'p.output_html_flg, ';
	$g_field .= 'p.publish_start, ';
	$g_field .= 'p.publish_end, ';
	$g_field .= 'p.template_id, ';
	$g_field .= 'p.cate_code, ';
	$g_field .= 'p.user_id, ';
	$g_field .= 'p.parent_id, ';
	$g_field .= 'p.menu_generation_order, ';
	$g_field .= 'p.update_datetime, ';
	$g_field .= 'p.inquiry_flg, ';
	$g_field .= 'Replace(Replace(Replace(p.inquiry_memo, "\r\n", "|@@ENTER@@|"), "\n", "|@@ENTER@@|"), "\r", "|@@ENTER@@|") as inquiry_memo, ';
	$g_field .= 'p.inquiry_id, ';
	$g_field .= 'u.*, t.name as temp_name, c1.name as cate1, c2.name as cate2, c3.name as cate3, c4.name as cate4';

	$max_inq_no = 0;
	if($toiawase_export_flg){
		$arr_tables = array('publish','work');
		foreach ($arr_tables as $table) {
			$sql = "SELECT MAX( `inquiry_no` ) AS `max_no` FROM `tbl_" . $table . "_inquiry`";
			if ($obj_dac->execute($sql)) {
				if($obj_dac->fetch() && (int)$obj_dac->fld['max_no'] > $max_inq_no){
					$max_inq_no = $obj_dac->fld['max_no'];
				}
			}
		}
	}

	$max_header_title_ary = $G_HEADER_TITLE_ARY;

	if($max_inq_no > 0){
		$max_header_title_ary[] = '問い合わせ先（' . INQUIRY_FREE_NAME . '）';
	}
	// CSV用のデータ作成処理
	// 問い合わせ先が存在する場合
	for($cnt = 1; $cnt <= $max_inq_no; $cnt++){
		// 問い合わせ先（組織コード）
		$max_header_title_ary[] = '問い合わせ先' . ($cnt) . '（' . INQUIRY_DEPT_NAME . '）';
		// 問い合わせ先（第一組織名称）
		$max_header_title_ary[] = '問い合わせ先' . ($cnt) . '（第一組織名称）';
		// 問い合わせ先（第一組織名称）
		$max_header_title_ary[] = '問い合わせ先' . ($cnt) . '（第二組織名称）';
		// 問い合わせ先（第一組織名称）
		$max_header_title_ary[] = '問い合わせ先' . ($cnt) . '（第三組織名称）';
		// 問い合わせ先（担当者名）
		$max_header_title_ary[] = '問い合わせ先' . ($cnt) . '（' . INQUIRY_CHARGE_NAME . '）';
		// 問い合わせ先（内線番号）
		$max_header_title_ary[] = '問い合わせ先' . ($cnt) . '（' . INQUIRY_EXTENSIONNUMBER_NAME . '）';
		// 問い合わせ先（電話番号）
		$max_header_title_ary[] = '問い合わせ先' . ($cnt) . '（' . INQUIRY_DIRECTNUMBER_NAME . '）';
		// 問い合わせ先（ファックス番号）
		$max_header_title_ary[] = '問い合わせ先' . ($cnt) . '（' . INQUIRY_FAX_NAME . '）';
		// 問い合わせ先（Email）
		$max_header_title_ary[] = '問い合わせ先' . ($cnt) . '（' . INQUIRY_EMAIL_NAME . '）';

	}

	$err_msg = '';
	// CSVファイル作成先
	$csv_file_path = DIR_PATH_TEMP . 'page_list';
	// Zipダウンロードファイル
	$download_zip_link = '';
	// 作業領域初期化
	_removeDir(DOCUMENT_ROOT . $csv_file_path);
	if (!_mkNewDirectory(DOCUMENT_ROOT . $csv_file_path . '/dummy.dummy')) {
		$err_msg = '作業用フォルダの作成に失敗しました。【' . DOCUMENT_ROOT . $csv_file_path . '】';
	}


	// 【CSVファイル作成】
	// ------------------------------------------------------
	// ---全ページ情報リスト用CSVファイル作成
	$page_list_csv_file_name = 'page_list.csv';

	// 出力ファイル見出し情報を追記
	if (!_create_Csv($page_list_csv_file_name, array(), $max_header_title_ary, 2, $csv_file_path, 'utf-8', '"')) {
		$msg = '出力ファイルへの見出し情報の追記に失敗しました。【' . $csv_file_path . '】';
		return FALSE;
	}

	// ページの検索
	$obj_page->select($g_where, $g_field, $g_order, '', '', $g_table);

	// 出力データの作成
	while ($obj_page->fetch()) {
		$g_export_csv_data_ary = array();
		// 公開前のページは、編集テーブルより抽出する
		if ($obj_page->fld['work_class'] == 1) {
			$g_table_name = 'work';
			// 編集ページの情報を抽出
			// ページタイトル、お問い合わせ先メモに改行がある場合「|@@ENTER@@|」で置換して出力する
			$fld = array();
			$sql = 'SELECT w.page_id, ';
			$sql .= 'Replace(Replace(Replace(w.page_title, "\r\n", "|@@ENTER@@|"), "\n", "|@@ENTER@@|"), "\r", "|@@ENTER@@|") as page_title, ';
			$sql .= 'w.file_path, w.status, w.work_class, w.close_flg, w.publish_start, w.publish_end, w.template_id, w.cate_code, w.user_id, w.parent_id, w.menu_generation_order, w.update_datetime, w.inquiry_flg, ';
			$sql .= 'Replace(Replace(Replace(w.inquiry_memo, "\r\n", "|@@ENTER@@|"), "\n", "|@@ENTER@@|"), "\r", "|@@ENTER@@|") as inquiry_memo, ';
			$sql .= 'w.inquiry_id ';
			$sql .= 'FROM tbl_work_page as w ';
			$sql .= 'WHERE w.page_id = ' . $obj_page->fld['page_id'];
			if (!$obj_tools->execute($sql)) {
				user_error('編集ページ情報の取得に失敗しました。【' . $obj_page->fld['page_id'] . '】');
			}
			if ($obj_tools->fetch()) {
				$fld += $obj_tools->fld;
			}
			// ユーザー情報を抽出
			$sql = 'SELECT * FROM tbl_user WHERE user_id = ' . $fld['user_id'];
			if (!$obj_tools->execute($sql)) {
				user_error('ユーザー情報の取得に失敗しました。【' . $fld['user_id'] . '】');
			}
			if ($obj_tools->fetch()) {
				$fld += $obj_tools->fld;
			}
			// テンプレート情報を抽出
			$sql = 'SELECT name as temp_name FROM tbl_template WHERE template_id = ' . $fld['template_id'] . ' ORDER BY template_ver DESC LIMIT 1';
			if (!$obj_tools->execute($sql)) {
				user_error('テンプレート情報の取得に失敗しました。【' . $fld['template_id'] . '】');
			}
			if ($obj_tools->fetch()) {
				$fld += $obj_tools->fld;
			}
			// 分類情報を抽出
			$cate_info = getCateCode($fld['cate_code']);
			$sql = 'SELECT * FROM tbl_category WHERE cate_code IN (' . $cate_info['cate1_code'] . ', ' . $cate_info['cate2_code'] . ', ' . $cate_info['cate3_code'] . ', ' . $cate_info['cate4_code'] . ')';
			if (!$obj_tools->execute($sql)) {
				user_error('分類情報の取得に失敗しました。【' . $sql . '】');
			}
			while ($obj_tools->fetch()) {
				$fld['cate' . $obj_tools->fld['level']] = $obj_tools->fld['name'];
			}
		}
		// 一度でも公開したページは、公開テーブルより抽出する
		else {
			$g_table_name = 'publish';
			$fld = $obj_page->fld;
		}
		// ページID
		$g_export_csv_data_ary[] = (isset($fld['page_id']) ? $fld['page_id'] : '');
		// ページタイトル
		$g_export_csv_data_ary[] = (isset($fld['page_title']) ? $fld['page_title'] : '');
		// ファイルパス
		$g_export_csv_data_ary[] = (isset($fld['file_path']) ? $fld['file_path'] : '');
		// 公開状態
		$ret_status_publish = getStatusPublish($fld);
		$g_export_csv_data_ary[] = $ret_status_publish;
		// ステータス
		$g_export_csv_data_ary[] = (isset($fld['status']) ? $fld['status'] : '');
		// ステータス（状態）
		$ret_ary = get_status_icon($fld);
		// ▼暫定▼
//		$g_export_csv_data_ary[] = (isset($ret_ary['wc_alt']) ? $ret_ary['wc_alt'] : '');
		if ($fld['work_class'] == WORK_CLASS_DELETE && $fld['close_flg'] == FLAG_ON) {
			// tbl_publish_pageの情報が、work_class:3 close_flg:1 の場合には「削除中」とする
			// [補足]work_class 1の場合のみ、work_pageの情報を取得している
			// [補足]非公開中ページの非公開待ち（組織編制時）のページがあることは考慮しない
			$g_export_csv_data_ary[] = '削除中';
		}
		else {
			$g_export_csv_data_ary[] = (isset($ret_ary['wc_alt']) ? $ret_ary['wc_alt'] : '');
		}
		// ▲暫定▲
		// 公開開始日
		$g_export_csv_data_ary[] = (isset($fld['publish_start']) ? $fld['publish_start'] : '');
		// 公開終了日
		$g_export_csv_data_ary[] = (isset($fld['publish_end']) ? $fld['publish_end'] : '');
		// テンプレートID
		$g_export_csv_data_ary[] = (isset($fld['template_id']) ? $fld['template_id'] : '');
		// テンプレート名称
		$g_export_csv_data_ary[] = (isset($fld['temp_name']) ? $fld['temp_name'] : '');
		// 分類コード
		$g_export_csv_data_ary[] = (isset($fld['cate_code']) ? $fld['cate_code'] : '');
		// 第一分類名称
		$g_export_csv_data_ary[] = (isset($fld['cate1']) ? $fld['cate1'] : '');
		// 第二分類名称
		$g_export_csv_data_ary[] = (isset($fld['cate2']) ? $fld['cate2'] : '');
		// 第三分類名称
		$g_export_csv_data_ary[] = (isset($fld['cate3']) ? $fld['cate3'] : '');
		// 第四分類名称
		$g_export_csv_data_ary[] = (isset($fld['cate4']) ? $fld['cate4'] : '');
		// 組織コード
		$g_export_csv_data_ary[] = (isset($fld['dept_code']) ? $fld['dept_code'] : '');
		// 組織情報を取得
		$dept_code = getDeptCode($fld['dept_code']);
		// 第一組織名称
		if ($obj_tools->getDeaprtment($dept_code['dept1_code'])) {
			$g_export_csv_data_ary[] = $obj_tools->fld['name'];
		}
		else {
			$g_export_csv_data_ary[] = '';
		}
		// 第二組織名称
		if ($obj_tools->getDeaprtment($dept_code['dept2_code'])) {
			$g_export_csv_data_ary[] = $obj_tools->fld['name'];
		}
		else {
			$g_export_csv_data_ary[] = '';
		}
		// 第三組織名称
		if ($obj_tools->getDeaprtment($dept_code['dept3_code'])) {
			$g_export_csv_data_ary[] = $obj_tools->fld['name'];
		}
		else {
			$g_export_csv_data_ary[] = '';
		}
		// ユーザーID
		$g_export_csv_data_ary[] = (isset($fld['user_id']) ? $fld['user_id'] : '');
		// ページ作成者
		$g_export_csv_data_ary[] = (isset($fld['name']) ? $fld['name'] : '');
		// 親ページID
		$g_export_csv_data_ary[] = (isset($fld['parent_id']) ? $fld['parent_id'] : '');
		// 親ページ情報の取得
		if ($obj_page2->selectFromID($fld['parent_id'])) {
			// 親ページタイトル
			$g_export_csv_data_ary[] = $obj_page2->fld['page_title'];
			// 親ページファイルパス
			$g_export_csv_data_ary[] = $obj_page2->fld['file_path'];
		}
		else {
			$g_export_csv_data_ary[] = '';
			$g_export_csv_data_ary[] = '';
		}
		// メニュー生成順
		$g_export_csv_data_ary[] = (isset($fld['menu_generation_order']) ? $fld['menu_generation_order'] : '');
		// 最終更新日
		$g_export_csv_data_ary[] = (isset($fld['update_datetime']) ? $fld['update_datetime'] : '');
		// 問い合わせ先の表示を行う場合
		$g_inq_data_ary = array();
		if($toiawase_export_flg){
			if ($fld['inquiry_flg'] == FLAG_ON) {
				// 問い合わせ先（フリー入力）
				$g_export_csv_data_ary[] = (isset($fld['inquiry_memo']) ? $fld['inquiry_memo'] : '');
				$g_inquiry_flg = FLAG_ON;
				// 問い合わせ先情報の取得
				$sql = "SELECT * FROM tbl_" . $g_table_name . "_inquiry WHERE inquiry_id = '" . $fld['inquiry_id'] . "' ORDER BY inquiry_no";
				if ($obj_dac->execute($sql)) {
					if ($obj_dac->getRowCount() > 0) {
						$inq_cnt = 0;
						// 問い合わせの数分ループ
						while ($obj_dac->fetch()) {
							// 問い合わせ先（組織コード）
							$g_inq_data_ary[$inq_cnt][] = $obj_dac->fld['dept_code'];
							// 組織情報を取得
							$dept_code = getDeptCode($obj_dac->fld['dept_code']);
							// 問い合わせ先（第一組織名称）
							if ($dept_code['level'] >= 1 && $obj_tools->getDeaprtment($dept_code['dept1_code'])) {
								$g_inq_data_ary[$inq_cnt][] = $obj_tools->fld['name'];
							}
							else {
								$g_inq_data_ary[$inq_cnt][] = '';
							}
							// 問い合わせ先（第二組織名称）
							if ($dept_code['level'] >= 2 && $obj_tools->getDeaprtment($dept_code['dept2_code'])) {
								$g_inq_data_ary[$inq_cnt][] = $obj_tools->fld['name'];
							}
							else {
								$g_inq_data_ary[$inq_cnt][] = '';
							}
							// 問い合わせ先（第三組織名称）
							if ($dept_code['level'] >= 3 && $obj_tools->getDeaprtment($dept_code['dept3_code'])) {
								$g_inq_data_ary[$inq_cnt][] = $obj_tools->fld['name'];
							}
							else {
								$g_inq_data_ary[$inq_cnt][] = '';
							}
							// 問い合わせ先（担当者名）
							$g_inq_data_ary[$inq_cnt][] = $obj_dac->fld['name'];
							// 問い合わせ先（内線番号）
							$g_inq_data_ary[$inq_cnt][] = $obj_dac->fld['anex_number'];
							// 問い合わせ先（電話番号）
							$g_inq_data_ary[$inq_cnt][] = $obj_dac->fld['drxt_number'];
							// 問い合わせ先（ファックス番号）
							$g_inq_data_ary[$inq_cnt][] = $obj_dac->fld['fax'];
							// 問い合わせ先（Email）
							$g_inq_data_ary[$inq_cnt][] = $obj_dac->fld['email'];
							$inq_cnt++;
						}
						// 問い合わせの最大数を取得
						if ($g_inq_max_cnt < $inq_cnt) {
							$g_inq_max_cnt = $inq_cnt;
						}
					}
				}
			}
			else {
				// 問い合わせ先（フリー入力）
				$g_export_csv_data_ary[] = '';
			}
	
			for ($cnt = 0; $cnt < $max_inq_no; $cnt++) {
				// 各問合せの数分ループ
				for ($i = 0; $i < 9; $i++) {
					// 問い合わせが存在する場合
					if (isset($g_inq_data_ary[$cnt][$i])) {
						$g_export_csv_data_ary[] = $g_inq_data_ary[$cnt][$i];
					}
					// 問い合わせが存在しない場合
					else {
						$g_export_csv_data_ary[] = '';
					}
				}
			}
		}
		// 出力ファイル見出し情報を追記
		if (!_create_Csv($page_list_csv_file_name, $g_export_csv_data_ary, '', 2, $csv_file_path, 'utf-8', '"')) {
			$err_msg = '出力ファイルへの見出し情報の追記に失敗しました。【' . $csv_file_path . '】';
			return FALSE;
		}

		
	}
	// 【ZIPファイル作成】
	// ------------------------------------------------------
	$tmp_path = DOCUMENT_ROOT . $csv_file_path;
	$zip_path = DOCUMENT_ROOT . $csv_file_path . '/' .  "pagelist.zip";
	// ダウンロード用zipファイル
	$dl_zip_path = $csv_file_path . '/' . "pagelist.zip";
	//Zipの作成に失敗
	$msg = "";
	if (!_create_Zip($tmp_path, $zip_path)) {
		$err_msg = "Zipファイルの作成に失敗しました。【" . $tmp_path . "】";
	}
	$download_zip_link = '<a href="' . $dl_zip_path . '">ページ情報Zipファイル</a>' . "\n";
}

?>
<?php if (php_sapi_name() == "cli") {?>
#!/usr/local/bin/php
<?php } else { ?>

	<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
	<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="Content-Style-Type" content="text/css">
		<meta http-equiv="Content-Script-Type" content="text/javascript">
		<title>全ページ情報抽出</title>
		<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css" type="text/css">
	</head>
	<body id="cms8341-mainbg">
	<?php if(!$go){ 
		$actual_link = "/cms8341_sys/cron/" . basename(__FILE__);
		$full_download_link = $actual_link . "?go=1&toiawase=1";
		$no_toiawase_download_link = $actual_link . "?go=1";
		?>
		<div align="center">
			<div class="cms8341-area-corner">
				<p><span id="cms_result">以下のリンクをクリックすると、ページ情報のダウンロードを開始します。</span></p>
				
				<?php
					echo '<p><a href="' . $full_download_link . '">ページ情報ダウンロード（問い合わせ情報あり）</a></p>' . "\n";
				?>
				<?php
					echo '<p><a href="' . $no_toiawase_download_link . '">ページ情報ダウンロード（問い合わせ情報なし）</a></p>' . "\n";
				?>
			</div>
		</div>
	<?php } 
	else { ?>
		<div align="center">
			<div class="cms8341-area-corner">
				<p><span id="cms_count"></span></p>
				<p><span id="cms_result">以下のリンクをクリックして、ZIPファイルをダウンロードしてください。</span></p>
				<p><span id="cms_result">ページタイトル、問い合わせフリー入力に改行がある場合、&nbsp;&nbsp;|@@ENTER@@|&nbsp;&nbsp;に置換して出力されます。</span></p>
				<p><span id="cms_error"></span></p>
				<?php
					echo '<p>' . $download_zip_link . '</p>' . "\n";
				?>
			</div>
		</div>
	<?php } ?>
	</body>
	</html>

<?php } ?>

<?php 
/**
 * ディレクトリを対象として、削除を行う
 *
 * @param $path 削除するディレクトリのパス
 * @return 削除に成功した場合は、TRUE。そうでない場合は、FALSEを返す。
 */
function _removeDir($path) {
	//ディレクトリが存在しなければ、TRUEを返す
	if (!@is_dir($path)) return TRUE;
	//パスの最後に「/」をつける
	if (substr($path, -1, 1) != "/") $path .= "/";
	//ディレクトリ内にある全てのファイルを削除する
	if ($handle = @opendir($path)) {
		while (false !== ($item = readdir($handle))) {
			//「.」「..」は無視
			if (in_array($item, array(
					".", 
					".."
			))) continue;
			//ディレクトリの場合は、再帰処理を行う
			if (@is_dir($path . $item . '/')) {
				if (!removeDir($path . $item . '/')) return FALSE;
			}
			else {
				//ファイルの場合は、削除を行う
				if (!@unlink($path . $item)) return FALSE;
			}
		}
		//後処理
		closedir($handle);
		//ディレクトリの削除
		if (!@rmdir($path)) return FALSE;
	}
	return TRUE;
}

/**
 * フォルダが無ければ作成する
 * 
 * @param $file_path ファイルパス
 */
function _mkNewDirectory($file_path) {
	$file_path = strtolower($file_path);
	$dir_path = preg_replace('/\/[^\/]*$/', '/', $file_path);
	$d = "";
	if (@file_exists($dir_path)) {
		@chmod($dir_path, 0777);
		return TRUE;
	}
	// ディレクトリの作成、移動
	if (preg_match_all('/([^\/]+)/', $file_path, $d)) {
		$d = $d[1];
		$filename = array_pop($d);
		$dir_path = INSTALL_DRIVE;
		foreach ($d as $directory) {
			if (INSTALL_DRIVE != "") {
				$pos = strpos($directory, INSTALL_DRIVE);
				if ($pos !== FALSE && $pos == 0) continue;
			}
			$dir_path .= "/" . $directory;
			if (@file_exists($dir_path)) continue;
			if (!@mkdir($dir_path, 0777)) return FALSE;
			@chmod($dir_path, 0777);
		}
	}
	return TRUE;
}

/**
 * Zip圧縮を行う
 *
 * @param $folder_path 圧縮対象フォルダパス
 * @param $zip_path 圧縮後Zipパス
 * @return 作成に成功した場合は、TRUE。そうでない場合は、FALSEを返す。
 */
function _create_Zip($folder_path, $zip_path) {
	//引数のチェック
	if ($folder_path == "" || $zip_path == "") return FALSE;
	//フォルダの存在チェック
	if (!@file_exists($folder_path)) return TRUE;
	
	//実際に圧縮する
	if (defined("SET_ZIP_EXE")) {
		exec('cd ' . str_replace('/', "\\", $folder_path) . ' & ' . SET_ZIP_EXE . ' -r ' . $zip_path . ' *');
	}
	else {
		exec('cd ' . $folder_path . '; zip -r ' . $zip_path . ' *');
	}
	
	//Zipファイルの存在チェック
	if (!@file_exists($zip_path)) return FALSE;
	return TRUE;
}

/**
 * CSVを出力する
 *
 * @param $file_name ファイル名
 * @param $data_ary 出力データ配列(2重配列)
 * @param $header_ary 出力ヘッダ配列(CSVファイルの1行目のデータ)
 * @param $file_output ファイル出力先 0：ユーザ保存(default) 1：サーバ保存 2：サーバ追記保存
 * @param $file_path サーバルートからのファイル出力先パス($file_output=1の場合のみ使用)
 * @param $char_code 出力文字コード
 * @param $escChar エスケープ文字
 * @return 成功した場合は、TRUE。そうでない場合は、FALSEを返す。
 */
function _create_Csv($file_name, $data_ary, $header_ary, $file_output, $file_path, $char_code, $escChar = "\\") {
	//引数のチェック
	if (!isset($file_name) || $file_name == "") return false;
	if (!isset($data_ary) || !is_array($data_ary)) return false;
	
	//変数の指定
	$csv_str = "";
	
	//CSV作成処理
	//出力ヘッダ配列が存在すれば、ヘッダー部分を作成
	if (isset($header_ary) && $header_ary != "") {
		foreach ($header_ary as $header) {
			$csv_str .= csvWrite($header, $escChar) . ',';
		}
		//$csv_str .= "\n";
	}
	//データ部分の作成
	if(isset($data_ary) && $data_ary != ""){
		foreach ($data_ary as $data) {	
			$csv_str .= csvWrite($data, $escChar) . ',';
		}
		$csv_str .= "\n";
	}


	//CSV出力処理
	$encode = mb_detect_encoding($csv_str, "ASCII,JIS,UTF-8,SJIS-WIN,SJIS,EUCJP-WIN,EUC_JP");
	if (strtoupper($char_code) != $encode) $csv_str = mb_convert_encoding($csv_str, $char_code, $encode);
	//ユーザ保存用出力
	if ($file_output == 0) {
		header("Content-Disposition: attachment; filename=" . $file_name);
		header('Content-type: text/comma-separated-values');
		print $csv_str;
	} //サーバ保存用出力
	else if ($file_output == 1) {
		$to_csv_path = DOCUMENT_ROOT . $file_path . "/" . $file_name;
		if (!mkNewDirectory($to_csv_path)) return FALSE;
		$fp = @fopen($to_csv_path, 'w', 0777);
		if (@fwrite($fp, $csv_str) === false) {
			if (isset($fp) && $fp != "") @fclose($fp);
			return FALSE;
		}
		@fclose($fp);
	}
	// サーバ追記保存用出力
	else if ($file_output == 2) {
		$to_csv_path = DOCUMENT_ROOT . $file_path . "/" . $file_name;
		if (!mkNewDirectory($to_csv_path)) return FALSE;
		$fp = @fopen($to_csv_path, 'a', 0777);
		if (@fwrite($fp, $csv_str) === false) {
			if (isset($fp) && $fp != "") @fclose($fp);
			return FALSE;
		}
		@fclose($fp);
	}
	return true;
}

/**
 * 公開状態	（"新規"、"公開"、"非公開"）を取得する
 *
 * @param $page_fld ページの情報
 * @return ページの公開状態の文字列
 */
function getStatusPublish($page_fld) {
	// 戻り値
	$ret ='';
	
	if ($page_fld['work_class'] == WORK_CLASS_NEW) {
		// "新規"
		$ret = '新規';
	}
	else {
		if ($page_fld['output_html_flg'] == FLAG_OFF) {
			$ret = 'ページ出力なし';
		}
		else {
			if ($page_fld['close_flg'] == FLAG_OFF) {
				// "公開"
				$ret = getStatusProcessing($page_fld, '公開');
			}
			else {
				// "非公開"
				$ret = getStatusProcessing($page_fld, '非公開');
			}
		}
	}
	return $ret;
}

/**
 * 処理状態	（"更新"、"非公開・削除処理"）の文字列を取得する
 *
 * @param $page_fld ページの情報
 * @param $str 公開状態の文字列
 * @return 公開状態に処理状態を付与した文字列
 */
function getStatusProcessing($page_fld, $str) {
	// 戻り値
	$ret = '';
	
	// 処理状態の判断
	if ($page_fld['work_class'] == WORK_CLASS_PUBLISH) {
		if ($page_fld['status'] == STATUS_PUBLISH) {
			$ret = $str;
		}
		else {
			// 更新
			$ret = $str . '(更新)';
		}
	}
	else if ($page_fld['work_class'] == WORK_CLASS_DELETE) {
		// 非公開・削除処理
		if ($page_fld['close_flg'] == FLAG_OFF) {
			$ret = $str . '(非公開・削除処理)';
		}
		else {
			$ret = $str . '(削除処理)';
		}
	}
	return $ret;
}