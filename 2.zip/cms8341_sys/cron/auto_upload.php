<?php
/*
 *
 */
require_once (dirname(__FILE__) . "/.htsetting");
global $objCnc;
?>
#!/usr/local/bin/php
<?php

$mode = "nomal";
require_once (DOCUMENT_ROOT . RPW . '/admin/page/upload/upload_exec.php');
?>
