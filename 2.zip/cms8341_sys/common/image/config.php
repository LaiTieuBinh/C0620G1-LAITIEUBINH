<?php

/**
 * The quality of the image being saved or output, if the format supports it.
 */
define("IMG_QUALITY", 100);

/**
 * The install location of the imagemagick executables.
 */
define("IMG_IMAGEMAGICK_DIR", "/usr/bin/");

/**
 * Temporary directory to store image files in that are being edited.
 */
define("IMG_TEMP_DIR", DOCUMENT_ROOT . DIR_PATH_UPLOAD . "/temp/");

/**
 * The string of text to append to the image.
 */
define("IMG_TEMP_APPEND", "gd_img_");
                
/**
 * Sets if the queue should be cleared after a save(), save_pa(), or output().
 */
define("IMG_CLEAR_QUEUE", true);

/**
 * Used to debug the class, defaults to false.
 */
define("IMG_DEBUG", false);

