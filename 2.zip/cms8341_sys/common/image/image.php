<?php
require_once(dirname(__FILE__) . '/config.php');

class Image {

    protected static $_instance = null;

    /**
     * Creates a new instance for static use of the class.
     *
     * @return  Image_Driver
     */
    protected static function instance($drive) {
        if (static::$_instance == null) {
            static::$_instance = static::forge($drive);
        }
        return static::$_instance;
    }

    /**
     * Creates a new instance of the image driver
     *
     * @param   array  $config
     * @return  Image_Driver
     */
    public static function forge($driver) {
        $protocol = ucfirst(!empty($driver) ? $driver : 'gd');
        $class = 'Image_' . $protocol;

        require_once $driver . '.php';

        $config = static::get_config();
        $return = new $class($config);

        return $return;
    }

    /**
     * Get config.
     *
     * @return  array
     */
    protected static function get_config() {
        return array(
            'quality' => IMG_QUALITY,
            'clear_queue' => IMG_CLEAR_QUEUE,
            'temp_append' => IMG_TEMP_APPEND,
            'temp_dir' => IMG_TEMP_DIR,
            'imagemagick_dir' => IMG_IMAGEMAGICK_DIR,
            'debug' => IMG_DEBUG,
        );
    }

    /**
     * Loads the image and checks if its compatable.
     *
     * @param   string  $filename   The file to load
     * @return  Image_Driver
     */
    public static function load($filename, $drive) {
        return static::instance($drive)->load($filename);
    }

    /**
     * Resizes the image. If the width or height is null, it will resize retaining the original aspect ratio.
     *
     * @param   integer  $width   The new width of the image.
     * @param   integer  $height  The new height of the image.
     * @param   boolean  $keepar  Defaults to true. If false, allows resizing without keeping AR.
     * @param   boolean  $pad     If set to true and $keepar is true, it will pad the image with the configured bgcolor
     * @return  Image_Driver
     */
    public static function resize($width, $height, $keepar = true, $pad = false) {
        return static::instance()->resize($width, $height, $keepar, $pad);
    }

}
