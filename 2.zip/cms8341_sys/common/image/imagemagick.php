<?php

include 'driver.php';

class Image_Imagemagick extends Image_Driver {

    protected $image_temp = null;
    protected $accepted_extensions = array('png', 'gif', 'jpg', 'jpeg');
    protected $sizes_cache = null;
    protected $im_path = null;

    public function load($filename, $return_data = false, $force_extension = false) {
        extract(parent::load($filename, $return_data, $force_extension));

        $this->clear_sizes();
        if (empty($this->image_temp)) {
            do {
                $this->image_temp = $this->config['temp_dir'] . substr($this->config['temp_append'] . md5(time() * microtime()), 0, 32) . '.png';
            } while (is_file($this->image_temp));
        } elseif (is_file($this->image_temp)) {
            $this->debug('Removing previous temporary image.');
            unlink($this->image_temp);
        }
        $this->debug('Temp file: ' . $this->image_temp);
        if (!is_dir($this->config['temp_dir'])) {
            throw new \RuntimeException("The temp directory that was given does not exist.");
        } elseif (!touch($this->config['temp_dir'] . $this->config['temp_append'] . '_touch')) {
            throw new \RuntimeException("Could not write in the temp directory.");
        }
	$this->exec('convert', '"' . $image_fullpath . '"[0] "' . $this->image_temp . '"');

        return $this;
    }

    protected function _resize($width, $height = null, $keepar = true, $pad = true) {
        extract(parent::_resize($width, $height, $keepar, $pad));

        $image = '"' . $this->image_temp . '"';
        $this->exec('convert', "-define png:size=" . $cwidth . "x" . $cheight . " " . $image . " " .
                "-background none " .
                "-resize \"" . ($pad ? $width : $cwidth) . "x" . ($pad ? $height : $cheight) . "!\" " .
                "-gravity center " .
                "-extent " . $cwidth . "x" . $cheight . " " . $image);
        $this->clear_sizes();
    }
    
    protected function _crop($x1, $y1, $x2, $y2) {
	extract(parent::_crop($x1, $y1, $x2, $y2));
	$image = '"' . $this->image_temp . '"';
	$this->exec('convert', $image . ' -crop ' . ($x2 - $x1) . 'x' . ($y2 - $y1) . '+' . $x1 . '+' . $y1 . ' +repage ' . $image);
	$this->clear_sizes();
    }

    public function sizes($filename = null, $usecache = true) {
        $is_loaded_file = $filename == null;
        if (!$is_loaded_file or $this->sizes_cache == null or ! $usecache) {
            $reason = ($filename != null ? "filename" : ($this->sizes_cache == null ? 'cache' : 'option'));
            $this->debug("Generating size of image... (triggered by $reason)");

            if ($is_loaded_file and ! empty($this->image_temp)) {
                $filename = $this->image_temp;
            }

            $output = $this->exec('identify', '-format "%w %h" "' . $filename . '"[0]');
            list($width, $height) = explode(" ", $output[0]);
            $return = (object) array(
                        'width' => $width,
                        'height' => $height,
            );

            if ($is_loaded_file) {
                $this->sizes_cache = $return;
            }
            $this->debug("Sizes " . (!$is_loaded_file ? "for <code>$filename</code> " : "") . "are now $width and $height");
        } else {
            $return = $this->sizes_cache;
        }

        return $return;
    }

    public function save($filename = null, $permissions = null) {
        extract(parent::save($filename, $permissions));

        $this->run_queue();

        $filetype = $this->image_extension;
        $old = '"' . $this->image_temp . '"';
        $new = '"' . $filename . '"';

        if (($filetype == 'jpeg' or $filetype == 'jpg') and $this->config['quality'] != 100) {
            $quality = '"' . $this->config['quality'] . '%"';
            $this->exec('convert', $old . ' -quality ' . $quality . ' ' . $new);
        } else {
            $this->exec('convert', $old . ' ' . $new);
        }

        return $this;
    }

    public function output($filetype = null) {
        extract(parent::output($filetype));

        $this->run_queue();

        $image = '"' . $this->image_temp . '"';

        if (($filetype == 'jpeg' or $filetype == 'jpg') and $this->config['quality'] != 100) {
            $quality = '"' . $this->config['quality'] . '%"';
            $this->exec('convert', $image . ' -quality ' . $quality . ' ' . strtolower($filetype) . ':-', true);
        } elseif (substr($this->image_temp, -1 * strlen($filetype)) != $filetype) {
            if (!$this->config['debug']) {
                $this->exec('convert', $image . ' ' . strtolower($filetype) . ':-', true);
            }
        } else {
            if (!$this->config['debug']) {
                echo file_get_contents($this->image_temp);
            }
        }

        return $this;
    }

    /**
     * Cleared the currently loaded sizes, used to removed cached sizes.
     */
    protected function clear_sizes() {
        $this->sizes_cache = null;
    }

    /**
     * Executes the specified imagemagick executable and returns the output.
     *
     * @param   string   $program   The name of the executable.
     * @param   string   $params    The parameters of the executable.
     * @param   boolean  $passthru  Returns the output if false or pass it to browser.
     * @return  mixed    Either returns the output or returns nothing.
     */
    protected function exec($program, $params, $passthru = false) {
        //  Determine the path
        $path = $this->config['imagemagick_dir'] . $program;
	if (is_executable($path)) {
	    $this->im_path = $path;
	}
	elseif (is_executable($path . '.exe')) {
	    $this->im_path = $path . '.exe';
	}
	elseif (is_executable($this->config['imagemagick_dir'] . 'magick.exe')) {
	    $this->im_path = $this->config['imagemagick_dir'] . 'magick.exe' . " " . $program;
	}
	else {
	    throw new ErrorException("imagemagick executables not found in " . $this->config['imagemagick_dir']);
	}

        $command = $this->im_path . " " . $params;
        $this->debug("Running command: <code>$command</code>");
        $code = 0;
        $output = null;

        $passthru ? passthru($command) : exec($command, $output, $code);

        if ($code != 0) {
            throw new \RuntimeException("imagemagick failed to edit the image. Returned with $code.<br /><br />Command:\n <code>$command</code>");
        }
	
        return $output;
    }

    public function __destruct() {
        if (is_file($this->image_temp)) {
            unlink($this->image_temp);
        }
    }
    
}
