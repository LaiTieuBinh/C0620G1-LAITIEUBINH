<?php
    $mobile_config = "Mobile : " . (IKOU_MOBILE ? 'true' : 'false');
    if($temp_fld['template_kind'] == TEMPLATE_KIND_MOBILE){
        $mobile_config = "Mobile : true,\n width : '" . FCK_MOBILE_WIDTH . "'";
    }
    $scriptEditor = "<script>
    CKEDITOR.disableAutoInline = true;
    CKEDITOR.replace( 'cms_context', {
        language: 'ja',
        toolbar: '" . $toolbar . "',
        extraPlugins: 'widget,gd_liststyle,gd_link,gd_templates,gd_table,gd_table_clear,gd_image,gd_table_property,gd_table_deletelayout,gd_indent,gd_table_tools" . $extraPlugins . "',
        removePlugins: 'specialchar',
        stylesSet: 'cms8341',
        contentsCss: ['".DIR_PATH_EDITCSS . $temp_fld['edit_css']."', '" . RPW . "/ckeditor/gd_files/css/internal.css'],
        format_tags: 'p;h1;h2;h3;h4;h5;h6',
        youtube_noembed : true,
        TableWidth : " . FCK_TABLE_DRESSUP_WIDTH . ", //テーブル幅（単位：％）
        TableBorder : " . FCK_TABLE_DRESSUP_BORDER . ", //テーブル枠	[0|1|3|5]
        TablePadding : " . FCK_TABLE_DRESSUP_CELLPADDING . ", //セル余白
        TableSpacing : " . FCK_TABLE_DRESSUP_CELLSPACING . ", //セル間隔
        TableCellSpacing : 0,
        " . $mobile_config . ",
        toolbar_cms8341_library :
         [
            ['Source','-','Cut','Copy','PasteText','PasteFromWord','GdTemplates'],
            ['Undo','Redo','-','Find','Replace','-','SelectAll'],
            ['NumberedList','BulletedList','-','GdIndent','GdOutdent'],
            ['JustifyLeft','JustifyCenter','JustifyRight',],
            '/',
            ['GdLink','Unlink','Anchor','-','GdImage','-','Table','GdTableProperty','GdClearTable','-','HorizontalRule'],
            '/',
            ['Styles','Format','RemoveFormat','Bold','Italic','-','Subscript','Superscript'],            
            ['GdYoutube','Maximize']
         ],
         toolbar_cms8341_admin :
         [
            ['Source','-','Cut','Copy','PasteText','PasteFromWord','GdTemplates'],
            ['Undo','Redo','-','Find','Replace','-','SelectAll'],
            ['NumberedList','BulletedList','-','GdIndent','GdOutdent'],
            ['JustifyLeft','JustifyCenter','JustifyRight',],
            '/',
            ['GdLink','Unlink','Anchor','-','GdImage','-','Table','GdTableProperty','GdClearTable','-','HorizontalRule'],
            '/',
            ['Styles','Format','RemoveFormat','Bold','Italic','-','Subscript','Superscript'],            
            ['GdYoutube','Maximize']
         ],
        toolbar_cms8341_user :
        [
            ['Cut','Copy','PasteText','PasteFromWord','GdTemplates'],
            ['Undo','Redo','-','Find','Replace','-','SelectAll'],
            ['NumberedList','BulletedList','-','GdIndent','GdOutdent'],
            ['JustifyLeft','JustifyCenter','JustifyRight',],
            '/',
            ['GdLink','Unlink','Anchor','-','GdImage','-','Table','GdTableProperty','GdClearTable','-','HorizontalRule'],
            '/',
            ['Styles','Format','RemoveFormat','Bold','Italic','-','Subscript','Superscript'],            
            ['GdYoutube','Maximize']
        ],
        toolbar_cms8341_mobile :
        [
            ['Cut','Copy','PasteText','PasteFromWord','GdTemplates'],
            ['Undo','Redo','-','Find','Replace','-','SelectAll'],
            ['NumberedList','BulletedList','-','GdIndent','GdOutdent'],
            ['JustifyLeft','JustifyCenter','JustifyRight',],
            '/',
            ['GdLink','Unlink','Anchor','-','GdImage','-','Table','GdTableProperty','GdClearTable','-','HorizontalRule'],
            '/',
            ['Styles','Format','RemoveFormat','Bold','Italic','-','Subscript','Superscript'],            
            ['GdYoutube','Maximize']
        ],
        toolbar_cms8341_mobileAdmin :
        [
            ['Source','Cut','Copy','PasteText','PasteFromWord','GdTemplates'],
            ['Undo','Redo','-','Find','Replace','-','SelectAll'],
            '/',
            ['NumberedList','BulletedList'],
            ['JustifyLeft','JustifyCenter','JustifyRight'],
            ['GdLink','Unlink','Anchor'],
            ['GdImage','-','HorizontalRule'],
            '/',
            ['Styles','Format','RemoveFormat','-','Bold','Italic'],
            ['Maximize', 'GdYoutube']
        ],
    });
    // load CK style
    " . $ckeditor_style . "

    </script>";
   
    echo $scriptEditor;