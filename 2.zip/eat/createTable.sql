-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- ホスト: localhost
-- 生成時間: 2010 年 3 月 05 日 09:23
-- サーバのバージョン: 5.1.37
-- PHP のバージョン: 5.2.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_advert_area`
--

DROP TABLE IF EXISTS `tbl_advert_area`;
CREATE TABLE IF NOT EXISTS `tbl_advert_area` (
  `area_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `delivery_from` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `layout_line` int(4) unsigned NOT NULL DEFAULT '0',
  `layout_row` int(4) unsigned NOT NULL DEFAULT '0',
  `order_from` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `banner_width` int(4) unsigned NOT NULL DEFAULT '0',
  `banner_height` int(4) unsigned NOT NULL DEFAULT '0',
  `source_code` text,
  `template_id` smallint(5) unsigned DEFAULT NULL,
  `recruitment_from` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`area_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_advert_banner`
--

DROP TABLE IF EXISTS `tbl_advert_banner`;
CREATE TABLE IF NOT EXISTS `tbl_advert_banner` (
  `area_id` int(10) unsigned NOT NULL DEFAULT '0',
  `banner_id` int(10) unsigned NOT NULL DEFAULT '0',
  `banner_type` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '1',
  `name` varchar(255) DEFAULT NULL,
  `link_url` text,
  `image_path` varchar(255) DEFAULT NULL,
  `image_alt` varchar(255) DEFAULT NULL,
  `text_banner_text` VARCHAR( 255 ) DEFAULT NULL,
  `text_banner_details` TEXT DEFAULT NULL,
  `publish_start` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sort_order` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`area_id`,`banner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_approve`
--

DROP TABLE IF EXISTS `tbl_approve`;
CREATE TABLE IF NOT EXISTS `tbl_approve` (
  `approve_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `approve1` varchar(20) DEFAULT NULL,
  `approve2` varchar(20) DEFAULT NULL,
  `approve3` varchar(20) DEFAULT NULL,
  `approve4` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`approve_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_approve_handler`
--

DROP TABLE IF EXISTS `tbl_approve_handler`;
CREATE TABLE IF NOT EXISTS `tbl_approve_handler` (
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item1` text,
  `item2` text,
  `item3` text,
  `item4` text,
  `item5` text,
  KEY `IDX_tbl_approve_handler_1` (`class`),
  KEY `IDX_tbl_approve_handler_2` (`class`,`item1`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_auto_link`
--

DROP TABLE IF EXISTS `tbl_auto_link`;
CREATE TABLE `tbl_auto_link` (
  `a_link_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `rss_flg` varchar(255) DEFAULT NULL,
  `rss_file` varchar(255) DEFAULT NULL,
  `use_group` varchar(32) DEFAULT NULL,
  `cate_code` varchar(20) DEFAULT NULL,
  `condition` text,
  `link_target` tinyint(1) NOT NULL DEFAULT '0',
  `order` varchar(255) DEFAULT NULL,
  `max_result` int(11) DEFAULT NULL,
  `auth` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`a_link_id`),
  KEY `IDX_tbl_auto_link_1` (`cate_code`),
  KEY `IDX_tbl_auto_link_2` (`link_target`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_auto_link_pages`
--

DROP TABLE IF EXISTS `tbl_auto_link_pages`;
CREATE TABLE `tbl_auto_link_pages` (
  `a_link_id` int(10) unsigned NOT NULL DEFAULT '0',
  `page_id` int(10) NOT NULL DEFAULT '0',
  `group` varchar(3) NOT NULL DEFAULT '0',
  `sort_order` varchar(6) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `image_alt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`a_link_id`,`page_id`),
  KEY `IDX_tbl_auto_link_pages_1` (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_category`
--

DROP TABLE IF EXISTS `tbl_category`;
CREATE TABLE IF NOT EXISTS `tbl_category` (
  `cate_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level` tinyint(4) NOT NULL DEFAULT '0',
  `cate_code` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `faqpage_id` int(10) unsigned DEFAULT NULL,
  `faq_children_flg` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` smallint(6) NOT NULL DEFAULT '0',
  `disaster_flg` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cate_id`),
  KEY `IDX_tbl_category_1` (`cate_code`),
  KEY `IDX_tbl_category_2` (`level`),
  KEY `IDX_tbl_category_3` (`disaster_flg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_check_config`
--

DROP TABLE IF EXISTS `tbl_check_config`;
CREATE TABLE IF NOT EXISTS `tbl_check_config` (
  `class` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `check_flg` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_check_pagesize`
--

DROP TABLE IF EXISTS `tbl_check_pagesize`;
CREATE TABLE IF NOT EXISTS `tbl_check_pagesize` (
  `text_size` int(11) DEFAULT NULL,
  `use_file_size` int(11) DEFAULT NULL,
  `tmp_size_chk` tinyint(1) DEFAULT NULL,
  `edit_size_chk` tinyint(1) DEFAULT NULL,
  `err_handle` tinyint(1) DEFAULT NULL,
  `text_size_k` int(11) DEFAULT NULL,
  `use_file_size_k` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_check_words`
--

DROP TABLE IF EXISTS `tbl_check_words`;
CREATE TABLE IF NOT EXISTS `tbl_check_words` (
  `word_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `word` varchar(255) NOT NULL DEFAULT '',
  `rep_word` varchar(255) NOT NULL DEFAULT '',
  `rep_word2` varchar(255) NOT NULL DEFAULT '',
  `convert_flg` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`word_id`),
  KEY `IDX_tbl_check_words_1` (`class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_contents_group`
--

DROP TABLE IF EXISTS `tbl_contents_group`;
CREATE TABLE IF NOT EXISTS `tbl_contents_group` (
  `group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `group_name` varchar(255) DEFAULT NULL,
  `note1` text,
  `note2` text,
  -- 移行作業用：否認時ファイル添付機能
  `attached_file` varchar(255) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `approve_id` smallint(5) unsigned DEFAULT NULL,
  `publish_start` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `request_datetime` datetime DEFAULT NULL,
  `approver_id` int(10) unsigned DEFAULT NULL,
  `approve_datetime` datetime DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- テーブルの構造 `tbl_conversion_path`
-- 

DROP TABLE IF EXISTS `tbl_conversion_path`;
CREATE TABLE IF NOT EXISTS `tbl_conversion_path` (
  `before` varchar(255) NOT NULL DEFAULT '',
  `after` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY  (`before`,`after`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
--
-- テーブルの構造 `tbl_counter`
--

DROP TABLE IF EXISTS `tbl_counter`;
CREATE TABLE IF NOT EXISTS `tbl_counter` (
  `user_id` int(10) unsigned DEFAULT '0',
  `approve_id` smallint(5) unsigned DEFAULT '0',
  `cate_id` smallint(5) unsigned DEFAULT '0',
  `page_id` int(10) unsigned DEFAULT '0',
  `group_id` int(10) unsigned DEFAULT '0',
  `template_id` smallint(5) unsigned DEFAULT '0',
  `library_id` smallint(5) unsigned DEFAULT '0',
  `index_id` smallint(5) unsigned DEFAULT '0',
  `inquiry_id` int(10) unsigned DEFAULT '0',
  `enquete_id` int(10) unsigned DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_department`
--

DROP TABLE IF EXISTS `tbl_department`;
CREATE TABLE IF NOT EXISTS `tbl_department` (
  `dept_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level` tinyint(4) NOT NULL DEFAULT '0',
  `dept_code` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `dept_name` text,
  `tel` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `sort_order` smallint(6) NOT NULL DEFAULT '0',
  `url` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`dept_id`),
  KEY `IDX_tbl_department_1` (`dept_code`),
  KEY `IDX_tbl_department_2` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_publish_enquete`
--

DROP TABLE IF EXISTS `tbl_publish_enquete`;
CREATE TABLE IF NOT EXISTS `tbl_publish_enquete` (
  `enquete_id` int(10) NOT NULL DEFAULT '0',
  `page_id` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `sort_order` smallint(6) NOT NULL DEFAULT '0',
  `require_flg` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text,
  `control_kind` varchar(20) DEFAULT NULL,
  `img_src` varchar(255) DEFAULT NULL,
  `img_alt` varchar(255) DEFAULT NULL,
  `desc_mail_flg` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`enquete_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_publish_enquete_detail`
--

DROP TABLE IF EXISTS `tbl_publish_enquete_detail`;
CREATE TABLE IF NOT EXISTS `tbl_publish_enquete_detail` (
  `enquete_id` int(10) NOT NULL DEFAULT '0',
  `enquete_no` tinyint(4) NOT NULL DEFAULT '0',
  `setting_info1` varchar(255) DEFAULT NULL,
  `setting_info2` varchar(255) DEFAULT NULL,
  `setting_info3` varchar(255) DEFAULT NULL,
  `setting_info4` varchar(255) DEFAULT NULL,
  `setting_info5` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`enquete_id`,`enquete_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- テーブルの構造 `tbl_work_enquete`
-- 

DROP TABLE IF EXISTS `tbl_work_enquete`;
CREATE TABLE IF NOT EXISTS `tbl_work_enquete` (
  `enquete_id` int(10) NOT NULL DEFAULT '0',
  `page_id` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `sort_order` smallint(6) NOT NULL DEFAULT '0',
  `require_flg` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text,
  `control_kind` varchar(20) DEFAULT NULL,
  `img_src` varchar(255) DEFAULT NULL,
  `img_alt` varchar(255) DEFAULT NULL,
  `desc_mail_flg` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`enquete_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- テーブルの構造 `tbl_work_enquete_detail`
-- 
DROP TABLE IF EXISTS `tbl_work_enquete_detail`;
CREATE TABLE IF NOT EXISTS `tbl_work_enquete_detail` (
  `enquete_id` int(10) NOT NULL DEFAULT '0',
  `enquete_no` tinyint(4) NOT NULL DEFAULT '0',
  `setting_info1` varchar(255) DEFAULT NULL,
  `setting_info2` varchar(255) DEFAULT NULL,
  `setting_info3` varchar(255) DEFAULT NULL,
  `setting_info4` varchar(255) DEFAULT NULL,
  `setting_info5` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`enquete_id`,`enquete_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_faq`
--

DROP TABLE IF EXISTS `tbl_faq`;
CREATE TABLE IF NOT EXISTS `tbl_faq` (
  `faq_id` int(10) NOT NULL DEFAULT '0',
  `cate_code` varchar(20) DEFAULT NULL,
  `charge` varchar(255) DEFAULT NULL,
  `question_title` varchar(255) DEFAULT NULL,
  `question_context` text,
  `answer_context` text,
  `status` smallint(6) DEFAULT '101',
  `publish_cls` tinyint(1) NOT NULL DEFAULT '0',
  `create_cls` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(32) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `sort_order` smallint(6) DEFAULT NULL,
  `special_out_flg` tinyint(1) NOT NULL DEFAULT '0',
  `regist_datatime` datetime DEFAULT NULL,
  `answer_datetime` datetime DEFAULT NULL,
  `publish_datetime` datetime DEFAULT NULL,
  `distribute` tinyint(3) unsigned DEFAULT '0',
  `send_back` varchar(255) DEFAULT NULL,
  `answer1` text,
  `answer2` text,
  `answer3` text,
  `answer4` text,
  `answer5` text,
  `answer6` text,
  `answer7` text,
  `answer8` text,
  `answer9` text,
  `answer10` text,
  `answer11` text,
  `answer12` text,
  `answer13` text,
  `answer14` text,
  `answer15` text,
  `answer16` text,
  `answer17` text,
  `answer18` text,
  `answer19` text,
  `answer20` text,
  `referrer_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`faq_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_fck_images`
--

DROP TABLE IF EXISTS `tbl_fck_images`;
CREATE TABLE IF NOT EXISTS `tbl_fck_images` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `regist_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_fck_links`
--

DROP TABLE IF EXISTS `tbl_fck_links`;
CREATE TABLE IF NOT EXISTS `tbl_fck_links` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `file_exte` varchar(255) DEFAULT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `regist_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_handler`
--

DROP TABLE IF EXISTS `tbl_handler`;
CREATE TABLE IF NOT EXISTS `tbl_handler` (
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item1` varchar(255) DEFAULT NULL,
  `item2` varchar(255) DEFAULT NULL,
  `item3` varchar(255) DEFAULT NULL,
  `item4` varchar(255) DEFAULT NULL,
  `item5` varchar(255) DEFAULT NULL,
  KEY `IDX_tbl_handler_1` (`class`),
  KEY `TEST_INDEX` (`class`,`item1`),
  KEY `IDX_tbl_handler_2` (`class`,`item1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_infomation`
--

DROP TABLE IF EXISTS `tbl_infomation`;
CREATE TABLE IF NOT EXISTS `tbl_infomation` (
  `info` text,
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_library`
--

DROP TABLE IF EXISTS `tbl_library`;
CREATE TABLE IF NOT EXISTS `tbl_library` (
  `library_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `library_ver` int(10) unsigned NOT NULL DEFAULT '1',
  `area` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `user_parmission` tinyint(1) DEFAULT '1',
  `context` longtext,
  `sort_order` smallint(6) NOT NULL DEFAULT '0',
  `disp_area` text,
  `all_area_flg` tinyint(1) NOT NULL DEFAULT '1',
  `is_open_autolink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`library_id`,`library_ver`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_lnavi_handler`
--

DROP TABLE IF EXISTS `tbl_lnavi_handler`;
CREATE TABLE IF NOT EXISTS `tbl_lnavi_handler` (
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item1` varchar(255) DEFAULT NULL,
  `item2` varchar(255) DEFAULT NULL,
  `item3` varchar(255) DEFAULT NULL,
  `item4` varchar(255) DEFAULT NULL,
  `item5` text,
  `item6` text,
  KEY `IDX_tbl_lnavi_handler_1` (`class`),
  KEY `IDX_tbl_lnavi_handler_2` (`class`,`item1`),
  KEY `IDX_tbl_lnavi_handler_3` (`class`,`item2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_logs`
--

DROP TABLE IF EXISTS `tbl_logs`;
CREATE TABLE IF NOT EXISTS `tbl_logs` (
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_class` tinyint(4) DEFAULT NULL,
  `dept_code` varchar(20) DEFAULT NULL,
  `dept_name` varchar(255) DEFAULT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `action_datetime` datetime DEFAULT NULL,
  `action_status` smallint(5) unsigned DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  KEY `IDX_tbl_logs_1` (`action_datetime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_output`
--

DROP TABLE IF EXISTS `tbl_output`;
CREATE TABLE IF NOT EXISTS `tbl_output` (
  `output_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `page_output_flg` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `extension` varchar(255) DEFAULT NULL,
  `encode` varchar(64) DEFAULT NULL,
  `output_kind` tinyint(1) DEFAULT NULL,
  `output_path` varchar(255) DEFAULT NULL,
  `output_order` varchar(255) DEFAULT NULL,
  `output_default_check` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `max_result` int(11) DEFAULT NULL,
  PRIMARY KEY (`output_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_output_handler`
--

DROP TABLE IF EXISTS `tbl_output_handler`;
CREATE TABLE IF NOT EXISTS `tbl_output_handler` (
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item1` varchar(255) DEFAULT NULL,
  `item2` varchar(255) DEFAULT NULL,
  `item3` varchar(255) DEFAULT NULL,
  `item4` varchar(255) DEFAULT NULL,
  `item5` varchar(255) DEFAULT NULL,
  KEY `IDX_tbl_output_handler_1` (`class`),
  KEY `IDX_tbl_output_handler_2` (`class`,`item1`),
  KEY `IDX_tbl_output_handler_3` (`class`,`item2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_output_history`
--

DROP TABLE IF EXISTS `tbl_output_history`;
CREATE TABLE IF NOT EXISTS `tbl_output_history` (
  `history_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `output_datetime` datetime DEFAULT NULL,
  `note` text,
  `output_id` int(10) unsigned NOT NULL DEFAULT '0',
  `disp_flg` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_publish_images`
--

DROP TABLE IF EXISTS `tbl_publish_images`;
CREATE TABLE IF NOT EXISTS `tbl_publish_images` (
  `page_id` int(10) unsigned NOT NULL DEFAULT '0',
  `no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `src` varchar(255) DEFAULT NULL,
  `alt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`page_id`,`no`),
  KEY `IDX_tbl_publish_image_2` (`src`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_publish_inquiry`
--

DROP TABLE IF EXISTS `tbl_publish_inquiry`;
CREATE TABLE IF NOT EXISTS `tbl_publish_inquiry` (
  `inquiry_id` int(10) unsigned NOT NULL DEFAULT '0',
  `inquiry_no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `dept_code` varchar(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `anex_number` varchar(255) DEFAULT NULL,
  `drxt_number` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`inquiry_id`,`inquiry_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_publish_kanko`
--

DROP TABLE IF EXISTS `tbl_publish_kanko`;
CREATE TABLE IF NOT EXISTS `tbl_publish_kanko` (
  `page_id` int(10) NOT NULL DEFAULT '0',
  `no` int(4) NOT NULL DEFAULT '0',
  `item` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `context` longtext,
  `kind` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`page_id`,`no`),
  KEY `IDX_tbl_publish_kanko_1` (`item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_publish_links`
--

DROP TABLE IF EXISTS `tbl_publish_links`;
CREATE TABLE IF NOT EXISTS `tbl_publish_links` (
  `page_id` int(10) unsigned NOT NULL DEFAULT '0',
  `no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `outer_flg` tinyint(1) DEFAULT '0',
  `path` varchar(255) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `file_exte` varchar(255) DEFAULT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`page_id`,`no`),
  KEY `IDX_tbl_publish_links_2` (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_publish_map`
--

DROP TABLE IF EXISTS `tbl_publish_map`;
CREATE TABLE IF NOT EXISTS `tbl_publish_map` (
  `page_id` int(10) unsigned NOT NULL DEFAULT '0',
  `map_name` varchar(255) DEFAULT NULL,
  `map_url` text,
  PRIMARY KEY (`page_id`, `map_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_publish_page`
--

DROP TABLE IF EXISTS `tbl_publish_page`;
CREATE TABLE IF NOT EXISTS `tbl_publish_page` (
  `page_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cate_code` varchar(20) DEFAULT NULL,
  `template_id` smallint(5) unsigned DEFAULT NULL,
  `template_ver` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `ancestor_path` text,
  `user_id` int(10) unsigned DEFAULT NULL,
  `dir_path` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `header` varchar(255) DEFAULT NULL,
  `context` longtext,
  `keywords` text,
  `description` text,
  `summary` text,
  `inquiry_flg` tinyint(1) DEFAULT '0',
  `inquiry_memo` text,
  `index_flg` tinyint(1) DEFAULT '0',
  `index_title` varchar(255) DEFAULT NULL,
  `contents_top_flg` tinyint(1) DEFAULT '0',
  `publish_start` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `addable_flg` tinyint(1) DEFAULT '1',
  `work_class` tinyint(4) DEFAULT '1',
  `status` smallint(6) DEFAULT '101',
  `bak_status` smallint(6) DEFAULT NULL,
  `user_lock` int(10) unsigned DEFAULT NULL,
  `regist_datetime` datetime DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `template_kind` tinyint(1) DEFAULT NULL,
  `inquiry_id` int(10) DEFAULT NULL,
  `open_start` datetime DEFAULT NULL,
  `open_end` datetime DEFAULT NULL,
  `enquete_kind` tinyint(1) DEFAULT NULL,
  `enquete_status` smallint(6) DEFAULT NULL,
  `enquete_email` text,
  `close_flg` tinyint(1) DEFAULT '0',
  `faq_id` int(10) unsigned DEFAULT NULL,
  `output_html_flg` tinyint(1) DEFAULT '1',
  `menu_generation_order`  varchar(255) default NULL,
  PRIMARY KEY (`page_id`),
  KEY `idx_publish_page1` (`page_id`,`work_class`,`cate_code`),
  KEY `IDX_tbl_publish_page_1` (`file_path`),
  KEY `IDX_tbl_publish_page_2` (`work_class`),
  KEY `IDX_tbl_publish_page_3` (`user_id`),
  KEY `IDX_tbl_publish_page_4` (`template_id`),
  KEY `IDX_tbl_publish_page_5` (`inquiry_id`),
  KEY `IDX_tbl_publish_page_6` (`faq_id`),
  KEY `IDX_tbl_publish_page_7` (`status`),
  KEY `IDX_tbl_publish_page_8` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_represent`
--

DROP TABLE IF EXISTS `tbl_represent`;
CREATE TABLE IF NOT EXISTS `tbl_represent` (
  `password` varchar(255) NOT NULL DEFAULT '',
  `invalid_flg` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`password`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_template`
--

DROP TABLE IF EXISTS `tbl_template`;
CREATE TABLE IF NOT EXISTS `tbl_template` (
  `template_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `template_ver` int(10) unsigned NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '',
  `temp_txt` varchar(255) DEFAULT NULL,
  `edit_css` varchar(255) DEFAULT NULL,
  `style_xml` varchar(255) DEFAULT NULL,
  `approve_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `template_kind` tinyint(1) DEFAULT NULL,
  `sort_order` smallint(6) NOT NULL DEFAULT '32767',
  `disp_flg` tinyint(1) NOT NULL DEFAULT '1',
  `nonuse_library_id` text,
  `kanko_xml` varchar(255) DEFAULT NULL,
  `kanko_type` tinyint(1) unsigned DEFAULT NULL,
  `acc_flg` tinyint(1) NOT NULL DEFAULT '0',
  `mobile_temp_txt` varchar(255) DEFAULT NULL,
  `use_site_id` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`template_id`,`template_ver`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE IF NOT EXISTS `tbl_user` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `dept_name` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `login_id` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `dept_code` varchar(20) NOT NULL DEFAULT '',
  `class` tinyint(4) NOT NULL DEFAULT '0',
  `sourceEdit_flg` tinyint(1) NOT NULL DEFAULT '0',
  `pass_last_upd` datetime DEFAULT '0000-00-00 00:00:00',
  `approve_edit_flg` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `login_error_count` int(10) NOT NULL DEFAULT '0',
  `login_error_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `IDX_tbl_user_1` (`dept_code`),
  KEY `IDX_tbl_user_2` (`login_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_work_images`
--

DROP TABLE IF EXISTS `tbl_work_images`;
CREATE TABLE IF NOT EXISTS `tbl_work_images` (
  `page_id` int(10) unsigned NOT NULL DEFAULT '0',
  `no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `src` varchar(255) DEFAULT NULL,
  `alt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`page_id`,`no`),
  KEY `IDX_tbl_work_image_2` (`src`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_work_inquiry`
--

DROP TABLE IF EXISTS `tbl_work_inquiry`;
CREATE TABLE IF NOT EXISTS `tbl_work_inquiry` (
  `inquiry_id` int(10) unsigned NOT NULL DEFAULT '0',
  `inquiry_no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `dept_code` varchar(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `anex_number` varchar(255) DEFAULT NULL,
  `drxt_number` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`inquiry_id`,`inquiry_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_work_kanko`
--

DROP TABLE IF EXISTS `tbl_work_kanko`;
CREATE TABLE IF NOT EXISTS `tbl_work_kanko` (
  `page_id` int(10) NOT NULL DEFAULT '0',
  `no` int(4) NOT NULL DEFAULT '0',
  `item` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `context` longtext,
  `kind` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`page_id`,`no`),
  KEY `IDX_tbl_work_kanko_1` (`item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_work_links`
--

DROP TABLE IF EXISTS `tbl_work_links`;
CREATE TABLE IF NOT EXISTS `tbl_work_links` (
  `page_id` int(10) unsigned NOT NULL DEFAULT '0',
  `no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `outer_flg` tinyint(1) DEFAULT '0',
  `path` varchar(255) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `file_exte` varchar(255) DEFAULT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`page_id`,`no`),
  KEY `IDX_tbl_work_links_2` (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_work_map`
--

DROP TABLE IF EXISTS `tbl_work_map`;
CREATE TABLE IF NOT EXISTS `tbl_work_map` (
  `page_id` int(10) unsigned NOT NULL DEFAULT '0',
  `map_name` varchar(255) DEFAULT NULL,
  `map_url` text,
  PRIMARY KEY (`page_id`, `map_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_work_page`
--

DROP TABLE IF EXISTS `tbl_work_page`;
CREATE TABLE IF NOT EXISTS `tbl_work_page` (
  `page_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT NULL,
  `cate_code` varchar(20) DEFAULT NULL,
  `template_id` smallint(5) unsigned DEFAULT NULL,
  `template_ver` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `approve_id` smallint(5) unsigned DEFAULT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `header` varchar(255) DEFAULT NULL,
  `context` longtext,
  `keywords` text,
  `description` text,
  `summary` text,
  `inquiry_flg` tinyint(1) DEFAULT '0',
  `inquiry_memo` text,
  `index_flg` tinyint(1) DEFAULT '0',
  `index_title` varchar(255) DEFAULT NULL,
  `contents_top_flg` tinyint(1) DEFAULT '0',
  `publish_start` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `work_class` tinyint(4) DEFAULT '1',
  `status` smallint(6) DEFAULT '101',
  `regist_datetime` datetime DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `template_kind` tinyint(1) DEFAULT NULL,
  `inquiry_id` int(10) DEFAULT NULL,
  `open_start` datetime DEFAULT NULL,
  `open_end` datetime DEFAULT NULL,
  `enquete_kind` tinyint(1) DEFAULT NULL,
  `enquete_status` smallint(6) DEFAULT NULL,
  `enquete_email` text,
  `close_flg` tinyint(1) DEFAULT '0',
  `faq_id` int(10) unsigned DEFAULT NULL,
  `output_html_flg` tinyint(1) DEFAULT '1',
  `menu_generation_order`  varchar(255) default NULL,
  PRIMARY KEY (`page_id`),
  KEY `IDX_tbl_work_page_1` (`template_id`),
  KEY `IDX_tbl_work_page_2` (`file_path`),
  KEY `IDX_tbl_work_page_3` (`user_id`),
  KEY `IDX_tbl_work_page_4` (`work_class`),
  KEY `IDX_tbl_work_page_5` (`inquiry_id`),
  KEY `IDX_tbl_work_page_6` (`faq_id`),
  KEY `IDX_tbl_work_page_7` (`group_id`),
  KEY `IDX_tbl_work_page_8` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_sitemap`
--

DROP TABLE IF EXISTS `tbl_sitemap`;
CREATE TABLE IF NOT EXISTS `tbl_sitemap` (
  `sitemap_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `floor` int(4) unsigned NOT NULL,
  `add_page` tinyint(1) unsigned NOT NULL,
  `auto_add_page` tinyint(1) unsigned NOT NULL,
  `language` tinyint(1) unsigned NOT NULL,
  `sitemap_source` text NOT NULL,
  `sitemap_top_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`sitemap_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_sitemap_handler`
--

DROP TABLE IF EXISTS `tbl_sitemap_handler`;
CREATE TABLE IF NOT EXISTS `tbl_sitemap_handler` (
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item1` varchar(255) DEFAULT NULL,
  `item2` varchar(255) DEFAULT NULL,
  `item3` varchar(255) DEFAULT NULL,
  `item4` varchar(255) DEFAULT NULL,
  `item5` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_disaster_handler`
--

DROP TABLE IF EXISTS `tbl_disaster_handler`;
CREATE TABLE IF NOT EXISTS `tbl_disaster_handler` (
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item1` varchar(255) DEFAULT NULL,
  `item2` varchar(255) DEFAULT NULL,
  `item3` varchar(255) DEFAULT NULL,
  `item4` varchar(255) DEFAULT NULL,
  KEY `IDX_tbl_disaster_handler_1` (`class`),
  KEY `IDX_tbl_disaster_handler_2` (`class`,`item1`),
  KEY `IDX_tbl_disaster_handler_3` (`class`,`item2`),
  KEY `IDX_tbl_disaster_handler_4` (`class`,`item3`),
  KEY `IDX_tbl_disaster_handler_5` (`class`,`item4`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_auto_link_handler`
--

DROP TABLE IF EXISTS `tbl_auto_link_handler`;
CREATE TABLE IF NOT EXISTS `tbl_auto_link_handler` (
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item1` varchar(255) DEFAULT NULL,
  `item2` varchar(255) DEFAULT NULL,
  `item3` varchar(255) DEFAULT NULL,
  `item4` varchar(255) DEFAULT NULL,
  `item5` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_publish_event`
--

DROP TABLE IF EXISTS `tbl_publish_event`;
CREATE TABLE IF NOT EXISTS `tbl_publish_event` (
  `page_id` int(11) NOT NULL,
  `no` int(11) NOT NULL,
  `open_start` datetime DEFAULT NULL,
  `open_end` datetime DEFAULT NULL,
  PRIMARY KEY (`page_id`,`no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_work_event`
--

DROP TABLE IF EXISTS `tbl_work_event`;
CREATE TABLE IF NOT EXISTS `tbl_work_event` (
  `page_id` int(11) NOT NULL,
  `no` int(11) NOT NULL,
  `open_start` datetime DEFAULT NULL,
  `open_end` datetime DEFAULT NULL,
  PRIMARY KEY (`page_id`,`no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
--
-- テーブルの構造 `tbl_shared_upload`
--

DROP TABLE IF EXISTS `tbl_shared_upload`;
CREATE TABLE `tbl_shared_upload` (
  `id` INT(10) NOT NULL AUTO_INCREMENT,
  `file_path` VARCHAR(255) NOT NULL,
  `upload_class` TINYINT(1) NOT NULL DEFAULT 0,
  `entry_datetime` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- ------------------------------
-- オープンデータ
-- ------------------------------
--
-- テーブルの構造 `tbl_publish_open_data`
--
DROP TABLE IF EXISTS `tbl_publish_open_data`;
CREATE TABLE IF NOT EXISTS `tbl_publish_open_data` (
  `page_id` int(10) unsigned NOT NULL DEFAULT '0',
  `no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `opendata_type` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '0',
  `opendata_title` varchar(255) DEFAULT NULL,
  `opendata_file_path` varchar(255) DEFAULT NULL,
  `file_extention` varchar(255) DEFAULT NULL,
  `file_bytes` smallint(5) unsigned DEFAULT NULL,
  `link_target` varchar(255) DEFAULT NULL,
  `opendata_summary` text,
  `opendata_license` smallint(5) unsigned DEFAULT NULL,
  `point_of_time` datetime DEFAULT NULL,
  `publication_date` datetime DEFAULT NULL,
  `opendata_category` varchar(255) DEFAULT NULL,
  `opendata_keywords` text,
  `od_data_type` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`page_id`,`no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルの構造 `tbl_work_open_data`
--
DROP TABLE IF EXISTS `tbl_work_open_data`;
CREATE TABLE IF NOT EXISTS `tbl_work_open_data` (
  `page_id` int(10) unsigned NOT NULL DEFAULT '0',
  `no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `opendata_type` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '0',
  `opendata_title` varchar(255) DEFAULT NULL,
  `opendata_file_path` varchar(255) DEFAULT NULL,
  `file_extention` varchar(255) DEFAULT NULL,
  `file_bytes` smallint(5) unsigned DEFAULT NULL,
  `link_target` varchar(255) DEFAULT NULL,
  `opendata_summary` text,
  `opendata_license` smallint(5) unsigned DEFAULT NULL,
  `point_of_time` datetime DEFAULT NULL,
  `publication_date` datetime DEFAULT NULL,
  `opendata_category` varchar(255) DEFAULT NULL,
  `opendata_keywords` text,
  `od_data_type` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`page_id`,`no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- 移行作業用：否認時ファイル添付機能
--
-- テーブルの構造 `tbl_ikou_denial_log`
--

DROP TABLE IF EXISTS `tbl_ikou_denial_log`;
CREATE TABLE IF NOT EXISTS `tbl_ikou_denial_log` (
  `page_id` int(10) unsigned NOT NULL DEFAULT '0',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `group_name` varchar(255) DEFAULT NULL,
  `approve_req_comment` varchar(255) DEFAULT NULL,
  `denial_reason` varchar(255) DEFAULT NULL,
  `attached_file` varchar(255) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `request_datetime` datetime DEFAULT NULL,
  `approver_id` int(10) unsigned DEFAULT NULL,
  `approve_datetime` datetime DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`page_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------

