--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tbl_open_data; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tbl_open_data (
    data_id integer,
    data_num smallint,
    data_link_title character varying(256),
    data_link_url character varying(512),
    data_link_target character varying(8),
    summary text,
    license smallint,
    category character varying(256),
    keyword character varying(256),
    data_type character varying(16),
    data_size integer,
    data_time date,
    data_upddt date,
    data_hidden smallint,
    data_open smallint,
    dept_code character varying(256),
    page_id integer,
    path character varying(256),
    title character varying(256),
    template_id smallint,
    cate_1st character varying(16),
    cate_2st character varying(16),
    cate_3st character varying(16),
    cate_4st character varying(16),
    publish_start timestamp without time zone,
    publish_end timestamp without time zone,
    adddt timestamp without time zone,
    upddt timestamp without time zone,
    od_data_type character varying(256)
);


ALTER TABLE public.tbl_open_data OWNER TO postgres;

--
-- PostgreSQL database dump complete
--

