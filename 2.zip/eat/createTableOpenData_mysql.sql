-- phpMyAdmin SQL Dump
-- version 4.4.15.8
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2019 年 11 月 18 日 13:13
-- サーバのバージョン： 5.5.60-MariaDB
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------

--
-- テーブルの構造 `tbl_open_data`
--

CREATE TABLE IF NOT EXISTS `tbl_open_data` (
  `data_id` int(11) DEFAULT NULL,
  `data_num` smallint(6) DEFAULT NULL,
  `data_link_title` varchar(256) DEFAULT NULL,
  `data_link_url` varchar(512) DEFAULT NULL,
  `data_link_target` varchar(8) DEFAULT NULL,
  `summary` text,
  `license` smallint(6) DEFAULT NULL,
  `category` varchar(256) DEFAULT NULL,
  `keyword` varchar(256) DEFAULT NULL,
  `data_type` varchar(16) DEFAULT NULL,
  `data_size` int(11) DEFAULT NULL,
  `data_time` date DEFAULT NULL,
  `data_upddt` date DEFAULT NULL,
  `data_hidden` smallint(6) DEFAULT NULL,
  `data_open` smallint(6) DEFAULT NULL,
  `dept_code` varchar(256) DEFAULT NULL,
  `page_id` int(11) DEFAULT NULL,
  `path` varchar(256) DEFAULT NULL,
  `title` varchar(256) DEFAULT NULL,
  `template_id` smallint(6) DEFAULT NULL,
  `cate_1st` varchar(16) DEFAULT NULL,
  `cate_2st` varchar(16) DEFAULT NULL,
  `cate_3st` varchar(16) DEFAULT NULL,
  `cate_4st` varchar(16) DEFAULT NULL,
  `publish_start` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `adddt` datetime DEFAULT NULL,
  `upddt` datetime DEFAULT NULL,
  `od_data_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
