-- --------------------------------------------------------
-- 組織に関する設定
-- --------------------------------------------------------
-- tbl_department
INSERT INTO `tbl_department` (`dept_id`, `level`, `dept_code`, `name`, `dept_name`, `tel`, `fax`, `email`, `sort_order`, `url`, `address`) VALUES 
(1, 1, '900000000', 'ダミー部', 'ダミー部', '', '', '', 1, '', ''),
(2, 2, '900001000', 'ダミー課', 'ダミー部ダミー課', '', '', '', 1, '', ''),
(3, 3, '900001001', 'ダミー係', 'ダミー部ダミー課ダミー係', '', '', '', 1, '', '');

-- tbl_handler
INSERT INTO `tbl_handler` (`class`, `item1`, `item2`, `item3`, `item4`, `item5`) VALUES 
(8, '900001001', '/', NULL, NULL, NULL),
(2, '900001001', '1', NULL, NULL, NULL),
(1, '900001001', '/', NULL, NULL, NULL);


-- --------------------------------------------------------
-- ユーザーに関する設定
-- --------------------------------------------------------
-- tbl_user
INSERT INTO `tbl_user` (`user_id`, `name`, `dept_name`, `email`, `login_id`, `password`, `dept_code`, `class`, `sourceEdit_flg`, `pass_last_upd`) VALUES 
(1, 'WebMaster', '', 'system_info@cms8341.jp', 'cms', '8341', '000000000', 5, 1, '2009-01-05 15:48:49'),
(2, 'ダミーページ作成者', 'ダミー部ダミー課ダミー係', 'system_info@cms8341.jp', 'a1-1', '1', '900001001', 1, 0, '2009-01-05 15:48:49');


-- --------------------------------------------------------
-- 承認フローに関する設定
-- --------------------------------------------------------
-- tbl_approve
INSERT INTO `tbl_approve` (`approve_id`, `name`, `approve1`, `approve2`, `approve3`, `approve4`) VALUES 
(1, '承認無しフロー', NULL, NULL, NULL, NULL),
(2, 'マスター承認フロー', NULL, NULL, NULL, '000000000');

-- tbl_represent
INSERT INTO `tbl_represent` (`password`, `invalid_flg`) VALUES ('cms8341', 1);


-- --------------------------------------------------------
-- テンプレートに関する設定
-- --------------------------------------------------------
-- tbl_template
INSERT INTO `tbl_template` (`template_id`, `template_ver`, `name`, `temp_txt`, `edit_css`, `style_xml`, `approve_id`, `template_kind`, `sort_order`, `disp_flg`, `nonuse_library_id`, `kanko_xml`, `kanko_type`, `acc_flg`, `mobile_temp_txt`) VALUES 
(0, 1, 'テンプレートなし', NULL, NULL, NULL, 2, 99, 32767, 1, NULL, NULL, NULL, 0, NULL),
(1, 1, 'ダミートップページ', 'temp1_1.html', '1.css', 'dummy-xml.xml', 2, 1, 1, 1, NULL, '', 0, 0, '');


-- --------------------------------------------------------
-- ライブラリに関する設定
-- --------------------------------------------------------
-- tbl_library
INSERT INTO `tbl_library` VALUES (1, 1, '2', '枠', 1, '<table class="outline">\r\n    <tbody>\r\n        <tr>\r\n            <!-- Convert name="cms8341_outline_s" --><!-- Convert name="cms8341_outline_td_s" -->\r\n            <td>\r\n            <p>本文が入ります</p>\r\n            </td>\r\n            <!-- Convert name="cms8341_outline_td_e" --><!-- Convert name="cms8341_outline_e" -->\r\n        </tr>\r\n    </tbody>\r\n</table>', 1,'',1,0);
INSERT INTO `tbl_library` VALUES (2, 1, '2', '2段組', 1, '<table class="col2">\r\n    <tbody>\r\n        <tr>\r\n            <!-- Convert name="cms8341_col2_s" --><!-- Convert name="cms8341_col2L_s" -->\r\n            <td class="col2L">\r\n            <p>本文が入ります</p>\r\n            </td>\r\n            <!-- Convert name="cms8341_col2L_e" --><!-- Convert name="cms8341_col2R_s" -->\r\n            <td class="col2R">\r\n            <p>本文が入ります</p>\r\n            </td>\r\n            <!-- Convert name="cms8341_col2R_e" --><!-- Convert name="cms8341_col2_e" -->\r\n        </tr>\r\n    </tbody>\r\n</table>', 2,'',1,0);
INSERT INTO `tbl_library` VALUES (3, 1, '2', '3段組', 1, '<table class="col3">\r\n    <tbody>\r\n        <tr>\r\n            <!-- Convert name="cms8341_col3_s" --><!-- Convert name="cms8341_col3L_s" -->\r\n            <td class="col3L">\r\n            <p>本文が入ります</p>\r\n            </td>\r\n            <!-- Convert name="cms8341_col3L_e" --><!-- Convert name="cms8341_col3M_s" -->\r\n            <td class="col3M">\r\n            <p>本文が入ります</p>\r\n            </td>\r\n            <!-- Convert name="cms8341_col3M_e" --><!-- Convert name="cms8341_col3R_s" -->\r\n            <td class="col3R">\r\n            <p>本文が入ります</p>\r\n            </td>\r\n            <!-- Convert name="cms8341_col3R_e" --><!-- Convert name="cms8341_col3_e" -->\r\n        </tr>\r\n    </tbody>\r\n</table>', 3,'',1,0);
INSERT INTO `tbl_library` VALUES (4, 1, '2', '4段組', 1, '<table class="col2">\r\n    <tbody>\r\n        <tr>\r\n            <!-- Convert name="cms8341_col2_s" --><!-- Convert name="cms8341_col2L_s" -->\r\n            <td class="col2L">\r\n            <table class="col2">\r\n                <tbody>\r\n                    <tr>\r\n                        <!-- Convert name="cms8341_col2_s" --><!-- Convert name="cms8341_col2L_s" -->\r\n                        <td class="col2L">\r\n                        <p>本文が入ります</p>\r\n                        </td>\r\n                        <!-- Convert name="cms8341_col2L_e" --><!-- Convert name="cms8341_col2R_s" -->\r\n                        <td class="col2R">\r\n                        <p>本文が入ります</p>\r\n                        </td>\r\n                        <!-- Convert name="cms8341_col2R_e" --><!-- Convert name="cms8341_col2_e" -->\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n            </td>\r\n            <!-- Convert name="cms8341_col2L_e" --><!-- Convert name="cms8341_col2R_s" -->\r\n            <td class="col2R">\r\n            <table class="col2">\r\n                <tbody>\r\n                    <tr>\r\n                        <!-- Convert name="cms8341_col2_s" --><!-- Convert name="cms8341_col2L_s" -->\r\n                        <td class="col2L">\r\n                        <p>本文が入ります</p>\r\n                        </td>\r\n                        <!-- Convert name="cms8341_col2L_e" --><!-- Convert name="cms8341_col2R_s" -->\r\n                        <td class="col2R">\r\n                        <p>本文が入ります</p>\r\n                        </td>\r\n                        <!-- Convert name="cms8341_col2R_e" --><!-- Convert name="cms8341_col2_e" -->\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n            </td>\r\n            <!-- Convert name="cms8341_col2R_e" --><!-- Convert name="cms8341_col2_e" -->\r\n        </tr>\r\n    </tbody>\r\n</table>', 4,'',1,0);
INSERT INTO `tbl_library` VALUES (5, 1, '2', 'キャプション付き画像', 1, '<table width="200" class="img_cap">\r\n    <tbody>\r\n        <tr>\r\n            <!-- Convert name="cms8341_img_cap_s" --><!-- Convert name="cms8341_img_cap_td_s" -->\r\n            <td>\r\n            <p><img height="150" alt="" width="200" src="/cms8341/shared/images/shared/img_dummy.gif" /></p>\r\n            <p>画像キャプション</p>\r\n            </td>\r\n            <!-- Convert name="cms8341_img_cap_td_e" --><!-- Convert name="cms8341_img_cap_e" -->\r\n        </tr>\r\n    </tbody>\r\n</table>', 5,'',1,0);
INSERT INTO `tbl_library` VALUES (6, 1, '2', 'お知らせボックス', 1, '<table class="box_info">\r\n    <tbody>\r\n        <tr>\r\n            <!-- Convert name="cms8341_box_info_1_s" --><!-- Convert name="cms8341_box_info_ttl_td_s" -->\r\n            <td class="box_info_ttl">\r\n            <p>お知らせ</p>\r\n            </td>\r\n            <!-- Convert name="cms8341_box_info_ttl_td_e" --><!-- Convert name="cms8341_box_info_1_e" -->\r\n        </tr>\r\n        <tr>\r\n            <!-- Convert name="cms8341_box_info_2_s" --><!-- Convert name="cms8341_box_info_cnt_td_s" -->\r\n            <td class="box_info_cnt">\r\n            <ul>\r\n                <li><a href="#">テキストテキストテキスト</a> </li>\r\n                <li><a href="#">テキストテキストテキスト</a> </li>\r\n                <li><a href="#">テキストテキストテキスト</a> </li>\r\n            </ul>\r\n            </td>\r\n            <!-- Convert name="cms8341_box_info_cnt_td_e" --><!-- Convert name="cms8341_box_info_2_e" -->\r\n        </tr>\r\n    </tbody>\r\n</table>', 6,'',1,0);
INSERT INTO `tbl_library` VALUES (7, 1, '2', '関連リンクボックス', 1, '<table class="box_link">\r\n    <tbody>\r\n        <tr>\r\n            <!-- Convert name="cms8341_box_link_1_s" --><!-- Convert name="cms8341_box_link_ttl_td_s" -->\r\n            <td class="box_link_ttl">\r\n            <p>関連リンク</p>\r\n            </td>\r\n            <!-- Convert name="cms8341_box_link_ttl_td_e" --><!-- Convert name="cms8341_box_link_1_e" -->\r\n        </tr>\r\n        <tr>\r\n            <!-- Convert name="cms8341_box_link_2_s" --><!-- Convert name="cms8341_box_link_cnt_td_s" -->\r\n            <td class="box_link_cnt">\r\n            <ul>\r\n                <li><a href="#">テキストテキストテキスト</a> </li>\r\n                <li><a href="#">テキストテキストテキスト</a> </li>\r\n                <li><a href="#">テキストテキストテキスト</a> </li>\r\n            </ul>\r\n            </td>\r\n            <!-- Convert name="cms8341_box_link_cnt_td_e" --><!-- Convert name="cms8341_box_link_2_e" -->\r\n        </tr>\r\n    </tbody>\r\n</table>', 7,'',1,0);
INSERT INTO `tbl_library` VALUES (8, 1, '2', 'メニューボックス', 1, '<table class="box_menu">\r\n<tbody>\r\n<tr><!-- Convert name="cms8341_box_menu_1_s" -->\r\n<!-- Convert name="cms8341_box_menu_ttl_td_s" --><td class="box_menu_ttl"><p>メニュータイトル</p></td><!-- Convert name="cms8341_box_menu_ttl_td_e" -->\r\n<!-- Convert name="cms8341_box_menu_1_e" --></tr>\r\n<tr><!-- Convert name="cms8341_box_menu_2_s" -->\r\n<!-- Convert name="cms8341_box_menu_cnt_td_s" --><td class="box_menu_cnt"><ul>\r\n<li><a href="#">テキストテキストテキスト</a> </li>\r\n<li><a href="#">テキストテキストテキスト</a> </li>\r\n<li><a href="#">テキストテキストテキスト</a> </li>\r\n</ul></td><!-- Convert name="cms8341_box_menu_cnt_td_e" -->\r\n<!-- Convert name="cms8341_box_menu_2_e" --></tr>\r\n</tbody>\r\n</table>', 8,'',1,0);


-- --------------------------------------------------------
-- ページに関する設定
-- --------------------------------------------------------
-- tbl_publish_page
INSERT INTO `tbl_publish_page` (`page_id`, `cate_code`, `template_id`, `template_ver`, `parent_id`, `ancestor_path`, `user_id`, `dir_path`, `filename`, `file_path`, `page_title`, `header`, `context`, `keywords`, `description`, `summary`, `inquiry_flg`, `inquiry_memo`, `index_flg`, `index_title`, `contents_top_flg`, `publish_start`, `publish_end`, `addable_flg`, `work_class`, `status`, `bak_status`, `user_lock`, `regist_datetime`, `update_datetime`, `template_kind`, `inquiry_id`, `open_start`, `open_end`, `enquete_kind`, `enquete_status`, `enquete_email`, `close_flg`, `faq_id`, `menu_generation_order`) VALUES 
(1, NULL, 1, 1, NULL, NULL, 1, '/', 'index.html', '/index.html', 'ホーム', NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 0, '2009-01-05 00:00:00', '2010-01-05 00:00:00', 1, 2, 402, NULL, NULL, '2009-01-05 15:48:16', '2009-01-05 15:48:16', 1, NULL, NULL, NULL, NULL, 402, NULL, 0, NULL, '10001');


-- --------------------------------------------------------
-- アクセシビリティチェックに関する設定
-- --------------------------------------------------------
-- tbl_check_config
INSERT INTO `tbl_check_config` (`class`, `check_flg`) VALUES 
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(11, 1),
(12, 1),
(13, 0),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1);

-- tbl_check_pagesize
INSERT INTO `tbl_check_pagesize` (`text_size`, `use_file_size`, `tmp_size_chk`, `edit_size_chk`, `err_handle`, `text_size_k`, `use_file_size_k`) VALUES 
(50, 600, 0, 1, 0, 3, 10);

-- tbl_check_words
INSERT INTO `tbl_check_words` (`word_id`, `class`, `word`, `rep_word`, `rep_word2`, `convert_flg`) VALUES 
(1, 2, '№', 'No.', 'number', 1),
(2, 2, '℡', 'Tel', 'Phone', 1),
(3, 2, 'Ⅰ', '1.', '1.', 1),
(4, 2, 'ⅰ', '1.', '1.', 1),
(5, 2, 'Ⅱ', '2.', '2.', 1),
(6, 2, 'ⅱ', '2.', '2.', 1),
(7, 2, 'Ⅲ', '3.', '3.', 1),
(8, 2, 'ⅲ', '3.', '3.', 1),
(9, 2, 'Ⅳ', '4.', '4.', 1),
(10, 2, 'ⅳ', '4.', '4.', 1),
(11, 2, 'Ⅴ', '5.', '5.', 1),
(12, 2, 'ⅴ', '5.', '5.', 1),
(13, 2, 'Ⅵ', '6.', '6.', 1),
(14, 2, 'ⅵ', '6.', '6.', 1),
(15, 2, 'Ⅶ', '7.', '7.', 1),
(16, 2, 'ⅶ', '7.', '7.', 1),
(17, 2, 'Ⅷ', '8.', '8.', 1),
(18, 2, 'ⅷ', '8.', '8.', 1),
(19, 2, 'Ⅸ', '9.', '9.', 1),
(20, 2, 'ⅸ', '9.', '9.', 1),
(21, 2, 'Ⅹ', '10.', '10.', 1),
(22, 2, 'ⅹ', '10.', '10.', 1),
(23, 2, '∑', 'Σ', '&sum;', 1),
(24, 2, '∟', '└', '└', 1),
(25, 2, '∮', '§', '&sect;', 1),
(26, 2, '∵', '∵', '&there4;', 1),
(27, 2, '≒', '≒', '≒', 1),
(28, 2, '⊿', '△', '△', 1),
(29, 2, '①', '1.', '1.', 1),
(30, 2, '②', '2.', '2.', 1),
(31, 2, '③', '3.', '3.', 1),
(32, 2, '④', '4.', '4.', 1),
(33, 2, '⑤', '5.', '5.', 1),
(34, 2, '⑥', '6.', '6.', 1),
(35, 2, '⑦', '7.', '7.', 1),
(36, 2, '⑧', '8.', '8.', 1),
(37, 2, '⑨', '9.', '9.', 1),
(38, 2, '⑩', '10.', '10.', 1),
(39, 2, '⑪', '11.', '11.', 1),
(40, 2, '⑫', '12.', '12.', 1),
(41, 2, '⑬', '13.', '13.', 1),
(42, 2, '⑭', '14.', '14.', 1),
(43, 2, '⑮', '15.', '15.', 1),
(44, 2, '⑯', '16.', '16.', 1),
(45, 2, '⑰', '17.', '17.', 1),
(46, 2, '⑱', '18.', '18.', 1),
(47, 2, '⑲', '19.', '19.', 1),
(48, 2, '⑳', '20.', '20.', 1),
(49, 2, '〝', '”', '&quot;', 1),
(50, 2, '〟', '”', '&quot;', 1),
(51, 2, '㈱', '(株)', 'Co. Ltd.', 1),
(52, 2, '㈲', '(有)', 'Inc.,', 1),
(53, 2, '㈹', '(代)', 'the pilot number:', 1),
(54, 2, '㊤', '(上)', '(top)', 1),
(55, 2, '㊥', '(中)', '(middle)', 1),
(56, 2, '㊦', '(下)', '(bottom)', 1),
(57, 2, '㊧', '(左)', '(left)', 1),
(58, 2, '㊨', '(右)', '(right)', 1),
(59, 2, '㌃', 'アール', 'are', 1),
(60, 2, '㌍', 'カロリー', 'cal', 1),
(61, 2, '㌔', 'キロ', 'kilo', 1),
(62, 2, '㌘', 'グラム', 'gram', 1),
(63, 2, '㌢', 'センチ', 'centimeter', 1),
(64, 2, '㌣', 'セント', 'cent', 1),
(65, 2, '㌦', 'ドル', 'dollar', 1),
(66, 2, '㌧', 'トン', 'ton', 1),
(67, 2, '㌫', 'パーセント', 'percent', 1),
(68, 2, '㌶', 'ヘクタール', 'ha', 1),
(69, 2, '㌻', 'ページ', 'page', 1),
(70, 2, '㍉', 'ミリ', 'milli', 1),
(71, 2, '㍊', 'ミリバール', 'millibar', 1),
(72, 2, '㍍', 'メートル', 'meter', 1),
(73, 2, '㍑', 'リットル', 'liter', 1),
(74, 2, '㍗', 'ワット', 'watt', 1),
(75, 2, '㍻', '平成', 'Heisei', 1),
(76, 2, '㍼', '昭和', 'Showa', 1),
(77, 2, '㍽', '大正', 'Taisho', 1),
(78, 2, '㍾', '明治', 'Meiji', 1),
(79, 2, '㎎', 'mg', 'mg', 1),
(80, 2, '㎏', 'kg', 'kg', 1),
(81, 2, '㎜', 'mm', 'mm', 1),
(82, 2, '㎝', 'cm', 'cm', 1),
(83, 2, '㎞', 'km', 'km', 1),
(84, 2, '㎡', '平方メートル', 'square meters', 1),
(85, 2, '㎥', '立方メートル', 'cubic meters', 1),
(86, 2, '㏄', 'cc', 'cubic centimeter', 1),
(87, 2, '㏍', 'K.K.', 'Co. Ltd.', 1),
(88, 7, '*', '', '', 1),
(89, 7, '※', '', '', 1),
(90, 7, '■', '', '', 1),
(91, 7, '□', '', '', 1),
(92, 7, '▲', '', '', 1),
(93, 7, '△', '', '', 1),
(94, 7, '▼', '', '', 1),
(95, 7, '▽', '', '', 1),
(96, 7, '◆', '', '', 1),
(97, 7, '◇', '', '', 1),
(98, 7, '○', '', '', 1),
(99, 7, '◎', '', '', 1),
(100, 7, '●', '', '', 1),
(101, 7, '・', '', '', 1),
(102, 7, '＊', '', '', 1),
(103, 8, '０', '0', '0', 1),
(104, 8, '１', '1', '1', 1),
(105, 8, '２', '2', '2', 1),
(106, 8, '３', '3', '3', 1),
(107, 8, '４', '4', '4', 1),
(108, 8, '５', '5', '5', 1),
(109, 8, '６', '6', '6', 1),
(110, 8, '７', '7', '7', 1),
(111, 8, '８', '8', '8', 1),
(112, 8, '９', '9', '9', 1),
(113, 8, 'Ａ', 'A', 'A', 1),
(114, 8, 'ａ', 'a', 'a', 1),
(115, 8, 'Ｂ', 'B', 'B', 1),
(116, 8, 'ｂ', 'b', 'b', 1),
(117, 8, 'Ｃ', 'C', 'C', 1),
(118, 8, 'ｃ', 'c', 'c', 1),
(119, 8, 'Ｄ', 'D', 'D', 1),
(120, 8, 'ｄ', 'd', 'd', 1),
(121, 8, 'Ｅ', 'E', 'E', 1),
(122, 8, 'ｅ', 'e', 'e', 1),
(123, 8, 'Ｆ', 'F', 'F', 1),
(124, 8, 'ｆ', 'f', 'f', 1),
(125, 8, 'Ｇ', 'G', 'G', 1),
(126, 8, 'ｇ', 'g', 'g', 1),
(127, 8, 'Ｈ', 'H', 'H', 1),
(128, 8, 'ｈ', 'h', 'h', 1),
(129, 8, 'Ｉ', 'I', 'I', 1),
(130, 8, 'ｉ', 'i', 'i', 1),
(131, 8, 'Ｊ', 'J', 'J', 1),
(132, 8, 'ｊ', 'j', 'j', 1),
(133, 8, 'Ｋ', 'K', 'K', 1),
(134, 8, 'ｋ', 'k', 'k', 1),
(135, 8, 'Ｌ', 'L', 'L', 1),
(136, 8, 'ｌ', 'l', 'l', 1),
(137, 8, 'Ｍ', 'M', 'M', 1),
(138, 8, 'ｍ', 'm', 'm', 1),
(139, 8, 'Ｎ', 'N', 'N', 1),
(140, 8, 'ｎ', 'n', 'n', 1),
(141, 8, 'Ｏ', 'O', 'O', 1),
(142, 8, 'ｏ', 'o', 'o', 1),
(143, 8, 'Ｐ', 'P', 'P', 1),
(144, 8, 'ｐ', 'p', 'p', 1),
(145, 8, 'Ｑ', 'Q', 'Q', 1),
(146, 8, 'ｑ', 'q', 'q', 1),
(147, 8, 'Ｒ', 'R', 'R', 1),
(148, 8, 'ｒ', 'r', 'r', 1),
(149, 8, 'Ｓ', 'S', 'S', 1),
(150, 8, 'ｓ', 's', 's', 1),
(151, 8, 'Ｔ', 'T', 'T', 1),
(152, 8, 'ｔ', 't', 't', 1),
(153, 8, 'Ｕ', 'U', 'U', 1),
(154, 8, 'ｕ', 'u', 'u', 1),
(155, 8, 'Ｖ', 'V', 'V', 1),
(156, 8, 'ｖ', 'v', 'v', 1),
(157, 8, 'Ｗ', 'W', 'W', 1),
(158, 8, 'ｗ', 'w', 'w', 1),
(159, 8, 'Ｘ', 'X', 'X', 1),
(160, 8, 'ｘ', 'x', 'x', 1),
(161, 8, 'Ｙ', 'Y', 'Y', 1),
(162, 8, 'ｙ', 'y', 'y', 1),
(163, 8, 'Ｚ', 'Z', 'Z', 1),
(164, 8, 'ｚ', 'z', 'z', 1),
(165, 9, '|', '｜', '｜', 1),
(166, 9, '‐', '-', '-', 1),
(167, 9, '，', ',', ',', 1),
(168, 9, '－', '-', '-', 1),
(169, 9, '．', '.', '.', 1),
(170, 9, '｡', '。', '。', 1),
(171, 9, '｢', '「', '「', 1),
(172, 9, '｣', '」', '」', 1),
(173, 9, '､', '、', '、', 1),
(174, 9, '･', '・', '・', 1),
(175, 9, 'ｦ', 'ヲ', 'ヲ', 1),
(176, 9, 'ｧ', 'ァ', 'ァ', 1),
(177, 9, 'ｨ', 'ィ', 'ィ', 1),
(178, 9, 'ｩ', 'ゥ', 'ゥ', 1),
(179, 9, 'ｪ', 'ェ', 'ェ', 1),
(180, 9, 'ｫ', 'ォ', 'ォ', 1),
(181, 9, 'ｬ', 'ャ', 'ャ', 1),
(182, 9, 'ｭ', 'ュ', 'ュ', 1),
(183, 9, 'ｮ', 'ョ', 'ョ', 1),
(184, 9, 'ｯ', 'ッ', 'ッ', 1),
(185, 9, 'ｰ', 'ー', 'ー', 1),
(186, 9, 'ｱ', 'ア', 'ア', 1),
(187, 9, 'ｲ', 'イ', 'イ', 1),
(188, 9, 'ｳ', 'ウ', 'ウ', 1),
(189, 9, 'ｴ', 'エ', 'エ', 1),
(190, 9, 'ｵ', 'オ', 'オ', 1),
(191, 9, 'ｶ', 'カ', 'カ', 1),
(192, 9, 'ｷ', 'キ', 'キ', 1),
(193, 9, 'ｸ', 'ク', 'ク', 1),
(194, 9, 'ｹ', 'ケ', 'ケ', 1),
(195, 9, 'ｺ', 'コ', 'コ', 1),
(196, 9, 'ｻ', 'サ', 'サ', 1),
(197, 9, 'ｼ', 'シ', 'シ', 1),
(198, 9, 'ｽ', 'ス', 'ス', 1),
(199, 9, 'ｾ', 'セ', 'セ', 1),
(200, 9, 'ｿ', 'ソ', 'ソ', 1),
(201, 9, 'ﾀ', 'タ', 'タ', 1),
(202, 9, 'ﾁ', 'チ', 'チ', 1),
(203, 9, 'ﾂ', 'ツ', 'ツ', 1),
(204, 9, 'ﾃ', 'テ', 'テ', 1),
(205, 9, 'ﾄ', 'ト', 'ト', 1),
(206, 9, 'ﾅ', 'ナ', 'ナ', 1),
(207, 9, 'ﾆ', 'ニ', 'ニ', 1),
(208, 9, 'ﾇ', 'ヌ', 'ヌ', 1),
(209, 9, 'ﾈ', 'ネ', 'ネ', 1),
(210, 9, 'ﾉ', 'ノ', 'ノ', 1),
(211, 9, 'ﾊ', 'ハ', 'ハ', 1),
(212, 9, 'ﾋ', 'ヒ', 'ヒ', 1),
(213, 9, 'ﾌ', 'フ', 'フ', 1),
(214, 9, 'ﾍ', 'ヘ', 'ヘ', 1),
(215, 9, 'ﾎ', 'ホ', 'ホ', 1),
(216, 9, 'ﾏ', 'マ', 'マ', 1),
(217, 9, 'ﾐ', 'ミ', 'ミ', 1),
(218, 9, 'ﾑ', 'ム', 'ム', 1),
(219, 9, 'ﾒ', 'メ', 'メ', 1),
(220, 9, 'ﾓ', 'モ', 'モ', 1),
(221, 9, 'ﾔ', 'ヤ', 'ヤ', 1),
(222, 9, 'ﾕ', 'ユ', 'ユ', 1),
(223, 9, 'ﾖ', 'ヨ', 'ヨ', 1),
(224, 9, 'ﾗ', 'ラ', 'ラ', 1),
(225, 9, 'ﾘ', 'リ', 'リ', 1),
(226, 9, 'ﾙ', 'ル', 'ル', 1),
(227, 9, 'ﾚ', 'レ', 'レ', 1),
(228, 9, 'ﾛ', 'ロ', 'ロ', 1),
(229, 9, 'ﾜ', 'ワ', 'ワ', 1),
(230, 9, 'ﾝ', 'ン', 'ン', 1),
(231, 9, 'ﾞ', '゛', '゛', 1),
(232, 9, 'ﾟ', '゜', '゜', 1),
(233, 9, '￥', '&yen;', '&yen;', 1),
(234, 11, 'CMS', 'コンテンツ管理システム', 'コンテンツ管理システム', 1),
(235, 11, 'm2', '平方メートル', 'square meters', 1),
(236, 11, 'm3', '立方メートル', 'cubic meters', 1),
(237, 15, 'ここをクリック', '', '', 1),
(238, 15, 'こちら', '', '', 1),
(239, 16, 'イラスト', '', '', 1),
(240, 16, '写真', '', '', 1);


-- --------------------------------------------------------
-- CMSに関する設定
-- --------------------------------------------------------
-- tbl_infomation
INSERT INTO `tbl_infomation` (`info`, `class`) VALUES ('', 1);

-- tbl_counter
INSERT INTO `tbl_counter` (`user_id`, `approve_id`, `cate_id`, `page_id`, `group_id`, `template_id`, `library_id`, `index_id`, `inquiry_id`, `enquete_id`) VALUES 
(2, 2, 0, 1, 0, 1, 8, 0, 0, 0);
