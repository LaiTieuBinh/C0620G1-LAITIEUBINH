


<?php

class Common extends User {
	// status 
	const ACTIVE = '1';
	const LOCKED = '2';
	const DELETED = '3';
	// gender
	const MALE = '1';
	const FEMALE = '2';
	// role
	const ADMIN = '1';
	const GENERAL = '2';

    // get ip client 
    public static function get_client_ip() {
		$ipaddress = '';
		if (isset($_SERVER['HTTP_CLIENT_IP']))
			$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
		else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
			$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else if(isset($_SERVER['HTTP_X_FORWARDED']))
			$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
		else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
			$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
		else if(isset($_SERVER['HTTP_FORWARDED']))
			$ipaddress = $_SERVER['HTTP_FORWARDED'];
		else if(isset($_SERVER['REMOTE_ADDR']))
			$ipaddress = $_SERVER['REMOTE_ADDR'];
		else
			$ipaddress = 'UNKNOWN';
			
		return $ipaddress;
	}

    // count login fail 
	public static function count_login_fail($email) {

		// create object
        $user = new User();

		// count times fail and update into tbl_users
		$sqlQuery = 'SELECT count_login_fail FROM ' . $user->userTable . ' WHERE email = %s';
		
		$data = $user->config->get_data($sqlQuery, $email);

		foreach ($data as $rows) {	
			$count_login_fail = $rows['count_login_fail'];
			$count_login_fail++;

			$updateQuery = 'UPDATE ' . $user->userTable . ' SET count_login_fail = %s WHERE email = %s';
			$user->config->update_data($updateQuery, $count_login_fail, $email);	
		}
	}
}
?>
