<?php
include('../class/User.php');
$user = new User();
if(!empty($_POST['action']) && $_POST['action'] == 'listUser') {
	$user->get_user_list();
}
if(!empty($_POST['action']) && $_POST['action'] == 'userDelete') {
	$user->delete_user();
}
if(!empty($_POST['action']) && $_POST['action'] == 'getUser') {
	$user->get_user();
}
if(!empty($_POST['action']) && $_POST['action'] == 'addUser') {
	$user->add_user();
}
if(!empty($_POST['action']) && $_POST['action'] == 'updateUser') {
	$user->update_user();
}
if(!empty($_POST['action']) && $_POST['action'] == 'filter') {
	$user->dashboard_filter();
}
?>