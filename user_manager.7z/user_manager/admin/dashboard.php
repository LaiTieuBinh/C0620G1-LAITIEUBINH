<?php 
include('../class/User.php');
$user = new User();
$user->adminLoginStatus();
include('../include/header.php');
?>
<title>User Management System</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel='stylesheet prefetch' href='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css'>
<link rel="stylesheet" href="css/datepicker.css">
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js'></script>

<link rel="stylesheet" href="css/style.css">
<?php include('../include/container.php'); ?>

<div class="container">	
	<div class="row">
		<h2 class = "col-md-4 col-md-offset-4">User Management System</h2>
	</div>	
	<?php include 'menus.php'; ?>
	<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12">   
		<a href="dashboard.php"><strong><span class="fa fa-dashboard"></span>My Dashboard</strong></a>
		<hr>		
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-3">
						<div class="panel panel-default">
							<div class="panel-body bk-primary text-light">
								<div class="stat-panel text-center">
									<div class="stat-panel-number h1 "><?php echo $user->totalUsers(""); ?></div>
									<div class="stat-panel-title text-uppercase">Total Users</div>
								</div>
							</div>											
						</div>
					</div>
					<div class="col-md-3">
						<div class="panel panel-default">
							<div class="panel-body bk-success text-light">
								<div class="stat-panel text-center">
									<div class="stat-panel-number h1 "><?php echo $user->totalUsers(USER::ACTIVE); ?></div>
									<div class="stat-panel-title text-uppercase">Total Active Users</div>
								</div>
							</div>											
						</div>
					</div>		
					<div class="col-md-3">
						<div class="panel panel-default">
							<div class="panel-body bk-success text-light">
								<div class="stat-panel text-center">
									<div class="stat-panel-number h1 "><?php echo $user->totalUsers(USER::LOCKED); ?></div>
									<div class="stat-panel-title text-uppercase">Total Locked Users</div>
								</div>
							</div>											
						</div>
					</div>													
					<div class="col-md-3">
						<div class="panel panel-default">
							<div class="panel-body bk-danger text-light">
								<div class="stat-panel text-center">												
									<div class="stat-panel-number h1 "><?php echo $user->totalUsers(USER::DELETED); ?></div>
									<div class="stat-panel-title text-uppercase">Total Deleted Users</div>
								</div>
							</div>											
						</div>
					</div>							
				</div>
			</div>
		</div>	
		<div class="row"> 
			<form>
				<div class = "col-md-3">
					<p>Start date: <input type="text" id="datepicker" class="form-control" data-date-format="yyyy-mm-dd"></p>
					<input type="button" id="btn-dashboard-filter" class="btn btn-primary btn-sm" value="Search">
				</div>

				<div class = "col-md-3" style="margin-left: 100px">
					<p>Finish date: <input type="text" id="datepicker2" class="form-control" data-date-format="yyyy-mm-dd"></p>
				</div>

				<div class = "col-md-2" style="margin-left: 80px">
					<p>Filter: 
						<select class="dashboard-filter form-contorl">
							<option value="">---Select---</option>
							<option value="today">Today</option>
							<option value="sevenDays">7 Days</option>
							<option value="lastMonth">Last Month</option>
							<option value="month">Month</option>
							<option value="year">Year</option>
						</select>
					</p>
				</div>
			</form>
		</div>	
		<div class="row"> 
			<div id="chart" style="height: 250px;"></div>
		</div>
	</div>
</div>	

<script type="text/javascript">
	$(function () {
	$("#datepicker").datepicker({ 
			autoclose: true, 
			todayHighlight: true
	}).datepicker('update', new Date());

	$("#datepicker2").datepicker({ 
			autoclose: true, 
			todayHighlight: true
	}).datepicker('update', new Date());
	});
</script>

<script>
	$(document).ready(function(){
		$('.dashboard-filter').change(function(){
			var dashboard_value = $(this).val();
			var action = "filter";

			$.ajax({
				url:"action.php",
				method:"POST",
				dataType: "JSON",
				data:{dashboard_value:dashboard_value, action:action},
				success:function(data) {					
					chart.setData(data);
				}
			});

			// alert(dashboard_value);
		});

	});

</script>
<?php include('include/footer.php'); ?>
