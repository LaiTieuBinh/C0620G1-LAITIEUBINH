<?php
$serverName = 'localhost';
$userName = 'root';
$password = 'cms-8341';
$dbName = 'my_database';

$conn = new mysqli($serverName, $userName, $password, $dbName);
// var_dump($conn);
// $fp = fopen('class/log.txt', 'a');
// fwrite($fp, 'Item xy passed from User Mike to User Alice' . '<br>');
// file_put_contents($fp, $serverName);
// fclose($fp);

$myfile = fopen("class/log.csv", "w") or die("Unable to open file!");
$txt = $serverName . ',' . $userName . ',' . $password . ',' . $dbName . "\n";
fwrite($myfile, $txt);
fclose($myfile);

 ?>
 