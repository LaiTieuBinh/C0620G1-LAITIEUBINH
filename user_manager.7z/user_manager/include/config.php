<?php
class DbConfig {
    protected $serverName;
    protected $userName;
    protected $password;
    protected $dbName;
    protected $timeZone;
    protected $dbConnect;
    
    // table
    public $userTable = 'tbl_users';
	public $historyTable = 'tbl_histories';

    public function __construct() {	
		$this->dbConnect = $this->connect();
    }

    // connect with db 
    public function connect() {
        $this->serverName = 'localhost';
        $this->userName = 'root';
        $this->password = 'cms-8341';
        $this->dbName = 'my_database';

        $conn = new mysqli($this->serverName, $this->userName, $this->password, $this->dbName);
            if ($conn->connect_error) {
                die("Error failed to connect to MySQL: " . $conn->connect_error);
            } else {
                return $conn;
            }
    }

    // set time zone 
    public function set_time_zone() {
        date_default_timezone_set('Asia/Ho_Chi_Minh');
    }

    // handle data 
    function handle_data($args, $query) {
        foreach ($args as $key => $val) {
            $args[$key] = $this->connect()->real_escape_string($val);
        }

        $query = str_replace("%s", "'%s'", $query); 
        $query = vsprintf($query, $args);
		
		$res = mysqli_query($this->connect(), $query);

        if (!$res) {
			trigger_error('dbgetarr: ' . mysql_error() . ' in '. $query);
		} 
        
        return $res;
    }

	// get data 
    function get_data() {
        $args  = func_get_args();
        $query = array_shift($args);

        $res = $this->handle_data($args, $query);
        if ($res) {
            $data = array();
			while ($row = mysqli_fetch_array($res, MYSQLI_ASSOC)) {
				$data[] = $row;            
			}
			
			return $data;
        }
    }

    // get one row 
    function get_one_row() {
        $args  = func_get_args();
        $query = array_shift($args);

        $res = $this->handle_data($args, $query);
        if ($res) {
            // $data = array();
			// while ($row=mysqli_fetch_row($res)) {
				           
			// }
            while($row = mysqli_fetch_assoc($res)) {
                return $row;
            }
			// return $data;
            
        }
    }

	// update data 
	function update_data() {
        $args  = func_get_args();
        $query = array_shift($args);

        $this->handle_data($args, $query);
    }

	// insert data 
	function insert_data() {
        $args  = func_get_args();
        $query = array_shift($args);

        $this->handle_data($args, $query);
    }
}
?>
