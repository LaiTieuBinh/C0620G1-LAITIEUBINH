<link rel="icon" type="image/png" href="https://www.tugo.com.vn/wp-content/uploads/i-mua-thu-thien-nhien-phu-si-810x459.png">
</head>
<body class="">
	<div role="navigation" class="navbar navbar-default navbar-static-top">
		<?php if (!empty($_SESSION["name"])) { ?>
		<div class="container">
			<div class="navbar-header">
				<button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a href="../user/login.php" class="navbar-brand">USER MANAGER</a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
				<li class="active"><a href="../user/index.php">DASHBOARD</a></li>
				</ul>
			
			</div><!--/.nav-collapse -->
		</div>
		<?php } else if (!empty($_SESSION["admin"])) { ?>

		<div class="container">
			<div class="navbar-header">
				<button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a href="../admin/dashboard.php" class="navbar-brand">USER MANAGER</a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
				<li class="active"><a href="../admin/dashboard.php">DASHBOARD</a></li>
				</ul>
			
			</div><!--/.nav-collapse -->
		</div>
		<?php } ?>
	</div>
