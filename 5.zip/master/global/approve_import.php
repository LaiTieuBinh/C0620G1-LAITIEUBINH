<?php
/*
 * 承認フロー管理　承認フロー情報のインポート(approve_import.php)
 */
//--- 設定ファイル読み込み
require ("./.htsetting");

/*---------------------------------------------
	定数 
----------------------------------------------*/
//csvファイルupload先
define("CSV_UPLOAD", "./tmp/");

//csvファイル最大行
define("G_CSV_MAX_LINE", 20000);

//csv項目数
//--- 2006-11-09 Y.Adachi Upd Start
//define("G_CSV_ITEM_MAX", 6);
define("G_CSV_ITEM_MAX", 7);
//--- 2006-11-09 Y.Adachi Upd End


//必須項目チェックフラグ（0:必須チェックなし　1:必須チェックあり)
//--- 2006-11-09 Y.Adachi Upd Start
//承認フローID,承認フロー名称,第一承認者,第二承認者,第三承認者,ウェブマスター承認
//$ChkItemFlg = array(1,1,0,0,0,0,0);
////項目名
//$ChkItemNm = array("承認フローID","承認フロー名称","第一承認者","第二承認者","第三承認者","ウェブマスター承認");


//承認フローID,承認フロー名称,第一承認者,第二承認者,第三承認者,公開責任者,ウェブマスター承認
$ChkItemFlg = array(
		1, 
		1, 
		0, 
		0, 
		0, 
		0, 
		0
);
//項目名
$ChkItemNm = array(
		"承認フローID", 
		"承認フロー名称", 
		"第一承認者", 
		"第二承認者", 
		"第三承認者", 
		"公開責任者", 
		"ウェブマスター承認"
);
//--- 2006-11-09 Y.Adachi Upd End


/*---------------------------------------------------------------------------------
	approve_import.php
---------------------------------------------------------------------------------*/

//---引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError("インポートをするcsvファイルを指定してください。", 2, "javascript:history.back()");
	exit();
}
//---ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError("csvファイルのファイルサイズが0バイトです。", 2, "javascript:history.back()");
	exit();
}

//---アップロード
$frmCsvFnm = CSV_UPLOAD . $frmCsvFnm;
if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $frmCsvFnm) == FALSE) {
	DispError("csvファイルのアップロードに失敗しました。", 2, "javascript:history.back()");
	exit();
}
//(念のため)ファイル存在チェック
if (file_exists($frmCsvFnm) == FALSE) {
	$wk_str = "指定されたファイル【" . $frmCsvFnm . "】が存在しません。";
	DispError($wk_str, 2, "javascript:history.back()");
	exit();
}

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*---csvを読込み、tbl_categoryに追加していく---*/
// トランザクション開始
$objCnc->begin();

//カテゴリ情報の全削除
$sql = "DELETE FROM tbl_approve";
$objDac->execute($sql);

//ファイルを開く
if (!($CsvFno = fopen($frmCsvFnm, 'r'))) {
	//エラーページの表示
	DispError("csvファイルのオープンに失敗しました。", 2, "javascript:history.back()");
	exit();
}
//一行目は飛ばす
$data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE);
//EOFになるまで読み出し
$err_msg = "";
while ($data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
	//配列数のチェック
	$arr_cnt = 0;
	$approve = "";
	foreach ($data as $value) {
		$arr_cnt = $arr_cnt + 1;
	}
	//項目数が少ない場合は配列に追加する
	if ($arr_cnt < G_CSV_ITEM_MAX) {
		$arr_cnt = G_CSV_ITEM_MAX - $arr_cnt;
		//足りない項目数を配列に追加
		for($idx = 0; $idx < $arr_cnt; $idx++) {
			array_push($data, "");
		}
	}
	//各項目のチェック
	if (FALSE == G_ChkCsvItem($data, $ChkItemFlg, $ChkItemNm, $objDac, $err_msg, $approve)) {
		//ファイルClose
		fclose($CsvFno);
		//ファイルを削除
		unlink($frmCsvFnm);
		//ロールバック
		$objCnc->rollback();
		//エラーページの表示
		DispError($err_msg, 2, "javascript:history.back()");
		exit();
	}
	//tbl_approveに追加
	if (FALSE == G_TblApprAdd($data, $approve, $objDac)) {
		//ファイルClose
		fclose($CsvFno);
		//ファイルを削除
		unlink($frmCsvFnm);
		//ロールバック
		$objCnc->rollback();
		//エラーページの表示
		DispError("承認フロー情報の登録に失敗しました。", 2, "javascript:history.back()");
		exit();
	}
}

//ファイルClose
fclose($CsvFno);
//ファイルを削除
if (unlink($frmCsvFnm) == FALSE) {
	//ロールバック
	$objCnc->rollback();
	//エラーページの表示
	DispError("csvファイルの削除に失敗しました。", 2, "javascript:history.back()");
	exit();
}

// コミット
$objCnc->commit();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>承認フロー情報インポート</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
</head>

<body id="cms8341-mainbg">
<div id="cms8341-headarea">
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	id="cms8341-header">
	<tr>
		<td align="left" valign="top"><img src="<?=DIR_PATH_LOGO_MENU?>"
			alt="<?=ALT_LOGO_MENU?>" width="330" height="41"></td>
		<td width="110" align="right" valign="top"><img
			src="<?=DIR_PATH_LOGO_CMSMENU?>" alt="<?=ALT_LOGO_CMSMENU?>"
			width="110" height="41"></td>
	</tr>
</table>
</div>
<div align="center" id="cms8341-user">
<div class="cms8341-area-corner">
<div align="center">
<table border="0" cellspacing="0" cellpadding="5">
	<tr>
		<td align="left">
		<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable">
			<tr>
				<th align="center">承認フロー情報のインポート</th>
			</tr>
			<tr>
				<td align="center">
				<p>承認フロー情報をインポートしました。</p>
				<p>[<a href="./index.php"> データ初期設定INDEXへ </a>]&nbsp;&nbsp;&nbsp;[<a
					href="../approve/index.php"> 承認フロー一覧へ </a>]</p>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</div>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</body>
</html>
<?php
/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	CSV項目のチェック

【引数】	$i_OneData		配列で指定されたcsvデータ（全項目)
		$i_ChkItemFlg	必須チェックフラグ
		$i_ChkItemNm	項目名
		$i_objDac		DB
		$o_ErrMsg		エラーメッセージ
		$o_Approve		承認者
		
【戻値】	True	すべてのチェックが正常に終了
		False	エラーが存在した
		
【備考】
-----------------------------------------------------------------------------*/
function G_ChkCsvItem($i_OneData, $i_ChkItemFlg, $i_ChkItemNm, $i_objDac, &$o_ErrMsg, &$o_Approve) {
	$o_Approve = array();
	
	/*---承認フローID$i_OneData[0]チェック---*/
	//必須チェック
	if (($i_ChkItemFlg[0] == 1) && (strlen($i_OneData[0]) <= 0)) {
		$o_ErrMsg = "承認フローIDが指定されていないデーターが存在します。";
		return FALSE;
	}
	if (strlen($i_OneData[0]) > 0) {
		if (!preg_match('/^[0-9]+$/', $i_OneData[0])) {
			$o_ErrMsg = "不正な値が指定されている承認フローIDが存在します。";
			return FALSE;
		}
		//tbl_approveに重複チェック
		$sql = "SELECT approve_id FROM tbl_approve " . "WHERE (approve_id=" . $i_OneData[0] . ")";
		$i_objDac->execute($sql);
		if ($i_objDac->getRowCount() > 0) {
			$o_ErrMsg = "すでに存在する承認フローIDが指定されているデーターが存在します。【" . $i_OneData[0] . "】";
			return FALSE;
		}
	}
	
	/*---承認フロー名称 $i_OneData[1] ---*/
	//必須チェック
	if (($i_ChkItemFlg[1] == 1) && (strlen($i_OneData[1]) <= 0)) {
		$o_ErrMsg = "承認フロー名称が指定されていないデーターが存在します。";
		return FALSE;
	}
	// 機種依存文字
	if (FALSE == checkMachineCode_sjis($i_OneData[1])) {
		$o_ErrMsg = "機種依存文字が指定されている承認フロー名称が存在します。";
		return FALSE;
	}
	
	/*---第一承認($i_OneData[2])～第三承認($i_OneData[4])チェック---*/
	for($idx = 2; $idx <= 4; $idx++) {
		//必須チェック
		if (($i_ChkItemFlg[$idx] == 1) && (strlen($i_OneData[$idx]) <= 0)) {
			$o_ErrMsg = $i_ChkItemNm[$idx] . "が指定されていないデーターが存在します。";
			return FALSE;
		}
		//組織の存在チェック
		if (strlen($i_OneData[$idx]) > 0) {
			if (($i_OneData[$idx] == 'appr1') || ($i_OneData[$idx] == 'appr2') || ($i_OneData[$idx] == 'appr3')) {
				$o_Approve[$idx] = $i_OneData[$idx];
			}
			else {
				if (!preg_match('/^[0-9]+$/', $i_OneData[$idx])) {
					$o_ErrMsg = "不正な値が指定されている" . $i_ChkItemNm[$idx] . "が存在します。【" . $i_OneData[$idx] . "】";
					return FALSE;
				}
				$dept_code = str_pad($i_OneData[$idx], (CODE_DIGIT_DEPT * 3), "0", STR_PAD_LEFT);
				$sql = "SELECT dept_id FROM tbl_department WHERE dept_code = '" . $dept_code . "'";
				$i_objDac->execute($sql);
				if ($i_objDac->getRowCount() <= 0) {
					$o_ErrMsg = "存在しない組織コードが指定されている" . $i_ChkItemNm[$idx] . "が存在します。【" . $dept_code . "】";
					return FALSE;
				}
				$o_Approve[$idx] = $dept_code;
			}
		}
		else {
			$o_Approve[$idx] = '';
		}
	}
	
	//--- 2006-11-09 Y.Adachi Add Start
	/*---ウェブマスター承認$i_OneData[5]チェック---*/
	//必須チェック
	//--- 2006-11-09 Y.Adachi Upd Start
	if (($i_ChkItemFlg[5] == 1) && (strlen($i_OneData[5]) <= 0)) {
		$o_ErrMsg = "公開責任者が指定されていないデーターが存在します。";
		return FALSE;
	}
	elseif ($i_ChkItemFlg[5] != "") {
		$sql = "SELECT user_id FROM tbl_user AS u ";
		$sql .= "INNER JOIN (SELECT item1 FROM tbl_handler WHERE class = " . HANDLER_CLASS_OEPN_FLG . ") AS h ";
		$sql .= "ON u.user_id = h.item1 ";
		$sql .= "WHERE user_id = " . $i_OneData[5];
		$i_objDac->execute($sql);
		if ($i_objDac->getRowCount() <= 0) {
			$o_ErrMsg = "公開責任者でないユーザーIDが指定されている公開責任者が存在します。【" . $i_OneData[5] . "】<br>" . $sql;
			return FALSE;
		}
	}
	$o_Approve[5] = $i_OneData[5];
	//--- 2006-11-09 Y.Adachi Add End
	

	/*---ウェブマスター承認$i_OneData[5]チェック---*/
	//必須チェック
	//--- 2006-11-09 Y.Adachi Upd Start
	//	if( ($i_ChkItemFlg[5] == 1) && (strlen($i_OneData[5]) <= 0) ){
	//		$o_ErrMsg = "ウェブマスター承認が指定されていないデーターが存在します。";
	//		return FALSE;
	//	} elseif ($i_ChkItemFlg[5] == "") {
	//		$i_ChkItemFlg[5] = 0;
	//	}
	//	if ( ($i_OneData[5] != 0) && ($i_OneData[5] != 1) ) {
	//		$o_ErrMsg = "不正な値が指定されているウェブマスター承認が存在します。";
	//		return FALSE;
	//	}
	//	$o_Approve[5] = ($i_OneData[5] == 1) ? WEB_MASTER_CODE : '';
	

	if (($i_ChkItemFlg[6] == 1) && (strlen($i_OneData[6]) <= 0)) {
		$o_ErrMsg = "ウェブマスター承認が指定されていないデーターが存在します。";
		return FALSE;
	}
	elseif ($i_ChkItemFlg[6] == "") {
		$i_ChkItemFlg[6] = 0;
	}
	if (($i_OneData[6] != 0) && ($i_OneData[6] != 1)) {
		$o_ErrMsg = "不正な値が指定されているウェブマスター承認が存在します。";
		return FALSE;
	}
	$o_Approve[6] = ($i_OneData[6] == 1) ? WEB_MASTER_CODE : '';
	//--- 2006-11-09 Y.Adachi Upd End
	

	return TRUE;

}

/*-----------------------------------------------------------------------------
	tbl_approveにCSVデータを追加

【引数】	$i_OneData	配列で指定されたcsvデータ（全項目)
		$i_Approve	承認者
		$i_objDac	DB
		
【戻値】	True	正常に終了
		False	エラー
		
【備考】
-----------------------------------------------------------------------------*/
function G_TblApprAdd($i_OneData, $i_Approve, $i_objDac) {
	//SQL作成
	$sql = "INSERT INTO tbl_approve ( approve_id, name, approve1, approve2, approve3, approve4) VALUES (";
	$sql = $sql . $i_objDac->_addslashes($i_OneData[0], 'INT') . ", "; //承認フローID
	$sql = $sql . $i_objDac->_addslashes($i_OneData[1], 'TEXT') . ", "; //承認フロー名称
	$sql = $sql . $i_objDac->_addslashes($i_Approve[2], 'TEXT') . ", "; //第一承認者
	$sql = $sql . $i_objDac->_addslashes($i_Approve[3], 'TEXT') . ", "; //第二承認者
	$sql = $sql . $i_objDac->_addslashes($i_Approve[4], 'TEXT') . ", "; //第三承認者
	//--- 2006-11-09 Y.Adachi Upd Start
	//	$sql = $sql . $i_objDac->_addslashes($i_Approve[5], 'TEXT');			//第四承認者
	

	//公開責任者が指定されていない場合
	if ($i_Approve[5] == "") {
		$sql = $sql . $i_objDac->_addslashes($i_Approve[6], 'TEXT'); //第四承認者
	}
	else {
		$sql = $sql . $i_objDac->_addslashes($i_Approve[5], 'TEXT'); //第四承認者
	}
	//--- 2006-11-09 Y.Adachi Upd End
	$sql = $sql . ")";
	
	//実行
	return ($i_objDac->execute(mb_convert_encoding($sql, "utf-8", "auto")));

}

?>
