<?php
/*
 * 承認フロー管理　承認フロー情報のエクスポート(export.php)
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/
//見出し文字
$G_SetHead = "承認フローID,承認フロー名称,第一承認者,第二承認者,第三承認者,公開責任者,ウェブマスター承認\n";

/*---------------------------------------------------------------------------------
	export.php
---------------------------------------------------------------------------------*/

//--- 設定ファイル読み込み
require ("./.htsetting");

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*---CSVファイルの作成---*/
//tbl_categoryの取得
$sql = "SELECT * FROM tbl_approve ORDER BY approve_id";
$objDac->execute($sql);
if ($objDac->getRowCount() <= 0) {
	DispError("承認フロー情報が一件も登録されていません。", 3, "javascript:history.back()");
	exit();
}
//承認フロー情報の作成
//見出し
$ExpCavData = $G_SetHead;
while ($objDac->fetch()) {
	$approve4 = ($objDac->fld['approve4'] != '' && $objDac->fld['approve4'] == WEB_MASTER_CODE) ? '1' : '0';
	
	if ($objDac->fld['approve4'] != '') {
		if ($objDac->fld['approve4'] == WEB_MASTER_CODE) {
			$open_id = '';
			$approve4 = '1';
		}
		else {
			$open_id = $objDac->fld['approve4'];
			$approve4 = '0';
		}
	}
	else {
		$open_id = '';
		$approve4 = '0';
	}
	//ID
	$ExpCavData = $ExpCavData . $objDac->fld['approve_id'] . ",";
	//承認フロー名称
	$ExpCavData = $ExpCavData . $objDac->fld['name'] . ",";
	//第一承認者
	$ExpCavData = $ExpCavData . $objDac->fld['approve1'] . ",";
	//第二承認者
	$ExpCavData = $ExpCavData . $objDac->fld['approve2'] . ",";
	//第三承認者
	$ExpCavData = $ExpCavData . $objDac->fld['approve3'] . ",";
	//公開責任者
	$ExpCavData = $ExpCavData . $open_id . ",";
	//ウェブマスター
	$ExpCavData = $ExpCavData . $approve4 . "\n";
}

/*---一覧画面へと戻る---*/
header("Content-Disposition: attachment; filename=approve.csv");
header('Content-type: text/comma-separated-values');

print mb_convert_encoding($ExpCavData, "sjis", "utf-8");

?>
