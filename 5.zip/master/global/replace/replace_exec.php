<?php
/*
 *
 */
/** 外部ページの取り込み処理 **/
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

require ("./include/replaceFunc.inc");
$replaceFunc = new replaceFunc($objCnc);

//	// ウェブマスター以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	user_error('不正アクセスです。');
}

if (!isset($_SESSION['replace'])) {
	user_error('パラメータエラーです。');
}

if (!isset($_SESSION['replace']['check']) || count($_SESSION['replace']['check']) < 1) {
	user_error('対象ページが一件も選択されていません。');
}
if (!isset($_POST['cms_target_status']) || $_POST['cms_target_status'] == "") {
	user_error('ステータスが指定されていません。');
}
if ($_POST['cms_target_status'] != PUBLISH_TABLE && $_POST['cms_target_status'] != WORK_TABLE) {
	user_error('ステータスに正しくない値が設定されています。');
}
if (!isset($_POST['cms_after_status']) || $_POST['cms_after_status'] == "") {
	user_error('置換後のステータスが指定されていません。');
}
if ($_POST['cms_after_status'] != STATUS_COMP && $_POST['cms_after_status'] != STATUS_PUBLISH_WAIT) {
	user_error('置換後のステータスに正しくない値が設定されています。');
}
if (!isset($_POST['cms_target_word']) || $_POST['cms_target_word'] == "") {
	user_error('置換対象文字列が指定されていません。');
}
if (!isset($_POST['cms_replace_word'])) {
	user_error('置換後文字列が指定されていません。');
}

$page_id_ary = $_SESSION['replace']['check'];
$target_status = $_POST['cms_target_status'];
$after_status = $_POST['cms_after_status'];
$target_word = $_POST['cms_target_word'];
$replace_word = $_POST['cms_replace_word'];

$page_ary = array();

if ($target_status == PUBLISH_TABLE) {
	//公開中ページ
	foreach ((array) $page_id_ary as $page_id => $chbox_id) {
		if (count($chbox_id) < 2) continue;
		if (!$objPage->selectFromID($page_id, PUBLISH_TABLE)) {
			user_error('ページ情報が存在しません。【ページID：' . $page_id . '】');
		}
		
		if ($objPage->selectFromID($page_id, WORK_TABLE)) {
			$page_ary[$page_id]['fld'] = $objPage->fld;
			$page_ary[$page_id]['msg'] = "※このページはステータスが編集中ページとなっています。";
			continue;
		}
		
		//DB登録処理開始
		$objCnc->begin();
		
		if (!$replaceFunc->insertWorkFromPublish($page_id, $after_status)) {
			$objCnc->rollback();
			user_error('公開ページ情報より編集ページ情報の作成に失敗しました。【ページID：' . $page_id . '】');
		}
		
		if (!$objPage->selectFromID($page_id, WORK_TABLE)) {
			$objCnc->rollback();
			user_error('ページ情報の取得に失敗しました。【ページID：' . $page_id . '】');
		}
		
		if (!isset($_SESSION['replace_context'][$page_id])) {
			$page_ary[$page_id]['fld'] = $objPage->fld;
			$page_ary[$page_id]['msg'] = "※編集領域情報の取得に失敗しました。";
			continue;
		}
		$context = $replaceFunc->getReplaceStr($page_id, $_SESSION['replace_context'][$page_id], "3");
		
		$ary = array();
		$ary['page_id'] = $page_id;
		$ary['status'] = $after_status;
		$ary['context'] = $context;
		
		if (!$objPage->update($ary, WORK_TABLE)) {
			$objCnc->rollback();
			user_error('ページ情報の登録に失敗しました。【ページID：' . $page_id . '】');
		}
		
		// 編集領域タグ内文字列置換後の情報反映
		$msg = "";
		if (!$replaceFunc->replace_mode_pageedit($context, $objPage->fld['file_path'], $page_id, $objPage->fld['template_id'], $msg)) {
			$page_ary[$page_id]['fld'] = $objPage->fld;
			$page_ary[$page_id]['msg'] = "※" . $msg;
			continue;
		}
		
		$objCnc->commit();
		
		$page_ary[$page_id]['fld'] = $objPage->fld;
		$page_ary[$page_id]['msg'] = "";
	
	}
}
else {
	//編集中ページ
	foreach ((array) $page_id_ary as $page_id => $chbox_id) {
		if (count($chbox_id) < 2) continue;
		if (!$objPage->selectFromID($page_id, PUBLISH_TABLE)) {
			user_error('ページ情報が存在しません。【ページID：' . $page_id . '】');
		}
		
		$pFld = $objPage->fld;
		
		if (isset($pFld['user_lock']) && $pFld['user_lock'] != "") {
			$page_ary[$page_id]['fld'] = $pFld;
			$page_ary[$page_id]['msg'] = "※現在このページは編集されているため置換できませんでした。";
			continue;
		}
		
		if (!$objPage->selectFromID($page_id, WORK_TABLE)) {
			$page_ary[$page_id]['fld'] = $pFld;
			$page_ary[$page_id]['msg'] = "※編集中ページ情報にこのページ情報は存在しません。";
			continue;
		}
		
		if (!isset($_SESSION['replace_context'][$page_id])) {
			$page_ary[$page_id]['fld'] = $pFld;
			$page_ary[$page_id]['msg'] = "※編集領域情報の取得に失敗しました。";
			continue;
		}
		$context = $replaceFunc->getReplaceStr($page_id, $_SESSION['replace_context'][$page_id], "3");
		
		$ary = array();
		$ary['page_id'] = $page_id;
		$ary['context'] = $context;
		
		//DB登録処理開始
		$objCnc->begin();
		
		if (!$objPage->update($ary, WORK_TABLE)) {
			$objCnc->rollback();
			user_error('ページ情報の登録に失敗しました。【ページID：' . $page_id . '】');
		}
		
		// 編集領域タグ内文字列置換後の情報反映
		$msg = "";
		if (!$replaceFunc->replace_mode_pageedit($context, $objPage->fld['file_path'], $page_id, $objPage->fld['template_id'], $msg)) {
			$page_ary[$page_id]['fld'] = $objPage->fld;
			$page_ary[$page_id]['msg'] = "※" . $msg;
			continue;
		}
		
		$objCnc->commit();
		
		$page_ary[$page_id]['fld'] = $objPage->fld;
		$page_ary[$page_id]['msg'] = "";
	}
}
unset($_SESSION['replace']);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>編集領域一括置換完了画面</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
//	$headerMode = 'replace';
//	include(APPLICATION_ROOT."/common/inc/header_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-replace">
<div><img
	src="<?=RPW?>/admin/master/global/replace/images/bar_edit_area_replace_comp.jpg"
	alt="編集領域一括置換完了画面" width="920" height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">結果</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">一括置換完了ページ一覧</th>
	</tr>
<?php
foreach ($page_ary as $ary) {
	if ($ary['msg'] != "") {
		$result = ' × ';
	}
	else {
		$result = ' ○ ';
	}
	print '<tr>' . "\n";
	print '<td align="center" valign="middle">' . $result . '</td>' . "\n";
	print '<td align="left" valign="top" nowrap><p>' . "\n";
	if ($ary['fld']['page_title'] != '') print '<strong>' . htmlDisplay($ary['fld']['page_title']) . '</strong>' . "\n";
	if ($ary['msg'] != '') print '<br><span class="cms8341-error">' . htmlDisplay($ary['msg']) . '</span>' . "\n";
	print '</p></td>' . "\n";
	print '</tr>' . "\n";
}
?>
</table>
<p align="center"><a href="./replace_index.php"><img
	src="<?=RPW?>/admin/images/btn/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0" style="margin-left: 10px;"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>