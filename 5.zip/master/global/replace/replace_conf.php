<?php
/*
 *
 */
/** 外部ページの取り込み **/
require ("../.htsetting");
$login = $objLogin->login;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage2 = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$objDept = new tbl_department($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/page_control.inc');
$objP = new page_control();

require ("./include/replaceFunc.inc");
$replaceFunc = new replaceFunc($objCnc);

//	// ウェブマスター以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	user_error('不正アクセスです。');
}

if (!isset($_POST['cms_dispMode']) || $_POST['cms_dispMode'] != 'search' && $_POST['cms_dispMode'] != 'pageset' && $_POST['cms_dispMode'] != 'change_num') {
	user_error('パラメータエラーです。');
}

// 検索条件初期値
$search = array(
		'page_title' => '', 
		'url' => '', 
		'publish_start' => '', 
		'publish_end' => '', 
		'pdsy' => '', 
		'pdsm' => '', 
		'pdsd' => '', 
		'pdey' => '', 
		'pdem' => '', 
		'pded' => '', 
		'target1' => '', 
		'target2' => '', 
		'target3' => '', 
		'cate_code' => array(
				'cms_cate1' => '', 
				'cms_cate2' => '', 
				'cms_cate3' => '', 
				'cms_cate4' => ''
		), 
		'p' => 1, 
		'template_ids' => '', 
		'template_kind' => "", 
		'after_status' => STATUS_PUBLISH_WAIT, 
		'target_word' => '', 
		'replace_word' => '', 
		'target_status' => PUBLISH_TABLE, 
		'regular' => '', 
		'case_sensitive' => ''
);

if (isset($_SESSION['search'])) {
	$search = $_SESSION['search'];
}

if (isset($_SESSION['search'])) unset($_SESSION['search']);
gd_errorhandler_ini_set("html0", RPW . '/admin/master/global/replace/replace_index.php?bak=1');

//エラーチェック
if (!isset($_POST['cms_target_status']) || $_POST['cms_target_status'] == "") {
	user_error('ステータスが指定されていません。。');
}
if ($_POST['cms_target_status'] != PUBLISH_TABLE && $_POST['cms_target_status'] != WORK_TABLE) {
	user_error('ステータスに正しくない値が設定されています。');
}
if (!isset($_POST['cms_after_status']) || $_POST['cms_after_status'] == "") {
	user_error('置換後のステータスが指定されていません。。');
}
if ($_POST['cms_after_status'] != STATUS_COMP && $_POST['cms_after_status'] != STATUS_PUBLISH_WAIT) {
	user_error('置換後のステータスに正しくない値が設定されています。');
}
if (!isset($_POST['cms_target_word']) || $_POST['cms_target_word'] == "") {
	user_error('置換対象文字列が指定されていません。');
}
if (!isset($_POST['cms_replace_word'])) {
	user_error('置換後文字列が指定されていません。');
}
$after_status = (isset($_POST['cms_after_status']) ? $_POST['cms_after_status'] : STATUS_PUBLISH_WAIT);
$target_word = (isset($_POST['cms_target_word']) ? $_POST['cms_target_word'] : "");

$replace_word = (isset($_POST['cms_replace_word']) ? $_POST['cms_replace_word'] : "");

if (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'search') {
	$disp_mode = $_POST['cms_dispMode'];
	$search = array();
	$search['p'] = 1;
	
	//ページタイトル
	if (isset($_POST['cms_search_page_title'])) {
		$search['page_title'] = str_replace('　', ' ', $_POST['cms_search_page_title']);
		$search['page_title'] = preg_replace('/(^ | $)/', '', $search['page_title']);
	}
	
	//ファイルパス
	$search['url'] = (isset($_POST['cms_url']) ? $_POST['cms_url'] : "");
	
	//公開開始日
	$search['pdsy'] = $_POST['cms_pdsy'];
	$search['pdsm'] = $_POST['cms_pdsm'];
	$search['pdsd'] = $_POST['cms_pdsd'];
	$search['pdey'] = $_POST['cms_pdey'];
	$search['pdem'] = $_POST['cms_pdem'];
	$search['pded'] = $_POST['cms_pded'];
	if (($search['pdsy'] != '') && ($search['pdsm'] != '') && ($search['pdsd'] != '')) $search['publish_start'] = $search['pdsy'] . '-' . $search['pdsm'] . '-' . $search['pdsd'];
	if (($search['pdey'] != '') && ($search['pdem'] != '') && ($search['pded'] != '')) $search['publish_end'] = $search['pdey'] . '-' . $search['pdem'] . '-' . $search['pded'] . ' 23:59:59';
	
	//対象
	$search['target1'] = (isset($_POST['cms_target_1']) ? $_POST['cms_target_1'] : (isset($_POST['cms_target1']) ? $_POST['cms_target1'] : ""));
	$search['target2'] = (isset($_POST['cms_target_2']) ? $_POST['cms_target_2'] : (isset($_POST['cms_target2']) ? $_POST['cms_target2'] : ""));
	$search['target3'] = (isset($_POST['cms_target_3']) ? $_POST['cms_target_3'] : (isset($_POST['cms_target3']) ? $_POST['cms_target3'] : ""));
	
	// -- カテゴリ
	$search['cate_code']["cms_cate1"] = (isset($_POST['cms_cate1'])) ? $_POST['cms_cate1'] : "";
	$search['cate_code']["cms_cate2"] = (isset($_POST['cms_cate2'])) ? $_POST['cms_cate2'] : "";
	$search['cate_code']["cms_cate3"] = (isset($_POST['cms_cate3'])) ? $_POST['cms_cate3'] : "";
	$search['cate_code']["cms_cate4"] = (isset($_POST['cms_cate4'])) ? $_POST['cms_cate4'] : "";
	
	//テンプレート
	$search['template_id'] = (isset($_POST['cms_template_ids']) ? $_POST['cms_template_ids'] : "");
	
	//テンプレート種類
	$search['template_kind'] = (isset($_POST['cms_template_kind']) ? $_POST['cms_template_kind'] : "");
	
	//ステータス
	$search['target_status'] = (isset($_POST['cms_target_status']) ? $_POST['cms_target_status'] : PUBLISH_TABLE);
	
	//置換後ステータス
	$search['after_status'] = (isset($_POST['cms_after_status']) ? $_POST['cms_after_status'] : STATUS_PUBLISH_WAIT);
	
	// 正規表現チェック
	$search['regular'] = (isset($_POST['cms_regular']) ? $_POST['cms_regular'][0] : FLAG_OFF);
	
	// 大文字小文字を区別
	$search['case_sensitive'] = (isset($_POST['cms_case_sensitive']) ? $_POST['cms_case_sensitive'][0] : FLAG_OFF);
	
	//置換対象文字列
	$search['target_word'] = (isset($_POST['cms_target_word']) ? $_POST['cms_target_word'] : "");
	
	//置換後文字列
	$search['replace_word'] = (isset($_POST['cms_replace_word']) ? $_POST['cms_replace_word'] : "");
	
	//表示リミット
	$search['disp_num'] = (isset($_POST['disp_num']) ? $_POST['disp_num'] : 10);
	
	$_SESSION['search'] = $search;
	$_SESSION['replace'] = array();
}
elseif (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'pageset') {
	$search['p'] = $_POST['cms_p'];
	$_SESSION['search'] = $search;
}
elseif (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'change_num') {
	$search['p'] = 1;
	$search['disp_num'] = (isset($_POST['disp_num']) ? $_POST['disp_num'] : 10);
	$_SESSION['search'] = $search;
}

// 置換対象文字列末端に「\」が奇数個ある場合エラーとする
if (isset($search['regular']) && $search['regular'] != FLAG_OFF) {
	$tmp_target_word = $_POST['cms_target_word'];
	$tmp_target_word = str_replace("\\\\", "", $tmp_target_word);
	if (preg_match("/(\\\)+$/", $tmp_target_word, $match)) {
		if (strlen($match[0]) % 2 == 1) {
			user_error('置換対象文字列の指定に誤りがあります。');
		}
	}
}

//----------検索条件表示用文字列作成----------//
//ページタイトル
$page_title = "";
$page_title = (isset($_POST['cms_search_page_title']) ? $_POST['cms_search_page_title'] : "");
//ファイルパス
$url = (isset($search['url']) ? $search['url'] : "");
//公開開始日
$publish_start = "";
$publish_end = "";
if ((isset($search['pdsy']) && $search['pdsy'] != '') && (isset($search['pdsm']) && $search['pdsm'] != '') && (isset($search['pdsd']) && $search['pdsd'] != '')) {
	$publish_start = $search['pdsy'] . '-' . $search['pdsm'] . '-' . $search['pdsd'];
}
if ((isset($search['pdey']) && $search['pdey'] != '') && (isset($search['pdem']) && $search['pdem'] != '') && (isset($search['pded']) && $search['pded'] != '')) {
	$publish_end = $search['pdey'] . '-' . $search['pdem'] . '-' . $search['pded'];
}

//対象
if ($search['target3'] != "") {
	$dept_code = $search['target3'];
}
else if ($search['target2'] != "") {
	$dept_code = $search['target2'];
}
else if ($search['target1'] != "") {
	$dept_code = $search['target1'];
}
else {
	$dept_code = "";
}
$dept_name = "";
if ($dept_code != "") {
	if ($objDept->selectFromCode($dept_code)) {
		$dept_name = $objDept->fld['dept_name'];
	}
}
// -- カテゴリ
$cate_str = "";
if ($search['cate_code']["cms_cate4"] != "") {
	$cate_code = $search['cate_code']["cms_cate4"];
}
else if ($search['cate_code']["cms_cate3"] != "") {
	$cate_code = $search['cate_code']["cms_cate3"];
}
else if ($search['cate_code']["cms_cate2"] != "") {
	$cate_code = $search['cate_code']["cms_cate2"];
}
else if ($search['cate_code']["cms_cate1"] != "") {
	$cate_code = $search['cate_code']["cms_cate1"];
}
else {
	$cate_code = "";
}
if ($cate_code != "") {
	$cate_str = $objCate->getCategoryInfo($cate_code, ' > ');
}
//テンプレート
$template_id_ary = explode(',', $search['template_id']);
$template_str = "";
//全テンプレート取得
$sql = "SELECT t.* FROM tbl_template AS t" . " WHERE t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND t.disp_flg = '" . FLAG_ON . "'" . " ORDER BY t.sort_order,t.template_id";
// 作成者の場合は所属に権限があるテンプレート
$objTool->execute($sql);
while ($objTool->fetch()) {
	if (in_array($objTool->fld['template_id'], $template_id_ary)) {
		$template_str .= ' 【' . $objTool->fld['name'] . '】';
	}
}

//テンプレート種類
$template_kind_str = "";
$TEMPLATE_KIND = getDefineArray('TEMPLATE_KIND');
if (isset($_POST['cms_template_kind']) && $_POST['cms_template_kind'] != "") {
	foreach ((array) $_POST['cms_template_kind'] as $template_kind) {
		if (isset($TEMPLATE_KIND[$template_kind]) && $TEMPLATE_KIND[$template_kind] != "") {
			$template_kind_str .= ' 【' . $TEMPLATE_KIND[$template_kind] . '】';
		}
	}
}

//ステータス
$target_status_str = "";
$target_status_ary = array(
		WORK_TABLE => '編集中ページ', 
		PUBLISH_TABLE => '公開中ページ'
);
if (isset($search['target_status']) && $search['target_status'] != "") {
	$target_status_str = $target_status_ary[$search['target_status']];
}

//置換後ステータス
$after_status_str = "";
$after_status_ary = array(
		STATUS_COMP => '更新待ち', 
		STATUS_PUBLISH_WAIT => '公開待ち'
);
if (isset($search['after_status']) && $search['after_status'] != "") {
	$after_status_str = $after_status_ary[$after_status];
}

//正規表現チェック
$regular = "";
if (isset($search['regular']) && $search['regular'] != FLAG_OFF) {
	$regular = '<br><span class="cms_require"><small>※正規表現を使用する</small></span>';
}

//大文字・小文字チェック
$case_sensitive = "";
if (isset($search['case_sensitive']) && $search['case_sensitive'] != FLAG_OFF) {
	$case_sensitive = '<br><span class="cms_require"><small>※大文字と小文字を区別する</small></span>';
}

if (isset($search['target_status']) && $search['target_status'] == PUBLISH_TABLE) {
	//公開中ページ
	$search['status'] = STATUS_PUBLISH;
}
else {
	//編集中ページ
	$search['work_class'] = WORK_CLASS_NEW . ',' . WORK_CLASS_PUBLISH;
}
//非公開ページは対象外
$search['close_flg'] = '0';

$_SESSION['search'] = $search;

//ページ情報取得
$search['disp_num'] = 100000;
$temp_target_word = $search['target_word'];
$search['target_word'] = "";
if (isset($search['target_status']) && $search['target_status'] == PUBLISH_TABLE) {
	$objPage->search($search, PUBLISH_TABLE);
}
else {
	$objPage->search($search, WORK_TABLE);
}
$search['disp_num'] = (isset($_POST['disp_num']) ? $_POST['disp_num'] : 10);
$search['target_word'] = $temp_target_word;

$reg_flg = (isset($search['regular']) && $search['regular'] != FLAG_OFF ? FLAG_ON : FLAG_OFF);
$case_sensitive_flg = (isset($search['case_sensitive']) && $search['case_sensitive'] != FLAG_OFF ? FLAG_ON : FLAG_OFF);
$ch_target_word = $target_word;
if ($reg_flg == "" || $reg_flg == FLAG_OFF) {
	$ch_target_word = reg_replace($ch_target_word);
	$ch_target_word = str_replace('^', '\^', $ch_target_word);
	$ch_target_word = str_replace('$', '\$', $ch_target_word);
}
else {
	$ch_target_word = str_replace("/", "\/", $ch_target_word);
}

// 置換対象文字列を含むページを取得
$page_fld = array();
$all_cnt = 0;
// ページ件数
$page_cnt = 0;
// 表示開始件数
$disp_start = $search['disp_num'] * ($search['p'] - 1) + 1;
// 表示終了件数
$disp_end = $search['disp_num'] * ($search['p'] - 1) + $search['disp_num'];
while ($objPage->fetch()) {
	$fld = $objPage->fld;
	
	// 検索する際大文字と小文字を区別しない場合オプションに「i」を追加
	if ($case_sensitive_flg == FLAG_OFF) {
		$case_sensitive_mode = 'is';
	}
	else {
		$case_sensitive_mode = 's';
	}
	// 検索対象文字列の存在チェック
	if (!preg_match("/" . $ch_target_word . "/" . $case_sensitive_mode, $fld['context'])) {
		unset($_SESSION['replace']['check'][$fld['page_id']]);
		continue;
	}
	
	// ページ件数カウント
	$page_cnt++;
	// 表示開始件数まで飛ばす
	if ($page_cnt < $disp_start) {
		$all_cnt++;
		continue;
	}
	// 表示終了件数以降はチェックボックスを作成しない
	if ($page_cnt <= $disp_end) {
		//チェックボックス付き置換対象文字列取得
		$chbox_str_data = $replaceFunc->getRepCheckboxStr($fld['page_id'], $fld['context'], $target_word, $reg_flg, $case_sensitive_flg);
		
		if (!isset($chbox_str_data['chbox_str']) || strlen($chbox_str_data['chbox_str']) < 1 || !isset($chbox_str_data['all_context']) || strlen($chbox_str_data['all_context']) < 1) {
			unset($_SESSION['replace']['check'][$fld['page_id']]);
			$page_cnt--;
			continue;
		}
		
		$fld['chbox_str'] = $chbox_str_data['chbox_str'];
		$fld['all_context'] = $chbox_str_data['all_context'];
		$_SESSION['replace_context'][$fld['page_id']] = $chbox_str_data['all_context'];
		$page_fld[] = $fld;
	}
	$all_cnt++;
}

$objPage->objP->limit = $search['disp_num'];
$objPage->objP->set($search['p'], $all_cnt);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>編集領域一括置換確認画面</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<link rel="stylesheet" href="replace.css" type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/master/global/replace/js/replace.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
Event.observe(window,'load',function(){
	cxChboxReload();
});
function cxChboxReload() {
	var check_cnt;
	var chbox_cnt;
	var inputs = document.getElementsByTagName("input");
	var page_id_ary = document['cms_Replace']['cms_target_page[]'];
	
	if (page_id_ary) {
		if (page_id_ary.value) {
			check_cnt = 0;
			chbox_cnt = 0;
			for (var i = 0, l = inputs.length; i < l; i++) {
				var input = inputs[i];
				if (input.type == "checkbox" && input.id.match("_"+page_id_ary.value+"_[0-9]+")) {
					if (input.checked) {
						check_cnt++;
					}
					chbox_cnt++;
				}
			}

			$('page_id_'+page_id_ary.value).disabled = '';
			if (check_cnt == 0) {
				$('page_id_'+page_id_ary.value).checked = '';
			} else {
				$('page_id_'+page_id_ary.value).checked = 'checked';
				if (check_cnt != chbox_cnt) {
					$('page_id_'+page_id_ary.value).disabled = 'disabled';
				}
			}
		} else {
			for (var id_cnt = 0; id_cnt < page_id_ary.length; id_cnt++) {
				check_cnt = 0;
				chbox_cnt = 0;
				for (var i = 0, l = inputs.length; i < l; i++) {
					var input = inputs[i];
					if (input.type == "checkbox" && input.id.match("_"+page_id_ary[id_cnt].value+"_[0-9]+")) {
						if (input.checked) {
							check_cnt++;
						}
						chbox_cnt++;
					}
				}

				$('page_id_'+page_id_ary[id_cnt].value).disabled = '';
				if (check_cnt == 0) {
					$('page_id_'+page_id_ary[id_cnt].value).checked = '';
				} else {
					$('page_id_'+page_id_ary[id_cnt].value).checked = 'checked';
					if (check_cnt != chbox_cnt) {
						$('page_id_'+page_id_ary[id_cnt].value).disabled = 'disabled';
					}
				}
			}
		}
	}
}
//-->
</script>

</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
//	$headerMode = 'replace';
//	include(APPLICATION_ROOT."/common/inc/header_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-replace">
<div><img
	src="<?=RPW?>/admin/master/global/replace/images/bar_edit_area_replace_conf.jpg"
	alt="編集領域一括置換確認画面" width="920" height="30"></div>
<div class="cms8341-area-corner">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle" style="background-image:url(<?=RPW?>/admin/page/publiclist/images/bar_topbg.jpg);height:31px;"><img
			src="<?=RPW?>/admin/master/global/replace/images/bar_searh.jpg"
			alt="検索条件" width="200" height="20" style="margin-left: 10px;"></td>
	</tr>
</table>
<div id="cms8341-search" style="display: block">
<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable">
<?php
if ($page_title != "") {
	?>
	<tr>
		<th width="150" align="left" valign="top" scope="row">ページタイトル</th>
		<td align="left" valign="middle"><?=htmlDisplay($page_title)?></td>
	</tr>
<?php
}
?>
<?php

if ($url != "") {
	?>
	<tr>
		<th width="150" align="left" valign="top" scope="row">ファイルパス</th>
		<td align="left" valign="middle"><?=htmlDisplay($url)?></td>
	</tr>
<?php
}
?>
<?php

if ($template_kind_str != "") {
	?>
	<tr>
		<th width="150" align="left" valign="top" scope="row">テンプレート種類</th>
		<td align="left" valign="middle"><?=htmlDisplay($template_kind_str)?></td>
	</tr>
<?php
}
?>
<?php

if ($template_str != "") {
	?>
	<tr>
		<th width="150" align="left" valign="top" scope="row">テンプレート</th>
		<td align="left" valign="middle"><?=htmlDisplay($template_str)?></td>
	</tr>
<?php
}
?>
<?php

if ($publish_start != "" || $publish_end != "") {
	?>
	<tr>
		<th width="150" align="left" valign="top" scope="row">公開開始日</th>
		<td align="left" valign="middle">
<?php
	if ($publish_start != "") {
		?>
		<?=htmlDisplay(dtFormat($publish_start, 'Y年m月d日'))?> から
<?php
	}
	?>
<?php

	if ($publish_end != "") {
		?>
		<?=htmlDisplay(dtFormat($publish_end, 'Y年m月d日'))?> まで
<?php
	}
	?>
		</td>
	</tr>
<?php
}
?>
<?php

if ($cate_str != "") {
	?>
	<tr>
		<th width="150" align="left" valign="top" scope="row">分類</th>
		<td align="left" valign="middle"><?=htmlDisplay($cate_str['name'])?></td>
	</tr>
<?php
}
?>
<?php

if ($dept_name != "") {
	?>
	<tr>
		<th width="150" align="left" valign="top" scope="row">対象</th>
		<td align="left" valign="middle"><?=htmlDisplay($dept_name)?></td>
	</tr>
<?php
}
?>
<?php

if ($target_status_str != "") {
	?>
	<tr>
		<th width="150" align="left" valign="top" scope="row">ステータス</th>
		<td align="left" valign="middle"><?=htmlDisplay($target_status_str)?></td>
	</tr>
<?php
}
?>
<?php

if ($after_status_str != "" && $search['target_status'] == PUBLISH_TABLE) {
	?>
	<tr>
		<th width="150" align="left" valign="top" scope="row">置換後のステータス</th>
		<td align="left" valign="middle"><?=htmlDisplay($after_status_str)?></td>
	</tr>
<?php
}
?>
<?php

if ($target_word != "") {
	?>
	<tr>
<?php
	if ($case_sensitive != "") {
		?>
		<th width="180" align="left" valign="top" scope="row">置換対象文字列<?=$regular?><?=$case_sensitive?></th>
<?php
	}
	else {
		?>
		<th width="150" align="left" valign="top" scope="row">置換対象文字列<?=$regular?><?=$case_sensitive?></th>
<?php
	}
	?>
		<td align="left" valign="middle"><?=htmlDisplay($target_word)?></td>
	</tr>
<?php
}
?>
<?php

if ($replace_word != "") {
	?>
	<tr>
		<th width="150" align="left" valign="top" scope="row">置換後文字列</th>
		<td align="left" valign="middle"><?=htmlDisplay($replace_word)?></td>
	</tr>
<?php
}
?>

</table>
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right" valign="middle" style="background-image:url(<?=RPW?>/admin/page/publiclist/images/bar_bottombg.jpg);height:32px;">
		<a href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			src="<?=RPW?>/admin/images/btn/btn_close_mini.jpg" alt="閉じる"
			width="80" height="15" border="0" style="margin-right: 10px;"
			id="cms-searchSwitch"></a></td>
	</tr>
</table>

</div>
<form name="cms_Replace_Prev" id="cms_Replace_Prev" class="cms8341-form"
	method="post" action=""><input type="hidden" name="cms_dispMode"
	id="cms_dispMode" value=""> <input type="hidden" name="cms_prevMode"
	id="cms_prevMode" value=""> <input type="hidden" name="cms_page_id"
	id="cms_page_id" value=""> <input type="hidden" name="cms_file_path"
	id="cms_file_path" value=""></form>
<form name="cms_Replace" id="cms_Replace" class="cms8341-form"
	method="post" action=""><input type="hidden" name="cms_dispMode"
	value=""> <input type="hidden" name="cms_p" id="cms_p" value=""> <input
	type="hidden" name="cms_target_status" id="cms_target_status"
	value="<?=$search['target_status']?>"> <input type="hidden"
	name="cms_after_status" id="cms_after_status"
	value="<?=$after_status?>"> <input type="hidden" name="cms_target_word"
	id="cms_target_word" value="<?=htmlspecialchars($target_word)?>"> <input
	type="hidden" name="cms_replace_word" id="cms_replace_word"
	value="<?=htmlspecialchars($replace_word)?>"> <input type="hidden"
	name="cms_regular" id="cms_regular" value="<?=$search['regular']?>"> <input
	type="hidden" name="cms_case_sensitive" id="cms_case_sensitive"
	value="<?=$search['case_sensitive']?>">

<?php
if ($all_cnt < 1) {
	?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-workspace">
	<tr>
		<th align="center" valign="middle" scope="col"
			style="font-weight: normal">&nbsp;</th>
	</tr>
	<tr>
		<td align="center" valign="middle">該当するページはありません。</td>
	</tr>
</table>
<p align="center"><a href="javascript:" onClick="return cxConfBak()"><img
	src="<?=RPW?>/admin/images/btn/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0" style="margin-left: 10px;"></a></p>

<?php
}
else {
	?>


<p><a href="javascript:" onClick="return cxCheckAll();"><img
	src="<?=RPW?>/admin/images/upload/btn_allselect.jpg" alt="全て選択する"
	width="120" height="20" border="0"></a> <a href="javascript:"
	onClick="return cxReleaseAll();"><img
	src="<?=RPW?>/admin/images/upload/btn_allcansel.jpg" alt="全て解除する"
	width="120" height="20" hspace="20" border="0"></a></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	style="margin-bottom: 10px; padding: 1px">
	<tr valign="top">
		<td colspan="3" align="right">
			<?=mkcombobox($MAXROW_LIST, "disp_num", $search['disp_num'], "cxDispNum(this.value)")?>
		</td>
	</tr>
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objPage->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objPage->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objPage->getNextLink()?></td>
	</tr>
</table>

<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">選択</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">置換対象ページ</th>
	</tr>
<?php
	
	$menu_no = 1;
	foreach ((array) $page_fld as $fld) {
		if (!isset($_SESSION['replace']['check'][$fld['page_id']]) || ($key = array_search($fld['page_id'], $_SESSION['replace']['check'][$fld['page_id']])) === FALSE) {
			$checked = "";
		}
		else {
			$checked = "checked";
		}
		if ($fld['status'] == STATUS_PUBLISH) {
			$tbl = PUBLISH_TABLE;
		}
		else {
			$tbl = WORK_TABLE;
		}
		
		//アイコン情報を取得
		$ret_ary = get_status_icon($fld);
		
		$meg = "";
		$objPage2->selectFromID($fld['page_id'], PUBLISH_TABLE);
		if (isset($objPage2->fld['user_lock']) && $objPage2->fld['user_lock'] != "") {
			unset($_SESSION['replace']['check'][$fld['page_id']]);
			$meg = '<br><span class="cms_require" style="font-size:12px;">※現在このページは編集されています。</span>';
		}
		$icon_img = '&nbsp;';
		$chkbox_name = 'cms_target_page';
		print '<tr>' . "\n";
		
		print '<td align="center" valign="middle">';
		if ($meg == "") {
			print '<input type="checkbox" name="' . $chkbox_name . '[]" id="page_id_' . $fld['page_id'] . '" value="' . $fld['page_id'] . '" onClick="return cxCheck(\'' . $fld['page_id'] . '\')" ' . $checked . '>';
		}
		print '</td>' . "\n";
		
		print '<td width="700" align="left" valign="top" nowrap>' . "\n";
		print '<p>' . "\n";
		print '<img src="' . RPW . '/admin/images/treelist/' . $ret_ary['wc_img'] . '" alt="' . $ret_ary['wc_alt'] . '" width="59" height="16" class="icon">';
		print '&nbsp;<a href="javascript:" onClick="return cxRepContentsMenu(\'cms_menu_' . $menu_no . '\',this)"  onContextMenu="cxRepContentsMenu(\'cms_menu_' . $menu_no . '\',this);return false;"><span id="cms_page_title_' . $menu_no . '">' . htmlDisplay($fld['page_title']) . '</span></a>' . $meg . "\n";
		print '<div id="cms_menu_' . $menu_no . '" class="cms8341-layer">' . "\n";
		print '<table width="166" border="0" cellpadding="0" cellspacing="0" class="cms8341-noneBorder">' . "\n";
		print '<tr>' . "\n";
		print '<td width="158" align="left" valign="top" bgcolor="#DFDFDF" style="border:solid 1px #343434 !important;">' . "\n";
		print '<table width="158" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader">' . "\n";
		print '<tr>' . "\n";
		print '<td align="right" valign="middle"><a href="javascript:" onClick="return cxLayer(\'cms_menu_' . $menu_no . '\',0)"><img src="' . RPW . '/admin/images/btn/btn_close.jpg" alt="閉じる" width="58" height="19" border="0" style="margin:4px 10px;"></a></td>' . "\n";
		print '</tr>' . "\n";
		print '</table>' . "\n";
		
		print '<div><a href="javascript:" onClick="return cxReplacePreview(\'cms_Replace_Prev\',\'' . $fld['page_id'] . '\',\'' . $tbl . '\',\'1\');"><img src="' . RPW . '/admin/images/contentsmenu/menu_rep_before00.jpg" alt="置換前プレビュー" width="158" height="20" border="0" onMouseOver="cxImageChange(this,\'' . RPW . '/admin/images/contentsmenu/menu_rep_before01.jpg\')" onMouseOut="cxImageChange(this,\'' . RPW . '/admin/images/contentsmenu/menu_rep_before00.jpg\')"></a></div>' . "\n";
		if ($meg == "") {
			echo '<div><a href="javascript:" onClick="return cxReplacePreview(\'cms_Replace_Prev\',\'' . $fld['page_id'] . '\',\'' . $tbl . '\',\'3\');"><img src="' . RPW . '/admin/images/contentsmenu/menu_rep_after00.jpg" alt="置換後プレビュー" width="158" height="20" border="0"  onMouseOver="cxImageChange(this,\'' . RPW . '/admin/images/contentsmenu/menu_rep_after01.jpg\')" onMouseOut="cxImageChange(this,\'' . RPW . '/admin/images/contentsmenu/menu_rep_after00.jpg\')"></a></div>' . "\n";
		}
		else {
			echo '<div><img src="' . RPW . '/admin/images/contentsmenu/menu_rep_after_off.jpg" alt="置換後プレビュー" width="158" height="20" border="0"></div>' . "\n";
		}
		
		print '</td>' . "\n";
		print '<td width="7" height="64" align="left" valign="top"><img src="' . RPW . '/admin/images/contentsmenu/shadow_right.jpg" alt="" width="5" height="84"></td>' . "\n";
		print '</tr>' . "\n";
		print '<tr>' . "\n";
		print '<td height="7" align="left" valign="top" class="cms8341-shadowBottomBg"><img src="' . RPW . '/admin/images/contentsmenu/shadow_bottom.jpg" alt="" width="160"></td>' . "\n";
		print '<td height="8" align="left" valign="top"><img src="' . RPW . '/admin/images/contentsmenu/shadow_corner.jpg" alt="" width="5" height="7"></td>' . "\n";
		print '</tr>' . "\n";
		print '</table>' . "\n";
		print '</div>' . "\n";
		
		if ($meg == "" && $fld['chbox_str'] != "") {
			print '<br>' . "\n" . $fld['chbox_str'] . "\n";
		}
		print '</p>' . "\n";
		
		print '<input type="hidden" name="cms_disp_page_id[]" value="' . $fld['page_id'] . '">' . "\n";
		
		print '</td>' . "\n";
		
		print '</tr>' . "\n";
		
		$menu_no++;
	}
	
	?>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="5"
	style="margin-top: 10px;">
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objPage->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objPage->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objPage->getNextLink()?></td>
	</tr>
</table>

<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center"><a href="javascript:" onClick="return cxConfSubmit()"><img
	src="<?=RPW?>/admin/images/btn/btn_execution.jpg" alt="実行" width="150"
	height="20" border="0" style="margin-right: 10px;"></a> <a
	href="javascript:" onClick="return cxConfBak()"><img
	src="<?=RPW?>/admin/images/btn/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0" style="margin-left: 10px;"></a></p>
<?php
}
?>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!--***処理中プロパティレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0" style="background-image:url(<?=RPW?>/admin/images/layer/titlebar_bg.jpg);height:30px;">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg">メッセージ</div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理中プロパティレイヤー ここまで********************************-->
</body>
</html>