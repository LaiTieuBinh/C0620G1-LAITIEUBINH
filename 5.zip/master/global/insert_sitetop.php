<?php
/*
 * サイトトップページ（index.html）の作成
 */
//--- 設定ファイル読み込み
require ("./.htsetting");

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

if (file_exists(DOCUMENT_ROOT . RPW . SITE_TOP_PAGE)) {
	user_error('サイトトップページは登録済みです。');
}
if (!$_POST['template_id'] || $_POST['template_id'] == '') {
	user_error('テンプレートIDが入力されていません。');
}
if (!preg_match('/^\d+$/', $_POST['template_id'])) {
	user_error('テンプレートIDは半角数字で入力してください。');
}
if (!$_POST['user_id'] || $_POST['user_id'] == '') {
	user_error('ユーザIDが入力されていません。');
}
if (!preg_match('/^\d+$/', $_POST['user_id'])) {
	user_error('ユーザIDは半角数字で入力してください。');
}

$sql = "SELECT * FROM tbl_template WHERE template_id = " . $_POST['template_id'] . " ORDER BY template_ver DESC LIMIT 1";
$objDac->execute($sql);
if (!$objDac->fetch()) {
	user_error('入力されたテンプレートは登録されていません。');
}
$template_ver = $objDac->fld['template_ver'];

$sql = "SELECT * FROM tbl_user WHERE user_id = " . $_POST['user_id'];
$objDac->execute($sql);
if (!$objDac->fetch()) {
	user_error('入力されたユーザは登録されていません。');
}

// トランザクション開始
$objCnc->begin();

// ページ情報登録（INSERT INTO tbl_publish_page）
$ary = array();
$PID = $objPage->getSeqNextval();
$ary['page_id'] = $PID;
$ary['template_id'] = $_POST['template_id'];
$ary['template_ver'] = $template_ver;
$ary['user_id'] = $_POST['user_id'];
$ary['dir_path'] = preg_replace('/([^\/])$/', '$1/', cms_dirname(SITE_TOP_PAGE));
$ary['filename'] = basename(SITE_TOP_PAGE);
$ary['file_path'] = SITE_TOP_PAGE;
$ary['page_title'] = 'ホーム';
//	$ary['index_title'] = 'ホーム';
$ary['publish_start'] = date('Y-m-d');
$ary['publish_end'] = (date('Y') + 1) . '-' . date('m-d');
$ary['work_class'] = 1;
$ary['template_kind'] = TEMPLATE_KIND_FREE;
$ary['status'] = 401;
$ary['menu_generation_order'] = $objPage->getNextMenuGenerationOrder(NULL);
if (!$objPage->insert($ary, 1)) {
	$objCnc->rollback();
	user_error('サイトトップページの作成に失敗しました。');
}

// 編集情報の登録（INSERT INTO tbl_work_page SELECT FROM tbl_work_page）
if (!$objPage->insertWorkFromPublish($PID, $objLogin->login)) {
	$objCnc->rollback();
	user_error('編集情報の登録に失敗しました。');
}

// HTMLファイル生成
if (mkNewPage($PID, SITE_TOP_PAGE) === FALSE) {
	$objCnc->rollback();
	user_error('HTMLファイルの生成に失敗しました。');
}

// コミット
$objCnc->commit();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>サイトトップページの作成</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
</head>

<body id="cms8341-mainbg">
<div id="cms8341-headarea">
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	id="cms8341-header">
	<tr>
		<td align="left" valign="top"><img src="<?=DIR_PATH_LOGO_MENU?>"
			alt="<?=ALT_LOGO_MENU?>" width="330" height="41"></td>
		<td width="110" align="right" valign="top"><img
			src="<?=DIR_PATH_LOGO_CMSMENU?>" alt="<?=ALT_LOGO_CMSMENU?>"
			width="110" height="41"></td>
	</tr>
</table>
</div>
<div align="center" id="cms8341-user">
<div class="cms8341-area-corner">
<div align="center">
<table border="0" cellspacing="0" cellpadding="5">
	<tr>
		<td align="left">
		<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable">
			<tr>
				<th align="center">サイトトップページの作成</th>
			</tr>
			<tr>
				<td align="center">
				<p>サイトトップページを作成しました。</p>
				<p>[<a href="./index.php"> データ初期設定INDEXへ </a></p>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</div>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</body>
</html>
