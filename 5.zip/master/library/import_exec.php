<?php
/*
 * ライブラリ管理　ライブラリ情報のインポート(import_exec.php)
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/
//csvファイル最大行
define("G_CSV_MAX_LINE", 50000);

//必須項目チェックフラグ（0:必須チェックなし　1:必須チェックあり)
//[ライブラリID][種類][ライブラリ名][ライブラリ権限][内容][ソート][表示可能エリア][自動リンク展開フラグ]
$ChkItemFlg = array(
		1, 
		1, 
		1, 
		1, 
		1, 
		0, 
		0, 
		0
);

define("G_CSV_ITM_CNT", 8); //ライブラリ情報項目数


/*---------------------------------------------------------------------------------
	import_exec.php
---------------------------------------------------------------------------------*/

//--- 設定ファイル読み込み
require ("./.htsetting");

//---引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError("インポートをするcsvファイルを指定してください。", 6, "javascript:history.back()");
	exit();
}
// 拡張子チェック
$sExtension = substr($frmCsvFnm, (strrpos($frmCsvFnm, '.') + 1));
$sExtension = strtolower($sExtension);
if ($sExtension != "csv") {
	DispError("csvファイルを指定してください。", 6, "javascript:history.back()");
	exit();
}
//---ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError("csvファイルのファイルサイズが0バイトです。", 6, "javascript:history.back()");
	exit();
}

//ディレクトリの作成
$tmpUpFile = DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/' . $frmCsvFnm;
if (!mkNewDirectory($tmpUpFile)) {
	DispError("csvファイルのアップロードフォルダの作成に失敗しました。", 6, "javascript:history.back()");
	exit();
}

//---アップロード
if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $tmpUpFile) == FALSE) {
	DispError("csvファイルのアップロードに失敗しました。", 6, "javascript:history.back()");
	exit();
}
//(念のため)ファイル存在チェック
if (file_exists($tmpUpFile) == FALSE) {
	$wk_str = "指定されたファイル【" . $tmpUpFile . "】が存在しません。";
	DispError($wk_str, 6, "javascript:history.back()");
	exit();
}

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_library.inc');
$objLibrary = new tbl_library($objCnc);

/*---csvを読込み、tbl_libraryに追加していく---*/
// トランザクション開始
$objCnc->begin();

//ファイルを開く
if (!($CsvFno = csvRead_UTF8($tmpUpFile))) {
	//エラーページの表示
	DispError("csvファイルのオープンに失敗しました。", 6, "javascript:history.back()");
	exit();
}
//EOFになるまで読み出し
$fst_line = 0;
$err_msg = "";
while ($data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
	//一行目は飛ばす
	if ($fst_line > 0) {
		// 行の項目数が組織情報の項目数よりも少なければ空で埋める
		while (count($data) < G_CSV_ITM_CNT) {
			$data[] = "";
		}
		
		//各項目のチェック
		if (strlen($err_msg) <= 0) {
			G_ChkCsvItem($data, $err_msg, $library_ver, $Sort, $ChkItemFlg, $objDac);
		}
		
		//種類変更チェック
		if (strlen($err_msg) <= 0) {
			$objLibrary->selectFromID($data[0]);
			if ($objLibrary->getRowCount() > 0) {
				//現在登録されているライブラリの種類を取得
				$area = $objLibrary->fld['area'];
				
				//更新の場合現データと異なる種類で登録しようとしていた場合エラー
				if ($area != $data[1]) {
					$err_msg = "更新しようとしているライブラリID【" . $data[0] . "】の種類が変更されています。";
				}
			}
		}
		
		//tbl_libraryに追加
		if (strlen($err_msg) <= 0) {
			if (FALSE == G_TblLibrayAdd($data, $library_ver, $Sort, $objDac)) {
				$err_msg = "ライブラリ情報の登録に失敗しました。";
			}
		}
		
		if (strlen($err_msg) > 0) {
			//ファイルClose
			fclose($CsvFno);
			//ファイルを削除
			unlink($tmpUpFile);
			//ロールバック
			$objCnc->rollback();
			//エラーページの表示
			DispError($err_msg, 6, "javascript:history.back()");
			exit();
		}
	}
	$fst_line = 1;
}

//ファイルClose
fclose($CsvFno);
//ファイルを削除
if (unlink($tmpUpFile) == FALSE) {
	//ロールバック
	$objCnc->rollback();
	//エラーページの表示
	DispError("csvファイルの削除に失敗しました。", 6, "javascript:history.back()");
	exit();
}

// コミット
$objCnc->commit();

/*---一覧画面へと戻る---*/
header("Location: " . "./index.php");

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	CSV項目のチェック

【引数】	$i_OneData		配列で指定されたcsvデータ（全項目)
		$o_ErrMsg		エラーメッセージ
		$o_library_ver		ライブラリバージョン
		$o_Sort		ライブラリソート
		$i_ChkItemFlg		必須チェックフラグ
		$i_objDac		DB
		
【戻値】	True	すべてのチェックが正常に終了
		False	エラーが存在した
		
【備考】
-----------------------------------------------------------------------------*/
function G_ChkCsvItem($i_OneData, &$o_ErrMsg, &$o_library_ver, &$o_Sort, $i_ChkItemFlg, $i_objDac) {
	
	/*---ライブラリID $i_OneData[0] ---*/
	//必須チェック
	if ($i_ChkItemFlg[0] == 1) {
		if (strlen($i_OneData[0]) <= 0) {
			$o_ErrMsg = "ライブラリIDが指定されていないデーターが存在します。";
			return FALSE;
		}
	}
	//半角数値チェック
	if (!(preg_match("/^[0-9]+$/", $i_OneData[0]))) {
		$o_ErrMsg = "半角数値以外の値が指定されているライブラリIDが存在します。【ライブラリID:" . $i_OneData[0] . "】";
		return FALSE;
	}
	//機種依存文字チェック
	if (FALSE == checkMachineCode($i_OneData[0])) {
		$o_ErrMsg = "機種依存文字が指定されているライブラリIDが存在します。【ライブラリID:" . $i_OneData[0] . "】";
		return FALSE;
	}
	
	//library_verの最大値取得
	$set_ver = 0;
	$sql = "SELECT MAX(library_ver) AS ver FROM tbl_library WHERE library_id=" . $i_OneData[0];
	$i_objDac->execute($sql);
	while ($i_objDac->fetch()) {
		$set_ver = $i_objDac->fld["ver"];
	}
	
	//ライブラリ修正処理
	$set_ver++;
	$o_library_ver = $set_ver;
	
	/*---種類 $i_OneData[1] ---*/
	//必須チェック
	if ($i_ChkItemFlg[1] == 1) {
		if (strlen($i_OneData[1]) <= 0) {
			$o_ErrMsg = "種類が指定されていないデーターが存在します。【ライブラリID:" . $i_OneData[0] . "】";
			return FALSE;
		}
	}
	//種類チェック
	if (($i_OneData[1] != AREA_LIBRARY) & ($i_OneData[1] != AREA_EDIT)) {
		$o_ErrMsg = "種類として認められない値が指定されているデーターが存在します。【ライブラリID:" . $i_OneData[0] . "】";
		return FALSE;
	}
	//半角数値チェック
	if (!(preg_match("/^[0-9]+$/", $i_OneData[1]))) {
		$o_ErrMsg = "半角数値以外の値が指定されている種類が存在します。【ライブラリID:" . $i_OneData[0] . "】";
		return FALSE;
	}
	//機種依存文字チェック
	if (FALSE == checkMachineCode($i_OneData[1])) {
		$o_ErrMsg = "機種依存文字が指定されている種類が存在します。【ライブラリID:" . $i_OneData[0] . "】";
		return FALSE;
	}
	
	/*---ライブラリ名 $i_OneData[2] ---*/
	if ($i_ChkItemFlg[2] == 1) {
		if (strlen($i_OneData[2]) <= 0) {
			$o_ErrMsg = "ライブラリ名が指定されていないデーターが存在します。【ライブラリID:" . $i_OneData[0] . "】";
			return FALSE;
		}
	}
	//機種依存文字チェック
	if (FALSE == checkMachineCode($i_OneData[2])) {
		$o_ErrMsg = "機種依存文字が指定されているライブラリ名が存在します。【ライブラリID:" . $i_OneData[0] . "】";
		return FALSE;
	}
	
	/*---ライブラリ権限 $i_OneData[3] ---*/
	//必須チェック
	if ($i_ChkItemFlg[3] == 1) {
		if (strlen($i_OneData[3]) <= 0) {
			$o_ErrMsg = "ライブラリ権限が指定されていないデーターが存在します。【ライブラリID:" . $i_OneData[0] . "】";
			return FALSE;
		}
	}
	//ライブラリ権限チェック
	if (($i_OneData[3] != 1) & ($i_OneData[3] != 2)) {
		$o_ErrMsg = "ライブラリ権限として認められない値が指定されているデーターが存在します。【ライブラリID:" . $i_OneData[0] . "】";
		return FALSE;
	}
	//半角数値チェック
	if (!(preg_match("/^[0-9]+$/", $i_OneData[3]))) {
		$o_ErrMsg = "半角数値以外の値が指定されているライブラリ権限が存在します。【ライブラリID:" . $i_OneData[0] . "】";
		return FALSE;
	}
	//機種依存文字チェック
	if (FALSE == checkMachineCode($i_OneData[3])) {
		$o_ErrMsg = "機種依存文字が指定されているライブラリ権限が存在します。【ライブラリID:" . $i_OneData[0] . "】";
		return FALSE;
	}
	
	/*---内容 $i_OneData[4] ---*/
	if ($i_ChkItemFlg[4] == 1) {
		if (strlen($i_OneData[4]) <= 0) {
			$o_ErrMsg = "内容が指定されていないデーターが存在します。【ライブラリID:" . $i_OneData[0] . "】";
			return FALSE;
		}
	}
	//機種依存文字チェック
	if (FALSE == checkMachineCode($i_OneData[4])) {
		$o_ErrMsg = "機種依存文字が指定されている内容が存在します。【ライブラリID:" . $i_OneData[0] . "】";
		return FALSE;
	}
	
	/*---ソート $i_OneData[5] ---*/
	//必須チェック
	if ($i_ChkItemFlg[5] == 1) {
		if (strlen($i_OneData[5]) <= 0) {
			$o_ErrMsg = "ソートが指定されていないデーターが存在します。【ライブラリID:" . $i_OneData[0] . "】";
			return FALSE;
		}
	}
	//半角数値チェック
	if (strlen($i_OneData[5]) > 0) {
		if (!(preg_match("/^[0-9]+$/", $i_OneData[5]))) {
			$o_ErrMsg = "半角数値以外の値が指定されているソートが存在します。【ライブラリID:" . $i_OneData[0] . "】";
			return FALSE;
		}
	}
	//機種依存文字チェック
	if (FALSE == checkMachineCode($i_OneData[5])) {
		$o_ErrMsg = "機種依存文字が指定されているソートが存在します。【ライブラリID:" . $i_OneData[0] . "】";
		return FALSE;
	}
	
	//ソートが指定されていなかったならライブラリIDをソート値とする
	if (strlen($i_OneData[5]) <= 0) {
		$o_Sort = $i_OneData[0];
	}
	else {
		$o_Sort = $i_OneData[5];
	}
	
	/*---表示可能エリア $i_OneData[6] ---*/
	if ($i_OneData[1] == AREA_LIBRARY) {
		if ($i_ChkItemFlg[6] == 1) {
			if (strlen($i_OneData[6]) <= 0) {
				$o_ErrMsg = "表示可能エリアが指定されていないデーターが存在します。【ライブラリID:" . $i_OneData[0] . "】";
				return FALSE;
			}
		}
		//機種依存文字チェック
		if (FALSE == checkMachineCode($i_OneData[6])) {
			$o_ErrMsg = "機種依存文字が指定されている表示可能エリアが存在します。【ライブラリID:" . $i_OneData[0] . "】";
			return FALSE;
		}
	}
	
	/*---自動リンク展開フラグ $i_OneData[7] ---*/
	//必須チェック
	if ($i_ChkItemFlg[7] == 1) {
		if (strlen($i_OneData[7]) <= 0) {
			$o_ErrMsg = "自動リンク展開フラグが指定されていないデーターが存在します。【ライブラリID:" . $i_OneData[0] . "】";
			return FALSE;
		}
	}
	//半角数値チェック
	if (strlen($i_OneData[7]) > 0) {
		if (!(preg_match("/^[0-1]+$/", $i_OneData[7]))) {
			$o_ErrMsg = "0か1以外の値が指定されている自動リンク展開フラグが存在します。【ライブラリID:" . $i_OneData[0] . "】";
			return FALSE;
		}
	}
	
	return TRUE;

}

/*-----------------------------------------------------------------------------
	tbl_libraryにCSVデータを追加

【引数】	$i_OneData	配列で指定されたcsvデータ（全項目)
		$i_library_ver	ライブラリバージョン
		$i_Sort		ライブラリソート
		$i_objDac	DB
		
【戻値】	True	正常に終了
		False	エラー
		
【備考】
-----------------------------------------------------------------------------*/
function G_TblLibrayAdd($i_OneData, $i_library_ver, $i_Sort, $i_objDac) {
	
	$sql = "INSERT INTO tbl_library ( library_id, library_ver, area, name, user_parmission, context, sort_order, disp_area, all_area_flg, is_open_autolink) VALUES (";
	$sql = $sql . $i_OneData[0] . ", "; //ライブラリID
	$sql = $sql . "'" . $i_library_ver . "'" . ", "; //ライブラリバージョン
	$sql = $sql . "'" . $i_OneData[1] . "'" . ", "; //種類
	$sql = $sql . "'" . gd_addslashes(str_replace("\\\\", "\\", $i_OneData[2])) . "'" . ", "; //ライブラリ名
	$sql = $sql . "'" . $i_OneData[3] . "'" . ", "; //ライブラリ権限
	$sql = $sql . "'" . gd_addslashes(str_replace("\\\\", "\\", $i_OneData[4])) . "'" . ", "; //内容
	$sql = $sql . "'" . $i_Sort . "'" . ", "; //ライブラリバージョン	
	if ($i_OneData[1] == AREA_LIBRARY) {
		$sql = $sql . "'" . gd_addslashes(str_replace("\\\\", "\\", $i_OneData[6])) . "'" . ", "; //表示可能エリア
		if (strlen($i_OneData[6]) < 1) {
			$sql = $sql . "'" . FLAG_ON . "',"; //エリア切り替えフラグ
		}
		else {
			$sql = $sql . "'" . FLAG_OFF . "',"; //エリア切り替えフラグ
		}
	}
	else {
		$sql = $sql . "''" . ", "; //表示可能エリア
		$sql = $sql . "'" . FLAG_ON . "',"; //エリア切り替えフラグ
	}
	$sql = $sql . "'" . gd_addslashes(str_replace("\\\\", "\\", $i_OneData[7])) . "'"; //自動リンク展開フラグ
	$sql = $sql . ");";
	
	//実行
	return ($i_objDac->execute($sql, "utf-8", "auto"));
}

?>
