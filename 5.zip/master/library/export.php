<?php
/*
 * ユーザーテーブルの情報をエクスポートする
 */
//設定ファイル読み込み
require ("./.htsetting");
//データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

//定数 
//見出し文字
$G_SetHead = array(
		"ライブラリID", 
		"種類", 
		"ライブラリ名", 
		"ライブラリ権限", 
		"内容", 
		"ソート", 
		"表示可能エリア"
);

//データの取得
$sql = "SELECT * FROM tbl_library ORDER BY library_id ASC, library_ver DESC";
$objDac->execute($sql);
if ($objDac->getRowCount() <= 0) {
	DispError("ライブラリ情報が一件も登録されていません。", 6, "javascript:history.back()");
	exit();
}

$library_id_ary = array();
//出力データの作成
$ExpCavData = array();
$CsvLine = 0;
while ($objDac->fetch()) {
	if (in_array($objDac->fld['library_id'], $library_id_ary)) {
		continue;
	}
	$library_id_ary[] = $objDac->fld['library_id'];
	
	$ExpCavData[$CsvLine][] = $objDac->fld['library_id']; //ライブラリID
	$ExpCavData[$CsvLine][] = $objDac->fld['area']; //種類
	$ExpCavData[$CsvLine][] = str_replace("\\", "\\\\", $objDac->fld['name']); //ライブラリ名
	$ExpCavData[$CsvLine][] = $objDac->fld['user_parmission']; //ライブラリ使用者
	$ExpCavData[$CsvLine][] = str_replace("\\", "\\\\", $objDac->fld['context']); //内容
	$ExpCavData[$CsvLine][] = $objDac->fld['sort_order']; //ソート
	$ExpCavData[$CsvLine][] = str_replace("\\", "\\\\", $objDac->fld['disp_area']); //表示可能エリア
	$ExpCavData[$CsvLine][] = $objDac->fld['is_open_autolink']; //自動リンク展開フラグ
	

	$CsvLine++;
}

//CSV出力処理
create_Csv("library.csv", $ExpCavData, $G_SetHead, 0, "", "sjis-win", "\"");
?>
