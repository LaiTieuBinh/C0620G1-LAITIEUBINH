<?php
/*
 * ライブラリ管理　表示順序変更画面(sortorder.php)
 */
/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

if (!isset($_POST['parmission']) || !isset($_POST['area'])) {
	DispError("パラメータ取得エラー(parmission or area)", 6, "javascript:history.back()");
	exit();
}

/*--- データアクセスクラス ---*/
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_library.inc');
$objLibrary = new tbl_library($objCnc);

/*---表示項目の取得---*/
$BakURL = "./index.php?area=" . $_SESSION['use_library_area'];
$ResURL = "./sortorder.php";
$dspMsg = "";

//---取得
$library_ary = array();
$objLibrary->selectFromArea($_POST['area'], $_POST['parmission']);
//---一件も存在しなかった
if ($objLibrary->getRowCount() <= 0) {
	$dspMsg = "<p>対象となるライブラリが存在しませんでした。</p>";
}

//---成形
$dspList = "";
$dat_cnt = 0;
while ($objLibrary->fetch()) {
	$fld = $objLibrary->fld;
	$dspList .= "<tr>\n";
	//入力エリア
	$dspList .= "<td width=\"150\" align=\"center\" valign=\"middle\">";
	$dspList .= "<input type=\"text\" style=\"width:100px;text-align:center\" id = \"" . $fld['library_id'] . "\" name = \"" . $fld['library_id'] . "\"value=\"" . $fld['sort_order'] . "\"></td>\n";
	//テンプレート名
	$dspList .= "<td align=\"left\" valign=\"top\">" . htmlspecialchars($fld['name']) . "</td>\n";
	$dspList .= "</tr>\n";
	$dat_cnt++;
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ライブラリ表示順変更</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="category.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>

<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxSubmit(){
	for (i = 0; i < document.getElementsByTagName("INPUT").length; i++) {
		if(document.getElementsByTagName("INPUT")[i].type != "text")continue;
	    value = document.getElementsByTagName("INPUT")[i].value;
		if (value != "" && value.match(/[^0-9]+/)) {
		    alert("半角数字でない箇所があります。半角数字で入力してください。");
		    return false;
	    }
	}
	$('Form').submit();
	return false;
}
function cxReset(parmission,area){
	$('Form').action = 'sortorder.php';
	$('parmission').value = parmission;
	$('area').value = area;
	$('Form').submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'library';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-categoryform">
<div><img src="images/bar_listorder.jpg" alt="ライブラリ表示順変更" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?=$dspMsg?>
<form class="cms8341-form" method="POST" action="./sortorder_comp.php"
	id="Form" name="Form">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
<?php
if (strlen($dspList) > 0) {
	?>
<th width="150" align="center" valign="middle" scope="col">表示順 <span
			class="cms_require">（必須）</span></th>
<?php
	if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
		echo '<th align="center" valign="middle" scope="col">ライブラリ名</th>';
	}
	else {
		echo '<th align="center" valign="middle" scope="col">パーツ名</th>';
	}
	?>
<?php
}
?>
</tr>
<?=$dspList?> 
</table>
<?php
if (strlen($dspList) > 0) {
	?>
<p align="center"><input type="image" onClick="return cxSubmit()"
	src="images/btn_listorder.jpg" alt="表示順を変更" width="150" height="20"
	border="0" style="margin-right: 10px"> <a href="javascript:"
	onClick="return cxReset('<?=$_POST['parmission']?>','<?=$_POST['area']?>')"><img
	src="images/btn_reset.jpg" alt="リセット" width="150" height="20"
	border="0" style="margin-left: 10px"></a></p>
<?php
}
?>
<p align="left"><a href="<?=$BakURL?>"><img
	src="../images/btn_small_back.jpg" alt="戻る" width="120" height="20"
	border="0"></a></p>
<input type="hidden" id="parmission" name="parmission"
	value="<?=$_POST['parmission']?>"> <input type="hidden" id="area"
	name="area" value="<?=$_POST['area']?>"></form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
