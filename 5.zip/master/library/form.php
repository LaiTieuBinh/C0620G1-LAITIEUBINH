<?php
/*
 *
 */
/** require **/
require ("./.htsetting");

/** init **/
$dat = array();
$is_lock = lock_file_management('check'); // アップロード処理中か確認


/** get post date **/
if (isset($_POST["behavior"])) {
	$bv = $_POST["behavior"];
}
else {
	DispError("パラメータ取得エラー(behavior)", 6, "javascript:history.back()");
	exit();
}
//main
switch ($bv) {
	case 1 :
		if (isset($_POST["parmission"])) {
			$pm = $_POST["parmission"];
		}
		else {
			DispError("パラメータ取得エラー(parmission)", 6, "javascript:history.back()");
			exit();
		}
		$label = 'ライブラリ追加';
		if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
			$image = '<img src="images/bar_add_1.jpg" alt="ライブラリ追加" width="920" height="30">';
		}
		else {
			$image = '<img src="images/bar_add_2.jpg" alt="パーツ追加" width="920" height="30">';
		}
		$dat = array(
				"id" => "", 
				"ver" => "", 
				"name" => "", 
				"area" => "", 
				"parmission" => $pm, 
				"context" => "", 
				"sort_order" => "", 
				"disp_area" => "", 
				"all_area_flg" => "1", 
				"is_open_autolink" => "0"
		);
		break;
	case 2 :
		if (isset($_POST["lib_id"])) {
			$id = $_POST["lib_id"];
		}
		else {
			DispError("パラメータ取得エラー(lib_id)", 6, "javascript:history.back()");
			exit();
		}
		$label = 'ライブラリ修正';
		if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
			$image = '<img src="images/bar_fix_1.jpg" alt="ライブラリ修正" width="920" height="30">';
		}
		else {
			$image = '<img src="images/bar_fix_2.jpg" alt="パーツ修正" width="920" height="30">';
		}
		require ("./include/getRecord.inc");
		$dat = getRecord($id);
		break;
	default :
		DispError("パラメータエラー（behavior）", 6, "javascript:history.back()");
		exit();
		break;
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$label?></title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="library.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/ckeditor/ckeditor.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
function cxChange() {
	if ($('all_area_on') && $('all_area_on').checked) {
		Element.hide('disp_area');
	} else {
		Element.show('disp_area');
	}

	return false;
}
function cxAutoLinkChange() {
	if(!$('is_open_autolink_tr')) return false;
	if ($('pw01').checked) {
		Element.hide('is_open_autolink_tr');
	} else {
		Element.show('is_open_autolink_tr');
	}

	return false;
}
window.onload = function(){
	if ($('all_area_on')) {
		cxChange();
	}
	cxAutoLinkChange();
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'library';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-library">
<div><?=$image?></div>
<?php
if ($is_lock && $bv == 2) {
	?>
<div class="cms8341-areamessage" id="cms8341-denaillist-msg">
現在アップロード処理中のため即公開を行うことができません。<br>
即公開を行う場合はしばらく時間をおいてから再度お試しください。</div>
<?php
}
?>
<div class="cms8341-area-corner">
<form id="lib_form" class="cms8341-form" name="lib_form" method="post"
	action="confirm.php">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
<?php
if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
	echo '<th width="150" align="left" valign="top" scope="row">ライブラリ名　<span class="cms_require">（必須）</span></th>';
}
else {
	echo '<th width="150" align="left" valign="top" scope="row">パーツ名　<span class="cms_require">（必須）</span></th>';
}
?>
<td align="left" valign="middle"><input id="name" name="name"
			type="text" style="width: 540px"
			value="<?=htmlspecialchars($dat["name"])?>"></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">種類 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle">
<?php
if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
	print "テンプレート領域";
}
else {
	print "編集領域";
}
?>
</td>
	</tr>
<?php
if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
	echo '<tr>';
	echo '<th width="150" align="left" valign="top" scope="row">表示可能エリア　<br><span class="cms_require">（必須）</span></th>';
	echo '<td align="left" valign="middle">';
	if ($dat["all_area_flg"] == 1) {
		?>
<input type="radio" id="all_area_on" name="all_area_flg"
		onclick="cxChange()" checked value=<?=FLAG_ON?>>
	<label for="all_area_on">全て表示</label>
	<input type="radio" id="all_areaoff" name="all_area_flg"
		onclick="cxChange()" value=<?=FLAG_OFF?>>
	<label for="all_areaoff">指定して表示</label>
	<input id="disp_area" name="disp_area" type="text"
		style="width: 540px; display: none;"
		value=<?=htmlspecialchars($dat["disp_area"])?>>
	<br>
<?php
	}
	else {
		?>
<input type="radio" id="all_area_on" name="all_area_flg"
		onclick="cxChange()" value=<?=FLAG_ON?>>
	<label for="all_area_on">全て表示</label>
	<input type="radio" id="all_areaoff" name="all_area_flg"
		onclick="cxChange()" checked value=<?=FLAG_OFF?>>
	<label for="all_areaoff">指定して表示</label>
	<input id="disp_area" name="disp_area" type="text" style="width: 540px"
		value=<?=htmlspecialchars($dat["disp_area"])?>>
	<br>
<?php
	}
	echo '<div style="font-size:small"><span class="cms_require">※複数エリアを設定する場合は「,」区切りで入力してください</span><div>';
	echo '</td>';
	echo '</tr>';
}
?>
<tr>
		<th width="150" align="left" valign="top" scope="row">権限 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle">
<?php
if ($dat["parmission"] == 1) {
	?>
<input type="radio" id="pw01" name="parmission"
			onclick="cxAutoLinkChange()" checked value="1"><label for="pw01">共通</label>
		<input type="radio" id="pw02" name="parmission"
			onclick="cxAutoLinkChange()" value="2"><label for="pw02">ウェブマスター用</label>
<?php
}
else {
	?>
<input type="radio" id="pw01" name="parmission"
			onclick="cxAutoLinkChange()" value="1"><label for="pw01">共通</label> <input
			type="radio" id="pw02" name="parmission" onclick="cxAutoLinkChange()"
			checked value="2"><label for="pw02">ウェブマスター用</label>
<?php
}
?>
</td>
	</tr>
<?php
if ($_SESSION['use_library_area'] == AREA_EDIT) {
	echo '<tr id="is_open_autolink_tr">';
	echo '<th width="150" align="left" valign="top" scope="row">自動リンク</th>';
	echo '<td align="left" valign="middle"><input type="checkbox" name="is_open_autolink" id="is_open_autolink" value="1"' . (($dat["is_open_autolink"]) ? " checked" : "") . '><label for="is_open_autolink">自動リンクを展開する</label></td>';
	echo '</tr>';
}
?>
<tr>
		<th width="150" align="left" valign="top" scope="row">内容 <span
			class="cms_require">（必須）</span></th>
		<?php
	 // custom plugin
	$textarea = '<textarea id="cms_context" name="context">' . htmlspecialchars($dat["context"]) . '</textarea>';
    // youtube plugin
    $extraPlugins = IS_YOUTUBE_CONVERT ? ',gd_youtube' : '';
    
    global $objLogin;
    $login = $objLogin->login;
    $toolbar = "cms8341_library";
    
   
    $scriptEditor = "<script>
    CKEDITOR.replace( 'cms_context', { customConfig: 'config_library.js',
        language: 'ja',
        extraPlugins: 'widget,gd_liststyle,gd_link,gd_templates,gd_table,gd_table_clear,gd_image,gd_table_property,gd_table_deletelayout,gd_indent,gd_table_tools" . $extraPlugins . "',
        removePlugins: 'specialchar',
        stylesSet: 'cms8341',
        format_tags: 'p;h1;h2;h3;h4;h5;h6',
        height: 300
    });
    // load CK style
    CKEDITOR.stylesSet.add( 'cms8341', [
        { name: '下線', element: 'span', attributes: { 'class': 'underline' } },
        { name: '打ち消し線', element: 'span', attributes: { 'class': 'strike' } },
        { name: '文字色-赤', element: 'span', attributes: { 'class': 'txt_red' } },
        { name: '文字色-緑', element: 'span', attributes: { 'class': 'txt_green' } },
        { name: '行中左スペース-字', element: 'span', attributes: { 'class': 'space_lft' } },
        { name: '文字サイズ-大', element: 'span', attributes: { 'class': 'txt_big' } },
        { name: '文字サイズ-小', element: 'span', attributes: { 'class': 'txt_small' } },
        { name: '画像回り込み-右', element: 'img', attributes: { 'class': 'float_rgt' } },
        { name: '画像回り込み-左', element: 'img', attributes: { 'class': 'float_lft' } },
        { name: '画像回り込み-解除', element: 'img', attributes: { 'class': 'clear' } },
        { name: 'データテーブル', element: 'table', attributes: { 'class': 'datatable' } },
        { name: 'アイコンなし', element: 'ul', attributes: { 'class': 'noicon' } },
    ]);
    </script>
<script src='". RPW . "/ckeditor/gd_files/lang/fcklangmanager.js' type='text/javascript'></script>
<script src='". RPW . "/ckeditor/gd_files/js/paste_clean_word.js' type='text/javascript'></script>
<script src='". RPW . "/ckeditor/gd_files/js/ultility.js' type='text/javascript'></script>
<script src='". RPW . "/ckeditor/gd_files/js/icon_state_manager.js' type='text/javascript'></script>
<script src='". RPW . "/ckeditor/gd_files/js/ckeditor_inline.js' type='text/javascript'></script>
<script src='". RPW . "/ckeditor/gd_files/js/iframe_dialog_manager.js' type='text/javascript'></script>";
?>
    
		<td align="left" valign="middle"><?php print $textarea . $scriptEditor; ?></td>
	</tr>
<?php
if ($bv == 2 && $dat["area"] == 1) {
	?>
<tr>
		<th width="150" align="left" valign="top" scope="row">公開設定</th>
		<td align="left" valign="middle"><input type="checkbox" id="public"
			name="public" value="1" <?=($is_lock ? " disabled" : "")?>><label
			for="public">即公開する</label></td>
	</tr>
<?php
}
?>
</table>
<p align="center" class="ctrl"><input type="image"
	src="../images/btn_conf.jpg" alt="確認" width="150" height="20"
	border="0" style="margin-right: 10px"><a
	href="index.php?area=<?=$_SESSION['use_library_area']?>"><img
	src="../../images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150"
	height="20" border="0" style="margin-left: 10px"></a></p>
<input type="hidden" name="id" value="<?=$dat["id"]?>"> <input
	type="hidden" name="ver" value="<?=$dat["ver"]?>"> <input type="hidden"
	name="behavior" value="<?=$bv?>"> <input type="hidden"
	name="sort_order" value="<?=$dat["sort_order"]?>"></form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>