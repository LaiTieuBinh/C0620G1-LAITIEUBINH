<?php
// turn of Google Chrome XSS protection for posted HTML
header('X-XSS-Protection:0');
/*
 *
 */
/** require **/
require ("./.htsetting");
//require("./include/areaxml_load.inc");
//require("./include/getAreaLabel.inc");
/** init **/
$dat = array();
unset($_SESSION["hidden"]);
$is_lock = lock_file_management('check'); // アップロード処理中か確認


/** function **/
function getPostData() {
	$dat = array();
	if (isset($_POST["id"])) $dat["id"] = $_POST["id"];
	if (isset($_POST["ver"])) $dat["ver"] = $_POST["ver"];
	if (isset($_POST["name"])) $dat["name"] = $_POST["name"];
	if (isset($_POST["area"])) $dat["area"] = $_POST["area"];
	if (isset($_POST["parmission"])) $dat["parmission"] = $_POST["parmission"];
	if (isset($_POST["context"])) $dat["context"] = $_POST["context"];
	if (isset($_POST["sort_order"])) $dat["sort_order"] = $_POST["sort_order"];
	if (isset($_POST["disp_area"])) $dat["disp_area"] = $_POST["disp_area"];
	else $dat["disp_area"] = "";
	if (isset($_POST["all_area_flg"])) $dat["all_area_flg"] = $_POST["all_area_flg"];
	else $dat["all_area_flg"] = FLAG_ON;
	if ($dat["parmission"] == 1) $dat["is_open_autolink"] = FLAG_OFF;
	else if (isset($_POST["is_open_autolink"])) $dat["is_open_autolink"] = $_POST["is_open_autolink"];
	else $dat["is_open_autolink"] = FLAG_OFF;
	//
	$msg = "";
	if (!isset($dat["name"]) || $dat["name"] == "") {
		$msg .= "ライブラリ名が入力されていません。<br>";
	}
	elseif (!checkMachineCode($dat["name"])) {
		$msg .= "ライブラリ名に機種依存文字が使用されています。<br>";
	
	}
	$dat["area_label"] = ($_SESSION['use_library_area'] == AREA_LIBRARY) ? "テンプレート領域" : "編集領域";
	if (!isset($dat["parmission"]) || $dat["parmission"] == "") {
		$msg .= "権限が選択されていません。<br>";
	}
	if (!isset($dat["context"]) || $dat["context"] == "") {
		$msg .= "ライブラリの内容が入力されていません。<br>";
	}
	elseif (!checkMachineCode($dat["context"])) {
		$msg .= "ライブラリの内容に機種依存文字が使用されています。<br>";
	}
	if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
		if ($dat["all_area_flg"] == FLAG_OFF) {
			if (!isset($dat["disp_area"]) || $dat["disp_area"] == "") {
				$msg .= "表示可能エリアが入力されていません。<br>";
			}
			if (isset($dat["disp_area"]) && $dat["disp_area"] != "") {
				if (!checkMachineCode($dat["disp_area"])) {
					$msg .= "表示可能エリアに機種依存文字が使用されています。<br>";
				}
			}
		}
		else {
			$dat["disp_area"] = "";
		}
	}
	if ($msg != "") {
		DispError($msg, 6, "javascript:history.back()");
		exit();
	}
	
	return $dat;
}

/** get post date **/
if (isset($_POST["behavior"])) {
	$bv = $_POST["behavior"];
}
else {
	DispError("パラメータ取得エラー(behavior)", 6, "javascript:history.back()");
	exit();
}
switch ($bv) {
	case 1 :
		$msg = '<p>この情報で登録してもよろしいですか？</p>';
		$back = 'javascript:history.back()';
		$image = '<input type="image" src="../images/btn_add.jpg" alt="追加" width="150" height="20" border="0" style="margin-right:10px">';
		$dat = getPostData();
		$_SESSION["hidden"] = $dat;
		break;
	case 2 :
		$msg = '<p>この情報で登録してもよろしいですか？</p>';
		$back = 'javascript:history.back()';
		$image = '<input type="image" src="../images/btn_fix.jpg" alt="修正" width="150" height="20" border="0" style="margin-right:10px">';
		$dat = getPostData();
		if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
			if (isset($_POST["public"])) {
				if ($is_lock) {
					DispError("現在アップロード処理中のため即公開を行うことができません。<br>しばらく時間をおいてから再度お試しください。<br>", 6, "javascript:history.back()");
					exit();
				}
				$public = $_POST["public"];
				$publabel = "即公開する";
			}
			else {
				$public = 0;
				$publabel = "即公開しない";
			}
		}
		else {
			$public = 0;
			$publabel = "即公開しない";
		}
		$dat["public"] = $public;
		$_SESSION["hidden"] = $dat;
		break;
	case 3 :
		require ("./include/getRecord.inc");
		$msg = '<p>この情報を削除してもよろしいですか？</p>';
		$image = '<input type="image" src="../images/btn_del.jpg" alt="削除" width="150" height="20" border="0" style="margin-right:10px">';
		$id = $_POST["lib_id"];
		$dat = getRecord($id);
		$dat["area_label"] = ($dat["area"] == 1) ? "テンプレート領域" : "編集領域";
		$back = 'index.php?area=' . $_SESSION['use_library_area'];
		$_SESSION["hidden"] = $dat;
		break;
	case 4 :
		require ("./include/getRecord.inc");
		$msg = '';
		$id = $_POST["lib_id"];
		$dat = getRecord($id);
		$dat["area_label"] = ($dat["area"] == 1) ? "テンプレート領域" : "編集領域";
		$image = '<a href="index.php?area=' . $_SESSION['use_library_area'] . '"><image type="image" src="../images/btn_back.jpg" alt="戻る" width="150" height="20" border="0"></a>';
		$_SESSION["hidden"] = $dat;
		break;
	default :
		DispError("パラメータエラー（behavior）", 6, "javascript:history.back()");
		exit();
		break;
}

$context = $dat["context"];
// 自動リンクの展開
if ($dat["is_open_autolink"] == FLAG_ON) {
	$context = setAutoLink($context);
	$context = preg_replace('/<(a|area)( [^>]*)? href="[^"]*"/i', '<${1}${2} href="#"', $context); // リンクの無効化
}
$context = del_escapes($context);
$context = repNonEvent($context); // イベントの無効化
//	$context = preg_replace("/<form[^>]*>/i", "", $context);
//	$context = preg_replace("/<\/form>/i", "", $context);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ライブラリ確認</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="library.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'library';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-library">
<?php
if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
	echo '<div><img src="images/bar_conf_1.jpg" alt="ライブラリ確認" width="920" height="30"></div>';
}
else {
	echo '<div><img src="images/bar_conf_2.jpg" alt="パーツ確認" width="920" height="30"></div>';
}
?>

<div class="cms8341-area-corner">
<?=$msg?>
<form id="lib_form" class="cms8341-form" name="lib_form" method="post"
	action="submit.php">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
<?php
if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
	echo '<th width="150" align="left" valign="top" scope="row">ライブラリ名</th>';
}
else {
	echo '<th width="150" align="left" valign="top" scope="row">パーツ名</th>';
}
?>
<td align="left" valign="middle"><?=htmlDisplay(del_escapes($dat["name"]))?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">種類</th>
		<td align="left" valign="middle"><?=$dat["area_label"]?></td>
	</tr>
<?php
if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
	echo '<tr>';
	echo '<th width="150" align="left" valign="top" scope="row">表示可能エリア</th>';
	if ($dat["all_area_flg"] == FLAG_ON) {
		echo '<td align="left" valign="middle">全てのエリアで表示</td>';
	}
	else {
		echo '<td align="left" valign="middle">';
		echo htmlDisplay(del_escapes($dat["disp_area"]));
		echo '</td>';
	}
	echo '</tr>';
}
?>
<tr>
		<th width="150" align="left" valign="top" scope="row">権限</th>
		<td align="left" valign="middle">
<?php
if ($dat["parmission"] == 1) {
	print "共通";
}
elseif ($dat["parmission"] == 2) {
	print "ウェブマスター";
}
?>
</td>
	</tr>
<?php
if ($dat["parmission"] == 2 && $_SESSION['use_library_area'] == AREA_EDIT) {
	?>
<tr>
		<th width="150" align="left" valign="top" scope="row">自動リンク</th>
		<td align="left" valign="middle">
<?php
	if ($dat["is_open_autolink"] == FLAG_ON) {
		print "自動リンクを展開する";
	}
	else {
		print "自動リンクを展開しない";
	}
	?>
</td>
	</tr>
<?php
}
?>
<tr>
		<th width="150" align="left" valign="top" scope="row">内容</th>
		<td align="left" valign="middle">
		<div class="preview"><?=$context?></div>
		</td>
	</tr>
<?php
if ($bv == 2 && $_SESSION['use_library_area'] == AREA_LIBRARY) {
	?>
<tr>
		<th width="150" align="left" valign="top" scope="row">公開設定</th>
		<td align="left" valign="middle"><?=$publabel?></td>
	</tr>
<?php
}
?>
</table>
<?php
if ($bv != 4) {
	?>
<p align="center" class="ctrl"><?=$image?><a href="<?=$back?>"><img
	src="../../images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150"
	height="20" border="0" style="margin-left: 10px"></a></p>
<?php
}
else {
	?>
<p align="center" class="ctrl"><?=$image?></p>
<?php
}
?>
<input type="hidden" name="behavior" value="<?=$bv?>">
<?php
if (isset($_SESSION['hidden'])) {
	foreach ($_SESSION['hidden'] as $key => $val) {
		?>
<input type="hidden" name="<?=htmlspecialchars($key)?>"
	value="<?=htmlspecialchars($val)?>">
<?php
	}
}
?>
<input type="hidden" name="use_library_area"
	value="<?=(isset($_SESSION['use_library_area']) ? htmlspecialchars($_SESSION['use_library_area']) : "")?>">
</form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
