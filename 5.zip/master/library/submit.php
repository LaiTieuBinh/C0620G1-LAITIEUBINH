<?php
/*
 *
 */
/** require **/
require ("./.htsetting");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ライブラリ即公開</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="template.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxdisplay() {
	$('css_disp').style.display = 'none';
	$('conf_disp').style.display = 'inline';
}
//-->	
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'library';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
require_once (APPLICATION_ROOT . '/common/function/func_progressbar.inc');
$pgrs_func = new progressbar();

?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><img src="images/bar_recreate.jpg" alt="ライブラリの再公開" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?=$pgrs_func->get_progress_area()?>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<?php
/** init **/
$dat = array();
/** get post data **/
$bv = $_POST["behavior"];

$id = $_POST["id"];
$ver = $_POST["ver"];
$name = $_POST["name"];
$parmission = $_POST["parmission"];
$context = $_POST["context"];
$sort_order = $_POST["sort_order"];
$disp_area = $_POST["disp_area"];
$all_area_flg = $_POST["all_area_flg"];

$area = $_POST['use_library_area'];
$is_open_autolink = $_POST["is_open_autolink"];

if ($bv == 2) {
	$public = $_POST['public'];
}

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/b_dac.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandle = new tbl_handler($objCnc);
$objDac = new b_dac($objCnc);
$objDac->setTableName("tbl_library");
$objDac->pk = "library_id";

switch ($bv) {
	case 1 :
		require ("./include/insert.inc");
		break;
	case 2 :
		require ("./include/update.inc");
		break;
	case 3 :
		require ("./include/delete.inc");
		break;
	default :
		DispError("パラメータ取得エラー（behavior）", 6, "javascript:history.back()");
		exit();
		break;
}
?>