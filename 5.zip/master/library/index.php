<?php
/*
 *
 */
/** require **/
require ("./.htsetting");
/** handler check **/
require ("./include/handlerCheck.inc");
/** create list **/
//require("./include/areaxml_load.inc");
//require("./include/getAreaLabel.inc");
//
unset($_SESSION["hidden"]);
unset($_SESSION['use_template_id']);
unset($_SESSION['use_template_kind']);

if (isset($_GET['area'])) {
	$_SESSION['use_library_area'] = $_GET['area'];
}
else {
	$_SESSION['use_library_area'] = AREA_LIBRARY;
}
$temp_ary = array(
		AREA_LIBRARY, 
		AREA_EDIT
);
if (!in_array($_SESSION['use_library_area'], $temp_ary)) {
	DispError("パラメータエラー（area）", 6, "javascript:history.back()");
	exit();
}

function createList($i_objDac, $pm, $area) {
	//format
	$fmt1 = '<tr>';
	$fmt1 .= '<td align="left" valign="top"><a href="javascript:" onClick="return cxLibraryForm({lib_id},4,null)" onKeyDown="return cxLibraryForm({lib_id},4,null)">{library_name}</a>（{lib_id}）</td>';
	$fmt1 .= '<td width="180" align="center" valign="middle">';
	$fmt1 .= '<a href="javascript:" onClick="return cxLibraryForm({lib_id},2,null)" onKeyDown="return cxLibraryForm({lib_id},2,null)"><img src="../images/btn_mini_fix.jpg" alt="修正" width="60" height="20" border="0" style="margin-right:3px"></a>';
	$fmt2a = '<a href="javascript:" onClick="return cxLibraryForm({lib_id},3,null)" onKeyDown="return cxLibraryForm({lib_id},3,null)"><img src="../images/btn_mini_del.jpg" alt="削除" width="60" height="20" border="0" style="margin-left:3px"></a>';
	$fmt2b = '<img src="../../images/spacer.gif" alt="" width="60" height="20" border="0" style="margin-left:3px">';
	$fmt3 = '</td>';
	$fmt3 .= '</tr>';
	//
	$html = '';
	//
	$sql = "SELECT library_id,library_ver,area,name FROM tbl_library L1";
	$sql .= " WHERE user_parmission='" . $pm . "' and area='" . $area . "' and library_ver=(SELECT MAX(L2.library_ver) from tbl_library L2 WHERE L1.library_id=L2.library_id)";
	$sql .= " order by L1.area, L1.sort_order,L1.library_id";
	$i_objDac->execute($sql);
	$i_objDac->fetchrow = 0;
	//
	$cnt = $i_objDac->getRowCount();
	$areaName = ($area == AREA_LIBRARY) ? "ライブラリ名" : "パーツ名";
	if ($cnt > 0) {
		while ($i_objDac->fetch()) {
			//print_dp($libDac->fld);
			//
			$id = $i_objDac->fld['library_id'];
			$name = htmlDisplay($i_objDac->fld['name']);
			$hchk = handlerCheck($id);
			if ($hchk) {
				$tmp = $fmt1 . $fmt2b . $fmt3;
			}
			else {
				$tmp = $fmt1 . $fmt2a . $fmt3;
			}
			$tmp = str_replace('{lib_id}', $id, $tmp);
			$tmp = str_replace('{library_name}', $name, $tmp);
			$html .= $tmp;
		}
		$header = '<tr>' . "\n";
		$header .= '<th>' . $areaName . '</th>' . "\n";
		$header .= '<th align="center">' . "\n";
		$header .= '<a href="javascript:" onClick="return cxLibrarySort(\'' . $pm . '\',\'' . $area . '\')">';
		$header .= '<img src="images/btn_list.jpg" alt="表示順を変更" width="101" height="21" border="0"></a>' . "\n";
		$header .= '</th>' . "\n";
		$header .= '</tr>' . "\n";
		$html = $header . $html;
	}
	else {
		$html = '<tr><td align="center" valign="top">現在、' . $areaName . 'のライブラリは登録されていません。</td></tr>';
	}
	return $html;
}

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
//$objCnc->begin();
//createList
$common_library_1 = createList($objDac, 1, $_SESSION['use_library_area']);
$master_library_1 = createList($objDac, 2, $_SESSION['use_library_area']);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ライブラリ管理</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="library.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxLibraryForm(id,bv,pm) {
	switch(bv) {
		case 1:
			$('behavior').value = bv;
			$('parmission').value = pm;
			$('lib_form').action = 'form.php';
			document.lib_form.submit();
			break;
		case 2:
			$('lib_id').value = id;
			$('behavior').value = bv;
			$('lib_form').action = 'form.php';
			document.lib_form.submit();
			break;
		case 3:
			$('lib_id').value = id;
			$('behavior').value = bv;
			$('lib_form').action = 'confirm.php';
			document.lib_form.submit();
			break;
		case 4:
			$('lib_id').value = id;
			$('behavior').value = bv;
			$('lib_form').action = 'confirm.php';
			document.lib_form.submit();
			break;
		default:
			alert('パラメータエラー（behavior）');
			break;
	}
	return false;
}
function cxLibrarySort(parmission,area){
	$('lib_form').action = 'sortorder.php';
	$('parmission').value = parmission;
	$('area').value = area;
	$('lib_form').submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'library';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-library">
<?php
if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
	echo '<div><img src="images/bar_library01_1.jpg" alt="共通ライブラリ" width="920" height="30"></div>';
}
else {
	echo '<div><img src="images/bar_library01_2.jpg" alt="共通パーツ" width="920" height="30"></div>';
}
?>
<div class="cms8341-area-box">
<p align="right">
<?php
if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
	echo '<a href="javascript:" onClick="return cxLibraryForm(null,1,1)" onKeyDown="return cxLibraryForm(null,1,1)"><img src="images/btn_add.jpg" alt="新規ライブラリを追加" width="150" height="20" border="0"></a>';
}
else {
	echo '<a href="javascript:" onClick="return cxLibraryForm(null,1,1)" onKeyDown="return cxLibraryForm(null,1,1)"><img src="images/btn_add_parts.jpg" alt="新規パーツを追加" width="150" height="20" border="0"></a>';
}
?>

</p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
<?=$common_library_1?>
</table>
<br>
</div>
<?php
if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
	echo '<div><img src="images/bar_library02_1.jpg" alt="ウェブマスター用ライブラリ" width="920" height="30"></div>';
}
else {
	echo '<div><img src="images/bar_library02_2.jpg" alt="ウェブマスター用パーツ" width="920" height="30"></div>';
}
?>
<div class="cms8341-area-box">
<p align="right">
<?php
if ($_SESSION['use_library_area'] == AREA_LIBRARY) {
	echo '<a href="javascript:" onClick="return cxLibraryForm(null,1,2)" onKeyDown="return cxLibraryForm(null,1,2)"><img src="images/btn_add.jpg" alt="新規ライブラリを追加" width="150" height="20" border="0"></a>';
}
else {
	echo '<a href="javascript:" onClick="return cxLibraryForm(null,1,2)" onKeyDown="return cxLibraryForm(null,1,2)"><img src="images/btn_add_parts.jpg" alt="新規パーツを追加" width="150" height="20" border="0"></a>';
}
?>

</p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
<?=$master_library_1?>
</table>
<br>
</div>
</div>
</div>
<!-- cms8341-contents -->
<form id="lib_form" class="cms8341-form" name="lib_form"
	action="form.php" method="post"><input type="hidden" id="lib_id"
	name="lib_id" value=""> <input type="hidden" id="behavior"
	name="behavior" value=""> <input type="hidden" id="parmission"
	name="parmission" value=""> <input type="hidden" id="area" name="area"
	value=""></form>
</body>
</html>
