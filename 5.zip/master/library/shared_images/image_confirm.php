<?php
/*
 *
 */
//外部ファイル読み込み
require_once ("../../.htsetting");

//変数の指定
//ファイル名
$file_name_ary = array();
//エラーメッセージ
$err_msg = array();
//ファイル情報
unset($_SESSION["FILES"]);
$_SESSION["FILES"] = $_FILES;
//一時フォルダ
$tmp_file_dir = DOCUMENT_ROOT . DIR_PATH_TEMP . $objLogin->get('user_id') . '/';

//一時フォルダを削除する
if (@file_exists($tmp_file_dir)) removeDir($tmp_file_dir);

//引数の取得
$image_id = (isset($_POST['cms_image_id']) ? $_POST['cms_image_id'] : "");

//引数のチェック
if ($image_id != "" && !is_numeric($image_id)) $image_id = "";

//アップロードファイル数分ループ
foreach ($_FILES as $file_key => $Up_File) {
	//ファイルID
	$i = substr($file_key, -1);
	//ファイル名
	$file_name_ary[$i] = "";
	//エラーメッセージ
	$err_msg[$i] = "";
	
	//ファイルが無ければスキップ
	if ($Up_File['name'] == "") {
		unset($err_msg[$i]);
		unset($file_name_ary[$i]);
		continue;
	}
	
	//ファイルパスの設定
	//差し替えの場合
	if ($image_id != "") {
		//同名で上書き
		$file_name_ary[$i] = $_POST['cms_image_file_name'];
	} //通常の登録
	else {
		//リネームが存在した場合、リネームされたファイル名を使用する
		if (isset($_POST['cms_rename_file_path_' . $i]) && $_POST['cms_rename_file_path_' . $i] != "") $file_name_ary[$i] = strtolower(basename($_POST['cms_rename_file_path_' . $i]));
		else $file_name_ary[$i] = strtolower($Up_File['name']);
	}
	
	//一時ファイルパス
	$tmp_file_path = $tmp_file_dir . $file_name_ary[$i];
	//完了時のパス
	$real_file_path = DOCUMENT_ROOT . RPW . FCK_IMAGES_FORDER_SHARED . "/" . $file_name_ary[$i];
	
	//エラー処理を行うため、whileを使用
	while (true) {
		//差し替えでない場合
		if ($image_id == "") {
			/* 上書きかリネームか選択できるようにしたためコメント化
			//同名ファイルの確認
			if(@file_exists($real_file_path)) $err_msg[$i] = "保存先フォルダに同名のファイルが存在します。";
			//エラーがあれば、抜ける
			if($err_msg[$i] != "") break;
			*/
		}
		
		//ファイルチェック
		if (!is_uploaded_file($Up_File["tmp_name"])) $err_msg[$i] = "不正なファイルが選択されています。";
		//ファイルエラーチェック
		if ($Up_File["error"] != UPLOAD_ERR_OK) $err_msg[$i] = "ファイルのアップロードに失敗しました。";
		//拡張子チェック
		$File_Exte = explode(",", DENIED_EXTENSIONS_FILE);
		foreach ($File_Exte as $exte) {
			if (preg_match('/(\.' . $exte . ')$/i', $file_name_ary[$i])) $err_msg[$i] = "指定されたファイルはアップロードすることが出来ません。";
		}
		//携帯用の拡張子及びサイズの取得
		if (isset($_SESSION['use_template_kind']) && $_SESSION['use_template_kind'] == TEMPLATE_KIND_MOBILE) {
			$File_Exte = explode(",", ALLOWED_EXTENSIONS_IMAGE_MOBILE);
			$Image_Max_Size_Width = FCK_MOBILE_UPLOAD_IMAGE_W;
			$Image_Max_Size_Height = FCK_MOBILE_UPLOAD_IMAGE_H;
		} //通常用の拡張子及びサイズの取得
		else {
			$File_Exte = explode(",", ALLOWED_EXTENSIONS_IMAGE);
			$Image_Max_Size_Width = FCK_UPLOAD_IMAGE_W;
			$Image_Max_Size_Height = FCK_UPLOAD_IMAGE_H;
		}
		//全て小文字に変換
		foreach ($File_Exte as $k => $val) {
			$File_Exte[$k] = strtolower($val);
		}
		//画像の情報取得
		$image_info = @getimagesize($Up_File["tmp_name"]);
		if (!isset($image_info) || isset($image_info) && $image_info == null) {
			$err_msg[$i] = "指定されたファイルはアップロードすることが出来ません。";
			break;
		}
		//拡張子によっての処理
		switch ($image_info[2]) {
			//GIF
			case IMG_GIF :
				if (!in_array("gif", $File_Exte)) $err_msg[$i] = "指定されたファイルはアップロードすることが出来ません。";
				break;
			//PNG
			case 3 :
			case IMG_PNG :
				if (!in_array("png", $File_Exte)) $err_msg[$i] = "指定されたファイルはアップロードすることが出来ません。";
				break;
			//JPG
			case IMG_JPG :
			case IMG_JPEG :
				if (!in_array("jpg", $File_Exte) && !in_array("jpeg", $File_Exte)) $err_msg[$i] = "指定されたファイルはアップロードすることが出来ません。";
				break;
			//その他
			default :
				$err_msg[$i] = "指定されたファイルはアップロードすることが出来ません。";
				break;
		}
		//ファイル名チェック
		//使用不可の記号チェック
		if (preg_match('/[^ \w\-_\.~]/i', $file_name_ary[$i])) $err_msg[$i] = "アップロードできないファイル名です。ファイル名に使用できるのは半角英数字と - _ . ~ です。";
		//「.」が複数含まれているかチェック
		if (strpos($file_name_ary[$i], '.') != strrpos($file_name_ary[$i], '.')) $err_msg[$i] = "ファイル名に「.」が二つ以上ついているファイルはアップロードすることが出来ません。";
		//「.」がファイル名の先頭に含まれているかチェック
		if (strpos($file_name_ary[$i], '.') == 0) $err_msg[$i] = "ファイル名にの先頭に「.」がついているファイルはアップロードすることが出来ません。";
		//ファイルサイズチェック
		//0byte以下のファイルチェック
		if ($Up_File["size"] <= 0) $err_msg[$i] = "ファイルサイズが0バイトのファイルは取り込めません。";
		//ファイルMAXサイズチェック
		if (is_none_check_dir($real_file_path) === FALSE && $Up_File["size"] > FCK_UPLOAD_MAX_IMAGE * 1024) $err_msg[$i] = "画像ファイルの容量が大き過ぎます。";
		//エラーがあれば、抜ける
		if ($err_msg[$i] != "") break;
		
		//ファイルの仮アップロード処理
		//フォルダが存在しなければ、フォルダを作成
		if (!mkNewDirectory($tmp_file_path)) $err_msg[$i] = "ファイルのアップロードに失敗しました。";
		//エラーがあれば、抜ける
		if ($err_msg[$i] != "") break;
		
		//ファイルの移動処理
		if (@move_uploaded_file($Up_File["tmp_name"], ($tmp_file_path))) chmod($tmp_file_path, 0777);
		else $err_msg[$i] = "ファイルのアップロードに失敗しました。";
		$_SESSION["FILES"][$file_key]['tmp_name'] = $tmp_file_path;
		//ファイルリサイズ
		//画像のアップロード完了時のパスがリサイズ無効フォルダならリサイズしない。
		if (is_none_check_dir($real_file_path) === FALSE) {
			if (!mkThumbnail($tmp_file_path, $Image_Max_Size_Width, $Image_Max_Size_Height)) $err_msg[$i] = "ファイルのアップロードに失敗しました。";
		}
		//差し替えの場合
		if ($image_id != "") {
			$real_image_info = @getimagesize($real_file_path);
			if ($real_image_info[0] != $image_info[0] || $real_image_info[1] != $image_info[1]) $err_msg[$i] = "画像の縦、横サイズが差し替え元のファイルと違うと、画像を差し替えることが出来ません。";
		}
		//エラーがあれば、抜ける
		if ($err_msg[$i] != "") break;
		
		break;
	}
	
	//エラーメッセージがあれば、ファイル削除
	if ($err_msg[$i] != "") {
		if (@file_exists($tmp_file_path)) @unlink($tmp_file_path);
	} //エラーメッセージが無ければ、エラーメッセージを削除
	else
		unset($err_msg[$i]);
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex, nofollow" />
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>共通画像 追加確認</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script
	src="<?=RPW?>/ckeditor/gd_files/js/dialog_common.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/ckeditor/plugins/gd_image/pages/js/com_func.js"
	type="text/javascript"></script>
<script
	src="<?=RPW?>/ckeditor/plugins/gd_image/pages/js/fck_image_upload.js"
	type="text/javascript"></script>
<script type="text/javascript">
			<!--
				var SHARED_FILE_PATH = '<?php
				print(DOCUMENT_ROOT . RPW . FCK_IMAGES_FORDER_SHARED)?>';
				var template_kind = '<?php
				print((isset($_SESSION["use_template_kind"]) ? $_SESSION["use_template_kind"] : ""));
				?>';
				<?php
				echo loadSettingVars();
				?>
			//-->
		</script>
</head>
<body id="cms8341-mainbg">
		<?php
		// ヘッダーメニュー挿入
		$headerMode = 'library';
		include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
		?>
		<div id="cms8341-contents">
<div align="center" id="cms8341-library">
<div><img src="images/bar_shared_images_add02.jpg" alt="共通画像 登録確認"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" cellspacing="0" cellpadding="0"
	style="background-color: #FFFFFF;">
	<tr>
		<td valign="top">
		<form name="cms_fck_image_upload" id="cms_fck_image_upload"
			action="image_complete.php" method="post">
								<?php
								if ($image_id == "") $loop_cnt = 5;
								else $loop_cnt = 1;
								for($i = 0; $i < $loop_cnt; $i++) {
									?>
									<input type="hidden" id="cms_image_name_<?=$i?>"
			name="cms_image_name_<?=$i?>"
			value="<?=(isset($_POST['cms_image_name_' . $i]) ? htmlDisplay($_POST['cms_image_name_' . $i]) : "")?>">
		<input type="hidden" id="cms_image_path_<?=$i?>"
			name="cms_image_path_<?=$i?>"
			value="<?=(isset($_POST['cms_image_path_' . $i]) ? $_POST['cms_image_path_' . $i] : "")?>">
		<input type="hidden" name="cms_image_collection_<?=$i?>"
			id="cms_image_collection_<?=$i?>"
			value="<?=(isset($_POST['cms_image_collection_' . $i]) ? $_POST['cms_image_collection_' . $i] : "")?>">
		<input type="hidden" id="cms_rename_file_path_<?=$i?>"
			name="cms_rename_file_path_<?=$i?>"
			value="<?=(isset($_POST['cms_rename_file_path_' . $i]) ? $_POST['cms_rename_file_path_' . $i] : "")?>">
		<input type="hidden" id="cms_image_file_name"
			name="cms_image_file_name"
			value="<?=(isset($_POST['cms_image_file_name']) ? $_POST['cms_image_file_name'] : "")?>">
		<input type="hidden" id="cms_image_id" name="cms_image_id"
			value="<?=(isset($_POST['cms_image_id']) ? $_POST['cms_image_id'] : "")?>">
									<?php
									if (!isset($file_name_ary[$i]) || $file_name_ary[$i] == "") continue;
									?>
									<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable" style="margin-top: 5px;">
			<tr style="padding: 5px;">
				<th width="150">画像名称<?=($image_id == "" ? ($i + 1) : "")?></th>
				<td>
												<?=(isset($_POST["cms_image_name_" . $i]) && $_POST["cms_image_name_" . $i] != "" ? htmlDisplay($_POST["cms_image_name_" . $i]) : "")?>
											</td>
			</tr>
			<tr style="padding: 5px;">
				<th><?=($image_id == "" ? "ファイル" . ($i + 1) : "差し替えファイル")?></th>
				<td>
												<?php
									if (isset($err_msg[$i]) && $err_msg[$i] != "") print($err_msg[$i]);
									else if (isset($file_name_ary[$i]) && $file_name_ary[$i] != "") {
										print('<img src="' . DIR_PATH_TEMP . $objLogin->get('user_id') . "/" . $file_name_ary[$i] . "?rnd=" . rand() . '" alt="' . (isset($_POST["cms_image_name_" . $i]) && $_POST["cms_image_name_" . $i] != "" ? htmlDisplay($_POST["cms_image_name_" . $i]) : "") . '"><br>');
										print(FCK_IMAGES_FORDER_SHARED . '/' . htmlDisplay($file_name_ary[$i]));
									}
									?>
											</td>
			</tr>
		</table>
								<?php
								}
								?>
								<br>
		<br>
		<div align="center">
									<?php
									if (count($err_msg) == count($file_name_ary)) {
										?>
										<img src="<?=RPW?>/admin/images/fckimage/btn_regist_off.jpg"
			border="0" alt="登録" width="100" height="20">
									<?php
									}
									else {
										?>
										<input type="image" name="submit_upload" id="submit_upload"
			src="<?=RPW?>/admin/images/fckimage/btn_regist_on.jpg" border="0"
			alt="登録" width="100" height="20">
									<?php
									}
									?>
									<a href="javascript:history.back()"><img
			src="<?=RPW?>/admin/images/btn/btn_cansel.jpg" alt="キャンセル"
			width="101" height="21" border="0" style="margin-left: 10px"></a></div>
		</form>
		</td>
	</tr>
</table>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
