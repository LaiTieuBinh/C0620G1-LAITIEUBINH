<?php
/**
 * 
 */
//外部ファイル読み込み
require_once ("../../.htsetting");

//DBアクセス用ファイルの読み込み
global $objCnc;
global $objLogin;
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);

//ページ内定数
//CMSで使用するPOSTのプレフィックス
define("CMS_POST", "cms_fck_image_");
//リスト表示時の画像の縦横幅
define("FCK_IMAGE_LIST_WIDTH", "64");
define("FCK_IMAGE_LIST_HEIGHT", "64");

//変数の指定
//検索条件配列
$search = array(
		"keyword" => "", 
		"path" => "", 
		"update_datetime" => FLAG_OFF
);
//検索フラグ
$search_flg = FLAG_OFF;

//POST値の取得
foreach ($_POST as $k => $v) {
	if (substr($k, 0, strlen(CMS_POST)) != CMS_POST) continue;
	$k = str_replace(CMS_POST, "", $k);
	$search[$k] = $v;
	$search_flg = FLAG_ON;
}

//検索条件作成


//共通画像のデータのみ抽出
$where = $objFCKImages->_addslashesC("path", FCK_IMAGES_FORDER_SHARED . "/%", "LIKE");

//キーワード抽出
if (strlen($search['keyword']) > 0) {
	$keyword = explode(" ", str_replace("　", " ", $search['keyword']));
	foreach ($keyword as $key => $val) {
		if (strlen($val) > 0) {
			$val = javaStringEscape($val);
			$where .= ' AND ( ';
			$where .= $objFCKImages->_addslashesC('name', '%' . $val . '%', 'LIKE');
			$where .= ' OR ';
			$where .= $objFCKImages->_addslashesC('path', '%' . $val . '%', 'LIKE');
			$where .= ')';
		}
	}
}

//条件文に付加されている最初の AND を除去
$where = preg_replace("/^( AND )+/i", "", $where);

//一時検索
$objFCKImages->select($objFCKImages->_addslashesC("path", FCK_IMAGES_FORDER_SHARED . "/%", "LIKE"), '*');
//検索結果全件抽出
$flds = array();
while ($objFCKImages->fetch()) {
	$flds[] = $objFCKImages->fld;
}

//フォルダ内の全てのファイルを読み込む
$real_file_path = array();
$dir = DOCUMENT_ROOT . RPW . FCK_IMAGES_FORDER_SHARED;
if ($handle = @opendir($dir)) {
	//「.」「..」は無視
	$temp_ary = array(
			".", 
			".."
	);
	while (false !== ($file = readdir($handle))) {
		//「.」「..」は無視
		if (in_array($file, $temp_ary)) continue;
		//拡張子がアップロード対象の画像の場合
		if (!preg_match('/.*?\.(.*?)$/i', $file, $matches)) continue;
		$file_ext = strtolower($matches['1']);
		$VISIBLE_EXTENSIONS_IMAGE = getDefineArray('VISIBLE_EXTENSIONS_IMAGE');
		if (in_array($file_ext, $VISIBLE_EXTENSIONS_IMAGE)) {
			//一覧に表示するためファイル名を保持
			$real_file_path[] = FCK_IMAGES_FORDER_SHARED . '/' . $file;
		}
	}
	closedir($handle);
}

//DBに情報の無いファイルの情報を登録する
//実ファイル分ループ
foreach ((array) $real_file_path as $num => $file) {
	$no_db_file_path_flg = true; //DB登録済み判定フラグ
	//DBに登録されている数分ループ
	foreach ((array) $flds as $fld) {
		//DBにパスがある場合
		if ($file == $fld['path']) {
			$no_db_file_path_flg = false;
			break;
		}
	}
	//DBに登録されていない場合
	if ($no_db_file_path_flg) {
		//トランザクション処理
		$objCnc->begin();
		//登録処理
		$temp_ary = array(
				'name' => $file, 
				'path' => $file
		);
		if ($objFCKImages->insert($temp_ary) === FALSE) {
			//エラー
			$objCnc->rollback();
			user_error("データの一覧登録処理に失敗しました。", E_USER_ERROR);
		}
		//コミット
		$objCnc->commit();
	}
}

//更新日
if ($search['update_datetime'] == FLAG_ON) $order = "update_datetime ASC";
else $order = "update_datetime DESC";

//検索
$objFCKImages->select($where, '*', $order);
//検索結果全件抽出
$drawHTML = "";
while ($objFCKImages->fetch()) {
	$fld = $objFCKImages->fld;
	//実ファイルが存在していない場合は表示しない
	if (!@file_exists(DOCUMENT_ROOT . RPW . $fld['path'])) continue;
	
	//画像サイズの取得
	$size = getimagesize(DOCUMENT_ROOT . RPW . $fld['path']);
	$witdh = $size[0];
	$height = $size[1];
	//サイズ判定処理
	$isResizeWitdh = ($witdh > FCK_IMAGE_LIST_WIDTH ? true : false);
	$isResizeHeight = ($height > FCK_IMAGE_LIST_HEIGHT ? true : false);
	//縦横ともに指定サイズを超えていた場合
	if ($isResizeWitdh && $isResizeHeight) {
		//横のサイズの方が大きい場合、縦を横に合わせる
		if ($witdh > $height) {
			$witdhDisp = FCK_IMAGE_LIST_WIDTH;
			$heightDisp = $height / ($witdh / FCK_IMAGE_LIST_WIDTH);
		} //縦のサイズの方が大きい場合、横を縦にあわせる
		else {
			$witdhDisp = $witdh / ($height / FCK_IMAGE_LIST_HEIGHT);
			$heightDisp = FCK_IMAGE_LIST_HEIGHT;
		}
	} //縦のサイズが指定のサイズを超えていた場合、横を縦にあわせる
	else if (!$isResizeWitdh && $isResizeHeight) {
		$witdhDisp = $witdh / ($height / FCK_IMAGE_LIST_HEIGHT);
		$heightDisp = FCK_IMAGE_LIST_HEIGHT;
	} //横のサイズが指定のサイズを超えていた場合、縦を横に合わせる
	else if ($isResizeWitdh && !$isResizeHeight) {
		$witdhDisp = FCK_IMAGE_LIST_WIDTH;
		$heightDisp = $height / ($witdh / FCK_IMAGE_LIST_WIDTH);
	} //縦横どちらも指定サイズを超えていない場合
	else if (!$isResizeWitdh && !$isResizeHeight) {
		$witdhDisp = $witdh;
		$heightDisp = $height;
	}
	
	//削除可能かチェックする
	$chk_tbl = array(
			'tbl_work_images', 
			'tbl_publish_images'
	);
	$Delete_Flg = true;
	foreach ($chk_tbl as $tbl) {
		$sql = "SELECT page_id FROM " . $tbl . " WHERE (" . $objImages->_addslashesC('src', $fld['path'], 'LIKE', 'TEXT') . ")";
		$objImages->execute($sql);
		if ($objImages->getRowCount() > 0) $Delete_Flg = false;
	}
	
	//HTML 作成
	$drawHTML .= '<tr id="cms_image_tr_' . $fld['id'] . '" style="padding:1px 1px 1px 1px;">';
	$drawHTML .= '<input type="hidden" name="cms_url_' . $fld['id'] . '" id="cms_url_' . $fld['id'] . '" value="' . htmlDisplay($fld['path']) . '">';
	$drawHTML .= '<input type="hidden" name="cms_width_' . $fld['id'] . '" id="cms_width_' . $fld['id'] . '" value="' . $witdh . '">';
	$drawHTML .= '<input type="hidden" name="cms_height_' . $fld['id'] . '" id="cms_height_' . $fld['id'] . '" value="' . $height . '">';
	$drawHTML .= '<input type="hidden" name="cms_alt_' . $fld['id'] . '" id="cms_alt_' . $fld['id'] . '" value="' . htmlDisplay($fld['name']) . '">';
	$drawHTML .= '<td width="10%" align="center">';
	$drawHTML .= '<img src="' . RPW . $fld['path'] . "?rnd=" . rand() . '" width="' . $witdhDisp . '" height="' . $heightDisp . '" alt="' . htmlDisplay($fld['name']) . '" border="0">';
	$drawHTML .= '</td>';
	$drawHTML .= '<td width="80%" align="left" style="border-right:solid 1px #FFFFFF;" height="70px">';
	$drawHTML .= '<table class="cms8341-noneBorder">';
	$drawHTML .= '<tr>';
	$drawHTML .= '<td>';
	$drawHTML .= '<div style="border-collapse:collapse;text-align:left;padding:2px 0px 0px 1px;">';
	$drawHTML .= '<div id="cms_image_name_' . $fld['id'] . '">' . htmlDisplay($fld['name']) . '</div>';
	$drawHTML .= '</div>';
	$drawHTML .= '</td>';
	$drawHTML .= '<td rowspan="2" width="30%" align="center" valign="center" style="border-left:solid 1px #FFFFFF;">';
	$drawHTML .= '<div style="border-collapse:collapse;text-align:right;padding:2px 0px 2px 0px;width: 220px;">';
	$drawHTML .= '<a href="' . RPW . $fld['path'] . '" target="_blank"><img src="' . RPW . '/admin/images/btn/btn_preview.jpg" width="100" height="20" alt="プレビュー" border="0"></a>&nbsp;&nbsp;&nbsp;';
	$drawHTML .= '<a href="javascript:void(0)" onclick="cxShowProperty(' . $fld['id'] . '); return false;"><img src="' . RPW . '/admin/master/library/shared_images/images/btn_shared_images_property.jpg" width="100" height="20" alt="画像プロパティ" border="0"></a><br>';
	$drawHTML .= '<a href="javascript:void(0)" onclick="cxChangeImage(' . $fld['id'] . '); return false;"><img src="' . RPW . '/admin/master/library/shared_images/images/btn_shared_images_change.jpg" width="100" height="20"  alt="画像差し替え" border="0"></a>&nbsp;&nbsp;&nbsp;';
	if ($Delete_Flg) $drawHTML .= '<a href="javascript:void(0)" onclick="cxDeleteImage(' . $fld['id'] . ',\'' . javaStringEscape(htmlDisplay($fld['name'])) . '\'); return false;"><img src="' . RPW . '/admin/master/library/shared_images/images/btn_shared_images_del_on.jpg" width="100" height="20" alt="画像削除" border="0"></a>';
	else $drawHTML .= '<img src="' . RPW . '/admin/master/library/shared_images/images/btn_shared_images_del_off.jpg" width="100" height="20" alt="画像削除" border="0">';
	$drawHTML .= '</div>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
	$drawHTML .= '<tr>';
	$drawHTML .= '<td>';
	$drawHTML .= htmlDisplay($fld['path']) . '<br>';
	$drawHTML .= '<div id="cms_image_update_datetime_' . $fld['id'] . '">更新日：' . dtFormat($fld['update_datetime'], "Y年m月d日 H時i分s秒") . '</div>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
	$drawHTML .= '</table>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
}
if ($drawHTML == "") $drawHTML .= '<tr><td><div style="padding:2px 2px 2px 10px;">表示の対象となるファイルはありません。</div></td></tr>';
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>共通画像 一覧</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="shared_images.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script
	src="<?=RPW?>/ckeditor/plugins/gd_image/pages/js/fck_image_list.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/ckeditor/plugins/gd_image/pages/js/com_func.js"
	type="text/javascript"></script>
<script type="text/javascript">
			<!--
				<?php
				echo loadSettingVars();
				?>
			//-->
		</script>
</head>

<body id="cms8341-mainbg">
		<?php
		// ヘッダーメニュー挿入
		$headerMode = 'library';
		include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
		?>
		<div id="cms8341-contents">
<div align="center" id="cms8341-library">
<div><img
	src="<?=RPW?>/admin/master/library/shared_images/images/bar_shared_images_list.jpg"
	alt="共通画像 一覧" width="920" height="30"></div>
<div class="cms8341-area-corner">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle" style="background-image:url(<?=RPW?>/admin/master/library/shared_images/images/bar_topbg.jpg);height:31px;">
		<img
			src="<?=RPW?>/admin/master/library/shared_images/images/bar_search.jpg"
			alt="検索" width="200" height="20" style="margin-left: 10px;"></td>
	</tr>
</table>
<div id="cms8341-search"
	<?=($search_flg == FLAG_ON ? '' : ' style="display:none"')?>>
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<td>
		<table border="0" cellspacing="0" cellpadding="5" align="center"
			width="100%">
			<form name="cms_fck_image_list" id="cms_fck_image_list"
				action="image_list.php" method="post">
			
			
			<tr>
				<th width="30%" align="left" valign="center"><label
					for="cms_fck_image_keyword">キーワード</label></th>
				<td width="70%"><input type="text" name="cms_fck_image_keyword"
					id="cms_fck_image_keyword"
					value="<?=htmlspecialchars($search['keyword'])?>"
					style="width: 270px;"></td>
			</tr>
			<tr>
				<th width="30%" align="left" valign="center"><label
					for="cms_fck_image_update">表示順</label></th>
				<td width="70%">更新日の&nbsp; <input id="upd_asc" type="radio"
					name="cms_fck_image_update_datetime" value="0"
					<?=($search['update_datetime'] == FLAG_OFF ? "checked" : "");?>> <label
					for="upd_asc">降順</label> <input id="upd_dsc" type="radio"
					name="cms_fck_image_update_datetime" value="1"
					<?=($search['update_datetime'] == FLAG_ON ? "checked" : "");?>> <label
					for="upd_dsc">昇順</label></td>
			</tr>
			</form>
		</table>
		</td>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="121" align="center" valign="middle"><a
			href="javascript:void(0)" onClick="return cxSearch()"> <img
			src="<?=RPW?>/admin/images/btn/btn_search.jpg" alt="検索する" width="101"
			height="21" border="0"> </a></td>
	</tr>
</table>
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right" valign="middle" style="background-image:url(<?=RPW?>/admin/master/library/shared_images/images/bar_bottombg.jpg);height:32px;">
		<a href="javascript:void(0)"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			<?=($search_flg == FLAG_ON ? ' src="' . RPW . '/admin/images/btn/btn_close_mini.jpg" alt="閉じる"' : ' src="' . RPW . '/admin/images/btn/btn_open_mini.jpg" alt="開く"')?>
			width="80" height="15" border="0" style="margin-right: 10px;"
			id="cms-searchSwitch"></a></td>
	</tr>
</table>
</div>
<p align="right"><a href="image_form.php"><img
	src="<?=RPW?>/admin/master/library/shared_images/images/btn_shared_images_add.jpg"
	alt="共通画像を追加" width="120" height="20" border="0"></a></p>
<div>
<div
	style="border-collapse: collapse; text-align: left; padding: 10px 2px 10px 2px; align: center">
<img src="<?=RPW?>/admin/images/fckimage/bar_filelist.jpg" width="570"
	height="20" alt="ファイルリスト"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	align="center" class="cms8341-dataTable"
	style="border-collapse: collapse; border: solid 1px #CCCCCC; border-top: none">
						<?=$drawHTML?>
					</table>
<form name="cms_fck_image_select" id="cms_fck_image_select"
	action="<?=RPW?>/ckeditor/plugins/gd_image/pages/fck_image.php" method="post">
<input type="hidden" name="url" id="url" value=""> <input type="hidden"
	name="width" id="width" value=""> <input type="hidden" name="height"
	id="height" value=""> <input type="hidden" name="alt" id="alt" value="">
</form>
</div>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
