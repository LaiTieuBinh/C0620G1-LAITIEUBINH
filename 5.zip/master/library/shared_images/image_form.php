<?php
/*
 *
 */
//外部ファイル読み込み
require_once ("../../.htsetting");

//DBアクセス用ファイルの読み込み
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);

//定数の宣言
define("PREV_WIDTH", 600); //プレビューサイズ


//変数の初期化
$real_base_path = DOCUMENT_ROOT . RPW . FCK_IMAGES_FORDER_SHARED; //フォルダパス(絶対パス)
$image_id = ""; //画像 ID
$image_file_path = ""; //画像 ファイルパス
$image_file_name = ""; //画像 ファイル名称
$image_file_width = 0; //画像 横幅
$image_file_height = 0; //画像 縦幅
$prev_width = 0; //プレビュー表示横幅
$prev_height = 0; //プレビュー表示縦幅


//引数の取得
$image_id = (isset($_POST['cms_image_id']) ? $_POST['cms_image_id'] : "");

//引数のチェック
if ($image_id != "" && !is_numeric($image_id)) $image_id = "";

//画像差し替え
if ($image_id != "") {
	if ($objFCKImages->selectFCKImageID($image_id) === FALSE) user_error("差し替え元の画像が見つかりませんでした。");
	$image_file_path = $objFCKImages->fld['path'];
	$image_file_name = $objFCKImages->fld['name'];
	$size = @getimagesize(DOCUMENT_ROOT . RPW . $image_file_path);
	$image_file_width = $size[0];
	$image_file_height = $size[1];
	$prev_width = $image_file_width;
	$prev_height = $image_file_height;
	if ($prev_width > PREV_WIDTH) {
		$prev_height = round((PREV_WIDTH * $prev_height) / $prev_width);
		$prev_width = PREV_WIDTH;
	}
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex, nofollow" />
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>共通画像 追加</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script
	src="<?=RPW?>/ckeditor/gd_files/js/dialog_common.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/ckeditor/plugins/gd_image/pages/js/com_func.js"
	type="text/javascript"></script>
<script
	src="<?=RPW?>/ckeditor/plugins/gd_image/pages/js/fck_image_upload.js"
	type="text/javascript"></script>
<script type="text/javascript">
			<!--
				var SHARED_FILE_PATH = '<?php
				print(DOCUMENT_ROOT . RPW . FCK_IMAGES_FORDER_SHARED)?>';
				var template_kind = '<?php
				print((isset($_SESSION["use_template_kind"]) ? $_SESSION["use_template_kind"] : ""));
				?>';
				<?php
				echo loadSettingVars();
				?>
			//-->
		</script>
</head>
<body id="cms8341-mainbg">
		<?php
		// ヘッダーメニュー挿入
		$headerMode = 'library';
		include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
		?>
		<div id="cms8341-contents">
<div align="center" id="cms8341-library">
<div><img src="images/bar_shared_images_add01.jpg" alt="共通画像 登録"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" cellspacing="0" cellpadding="0"
	style="background-color: #FFFFFF;">
	<tr>
		<td valign="top">
							<?php
							if ($image_id != "") {
								print('<div align="center">');
								print('<img src="' . RPW . $image_file_path . "?rnd=" . rand() . '" alt="' . $image_file_name . '" border="0" width="' . $prev_width . '" height="' . $prev_height . '">');
								print('</div>');
								print('<div align="center" style="margin-top:10px;">');
								print('<table width="' . PREV_WIDTH . '" border="0" style="margin:0px;padding:0px;border:solid 1px #CCCCCC;">');
								print('<tr align="left">');
								print('<th width="30%" style="padding-left:20px;">画像ファイルパス</th>');
								print('<td width="60%">' . $image_file_path . '</td>');
								print('</tr>');
								print('<tr align="left">');
								print('<th style="padding-left:20px;">画像サイズ</th>');
								print('<td>横幅 ： ' . $image_file_width . 'px<br>縦幅 ： ' . $image_file_height . 'px</td>');
								print('</tr>');
								print('</table>');
								print('<br>');
							}
							?>
							<form name="cms_fck_image_upload" id="cms_fck_image_upload"
			action="image_confirm.php" method="post"
			enctype="multipart/form-data"
			onsubmit="cxSubmit_Upload('<?=$real_base_path?>'); return false;">
								<?php
								if ($image_id == "") $loop_cnt = 5;
								else $loop_cnt = 1;
								for($i = 0; $i < $loop_cnt; $i++) {
									?>
									<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable">
			<tr style="padding: 5px;">
				<th width="150">画像名称<?=($image_id == "" ? ($i + 1) : "")?></th>
				<td><input id="cms_image_name_<?=$i?>" name="cms_image_name_<?=$i?>"
					style="WIDTH: 98%;" type="text" maxlength="64"
					value="<?=(isset($POST['cms_image_name_' . $i]) ? htmlDisplay($POST['cms_image_name_' . $i]) : ($image_id != "" ? $image_file_name : ""))?>">
				</td>
			</tr>
			<tr style="padding: 5px;">
				<th><?=($image_id == "" ? "ファイル" . ($i + 1) : "差し替えファイル")?></th>
				<td><input id="cms_image_path_<?=$i?>" name="cms_image_path_<?=$i?>"
					type="file" style="WIDTH: 98%;"></td>
			</tr>
			<input type="checkbox" name="cms_image_collection_<?=$i?>"
				id="cms_image_collection_<?=$i?>" value="<?=FLAG_ON?>" checked
				style="display: none;">
			<input type="hidden" id="cms_rename_file_path_<?=$i?>"
				name="cms_rename_file_path_<?=$i?>">
			<input type="hidden" id="cms_image_file_name"
				name="cms_image_file_name"
				value="<?=($image_id != "" ? basename($image_file_path) : "")?>">
			<input type="hidden" id="cms_image_id" name="cms_image_id"
				value="<?=$image_id?>">
		</table>
								<?php
								}
								?>
								<br>
		<br>
		<div align="center"><input type="image" name="submit_upload"
			id="submit_upload"
			src="<?=RPW?>/admin/images/fckimage/btn_regist_on.jpg" border="0"
			alt="登録" width="100" height="20"> <a href="image_list.php"><img
			src="<?=RPW?>/admin/images/btn/btn_cansel.jpg" alt="キャンセル"
			width="101" height="21" border="0" style="margin-left: 10px"></a></div>
		</form>
		</td>
	</tr>
</table>
				<?php
				print($objTool->setAccessibility());
				?>
			</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
