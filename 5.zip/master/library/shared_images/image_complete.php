<?php
/*
 *
 */
//外部ファイル読み込み
require_once ("../../.htsetting");

//DBアクセス用ファイルの読み込み
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_shared_upload.inc');
$objShared = new tbl_shared_upload($objCnc);

//変数の初期化
//ファイル名
$file_name_ary = array();
//エラーメッセージ
$err_msg = array();
//ファイル情報
if (isset($_SESSION["FILES"]) && $_SESSION["FILES"] != "") $_FILES = $_SESSION["FILES"];
unset($_SESSION["FILES"]);

//引数の取得
$image_id = (isset($_POST['cms_image_id']) ? $_POST['cms_image_id'] : "");

//引数のチェック
if ($image_id != "" && !is_numeric($image_id)) $image_id = "";

//アップロードファイル数分ループ
foreach ($_FILES as $file_key => $Up_File) {
	//ファイルID
	$i = substr($file_key, -1);
	//ファイル名
	$file_name_ary[$i] = "";
	//エラーメッセージ
	$err_msg[$i] = "";
	
	//ファイルが無ければスキップ
	if ($Up_File['name'] == "") continue;
	
	//ファイルパスの設定
	//差し替えの場合
	if ($image_id != "") {
		//同名で上書き
		$file_name_ary[$i] = $_POST['cms_image_file_name'];
	} //通常の登録
	else {
		//リネームが存在した場合、リネームされたファイル名を使用する
		if (isset($_POST['cms_rename_file_path_' . $i]) && $_POST['cms_rename_file_path_' . $i] != "") $file_name_ary[$i] = strtolower(basename($_POST['cms_rename_file_path_' . $i]));
		else $file_name_ary[$i] = strtolower($Up_File['name']);
	}
	//ファイルパス
	$file_path = FCK_IMAGES_FORDER_SHARED . "/" . $file_name_ary[$i];
	//ファイルパス(絶対パス)
	$real_file_path = DOCUMENT_ROOT . RPW . $file_path;
	$overwrite = FALSE;
	//エラー処理を行うため、whileを使用
	while (true) {
		//差し替えでない場合
		if ($image_id == "") {
			/* 上書きかリネームか選択できるようにしたためコメント化
			//同名ファイルの確認
			if(@file_exists($real_file_path)){
				$err_msg[$i] = "保存先フォルダに同名のファイルが存在します。";
				$real_file_path = "";
			}
			*/
		}
		if(@file_exists($real_file_path)){
			$overwrite = TRUE;
		}
		//エラーがあれば、抜ける
		if ($err_msg[$i] != "") break;
		
		//ファイルエラーチェック
		if ($Up_File["error"] != UPLOAD_ERR_OK) $err_msg[$i] = "ファイルのアップロードに失敗しました。";
		//拡張子チェック
		$File_Exte = explode(",", DENIED_EXTENSIONS_FILE);
		foreach ($File_Exte as $exte) {
			if (preg_match('/(\.' . $exte . ')$/i', $file_name_ary[$i])) $err_msg[$i] = "指定されたファイルはアップロードすることが出来ません。";
		}
		if (isset($_SESSION['use_template_kind']) && $_SESSION['use_template_kind'] == TEMPLATE_KIND_MOBILE) {
			$File_Exte = explode(",", ALLOWED_EXTENSIONS_IMAGE_MOBILE);
			$Image_Max_Size_Width = FCK_MOBILE_UPLOAD_IMAGE_W;
			$Image_Max_Size_Height = FCK_MOBILE_UPLOAD_IMAGE_H;
		}
		else {
			$File_Exte = explode(",", ALLOWED_EXTENSIONS_IMAGE);
			$Image_Max_Size_Width = FCK_UPLOAD_IMAGE_W;
			$Image_Max_Size_Height = FCK_UPLOAD_IMAGE_H;
		}
		//全て小文字に変換
		foreach ($File_Exte as $k => $val) {
			$File_Exte[$k] = strtolower($val);
		}
		//画像の情報取得
		$image_info = @getimagesize($Up_File["tmp_name"]);
		if (!isset($image_info) || isset($image_info) && $image_info == null) {
			$err_msg[$i] = "指定されたファイルはアップロードすることが出来ません。";
			break;
		}
		//拡張子によっての処理
		switch ($image_info[2]) {
			//GIF
			case IMG_GIF :
				if (!in_array("gif", $File_Exte)) $err_msg[$i] = "指定されたファイルはアップロードすることが出来ません。";
				break;
			//PNG
			case 3 :
			case IMG_PNG :
				if (!in_array("png", $File_Exte)) $err_msg[$i] = "指定されたファイルはアップロードすることが出来ません。";
				break;
			//JPG
			case IMG_JPG :
			case IMG_JPEG :
				if (!in_array("jpg", $File_Exte) && !in_array("jpeg", $File_Exte)) $err_msg[$i] = "指定されたファイルはアップロードすることが出来ません。";
				break;
			//その他
			default :
				$err_msg[$i] = "指定されたファイルはアップロードすることが出来ません。";
				break;
		}
		//ファイル名チェック
		//使用不可の記号チェック
		if (preg_match('/[^ \w\-_\.~]/i', $file_name_ary[$i])) $err_msg[$i] = "アップロードできないファイル名です。ファイル名に使用できるのは半角英数字と - _ . ~ です。";
		//「.」が複数含まれているかチェック
		if (strpos($file_name_ary[$i], '.') != strrpos($file_name_ary[$i], '.')) $err_msg[$i] = "ファイル名に「.」が二つ以上ついているファイルはアップロードすることが出来ません。";
		//「.」がファイル名の先頭に含まれているかチェック
		if (strpos($file_name_ary[$i], '.') == 0) $err_msg[$i] = "ファイル名にの先頭に「.」がついているファイルはアップロードすることが出来ません。";
		//ファイルサイズチェック
		//0byte以下のファイルチェック
		if ($Up_File["size"] <= 0) $err_msg[$i] = "ファイルサイズが0バイトのファイルは取り込めません。";
		//ファイルMAXサイズチェック
		if (is_none_check_dir($real_file_path) === FALSE && $Up_File["size"] > FCK_UPLOAD_MAX_IMAGE * 1024) $err_msg[$i] = "画像ファイルの容量が大き過ぎます。";
		//エラーがあれば、抜ける
		if ($err_msg[$i] != "") break;
		
		//ファイルの移動処理
		//フォルダが存在しなければ、フォルダを作成
		if (!is_dir(cms_dirname($real_file_path))) {
			if (!@mkNewDirectory($real_file_path)) $err_msg[$i] = "ファイルのアップロードに失敗しました。";
		}
		//エラーがあれば、抜ける
		if ($err_msg[$i] != "") break;
		
		//ファイルの移動
		if (@copy($Up_File["tmp_name"], ($real_file_path))) chmod($real_file_path, 0777);
		else $err_msg[$i] = "ファイルのアップロードに失敗しました。";
		//ファイルリサイズ
		if (!mkThumbnail($real_file_path, $Image_Max_Size_Width, $Image_Max_Size_Height)) $err_msg[$i] = "ファイルのアップロードに失敗しました。";
		//エラーがあれば、抜ける
		if ($err_msg[$i] != "") break;
		
		//登録処理
		$Up_File_Info = pathinfo($real_file_path);
		//登録用配列の設定
		$filedtl_ary = array();
		if ($image_id != "") {
			$filedtl_ary["id"] = $image_id; //画像ID
			$filedtl_ary["update_datetime"] = "NOW"; //更新時間
		}
		$filedtl_ary["name"] = $_POST['cms_image_name_' . $i]; //画像名称
		$filedtl_ary["path"] = $file_path; //ファイルパス
		//登録処理
		$objCnc->begin();
		//差し替えでない場合
		if ($image_id == "") {
			//「tbl_fck_images」に同じパスが存在する場合、削除する
			if ($objFCKImages->selectFCKImage($file_path)) {
				if (!$objFCKImages->deleteFromImagePath($file_path)) $err_msg[$i] = "データベースの更新に失敗しました。";
			}
			//「tbl_fck_images」にアップロードした画像情報の登録
			if (!$objFCKImages->insert($filedtl_ary)) $err_msg[$i] = "データベースへの登録に失敗しました。";
		}
		else {
			//「tbl_fck_images」にアップロードした画像情報の登録
			if (!$objFCKImages->update($filedtl_ary)) $err_msg[$i] = "データベースの更新に失敗しました。";
		}
		if ($err_msg[$i] == "") {
			$upload_class = ($overwrite) ? $objShared::SHARED_OVERWRITE : $objShared::SHARED_NEW;
			$err_msg[$i] = $objShared->add_data($file_path, $upload_class);
		}
		//エラーが無ければ、登録する
		if ($err_msg[$i] == "") $objCnc->commit();
		//エラーがあれば、元に戻す
		else $objCnc->rollback();
		break;
	}
}
//一時フォルダを削除する
if (@file_exists(DOCUMENT_ROOT . DIR_PATH_TEMP . $objLogin->get('user_id') . '/')) removeDir(DOCUMENT_ROOT . DIR_PATH_TEMP . $objLogin->get('user_id') . '/');
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex, nofollow" />
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>共通画像 追加完了</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>
<body id="cms8341-mainbg">
		<?php
		// ヘッダーメニュー挿入
		$headerMode = 'library';
		include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
		?>
		<div id="cms8341-contents">
<div align="center" id="cms8341-library">
<div><img src="images/bar_shared_images_add03.jpg" alt="共通画像 登録完了"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" cellspacing="0" cellpadding="0"
	style="background-color: #FFFFFF;">
	<tr>
		<td valign="top">
							<?php
							if (count($file_name_ary) == 0) {
								?>
								<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable">
			<tr style="padding: 5px;">
				<td>登録された画像はありません。</td>
			</tr>
		</table>
							<?php
							}
							else {
								if ($image_id == "") $loop_cnt = 5;
								else $loop_cnt = 1;
								for($i = 0; $i < $loop_cnt; $i++) {
									if (!isset($file_name_ary[$i]) || $file_name_ary[$i] == "") continue;
									?>
								<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable" style="margin-top: 5px;">
			<tr style="padding: 5px;">
				<th width="150">画像名称<?=($image_id == "" ? ($i + 1) : "")?></th>
				<td>
											<?=(isset($_POST["cms_image_name_" . $i]) && $_POST["cms_image_name_" . $i] != "" ? htmlDisplay($_POST["cms_image_name_" . $i]) : "")?>
										</td>
			</tr>
			<tr style="padding: 5px;">
				<th><?=($image_id == "" ? "ファイル" . ($i + 1) : "差し替えファイル")?></th>
				<td>
											<?php
									if (isset($err_msg[$i]) && $err_msg[$i] != "") print($err_msg[$i]);
									else print('登録が完了しました。');
									?>
										</td>
			</tr>
		</table>
							<?php
								}
							}
							?>
						</td>
	</tr>
</table>
<p align="center"><a href="image_list.php"><img
	src="images/btn_shared_images_list.jpg" alt="共通画像 一覧へ" width="120"
	height="20" border="0" style="margin-right: 10px"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
