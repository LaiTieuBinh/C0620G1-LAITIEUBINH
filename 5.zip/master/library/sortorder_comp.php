<?php
/*
 * ライブラリ管理　表示順序更新処理(sortorder_comp.php)
 */
$StrDbg = "";
$GLOBALS["StrDbg"] = "";

/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

if (!isset($_POST['parmission']) || !isset($_POST['area'])) {
	DispError("パラメータ取得エラー(parmission or area)", 6, "javascript:history.back()");
	exit();
}

/*---引数の取得---*/
$args = ($_SERVER['REQUEST_METHOD'] == 'GET') ? $_GET : $_POST;
//処理モード
/*--- データアクセスクラス ---*/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

//---画面項目の取得とチェック
$ArrItem = array();
if (entryChkItem($objDac, $args, $ArrItem, $ErrMsg) == FALSE) {
	//Err
	DispError($ErrMsg, 6, "javascript:history.back()");
	exit();
}

//---ソートの更新
// トランザクション開始
$objCnc->begin();
foreach ($ArrItem as $key => $order) {
	//ライブラリテーブルの存在チェック
	if (FALSE == isLibraryDate($objDac, $key)) {
		//ロールバック
		$objCnc->rollback();
		DispError("存在しないテンプレートの表示順が指定されました。", 6, "javascript:history.back()");
		exit();
	}
	//更新
	updateLibraryDate($objDac, $key, $order);
}

// コミット
$objCnc->commit();

/*---一覧画面へと戻る---*/
header("Location: " . "./index.php?area=" . $_SESSION['use_library_area']);

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	ライブラリテーブルの更新

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateID		更新をするカテゴリID
		$i_SortOrder	更新するカテゴリのソート順
		
【戻値】	なし
		
【備考】
-----------------------------------------------------------------------------*/
function updateLibraryDate($i_objDac, $i_CateID, $i_SortOrder) {
	
	$sql = "UPDATE tbl_library SET  sort_order = '" . $i_SortOrder . "' WHERE( library_id = " . $i_CateID . " )";
	//実行
	$i_objDac->execute(mb_convert_encoding($sql, "utf-8", "auto"));

}
/*-----------------------------------------------------------------------------
	指定されたライブラリＩＤからライブラリデータを取得する

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_GetCateID	取得するカテゴリID
		
【戻値】	TRUE	データが取得できた
		FALSE	データが取得できなかった
		
【備考】
-----------------------------------------------------------------------------*/
function isLibraryDate($i_objDac, $library_id) {
	
	$ret = FALSE;
	
	$sql = "SELECT library_id FROM tbl_library " . "WHERE library_id = '" . gd_addslashes($library_id) . "'";
	$i_objDac->execute($sql);
	
	if ($i_objDac->getRowCount() > 0) {
		$ret = TRUE;
	}
	
	return ($ret);
}

/*-----------------------------------------------------------------------------
	入力項目の取得とチェック

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateLevel	指定されたカテゴリレベル
		$i_CateCode		指定されたカテゴリコード
		$i_Args			画面から取得された値
		$o_ArrItem		画面項目の格納先
		$o_ErrMsg		エラーメッセージ
		
【戻値】	FALSE	エラーが存在した
		TRUE	エラーなし
		
【備考】
-----------------------------------------------------------------------------*/
function entryChkItem($i_objDac, $i_Args, &$o_ArrItem, &$o_ErrMsg) {
	
	//---SQL部品の作成
	$sql = "SELECT distinct library_id FROM tbl_library WHERE user_parmission='" . $_POST['parmission'] . "' AND area='" . $_POST['area'] . "' order by sort_order";
	//---取得
	$i_objDac->execute($sql);
	
	//---画面項目との連携
	while ($i_objDac->fetch()) {
		//存在する項目のみをチェックする（この処理中に追加、削除された項目は無効
		if (isset($i_Args[$i_objDac->fld['library_id']]) == TRUE) {
			//項目確保
			$sort_order = $i_Args[$i_objDac->fld['library_id']];
			//未入力		
			if (strlen($sort_order) <= 0) {
				$o_ErrMsg = "表示順序の省略はできません。";
				return FALSE;
			}
			//半角数値チェック
			if (!(preg_match("/^[0-9]+$/", $sort_order))) {
				$o_ErrMsg = "表示順序は半角数値のみ有効です。";
				return FALSE;
			}
			//配列にセット
			$o_ArrItem[$i_objDac->fld['library_id']] = $sort_order;
		
		}
	}
	
	return TRUE;

}

?>
