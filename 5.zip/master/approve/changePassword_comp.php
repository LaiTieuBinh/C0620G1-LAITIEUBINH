<?php
/*
 *
 */
/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

if (!isset($_POST['cms_invalid']) || !isset($_POST['cms_password'])) {
	DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
	exit();
}
/*--- データアクセスクラス ---*/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

// トランザクション開始
$objCnc->begin();

$sql = "UPDATE tbl_represent SET ";
$sql .= " invalid_flg = '" . $_POST['cms_invalid'] . "' ";
if ($_POST['cms_invalid'] == FLAG_OFF && $_POST['cms_password'] != "") {
	$sql .= " ,password = '" . gd_addslashes($_POST['cms_password']) . "' ";
}
$objDac->execute($sql);
// コミット
$objCnc->commit();

/*---一覧画面へと戻る---*/
header("Location: " . "./index.php");

?>
