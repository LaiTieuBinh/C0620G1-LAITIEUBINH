<?php
/*
 *
 */
/** require **/
require ("./.htsetting");

/** init **/
$dat = array();
/** get post data **/
$bv = $_POST["behavior"];
$app_id = $_SESSION["hidden"]["app_id"];
$app_name = $_SESSION["hidden"]["app_name"];
$app01 = $_SESSION["hidden"]["app01"];
$app02 = $_SESSION["hidden"]["app02"];
$app03 = $_SESSION["hidden"]["app03"];
if (isset($_SESSION["hidden"]["open_id"]) == false || $_SESSION["hidden"]["open_id"] == "") {
	$app04 = $_SESSION["hidden"]["app04"];
}
else {
	$app04 = $_SESSION["hidden"]["open_id"];
}

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

switch ($bv) {
	case 1 :
		require ("./include/insert.inc");
		break;
	case 2 :
		require ("./include/update.inc");
		break;
	case 3 :
		require ("./include/delete.inc");
		break;
	default :
		DispError("パラメータ取得エラー（behavior）", 4, "javascript:history.back()");
		exit();
		break;
}
?>