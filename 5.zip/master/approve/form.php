<?php
/*
 *
 */
/** require **/
require ("./.htsetting");

/** init **/
$dat = array();

//function 
function getOption($cd) {
	$fmt = '<option value="0"{opt0}>承認なし</option>' . '<option value="appr1"{opt1}>所属第1承認者</option>' . '<option value="appr2"{opt2}>所属第2承認者</option>' . '<option value="appr3"{opt3}>所属第3承認者</option>' . '<option value="1"{opt4}>その他承認者</option>';
	//
	$ary = array();
	if ($cd == "" || !isset($cd)) {
		$ret = str_replace('{opt0}', ' selected', $fmt);
		$ret = str_replace('{opt1}', '', $ret);
		$ret = str_replace('{opt2}', '', $ret);
		$ret = str_replace('{opt3}', '', $ret);
		$ret = str_replace('{opt4}', '', $ret);
		$ary["opt"] = $ret;
		$ary["cod"] = "";
		return $ary;
	}
	elseif (preg_match('/appr/', $cd)) {
		$ap = str_replace('appr', '', $cd);
		switch ($ap) {
			case "1" :
				$ret = str_replace('{opt0}', '', $fmt);
				$ret = str_replace('{opt1}', ' selected', $ret);
				$ret = str_replace('{opt2}', '', $ret);
				$ret = str_replace('{opt3}', '', $ret);
				$ret = str_replace('{opt4}', '', $ret);
				$ary["opt"] = $ret;
				$ary["cod"] = "";
				return $ary;
			case "2" :
				$ret = str_replace('{opt0}', '', $fmt);
				$ret = str_replace('{opt1}', '', $ret);
				$ret = str_replace('{opt2}', ' selected', $ret);
				$ret = str_replace('{opt3}', '', $ret);
				$ret = str_replace('{opt4}', '', $ret);
				$ary["opt"] = $ret;
				$ary["cod"] = "";
				return $ary;
			case "3" :
				$ret = str_replace('{opt0}', '', $fmt);
				$ret = str_replace('{opt1}', '', $ret);
				$ret = str_replace('{opt2}', '', $ret);
				$ret = str_replace('{opt3}', ' selected', $ret);
				$ret = str_replace('{opt4}', '', $ret);
				$ary["opt"] = $ret;
				$ary["cod"] = "";
				return $ary;
			default :
				DispError("承認コードエラー（" . $cd . ")", 4, "javascript:history.back()");
				exit();
				break;
		}
	}
	else {
		$ret = str_replace('{opt0}', '', $fmt);
		$ret = str_replace('{opt1}', '', $ret);
		$ret = str_replace('{opt2}', '', $ret);
		$ret = str_replace('{opt3}', '', $ret);
		$ret = str_replace('{opt4}', ' selected', $ret);
		$ary["opt"] = $ret;
		$ary["cod"] = $cd;
		return $ary;
	}
	return;
}
//
function getOptionSet($ary) {
	$opt[0] = getOption($ary["app01"]);
	$opt[1] = getOption($ary["app02"]);
	$opt[2] = getOption($ary["app03"]);
	if (!isset($ary["app04"]) || $ary["app04"] == "") {
		$opt[3][0] = " checked";
		$opt[3][1] = "";
		$opt[4] = "";
	}
	else {
		//第4承認がウェブマスターの場合
		if ($ary["app04"] == WEB_MASTER_CODE) {
			$opt[3][0] = "";
			$opt[3][1] = " checked";
			$opt[4] = "";
		}
		else {
			$opt[3][0] = " checked";
			$opt[3][1] = "";
			$opt[4] = $ary["app04"];
		}
	}
	return $opt;
}

//main
if (isset($_POST["behavior"])) {
	$bv = $_POST["behavior"];
}
elseif (isset($_GET["behavior"])) {
	$bv = $_GET["behavior"];
}
else {
	DispError("パラメータ取得エラー(behavior)", 4, "javascript:history.back()");
	exit();
}
switch ($bv) {
	case 1 :
		$label = '承認フロー追加';
		$image = '<img src="images/bar_add.jpg" alt="承認フロー追加" width="920" height="30">';
		$dat = array(
				"app_id" => "", 
				"app_name" => "", 
				"app01" => "", 
				"app02" => "", 
				"app03" => "", 
				"app04" => ""
		);
		$opt = getOptionSet($dat);
		break;
	case 2 :
		if (isset($_POST["app_id"])) {
			$id = $_POST["app_id"];
		}
		else {
			DispError("パラメータ取得エラー(app_id)", 4, "javascript:history.back()");
			exit();
		}
		$label = '承認フロー修正';
		$image = '<img src="images/bar_fix.jpg" alt="承認フロー修正" width="920" height="30">';
		require ("./include/getRecord.inc");
		$dat = getRecord($id);
		$opt = getOptionSet($dat);
		//
		break;
	default :
		DispError("パラメータエラー（behavior）", 4, "javascript:history.back()");
		exit();
		break;
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$label?></title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="approve.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxSubmit() {
	if($F('app01') == 0 && ($F('app02') != 0 || $F('app03') != 0) ){
		alert("第1承認者を指定してください");
		return false;
	}
	if($F('app02') == 0 && $F('app03') != 0){
		alert("第2承認者を指定してください");
		return false;
	}
	$('app_form').submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'approve';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-approve">
<div><?=$image?></div>
<div class="cms8341-area-corner">
<form id="app_form" class="cms8341-form" name="app_form" method="post"
	action="confirm.php">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="150" align="left" valign="top" scope="row">承認フロー名 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><input id="app_name" name="app_name"
			type="text" style="width: 540px"
			value="<?=htmlspecialchars($dat["app_name"])?>"></td>
	</tr>
</table>
<p>組織コードを指定した場合は、指定された組織の承認者へ承認依頼が行われます。</p>
<p>また、公開責任者のユーザーIDを指定した場合は、ウェブマスターは「承認なし」となります。</p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="150" align="left" valign="middle" scope="row">第1承認者 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><select id="app01" name="app01">
<?=$opt[0]["opt"]?>
</select> 組織コード<input id="app01_code" name="app01_code" type="text"
			style="width: 200px" value="<?=$opt[0]["cod"]?>" class="no-ime"></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">第2承認者 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><select id="app02" name="app02">
<?=$opt[1]["opt"]?>
</select> 組織コード<input id="app02_code" name="app02_code" type="text"
			style="width: 200px" value="<?=$opt[1]["cod"]?>" class="no-ime"></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">第3承認者 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><select id="app03" name="app03">
<?=$opt[2]["opt"]?>
</select> 組織コード<input id="app03_code" name="app03_code" type="text"
			style="width: 200px" value="<?=$opt[2]["cod"]?>" class="no-ime"></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">公開責任者</th>
		<td align="left" valign="top">ユーザーID<input id="open_id" name="open_id"
			type="text" style="width: 200px" value="<?=$opt[4]?>" class="no-ime"></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">ウェブマスター <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><input name="app04" type="radio"
			id="app04_01" <?=$opt[3][0]?> value="0"><label for="app04_01">承認なし</label>
		<input type="radio" id="app04_02" name="app04" <?=$opt[3][1]?>
			value="1"><label for="app04_02">承認あり</label></td>
	</tr>
</table>
<p align="center"><a href="javascript:" onclick="return cxSubmit()"><img
	src="../images/btn_conf.jpg" alt="確認" width="150" height="20"
	border="0" style="margin-right: 10px"></a><a href="index.php"><img
	src="../../images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150"
	height="20" border="0" style="margin-left: 10px"></a></p>
<input type="hidden" name="app_id" value="<?=$dat["app_id"]?>"> <input
	type="hidden" name="behavior" value="<?=$bv?>"></form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
