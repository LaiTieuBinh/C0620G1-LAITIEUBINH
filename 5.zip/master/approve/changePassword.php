<?php
/*
 *
 */
/** require **/
require ("./.htsetting");

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
//createList
$html = '';
$objDac->setTableName("tbl_represent");
$objDac->select();
$cnt = $objDac->getRowCount();
if ($cnt != 1) {
	//		エラー
}
$display = "";
$objDac->fetch();
$fld = $objDac->fld;
if ($fld['invalid_flg'] == FLAG_ON) {
	$rep_radio_str = '<input type="radio" id="cms_rep_radio1" name="cms_rep_radio" onclick="cxChange(this.id)" onChange="cxChange(this.id)"><label for="cms_rep_radio1">有効にする</label>' . "\n";
	$rep_radio_str .= '<input type="radio" id="cms_rep_radio2" name="cms_rep_radio" onclick="cxChange(this.id)" onChange="cxChange(this.id)" checked><label for="cms_rep_radio2">無効にする</label>' . "\n";
	$display = ' style="display:none" ';
}
else {
	$rep_radio_str = '<input type="radio" id="cms_rep_radio1" name="cms_rep_radio" onclick="cxChange(this.id)" onChange="cxChange(this.id)" checked><label for="cms_rep_radio1">有効にする</label>' . "\n";
	$rep_radio_str .= '<input type="radio" id="cms_rep_radio2" name="cms_rep_radio" onclick="cxChange(this.id)" onChange="cxChange(this.id)"><label for="cms_rep_radio2">無効にする</label>' . "\n";
}

$pass_radio_str = '<input type="radio" id="cms_pass_radio1" name="cms_pass_radio" onclick="cxChange(this.id)" onChange="cxChange(this.id)"><label for="cms_pass_radio1">変更する</label>' . "\n";
$pass_radio_str .= '<input type="radio" id="cms_pass_radio2" name="cms_pass_radio" onclick="cxChange(this.id)" onChange="cxChange(this.id)" checked><label for="cms_pass_radio2">変更しない</label>' . "\n";
$password = $fld['password'];
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>代理承認設定</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="approve.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<?php
$ary_symbol = getDefineArray("PASSWORD_ALLOWED_SYMBOL");
while ($symbol = current($ary_symbol)) {
	if ($symbol == '\\') {
		$ary_symbol[key($ary_symbol)] = '\\\\';
	}
	next($ary_symbol);
}
$PASSWORD_ALLOWED_SYMBOL = implode(", ", $ary_symbol);
// 使用を許可する英字大文字（配列）取得
$PASSWORD_ALLOWED_UPPERCASE = getDefineArray('PASSWORD_ALLOWED_UPPERCASE');
$PASSWORD_ALLOWED_UPPERCASE = implode(",", $PASSWORD_ALLOWED_UPPERCASE);
// 使用を許可する英字小文字（配列）取得
$PASSWORD_ALLOWED_LOWERCASE = getDefineArray('PASSWORD_ALLOWED_LOWERCASE');
$PASSWORD_ALLOWED_LOWERCASE = implode(",", $PASSWORD_ALLOWED_LOWERCASE);
// 使用を許可する数字（配列）取得
$PASSWORD_ALLOWED_NUMBER = getDefineArray('PASSWORD_ALLOWED_NUMBER');
$PASSWORD_ALLOWED_NUMBER = implode(",", $PASSWORD_ALLOWED_NUMBER);
?>
var PASSWORD_ALLOWED_SYMBOL = '<?php echo str_replace("'", "\'", $PASSWORD_ALLOWED_SYMBOL); ?>';
var PASSWORD_MINIMUM_LENGTH = '<?php echo PASSWORD_MINIMUM_LENGTH ?>';
var PASSWORD_MULTI_TYPE_NUM = '<?php echo PASSWORD_MULTI_TYPE_NUM ?>';
var PASSWORD_ALLOWED_UPPERCASE = '<?php echo str_replace("'", "\'", $PASSWORD_ALLOWED_UPPERCASE); ?>';
var PASSWORD_ALLOWED_LOWERCASE = '<?php echo str_replace("'", "\'", $PASSWORD_ALLOWED_LOWERCASE); ?>';
var PASSWORD_ALLOWED_NUMBER = '<?php echo str_replace("'", "\'", $PASSWORD_ALLOWED_NUMBER); ?>';
<!--
// 決定処理
function cxSubmit() {
if($('cms_rep_radio1').checked && $('cms_pass_radio1').checked){
	if($F('cms_password1') == ""){
		alert("新規パスワードを入力してください。");
		$('cms_password1').focus();
		return false;
	}
	if(!cxCheckMachineCode($F('cms_password1'))){
		alert("新規パスワードは機種依存文字を含んでいるため変更できません。");
		$('cms_password1').focus();
		return false;
	}
	if(!($F('cms_password1').match('^[a-zA-Z0-9\\' + PASSWORD_ALLOWED_SYMBOL.split(', ').join('\\') + ']+$'))) {
		alert("新パスワードは文字と数字と許可されている特殊文字のみで入力してくだい。");
		$('cms_password1').focus();
		return false;
	}
	if ($F('cms_password1').length < PASSWORD_MINIMUM_LENGTH) {
		alert('新規パスワードは' + PASSWORD_MINIMUM_LENGTH + '文字以上で指定してください。');
		$('cms_password1').focus();
		return false;
	}
	if (PASSWORD_MULTI_TYPE_NUM > 0) {
		var message_ary = Array();
		// 使用文字種カウントアップ変数初期化
		var use_multi_type_cnt = 0;
		// 英字大文字使用チェック
		if (PASSWORD_ALLOWED_UPPERCASE.length > 0) {
			message_ary.push('半角英字大文字');
			if ($F('cms_password1').match(new RegExp(PASSWORD_ALLOWED_UPPERCASE.split(',').join('|')))) {
				use_multi_type_cnt++;
			}
		}
		// 英字小文字使用チェック
		if (PASSWORD_ALLOWED_LOWERCASE.length > 0) {
			message_ary.push('半角英字小文字');
			if ($F('cms_password1').match(new RegExp(PASSWORD_ALLOWED_LOWERCASE.split(',').join('|')))) {
				use_multi_type_cnt++;
			}
		}
		// 数字使用チェック
		if (PASSWORD_ALLOWED_NUMBER.length > 0) {
			message_ary.push('半角数字');
			if ($F('cms_password1').match(new RegExp(PASSWORD_ALLOWED_NUMBER.split(',').join('|')))) {
				use_multi_type_cnt++;
			}
		}
		// 記号使用チェック
		if (PASSWORD_ALLOWED_SYMBOL.length > 0) {
			message_ary.push('記号【' + PASSWORD_ALLOWED_SYMBOL + '】');
			if ($F('cms_password1').match(new RegExp('\\' + PASSWORD_ALLOWED_SYMBOL.split(', ').join('|\\')))) {
				use_multi_type_cnt++;
			}
		}
		if (use_multi_type_cnt < PASSWORD_MULTI_TYPE_NUM) {
			let message = '';
			for(let i = 1; i <= message_ary.length; i++) {
				message += i + '. ' + message_ary[i-1] + '\n';
			}
			alert('新規パスワードは' + PASSWORD_MULTI_TYPE_NUM + '種類以上の文字を組み合わせて指定してください。\n' + message);
			return false;
		}
	}
	$('cms_password').value = $F('cms_password1');
}
if($('cms_rep_radio1').checked){
	$('cms_invalid').value = 0;
} else {
	$('cms_invalid').value = 1;
}
$('chpwd_form').submit();
return false;
}
// 項目　表示／非表示
function cxChange(id){
if(id == "cms_rep_radio2"){
	Element.hide($('cms_pwd_tr'),$('cms_now_pwd_tr'),$('cms_en_pwd_tr'));
}
if(id == "cms_rep_radio1"){
	Element.show($('cms_pwd_tr'),$('cms_now_pwd_tr'));
	$('cms_pass_radio2').checked = true;
}
if(id == "cms_pass_radio1"){
	Element.show($('cms_en_pwd_tr'));
}
if(id == "cms_pass_radio2"){
	Element.hide($('cms_en_pwd_tr'));
}
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'approve';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-approve">
<div><img src="images/bar_agentset.jpg" alt="代理承認設定" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr id="invalid_tr">
		<th width="150" align="left" valign="middle" scope="col">代理承認機能</th>
		<td>
<?=$rep_radio_str?>
</td>
	</tr>
	<tr id="cms_now_pwd_tr" <?=$display?>>
		<th width="150" align="left" valign="middle" scope="col">現在のパスワード</th>
		<td><?=$password?></td>
	</tr>
	<tr id="cms_pwd_tr" <?=$display?>>
		<th width="150" align="left" valign="middle" scope="col">パスワード</th>
		<td>
<?=$pass_radio_str?>
</td>
	</tr>
	<tr id="cms_en_pwd_tr" style="display: none">
		<th width="150" align="left" valign="middle" scope="col">新規パスワード</th>
		<td><input type="text" id="cms_password1" name="cms_password1"
			value=""></td>
	</tr>
</table>
<p align="center"><a href="javascript:" onclick="return cxSubmit()"><img
	src="../images/btn_fix.jpg" alt="修正" width="150" height="20" border="0"
	style="margin-right: 10px"></a> <a href="javascript:history.back()"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px"></a></p>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<form id="chpwd_form" class="cms8341-form" name="chpwd_form"
	action="changePassword_comp.php" method="post"><input type="hidden"
	id="cms_password" name="cms_password" value=""> <input type="hidden"
	id="cms_invalid" name="cms_invalid" value=""></form>
</body>
</html>
