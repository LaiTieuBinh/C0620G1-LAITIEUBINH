<?php
/*
 *
 */
/** require **/
require ("./.htsetting");

require ("./include/getUserName.inc");

/** init **/
$dat = array();
unset($_SESSION["hidden"]);

/** function **/
function isDept($cd) {
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
	$objDac = new dac($objCnc);
	$sql = "SELECT dept_name FROM tbl_department WHERE dept_code='" . gd_addslashes($cd) . "'";
	$objDac->execute($sql);
	$cnt = $objDac->getRowCount();
	$objDac->fetch();
	if ($cnt == 1) {
		$label = $objDac->fld["dept_name"];
		return $label;
	}
	return FALSE;
}
//
function getLabel($cd) {
	if (preg_match('/appr/', $cd)) {
		$ap = str_replace('appr', '', $cd);
		switch ($ap) {
			case "1" :
				return "所属第1承認者";
			case "2" :
				return "所属第2承認者";
			case "3" :
				return "所属第3承認者";
			default :
				DispError("承認コードエラー（" . $cd . ")", 4, "javascript:history.back()");
				exit();
				break;
		}
	}
	return false;
}
//
function getPostData() {
	$dat = array();
	if (isset($_POST["app_id"])) $dat["app_id"] = $_POST["app_id"];
	if (isset($_POST["app_name"])) $dat["app_name"] = $_POST["app_name"];
	if (isset($_POST["app01"])) $dat["app01"] = $_POST["app01"];
	if (isset($_POST["app01_code"])) $dat["app01_code"] = $_POST["app01_code"];
	if (isset($_POST["app02"])) $dat["app02"] = $_POST["app02"];
	if (isset($_POST["app02_code"])) $dat["app02_code"] = $_POST["app02_code"];
	if (isset($_POST["app03"])) $dat["app03"] = $_POST["app03"];
	if (isset($_POST["app03_code"])) $dat["app03_code"] = $_POST["app03_code"];
	//--- 2006-11-09 Y.Adachi Add Start
	if (isset($_POST["open_id"])) $dat["open_id"] = $_POST["open_id"];
	//--- 2006-11-09 Y.Adachi Add End
	if (isset($_POST["app04"])) $dat["app04"] = $_POST["app04"];
	//
	$msg = "";
	if (!isset($dat["app_name"]) || $dat["app_name"] == "") {
		$msg .= "承認フロー名が入力されていません。<br>";
	}
	elseif (!checkMachineCode($dat["app_name"])) {
		$msg .= "承認フロー名に機種依存文字が使用されています。<br>";
	}
	if (!isset($dat["app01"]) || $dat["app01"] == "") {
		$msg .= "第1承認者が選択されていません。<br>";
	}
	if (!isset($dat["app02"]) || $dat["app02"] == "") {
		$msg .= "第2承認者が選択されていません。<br>";
	}
	if (!isset($dat["app03"]) || $dat["app03"] == "") {
		$msg .= "第3承認者が選択されていません。<br>";
	}
	if (!isset($dat["app04"]) || $dat["app04"] == "") {
		$msg .= "ウェブマスターが選択されていません。<br>";
	}
	//
	if ($dat["app01"] == "0") {
		$dat["app01_label"] = "承認なし";
	}
	elseif ($dat["app01"] == "1") {
		if (!isset($dat["app01_code"]) || $dat["app01_code"] == "") {
			$msg .= "第1承認者の組織コードが入力されていません。<br>";
		}
		else {
			$isApp01 = isDept($dat["app01_code"]);
			if ($isApp01) {
				$dat["app01"] = $dat["app01_code"];
				$dat["app01_label"] = $isApp01;
			}
			else {
				$msg .= "第1承認者に指定された組織コードに誤りがあります（" . $dat["app01_code"] . "）。<br>";
			}
		}
	}
	else {
		$dat["app01_label"] = getLabel($dat["app01"]);
	}
	if ($dat["app02"] == "0") {
		$dat["app02_label"] = "承認なし";
	}
	elseif ($dat["app02"] == "1") {
		if (!isset($dat["app02_code"]) || $dat["app02_code"] == "") {
			$msg .= "第2承認者の組織コードが入力されていません。<br>";
		}
		else {
			$isApp02 = isDept($dat["app02_code"]);
			if ($isApp02) {
				$dat["app02"] = $dat["app02_code"];
				$dat["app02_label"] = $isApp02;
			}
			else {
				$msg .= "第2承認者に指定された組織コードに誤りがあります（" . $dat["app02_code"] . "）。<br>";
			}
		}
	}
	else {
		$dat["app02_label"] = getLabel($dat["app02"]);
	}
	if ($dat["app03"] == "0") {
		$dat["app03_label"] = "承認なし";
	}
	elseif ($dat["app03"] == "1") {
		if (!isset($dat["app03_code"]) || $dat["app03_code"] == "") {
			$msg .= "第3承認者の組織コードが入力されていません。<br>";
		}
		else {
			$isApp03 = isDept($dat["app03_code"]);
			if ($isApp03) {
				$dat["app03"] = $dat["app03_code"];
				$dat["app03_label"] = $isApp03;
			}
			else {
				$msg .= "第3承認者に指定された組織コードに誤りがあります（" . $dat["app03_code"] . "）。<br>";
			}
		}
	}
	else {
		$dat["app03_label"] = getLabel($dat["app03"]);
	}
	//--- 2006-11-09 Y.Adachi Add Start
	if (isset($dat["open_id"]) == True && trim($dat["open_id"]) != "") {
		$dat["open_id_label"] = getUserName($dat["open_id"]);
	}
	else {
		$dat["open_id"] = "";
		$dat["open_id_label"] = "";
	}
	//--- 2006-11-09 Y.Adachi Add End
	//--- 2006-11-09 Y.Adachi Upd Start
	//		if($dat["app04"]=="1") {
	if ($dat["app04"] == "1" && (isset($dat["open_id"]) == False || trim($dat["open_id"]) == "")) {
		//--- 2006-11-09 Y.Adachi Upd End
		$digit = CODE_DIGIT_DEPT * 3;
		$dat["app04"] = "";
		for($i = 0; $i < $digit; $i++) {
			$dat["app04"] .= "0";
		}
		$dat["app04_label"] = "承認あり";
	}
	else {
		$dat["app04"] = "0";
		$dat["app04_label"] = "承認なし";
	}
	//
	//--- 2006-11-09 Y.Adachi Upd Start
	//		if($dat["app01"]=="0" && $dat["app02"]=="0" && $dat["app03"]=="0" && $dat["app04"]==="0") {
	if ($dat["app01"] == "0" && $dat["app02"] == "0" && $dat["app03"] == "0" && $dat["open_id"] == "" && $dat["app04"] === "0") {
		//--- 2006-11-09 Y.Adachi Upd End
		$msg .= "ひとつの承認も設定されていません。<br>";
	}
	//
	if ($msg != "") {
		DispError($msg, 4, "javascript:history.back()");
		exit();
	}
	return $dat;
}

/** get post date **/
if (isset($_POST["behavior"])) {
	$bv = $_POST["behavior"];
}
else {
	DispError("パラメータ取得エラー(behavior)", 4, "javascript:history.back()");
	exit();
}
switch ($bv) {
	case 1 :
		$msg = '<p>この情報で登録してもよろしいですか？</p>';
		$back = 'javascript:history.back()';
		$image = '<input type="image" src="../images/btn_add.jpg" alt="追加" width="150" height="20" border="0" style="margin-right:10px">';
		$dat = getPostData();
		$_SESSION["hidden"] = $dat;
		break;
	case 2 :
		$msg = '<p>この情報で登録してもよろしいですか？</p>';
		$back = 'javascript:history.back()';
		$image = '<input type="image" src="../images/btn_fix.jpg" alt="修正" width="150" height="20" border="0" style="margin-right:10px">';
		$dat = getPostData();
		$_SESSION["hidden"] = $dat;
		break;
	case 3 :
		require ("./include/getRecord.inc");
		$msg = '<p>この情報を削除してもよろしいですか？</p>';
		$back = 'index.php';
		$image = '<input type="image" src="../images/btn_del.jpg" alt="削除" width="150" height="20" border="0" style="margin-right:10px">';
		$id = $_POST["app_id"];
		$dat = getRecord($id);
		if (!isset($dat["app01"]) || $dat["app01"] == "") {
			$dat["app01_label"] = "承認なし";
		}
		elseif (preg_match('/appr/', $dat["app01"])) {
			$dat["app01_label"] = getLabel($dat["app01"]);
		}
		else {
			$dat["app01_label"] = isDept($dat["app01"]);
		}
		if (!isset($dat["app02"]) || $dat["app02"] == "") {
			$dat["app02_label"] = "承認なし";
		}
		elseif (preg_match('/appr/', $dat["app02"])) {
			$dat["app02_label"] = getLabel($dat["app02"]);
		}
		else {
			$dat["app02_label"] = isDept($dat["app02"]);
		}
		if (!isset($dat["app03"]) || $dat["app03"] == "") {
			$dat["app03_label"] = "承認なし";
		}
		elseif (preg_match('/appr/', $dat["app03"])) {
			$dat["app03_label"] = getLabel($dat["app03"]);
		}
		else {
			$dat["app03_label"] = isDept($dat["app03"]);
		}
		if (!isset($dat["app04"]) || $dat["app04"] == "") {
			//--- 2006-11-09 Y.Adachi Add Start
			$dat["open_id"] = "";
			$dat["open_id_label"] = "";
			//--- 2006-11-09 Y.Adachi Add End
			$dat["app04_label"] = "承認なし";
		}
		else {
			//--- 2006-11-09 Y.Adachi Upd Start
			//				$dat["app04_label"] = "承認あり";
			

			if ($dat["app04"] == WEB_MASTER_CODE) {
				$dat["open_id"] = "";
				$dat["open_id_label"] = "";
				$dat["app04_label"] = "承認あり";
			}
			else {
				$dat["open_id"] = $dat["app04"];
				$dat["open_id_label"] = getUserName($dat["app04"]);
				$dat["app04_label"] = "承認なし";
			}
			//--- 2006-11-09 Y.Adachi Upd End
		}
		$_SESSION["hidden"] = $dat;
		break;
	default :
		DispError("パラメータエラー（behavior）", 4, "javascript:history.back()");
		exit();
		break;
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>承認フロー確認</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="approve.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'approve';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-approve">
<div><img src="images/bar_conf.jpg" alt="承認フロー確認" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?=$msg?>
<form id="app_form" class="cms8341-form" name="app_form" method="post"
	action="submit.php">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="150" align="left" valign="middle" scope="row">承認フロー名 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay(del_escapes($dat["app_name"]))?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">第1承認者 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay($dat["app01_label"])?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">第2承認者 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay($dat["app02_label"])?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">第3承認者 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay($dat["app03_label"])?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">公開責任者</th>
		<td align="left" valign="top"><?=htmlDisplay($dat["open_id_label"])?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">ウェブマスター <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay($dat["app04_label"])?></td>
	</tr>
</table>
<p align="center"><?=$image?><a href="<?=$back?>"><img
	src="../images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0" style="margin-left: 10px"></a></p>
<input type="hidden" name="behavior" value="<?=$bv?>"></form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
