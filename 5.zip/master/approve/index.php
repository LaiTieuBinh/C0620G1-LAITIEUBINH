<?php
/*
 *
 */
/** require **/
require ("./.htsetting");
//function
require ("./include/isUsedWorkPage.inc");
require ("./include/isUsedTemplate.inc");
//
unset($_SESSION["hidden"]);
//
function getAppLabel($dat, $lv) {
	if ($dat == "" || !isset($dat)) {
		return "－";
	}
	elseif ($lv == 4) {
		//組織コードがウェブマスター用でない場合は公開責任者なので、公開責任者の名前を取得
		if ($dat != WEB_MASTER_CODE) {
			global $objCnc;
			$i_objDac = new dac($objCnc);
			$sql = "SELECT name FROM tbl_user WHERE user_id=" . $dat;
			$i_objDac->execute($sql);
			$cnt = $i_objDac->getRowCount();
			if ($cnt != 1) {
				DispError("ユーザー名取得エラー（ユーザーID：" . $dat . "）", 4, "javascript:history.back()");
				exit();
			}
			$i_objDac->fetch();
			return $i_objDac->fld['name'];
		}
		return "○";
	}
	elseif (preg_match('/appr/', $dat)) {
		$ap = str_replace('appr', '', $dat);
		switch ($ap) {
			case "1" :
				return "所属第1承認者";
			case "2" :
				return "所属第2承認者";
			case "3" :
				return "所属第3承認者";
			default :
				DispError("承認コードエラー（" . $dat . ")", 4, "javascript:history.back()");
				exit();
				break;
		}
	}
	global $objCnc;
	$i_objDac = new dac($objCnc);
	$sql = "SELECT dept_name FROM tbl_department WHERE dept_code=" . $dat;
	$i_objDac->execute($sql);
	$cnt = $i_objDac->getRowCount();
	if ($cnt != 1) {
		DispError("組織名取得エラー（組織コード：" . $dat . "）", 4, "javascript:history.back()");
		exit();
	}
	$i_objDac->fetch();
	return $i_objDac->fld['dept_name'];
}

//list format
$fmt1 = '<tr>';
$fmt1 .= '<td align="left" valign="middle">{app_name}</td>';
$fmt1 .= '<td align="center" valign="middle">{app01}</td>';
$fmt1 .= '<td align="center" valign="middle">{app02}</td>';
$fmt1 .= '<td align="center" valign="middle">{app03}</td>';
//--- 2006-11-09 Y.Adachi Add Start
$fmt1 .= '<td align="center" valign="middle">{app04-open}</td>';
//--- 2006-11-09 Y.Adachi Add End
$fmt1 .= '<td align="center" valign="middle">{app04}</td>';
$fmt1 .= '<td align="center" valign="middle">';
$fmt2_1 = '<a href="javascript:" onClick="return cxApproveForm({app_id},2)"><img src="../images/btn_mini_fix.jpg" alt="修正" width="60" height="20" border="0" style="margin-right:3px"></a>';
$fmt2_2 = '<img src="../../images/spacer.gif" alt="" width="60" height="20" border="0" style="margin-right:3px">';
$fmt3_1 = '<a href="javascript:" onClick="return cxApproveForm({app_id},3)"><img src="../images/btn_mini_del.jpg" alt="削除" width="60" height="20" border="0" style="margin-left:3px"></a>';
$fmt3_2 = '<img src="../../images/spacer.gif" alt="" width="60" height="20" border="0" style="margin-left:3px">';
$fmt4 = '</td>';
$fmt4 .= '</tr>';

//
/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
//createList
$html = '';
$sql = "SELECT * FROM tbl_approve ORDER BY approve_id";
$objDac->execute($sql);
$cnt = $objDac->getRowCount();
if ($cnt > 0) {
	while ($objDac->fetch()) {
		//print_dp($objDac->fld);
		//
		$app_id = $objDac->fld['approve_id'];
		$app_name = htmlDisplay($objDac->fld['name']);
		$app01 = $objDac->fld['approve1'];
		$app02 = $objDac->fld['approve2'];
		$app03 = $objDac->fld['approve3'];
		$app04 = $objDac->fld['approve4'];
		//
		$app01 = getAppLabel($app01, 1);
		$app02 = getAppLabel($app02, 2);
		$app03 = getAppLabel($app03, 3);
		$app04 = getAppLabel($app04, 4);
		//
		$isUsedWp = isUsedWorkPage($app_id);
		$isUsedTpl = isUsedTemplate($app_id);
		//
		$tmp = $fmt1;
		//承認なしフローは削除も編集も不可
		if ($app_id != NONE_APPROVE_ID) {
			if ($isUsedWp) {
				$tmp .= $fmt2_2;
			}
			else {
				$tmp .= $fmt2_1;
			}
			if ($isUsedTpl) {
				$tmp .= $fmt3_2;
			}
			else {
				$tmp .= $fmt3_1;
			}
		}
		$tmp .= $fmt4;
		//
		$tmp = str_replace('{app_id}', $app_id, $tmp);
		$tmp = str_replace('{app_name}', $app_name, $tmp);
		$tmp = str_replace('{app01}', $app01, $tmp);
		$tmp = str_replace('{app02}', $app02, $tmp);
		$tmp = str_replace('{app03}', $app03, $tmp);
		if ($objDac->fld['approve4'] == WEB_MASTER_CODE) {
			$tmp = str_replace('{app04-open}', getAppLabel("", 4), $tmp);
			$tmp = str_replace('{app04}', $app04, $tmp);
		}
		else {
			$tmp = str_replace('{app04-open}', $app04, $tmp);
			$tmp = str_replace('{app04}', getAppLabel("", 4), $tmp);
		}
		$html .= $tmp;
	}
}
else {
	$html = '<tr><td align="center" valign="top">現在、承認フローは登録されていません。</td></tr>';
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>承認フロー一覧</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="approve.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxApproveForm(id,bv) {
	switch(bv) {
		case 1:
			$('behavior').value = bv;
			$('app_form').action = 'form.php';
			document.app_form.submit();
			break;
		case 2:
			$('app_id').value = id;
			$('behavior').value = bv;
			$('app_form').action = 'form.php';
			document.app_form.submit();
			break;
		case 3:
			$('app_id').value = id;
			$('behavior').value = bv;
			$('app_form').action = 'confirm.php';
			document.app_form.submit();
			break;
		default:
			alert('パラメータエラー（behavior）');
			break;
	}
	return false;
}
function cxChangePassword() {
	$('app_form').action = 'changePassword.php';
	document.app_form.submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'approve';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-approve">
<div><img src="images/bar_approve.jpg" alt="承認フロー一覧" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="30%" align="center" valign="middle" nowrap scope="col">承認フロー名称</th>
		<th width="10%" align="center" valign="middle" nowrap scope="col">第1承認者</th>
		<th width="10%" align="center" valign="middle" nowrap scope="col">第2承認者</th>
		<th width="10%" align="center" valign="middle" nowrap scope="col">第3承認者</th>
		<th width="10%" align="center" valign="middle" nowrap scope="col">公開責任者</th>
		<th width="10%" align="center" valign="middle" nowrap scope="col">ウェブマスター</th>
		<th width="20%" align="center" valign="middle" scope="col">&nbsp;</th>
	</tr>
<?=$html?>
</table>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<form id="app_form" class="cms8341-form" name="app_form"
	action="form.php" method="post"><input type="hidden" id="app_id"
	name="app_id" value=""> <input type="hidden" id="behavior"
	name="behavior" value=""></form>
</body>
</html>
