<?php
/*
 * sharedアップロード：フォーム画面
 */
// ** require -------------------------------
require ("../../.htsetting");

// ** global 宣言 ---------------------------
global $objCnc;
global $objLogin;

// ウェブマスターではない場合はエラー
if ($objLogin->get('class') != USER_CLASS_WEBMASTER || $objLogin->get('isOpenUser')) {
	user_error('不正アクセスです。');
}

// 同期ディレクトリリスト
$shared_link_ary = array(
		// shared
		"0" => array(
				"cms" => HTTP_ROOT . RPW . SHARED_UPLOAD_DIR, 
				"pub" => HTTP_REAL_ROOT . SHARED_UPLOAD_DIR,
				"name" => SHARED_UPLOAD_DIR
		), 
		// shared_images
		"1" => array(
				"cms" => HTTP_ROOT . RPW . FCK_IMAGES_FORDER_SHARED, 
				"pub" => HTTP_REAL_ROOT . FCK_IMAGES_FORDER_SHARED,
				"name" => FCK_IMAGES_FORDER_SHARED
		), 
		// shared_documents
		//	"2" => array(
		//		"cms" => HTTP_ROOT . RPW . FCK_FILELINK_FORDER_SHARED,
		//		"pub" => HTTP_REAL_ROOT . FCK_FILELINK_FORDER_SHARED
		//	),
		// library_images
		"3" => array(
				"cms" => HTTP_ROOT . RPW . FCK_IMAGES_FORDER_LIBRARY, 
				"pub" => HTTP_REAL_ROOT . FCK_IMAGES_FORDER_LIBRARY,
				"name" => FCK_IMAGES_FORDER_LIBRARY
		), 
		// library_documents
		"4" => array(
				"cms" => HTTP_ROOT . RPW . FCK_FILELINK_FORDER_LIBRARY, 
				"pub" => HTTP_REAL_ROOT . FCK_FILELINK_FORDER_LIBRARY,
				"name" => FCK_FILELINK_FORDER_LIBRARY
		), 
		// library_documents
		"5" => array(
				"cms" => HTTP_ROOT . RPW . FCK_FILELINK_FORDER_SITEMAP, 
				"pub" => HTTP_REAL_ROOT . FCK_FILELINK_FORDER_SITEMAP,
				"name" => FCK_FILELINK_FORDER_SITEMAP
		)
);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>Shared管理</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="./js/index.js"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>


// 取り込み開始
function cxSubmitLink() {
	if (!_isChecked(document.getElementsByClassName('folder_sync'))) {
		alert('同期するフォルダを選択してください。');
		return false;
	}

	$('cms8341-progressmsg').innerHTML = '<p>処理中です...</p>';
	cxLayer('cms8341-progress',1,500,500);
	document.cms_fLink.submit();
	return false;
}

//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'template';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
	<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">

<form name="cms_fImport" class="cms8341-form" method="post"
	action="confirm.php" enctype="multipart/form-data"
	onSubmit="return false;"><input type="hidden" id="cms_filename"
	name="cms_filename" value="">
<div><img src="./images/bar_shared_index.jpg" alt="Shared管理" width="920"
	height="30"></div>
			<?php
			if (file_exists(DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/')) {
				?>
				<div class="cms8341-areamessage" id="cms8341-denaillist-msg">
※取り込みファイルの展開フォルダにファイルが存在します。<br>
[取り込み確認]を行うと、展開フォルダ内は上書きされます。他ユーザが作業中でないことを確認して作業を続けてください。</div>
			<?php
			}
			?>
			<div class="cms8341-area-corner">

<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable">
	<tr id="cms_dir_tr">
		<th align="left" valign="top" scope="row">共有ファイルアップロード</th>
	</tr>
	<tr>
		<td>
		<table width="100%" border="0" cellpadding="7" cellspacing="0"
			class="cms8341-dataTable">

			<tr id="cms_FrmZipnm_tr">
				<th width="150" align="left" valign="top" scope="row">取り込みファイル<br>
				<span class="cms_require">（必須）</span></th>
				<td><input type="file" id="FrmZipnm" name="FrmZipnm"
					style="width: 500px;"><br>
				※zip形式の圧縮ファイルを指定してください<br>
				</td>
			</tr>

			<tr id="cms_dir_tr">
				<th align="left" valign="top" scope="row"><label for="cms_dir">アップロード先</label></th>
				<td><?=HTTP_ROOT . RPW . SHARED_UPLOAD_DIR?>/</td>
			</tr>

		</table>

		<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
			alt="" width="36" height="26"></p>
		<p align="center" id="cms_submit"><a href="javascript:"
			onClick="return cxSubmitImport()" onKeyDown="cxSubmitImport()"><img
			src="<?=RPW?>/admin/images/outerimport/btn_import_confirm.jpg"
			alt="取り込み確認" width="150" height="20" border="0"></a></p>
		</td>
	</tr>
</table>

</div>

</form>

<form name="cms_fLink" class="cms8341-form" id="cms_fLink" method="post"
	action="confirm_sync.php" enctype="multipart/form-data"
	onSubmit="return false;"><input type="hidden" id="cms_filename"
	name="cms_filename" value="">

<div class="cms8341-area-corner">

<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable">
	<tr id="cms_dir_tr">
		<th align="left" valign="top" scope="row">共有ファイル同期</th>
	</tr>
	<tr>
		<td>
		<table width="100%" border="0" cellpadding="7" cellspacing="0"
			class="cms8341-dataTable">
			<tr id="cms_dir_tr">
				<th align="left" valign="top" scope="row" width="150"><label
					for="cms_linkdir">同期ディレクトリ</label></th>
				<td>
					<div>
						<a href="javascript:" onClick="return cxCheckAll(1);"><img
						src="<?=RPW?>/admin/images/upload/btn_allselect.jpg" alt="全て選択する"
						width="120" height="20" border="0"></a> <a href="javascript:"
						onClick="return cxReleaseAll(1);"><img
						src="<?=RPW?>/admin/images/upload/btn_allcansel.jpg" alt="全て解除する"
						width="120" height="20" hspace="20" border="0"></a>
					</div>
<?php
foreach ($shared_link_ary as $shred_link_dirs) {
	?>
					<table width="100%" border="0" cellpadding="5" cellspacing="0"
					class="cms8341-dataTable" style="margin-bottom: 8px;">
					<tr>
						<td rowspan="2" width="30">
							<input type="checkbox" class="folder_sync" id="chkb_<?=$shred_link_dirs['name']?>" onchange="return cxSelectFolder(this)" name="folder_sync[]" value="<?=$shred_link_dirs['name']?>" />
						</td>
						<td><label for="chkb_<?=$shred_link_dirs['name']?>"><?=$shred_link_dirs['cms']?>/</label></td>
					</tr>
					<tr>
						<td><label for="chkb_<?=$shred_link_dirs['name']?>">=>&nbsp;<?=$shred_link_dirs['pub']?>/</label></td>
					</tr>
				</table>
<?php
}
?>
					<div align="center">
						<strong>
							<label><input type="radio" class="" name="type_sync" value="all" checked disabled />すべて</label>
							<label><input type="radio" class="" name="type_sync" value="part" disabled />未同期ファイルのみ</label>
						</strong>
					</div>
				</td>
			</tr>
		</table>
		<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
			alt="" width="36" height="26"></p>
		<p align="center" id="shared_submit"><img id="btn_sync"
			src="<?=RPW?>/admin/master/template/shared/images/btn_shared_link_off.jpg"
			alt="同期" width="80" height="20" border="0"></p>
		</td>
	</tr>
</table>

</div>

<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>

</form>

</div>
</div>
<!-- cms8341-contents -->
<!--***エラーメッセージレイヤー　　ここから***********-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxErrorClose();"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー　　ここまで***********-->
<!--***処理中プロパティレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0" style="background-image:url(<?=RPW?>/admin/images/layer/titlebar_bg.jpg);height:30px;">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg">メッセージ</div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理中プロパティレイヤー ここまで********************************-->
</body>

</html>
