<?php
/*
 * sharedアップロード：確認画面
 */
// ** require -------------------------------
require ("../../.htsetting");

// ** global 宣言 ---------------------------
global $objCnc;
global $objLogin;

// ウェブマスターではない場合はエラー
if ($objLogin->get('class') != USER_CLASS_WEBMASTER || $objLogin->get('isOpenUser')) {
	user_error('不正アクセスです。');
}

// ** 取り込みファイルチェック --------------


// （php.ini）post_max_size をオーバーすると$_POSTの値が飛んでこない
if (count($_POST) == 0 || count($_FILES) == 0) {
	user_error('取り込みファイルのファイルサイズが大きすぎる可能性があります。<br>いくつかに分けて実行してください。');
}
// 取り込みファイルが指定されていなければエラー
if (!isset($_FILES['FrmZipnm']) || $_FILES['FrmZipnm']['name'] == '') {
	user_error('取り込みファイルを指定してください。');
}
// （php.ini）upload_max_filesize をオーバーすると$_FILES['FrmZipnm']['size']はゼロになる
// ファイルサイズがゼロならエラー
if ($_FILES['FrmZipnm']['size'] <= 0) {
	user_error('取り込みファイルの指定が正しくないか、取り込みファイルのファイルサイズが大きすぎる可能性があります。');
}
// 取り込みファイルはzip圧縮のファイルでなければエラー
if (!preg_match('/\.zip$/i', $_FILES['FrmZipnm']['name'])) {
	user_error('取り込みファイルはzip形式の圧縮ファイルを指定してください。');
}

// ** アップロードディレクトリ ---------------


// ディレクトリパスの整形
$cms_dir = SHARED_UPLOAD_DIR;
$cms_dir = preg_replace('/(^\/?|\/?$)/', '/', $cms_dir);
$cms_dir = preg_replace('/\/+/', '/', $cms_dir);

$file_path = DOCUMENT_ROOT . RPW . $cms_dir;

// 対象ディレクトリが存在しなければ作成
if (!@file_exists($file_path)) {
	if (!mkNewDirectory($file_path)) {
		user_error('アップロード先フォルダの生成に失敗しました。【' . $file_path . '】');
	}
}

// 取り込みファイルの展開ディレクトリ
$tmpUpDir = DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/';
chmodAll($tmpUpDir, 0777);
if (@file_exists($tmpUpDir)) removeDir($tmpUpDir);
if (!@mkdir($tmpUpDir, 0777)) {
	user_error('取り込みファイルの展開フォルダ作成に失敗しました。');
}
chmod($tmpUpDir, 0777);

// 圧縮ファイルを解凍する
if (defined("SET_UNZIP_EXE")) {
	exec(SET_UNZIP_EXE . ' ' . $_FILES['FrmZipnm']['tmp_name'] . ' ' . $tmpUpDir);
}
else {
	exec('unzip ' . $_FILES['FrmZipnm']['tmp_name'] . ' -d ' . $tmpUpDir);
}

// 取り込みファイルの確認
$aryFilenameErr = array();
$aryFiles = array();
$aryDelList = array();

$in_currDir = '';
$in_upDir = $cms_dir;
$tmpDir = DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id');

$chk = array(
		"err_mes" => "取り込めません", 
		"yes_dir" => "", 
		"non_dir" => getDefineArray('SHARED_NOT_UPLOAD_DIR'), 
		"non_extension" => explode(",", DENIED_EXTENSIONS_SHARED_UPLOAD), 
		"file_name" => true, 
		"dir_name" => true, 
		"capital" => true, 
		"dot" => true, 
		"zero_byte" => true, 
		"size" => true
);

sharedChkFiles($in_currDir, $in_upDir, $tmpDir, $chk, $aryFiles, $aryDelList);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>共有ファイルアップロード</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/outerimport_conf.js"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'template';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
	<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">

<div><img src="./images/bar_shared_upload.jpg" alt="共有ファイルアップロード"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle" style="background-image:url(<?=RPW?>/admin/page/publiclist/images/bar_topbg.jpg);height:31px;"><img
			src="<?=RPW?>/admin/images/outerimport/bar_importconf.jpg" alt="取込条件"
			width="200" height="20" style="margin-left: 10px;"></td>
	</tr>
</table>
<div id="cms8341-search" style="display: block">
<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="150" align="left" valign="top" scope="row">取り込みファイル</th>
		<td><?=htmlDisplay($_POST['cms_filename'])?></td>
	</tr>

	<tr>
		<th align="left" valign="top" scope="row">アップロード先</th>
		<td><?=HTTP_ROOT . RPW . SHARED_UPLOAD_DIR?>/</td>
	</tr>
</table>
</div>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right" valign="middle" style="background-image:url(<?=RPW?>/admin/page/publiclist/images/bar_bottombg.jpg);height:32px;">
		<a href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			src="<?=RPW?>/admin/images/btn/btn_close_mini.jpg" alt="閉じる"
			width="80" height="15" border="0" style="margin-right: 10px;"
			id="cms-searchSwitch"></a></td>
	</tr>
</table>

</div>

<form name="cms_fImport" class="cms8341-form" method="post"
	action="complete.php" onSubmit="return false;">

<p><a href="javascript:" onClick="return cxCheckAll();"><img
	src="<?=RPW?>/admin/images/upload/btn_allselect.jpg" alt="全て選択する"
	width="120" height="20" border="0"></a> <a href="javascript:"
	onClick="return cxReleaseAll();"><img
	src="<?=RPW?>/admin/images/upload/btn_allcansel.jpg" alt="全て解除する"
	width="120" height="20" hspace="20" border="0"></a></p>

<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">選択</th>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">状態</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">取り込みファイル</th>
	</tr>
<?php
foreach ($aryFiles as $ary) {
	$icon_img = '&nbsp;';
	if (!$ary['error']) {
		if ($ary['overwrite']) $icon_img = '[上書き]';
	}
	$chkbox_name = ($ary['pagefile']) ? 'cms_file_path' : 'cms_item_path';
	print '<tr>' . "\n";
	print '<td align="center" valign="middle">';
	if ($ary['error']) print '&nbsp;';
	else print '<input type="checkbox" name="' . $chkbox_name . '[]" value="' . $ary['file_path'] . '">';
	print '</td>' . "\n";
	print '<td align="center" valign="middle">' . $icon_img . '</td>' . "\n";
	print '<td align="left" valign="top" nowrap><p>' . htmlDisplay($ary['file_path']) . "\n";
	if ($ary['message'] != '') print '<br><span class="cms8341-error">' . $ary['message'] . '</span>' . "\n";
	print '</p></td>' . "\n";
	print '</tr>' . "\n";
}
?>
</table>
<?php
if (count($aryFilenameErr) > 0) {
	print '<div class="cms8341-errorDiv">' . "\n";
	foreach ($aryFilenameErr as $dir => $cnt) {
		print 'アップロードできないファイル名のものが&nbsp;' . $dir . '&nbsp;フォルダ内に ' . $cnt . ' ファイルあります。<br>' . "\n";
	}
	print '<p class="cms8341-error">ファイル名に使用できるのは半角英数字と - _ . ~ です。</p>' . "\n";
	print '</div>' . "\n";
}
?>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center"><a href="javascript:" onClick="return cxSubmit()"
	onKeyDown="cxSubmit()"><img
	src="<?=RPW?>/admin/images/btn/btn_start.jpg" alt="取り込み開始" width="150"
	height="20" border="0" style="margin-right: 10px;"></a> <a
	href="javascript:history.back();"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px;"></a></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!--***処理中プロパティレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			style="background-image: url(images/layer/titlebar_bg.jpg); height: 30px;">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg">メッセージ</div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理中プロパティレイヤー ここまで********************************-->
</body>
</html>