/*
 * shared アップロード：取り込み画面
 */

// 
cxPreImages(cms8341admin_path+'/images/menu/logout01_btn.jpg',
			cms8341admin_path+'/images/menu/logout02_btn.jpg');


// 取り込み開始
function cxSubmitImport() {
	var msg = new Array();
	if (!$('FrmZipnm').value) {
		msg.push('取り込みファイルを入力してください。');
	} else {
		var filetype = $('FrmZipnm').value.replace(/^.*\.([^\.]+$)/, '$1');
		filetype = filetype.toLowerCase();
		if (filetype != 'zip') msg.push('取り込みファイルはzip形式でアップロードしてください。');
		//
		// 「[a-z]:\～」または「\\～」で始まるパスの指定のみを許容する
		var filepath = $('FrmZipnm').value.match(/^([a-z]:\\|\\\\).+/i);
		if(!filepath) {
			msg.push('取り込みファイルの参照先を正しく指定してください。');
		}
	}
	// エラー表示
	if (msg.length > 0) {
		$('cms8341-errormsg').innerHTML = msg.join("<br>");
		cxLayer('cms8341-error',1,500,500);
		return false;
	}
	
	// 公開アップロードにチェック済みなら確認
	if ( $('cms_publish_upload') && $('cms_publish_upload').checked == true ) {
		if ( ! confirm("公開側にもアップロードを行います。よろしいですか？") ) {
			return false;
		}
	}
	
	$('cms_filename').value = $('FrmZipnm').value;
	document.cms_fImport.submit();
	return false;
}

function cxErrorClose() {
	cxComboVisible();
	cxLayer('cms8341-error',0);
}
// select folder sync
function cxSelectFolder() {
	var checkbox_folder = document.getElementsByClassName('folder_sync');
	if (checkbox_folder.length < 1) {
		return false;
	}
	var sync_btn_flg = false;
	var length_checkbox = checkbox_folder.length;
	for (var cnt = 0; cnt < length_checkbox; cnt++) {
		if (checkbox_folder[cnt].checked == true) {
			sync_btn_flg = true;
			break;
		}
	}
	var type_sync = document.getElementsByName('type_sync');
	// enable/disable radio button
	for (var cnt_radio = 0; cnt_radio < type_sync.length; cnt_radio++) {
		type_sync[cnt_radio].disabled = !sync_btn_flg;
	}
	changeSyncButton(sync_btn_flg, 'return cxSubmitLink()');
}
// btn sync enable/disable
function changeSyncButton(btn_flg, onclick_str) {
	if (btn_flg == true) {
		$('btn_sync').src = cms8341admin_path+'/master/template/shared/images/btn_shared_link.jpg';
		var parent = $('btn_sync').parentNode;
		if (parent.id == 'shared_submit') {
			parent.innerHTML = '<a href="javascript:" onClick="' + onclick_str + '">' + $('btn_sync').outerHTML + '</a>';
		}
	} else {
		$('btn_sync').src = cms8341admin_path+'/master/template/shared/images/btn_shared_link_off.jpg';
		var parent = $('btn_sync').parentNode.parentNode;
		if (parent.id == 'shared_submit') {
			parent.innerHTML = $('btn_sync').outerHTML;
		}
	}
}

function cxCheckAll(index_flg) {
	if (index_flg == 1) {
		_checkAll(document.getElementById("cms_fLink").getElementsByClassName("folder_sync"), index_flg);
		cxSelectFolder();
	} else {
		_checkAll(document.getElementById("cms_fSync").getElementsByClassName("upload_class"));
		_checkAll(document.getElementById("cms_fSync").getElementsByClassName("upload_file"));
	}
}

function cxReleaseAll(index_flg) {
	if (index_flg == 1) {
		_releaseAll(document.getElementById("cms_fLink").getElementsByClassName("folder_sync"), index_flg);
		cxSelectFolder();
	} else {
		_releaseAll(document.getElementById("cms_fSync").getElementsByClassName("upload_class"));
		_releaseAll(document.getElementById("cms_fSync").getElementsByClassName("upload_file"));
	}
}

//
function cxSubmit() {
	if (_isChecked(document.getElementById("cms_fSync").getElementsByClassName("upload_class")) == false ) {
		alert('同期するファイルを選択してください。');
		return false;
	}
	$('cms8341-progressmsg').innerHTML = '<p>処理中です...</p>';
	cxLayer('cms8341-progress',1,500,500);
	document.cms_fSync.submit();
	return false;
}

//
function _checkAll(alElem, index_flg) {
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = true;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = true;
			}
		}
		if (index_flg == 1) {
			changeSyncButton(_isChecked(alElem), 'return cxSubmitLink()');
		} else {
			changeSyncButton(_isChecked(document.getElementById("cms_fSync").getElementsByClassName("upload_class")), 'return cxSubmit()');
		}
	}
}
function _releaseAll(alElem, index_flg) {
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = false;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = false;
			}
		}
		if (index_flg == 1) {
			changeSyncButton(_isChecked(alElem), 'return cxSubmitLink()');
		} else {
			changeSyncButton(_isChecked(document.getElementById("cms_fSync").getElementsByClassName("upload_class")), 'return cxSubmit()');
		}
	}
}
function _isChecked(alElem) {
	var err = false;
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			if (alElem.checked) {
				err = true;
			}
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				if (alElem[i].checked) {
					err = true;
					break;
				}
			}
		}
	}
	return err;
}
// select file sync
function cxSelectFile(_this) {
	var _ele_this = $(_this),
		sibling_this = _ele_this.nextSibling;
	if (sibling_this) {
		sibling_this.checked = _ele_this.checked;
	}
	changeSyncButton(_isChecked(document.getElementById("cms_fSync").getElementsByClassName("upload_class")), 'return cxSubmit()');
}

document.addEventListener('DOMContentLoaded', function () {
	cxSelectFolder();
});