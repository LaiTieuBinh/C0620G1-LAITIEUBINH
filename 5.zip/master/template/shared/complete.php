<?php
/*
 * sharedアップロード：アップロード処理 完了画面
 */
// ** require -------------------------------
require ("../../.htsetting");

// ** global 宣言 ---------------------------
global $objCnc;
global $objLogin;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_shared_upload.inc');
$objShared = new tbl_shared_upload($objCnc);

// ウェブマスターではない場合はエラー
if ($objLogin->get('class') != USER_CLASS_WEBMASTER || $objLogin->get('isOpenUser')) {
	user_error('不正アクセスです。');
}

// テンポラリーにファイルがない
$tmpUpDir = DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/';
$upDir = SHARED_UPLOAD_DIR . "/";
if (!file_exists($tmpUpDir)) {
	user_error('取り込みデータが見つかりません。');
}

// ファイルが一つも選択されていなければエラー
if ((!isset($_POST['cms_file_path']) || !is_array($_POST['cms_file_path']) || count($_POST['cms_file_path']) == 0) && (!isset($_POST['cms_item_path']) || !is_array($_POST['cms_item_path']) || count($_POST['cms_item_path']) == 0)) {
	user_error('取り込むファイルを選択してください。');
}

// 取り込み処理
$aryUpFiles = array();
$aryMkFiles = array();
$aryParent = array();

$chk = array(
		"err_mes" => "取り込めません", 
		"non_dir" => getDefineArray('SHARED_NOT_UPLOAD_DIR')
);

$aryFiles = array();
foreach ($_POST['cms_item_path'] as $filename) {
	// ファイル情報を格納
	$aryFiles[] = array(
			'file_path' => $filename, 
			'page_title' => '', 
			'pagefile' => false, 
			'error' => false, 
			'mode' => '', 
			'overwrite' => false, 
			'message' => '', 
			'rename' => false, 
			'editcss' => false, 
			'tpl_css' => 0
	);
}

// cmsサーバーにアップロード
publishUploadShared($aryFiles, $aryUpFiles, $tmpUpDir, $upDir, $chk, true, false);

// 取り込みファイルの削除
removeDir($tmpUpDir);

$objCnc->begin();

foreach ($aryUpFiles as $filename => $upfile) {
	if ($upfile['error'] == TRUE) {
		continue;
	}
	
	$filepath = SHARED_UPLOAD_DIR . "/" . $upfile['file_path'];
	$objShared->select($objShared->_addslashesC('file_path', $filepath));
	if ($objShared->getRowCount() > 0 && $objShared->fetch()) {
		$data_update = array(
			'id' => $objShared->fld['id'],
			'entry_datetime' => date('Y-m-d H:i:s')
		);
		if (!$objShared->update($data_update)) {
			$aryUpFiles[$filename]['error'] = TRUE;
			$aryUpFiles[$filename]['message'] = 'DB:ファイル情報の更新に失敗しました。';
		}
	} else {
		$ary_shared = array(
			'file_path' => $filepath,
			'upload_class' => ($upfile['overwrite']) ? $objShared::SHARED_OVERWRITE : $objShared::SHARED_NEW
		);
		if(!$objShared->insert($ary_shared)) {
			$aryUpFiles[$filename]['error'] = TRUE;
			$aryUpFiles[$filename]['message'] = 'DB:ファイル情報の登録に失敗しました。';
		}
	}
}
$objCnc->commit();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>共有ファイルアップロード</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'template';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
	<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">
<div><img src="./images/bar_shared_upload.jpg" alt="共有ファイルアップロード"
	width="920" height="30"></div>
<div class="cms8341-area-corner">

<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">状態</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">アップロードしたファイル</th>
	</tr>

<?php
foreach ($aryUpFiles as $ary) {
	$icon_img = '';
	if (!$ary['error']) {
		if ($ary['overwrite']) $icon_img = '[上書き]';
	}
	print '<tr>' . "\n";
	print '<td align="center" valign="middle">' . $icon_img . '</td>' . "\n";
	print '<td align="left" valign="top" nowrap><p>' . htmlDisplay(SHARED_UPLOAD_DIR . "/" . $ary['file_path']) . "\n";
	if ($ary['message'] != '') print '<br><span class="cms8341-error">' . $ary['message'] . '</span>' . "\n";
	print '</p></td>' . "\n";
	print '</tr>' . "\n";
}
?>

			</table>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>