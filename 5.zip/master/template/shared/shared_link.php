<?php
/*
 * sharedアップロード：確認画面
 */
// ** require -------------------------------
require ("../../.htsetting");

// ** global 宣言 ---------------------------
global $objCnc;
global $objLogin;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_shared_upload.inc');
$objShared = new tbl_shared_upload($objCnc);
// ウェブマスターではない場合はエラー
if ($objLogin->get('class') != USER_CLASS_WEBMASTER || $objLogin->get('isOpenUser')) {
	user_error('不正アクセスです。');
}

// check parameter
if (!isset($_POST['upload_class']) || count($_POST['upload_class']) == 0 || !isset($_POST['upload_file']) || count($_POST['upload_file']) == 0) {
	user_error('不正なパラメータです。');
}

$aryUpFiles = array();
$result_html = "";
$upload_class_ary = $_POST['upload_class'];
$upload_file_ary = $_POST['upload_file'];
$ftpCnc = null;
// 公開へアップロードする場合FTP接続
if (FTP_UPLOAD_FLG && !SFTP_FLG) {
	$ftpCnc = connectFTP("cms");
}
foreach ($upload_class_ary as $key_file_path => $mode_upload) {
	$file_path = $upload_file_ary[$key_file_path];
	$chk = array(
			"err_mes" => "同期できません", 
			"css_cms8341" => true
	);
	
	// 公開サーバーにアップロード
	if (publishShared($file_path, $aryUpFiles, $chk, $mode_upload, $ftpCnc)) {
		if (!$objShared->delete($objShared->_addslashesC('file_path', $file_path))) {
			$aryUpFiles[$file_path]['error'] = TRUE;
			$aryUpFiles[$file_path]['message'] = 'Sharedアップロード情報の削除に失敗しました。【' . $file_path . '】';
		}
		// ***_pub.js => ***.js
		if (preg_match('/' . JS_UPLOAD . '\.js$/i', $file_path)) {
			$cms_file_path = preg_replace('/' . JS_UPLOAD . '\.js$/i', '.js', $file_path);
			if (!$objShared->delete($objShared->_addslashesC('file_path', $cms_file_path))) {
				$aryUpFiles[$file_path]['error'] = TRUE;
				$aryUpFiles[$file_path]['message'] .= 'Sharedアップロード情報の削除に失敗しました。【' . $cms_file_path . '】';
			}
		}
	}
}
if (!SFTP_FLG && FTP_UPLOAD_FLG) {
	// FTP ストリームを閉じる
	cx_ftp_close($ftpCnc);
}
foreach ($aryUpFiles as $ary) {
	$icon_img = '';
	if (!$ary['error']) {
		if ($ary['mode_upload'] == $objShared::SHARED_OVERWRITE) {
			$icon_img .= '[上書き]<br>';
		}
		if ($ary['rename']) {
			$icon_img .= '[リネーム]<br>';
		}
		if ($ary['mode_upload'] == $objShared::SHARED_DELETE_MODE) {
			$icon_img .= '[削除]<br>';
		}
	}
	$result_html .= '<tr>' . "\n";
	$result_html .= '<td align="center" valign="middle">' . $icon_img . '</td>' . "\n";
	$result_html .= '<td align="left" valign="top" nowrap><p>' . htmlDisplay($ary['file_title']) . "\n";
	if ($ary['message'] != '') {
		$result_html .= '<br><span class="cms8341-error">' . $ary['message'] . '</span>' . "\n";
	}
	$result_html .= '</p></td>' . "\n";
	$result_html .= '</tr>' . "\n";
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>共有ファイル同期</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'template';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
	<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">
<div><img src="./images/bar_shared_link.jpg" alt="共有ファイル同期" width="920"
	height="30"></div>
<div class="cms8341-area-corner">

<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">状態</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">同期したファイル</th>
	</tr>
				<?=$result_html?>
			</table>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>