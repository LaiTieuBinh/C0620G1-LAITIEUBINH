<?php
/*
 * sharedアップロード：確認画面
 */
// ** require -------------------------------
require ("../../.htsetting");

// ** global 宣言 ---------------------------
global $objCnc;
global $objLogin;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_shared_upload.inc');
$objShared = new tbl_shared_upload($objCnc);
// ウェブマスターではない場合はエラー
if ($objLogin->get('class') != USER_CLASS_WEBMASTER || $objLogin->get('isOpenUser')) {
	user_error('不正アクセスです。');
}

// check parameter
if (!isset($_POST['folder_sync']) || count($_POST['folder_sync']) == 0) {
	user_error('不正なパラメータです。');
}

// 取り込みファイルの確認 --------------------
$folder_sync_ary = $_POST['folder_sync'];
$result_html = "";

$chk = array(
		"err_mes" => "同期できません", 
		"non_dir" => getDefineArray('SHARED_NOT_UPLOAD_DIR')
);

// アップロードディレクトリ
$upDirAry = array(
		SHARED_UPLOAD_DIR, 
		FCK_IMAGES_FORDER_SHARED, 
		FCK_FILELINK_FORDER_SHARED, 
		FCK_IMAGES_FORDER_LIBRARY, 
		FCK_FILELINK_FORDER_LIBRARY, 
		FCK_FILELINK_FORDER_SITEMAP
);
$key_checkbox = 0;
foreach ($folder_sync_ary as $dir) {
	if (!in_array($dir, $upDirAry)) {
		continue;
	}
	// get file path from DB
	$shared_upload_ary = array();
	if ($_POST['type_sync'] == 'part') {
		$objShared->select($objShared->_addslashesC('file_path', str_replace('_', '\_', $dir) . '/%', 'LIKE'));
		if ($objShared->getRowCount() == 0) {
			continue;
		}
		while ($objShared->fetch()) {
			$shared_upload_ary[$objShared->fld['file_path']] = $objShared->fld['upload_class'];
		}
	}
	// file publish
	$aryFiles_pub = array();
	$aryDelList_pub = array();
	$tmpUpDir_pub = DOCUMENT_ROOT . RPR . $dir . "/";
	if ($_POST['type_sync'] != 'part') {
		// get file in public server ( cms8341_real )
		sharedChkFiles('/', $dir, $tmpUpDir_pub, $chk, $aryFiles_pub, $aryDelList_pub, FALSE);
		// get first element in array ( file_path is first )
		$file_pub_ary = array_map('current', $aryFiles_pub);
	}
	// file cms8341
	$aryFiles = array();
	$aryDelList = array();
	$tmpUpDir = DOCUMENT_ROOT . RPW . $dir . "/";
	$upDir = $dir . "/";
	// 公開するファイル一覧取得
	sharedChkFiles('/', $dir, $tmpUpDir, $chk, $aryFiles, $aryDelList);
	
	// _pub.js がある場合
	if ($dir == SHARED_UPLOAD_DIR && count($aryDelList) > 0) {
		// _pub でない js 一覧から削除
		sharedChkFilesJS($aryFiles, $aryDelList);
	}
	$file_cms_ary = array();
	// 上書きフラグは消す
	foreach ((array) $aryFiles as $key => $fileInfo) {
		// 上書きフラグは消す
		$aryFiles[$key]['overwrite'] = FALSE;
		// set file_title
		$aryFiles[$key]['file_title'] = $fileInfo['file_path'];
		// 情報
		$fn = $fileInfo['file_path'];
		$file_cms_ary[] = $fileInfo['file_path'];
		// ローカルパス
		$filename = $fn;
		// 公開用パス()
		$pub_filename = $fn;
		// ***_pub.js => ***.js
		if (preg_match('/' . JS_UPLOAD . '\.js$/i', $pub_filename)) {
			$pub_filename = preg_replace('/' . JS_UPLOAD . '\.js$/i', '.js', $pub_filename);
			$aryFiles[$key]['file_title'] .= "\n=> " . $dir . $pub_filename;
		}

		// 8341 パス
		$file_path = str_replace("//", "/", DOCUMENT_ROOT . RPW . $upDir . $filename);
		// real パス
		$rfile_path = str_replace("//", "/", DOCUMENT_ROOT . RPR . $upDir . $pub_filename);
		// remove file list
		if ($_POST['type_sync'] == 'part') {
			$path_key = str_replace("//", "/", $upDir . $filename);
			if (!array_key_exists($path_key, $shared_upload_ary)) {
				unset($aryFiles[$key]);
			} else {
				$aryFiles[$key]['overwrite'] = ($shared_upload_ary[$path_key] == $objShared::SHARED_OVERWRITE) ? TRUE : FALSE;
			}
		} else {
			// real root にファイルが存在すれば上書き
			if (file_exists($rfile_path)) {
				$aryFiles[$key]['overwrite'] = TRUE;
			}
		}
	}
	// sync all, compare file publish and cms8341, then merge with deleted file list
	if ($_POST['type_sync'] != 'part') {
		$file_del_diff = array_diff($file_pub_ary, $file_cms_ary);
		
		// _pub.js がある場合
		if ($dir == SHARED_UPLOAD_DIR && count($aryDelList) > 0) {
			// _pub でない js 一覧から削除
			$file_del_diff = array_diff($file_del_diff, $aryDelList);
		}
	} else {
		// get file delete
		$shared_filepath_ary = array();
		foreach ($shared_upload_ary as $key_path => $val_flg) {
			if ($val_flg == $objShared::SHARED_DELETE_DB) {
				$shared_filepath_ary[] = str_replace($dir, "", $key_path);
			}
		}
		$file_del_diff = array_diff($shared_filepath_ary, $file_cms_ary);
	}
	$file_del_ary = array();
	foreach ($file_del_diff as $key => $file_del) {
		$file_del_ary[] = array(
			'file_path' => $file_del, 
			'page_title' => '', 
			'pagefile' => false, 
			'error' => false, 
			'mode' => '', 
			'overwrite' => false, 
			'message' => '', 
			'rename' => false, 
			'editcss' => false, 
			'tpl_css' => 0, 
			'up_dir' => $dir,
			'delete' => true
		);
	}
	$file_confirm_ary = array_merge($aryFiles, $file_del_ary);
	// list file confirm
	foreach ($file_confirm_ary as $ary) {
		$icon_img = '';
		$class_value = $objShared::SHARED_NEW;
		if (!$ary['error']) {
			if ($ary['overwrite']) {
				$icon_img .= '[上書き]<br>';
				$class_value = $objShared::SHARED_OVERWRITE;
			}
			if ($ary['rename']) {
				$icon_img .= '[リネーム]<br>';
			}
			if ($ary['delete']) {
				$icon_img .= '[削除]<br>';
				$class_value = $objShared::SHARED_DELETE_MODE;
			}
		}
		$result_html .= '<tr>' . "\n";
		if ($ary['message'] == '') {
			$result_html .= '<td align="center" valign="middle">'
					.	'<input type="checkbox" class="upload_class" id="chkb_' . htmlDisplay($ary['up_dir'] . $ary['file_path']) 
					.		'" onchange="return cxSelectFile(this)" name="upload_class[' . $key_checkbox . ']" value="' . $class_value . '" />'
					.	'<input type="checkbox" class="upload_file hidden" name="upload_file[' . $key_checkbox . ']" value="' . ($ary['up_dir'] . $ary['file_path']) . '" />'
					. '</td>' . "\n";
		} else {
			$result_html .= '<td align="center" valign="middle">&nbsp;</td>' . "\n";
		}
		$result_html .= '<td align="center" valign="middle">' . $icon_img . '</td>' . "\n";
		$result_html .= '<td align="left" valign="top" nowrap><p><label for="chkb_' . htmlDisplay($ary['up_dir'] . $ary['file_path']) . '">' 
					. htmlDisplay($ary['up_dir'] . (isset($ary['file_title']) ? $ary['file_title'] : $ary['file_path'])) . "\n";
		if ($ary['message'] != '') {
			$result_html .= '<br><span class="cms8341-error">' . $ary['message'] . '</span>' . "\n";
		}
		$result_html .= '</p></label></td>' . "\n";
		$result_html .= '</tr>' . "\n";
		$key_checkbox++;
	}
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>共有ファイル同期</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="./js/index.js"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'template';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
	<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">
<div><img src="./images/bar_shared_link.jpg" alt="共有ファイル同期" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<form name="cms_fSync" class="cms8341-form" id="cms_fSync" method="post"
	  action="shared_link.php" onSubmit="return false;">
<p><a href="javascript:" onClick="return cxCheckAll();"><img
	src="<?=RPW?>/admin/images/upload/btn_allselect.jpg" alt="全て選択する"
	width="120" height="20" border="0"></a> <a href="javascript:"
	onClick="return cxReleaseAll();"><img
	src="<?=RPW?>/admin/images/upload/btn_allcansel.jpg" alt="全て解除する"
	width="120" height="20" hspace="20" border="0"></a></p>

<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">選択</th>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">状態</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">同期したファイル</th>
	</tr>
	<?php
		if ($result_html != '') {
			echo $result_html;
		} else {
			echo '<tr><td colspan="3" align="center">同期するファイルはありません。</td></tr>';
		}
	?>
			</table>
	
	<p align="center"><span id="shared_submit"><img id="btn_sync"
	src="<?=RPW?>/admin/master/template/shared/images/btn_shared_link_off.jpg" alt="同期" width="80"
	height="20" border="0" style="margin-right: 10px;"></span> <a
	href="javascript:history.back();"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px;"></a></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!--***処理中プロパティレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			style="background-image: url(images/layer/titlebar_bg.jpg); height: 30px;">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg">メッセージ</div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理中プロパティレイヤー ここまで********************************-->
</body>