<?php
/*
 * 定型項目表示設定画面
 */
/** require **/
require ("./.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');

global $objCnc;
$objHandler = new tbl_handler($objCnc);

// パラメータチェック	
if (!isset($_POST['tpl_id']) || $_POST['tpl_id'] == "") {
	DispError("パラメータ取得エラー(tpl_id)", 5, "javascript:history.back()");
	exit();
}
$template_id = $_POST['tpl_id'];
// 定型項目情報取得
$items = getItem($template_id, "page", "edit");
// 取得数チェック
if (count($items) == 0) {
	DispError("定型項目がありません", 5, "javascript:history.back()");
	exit();
}
// 定型項目情報表示情報の取得
$idAry = array();
if ($objHandler->selectKankoDisp($template_id) !== FALSE) {
	while ($objHandler->fetch()) {
		$idAry[] = $objHandler->fld['item2'];
	}
}

$tmpAry = array();
$dispAry = array();
$entryItem = array();
foreach ($items as $item) {
	if (!isset($item['work'])) continue;
	$id = $item['id'];
	$tmpAry[$id] = $item;
}
foreach ($tmpAry as $id => $item) {
	if (in_array($id, $entryItem)) continue;
	$dispAry[$id] = $item;
	$dispAry[$id]['class'] = "0";
	if (isset($item['group'])) {
		foreach (explode(",", $item['group']) as $value) {
			if (!isset($tmpAry[$value])) continue;
			$dispAry[$value] = $tmpAry[$value];
			$dispAry[$value]['class'] = "1";
			$entryItem[] = $value;
			if (!isset($tmpAry[$value]['group'])) continue;
			foreach (explode(",", $tmpAry[$value]['group']) as $value2) {
				if (!isset($tmpAry[$value2])) continue;
				$dispAry[$value2] = $tmpAry[$value2];
				$dispAry[$value2]['class'] = "2";
				$entryItem[] = $value2;
			}
			$groupAry = explode(",", $dispAry[$id]['group']);
			unset($groupAry[array_search($value, $groupAry)]);
			$dispAry[$id]['group'] = implode(",", $groupAry);
		}
	}
}

// 表示用データ作成
$html = '<tr><th width="60%" align="center">項目名</th><th width="20%" align="center">種類</th><th width="20%" align="center">公開時</th></tr>';
foreach ($dispAry as $id => $item) {
	if (isset($item['group'])) {
		$space = ($item['class'] > 0) ? '<span style="background-color:#FFF888;">' . str_repeat("&nbsp;", $item['class'] * 5) . '</span>' : '';
		$html .= '<tr id="' . $id . '">' . "\n";
		$html .= '<td style="background-color:#FFF888;" colspan="3">' . $space . "\n";
		$html .= '<a href="javascript:" onclick="cxDisp(\'' . $id . '\')">' . htmlDisplay($item['name']) . '</a>' . "\n";
		$html .= '<input type="hidden" id="' . $id . '_group_id" name="' . $id . '_group_id" value="' . $item['group'] . '">' . "\n";
		$html .= '</td>' . "\n";
		$html .= '</tr>' . "\n";
	}
	else {
		$ctrl = array_pop($item['ctrl']);
		$publish = (isset($item['publish']) && $item['publish'] == 1) ? "表示" : "非表示";
		$space = ($item['class'] > 0) ? '<span style="background-color:#ffffff;">' . str_repeat("&nbsp;", $item['class'] * 5) . '</span>' : '';
		$checked = (in_array($id, $idAry)) ? " checked" : "";
		$type = getInputTyepName($ctrl['type']);
		$html .= '<tr id="' . $id . '">' . "\n";
		$html .= '<td align="left">' . $space;
		$html .= '<input type="checkbox" name="cms_kanko[]" id="cms_kanko_' . $id . '" value="' . htmlDisplay($id) . '"' . $checked . '>' . "\n";
		$html .= '<label for="cms_kanko_' . $id . '">' . htmlDisplay($item['name']) . '</label></td>' . "\n";
		$html .= '<td>' . htmlDisplay($type) . '</td>' . "\n";
		$html .= '<td>' . $publish . '</td>' . "\n";
		$html .= '</tr>' . "\n";
	}
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>定型項目表示設定</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="template.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxCheckAll() {
	var alElem = document['tpl_form']['cms_kanko[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = true;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = true;
			}
		}
	}
}
function cxReleaseAll() {
	var alElem = document['tpl_form']['cms_kanko[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = false;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = false;
			}
		}
	}
}
function cxSubmit() {
	var chkFlg = false;
	var alElem = document['tpl_form']['cms_kanko[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			if (alElem.checked) chkFlg = true;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				if (alElem[i].checked) {
					chkFlg = true;
					break;
				}
			}
		}
	}
	if (!chkFlg) {
		alert("表示する項目にチェックを入れてください");
		return false;
	}

	$('tpl_form').submit();
	return false;
}
function cxDisp(id){
	group_id = $F(id+'_group_id');
	group_id_ary = group_id.split(",");
	for(i = 0; i < group_id_ary.length; i++){
		if($(group_id_ary[i])){
			Element.toggle($(group_id_ary[i]));
		}
	}
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'template';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<form id="tpl_form" class="cms8341-form" name="tpl_form"
	action="kankoDispSetting_confirm.php" method="post"><input
	type="hidden" id="tpl_id" name="tpl_id" value="<?=$template_id?>">
<div align="center" id="cms8341-templates">
<div><img src="images/bar_kanko_disp.jpg" alt="定型項目表示設定" width="920"
	height="30"></div>
<div class="cms8341-area-corner">表示したい項目にチェックを入れてください
<p align="left"><a href="javascript:" onClick="return cxCheckAll();"><img
	src="../../images/upload/btn_allselect.jpg" alt="全て選択する" width="120"
	height="20" border="0"></a> <a href="javascript:"
	onClick="return cxReleaseAll();"><img
	src="../../images/upload/btn_allcansel.jpg" alt="全て解除する" width="120"
	height="20" hspace="20" border="0"></a></p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
				<?=$html?>
			</table>
<p align="center"><a href="javascript:" onclick="return cxSubmit()"><img
	src="../images/btn_conf.jpg" alt="確認" width="150" height="20"
	border="0" style="margin-right: 10px"></a> <a href="index.php"><img
	src="../../images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150"
	height="20" border="0" style="margin-left: 10px"></a></p>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</form>
</div>
<!-- cms8341-contents -->
</body>
</html>
