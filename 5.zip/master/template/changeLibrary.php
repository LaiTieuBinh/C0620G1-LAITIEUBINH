<?php
/*
 *
 */
/** require **/
require ("./.htsetting");
//function
require ("./include/isTplExist.inc");
unset($_SESSION["hidden"]);

//main
if (isset($_POST["tpl_id"])) {
	$tpl_id = $_POST["tpl_id"];
}
else {
	DispError("パラメータ取得エラー(tpl_id)", 5, "javascript:history.back()");
	exit();
}

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objDacTools = new dac_tools($objCnc);
if ($objDacTools->selectTemplate($tpl_id) === FALSE) {
	DispError("指定したテンプレートがみつかりません(tpl_id)", 5, "javascript:history.back()");
}
$nonuse_library_id_Ary = explode(",", $objDacTools->fld['nonuse_library_id']);

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
//createList
$lib_htmlAry = array();
$edit_htmlAry = array();
$lib_idAry = array();
$library_html = '';
$parts_html = '';
$sql = "SELECT * from tbl_library AS l WHERE l.library_ver = (SELECT MAX(library_ver) FROM tbl_library WHERE library_id = l.library_id) ORDER BY user_parmission,sort_order,library_id";
$objDac->execute($sql);
$cnt = $objDac->getRowCount();
if ($cnt > 0) {
	while ($objDac->fetch()) {
		$fld = $objDac->fld;
		$checked = '';
		$style = ' style="background-color:FFFFFF" ';
		if (in_array($fld['library_id'], $nonuse_library_id_Ary)) {
			$checked = ' checked ';
			$style = ' style="background-color:#BCBCBC" ';
		}
		$user_parmission = "【ウェブマスター専用】";
		if ($fld['user_parmission'] == 1) {
			$user_parmission = "【共通】";
		}
		$tmp = '<td width="33%" align="center" id="cms_library_td_' . $fld['library_id'] . '" ' . $style . '>';
		$tmp .= '<table border="0" class="cms8341-noneBorder">';
		$tmp .= '<tr><td colspan="2" align="left"><strong>' . $user_parmission . '</strong></td></tr>';
		$tmp .= '<tr><th colspan="2"><strong>' . $fld['name'] . '</strong></th></tr>';
		$tmp .= '<tr><td><label for="cms_library_' . $fld['library_id'] . '"><iframe src="' . RPW . '/admin/page/common/libview.php?tpl_id=' . $tpl_id . '&id=' . $fld['library_id'] . '" name="cms_thumb_' . $fld['library_id'] . '" id="cms_thumb_' . $fld['library_id'] . '" width="200px" height="130px" frameborder="0" scrolling="no" style="border:solid 1px #666"></iframe></label></td>';
		$tmp .= '<td><a href="javascript:" onClick="cxZoom(\'cms_thumb_' . $fld['library_id'] . '\',\'0\')"><img src="images/btn_zoomin.jpg" width="28" height="30" border="0"></a><br>';
		$tmp .= '<a href="javascript:" onClick="cxZoom(\'cms_thumb_' . $fld['library_id'] . '\',\'1\')"><img src="images/btn_zoomback.jpg" width="28" height="30" border="0"></a></td></tr>';
		$tmp .= '<tr><td colspan="2"><input type="checkbox" onClick="cxChangeDisp(cms_library_td_' . $fld['library_id'] . ',cms_library_' . $fld['library_id'] . ')" name="cms_library[]" id="cms_library_' . $fld['library_id'] . '" value="' . $fld['library_id'] . '" ' . $checked . '><label for="cms_library_' . $fld['library_id'] . '">使用しない</label></td></tr>';
		$tmp .= '</table>' . "\n";
		$tmp .= '</td>' . "\n";
		if ($fld['area'] == AREA_LIBRARY) {
			$lib_htmlAry[] = $tmp;
		}
		else {
			$edit_htmlAry[] = $tmp;
		}
		$lib_idAry[] = $fld['library_id'];
	}
}

//list format
if (count($lib_htmlAry) > 0) {
	$library_html = getLibraryListStr($lib_htmlAry);
}
else {
	$library_html = '<tr><td colspan="3" align="center" valign="top">現在、ライブラリは登録されていません。</td></tr>' . "\n";
}
if (count($edit_htmlAry) > 0) {
	$parts_html = getLibraryListStr($edit_htmlAry);
}
else {
	$parts_html = '<tr><td colspan="3" align="center" valign="top">現在、パーツは登録されていません。</td></tr>' . "\n";
}

function getLibraryListStr($ListAry) {
	$html = "";
	$tdCnt = 0;
	foreach ($ListAry as $value) {
		$tdCnt++;
		$html .= $value;
		if ($tdCnt == 3) {
			$html = "<tr>" . $html . "</tr>";
			$tdCnt = 0;
		}
		if (count($ListAry) == $tdCnt) {
			$dec = count($ListAry) % 3;
			for(; $dec < 3; $dec++) {
				$html .= '<td width="33%">&nbsp;</td>';
			}
			$html = "<tr>" . $html . "</tr>";
		}
	}
	return $html;
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>テンプレート一覧</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="template.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
var cms_sid;
var cms_inv_cnt = 0;
var cms_inv_tim = 200;
var cms_inv_max = 25;
var cms_now_zoom = 0;
function cxChangeDisp(td_id,ck_id){
	if($(ck_id).checked == true){
		Element.setStyle($(td_id),{'background-color':'#BCBCBC'});
	} else {
		Element.setStyle($(td_id),{'background-color':'#FFFFFF'});
	}
}
function cxSubmit(){
	document.tpl_form.submit();
	return false;
}
function cxInit() {
	var si,src;
	if(cms_sid) clearInterval(cms_sid);
	cms_sid = 0;
	cms_inv_cnt = 0;
	cms_sid = setInterval(cxIFrameZoom,cms_inv_tim);
}
function cxIFrameZoom() {
<?php
foreach ($lib_idAry as $value) {
	?>
	if($('cms_thumb_<?=$value?>').contentWindow.document.body){
            var styleBody = $('cms_thumb_<?=$value?>').contentWindow.document.body.style;
            styleBody.transformOrigin  = "0 0";
            styleBody.transform = 'scale(0.5)';
            styleBody.webkitTransformOrigin  = "0 0";
            styleBody.webkitTransform = 'scale(0.5)';
	}
	//
	cms_inv_cnt++;
	if(cms_inv_cnt > cms_inv_max) {
		clearInterval(cms_sid);
		cms_inv_cnt = 0;
	}
<?php
}
?>
}
function cxZoom(id,mode){
    var styleBody = $(id).contentWindow.document.body.style;
    var transform = styleBody.webkitTransform;
    var zoom = transform.substring(transform.indexOf("(") + 1, transform.indexOf(")"));
    if(mode == 1){
        if(zoom == 0.5){
                alert("これ以上は縮小できません");
                return;
        }
        var zoom = (zoom * 10 - 2) / 10;
    } else {
        var zoom = (zoom * 10 + 2) / 10;
    }
    styleBody.webkitTransform = 'scale(' + zoom + ')';
    styleBody.transform = 'scale(' + zoom + ')';
}
Event.observe(window,'load',cxInit,false);

//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'template';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<form id="tpl_form" class="cms8341-form" name="tpl_form"
	action="changeLibrary_comp.php" method="post">
<div align="center" id="cms8341-templates">
<div><img src="images/bar_use_library.jpg" alt="使用可能ライブラリ" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<th colspan="3"><?=$_POST['tpl_name']?></th>
		<?=$library_html?>
		</table>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<br>
<div align="center" id="cms8341-templates">
<div><img src="images/bar_use_parts.jpg" alt="使用可能パーツ" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<th colspan="3"><?=$_POST['tpl_name']?></th>
		<?=$parts_html?>
		</table>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<p align="center"><a href="javascript:" onClick="return cxSubmit()"><img
	src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
	height="20" border="0"></a>&nbsp;&nbsp;&nbsp; <a
	href="javascript:history.back()"><img
	src="<?=RPW?>/admin/master/images/btn_small_back.jpg" alt="戻る"
	width="120" height="20" border="0"></a></p>
<input type="hidden" id="tpl_id" name="tpl_id" value="<?=$tpl_id?>"></form>
</div>
<!-- cms8341-contents -->
</body>
</html>
