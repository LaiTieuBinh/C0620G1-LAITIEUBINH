<?php
/*
 *
 */
/** require **/
require ("./.htsetting");
define("PREV_TPL_PATH", RPW . "/upload/template/");
define("PREV_CSS_PATH", RPW . "/upload/editcss/");
define("PREV_XML_PATH", RPW . "/upload/stylexml/");
define("PREV_KANKO_XML_PATH", RPW . "/upload/kankoxml/");
$KANKO_TYPE = getDefineArray("KANKO_TYPE");
$ACC_CHECK_FLG = getDefineArray("SET_ACCESSIBILITY_CHECK");
# サブサイト対応
$USE_SITE_TYPE = getDefineArray("USE_SITE_TYPE_ARY");
$siteid_count = count($USE_SITE_TYPE);
$kanko_type_key = '';
# サブサイト対応

/** init **/
$dat = array();
$is_lock = lock_file_management('check'); // アップロード処理中か確認


//function 
function getApprove($a_id) {
	global $objCnc;
	$objDac = new dac($objCnc);
	$sql = "SELECT approve_id,name FROM tbl_approve ORDER BY approve_id";
	$objDac->execute($sql);
	//options
	$options = "";
	$cnt = $objDac->getRowCount();
	if ($cnt > 0) {
		while ($objDac->fetch()) {
			$app_id = $objDac->fld['approve_id'];
			$app_name = htmlDisplay($objDac->fld['name']);
			//
			if ($a_id && $a_id == $app_id) {
				$options .= '<option value="' . $app_id . '" selected>' . $app_name . '</option>';
			}
			else {
				$options .= '<option value="' . $app_id . '">' . $app_name . '</option>';
			}
		}
		return $options;
	}
	DispError("承認フローが登録されていません。<br>承認フロー管理において承認フローを登録してください。", 5, "javascript:history.back()");
	exit();
	return;
}

//main
if (isset($_POST["behavior"])) {
	$bv = $_POST["behavior"];
}
elseif (isset($_GET["behavior"])) {
	$bv = $_GET["behavior"];
}
else {
	DispError("パラメータ取得エラー(behavior)", 5, "javascript:history.back()");
	exit();
}
$app_disabled = '';
$app_hidden = '';
$dispChecked = "";
$display = '';
# サブサイト対応
$use_site_id_str = '';	
# サブサイト対応
switch ($bv) {
	case 1 :
		$label = 'テンプレート追加';
		$image = '<img src="images/bar_add.jpg" alt="テンプレート追加" width="920" height="30">';
		$dat = array(
				"tpl_id" => "", 
				"tpl_name" => "", 
				"app_id" => "", 
				"sort_order" => "", 
				"acc_flg" => "0", 
				"tpl_kind" => ""
		);
		$options = getApprove(false);
		$kind_str = "";
		foreach ($TEMPLATE_KIND as $key => $value) {
			if ($key == TEMPLATE_KIND_NONE) continue;
			$kind_str .= '<input type="radio" name="tpl_kind" id="tpl_kind_' . $key . '" value="' . $key . '" onclick="cxChange(\'' . $key . '\')"><label for="tpl_kind_' . $key . '">' . $value . '</label>&nbsp;&nbsp;&nbsp;';
		}
		$label_cssname = '';
		$label_xmlname = '';
		$label_kanko_xmlname = '';
		$kanko_type_str = "";
		$mobile_tpltxt = '';
		foreach ($KANKO_TYPE as $key => $value) {
		# サブサイト対応
			$kanko_type_key = $key;
			$kanko_type_str .= '<input type="radio" name="kanko_type" id="kanko_type_' . $key . '" value="' . $key . '" onclick="cxKankoTypeChange(\'' . $key . '\' , \'' . $siteid_count . '\')"><label for="kanko_type_' . $key . '">' . $value . '</label>&nbsp;&nbsp;&nbsp;';
		# サブサイト対応
		}
		# サブサイト対応
		$use_site_id_str .= '<select name="use_site_id" id="use_site_id">';
		foreach($USE_SITE_TYPE as $key => $value){
			$selected = ($key == USE_SITE_DEFAULT_ID)?' selected':'';
			$use_site_id_str .= "<option value=\"{$key}\"{$selected}>{$value}</option>";
		}
		$use_site_id_str .= '</select>';
		# サブサイト対応	
		break;
	case 2 :
		if (isset($_POST["tpl_id"])) {
			$id = $_POST["tpl_id"];
		}
		else {
			DispError("パラメータ取得エラー(tpl_id)", 5, "javascript:history.back()");
			exit();
		}
		$label = 'テンプレート修正';
		$image = '<img src="images/bar_fix.jpg" alt="テンプレート修正" width="920" height="30">';
		require ("./include/getRecord.inc");
		$dat = getRecord($id);
		$options = getApprove($dat["app_id"]);
		require ("./include/isUsedWorkPage.inc");
		if (isUsedWorkPage($_POST['tpl_id'])) {
			$app_disabled = ' disabled';
			$app_hidden = '<input type="hidden" name="app_id" value="' . $dat['app_id'] . '">';
		}
		$label_tpltxt = '<br><a href="' . RPW . '/admin/page/common/tplview.php?path=' . urlencode(DIR_PATH_TEMPLATE . $dat["tpl_txt"]) . '&dl=' . FLAG_ON . '" target="_blank">' . $dat["tpl_txt"] . "</a>";
		switch ($dat['tpl_kind']) {
			case TEMPLATE_KIND_FREE :
			case TEMPLATE_KIND_MOBILE :
			case TEMPLATE_KIND_ENQUETE :
				$label_cssname = '<br><a href="' . PREV_CSS_PATH . $dat["css_name"] . '" target="_blank">' . $dat["css_name"] . "</a>";
				$label_xmlname = '<br><a href="' . PREV_XML_PATH . $dat["xml_name"] . '" target="_blank">' . $dat["xml_name"] . "</a>";
				$label_kanko_xmlname = '<br><a href="' . PREV_KANKO_XML_PATH . $dat["kanko_xml_name"] . '" target="_blank">' . $dat["kanko_xml_name"] . "</a>";
				$kanko_type_str = '';
				$mobile_tpltxt = '';
				break;
			case TEMPLATE_KIND_FIXED :
				$label_cssname = '';
				$label_xmlname = '<br><a href="' . PREV_XML_PATH . $dat["xml_name"] . '" target="_blank">' . $dat["xml_name"] . "</a>";
				$label_kanko_xmlname = '<br><a href="' . PREV_KANKO_XML_PATH . $dat["kanko_xml_name"] . '" target="_blank">' . $dat["kanko_xml_name"] . "</a>";
				foreach ($KANKO_TYPE as $key => $value) {
					if ($dat["kanko_type"] != $key) continue;
					$kanko_type_key = $key;
					$kanko_type_str = $value . '<input type="hidden" name="kanko_type" value="' . $key . '">';
				}
				$mobile_tpltxt = '<br><a href="' . RPW . '/admin/page/common/tplview.php?path=' . urlencode(DIR_PATH_TEMPLATE . $dat["mobile_tpl_txt"]) . '" target="_blank">' . $dat["mobile_tpl_txt"] . "</a>";
				# サブサイト対応
				$use_site_id_str .= '<select name="use_site_id" id="use_site_id">';
				foreach($USE_SITE_TYPE as $key => $value){
					$selected = ($key == $dat["use_site_id"])?' selected':'';
					$use_site_id_str .= "<option value=\"{$key}\"{$selected}>{$value}</option>";
				}
				$use_site_id_str .= '</select>';	
				# サブサイト対応
				break;
			case TEMPLATE_KIND_NONE :
				$label_cssname = '';
				$label_xmlname = '';
				$label_kanko_xmlname = '';
				$kanko_type_str = '';
				$mobile_tpltxt = '';
				$label_tpltxt = '';
				$display = ' style="display:none"';
				break;
		}
		$kind_str = "";
		foreach ($TEMPLATE_KIND as $key => $value) {
			if ($dat["tpl_kind"] != $key) continue;
			$kind_str = $value . '<input type="hidden" name="tpl_kind" value="' . $key . '">';
		}
		if ($dat['disp'] == FLAG_OFF) {
			$dispChecked = " checked ";
		}
		
		break;
	default :
		DispError("パラメータエラー（behavior）", 5, "javascript:history.back()");
		exit();
		break;
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$label?></title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="template.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>
<script type="text/javascript">
<!--
function cxChange(kind) {
	
	Element.show('tpl_dependence_tr');
	
	switch(kind) {
		case TEMPLATE_KIND_FREE:
			Element.show('tpl_xml_tr');
			Element.show('cms_require_style_xml');
			Element.show('tpl_kanko_xml_tr');
			Element.hide('tpl_kanko_type_tr');
			Element.hide('tpl_mobile_htm_tr');
			// サブサイト対応
			Element.hide('tpl_use_site_id_tr');
			// サブサイト対応
			$('tpl_kanko_xml_span').innerHTML = "";
			break;
		case TEMPLATE_KIND_MOBILE:
		case TEMPLATE_KIND_ENQUETE:
			Element.show('tpl_xml_tr');
			Element.show('cms_require_style_xml');
			Element.show('tpl_kanko_xml_tr');
			Element.hide('tpl_kanko_type_tr');
			Element.hide('tpl_mobile_htm_tr');
			// サブサイト対応
			Element.hide('tpl_use_site_id_tr');
			// サブサイト対応			
			$('tpl_kanko_xml_span').innerHTML = "";
			break;
		case TEMPLATE_KIND_FIXED:
			Element.show('tpl_xml_tr');
			Element.hide('cms_require_style_xml');
			Element.show('tpl_kanko_xml_tr');
			Element.show('tpl_kanko_type_tr');
			Element.show('tpl_mobile_htm_tr');
			// サブサイト対応
			if( $('kanko_type_'+KANKO_TYPE_EVENT) && $('kanko_type_'+KANKO_TYPE_EVENT).checked ){
				Element.show('tpl_use_site_id_tr');
			}else{
				Element.hide('tpl_use_site_id_tr');
			}
			// サブサイト対応
			$('tpl_kanko_xml_span').innerHTML = "（必須）";
			break;
		default:
			alert('パラメータエラー');
			break;
	}
	return false;
}
// サブサイト対応
function cxKankoTypeChange(type,count) {
	if (type == KANKO_TYPE_EVENT && count > 1) {
		Element.show('tpl_use_site_id_tr');
	}
	else {
		Element.hide('tpl_use_site_id_tr');
	}
	return false;
}
// サブサイト対応
window.onload = function(){
	if($F('behavior') == 1){
		isChange = false;
		for (i = 0; i < document.tpl_form.tpl_kind.length; i++) {
		    if (document.tpl_form.tpl_kind[i].checked) {
				cxChange(document.tpl_form.tpl_kind[i].value);
				isChange = true;
		    }
		}
		if(isChange == false) cxChange(TEMPLATE_KIND_FREE);
	}
	// サブサイト対応
	var count = '<?php echo $siteid_count ?>';
	var type = '<?php echo $kanko_type_key ?>';
	cxKankoTypeChange(type,count);
	// サブサイト対応
}
//-->
</script>
</head>



<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'template';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><?=$image?></div>
<?php
if ($is_lock && $bv == 2) {
	?>
<div class="cms8341-areamessage" id="cms8341-denaillist-msg">
現在アップロード処理中のため即公開を行うことができません。<br>
即公開を行う場合はしばらく時間をおいてから再度お試しください。</div>
<?php
}
?>
<div class="cms8341-area-corner">
<form id="tpl_form" class="cms8341-form" name="tpl_form" method="post"
	action="confirm.php" enctype="multipart/form-data">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="200" align="left" valign="top" scope="row">テンプレート名 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle"><input id="tpl_name" name="tpl_name"
			type="text" style="width: 490px"
			value="<?=htmlspecialchars($dat["tpl_name"])?>"></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">テンプレート種類 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle">
<?=$kind_str?>
</td>
	</tr>
	<tr <?=$display?>>
		<th width="200" align="left" valign="top" scope="row">テンプレートファイル
<?php
if ($bv != 2) print '<br><span class="cms_require">（必須）</span>';
?>
</th>
		<td align="left" valign="middle"><input id="tpl_txt" name="tpl_txt"
			type="file" style="width: 490px" class="no-ime">
<?php
if ($bv == 2) print $label_tpltxt;
?>
</td>
	</tr>

	<tr id="tpl_dependence_tr" <?=$display?>>
		<th width="200" align="left" valign="top" scope="row">依存ファイル</th>
		<td align="left" valign="middle"><input id="tpl_dependence"
			name="tpl_dependence" type="file" style="width: 490px" class="no-ime">
<?php
if (file_exists(DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/')) {
	?>
<div style="font-size: small; padding: 5px; color: red;">※依存ファイルの展開フォルダにファイルが存在します。<br>
		[確認]を行うと、展開フォルダ内は上書きされます。他ユーザが作業中でないことを確認して作業を続けてください。</div>
<?php
}
?>
</td>
	</tr>

	<tr id="tpl_xml_tr"
		<?=($label_xmlname == "") ? ' style="display:none"' : '';?>>
		<th width="200" align="left" valign="top" scope="row">スタイル設定ファイル
<?php
if ($bv != 2 && $dat['tpl_kind'] != TEMPLATE_KIND_FIXED) {
	print '<br><span id="cms_require_style_xml" class="cms_require">（必須）</span>';
}
?>
</th>
		<td align="left" valign="middle"><input id="tpl_xml" name="tpl_xml"
			type="file" style="width: 490px" class="no-ime">
<?php
if ($bv == 2) print $label_xmlname;
?>
</td>
	</tr>
	<tr id="tpl_kanko_xml_tr"
		<?=($label_kanko_xmlname == "") ? ' style="display:none"' : '';?>>
		<th width="200" align="left" valign="top" scope="row">定型項目定義ファイル
<?php
if ($bv != 2) print '<br><span id="tpl_kanko_xml_span" class="cms_require">（必須）</span>';
?>
</th>
		<td align="left" valign="middle"><input id="tpl_kanko_xml"
			name="tpl_kanko_xml" type="file" style="width: 490px" class="no-ime">
<?php
if ($bv == 2) print $label_kanko_xmlname;
?>
</td>
	</tr>
	<tr id="tpl_mobile_htm_tr"
		<?=(($mobile_tpltxt == "") ? ' style="display:none"' : '');?>>
		<th width="200" align="left" valign="top" scope="row">携帯用テンプレートファイル</th>
		<td align="left" valign="middle"><input id="mobile_tpl_txt"
			name="mobile_tpl_txt" type="file" style="width: 490px" class="no-ime">
<?php
if ($bv == 2) print $mobile_tpltxt;
?>
</td>
	</tr>
	<tr id="tpl_kanko_type_tr"
		<?=($kanko_type_str == "") ? ' style="display:none"' : '';?>>
		<th width="200" align="left" valign="top" scope="row">用途 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle">
<?=$kanko_type_str?>
</td>
	</tr>
	<!-- // サブサイト対応 -->
	<tr id="tpl_use_site_id_tr"<?=($use_site_id_str=="")?' style="display:none;"':'';?>>
		<th width="200" align="left" valign="top" scope="row">サイト名 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle">
		<?=$use_site_id_str?>
		</td>
	</tr>
	<!-- // サブサイト対応 -->
	<tr>
		<th width="200" align="left" valign="top" scope="row">承認フロー <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle"><?=$app_hidden?><select id="app_id"
			name="app_id" <?=$app_disabled?>>
			<option <?php
			if ($bv == 1) print " selected";
			?> value="">--承認フローを選択してください--</option>
<?=$options?>	
</select></td>
	</tr>
<?php
if ($bv == 2) {
	?>
<tr>
		<th width="150" align="left" valign="top" scope="row">公開設定</th>
		<td align="left" valign="middle"><input type="checkbox" id="public"
			name="public" value="1" <?=($is_lock ? " disabled" : "")?>><label
			for="public">即公開する</label></td>
	</tr>
<?php
}
?>	
<tr>
		<th width="150" align="left" valign="top" scope="row">表示設定</th>
		<td align="left" valign="middle"><input type="checkbox" id="disp"
			name="disp" value="0" <?=$dispChecked?>><label for="disp">非表示にする</label></td>
	</tr>
	<tr <?=$display?>>
		<th width="200" align="left" valign="top" scope="row">言語設定 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle">
<?=mkradiobutton($ACC_CHECK_FLG, "acc_flg", $dat["acc_flg"])?>
</td>
	</tr>
</table>
<p align="center"><input type="image" src="../images/btn_conf.jpg"
	alt="確認" width="150" height="20" border="0" style="margin-right: 10px"><a
	href="index.php"><img src="../../images/btn/btn_cansel_large.jpg"
	alt="キャンセル" width="150" height="20" border="0"
	style="margin-left: 10px"></a></p>
<input type="hidden" id="tpl_id" name="tpl_id"
	value="<?=$dat["tpl_id"]?>"> <input type="hidden" id="sort_order"
	name="sort_order" value="<?=$dat["sort_order"]?>"> <input type="hidden"
	id="behavior" name="behavior" value="<?=$bv?>"></form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
