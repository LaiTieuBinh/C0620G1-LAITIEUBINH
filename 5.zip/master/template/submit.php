<?php
/*
 *
 */
/** require **/
require ("./.htsetting");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>テンプレート即公開</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="template.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxdisplay() {
	$('css_disp').style.display = 'none';
	$('conf_disp').style.display = 'inline';
}
//-->	
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'template';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
require_once (APPLICATION_ROOT . '/common/function/func_progressbar.inc');
$pgrs_func = new progressbar();
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><img src="images/bar_recreate.jpg" alt="テンプレート確認" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?=$pgrs_func->get_progress_area()?>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>


<?php
/** init **/
$dat = array();
/** get post data **/
$bv = $_POST["behavior"];
$tpl_id = $_SESSION["hidden"]["tpl_id"];
$tpl_name = $_SESSION["hidden"]["tpl_name"];
$tpl_kind = $_SESSION["hidden"]["tpl_kind"];
$tpl_txt = $_SESSION["hidden"]["tpl_txt"];
$acc_flg = $_SESSION["hidden"]["acc_flg"];

// サブサイト対応
$tpl_use_site_id = '';
// サブサイト対応

switch ($tpl_kind) {
	case TEMPLATE_KIND_FREE :
		$tpl_xml = $_SESSION["hidden"]["xml_name"];
		$tpl_kanko_xml = $_SESSION["hidden"]["kanko_xml_name"];
		$tpl_kanko_type = "0";
		$tpl_mobile_tpl_txt = "";
		break;
	case TEMPLATE_KIND_MOBILE :
	case TEMPLATE_KIND_ENQUETE :
		$tpl_xml = $_SESSION["hidden"]["xml_name"];
		$tpl_kanko_xml = $_SESSION["hidden"]["kanko_xml_name"];
		$tpl_kanko_type = "0";
		$tpl_mobile_tpl_txt = "";
		break;
	case TEMPLATE_KIND_FIXED :
		$tpl_xml = isset($_SESSION["hidden"]["xml_name"]) ? $_SESSION["hidden"]["xml_name"] : "";
		$tpl_kanko_xml = $_SESSION["hidden"]["kanko_xml_name"];
		$tpl_kanko_type = $_SESSION["hidden"]["kanko_type"];
		// サブサイト対応
		if($tpl_kanko_type == KANKO_TYPE_EVENT){
			$tpl_use_site_id = $_SESSION["hidden"]["use_site_id"];
		}
		// サブサイト対応
		$tpl_mobile_tpl_txt = $_SESSION["hidden"]["mobile_tpl_txt"];
		break;
}

$app_id = $_SESSION["hidden"]["app_id"];
if ($bv == 2) {
	$public = $_SESSION["hidden"]["public"];
	$sort = $_SESSION["hidden"]["sort_order"];
}
$disp = $_SESSION["hidden"]["disp"];

if (isset($_SESSION["hidden"]["tpl_dependence"]["aryFiles"])) $aryFiles = $_SESSION["hidden"]["tpl_dependence"]["aryFiles"];
$aryDelList = array();
if (isset($_SESSION["hidden"]["tpl_dependence"]["aryDelList"])) $aryDelList = $_SESSION["hidden"]["tpl_dependence"]["aryDelList"];
if (isset($_SESSION["hidden"]["tpl_dependence"]["aryImp"])) $aryImp = $_SESSION["hidden"]["tpl_dependence"]["aryImp"];
/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

switch ($bv) {
	case 1 :
		require ("./include/insert.inc");
		break;
	case 2 :
		require ("./include/getRecord.inc");
		$dat = getRecord($tpl_id);
		require ("./include/update.inc");
		break;
	case 3 :
		require ("./include/delete.inc");
		break;
	default :
		DispError("パラメータ取得エラー（behavior）", 6, "javascript:history.back()");
		exit();
		break;
}
?>

</body>
</html>
