<?php
/*
 * 定型項目表示登録画面
 */
/** require **/
require ("./.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');

global $objCnc;
$objHandler = new tbl_handler($objCnc);

// パラメータチェック	
if (!isset($_POST['tpl_id']) || $_POST['tpl_id'] == "") {
	DispError("パラメータ取得エラー(tpl_id)", 5, "javascript:history.back()");
	exit();
}
$template_id = $_POST['tpl_id'];

// トランザクション開始
$objCnc->begin();
// 現在の定型項目表示設定を削除
$objHandler->deleteKankoDisp($template_id);
foreach ($_SESSION['kankoDisp'] as $id) {
	$insAry = array();
	$insAry['template_id'] = $template_id;
	$insAry['xml_id'] = $id;
	// 現在の定型項目情示設定を登録
	$objHandler->insertKankoDisp($insAry);
}
// コミット
$objCnc->commit();

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>定型項目表示設定</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="template.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'template';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<form id="tpl_form" class="cms8341-form" name="tpl_form"
	action="kankoDispSetting_submit.php" method="post"><input type="hidden"
	id="tpl_id" name="tpl_id" value="<?=$template_id?>">
<div align="center" id="cms8341-templates">
<div><img src="images/bar_kanko_disp.jpg" alt="定型項目表示設定" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<p align="left">設定が完了しました。</p>
<p align="center"><a href="index.php"><img
	src="<?=RPW?>/admin/master/images/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0" style="margin-left: 10px"></a></p>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</form>
</div>
<!-- cms8341-contents -->
</body>
</html>
