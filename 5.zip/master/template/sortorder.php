<?php
/*
 * テンプレート管理　表示順序変更画面(sortorder.php)
 */
$StrDbg = "";
$GLOBALS["StrDbg"] = "";

/*---------------------------------------------------------------------------------
	form.php
	
	パラメーター
	level:指定されたカテゴリレベル
	cate_code：指定されたカテゴリコード
	d_l:一覧画面の表示レベル
	d_c：一覧画面で対象となっているカテゴリコード
	
---------------------------------------------------------------------------------*/

/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

/*--- データアクセスクラス ---*/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objDacTools = new dac_tools($objCnc);

/*---表示項目の取得---*/
$BakURL = "javascript:history.back()";
$ResURL = "./sortorder.php";
//画面項目の取得
$DspList = "";
$DspLstCnt = G_GetTemplateList($objDacTools, $DspList, $DspMsg);

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	表示リストの作成

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateLevel	指定されたカテゴリレベル
		$i_CateCode		指定されたカテゴリコード
		$o_DspList		表示リストの格納先
		$o_DspMsg		表示されるメッセージ
		
【戻値】	取得されたデータ数	
		
【備考】
-----------------------------------------------------------------------------*/
function G_GetTemplateList($objDacTools, &$o_DspList, &$o_DspMsg) {
	
	//---SQL部品の作成
	$sql_level = 0;
	$sql_like = "";
	$sql = "SELECT distinct template_id FROM tbl_template order by sort_order";
	
	//---取得
	$template_ary = array();
	$objDacTools->execute($sql);
	//---一件も下位カテゴリが存在しなかった
	if ($objDacTools->getRowCount() <= 0) {
		$o_DspMsg = "<p>対象となるテンプレートが存在しませんでした。</p>";
	}
	
	while ($objDacTools->fetch()) {
		//if($objDacTools->fld['template_id'] == TEMPLATE_ID_NONE) continue;
		$template_ary[] = $objDacTools->fld['template_id'];
	}
	//---成形
	$o_DspList = "";
	$dat_cnt = 0;
	foreach ($template_ary as $template_id) {
		$fld = $objDacTools->selectTemplate($template_id);
		$o_DspList = $o_DspList . "<tr>\n";
		//入力エリア
		$o_DspList = $o_DspList . "<td width=\"150\" align=\"center\" valign=\"middle\">";
		$o_DspList = $o_DspList . "<input type=\"text\" style=\"width:100px;text-align:center\" id = \"" . $fld['template_id'] . "\" name = \"" . $fld['template_id'] . "\"value=\"" . $fld['sort_order'] . "\"></td>\n";
		//テンプレート名
		$o_DspList = $o_DspList . "<td align=\"left\" valign=\"top\">" . htmlspecialchars($fld['name']) . "</td>\n";
		$o_DspList = $o_DspList . "</tr>\n";
		$dat_cnt++;
	}
	
	return ($dat_cnt);

}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>テンプレート表示順変更</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="template.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxSubmit(){
	for (i = 0; i < document.getElementsByTagName("INPUT").length; i++) {
		if(document.getElementsByTagName("INPUT")[i].type != "text")continue;
	    value = document.getElementsByTagName("INPUT")[i].value;
		if (value != "" && value.match(/[^0-9]+/)) {
		    alert("半角数字でない箇所があります。半角数字で入力してください。");
		    return false;
	    }
	}
	$('Form').submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?=$GLOBALS["StrDbg"]?>

<?php
// ヘッダーメニュー挿入
$headerMode = 'template';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-categoryform">
<div><img src="images/bar_listorder.jpg" alt="テンプレート表示順変更" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?=$DspMsg?>
<form class="cms8341-form" method="POST" action="./sortorder_comp.php"
	id="Form" name="Form">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
<?php
if (strlen($DspList) > 0) {
	?>
<th width="150" align="center" valign="middle" scope="col">表示順 <span
			class="cms_require">（必須）</span></th>
		<th align="center" valign="middle" scope="col">テンプレート名</th>
<?php
}
?>
</tr>
<?=$DspList?> 
</table>
<?php
if (strlen($DspList) > 0) {
	?>
<p align="center"><input type="image" onClick="return cxSubmit()"
	src="images/btn_listorder.jpg" alt="表示順を変更" width="150" height="20"
	border="0" style="margin-right: 10px"> <a href="<?=$ResURL?>"><img
	src="images/btn_reset.jpg" alt="リセット" width="150" height="20"
	border="0" style="margin-left: 10px"></a></p>
<?php
}
?>
<p align="left"><a href="<?=$BakURL?>"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel.jpg" alt="キャンセル" width="101"
	height="21" border="0"></a></p>
</form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
