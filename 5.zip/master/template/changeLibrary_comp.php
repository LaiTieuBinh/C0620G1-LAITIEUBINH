<?php
/*
 * テンプレート管理　使用可能ライブラリ更新処理(changeLibrary_comp.php)
 */
/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

//main
if (isset($_POST["tpl_id"])) {
	$tpl_id = $_POST["tpl_id"];
}
else {
	DispError("パラメータ取得エラー(tpl_id)", 5, "javascript:history.back()");
	exit();
}

//処理モード
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

$nonuse_library_id = "";
if (isset($_POST['cms_library'])) {
	foreach ($_POST['cms_library'] as $value) {
		$nonuse_library_id .= $value . ",";
	}
	if (substr($nonuse_library_id, -1, 1) == ",") {
		$nonuse_library_id = substr($nonuse_library_id, 0, strlen($nonuse_library_id) - 1);
	}
}

// トランザクション開始
$objCnc->begin();
$sql = "UPDATE tbl_template SET nonuse_library_id='" . $nonuse_library_id . "' " . "WHERE template_id='" . gd_addslashes($tpl_id) . "'";
$objDac->execute($sql);

// コミット
$objCnc->commit();

/*---一覧画面へと戻る---*/
header("Location: " . "./index.php");

?>
