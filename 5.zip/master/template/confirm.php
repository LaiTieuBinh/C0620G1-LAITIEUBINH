<?php
/*
 *
 */
/** require **/
require ("./.htsetting");

/** init **/
$dat = array();
unset($_SESSION["hidden"]);
$is_lock = lock_file_management('check'); // アップロード処理中か確認


require ("./setting_filepath.inc");
$KANKO_TYPE = getDefineArray("KANKO_TYPE");
$ACC_CHECK_FLG = getDefineArray("SET_ACCESSIBILITY_CHECK");
// サブサイト対応
$USE_SITE_TYPE = getDefineArray("USE_SITE_TYPE_ARY");
$siteid_count = count($USE_SITE_TYPE);
// サブサイト対応

/** function **/
function getPostData($bv, $nowTplInfo = "") {
	
	global $objCnc;
	
	$dat = array();
	if (isset($_POST["tpl_id"])) $dat["tpl_id"] = $_POST["tpl_id"];
	if (isset($_POST["tpl_name"])) $dat["tpl_name"] = $_POST["tpl_name"];
	if (isset($_POST["tpl_kind"])) $dat["tpl_kind"] = $_POST["tpl_kind"];
	if (isset($_POST["acc_flg"])) $dat["acc_flg"] = $_POST["acc_flg"];
	$dat["tpl_txt"] = basename($_FILES["tpl_txt"]["name"]);
	$dat["tpl_dependence"]['name'] = basename($_FILES["tpl_dependence"]["name"]);
	$dat["xml_name"] = basename($_FILES["tpl_xml"]["name"]);
	$dat["kanko_xml_name"] = basename($_FILES["tpl_kanko_xml"]["name"]);
	$dat["mobile_tpl_txt"] = basename($_FILES["mobile_tpl_txt"]["name"]);
	if (isset($_POST["kanko_type"])) $dat["kanko_type"] = $_POST["kanko_type"];
	if (isset($_POST["app_id"])) $dat["app_id"] = $_POST["app_id"];
	// サブサイト対応
	if (isset($_POST["use_site_id"])) $dat["use_site_id"] = $_POST["use_site_id"];
	// サブサイト対応
	
	$msg = "";
	if (!isset($dat["tpl_id"])) $msg .= "テンプレートID取得エラー<br>";
	if (!isset($dat["tpl_name"]) || $dat["tpl_name"] == "") {
		$msg .= "テンプレート名が入力されていません。<br>";
	}
	elseif (!checkMachineCode($dat["tpl_name"])) {
		$msg .= "テンプレート名に機種依存文字が使用されています。<br>";
	}
	if (isset($_POST["sort_order"])) $dat["sort_order"] = $_POST["sort_order"];
	
	//
	if ($bv != 2) {
		if (!isset($dat["tpl_txt"]) || $dat["tpl_txt"] == "" || !is_uploaded_file($_FILES['tpl_txt']['tmp_name'])) {
			$msg .= "テンプレートファイルが選択されていません。<br>";
		}
		if (file_exists($_FILES['tpl_dependence']['tmp_name']) && !is_uploaded_file($_FILES['tpl_dependence']['tmp_name'])) {
			$msg .= "依存ファイルの指定が正しくありません。<br>";
		}
		if (!isset($dat["tpl_kind"]) || $dat["tpl_kind"] == "") {
			$msg .= "テンプレート種類が選択されていません。<br>";
		}
		else {
			switch ($dat["tpl_kind"]) {
				case TEMPLATE_KIND_FREE :
				case TEMPLATE_KIND_MOBILE :
				case TEMPLATE_KIND_ENQUETE :
					if (!isset($dat["xml_name"]) || $dat["xml_name"] == "" || !is_uploaded_file($_FILES['tpl_xml']['tmp_name'])) {
						$msg .= "スタイル設定ファイルが選択されていません。<br>";
					}
					$dat["kanko_type"] = "";
					$dat["mobile_tpl_txt"] = "";
					// サブサイト対応
					$dat["use_site_id"] = "";
					// サブサイト対応
					break;
				case TEMPLATE_KIND_FIXED :
					// イベント末端TPLの親ページ設定自由化
					// if (!isset($dat["kanko_xml_name"]) || $dat["kanko_xml_name"] == "" || !is_uploaded_file($_FILES['tpl_kanko_xml']['tmp_name'])) {
					// 	$msg .= "スタイル設定ファイルが選択されていません。<br>";
					// }
					if (!isset($dat["kanko_type"]) || $dat["kanko_type"] == "") {
						$msg .= "用途が選択されていません。<br>";
					}
					// サブサイト対応
					else{
						if (($dat['kanko_type'] == KANKO_TYPE_EVENT ) && 
							(!isset($dat["use_site_id"]) || $dat["use_site_id"] == "") ) {
								$msg .= "サイト名が選択されていません。<br>";
						}
					}
					// サブサイト対応
					break;
			}
		}
	}
	//
	if (isset($dat["tpl_txt"]) && $dat["tpl_txt"] != "" && is_uploaded_file($_FILES['tpl_txt']['tmp_name'])) {
		if ($_FILES['tpl_txt']['size'] <= 0) {
			$msg .= "テンプレートファイルのファイルサイズが0バイトです。<br>";
		}
		elseif (!preg_match('/(\.html$)|(\.htm$)|(\.xhtml$)|(\.txt$)|(\.dwt$)/i', $dat["tpl_txt"])) {
			$msg .= "選択されたテンプレートファイルはテンプレートとして適切なファイルではありません。<br>";
		}
		elseif (preg_match('/[^\w\-_\.~]/i', $dat['tpl_txt'])) {
			$msg .= "選択されたテンプレートファイルにはファイル名としてふさわしくない文字が使用されています。<br>";
		}
	}
	// ** 依存ファイルチェック -- ------------------
	if (isset($dat["tpl_dependence"]['name']) && $dat["tpl_dependence"]['name'] != "" && is_uploaded_file($_FILES['tpl_dependence']['tmp_name'])) {
		// ファイルサイズがゼロならエラー
		if ($_FILES['tpl_dependence']['size'] <= 0) {
			$msg .= '依存ファイルの指定が正しくないか、取り込みファイルのファイルサイズが大きすぎる可能性があります。<br>';
		}
		// 取り込みファイルはzip圧縮のファイルでなければエラー
		if (!preg_match('/\.zip$/i', $_FILES['tpl_dependence']['name'])) {
			$msg .= '依存ファイルはzip形式の圧縮ファイルを指定してください。<br>';
		}
	}
	// ** -- ---------------------------------------
	if (isset($dat["xml_name"]) && $dat["xml_name"] != "" && is_uploaded_file($_FILES['tpl_xml']['tmp_name'])) {
		if ($_FILES['tpl_xml']['size'] <= 0) {
			$msg .= "スタイル設定ファイルのファイルサイズが0バイトです。<br>";
		}
		elseif (!preg_match('/(\.xml$)|(.txt$)/i', $dat["xml_name"])) {
			$msg .= "選択されたスタイル設定ファイルは適切なファイルではありません。<br>";
		}
		elseif (preg_match('/[^\w\-_\.~]/i', $dat['xml_name'])) {
			$msg .= "選択されたスタイル設定ファイルにファイル名としてふさわしくない文字が使用されています。<br>";
		}
		else {
			//上書きチェック
			if (file_exists(REAL_XML_PATH . $dat["xml_name"])) {
				global $xmlfile_msg;
				$xmlfile_msg = "注意！サーバー上に同名ファイルの" . $dat["xml_name"] . "が存在するため、このまま登録すると上書きされます。";
			}
		}
	}
	if (isset($dat["kanko_xml_name"]) && $dat["kanko_xml_name"] != "" && is_uploaded_file($_FILES['tpl_kanko_xml']['tmp_name'])) {
		if ($_FILES['tpl_kanko_xml']['size'] <= 0) {
			$msg .= "定型項目定義ファイルのファイルサイズが0バイトです。<br>";
		}
		elseif (!preg_match('/(\.xml$)|(.txt$)/i', $dat["kanko_xml_name"])) {
			$msg .= "選択された定型項目定義ファイルは適切なファイルではありません。<br>";
		}
		elseif (preg_match('/[^\w\-_\.~]/i', $dat['kanko_xml_name'])) {
			$msg .= "選択された定型項目定義ファイルにファイル名としてふさわしくない文字が使用されています。<br>";
		}
		else {
			//上書きチェック
			if (file_exists(REAL_KANKO_XML_PATH . $dat["kanko_xml_name"])) {
				global $kankoxmlfile_msg;
				$kankoxmlfile_msg = "注意！サーバー上に同名ファイルの" . $dat["kanko_xml_name"] . "が存在するため、このまま登録すると上書きされます。";
			}
		}
	}
	
	if (isset($dat["mobile_tpl_txt"]) && $dat["mobile_tpl_txt"] != "" && is_uploaded_file($_FILES['mobile_tpl_txt']['tmp_name'])) {
		if ($_FILES['mobile_tpl_txt']['size'] <= 0) {
			$msg .= "携帯用テンプレートファイルのファイルサイズが0バイトです。<br>";
		}
		elseif (!preg_match('/(\.html$)|(\.htm$)|(\.xhtml$)|(\.txt$)|(\.dwt$)/i', $dat["mobile_tpl_txt"])) {
			$msg .= "選択された携帯用テンプレートファイルはテンプレートとして適切なファイルではありません。<br>";
		}
		elseif (preg_match('/[^\w\-_\.~]/i', $dat['mobile_tpl_txt'])) {
			$msg .= "選択された携帯用テンプレートファイルにはファイル名としてふさわしくない文字が使用されています。<br>";
		}
	}
	
	//
	if (!isset($dat["app_id"]) || $dat["app_id"] == "") {
		$msg .= "承認フローが選択されていません。<br>";
	}
	if (!isset($dat["acc_flg"]) || $dat["acc_flg"] == "") {
		$msg .= "言語設定が選択されていません。<br>";
	}
	if ($msg != "") {
		DispError($msg, 5, "javascript:history.back()");
		exit();
	}
	
	$mode_ary = array(
		'mobile' => '携帯'
	);
	foreach ((array) $mode_ary as $mode => $name) {
		if (isset($dat[$mode . "_tpl_txt"]) && $dat[$mode . "_tpl_txt"] != "" && is_uploaded_file($_FILES[$mode . '_tpl_txt']['tmp_name'])) {
			$msg = "";
			// 自動生成用ダミーファイルチェック
			if ($bv == 2 && isset($dat['tpl_id']) && $dat['tpl_id'] != "") {
				require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
				$objPage = new tbl_page($objCnc);
				$objPage2 = new tbl_page($objCnc);
				require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
				$objTool = new dac_tools($objCnc);
				
				// 最新のテンプレート情報取得
				$tmp_fld = $objTool->selectTemplate($dat['tpl_id']);
				if ($tmp_fld != FALSE) {
					// 自動生成テンプレートが登録されていなかった場合
					if (!isset($tmp_fld[$mode . '_temp_txt']) || $tmp_fld[$mode . '_temp_txt'] == "") {
						$file_path_ary = array();
						// 編集中・公開中テーブルチェック
						$tbl_ary = array(
							WORK_TABLE, 
							PUBLISH_TABLE
						);
						foreach ((array) $tbl_ary as $tbl) {
							// テーブルセット
							$objPage->setTableName($tbl);
							// 条件作成
							$where = $objPage->_addslashesC('template_id', $dat['tpl_id']);
							// 取得カラム名
							$fields = 'page_id,file_path';
							// 検索
							$objPage->select($where, $fields);
							while ($objPage->fetch()) {
								$err_flg = FLAG_OFF;
								// ファイルパス取得
								$file_path = $objPage->fld['file_path'];
								// 自動生成ページパス
								if ($mode == 'mobile') {
									$file_path = DIR_PATH_MOBILE . $file_path;
								}
								// 自動生成スマートフォンページパス（ルートパス）
								$root_file_path = DOCUMENT_ROOT . RPW . $file_path;
								
								// DBチェック
								foreach ((array) $tbl_ary as $tbl2) {
									if ($objPage2->selectFromPath($file_path, $tbl2)) {
										$err_flg = FLAG_ON;
										break;
									}
								}
								// 実ファイルチェック
								if (!$err_flg) {
									if (@file_exists($root_file_path)) {
										$err_flg = FLAG_ON;
									}
								}
								// エラーメッセージ(一度出力したファイルパスは出力しない)
								if ($err_flg && !in_array($file_path, $file_path_ary)) {
									$msg .= "<li>【" . $file_path . "】自動生成先にすでにページが存在します</li>";
									// エラーファイルパスを保持
									$file_path_ary[] = $file_path;
								}
							}
						}
					}
				}
			}
			if ($msg != "") {
				$msg = $name . "用テンプレートの登録が行えません。" . $msg;
				DispError($msg, 5, "javascript:history.back()");
				exit();
			}
		}
	}
	
	//承認フロー名の取得
	require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
	$objDac = new dac($objCnc);
	//
	$sql = "SELECT name FROM tbl_approve WHERE approve_id=" . $dat["app_id"];
	$objDac->execute($sql);
	$objDac->fetch();
	$dat["app_name"] = $objDac->fld["name"];
	if (!isset($dat["app_name"])) {
		DispError("承認フロー名の取得に失敗しました。", 5, "javascript:history.back()");
		exit();
	}
	
	//仮アップロード処理
	global $objLogin;
	$login = $objLogin->login;
	$usr_id = $login["user_id"];
	//*ごみの削除
	if (file_exists(TMP_UPLOAD_PATH . $usr_id . TMP_FILE_TPL)) unlink(TMP_UPLOAD_PATH . $usr_id . TMP_FILE_TPL);
	if (file_exists(TMP_UPLOAD_PATH . $usr_id . TMP_FILE_XML)) unlink(TMP_UPLOAD_PATH . $usr_id . TMP_FILE_XML);
	if (file_exists(TMP_UPLOAD_PATH . $usr_id . TMP_FILE_KANKO_XML)) unlink(TMP_UPLOAD_PATH . $usr_id . TMP_FILE_KANKO_XML);
	if (file_exists(TMP_UPLOAD_PATH . $usr_id . TMP_FILE_MOBILE_TPL)) unlink(TMP_UPLOAD_PATH . $usr_id . TMP_FILE_MOBILE_TPL);
	//*仮アップロード
	if (isset($dat["tpl_txt"]) && $dat["tpl_txt"] != "") {
		if (move_uploaded_file($_FILES['tpl_txt']['tmp_name'], TMP_UPLOAD_PATH . $usr_id . TMP_FILE_TPL) == FALSE) {
			DispError("テンプレートファイルの仮アップロードに失敗しました。", 5, "javascript:history.back()");
			exit();
		}
		checkFile($usr_id . TMP_FILE_TPL);
		$tpl_fn = TMP_UPLOAD_PATH . $usr_id . TMP_FILE_TPL;
		$str = file_get_contents($tpl_fn);
		if (!preg_match('/<body\s*(class="[^\"]*")?>/i', $str)) {
			DispError("BODYタグが存在しないまたは、BODYタグにクラス以外の属性があります。<br>BODYタグにはクラス以外の属性を付けないでください。", 5, "javascript:history.back()");
			exit();
		}
	}
	if (isset($dat["xml_name"]) && $dat["xml_name"] != "") {
		if (move_uploaded_file($_FILES['tpl_xml']['tmp_name'], TMP_UPLOAD_PATH . $usr_id . TMP_FILE_XML) == FALSE) {
			DispError("スタイル設定ファイルの仮アップロードに失敗しました。", 5, "javascript:history.back()");
			exit();
		}
	}
	// ** 依存ファイル作業フォルダに -- ------------
	if (isset($dat["tpl_dependence"]['name']) && $dat["tpl_dependence"]['name'] != "") {
		// 対象ディレクトリが存在しなければ作成
		if (!@file_exists(DEPENDENCE_PUBLISH_DIR)) {
			if (!mkNewDirectory(DEPENDENCE_PUBLISH_DIR)) {
				DispError("依存ファイルアップロード先フォルダの生成に失敗しました。", 5, "javascript:history.back()");
				exit();
			}
		}
		// 取り込みファイルの展開ディレクトリ
		chmodAll(DEPENDENCE_WORK_DIR . "/", 0777);
		if (@file_exists(DEPENDENCE_WORK_DIR . "/")) removeDir(DEPENDENCE_WORK_DIR . "/");
		if (!@mkdir(DEPENDENCE_WORK_DIR . "/", 0777)) {
			DispError('依存ファイルの展開フォルダ作成に失敗しました。', 5, "javascript:history.back()");
			exit();
		}
		chmod(DEPENDENCE_WORK_DIR . "/", 0777);
		// 圧縮ファイルを解凍する
		if (defined("SET_UNZIP_EXE")) {
			exec(SET_UNZIP_EXE . ' ' . $_FILES['tpl_dependence']['tmp_name'] . ' ' . DEPENDENCE_WORK_DIR . "/");
		}
		else {
			exec('unzip ' . $_FILES['tpl_dependence']['tmp_name'] . ' -d ' . DEPENDENCE_WORK_DIR . "/");
		}
		// 取り込みファイルの確認
		$aryFiles = array();
		$aryDelList = array();
		$chk = array(
				"err_mes" => "取り込めません", 
				"file_name" => true, 
				"dir_name" => true, 
				"capital" => true, 
				"dot" => true, 
				"zero_byte" => true, 
				"size" => true, 
				"edit_css" => true
		);
		sharedChkFiles('', DEPENDENCE_PUBLISH_DIR, DEPENDENCE_WORK_DIR, $chk, $aryFiles, $aryDelList);
		
		$msg = "";
		$DEPENDENCE_UPLOAD_TRUE_DIR = getDefineArray('DEPENDENCE_UPLOAD_TRUE_DIR');
		foreach ($aryFiles as $fileInfo) {
			if ($fileInfo['error'] == true) {
				$msg .= "<li>【" . $fileInfo['file_path'] . "】" . $fileInfo['message'] . "</li>";
			}
			else {
				$dirFlg = FLAG_OFF;
				foreach ($DEPENDENCE_UPLOAD_TRUE_DIR as $dir_key) {
					if (preg_match($dir_key, $fileInfo['file_path'])) {
						$dirFlg = FLAG_ON;
					}
				}
				if ($dirFlg == FLAG_OFF) {
					$msg .= "<li>【" . $fileInfo['file_path'] . "】指定されたファイルはアップロードできません。</li>";
				}
			}
		}
		
		if ($msg != "") {
			DispError($msg, 5, "javascript:history.back()");
			exit();
		}
		
		$tpl_fn = "";
		if (isset($dat["tpl_txt"]) && $dat["tpl_txt"] != "") {
			$tpl_fn = TMP_UPLOAD_PATH . $usr_id . TMP_FILE_TPL;
		}
		elseif (isset($nowTplInfo['tpl_txt'])) {
			$tpl_fn = DOCUMENT_ROOT . DIR_PATH_TEMPLATE . $nowTplInfo['tpl_txt'];
		}
		
		// テンプレートが同時にアップされていたら edit.css の修正(アップされていない場合、更新の時は既存テンプレートを参照)
		if ($tpl_fn != "") {
			if (@file_exists($tpl_fn)) {
				$editcss_name = "";
				//$tpl_fn = TMP_UPLOAD_PATH . $usr_id . TMP_FILE_TPL;
				// edit.css の記述を探す
				$search_file = searchEditCSS($tpl_fn, $aryFiles);
				// あれば edit.css を一覧から探す
				if ($search_file != false) {
					
					if (count($search_file) > 1) {
						DispError("テンプレートにエディタ用スタイルシートが複数指定されています。", 5, "javascript:history.back()");
						exit();
					}
					//　エディタ用スタイルシートの名前を取得
					$edit_ary = explode("/", $search_file[0]);
					if ($edit_ary[0]) $editcss_name = $edit_ary[0] . TMP_FILE_CSS;
					//エディタ用スタイルシートの名前の取得失敗
					if ($editcss_name == "") {
						DispError("テンプレートに指定されたエディタ用スタイルシートの指定が間違っています。", 5, "javascript:history.back()");
						exit();
					}
					$replace_file = "";
					$edit_pattern = "/.*\/" . reg_replace(DEPENDENCE_EDIT_CSS) . "/i";
					foreach ($aryFiles as $key => $fileInfo) {
						$p_file_path = preg_replace("/^\//i", "", $fileInfo['file_path']);
						if (in_array($p_file_path, $search_file)) {
							$aryFiles[$key]['editcss'] = true;
							$replace_file = $fileInfo['file_path'];
							$aryFiles[$key]['tpl_css'] = $editcss_name;
						}
						else if (preg_match($edit_pattern, $p_file_path)) {
							DispError("依存ファイルに指定と違うエディタ用スタイルシートがあります。", 5, "javascript:history.back()");
							exit();
						}
					}
					// エディタ用スタイルシートがない
					if ($replace_file == "") {
						if ($bv == 1) {
							if (checkCss($search_file[0], $editcss_name) == false) {
								DispError("テンプレートに指定されたエディタ用スタイルシートが存在しません", 5, "javascript:history.back()");
								exit();
							}
							$dat["tpl_dependence"]["conf_str"] = $editcss_name;
						}
					}
					else {
						if (filesize(DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . "/" . $replace_file) <= 0) {
							DispError("エディタ用スタイルシートのファイルサイズが0バイトです。", 5, "javascript:history.back()");
							exit();
						}
					}
				}
				elseif ($bv == 1 && $dat["tpl_kind"] != TEMPLATE_KIND_FIXED) {
					// 新規登録時にエディタ用スタイルシートが存在しない場合
					DispError("テンプレートにエディタ用スタイルシートの指定がないか、指定が間違っています。", 5, "javascript:history.back()");
					exit();
				}
				//テンプレートのからインポート用のCSS作成に必要な情報取得
				$imp_style_ary = searchStylesheet($tpl_fn, $editcss_name);
			}
		}
		// 取得したデータを代入
		$dat["tpl_dependence"]['aryFiles'] = $aryFiles;
		$dat["tpl_dependence"]['aryDelList'] = $aryDelList;
		if ($imp_style_ary != false) $dat["tpl_dependence"]['aryImp'] = $imp_style_ary;
	}
	// 更新の場合はedit.cssの存在チェックを行う
	if ($bv == 2 && isset($dat["tpl_txt"]) && $dat["tpl_txt"] != "") {
		// テンプレート内の edit.css の記述を探す
		$search_file = searchEditCSS($tpl_fn, $aryFiles);
		// あれば edit.css を一覧から探す
		if ($search_file != false) {
			// 複数指定はできない
			if (count($search_file) > 1) {
				DispError("テンプレートにエディタ用スタイルシートが複数指定されています。", 5, "javascript:history.back()");
				exit();
			}
			//　エディタ用スタイルシートの名前を取得
			$edit_ary = explode("/", $search_file[0]);
			if ($edit_ary[0]) $editcss_name = $edit_ary[0] . TMP_FILE_CSS;
			//エディタ用スタイルシート名前の取得失敗
			if ($editcss_name == "") {
				DispError("テンプレートに指定されたエディタ用スタイルシートの指定が間違っています。", 5, "javascript:history.back()");
				exit();
			}
			
			// edit.css の存在フラグ
			$cssExists = array(
					"0" => FLAG_OFF,  // 依存ファイル
					"1" => FLAG_OFF
			); // CMSサーバ
			

			// 依存ファイルのチェック
			if (isset($dat["tpl_dependence"]['name']) && $dat["tpl_dependence"]['name'] != "") {
				if (file_exists(DEPENDENCE_WORK_DIR . "/" . $search_file[0])) $cssExists[0] = FLAG_ON;
			}
			// CMSサーバのチェック
			if (file_exists(DOCUMENT_ROOT . RPW . DEPENDENCE_UPLOAD_DIR . "/" . $search_file[0])) $cssExists[1] = FLAG_ON;
			// /editcss/
			if (file_exists(DOCUMENT_ROOT . DIR_PATH_EDITCSS . $editcss_name)) {
				if ($cssExists[0] != FLAG_ON) $dat["tpl_dependence"]["conf_str"] = $editcss_name;
			}
			// 依存ファイルにもサーバにもcssが存在しない場合はエラー
			// ※ 定型の場合は依存ファイルが必要ないのでチェックしない
			if (!in_array(FLAG_ON, $cssExists) && $dat["tpl_kind"] != TEMPLATE_KIND_FIXED) {
				DispError("テンプレートに指定されたエディタ用スタイルシートが存在しません。", 5, "javascript:history.back()");
				exit();
			}
			//テンプレートのからインポート用のCSS作成に必要な情報取得
			if (!isset($dat["tpl_dependence"]['aryImp'])) {
				$imp_style_ary = searchStylesheet($tpl_fn, $editcss_name);
				if ($imp_style_ary != false) $dat["tpl_dependence"]['aryImp'] = $imp_style_ary;
			}
		}
		elseif ($dat["tpl_kind"] != TEMPLATE_KIND_FIXED) {
			// エディタ用スタイルシートが存在しない場合
			DispError("テンプレートにエディタ用スタイルシートの指定がないか、指定が間違っています。", 5, "javascript:history.back()");
			exit();
		}
	}
	//新規で依存ファイルを指定しなかった場合はエディタ用cssが登録済みか確認を行う
	if ($bv == 1 && $dat["tpl_dependence"]['name'] == "") {
		if ($tpl_fn != "") {
			$editcss_name = "";
			// テンプレート内の edit.css の記述を探す
			$search_file = searchEditCSS($tpl_fn, $aryFiles);
			// あれば edit.css を一覧から探す
			if ($search_file != false) {
				// 複数指定はできない
				if (count($search_file) > 1) {
					DispError("テンプレートにエディタ用スタイルシートが複数指定されています。", 5, "javascript:history.back()");
					exit();
				}
				//　エディタ用スタイルシートの名前を取得
				$edit_ary = explode("/", $search_file[0]);
				if ($edit_ary[0]) $editcss_name = $edit_ary[0] . TMP_FILE_CSS;
				//エディタ用スタイルシート名前の取得失敗
				if ($editcss_name == "") {
					DispError("テンプレートに指定されたエディタ用スタイルシートの指定が間違っています。", 5, "javascript:history.back()");
					exit();
				}
				//存在チェック
				if (checkCss($search_file[0], $editcss_name) == false) {
					DispError("テンプレートに指定されたエディタ用スタイルシートが存在しません", 5, "javascript:history.back()");
					exit();
				}
				
				$dat["tpl_dependence"]["conf_str"] = $editcss_name;
			}
			else if ($dat["tpl_kind"] != TEMPLATE_KIND_FIXED) {
				// エディタ用スタイルシートが存在しない場合
				DispError("テンプレートにエディタ用スタイルシートの指定がないか、指定が間違っています。", 5, "javascript:history.back()");
				exit();
			}
			//テンプレートからインポート用のCSS作成に必要な情報取得
			$imp_style_ary = searchStylesheet($tpl_fn, $editcss_name);
			if ($imp_style_ary != false) $dat["tpl_dependence"]['aryImp'] = $imp_style_ary;
		}
	}
	// ** -- ---------------------------------------
	if (isset($dat["kanko_xml_name"]) && $dat["kanko_xml_name"] != "") {
		if (move_uploaded_file($_FILES['tpl_kanko_xml']['tmp_name'], TMP_UPLOAD_PATH . $usr_id . TMP_FILE_KANKO_XML) == FALSE) {
			DispError("定型項目定義ファイルの仮アップロードに失敗しました。", 5, "javascript:history.back()");
			exit();
		}
		if (checkKankoXml(TMP_UPLOAD_PATH . $usr_id . TMP_FILE_KANKO_XML, $msg) === FALSE) {
			DispError("定型項目定義ファイルが正しい形式ではありません。[" . $msg . "]", 5, "javascript:history.back()");
			exit();
		}
	}
	if (isset($dat["mobile_tpl_txt"]) && $dat["mobile_tpl_txt"] != "") {
		if (move_uploaded_file($_FILES['mobile_tpl_txt']['tmp_name'], TMP_UPLOAD_PATH . $usr_id . TMP_FILE_MOBILE_TPL) == FALSE) {
			DispError("携帯用テンプレートファイルの仮アップロードに失敗しました。", 5, "javascript:history.back()");
			exit();
		}
		checkFile($usr_id . TMP_FILE_MOBILE_TPL);
	}
	$msg = "";
	
	//
	return $dat;
}
//main
if (isset($_POST["behavior"])) {
	$bv = $_POST["behavior"];
}
else {
	DispError("パラメータ取得エラー(behavior)", 5, "javascript:history.back()");
	exit();
}
switch ($bv) {
	case 1 :
		$msg = '<p>この情報で登録してもよろしいですか？</p>';
		$back = 'javascript:history.back()';
		$image = '<input type="image" src="../images/btn_add.jpg" alt="追加" width="150" height="20" border="0" style="margin-right:10px">';
		$dat = getPostData($bv);
		$_SESSION["hidden"] = $dat;
		if (isset($_POST["disp"])) {
			$disp = $_POST["disp"];
			$displabel = "非表示にする";
		}
		else {
			$disp = 1;
			$displabel = "表示する";
		}
		$_SESSION["hidden"]["disp"] = $disp;
		break;
	case 2 :
		// 現在のテンプレート情報取得
		require_once ("./include/getRecord.inc");
		$msg = '<p>この情報で登録してもよろしいですか？</p>';
		$back = 'javascript:history.back()';
		$image = '<input type="image" src="../images/btn_fix.jpg" alt="修正" width="150" height="20" border="0" style="margin-right:10px">';
		$tpl_id = $_POST["tpl_id"];
		// 引数に現在のテンプレート情報追加
		$nowTplInfo = getRecord($tpl_id);
		$dat = getPostData($bv, $nowTplInfo);
		if (isset($_POST["public"])) {
			if ($is_lock) {
				DispError("現在アップロード処理中のため即公開を行うことができません。<br>しばらく時間をおいてから再度お試しください。<br>", 5, "javascript:history.back()");
				exit();
			}
			$public = $_POST["public"];
			$publabel = "即公開する";
		}
		else {
			$public = 0;
			$publabel = "即公開しない";
		}
		if (isset($_POST["disp"])) {
			$disp = $_POST["disp"];
			$displabel = "非表示にする";
		}
		else {
			$disp = 1;
			$displabel = "表示する";
		}
		$_SESSION["hidden"] = $dat;
		$_SESSION["hidden"]["public"] = $public;
		$_SESSION["hidden"]["disp"] = $disp;
		$_SESSION["hidden"]["acc_flg"] = $dat["acc_flg"];
		break;
	case 3 :
		require ("./include/getRecord.inc");
		$msg = '<p>この情報を削除してもよろしいですか？</p>';
		$back = 'index.php';
		$image = '<input type="image" src="../images/btn_del.jpg" alt="削除" width="150" height="20" border="0" style="margin-right:10px">';
		$tpl_id = $_POST["tpl_id"];
		$dat = getRecord($tpl_id);
		if ($dat["disp"] == FLAG_OFF) {
			$displabel = "非表示にする";
		}
		else {
			$displabel = "表示する";
		}
		$_SESSION["hidden"] = $dat;
		$_SESSION["hidden"]["tpl_id"] = $tpl_id;
		break;
	default :
		DispError("パラメータエラー（behavior）", 5, "javascript:history.back()");
		exit();
		break;
}

function checkFile($file_name) {
	
	global $objCnc;
	
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_library.inc');
	$objLibrary = new tbl_library($objCnc);
	
	$err_ary = array();
	$tmpDir = DOCUMENT_ROOT . DIR_PATH_UPLOAD . '/temp/';
	$fp = fopen($tmpDir . $file_name, "r");
	$htmlStr = fread($fp, filesize($tmpDir . $file_name));
	
	$err_flg = FLAG_OFF;
	$inquiry_str = getMidString($htmlStr, '<!-- InstanceBeginEditable name="inquiry" -->', '<!-- InstanceEndEditable -->');
	if ($inquiry_str !== FALSE) {
		$memo = getMidString($inquiry_str, '<!-- BeginInqMemo -->', '<!-- EndInqMemo -->');
		if ($memo === FALSE) {
			$err_ary[] = 'お問い合わせメモが正しく設定されていません(BeginInqMemoまたはEndInqMemoが存在しない)';
		}
		elseif (strpos($memo, "#memo#") === FALSE) {
			$err_ary[] = 'お問い合わせメモが正しく設定されていません(#memo#が存在しない)';
		}
		$inquiry_detail = getMidString($inquiry_str, '<!-- BeginInq -->', '<!-- EndInq -->');
		if ($inquiry_detail === FALSE) {
			$err_ary[] = 'お問い合わせ領域が正しく設定されていません(BeginInqまたはEndInqが存在しない)';
		}
	}
	// ライブラリ領域のチェック
	$libHtmlStr = $htmlStr;
	$libAry = array();
	// ライブラリ領域を検索
	while (getLibraryArea($libAry, $libHtmlStr, 0)) {
		// 空のエリア名は無効
		if (!isset($libAry["area"]) || trim($libAry["area"] == "")) {
			$err_ary[] = 'ライブラリ領域のareaが入力されていません。';
		} // 指定した id のライブラリが存在しない
		elseif (isset($libAry["id"]) && $libAry["id"] != "" && $objLibrary->selectFromID($libAry["id"]) === FALSE) {
			$err_ary[] = 'ライブラリ領域に指定されたidのライブラリが存在しません【' . $libAry['id'] . '】';
		}
		// 検索したエリア情報を対象から除外
		$libHtmlStr = str_replace($libAry["match"], "", $libHtmlStr);
	}
	if (count($err_ary) > 0) {
		DispError(implode("<br>", $err_ary) . "<br>テンプレートファイルに不正な形式を発見しました。", 5, "javascript:history.back()");
		exit();
	}
	
	return;
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>テンプレート確認</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="template.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxdisplay() {
	$('css_disp').style.display = 'none';
	$('conf_disp').style.display = 'inline';
}
//-->	
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'template';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><img src="images/bar_conf.jpg" alt="テンプレート確認" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?php
if (isset($dat["tpl_dependence"]["conf_str"])) echo ('<div id="conf_disp" style="display:none">');
?>
<?=

$msg?>
<form id="tpl_form" class="cms8341-form" name="tpl_form"
	action="submit.php" method="post">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="200" align="left" valign="top" scope="row">テンプレート名 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle"><?=htmlDisplay(del_escapes($dat["tpl_name"]))?></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">テンプレート種類 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle"><?=$TEMPLATE_KIND[$dat["tpl_kind"]]?></td>
	</tr>
<?php
if ($dat["tpl_kind"] != TEMPLATE_KIND_NONE) {
	?>
<tr>
		<th width="200" align="left" valign="top" scope="row">テンプレートファイル
<?php
	if ($bv != 2) print '<br><span class="cms_require">（必須）</span>';
	?>
</th>
		<td align="left" valign="middle"><?=$dat["tpl_txt"]?></td>
	</tr>

<?php
	if ($bv != 3) {
		?>
<tr>
		<th width="200" align="left" valign="top" scope="row">依存ファイル</th>
		<td align="left" valign="middle"><?=$dat["tpl_dependence"]["name"]?>
</td>
	</tr>
<?php
	}
	?>

<?php
	if (isset($dat["xml_name"]) && $dat["xml_name"] != "") {
		?>
<tr>
		<th width="200" align="left" valign="top" scope="row">スタイル設定ファイル
<?php
		if ($bv != 2 && $dat['tpl_kind'] != TEMPLATE_KIND_FIXED) {
			print '<br><span class="cms_require">（必須）</span>';
		}
		?>
</th>
		<td align="left" valign="middle"><?=$dat["xml_name"]?>
		<?php
		if (isset($xmlfile_msg)) print '<br><span style="font-size:90%;color:red;font-weight:bold">' . $xmlfile_msg . '</span>';
		?>
</td>
	</tr>
<?php
	}
	?>
<?php

	if (isset($dat["kanko_xml_name"]) && $dat["kanko_xml_name"] != "") {
		?>
<tr>
		<th width="200" align="left" valign="top" scope="row">定型項目定義ファイル
<?php
		if ($bv != 2) print '<br><span class="cms_require">（必須）</span>';
		?>
</th>
		<td align="left" valign="middle"><?=$dat["kanko_xml_name"]?>
		<?php
		if (isset($kankoxmlfile_msg)) print '<br><span style="font-size:90%;color:red;font-weight:bold">' . $kankoxmlfile_msg . '</span>';
		?>
</td>
	</tr>
<?php
	}
	?>
<?php

	if (isset($dat["mobile_tpl_txt"]) && $dat["mobile_tpl_txt"] != "") {
		?>
<tr>
		<th width="200" align="left" valign="top" scope="row">携帯用テンプレートファイル</th>
		<td align="left" valign="middle"><?=$dat["mobile_tpl_txt"]?>
</td>
	</tr>
<?php
	}
	?>
<?php

	if (isset($dat["kanko_type"]) && isset($KANKO_TYPE[$dat["kanko_type"]])) {
		?>
<tr>
		<th width="200" align="left" valign="top" scope="row">用途 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle"><?=$KANKO_TYPE[$dat["kanko_type"]]?>
</td>
	</tr>
<!-- サブサイト対応 -->
<?php
	}
	if( (isset($dat['kanko_type']) && ($dat['kanko_type'] == KANKO_TYPE_EVENT) ) &&
		(isset($dat["use_site_id"]) && isset($USE_SITE_TYPE[$dat["use_site_id"]])) && $siteid_count > 1) { 
?>
<tr>
		<th width="200" align="left" valign="top" scope="row">サイト名 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle"><?=$USE_SITE_TYPE[$dat["use_site_id"]]?>
</td>
	</tr>
<?php 
	}
}
?>
<!-- サブサイト対応 -->
<tr>
		<th width="200" align="left" valign="top" scope="row">承認フロー <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle"><?=htmlDisplay($dat["app_name"])?></td>
	</tr>
<?php
if ($bv == 2) {
	?>
<tr>
		<th width="150" align="left" valign="top" scope="row">公開設定</th>
		<td align="left" valign="middle"><?=$publabel?></td>
	</tr>
<?php
}
?>
<tr>
		<th width="150" align="left" valign="top" scope="row">表示設定</th>
		<td align="left" valign="middle"><?=$displabel?></td>
	</tr>
<?php
if ($dat["tpl_kind"] != TEMPLATE_KIND_NONE) {
	?>
<tr>
		<th width="200" align="left" valign="top" scope="row">言語設定 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle"><?=$ACC_CHECK_FLG[$dat["acc_flg"]]?></td>
	</tr>
<?php
}
?>
</table>
<p align="center"><?=$image?><a href="<?=$back?>"><img
	src="../images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0" style="margin-left: 10px"></a></p>
<input type="hidden" name="behavior" value="<?=$bv?>"></form>
<?php
if (isset($dat["tpl_dependence"]["conf_str"])) {
	?>
</div>
<!--  CSSの確認画面   -->
<div id="css_disp" style="display: inline">
<p>以下の登録済みエディタ用スタイルシートを使用しますか？</p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="200" align="left" valign="top" scope="row">スタイルシート</th>
		<td align="left" valign="middle"><?=$dat["tpl_dependence"]["conf_str"]?>
</td>
	</tr>
</table>
<p align="center"><a href="javascript:" onClick="return cxdisplay();"><img
	src="../images/btn_conf.jpg" alt="確認" width="150" height="20"
	border="0" style="margin-right: 10px"></a> <a href="<?=$back?>"><img
	src="../images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0" style="margin-left: 10px"></a></p>
</div>
<!--  CSSの確認画面   -->
<?php
}
?>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</body>
</html>
