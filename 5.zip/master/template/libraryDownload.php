<?php
/*
 *
 */
/** require **/
require ("./.htsetting");

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
$csvData = "";

// ライブラリの検索
$sql = "SELECT l.*" . " FROM tbl_library AS l" . " WHERE l.library_ver=(SELECT MAX(l2.library_ver) FROM tbl_library l2 WHERE l.library_id=l2.library_id)" . " ORDER BY l.area, l.user_parmission, l.sort_order, l.library_id";
$objDac->execute($sql);
if ($objDac->getRowCount() == 0) {
	DispError("ライブラリが登録されていません", 5, "javascript:history.back()");
	exit();
}
$libAry = array();
while ($objDac->fetch()) {
	$lFld = $objDac->fld;
	$libAry[$lFld['library_id']] = $lFld;
}

// テンプレートの検索
$sql = "SELECT t.*" . " FROM tbl_template AS t" . " WHERE t.template_ver=(SELECT MAX(t2.template_ver) FROM tbl_template t2 WHERE t.template_id=t2.template_id)" . " ORDER BY t.sort_order, t.template_id";
$objDac->execute($sql);
if ($objDac->getRowCount() == 0) {
	DispError("テンプレートが登録されていません", 5, "javascript:history.back()");
	exit();
}

$csvData .= createHeader($libAry) . "\n";
while ($objDac->fetch()) {
	$tFld = $objDac->fld;
	if ($tFld['template_id'] == TEMPLATE_ID_NONE) continue;
	$line = csvWrite($tFld["name"]);
	foreach ($libAry as $key => $value) {
		if (in_array($key, explode(",", $tFld['nonuse_library_id']))) {
			$line .= "," . csvWrite("×");
		}
		else {
			$line .= "," . csvWrite("○");
		}
	}
	$csvData .= $line . "\n";
}

/*---一覧画面へと戻る---*/
$fileName = "CSV_" . date('Y') . date('n') . date('j') . date('H') . date('j') . ".csv";
header("Content-Disposition: attachment; filename=" . $fileName);
header('Content-type: text/comma-separated-values');

print mb_convert_encoding($csvData, "sjis", "utf-8");

function createHeader($libAry) {
	$header = csvWrite("テンプレート名");
	foreach ($libAry as $key => $value) {
		$header .= "," . csvWrite($value['name']);
	}
	return $header;
}
?>