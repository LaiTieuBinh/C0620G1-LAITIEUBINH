<?php
/*
 * テンプレート管理　初期表示画面
 */
/** require **/
require ("./.htsetting");
//function
require ("./include/isTplExist.inc");
unset($_SESSION["hidden"]);

//list format
$fmt1 = '<tr>' . "\n";
$fmt1 .= '<td {disp}>' . "\n";
$fmt1 .= '<table width="100%" border="0" cellpadding="5" cellspacing="0" style="border:none;">' . "\n";
$fmt1 .= '<tr>' . "\n";
$fmt1 .= '<td width="30%" align="left" valign="middle" style="border:none">' . "\n";
$fmt1 .= '<strong><a href="{tpl_path}" target="_blank">{tpl_name}</a>（{tpl_id}）</strong>' . "\n";
$fmt1 .= '</td>' . "\n";
$fmt1 .= '<td width="70%" align="right" valign="middle" style="border:none">' . "\n";

$fmta = '<a href="javascript:" onClick="return cxChangeLibrary(\'{tpl_id}\',\'{tpl_name}\')"><img src="../images/btn_mini_library.jpg" alt="ライブラリ設定" width="120" height="20" hspace="0" border="0"></a>' . "\n";
$fmtaa = '<a href="javascript:" onClick="return cxTemplateForm({tpl_id},2)"><img src="../images/btn_mini_fix.jpg" alt="修正" width="60" height="20" hspace="10" border="0"></a>' . "\n";
$fmtb = '<a href="javascript:" onClick="return cxTemplateForm({tpl_id},3)"><img src="../images/btn_mini_del.jpg" alt="削除" width="60" height="20" border="0"></a>' . "\n";
$fmtc = '<a href="javascript:" onClick="return cxTemplateForm({tpl_id},4)"><img src="./images/btn_mini_kanko_disp.jpg" alt="定型項目表示設定" width="120" height="20" border="0"></a>&nbsp;&nbsp;' . "\n";
$fmtSpace = '<img src="../../images/spacer.gif" alt="" width="60" height="20" border="0">' . "\n";

$fmt2 = '</td>' . "\n";
$fmt2 .= '</tr>' . "\n";
$fmt2 .= '</table>' . "\n";
$fmt2 .= '<table class="cms8341-dataTable" width="100%"><tr><td style="{defStyle}width:180px;">テンプレート種類</td><td style="width:200px;">{tpl_kind}</td><td style="{defStyle};width:180px;">承認フロー</td><td style="width:200px;">{app_name}</td></tr>' . "\n";
$fmt2 .= '<tr{edit_display}><td style="{defStyle}">エディタ用スタイルシート</th><td>{css_name}</td><td style="{defStyle}">スタイル設定ファイル</td><td>{xml_name}</td></tr>' . "\n";
$fmt2 .= '<tr{kanko_display}><td style="{defStyle}">定型項目定義ファイル</th><td>{kanko_xml_name}</td><td style="{defStyle}">用途</td><td>{kanko_type}</td></tr>' . "\n";
$fmt2 .= '</table>' . "\n";
$fmt2 .= '</td>' . "\n";
$fmt2 .= '</tr>' . "\n";

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
//createList
$html = '';
$sql = "SELECT t.template_id AS tpl_id,t.template_kind AS tpl_kind,t.name AS tpl_name,t.edit_css AS css_name, t.style_xml AS xml_name, t.kanko_xml AS kanko_xml_name, a.name AS app_name, t.disp_flg AS disp_flg, t.temp_txt AS temp_txt, t.kanko_type AS kanko_type, t.acc_flg AS acc_flg" . " FROM tbl_template AS t" . " LEFT JOIN tbl_approve AS a ON t.approve_id=a.approve_id" . " WHERE t.template_ver=(SELECT MAX(t2.template_ver) FROM tbl_template t2 WHERE t.template_id=t2.template_id)" . " ORDER BY t.sort_order, t.template_id";
$objDac->execute($sql);
$cnt = $objDac->getRowCount();
if ($cnt > 0) {
	$KANKO_TYPE = getDefineArray("KANKO_TYPE");
	while ($objDac->fetch()) {
		$fld = $objDac->fld;
		$tpl_id = $fld['tpl_id'];
		$tpl_kind = htmlDisplay($TEMPLATE_KIND[$fld['tpl_kind']]);
		$tpl_name = htmlDisplay($fld['tpl_name']);
		$css_name = htmlDisplay($fld['css_name']);
		$xml_name = htmlDisplay($fld['xml_name']);
		$app_name = htmlDisplay($fld['app_name']);
		$file_path = htmlDisplay(RPW . "/admin/page/common/tplview.php?path=" . urlencode(DIR_PATH_TEMPLATE . $fld['temp_txt']));
		if ($fld['disp_flg'] == FLAG_OFF) {
			$disp = ' style="background-color:#BBBBBB;"';
			$defStyle = '';
		}
		else {
			$disp = '';
			$defStyle = 'background-color:#F0F0F0;';
		}
		
		switch ($fld['tpl_kind']) {
			case TEMPLATE_KIND_FREE :
			case TEMPLATE_KIND_MOBILE :
			case TEMPLATE_KIND_ENQUETE :
				$edit_display = '';
				if ($fld['kanko_xml_name'] != "") {
					$kanko_display = '';
					$kanko_xml_name = htmlDisplay($fld['kanko_xml_name']);
					$kanko_type = (isset($KANKO_TYPE[$fld['kanko_type']])) ? $KANKO_TYPE[$fld['kanko_type']] : "";
				}
				else {
					$kanko_display = ' style="display:none"';
					$kanko_xml_name = "";
					$kanko_type = "";
				}
				break;
			case TEMPLATE_KIND_FIXED :
				$edit_display = ' style="display:none"';
				$kanko_display = '';
				$kanko_xml_name = htmlDisplay($fld['kanko_xml_name']);
				$kanko_type = (isset($KANKO_TYPE[$fld['kanko_type']])) ? $KANKO_TYPE[$fld['kanko_type']] : "";
				break;
			case TEMPLATE_KIND_NONE :
				$kanko_display = ' style="display:none"';
				$edit_display = ' style="display:none"';
				$kanko_xml_name = "";
				$kanko_type = "";
				break;
		}
		
		// ボタン表示
		$tmp = ($fld['tpl_kind'] != TEMPLATE_KIND_NONE) ? $fmt1 : str_replace('<a href="{tpl_path}" target="_blank">{tpl_name}</a>', '{tpl_name}', $fmt1);
		// 定型項目定義ファイルがある場合は定型項目情報設定ボタンを表示
		$tmp .= ($fld['kanko_xml_name'] != "") ? $fmtc : $fmtSpace;
		// テンプレートなしの場合はライブラリボタンを表示しない
		$tmp .= ($fld['tpl_kind'] != TEMPLATE_KIND_NONE) ? $fmta : $fmtSpace;
		//修正ボタンを表示
		$tmp .= $fmtaa;
		// 作成されているページがなければ削除ボタンを表示
		$tmp .= (isTplExist($tpl_id) || $fld['tpl_kind'] == TEMPLATE_KIND_NONE) ? $fmtSpace : $fmtb;
		$tmp .= $fmt2;
		
		// 内容の埋め込み
		$tmp = str_replace('{tpl_id}', $tpl_id, $tmp);
		$tmp = str_replace('{tpl_kind}', $tpl_kind, $tmp);
		$tmp = str_replace('{tpl_name}', $tpl_name, $tmp);
		$tmp = str_replace('{css_name}', $css_name, $tmp);
		$tmp = str_replace('{xml_name}', $xml_name, $tmp);
		$tmp = str_replace('{kanko_xml_name}', $kanko_xml_name, $tmp);
		$tmp = str_replace('{kanko_type}', $kanko_type, $tmp);
		$tmp = str_replace('{app_name}', $app_name, $tmp);
		$tmp = str_replace('{tpl_path}', $file_path, $tmp);
		$tmp = str_replace('{disp}', $disp, $tmp);
		$tmp = str_replace('{defStyle}', $defStyle, $tmp);
		$tmp = str_replace('{edit_display}', $edit_display, $tmp);
		$tmp = str_replace('{kanko_display}', $kanko_display, $tmp);
		$html .= $tmp;
	}
}
else {
	$html = '<tr><td align="center" valign="top">現在、テンプレートは登録されていません。</td></tr>';
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>テンプレート一覧</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="template.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxTemplateForm(id,bv) {
	switch(bv) {
		case 1:
			$('behavior').value = bv;
			$('tpl_form').action = 'form.php';
			document.tpl_form.submit();
			break;
		case 2:
			$('tpl_id').value = id;
			$('behavior').value = bv;
			$('tpl_form').action = 'form.php';
			document.tpl_form.submit();
			break;
		case 3:
			$('tpl_id').value = id;
			$('behavior').value = bv;
			$('tpl_form').action = 'confirm.php';
			document.tpl_form.submit();
			break;
		case 4:
			$('tpl_id').value = id;
			$('tpl_form').action = 'kankoDispSetting.php';
			document.tpl_form.submit();
			break;
		default:
			alert('パラメータエラー（behavior）');
			break;
	}
	return false;
}
function cxTemplateSort(){
	$('tpl_form').action = 'sortorder.php';
	$('tpl_form').submit();
	return false;
}
function cxChangeLibrary(id,name){
	$('tpl_form').action = 'changeLibrary.php';
	$('tpl_id').value = id;
	$('tpl_name').value = name;
	$('tpl_form').submit();
	return false;
}
function cxLibraryDownload(){
	$('tpl_form').action = 'libraryDownload.php';
	$('tpl_form').submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'template';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-templates">
<div><img src="images/bar_template.jpg" alt="テンプレート一覧" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
<?=$html?>
</table>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<form id="tpl_form" class="cms8341-form" name="tpl_form"
	action="form.php" method="post"><input type="hidden" id="tpl_id"
	name="tpl_id" value=""> <input type="hidden" id="tpl_name"
	name="tpl_name" value=""> <input type="hidden" id="behavior"
	name="behavior" value=""></form>
</body>
</html>
