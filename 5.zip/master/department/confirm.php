<?php
/*
 *
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/
//レヴェル
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


/** require **/
require ("./.htsetting");
/*--- 共通関数読み込み ---*/
require ("./include/common.inc");

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output.inc');
$objDac = new dac($objCnc);
$objOp = new tbl_output($objCnc);

/** init **/
$dat = array();
unset($_SESSION["hidden"]);
$temp_list = "";
$output_list = "";
$auto_output_list = "";
$iDept = array();
$back = "javascript:history.back()";
$is_lock = lock_file_management('check'); // アップロード処理中か確認
/** function **/
function getPostData($objDac) {
	$ARY_NO_CREATE_DIR = getDefineArray("ARY_NO_CREATE_DIR");
	
	$dat = array();
	if (isset($_POST['dept_id'])) $dat['dept_id'] = $_POST['dept_id'];
	if (isset($_POST['dept_code'])) $dat['dept_code'] = $_POST['dept_code'];
	elseif (isset($_POST['cms_target2']) && $_POST['cms_target2'] != "") $dat['dept_code'] = $_POST['cms_target2'];
	elseif (isset($_POST['cms_target1']) && $_POST['cms_target1'] != "") $dat['dept_code'] = $_POST['cms_target1'];
	else $dat['dept_code'] = "";
	if (isset($_POST['name'])) $dat['name'] = $_POST['name'];
	if (isset($_POST['tel'])) $dat['tel'] = $_POST['tel'];
	if (isset($_POST['fax'])) $dat['fax'] = $_POST['fax'];
	if (isset($_POST['email'])) $dat['email'] = $_POST['email'];
	if (isset($_POST['url'])) $dat['url'] = $_POST['url'];
	if (isset($_POST['address'])) $dat['address'] = $_POST['address'];
	if (isset($_POST['temp_id'])) $dat['temp_id'] = $_POST['temp_id'];
	else $dat['temp_id'] = array();
	if (isset($_POST['dir_list'])) $dat['dir_list'] = $_POST['dir_list'];
	else $dat['dir_list'] = "";
	if (isset($_POST['dept'])) $dat['dept'] = $_POST['dept'];
	if (isset($_POST['def_dir1'])) {
		$dat['def_dir1'] = $_POST['def_dir1'];
		if ($dat['def_dir1'] != "" && substr($dat['def_dir1'], -1, 1) != "/") $dat['def_dir1'] .= "/";
		$dat['def_dir1'] = preg_replace("/\/+/", "/", $dat['def_dir1']);
	}
	if (isset($_POST['def_outer'])) $dat['def_outer'] = $_POST['def_outer'];
	if (isset($_POST['def_FAQanswer'])) $dat['def_FAQanswer'] = $_POST['def_FAQanswer'];
	if (isset($_POST['output_id'])) $dat['output_id'] = $_POST['output_id'];
	else $dat['output_id'] = array();
	if (isset($_POST['def_disaster_edit'])) {
		$dat['def_disaster_edit'] = $_POST['def_disaster_edit'];
	}
	if (isset($_POST['public'])) $dat['public'] = $_POST['public'];
	//
	$msg = "";
	$dept_flg = true;
	if (isset($dat['dept_code']) && $dat['dept_code'] != "") {
		$sql = "SELECT * FROM tbl_department" . " WHERE dept_code = '" . gd_addslashes($dat['dept_code']) . "'";
		if (!$objDac->execute($sql) || !$objDac->fetch()) {
			$msg .= "指定された上階層組織に誤りがあります（" . $dat["dept_code"] . "）<br>";
			$dept_flg = false;
		}
		$iDept = getDeptCode($dat['dept_code']);
	}
	if ($_POST['behavior'] == 1) {
		if (!isset($dat["dept"]) || $dat["dept"] == "") {
			$msg .= "組織コードが入力されていません。<br>";
		}
		elseif (!preg_match("/^[0-9]+$/", $dat["dept"])) {
			$msg .= "組織コードに半角数字以外の文字が使用されています。<br>";
		}
		elseif (strlen($dat["dept"]) > CODE_DIGIT_DEPT) {
			$msg .= "組織コードは" . CODE_DIGIT_DEPT . "桁以内で入力してください。<br>";
		}
		elseif ($dept_flg) {
			//少ない場合は、0埋め
			if (strlen($dat['dept']) < CODE_DIGIT_DEPT) {
				$dat['dept'] = str_pad($dat['dept'], CODE_DIGIT_DEPT, "0", STR_PAD_LEFT);
			}
			$dc = $dat['dept'] . str_repeat("0", (CODE_DIGIT_DEPT * 2));
			if (isset($iDept)) {
				if ($iDept['level'] == G_DEPT_LEVEL01) $dc = $iDept['dept1'] . $dat['dept'] . str_repeat("0", CODE_DIGIT_DEPT);
				elseif ($iDept['level'] == G_DEPT_LEVEL02) $dc = $iDept['dept1'] . $iDept['dept2'] . $dat['dept'];
			}
			else {
				$iDept = array(
						'level' => 0
				);
			}
			$sql = "SELECT COUNT(dept_id) AS rc FROM tbl_department" . " WHERE dept_code = '" . $dc . "' AND level = " . ($iDept['level'] + 1);
			$objDac->execute($sql);
			$objDac->fetch();
			if ($objDac->fld['rc'] > 0) {
				$msg .= "入力された組織コードは既に登録されています（" . $dat["dept"] . "）<br>";
			}
			//組織コードに000000000は指定できない。
			if ($dc == WEB_MASTER_CODE) {
				$msg .= "入力された組織コードは指定できません。（" . $dat["dept"] . "）<br>";
			}
		}
	}
	if (!isset($dat["name"]) || $dat["name"] == "") {
		$msg .= "組織名が入力されていません。<br>";
	}
	elseif (!checkMachineCode($dat["name"])) {
		$msg .= "組織名に機種依存文字が使用されています。<br>";
	}
	if (!isset($dat["email"]) || $dat["email"] == "") {
		//形式チェック
	//1: 文字列先頭から@直前までに、@以外の任意の文字が１文字以上あること
	//2: @は1つだけ指定されていること。
	//3: @の後にはドット以外の文字が１文字以上あること。
	//4: ドット後に任意の文字が１文字以上あること。
	}
	elseif (!preg_match("/^[\w\_\-][\w\_\-\.]*@[\w\_\-]+\.([\w\_\-]+\.)*\w+$/i", $dat["email"])) {
		$msg .= "メールアドレスとしてふさわしくない値が入力されています。<br>";
	}
	if (isset($iDept) && (($_POST['behavior'] == 1 && $iDept['level'] == G_DEPT_LEVEL02) || ($_POST['behavior'] == 2 && $iDept['level'] == G_DEPT_LEVEL03))) {
		// フォルダ階層制限チェック用
		$limitDirAdd = 0;
		// FCK用フォルダ images documents の場合は階層制限 + 1
		if (strlen(LIMIT_DIR_STRUCTURE) != 0) {
			$dir_structure = preg_replace("/\/$/", "", $dat['def_dir1']);
			$dir_array = explode("/", $dir_structure);
			$temp_ary = array(
					FCK_FILELINK_FORDER, 
					FCK_IMAGES_FORDER
			);
			if (count($dir_array) > 0 && in_array("/" . $dir_array[count($dir_array) - 1], $temp_ary)) $limitDirAdd = 1;
		}
		$dir_list_ary = explode("\n", $dat['dir_list']);
		foreach ($dir_list_ary as $key => $val) {
			$dir_list_ary[$key] = preg_replace('/^[^\/]*(\/.*\/)[^\/]*$/', "$1", $val);
		}
		
		// 作成禁止ディレクトリは権限を与えない
		foreach ((array) $ARY_NO_CREATE_DIR as $no_dir) {
			if (preg_match("/^" . reg_replace($no_dir) . "/i", $dat['def_dir1'])) {
				$msg .= "通常ページ初期フォルダに権限を与えられないフォルダが指定されています。<br>";
				break;
			}
		}
		
		if (preg_match('/^[^\/]/', $dat['def_dir1'])) {
			$msg .= "通常ページ初期フォルダは/（スラッシュ）から始まるパスを入力してください。<br>";
		}
		elseif (preg_match('/[^0-9a-zA-Z\~\.\-\_\/]/', $dat['def_dir1'])) {
			$msg .= "通常ページ初期フォルダにフォルダ名としてふさわしくない文字が使用されています。<br>";
		}
		elseif (!@is_dir(DOCUMENT_ROOT . RPW . $dat['def_dir1']) && strlen(LIMIT_DIR_STRUCTURE) != 0 && count($dir_array) > LIMIT_DIR_STRUCTURE + $limitDirAdd) {
			$msg .= "フォルダ作成に制限があるため、通常ページ初期フォルダに設定できません。";
		}
		elseif ($dat['def_dir1'] != "" && !in_array($dat['def_dir1'], $dir_list_ary)) {
			$dat['dir_list'] .= "\n" . $dat['def_dir1'];
		}
	}
	
	if (!isset($dat['def_outer']) && $iDept['level'] == G_DEPT_LEVEL03) {
		$msg .= "外部ファイル取り込み権限が選択されていません。<br>";
	}
	if (!isset($dat['def_FAQanswer']) && $iDept['level'] == G_DEPT_LEVEL03) {
		$msg .= "FAQ振分権限が選択されていません。<br>";
	}
	if (!isset($dat['def_disaster_edit']) && $iDept['level'] == G_DEPT_LEVEL03) {
		$msg .= "大規模災害ページ作成権限が選択されていません。<br>";
	}
	
	$ary1 = array(
			'/\r?\n/', 
			'/\n{2,}/', 
			'/^\n/', 
			'/\n$/', 
			'/\/+/'
	);
	$ary2 = array(
			"\n", 
			"\n", 
			'', 
			'', 
			'/'
	);
	$dat['dir_list'] = preg_replace($ary1, $ary2, $dat['dir_list']);
	
	if (isset($dat['dir_list']) && $dat['dir_list'] != "") {
		$dirAry = explode("\n", preg_replace('/\r?\n/', "\n", $dat['dir_list']));
		foreach ($dirAry as $key => $dir) {
			//「*」の後には「/」はつけない
			if (preg_match("/\/\*\/?$/", $dir)) {
				$dir = preg_replace("/\/\*\/?$/", "/*", $dir);
			}
			else {
				if (substr($dir, -1, 1) == "/") continue;
				$dir .= "/";
			}
			
			$dirAry[$key] = $dir;
		}
		$dirAry = array_unique($dirAry);
		natsort($dirAry);
		
		foreach ($dirAry as $dir) {
			if ($dir == "") continue;
			if (preg_match('/^[^\/]/', $dir)) {
				$msg .= "権限のあるフォルダは/（スラッシュ）から始まるパスを入力してください。<br>";
				break;
			}
			if (preg_match('/[^0-9a-zA-Z\~\.\-\_\/\*]/', $dir)) {
				$msg .= "権限のあるフォルダにフォルダ名としてふさわしくない文字が使用されています。<br>";
				break;
			}
			
			// 作成禁止ディレクトリは権限を与えない
			foreach ((array) $ARY_NO_CREATE_DIR as $no_dir) {
				if (preg_match("/^" . reg_replace($no_dir) . "/i", $dir)) {
					$msg .= "権限のあるフォルダに権限を与えられないフォルダが指定されています。【" . htmlspecialchars($dir) . "】<br>";
					break;
				}
			}
			
			if ($msg != "") break;
			
			if (strpos($dir, '*') != strrpos($dir, '*')) {
				$msg .= "権限のあるフォルダに「*」が複数指定されています。【" . htmlspecialchars($dir) . "】<br>";
				break;
			}
			if (preg_match('/([0-9a-zA-Z\~\.\-\_\*]\*|\*[0-9a-zA-Z\~\.\-\_\*])/', $dir)) {
				$msg .= "権限のあるフォルダに「*」を使用する場合前後には「/」のみとしてください。【" . htmlspecialchars($dir) . "】<br>";
				break;
			}
			if (preg_match('/\*\/[0-9a-zA-Z\~\.\-\_\/\*]/', $dir)) {
				$msg .= "権限のあるフォルダに「*」を使用する場合「*」以下は指定しないでください。【" . htmlspecialchars($dir) . "】<br>";
				break;
			}
			
			if (!@is_dir(DOCUMENT_ROOT . RPW . $dir)) {
				if (strlen(LIMIT_DIR_STRUCTURE) != 0) {
					$dir_structure = preg_replace("/\/$/", "", $dir);
					$dir_array = explode("/", $dir_structure);
					$temp_ary = array(
							FCK_FILELINK_FORDER, 
							FCK_IMAGES_FORDER
					);
					$limitDirAdd = (count($dir_array) > 0 && in_array("/" . $dir_array[count($dir_array) - 1], $temp_ary)) ? 1 : 0;
					if (count($dir_array) > LIMIT_DIR_STRUCTURE + $limitDirAdd) {
						$msg .= "フォルダ作成に制限があるため、権限を付加できません。【" . $dir . "】<br>";
						break;
					}
				}
			}
		}
		
		if ($msg == "") {
			if (count($dirAry) > 0) {
				//表示用フォルダ一覧取得
				$dirAry = get_disp_dir($dirAry);
				if ($dirAry === FALSE) {
					DispError("フォルダ一覧の取得に失敗しました。", 2, "javascript:history.back()");
					exit();
				}
			}
		}
		
		$dat['dir_list'] = implode("\n", $dirAry);
	}
	//
	if ($msg != "") {
		if ($_POST['behavior'] == 1) DispError($msg, 2, "department/edit.php?back=1");
		else DispError($msg, 2, "javascript:history.back()");
		exit();
	}
	return $dat;
}

/** get post date **/
if (isset($_POST["behavior"])) {
	$bv = $_POST["behavior"];
}
else {
	DispError("パラメータ取得エラー(behavior)", 2, "javascript:history.back()");
	exit();
}
if (!isset($_POST["dept_id"])) {
	DispError("パラメータ取得エラー(dept_id)", 2, "javascript:history.back()");
	exit();
}
switch ($bv) {
	case 1 :
		$_SESSION['hidden'] = $_POST;
		$msg = '<p>この情報で登録してもよろしいですか？</p>';
		$image = '<input type="image" src="../images/btn_add.jpg" alt="追加" width="150" height="20" border="0" style="margin-right:10px">';
		$dat = getPostData($objDac);
		$back = "edit.php?back=1";
		break;
	case 2 :
		$msg = '<p>この情報で登録してもよろしいですか？</p>';
		$image = '<input type="image" src="../images/btn_fix.jpg" alt="修正" width="150" height="20" border="0" style="margin-right:10px">';
		$dat = getPostData($objDac);
		break;
	case 3 :
		$msg = '<p>この情報を削除してもよろしいですか？</p>';
		$image = '<input type="image" src="../images/btn_del.jpg" alt="削除" width="150" height="20" border="0" style="margin-right:10px">';
		$sql = "SELECT d.*, h1.item2 AS def_dir1" . " FROM tbl_department AS d" . " LEFT JOIN tbl_handler AS h1 ON (h1.class = " . HANDLER_CLASS_DEF_DIR1 . " AND h1.item1 = d.dept_code)" . " WHERE d.dept_id = " . gd_addslashes($_POST["dept_id"]);
		$objDac->execute($sql);
		if (!$objDac->fetch()) {
			DispError("指定された組織情報が存在しません。", 2, "javascript:history.back()");
			exit();
		}
		$dat = $objDac->fld;
		/*---テンプレート一覧の取得---*/
		$aryTemp = array();
		$sql = "SELECT item2 FROM tbl_handler" . " WHERE class = " . HANDLER_CLASS_TEMPLATE . " AND item1 = '" . gd_addslashes($dat['dept_code']) . "'";
		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$aryTemp[] = $objDac->fld['item2'];
		}
		$dat['temp_id'] = $aryTemp;
		/*---ディレクトリ一覧の取得---*/
		$dir_list = "";
		$sql = "SELECT item2 FROM tbl_handler" . " WHERE class = " . HANDLER_CLASS_DIRECTORY . " AND item1 = '" . gd_addslashes($dat['dept_code']) . "'";
		$objDac->execute($sql);
		$objDac->fetchrow = 0;
		$dir_list_ary = array();
		while ($objDac->fetch()) {
			$dir_list_ary[] = $objDac->fld['item2'];
		}
		$dir_list_ary = array_unique($dir_list_ary);
		natsort($dir_list_ary);
		if (count($dir_list_ary) > 0) {
			//表示用ディレクトリ一覧取得
			$dir_list_ary = get_disp_dir($dir_list_ary);
			if ($dir_list_ary == FALSE) {
				DispError("フォルダ一覧の取得に失敗しました。", 2, "javascript:history.back()");
				exit();
			}
		}
		$dat['dir_list'] = implode("\n", $dir_list_ary);
		
		$where = "class = " . HANDLER_CLASS_OUTER_IMPORT . " AND item1 = '" . gd_addslashes($dat['dept_code']) . "'";
		$objDac->setTableName("tbl_handler");
		$objDac->select($where);
		if ($objDac->getRowCount() == 0) {
			$dat['def_outer'] = FLAG_OFF;
		}
		else {
			$dat['def_outer'] = FLAG_ON;
		}
		
		// FAQ振分権限
		$where = "class = " . HANDLER_CLASS_FAQ_ANSWER . " AND item1 = '" . gd_addslashes($dat['dept_code']) . "'";
		$objDac->setTableName("tbl_handler");
		$objDac->select($where);
		if ($objDac->getRowCount() == 0) {
			$dat['def_FAQanswer'] = FLAG_OFF;
		}
		else {
			$dat['def_FAQanswer'] = FLAG_ON;
		}
		$dat['output_id'] = array();
		foreach (getOutputTemplateFromDeptCode($dat['dept_code']) as $op_fld) {
			$dat['output_id'][] = $op_fld['output_id'];
		}
		
		// 大規模災害ページ作成権限
		// 表示あり・なし
		$def_disaster_display = 'block';
		if (isDisasterEditFlg($dat['dept_code'])) {
			$dat['def_disaster_edit'] = FLAG_ON;
		}
		else {
			$dat['def_disaster_edit'] = FLAG_OFF;
		}
		
		break;
	default :
		DispError("パラメータエラー（behavior）", 2, "javascript:history.back()");
		exit();
		break;
}
/*---組織名称の取得---*/
$DspDeptNm = "";
$dept_name = "";
if ($dat['dept_code'] != "") {
	$iDept = getDeptCode($dat['dept_code']);
	if ($bv == 1) $iDept['level'] = $iDept['level'] + 1;
	//部
	if ($iDept['level'] == G_DEPT_LEVEL01) {
		$DspDeptNm .= $dat['name'];
		$dept_name .= $dat['name'];
	}
	else {
		$sql = "SELECT name FROM tbl_department" . " WHERE dept_code = '" . gd_addslashes($iDept['dept1_code']) . "'";
		$objDac->execute($sql);
		if ($objDac->fetch()) {
			$DspDeptNm .= $objDac->fld['name'];
			$dept_name .= $objDac->fld['name'];
		}
		// 課
		if ($iDept['level'] == G_DEPT_LEVEL02) {
			$DspDeptNm .= " > " . $dat['name'];
			$dept_name .= $dat['name'];
		}
		else {
			$sql = "SELECT name FROM tbl_department" . " WHERE dept_code = '" . gd_addslashes($iDept['dept2_code']) . "'";
			$objDac->execute($sql);
			if ($objDac->fetch()) {
				$DspDeptNm .= " > " . $objDac->fld['name'];
				$dept_name .= $objDac->fld['name'];
			}
			// 係
			$DspDeptNm .= " > " . $dat['name'];
			$dept_name .= $dat['name'];
		}
	}
}
else {
	$iDept['level'] = 1;
	$DspDeptNm .= $dat['name'];
	$dept_name .= $dat['name'];
}
$dat['dept_name'] = $dept_name;
$dat['iDept'] = $iDept;
// テンプレート一覧
if (count($dat['temp_id']) > 0) {
	$sql = "SELECT t.template_id, t.name FROM tbl_template AS t" . " WHERE t.template_ver=(SELECT MAX(t2.template_ver) FROM tbl_template t2 WHERE t.template_id=t2.template_id)" . " AND template_id IN (" . join(', ', $dat['temp_id']) . ")" . " ORDER BY t.sort_order, t.template_id";
	$objDac->execute($sql);
	while ($objDac->fetch()) {
		$temp_list .= htmlDisplay($objDac->fld['name']) . "<br>";
	}
}

if ($bv == 3) {
	//下位組織の検索
	if ($dat['level'] < G_DEPT_LEVEL03) {
		$sc = ($dat['level'] == G_DEPT_LEVEL01) ? $iDept['dept1'] : $iDept['dept1'] . $iDept['dept2'];
		$sql = "SELECT COUNT(dept_id) AS rc FROM tbl_department" . " WHERE level > " . $dat['level'] . " AND dept_code LIKE '" . $sc . "%'";
		$objDac->execute($sql);
		if ($objDac->fetch() && $objDac->fld['rc'] > 0) {
			$msg = '<p>下位組織が登録されているため、この組織を削除できません。</p>';
			DispError($msg, 2, "javascript:history.back()");
			exit();
		}
	}
	//所属ユーザーの検索
	if ($image != "") {
		$sql = "SELECT COUNT(user_id) AS rc FROM tbl_user" . " WHERE dept_code = '" . gd_addslashes($dat['dept_code']) . "'";
		$objDac->execute($sql);
		if ($objDac->fetch() && $objDac->fld['rc'] > 0) {
			$msg = '<p>所属するユーザーが登録されているため、この組織を削除できません。</p>';
			DispError($msg, 2, "javascript:history.back()");
			exit();
		}
	}
	//担当するお問い合わせ情報の検索
	if (ENABLE_OPTION_FAQ) {
		$sql = "SELECT COUNT(faq_id) AS rc FROM tbl_faq WHERE charge = '" . gd_addslashes($dat['dept_code']) . "'";
		$objDac->execute($sql);
		if ($objDac->fetch() && $objDac->fld['rc'] > 0) {
			$msg = '<p>担当するお問い合わせ情報が存在するため、この組織を削除できません。</p>';
			DispError($msg, 2, "javascript:history.back()");
			exit();
		}
	}
	
	$temp_msg = "";
	$sql = "SELECT p.page_title, p.file_path FROM tbl_publish_page as p INNER JOIN (SELECT DISTINCT inquiry_id, dept_code FROM tbl_publish_inquiry) as i" . " ON p.inquiry_id = i.inquiry_id" . " WHERE i.dept_code = '" . gd_addslashes($dat['dept_code']) . "'";
	$objDac->execute($sql);
	if ($objDac->getRowCount() > 0) {
		while ($objDac->fetch()) {
			$temp_msg .= "[公開中]" . htmlDisplay($objDac->fld['page_title']) . "（" . htmlDisplay($objDac->fld['file_path']) . "）<br>";
		}
	}
	
	$sql = "SELECT w.page_title, w.file_path FROM tbl_work_page as w INNER JOIN (SELECT DISTINCT inquiry_id, dept_code FROM tbl_work_inquiry) as i" . " ON w.inquiry_id = i.inquiry_id" . " WHERE i.dept_code = '" . gd_addslashes($dat['dept_code']) . "'";
	$objDac->execute($sql);
	if ($objDac->getRowCount() > 0) {
		while ($objDac->fetch()) {
			$temp_msg .= "[作業中]" . htmlDisplay($objDac->fld['page_title']) . "（" . htmlDisplay($objDac->fld['file_path']) . "）<br>";
		}
	}
	if (trim($temp_msg) != "") {
		$msg = '<p>以下のページの問い合わせ先で使用されているため、この組織を削除できません。</p>';
		$msg .= '<p>';
		$msg .= $temp_msg;
		$msg .= '</p>';
		DispError($msg, 2, "javascript:history.back()");
		exit();
	}
}
foreach ($dat['output_id'] as $output_id) {
	if ($objOp->selectFromID($output_id) === FALSE) continue;
	if (isset($objOp->fld['output_kind']) && $objOp->fld['output_kind'] == OUTPUT_KIND_AUTO) {
		// 外部連携自動出力形式表示用文字列作成
		$auto_output_list .= htmlDisplay($objOp->fld['name']) . "<br>";
	}
	else {
		// 外部連携手動出力形式表示用文字列作成
		$output_list .= htmlDisplay($objOp->fld['name']) . "<br>";
	}
}

//公開設定
if (isset($dat['public'])) {
	if ($is_lock) {
		DispError("現在アップロード処理中のため即公開を行うことができません。<br>しばらく時間をおいてから再度お試しください。<br>", 2, "javascript:history.back()");
		exit();
	}
	$publabel = "即公開する";
}
else {
	$publabel = "即公開しない";
}

$_SESSION["hidden"] = $dat;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>組織情報確認</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="department.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'department';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-user">
<div><img src="images/bar_conf.jpg" alt="組織情報確認" width="920" height="30"></div>
<div class="cms8341-area-corner">
<?=$msg?>
<form id="form" class="cms8341-form" name="form" action="submit.php"
	method="post">
<p align="left" id="cms8341-pankuzu"><?=$DspDeptNm?></p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable"><?php
	if ($bv != 1) {
		?>
<tr>
		<th align="left" valign="top" scope="row">組織コード</th>
		<td align="left" valign="top"><?=htmlDisplay($dat['dept_code'])?></td>
	</tr><?php
	}
	?>
<tr>
		<th width="230" align="left" valign="top" scope="row">組織名 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay($dat['name'])?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">住所</th>
		<td align="left" valign="top"><?=htmlDisplay($dat['address'])?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">電話番号</th>
		<td align="left" valign="top"><?=htmlDisplay($dat['tel'])?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">FAX番号</th>
		<td align="left" valign="top"><?=htmlDisplay($dat['fax'])?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">メールアドレス</th>
		<td align="left" valign="top"><?=htmlDisplay($dat['email'])?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">URL</th>
		<td align="left" valign="top"><?=htmlDisplay($dat['url'])?></td>
	</tr>
<?php
if ($iDept['level'] == G_DEPT_LEVEL03) {
	?>
<tr>
		<th align="left" valign="top" scope="row">外部ファイル取り込み権限<br>
		<span class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay(($dat['def_outer'] == FLAG_ON) ? "許可する" : "許可しない")?></td>
	</tr>
<?php
	if (ENABLE_OPTION_FAQ) {
		?>
<tr>
		<th align="left" valign="top" scope="row">FAQ振分権限 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay(($dat['def_FAQanswer'] == FLAG_ON) ? "許可する" : "許可しない")?></td>
	</tr>
<?php
	}
	?>
<?php

	if (ENABLE_OPTION_OUTPUT) {
		?>
<tr>
		<th align="left" valign="top" scope="row">外部データ連携権限</th>
		<td align="left" valign="top">
<?php
		if ($output_list != "" || $auto_output_list != "") {
			?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable">
<?php
			if ($output_list != "") {
				?>
<tr>
				<th align="left" valign="middle" scope="row" width="20%">手動出力</th>
				<td align="left" valign="top"><?=$output_list?></td>
			</tr>
<?php
			}
			?>
<?php

			if ($auto_output_list != "") {
				?>
<tr>
				<th align="left" valign="middle" scope="row" width="20%">自動出力</th>
				<td align="left" valign="top"><?=$auto_output_list?></td>
			</tr>
<?php
			}
			?>
</table>
<?php
		}
		?>
</td>
	</tr>
<?php
	}
	?>
	<tr>
		<th align="left" valign="top" scope="row">大規模災害ページ作成権限 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay(($dat['def_disaster_edit'] == FLAG_ON) ? "許可する" : "許可しない")?></td>
	</tr>
<tr>
		<th align="left" valign="top" scope="row">通常ページ初期フォルダ</th>
		<td align="left" valign="top"><?=htmlDisplay($dat['def_dir1'])?></td>
	</tr>
<tr>
		<th align="left" valign="top" scope="row">テンプレート一覧</th>
		<td align="left" valign="top"><?=$temp_list?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">フォルダ一覧</th>
		<td align="left" valign="top"><?=htmlDisplay($dat['dir_list'])?></td>
	</tr>
<?php
}
?>
<?php
if ($bv == 2) {
	?>
<tr>
		<th width="150" align="left" valign="top" scope="row">公開設定</th>
		<td align="left" valign="middle"><?=$publabel?></td>
	</tr>
<?php
}
?>
</table>
<p align="center"><?=$image?><a href="<?=$back?>"><img
	src="../images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0" style="margin-left: 10px"></a></p>

</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<input type="hidden" name="behavior" value="<?=$bv?>">
</form>
</body>
</html>
