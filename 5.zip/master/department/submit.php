<?php
/*
 * 
 */
require ("./.htsetting");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>組織情報即公開</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="department.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'deptuser';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
require_once (APPLICATION_ROOT . '/common/function/func_progressbar.inc');
$pgrs_func = new progressbar();

?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><img src="images/bar_recreate.jpg" alt="組織情報即公開" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?=$pgrs_func->get_progress_area()?>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<?php
require ("./include/common.inc");
/*---------------------------------------------
	定数 
----------------------------------------------*/
//レヴェル
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係

/** get post data **/
$bv = $_POST["behavior"];
$dept_id = $_SESSION["hidden"]["dept_id"];
$dept_code = $_SESSION["hidden"]["dept_code"];
$name = $_SESSION["hidden"]["name"];
$tel = $_SESSION["hidden"]["tel"];
$fax = $_SESSION["hidden"]["fax"];
$email = $_SESSION["hidden"]["email"];
$url = $_SESSION["hidden"]["url"];
$address = $_SESSION["hidden"]["address"];
$dept_name = $_SESSION["hidden"]["dept_name"];
$iDept = $_SESSION["hidden"]["iDept"];
if (isset($_SESSION["hidden"]["temp_id"])) $temp_id = $_SESSION["hidden"]["temp_id"];
if (isset($_SESSION["hidden"]["dir_list"])) $dir_list = $_SESSION["hidden"]["dir_list"];
if (isset($_SESSION["hidden"]["dept"])) $dept = $_SESSION["hidden"]["dept"];
$search_code = "";
if ($iDept['level'] == 2) $dsearch_code = $iDept['dept1'];
elseif ($iDept['level'] == 3) $search_code = $iDept['dept1'] . $iDept['dept2'];
if (isset($_SESSION["hidden"]["def_dir1"])) $def_dir1 = $_SESSION["hidden"]["def_dir1"];
if (isset($_SESSION["hidden"]["def_outer"])) $def_outer = $_SESSION["hidden"]["def_outer"];
if (isset($_SESSION["hidden"]["def_FAQanswer"])) $def_FAQanswer = $_SESSION["hidden"]["def_FAQanswer"];
if (isset($_SESSION["hidden"]["output_id"])) $output_id_ary = $_SESSION["hidden"]["output_id"];
// 大規模災害ページ作成権限
if (isset($_SESSION["hidden"]["def_disaster_edit"])) {
	$def_disaster_edit = $_SESSION["hidden"]["def_disaster_edit"];
}
if (isset($_SESSION["hidden"]["public"])) $public = $_SESSION["hidden"]["public"];

//戻り先index
$deptInfo = getDeptCode($dept_code);
$DspBackURL = "index.php?level=" . ($iDept['level'] - 1) . "&dept_code=" . $dept_code . "#" . $deptInfo['dept1_code'];

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output_handler.inc');
$objDac = new dac($objCnc);
$objOpHndl = new tbl_output_handler($objCnc);

switch ($bv) {
	case 1 :
		require ("./include/insert.inc");
		break;
	case 2 :
		require ("./include/update.inc");
		break;
	case 3 :
		require ("./include/delete.inc");
		break;
	default :
		DispError("パラメータ取得エラー（behavior）", 2, "javascript:history.back()");
		exit();
		break;
}

function _rollback($objCnc, $msg) {
	$objCnc->rollback();
	DispError($msg, 2, "javascript:history.back()");
	exit();
}
?>