<?php
/*
 * 組織管理　組織情報のインポート(form.php)
 */
$GLOBALS["StrDbg"] = "";

// 設定ファイル読み込み
require ("./.htsetting");
require ("./include/common.inc");

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$obj_Dac = new dac($objCnc);
$obj_dac2 = new dac($objCnc);

// 定数の宣言

// 部
define('G_DEPT_LEVEL01', 1);
// 課
define('G_DEPT_LEVEL02', 2);
// 係
define('G_DEPT_LEVEL03', 3);

// 組織情報項目数
define('G_CSV_ITM_CNT', 11);

// CSVファイルupload先
define('CSV_UPLOAD', './tmp/');
// CSVファイル最大行
define('G_CSV_MAX_LINE', 40000);

// チェック対象項目
$CHECK_ITEM = array(
	array(
		// 項目名
		'label' => '組織コード1',
		// 必須（0:必須チェックなし　1:必須チェックあり)
		'required' => 1,
	),
	array(
		'label' => '組織コード2',
		'required' => 1,
	),
	array(
		'label' => '組織コード3',
		'required' => 1,
	),
	array(
		'label' => '組織名',
		'required' => 1,
	),
	array(
		'label' => '問い合せ先TEL',
		'required' => 0,
	),
	array(
		'label' => '問い合せ先FAX',
		'required' => 0,
	),
	array(
		'label' => '問い合せ先Eメール',
		'required' => 0,
	),
	array(
		'label' => '問い合せ先住所',
		'required' => 0,
	),
	array(
		'label' => '問い合せ先URL',
		'required' => 0,
	),
	array(
		'label' => '表示順',
		'required' => 1,
	),
	array(
		'label' => '通常ページ初期フォルダ',
		'required' => 1,
	)
);

// 変数の宣言

// 権限のあるテンプレートの最大数
$max_template_cnt = 0;
// 権限のあるフォルダの最大数
$max_dir_cnt = 0;


// 引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError('インポートをするCSVファイルを指定してください。', 2, 'javascript:history.back()');
	exit;
}
// 拡張子チェック
$sExtension = strtolower(substr($frmCsvFnm, (strrpos($frmCsvFnm, '.') + 1)));
if ($sExtension != "csv") {
	DispError('CSVファイルを指定してください。', 2, 'javascript:history.back()');
	exit;
}
// ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError('CSVファイルのファイルサイズが0バイトです。', 2, 'javascript:history.back()');
	exit;
}
// アップロード
$frmCsvFnm = CSV_UPLOAD . $frmCsvFnm;
if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $frmCsvFnm) == FALSE) {
	DispError('CSVファイルのアップロードに失敗しました。', 2, 'javascript:history.back()');
	exit;
}
// ファイル存在チェック
if (file_exists($frmCsvFnm) == FALSE) {
	DispError('指定されたファイル【' . $frmCsvFnm . '】が存在しません。', 2, 'javascript:history.back()');
	exit;
}

// トランザクション開始
$objCnc->begin();

// 組織情報の全削除
$sql = 'DELETE FROM tbl_department';
$obj_Dac->execute($sql);
// ハンドラテーブルのディレクトリ項目、テンプレート項目全削除
$sql = 'DELETE FROM tbl_handler WHERE class IN (' . HANDLER_CLASS_DIRECTORY . ', ' . HANDLER_CLASS_TEMPLATE . ', ' . HANDLER_CLASS_DEF_DIR1 . ')';
$obj_Dac->execute($sql);

// CSVファイルを開く
if (!($CsvFno = csvRead_UTF8($frmCsvFnm))) {
	// エラーページの表示
	DispError('CSVファイルのオープンに失敗しました。', 2, 'javascript:history.back()');
	exit;
}

// 一行目（見出し）の項目を取得
$data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE);

// 変動項目の最大値を取得
foreach ($data as $label) {
	if (strpos($label, '権限のあるテンプレートID') === 0) {
		$max_template_cnt = (int) str_replace('権限のあるテンプレートID', '', $label);
	}
	if (strpos($label, '権限のあるフォルダ') === 0) {
		$max_dir_cnt = (int) str_replace('権限のあるフォルダ', '', $label);
	}
}

// EOFになるまで読み出し
$err_msg = '';
while ($data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
	// 行の項目数が組織情報の項目数よりも少なければ空で埋める
	while (count($data) <= G_CSV_ITM_CNT) {
		$data[] = '';
	}
	
	// 「通常ページ初期フォルダ」の最後に「/」を追加
	if ($data[10] != '' && substr($data[10], -1, 1) != '/') {
		$data[10] .= '/';
	}
	
	// 各項目のチェック
	if (G_ChkCsvItem($data, $CHECK_ITEM, $obj_Dac, $err_msg, $dept_code) == FALSE) {
		// ファイルCLOSE
		fclose($CsvFno);
		// ファイルを削除
		@unlink($frmCsvFnm);
		// ロールバック
		$objCnc->rollback();
		// エラーページの表示
		DispError($err_msg, 2, 'javascript:history.back()');
		exit;
	}
	
	// 組織コードにウェブマスターが指定されていたら登録はしない
	if ($dept_code == WEB_MASTER_CODE) {
		continue;
	}
	
	// 組織コード詳細
	$dept_info = getDeptCode($dept_code);
	
	// tbl_departmentに追加
	if (G_TblDeptAdd($data, $dept_info, $obj_Dac) == FALSE) {
		// ファイルCLOSE
		fclose($CsvFno);
		// ファイルを削除
		@unlink($frmCsvFnm);
		// ロールバック
		$objCnc->rollback();
		// エラーページの表示
		DispError('組織情報の登録に失敗しました。', 2, 'javascript:history.back()');
		exit;
	}
	
	// 第三組織以外はtbl_handlerに追加を行わない
	if ($dept_info['level'] != G_DEPT_LEVEL03) {
		continue;
	}
	
	// tbl_handlerに追加
	if (G_TblHandlerAdd($data, $dept_code, $obj_Dac) == FALSE) {
		// ファイルCLOSE
		fclose($CsvFno);
		// ファイルを削除
		@unlink($frmCsvFnm);
		// ロールバック
		$objCnc->rollback();
		// エラーページの表示
		DispError('ハンドラー情報の登録に失敗しました。', 2, 'javascript:history.back()');
		exit;
	}
}

// ファイルCLOSE
fclose($CsvFno);
// ファイルを削除
if (@unlink($frmCsvFnm) == FALSE) {
	// ロールバック
	$objCnc->rollback();
	// エラーページの表示
	DispError('CSVファイルの削除に失敗しました。', 2, 'javascript:history.back()');
	exit;
}

// dept_name(部+課+係)の取得
$err_msg = '';
if (G_GetDeptNmIntoTblDept($obj_Dac, $obj_dac2, $err_msg) == FALSE) {
	// ロールバック
	$objCnc->rollback();
	// エラーページの表示
	DispError(($err_msg != '' ? $err_msg : '組織名の取得に失敗しました。'), 2, 'javascript:history.back()');
	exit;
}

// tbl_userに指定されているuser_idがtbl_departmentに存在しない場合はエラー
$sql = "SELECT u.user_id FROM tbl_user AS u LEFT JOIN tbl_department AS d ON (u.dept_code = d.dept_code) WHERE ((d.dept_code IS NULL) AND (u.dept_code <> '" . WEB_MASTER_CODE . "'))";
$obj_Dac->execute($sql);
if ($obj_Dac->getRowCount() > 0) {
	// ロールバック
	$objCnc->rollback();
	// エラーページの表示
	DispError('組織情報に存在しない組織コードがユーザー情報で使用されています。', 2, 'javascript:history.back()');
	exit;
}

// tbl_faqに指定されているfaq_idがtbl_departmentに存在しない場合はエラー
if (ENABLE_OPTION_FAQ) {
	$sql = "SELECT f.faq_id FROM tbl_faq AS f LEFT JOIN tbl_department AS d ON (f.charge = d.dept_code) WHERE ((d.dept_code IS NULL))";
	$obj_Dac->execute($sql);
	if ($obj_Dac->getRowCount() > 0) {
		// ロールバック
		$objCnc->rollback();
		// エラーページの表示
		DispError('担当するお問い合わせ情報が存在するため、この組織を削除できません。', 2, 'javascript:history.back()');
		exit;
	}
}

// コミット
$objCnc->commit();

// 一覧画面へと戻る
header("Location: " . "./index.php");

exit;

/**
 * CSV項目のチェック
 * @param $csv_data 配列で指定されたCSVデータ（全項目)
 * @param $check_item チェック項目の情報
 * @param $obj_dac DBコネクション
 * @param &$err_msg エラーメッセージ
 * @param &$dept_code 組織コード
 * @return すべてのチェックが正常に終了した場合はTRUE、そうでない場合はFALSEを返す
 */
function G_ChkCsvItem($csv_data, $check_item, $obj_dac, &$err_msg, &$dept_code) {
	global $max_template_cnt;
	$ARY_NO_CREATE_DIR = getDefineArray("ARY_NO_CREATE_DIR");
	$dept_cd = array(
			"", 
			"", 
			""
	);
	
	// 組織コード１（部）($csv_data[0])～組織コード３（係）チェック($csv_data[2])
	for ($idx = 0; $idx <= 2; $idx++) {
		// 必須チェック
		if ($check_item[$idx]['required'] == 1) {
			if (strlen($csv_data[$idx]) <= 0) {
				$err_msg = "組織コード" . ($idx + 1) . "が指定されていないデーターが存在します。";
				return FALSE;
			}
			// 桁数チェック
			if (strlen($csv_data[$idx]) > CODE_DIGIT_DEPT) {
				$err_msg = "組織コード" . ($idx + 1) . "に" . CODE_DIGIT_DEPT . "桁を越えて指定されているデーターが存在します。" . "【" . $csv_data[$idx] . "】";
				return FALSE;
			}
			if (strlen($csv_data[$idx]) < CODE_DIGIT_DEPT) {
				// 少ない場合は、0埋め
				$dept_cd[$idx] = str_pad($csv_data[$idx], CODE_DIGIT_DEPT, "0", STR_PAD_LEFT);
			}
			else {
				$dept_cd[$idx] = $csv_data[$idx];
			}
			if (checkMachineCode($dept_cd[$idx]) == FALSE) {
				$err_msg = "機種依存文字が指定されている組織コード" . ($idx + 1) . "が存在します。";
				return FALSE;
			}
		}
	}
	
	// 他組織項目の必須チェック
	for($idx = 3; $idx < 10; $idx++) {
		if ($check_item[$idx]['required'] == 1) {
			if (strlen($csv_data[$idx]) <= 0) {
				$err_msg = $check_item[$idx]['label'] . "が指定されていないデーターが存在します。";
				return FALSE;
			}
		}
		if (checkMachineCode($csv_data[$idx]) == FALSE) {
			$err_msg = "機種依存文字が指定されている" . $check_item[$idx]['label'] . "が存在します。【" . $csv_data[$idx] . "】";
			return FALSE;
		}
	}
	
	// （第3階層）初期ディレクトリの必須チェック
	if ($csv_data[2] != str_repeat('0', CODE_DIGIT_DEPT)) {
		for ($idx = 10; $idx < G_CSV_ITM_CNT; $idx++) {
			if ($check_item[$idx]['required'] == 1) {
				if (strlen($csv_data[$idx]) <= 0) continue;
				if (preg_match('/^[^\/]/', $csv_data[$idx])) {
					$err_msg = $check_item[$idx]['label'] . "は/（スラッシュ）から始まるパスを入力してください。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				if ((preg_match('/[^0-9a-zA-Z\~\.\-\_\/]/', $csv_data[$idx]))) {
					$err_msg = $check_item[$idx]['label'] . "にフォルダ名としてふさわしくない文字が使用されています。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				// 作成禁止ディレクトリは権限を与えない
				foreach ((array) $ARY_NO_CREATE_DIR as $no_dir) {
					if (preg_match("/^" . reg_replace($no_dir) . "/i", $csv_data[$idx])) {
						$err_msg = $check_item[$idx]['label'] . "に権限を与えられないフォルダが指定されています。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
						return FALSE;
					}
				}
				
				if (!@is_dir(DOCUMENT_ROOT . RPW . $csv_data[$idx])) {
					if (strlen(LIMIT_DIR_STRUCTURE) != 0) {
						$dir_structure = preg_replace("/\/$/", "", $csv_data[$idx]);
						$dir_array = explode("/", $dir_structure);
						$temp_ary = array(
								FCK_FILELINK_FORDER, 
								FCK_IMAGES_FORDER
						);
						$limitDirAdd = (count($dir_array) > 0 && in_array("/" . $dir_array[count($dir_array) - 1], $temp_ary)) ? 1 : 0;
						if (count($dir_array) > LIMIT_DIR_STRUCTURE + $limitDirAdd) {
							$err_msg = $check_item[$idx]['label'] . "はフォルダ作成に制限があるため、初期ディレクトリに指定できません。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
							return FALSE;
						}
					}
				}
			}
			if (checkMachineCode($csv_data[$idx]) == FALSE) {
				$err_msg = "機種依存文字が指定されている" . $check_item[$idx]['label'] . "が存在します。【" . $csv_data[$idx] . "】";
				return FALSE;
			}
		}
		
		for ($idx = G_CSV_ITM_CNT; $idx < (G_CSV_ITM_CNT + $max_template_cnt); $idx++) {
			if (strlen($csv_data[$idx]) > 0) {
				$where = $obj_dac->_addslashesC("template_id", $csv_data[$idx], "=");
				$obj_dac->setTableName("tbl_template");
				$obj_dac->select($where);
				if ($obj_dac->getRowCount() == 0) {
					$err_msg = "指定されたテンプレートは存在しません。【テンプレートID:" . $csv_data[$idx] . "】";
					return FALSE;
				}
			}
		}
		
		for($idx = (G_CSV_ITM_CNT + $max_template_cnt); $idx < count($csv_data); $idx++) {
			if (strlen($csv_data[$idx]) > 0) {
				if (preg_match('/^[^\/]/', $csv_data[$idx])) {
					$err_msg = "権限のあるフォルダは/（スラッシュ）から始まるパスを入力してください。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				if ((preg_match('/[^0-9a-zA-Z\~\.\-\_\/\*]/', $csv_data[$idx]))) {
					$err_msg = "権限のあるフォルダにフォルダ名としてふさわしくない文字が使用されています。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				
				// 作成禁止ディレクトリは権限を与えない
				foreach ((array) $ARY_NO_CREATE_DIR as $no_dir) {
					if (preg_match("/^" . reg_replace($no_dir) . "/i", $csv_data[$idx])) {
						$err_msg = "権限のあるフォルダに権限を与えられないフォルダが指定されています。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
						return FALSE;
					}
				}
				
				if (strpos($csv_data[$idx], '*') != strrpos($csv_data[$idx], '*')) {
					$err_msg = "権限のあるフォルダに「*」が複数指定されています。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				if (preg_match('/([0-9a-zA-Z\~\.\-\_]\*|\*[0-9a-zA-Z\~\.\-\_])/', $csv_data[$idx])) {
					$err_msg = "権限のあるフォルダに「*」を使用する場合前後には「/」のみとしてください。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				if (preg_match('/\*\/[0-9a-zA-Z\~\.\-\_\/\*]/', $csv_data[$idx])) {
					$err_msg = "権限のあるフォルダに「*」を使用する場合「*」以下は指定しないでください。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				
				if (!@is_dir(DOCUMENT_ROOT . RPW . $csv_data[$idx])) {
					if (strlen(LIMIT_DIR_STRUCTURE) != 0) {
						$dir_structure = preg_replace("/\/$/", "", $csv_data[$idx]);
						$dir_array = explode("/", $dir_structure);
						$temp_ary = array(
								FCK_FILELINK_FORDER, 
								FCK_IMAGES_FORDER
						);
						$limitDirAdd = (count($dir_array) > 0 && in_array("/" . $dir_array[count($dir_array) - 1], $temp_ary)) ? 1 : 0;
						if (count($dir_array) > LIMIT_DIR_STRUCTURE + $limitDirAdd) {
							$err_msg = "フォルダ作成に制限があるため、権限を付加できません。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
							return FALSE;
						}
					}
				}
			}
		}
	}
	
	// 組織コード(部)(課)(係)
	$dept_code = $dept_cd[0] . $dept_cd[1] . $dept_cd[2];
	if (strlen($dept_code) > 0) {
		// tbl_departmentに重複チェック
		$sql = "SELECT dept_id FROM tbl_department WHERE dept_code='" . $dept_code . "'";
		$obj_dac->execute($sql);
		if ($obj_dac->getRowCount() > 0) {
			$err_msg = "すでに存在する組織コード（部、課、係）の指定されているデーターが存在します。【" . $dept_cd[0] . "," . $dept_cd[1] . "," . $dept_cd[2] . "】";
			return FALSE;
		}
	}
	
	// 表示順 $csv_data[9]
	// 半角数値チェック
	if (!(preg_match("/^[0-9]+$/", $csv_data[9]))) {
		$err_msg = "半角数値以外の値が指定されている表示順が存在します。";
		return FALSE;
	}
	
	return TRUE;

}

/**
 * tbl_departmentにCSVデータを追加
 * @param $csv_data 配列で指定されたcsvデータ（全項目)
 * @param $dept_info 組織コード詳細(配列)
 * @param $obj_dac DBコネクション
 * @return 正常に終了した場合はTRUE、そうでない場合はFALSEを返す
 */
function G_TblDeptAdd($csv_data, $dept_info, $obj_dac) {
	
	// データの設定
	$level = $dept_info['level'];
	$dept_code = $dept_info['dept3_code'];
	
	// SQL作成
	$sql = "INSERT INTO tbl_department ( level, dept_code, name, tel, fax, email, address, url, sort_order) VALUES (";
	$sql .= $level . ", "; //レベル
	$sql .= "'" . $dept_code . "', "; //組織コード
	$sql .= "'" . gd_addslashes($csv_data[3]) . "', "; //名前
	$sql .= "'" . gd_addslashes($csv_data[4]) . "', "; //問い合せTEL
	$sql .= "'" . gd_addslashes($csv_data[5]) . "', "; //問い合せFAX
	$sql .= "'" . gd_addslashes($csv_data[6]) . "', "; //問い合せＥメール
	$sql .= "'" . gd_addslashes($csv_data[7]) . "', "; //問い合せ住所
	$sql .= "'" . gd_addslashes($csv_data[8]) . "', "; //問い合せURL
	$sql .= $csv_data[9]; //sort_order
	$sql .= ")";
	
	// 実行
	return ($obj_dac->execute($sql, "utf-8", "auto"));
}

/**
 * tbl_handlerにCSVデータを追加
 * @param $csv_data 配列で指定されたcsvデータ（全項目)
 * @param $dept_code 結合された組織コード
 * @param $obj_dac DBコネクション
 * @return 正常に終了した場合はTRUE、そうでない場合はFALSEを返す
 */
function G_TblHandlerAdd($csv_data, $dept_code, $obj_dac) {
	global $max_template_cnt;
	$ARY_NO_CREATE_DIR = getDefineArray("ARY_NO_CREATE_DIR");
	
	// 「通常ページ初期ディレクトリ」項目処理
	if (strlen($csv_data[10]) > 0) {
		$csv_data[10] = preg_replace("/\/+/", "/", $csv_data[10]);
		//SQL作成
		$sql = "INSERT INTO tbl_handler (class, item1, item2) VALUES (" . HANDLER_CLASS_DEF_DIR1 . ", '" . gd_addslashes($dept_code) . "', '" . gd_addslashes($csv_data[10]) . "')";
		//実行
		if ($obj_dac->execute(mb_convert_encoding($sql, "utf-8", "auto")) == FALSE) {
			return FALSE;
		}
	}
	
	// 「権限のあるテンプレートID」項目処理
	$min_idx = G_CSV_ITM_CNT;
	$max_idx = (G_CSV_ITM_CNT + $max_template_cnt);
	if (count($csv_data) < $max_idx) $max_idx = count($csv_data);
	for($idx = $min_idx; $idx < $max_idx; $idx++) {
		if (strlen($csv_data[$idx]) > 0) {
			//SQL作成
			$sql = "INSERT INTO tbl_handler (class, item1, item2) VALUES (" . HANDLER_CLASS_TEMPLATE . ", '" . gd_addslashes($dept_code) . "', '" . gd_addslashes($csv_data[$idx]) . "')";
			//実行
			if ($obj_dac->execute(mb_convert_encoding($sql, "utf-8", "auto")) == FALSE) {
				return FALSE;
			}
		}
	}
	
	// 「権限のあるディレクトリ」項目処理
	$dir_list_ary = array();
	$list = array();
	$dirData = array_slice($csv_data, (G_CSV_ITM_CNT + $max_template_cnt));
	// 初期ディレクトリに指定されたは強制的に登録する
	if (!in_array($csv_data[10], $dirData)) $csv_data[] = $csv_data[10];
	for($idx = (G_CSV_ITM_CNT + $max_template_cnt); $idx < count($csv_data); $idx++) {
		if (strlen($csv_data[$idx]) > 0) {
			$dir = $csv_data[$idx];
			$dir = preg_replace("/\/+/", "/", $dir);
			
			//「*」ワイルドカードを使用した権限登録
			if (preg_match("/\/\*\/?$/", $dir)) {
				// 「*」権限追加
				$dir_list_ary[] = mb_convert_encoding(preg_replace("/\/\*\/?$/", "/*", $dir), "utf-8", "auto");
				// 「*」以下のパスを削除
				$dir = preg_replace("/\/\*\/?$/", "", $dir);
			}
			
			$dir_list_ary[] = mb_convert_encoding((substr($dir, -1, 1) == "/" ? $dir : $dir . "/"), "utf-8", "auto");
		}
	}
	
	//重複パスの削除
	$dir_list_ary = array_unique($dir_list_ary);
	natsort($dir_list_ary);
	//権限登録
	if (!insert_handler_directory($dept_code, $dir_list_ary, HANDLER_DIR_SPECIAL_INS)) {
		return FALSE;
	}
	// フォルダ作成
	foreach ((array) $dir_list_ary as $dir_path) {
		//ワイルドカードを使用していたならディレクトリを作成しない
		if (preg_match("/^.*\*.*$/", $dir_path)) continue;
		
		$dummy = (substr($dir_path, -1, 1) == "/") ? "dummy.txt" : "/dummy.txt";
		mkNewDirectory(DOCUMENT_ROOT . RPW . $dir_path . $dummy);
	}
	
	return TRUE;
}

/**
 * 組織名の取得
 * @param $obj_dac DBコネクション
 * @param $obj_dac2 DBコネクション
 * @param $err_msg エラーメッセージ
 * @return 正常に終了した場合はTRUE、そうでない場合はFALSEを返す
 */
function G_GetDeptNmIntoTblDept($obj_dac, $obj_dac2, &$err_msg) {
	
	// tbl_department全件処理
	$sql = "SELECT dept_code, name, level FROM tbl_department ORDER BY dept_code";
	// 取得
	$obj_dac->execute($sql);
	
	while ($obj_dac->fetch()) {
		$dept_nm = "";
		// レベルに応じて部、課、係名を取得する
		if ($obj_dac->fld['level'] == G_DEPT_LEVEL01) {
			// 部
			$dept_nm = $obj_dac->fld['name'];
		}
		else {
			if (($obj_dac->fld['level'] != G_DEPT_LEVEL02) && ($obj_dac->fld['level'] != G_DEPT_LEVEL03)) {
				$err_msg = "有効ではないレベルが指定されている組織データーが存在しました。";
				return FALSE;
			}
			// 対応する部コードの作成
			$dept_01 = substr($obj_dac->fld['dept_code'], 0, CODE_DIGIT_DEPT); //組織コード１の切り出し
			$dept_01 = str_pad($dept_01, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
			if ($obj_dac->fld['level'] == G_DEPT_LEVEL02) {
				$sql = "SELECT dept_code, name FROM tbl_department WHERE (tbl_department.dept_code = '" . $dept_01 . "') ORDER BY dept_code";
				// 取得
				$obj_dac2->execute($sql);
				if ($obj_dac2->getRowCount() <= 0) {
					$err_msg = "上位の組織名が取得できません。【" . $obj_dac->fld['dept_code'] . "】";
					return FALSE;
				}
				// 部 + 課
				while ($obj_dac2->fetch()) {
					$dept_nm = $obj_dac2->fld['name'] . $obj_dac->fld['name'];
				}
			}
			else {
				// 対応する課コードの作成
				$dept_02 = substr($obj_dac->fld['dept_code'], 0, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT)); //組織コード2の切り出し
				$dept_02 = str_pad($dept_02, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
				$sql = "SELECT d.dept_code, d.name as dept_nm01, d2.dept_code, d2.name as dept_nm02 FROM tbl_department AS d, tbl_department AS d2 WHERE ((d.dept_code = '" . $dept_01 . "') AND (d2.dept_code = '" . $dept_02 . "'))";
				// 取得
				$obj_dac2->execute($sql);
				if ($obj_dac2->getRowCount() <= 0) {
					$err_msg = "上位の組織名が取得できません。【" . $obj_dac->fld['dept_code'] . "】";
					return FALSE;
				}
				// 部 + 課 + 係
				while ($obj_dac2->fetch()) {
					$dept_nm = $obj_dac2->fld['dept_nm01'] . $obj_dac2->fld['dept_nm02'] . $obj_dac->fld['name'];
				}
			}
		}
		// 組織テーブルの更新
		$sql = "UPDATE tbl_department SET dept_name = '" . $dept_nm . "' WHERE(dept_code = '" . $obj_dac->fld['dept_code'] . "')";
		// 実行
		$obj_dac2->execute($sql);
		// ユーザテーブルの更新
		$sql = "UPDATE tbl_user SET dept_name = '" . $dept_nm . "' WHERE(dept_code = '" . $obj_dac->fld['dept_code'] . "')";
		// 実行
		$obj_dac2->execute($sql);
	}
	return TRUE;
}
?>
