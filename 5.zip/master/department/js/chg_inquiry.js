/*
 *
 */
//通信失敗処理
function cxFailure() {
	alert('情報取得中に通信エラーが発生しました');
}
//
function cxChangeDept(lv, target, val) {
	//reset
	if (target == "1") {
		target_str = '_before_';
	} else {
		target_str = '_after_';
	}
	if (val == "") {
		var t = lv + 1;
		for ( var i = t; i <= 3; i++) {
			var obj = $('cms_target' + target_str + i);
			while (obj.length > 1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "----------------";
		}
	} else {
		//get data
		lv++;
		var prm = 'level=' + lv + '&code=' + val;
		if (target == "1") {
			cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK_Before);
		} else {
			cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK_After);
		}
	}
}

function cxGetDeptComboOK_Before(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Department') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    var code = xmlDoc.attributes.getNamedItem('code').value;
    for ( var i = level; i <= 3; i++) {
        var obj = $('cms_target_before_' + i);
        while (obj.length > 1) {
                obj.options[1] = null;
        }
        if (i == level) {
                obj.options[0].text = "指定なし";
        } else {
                obj.options[0].text = "----------------";
        }
    }
    if (level < 4) {
        var obj = $('cms_target_before_' + level);
        var xmlDocfix = xmlDoc.childElementCount;
        for (var i=0; i<xmlDocfix; i++) {
            nodeL = xmlDoc.firstElementChild;
            obj.length++;
            obj.options[i+1].text = nodeL.textContent;
            var val = nodeL.attributes.getNamedItem('value').value;
            obj.options[i+1].value = val;
            xmlDoc.removeChild(xmlDoc.firstElementChild);
        }
    }
}

function cxGetDeptComboOK_After(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Department') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    var code = xmlDoc.attributes.getNamedItem('code').value;
    for ( var i = level; i <= 3; i++) {
        var obj = $('cms_target_after_' + i);
        while (obj.length > 1) {
            obj.options[1] = null;
        }
        if (i == level) {
            obj.options[0].text = "指定なし";
        } else {
            obj.options[0].text = "----------------";
        }
    }
    if (level < 4) {
        var obj = $('cms_target_after_' + level);
        var xmlDocfix = xmlDoc.childElementCount;
        for (var i=0; i<xmlDocfix; i++) {
            nodeL = xmlDoc.firstElementChild;
            obj.length++;
            obj.options[i+1].text = nodeL.textContent;
            var val = nodeL.attributes.getNamedItem('value').value;
            obj.options[i+1].value = val;
            xmlDoc.removeChild(xmlDoc.firstElementChild);
        }
    }
}
// エクスポート、CSV指定項目の表示/非表示
function cxDispChange() {
	if ($('cms_page_select_1').checked) {
		Element.show($('cms_inq_page_export'));
		Element.show($('cms_inq_page_import'));
	} else {
		Element.hide($('cms_inq_page_export'));
		Element.hide($('cms_inq_page_import'));
	}

}
// 確認画面へ送信
function cxSubmit() {
	// ページ指定をするとき、アップロードファイルのチェックを行う
	if ($('cms_page_select_1').checked) {
		// アップロードファイルのチェック
		if ($('FrmCsvnm').value == '') {
			alert('変更対象ページの指定をしてください。');
			return false;
		}
		// 拡張子チェック
		var csv_exp = '\.csv$';
		var csv_reg = new RegExp(csv_exp);
		if (!$('FrmCsvnm').value.match(csv_reg)) {
			alert('CSVファイルを指定してください。');
			return false;
		}
	}
	$('form').action = cms8341admin_path
			+ "/master/department/chg_inquiry_conf.php";
	$('form').submit();
	return false;
}
// エクスポート
function cxInqExport() {
	if (!$('cms_target_before_1').value) {
		alert('変更対象の組織を選択してください。');
		return false;
	}
	$('form').action = cms8341admin_path
			+ "/master/department/chg_inquiry_export.php";
	$('form').submit();
	return false;
}
function cxDeptExport() {
	$('form').action = cms8341admin_path + "/master/department/export.php";
	$('form').submit();
	return false;
}