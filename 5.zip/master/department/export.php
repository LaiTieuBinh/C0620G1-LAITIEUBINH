<?php
/*
 * 組織テーブルの情報をエクスポートする
 */

// 設定ファイル読み込み
require ("./.htsetting");
require ("./include/common.inc");

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
$objDac2 = new dac($objCnc);

// 定数の宣言

// 部
define("G_DEPT_LEVEL01", 1);
// 課
define("G_DEPT_LEVEL02", 2);
// 係
define("G_DEPT_LEVEL03", 3);

// テンプレート項目の最少列数（見出しのための制限）
define("MIN_ROW_CNT_TEMPLATE", 5);
// ディレクトリ項目の最少列数（見出しのための制限）
define("MIN_ROW_CNT_DIRECTORY", 5);

// 見出し文字
$G_SetHead = array(
		'組織コード1', 
		'組織コード2', 
		'組織コード3', 
		'組織名', 
		'問い合せ先TEL', 
		'問い合せ先FAX', 
		'問い合せ先Eメール', 
		'問い合せ先住所', 
		'問い合せ先URL', 
		'表示順', 
		'通常ページ初期フォルダ', 
);

//tbl_departmentとtbl_handlerの取得
$sql = "SELECT d.*, h1.item2 AS def_dir1 FROM tbl_department AS d LEFT JOIN tbl_handler AS h1 ON (h1.class = " . HANDLER_CLASS_DEF_DIR1 . " AND h1.item1 = d.dept_code) ORDER BY d.dept_code, d.level, d.dept_id";
$objDac->execute($sql);
if ($objDac->getRowCount() <= 0) {
	DispError("組織情報が一件も登録されていません。", 2, "javascript:history.back()");
	exit();
}
//組織情報の作成
$template_ary = array();
$directory_ary = array();
$ExpCavData = array();
$max_template_cnt = 0;
$max_dir_cnt = 0;
$CsvLine = 0;
while ($objDac->fetch()) {
	$tmp_cnt = 0;
	$dir_cnt = 0;
	$dir_list_ary = array();
	$list = array();
	$dir_temp = array();
	
	// 組織コード詳細
	$dept_info = getDeptCode($objDac->fld['dept_code']);
	
	$ExpCavData[$CsvLine][] = substr($objDac->fld['dept_code'], 0, CODE_DIGIT_DEPT); //組織コード1(部)
	$ExpCavData[$CsvLine][] = substr($objDac->fld['dept_code'], CODE_DIGIT_DEPT, CODE_DIGIT_DEPT); //組織コード2(課)
	$ExpCavData[$CsvLine][] = substr($objDac->fld['dept_code'], (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), CODE_DIGIT_DEPT); //組織コード3(係)
	$ExpCavData[$CsvLine][] = $objDac->fld['name']; //組織名
	$ExpCavData[$CsvLine][] = $objDac->fld['tel']; //問い合せ先TEL
	$ExpCavData[$CsvLine][] = $objDac->fld['fax']; //問い合せ先FAX
	$ExpCavData[$CsvLine][] = $objDac->fld['email']; //問い合せ先Eメール
	$ExpCavData[$CsvLine][] = $objDac->fld['address']; //問い合せ先住所
	$ExpCavData[$CsvLine][] = $objDac->fld['url']; //問い合せ先URL
	$ExpCavData[$CsvLine][] = $objDac->fld['sort_order']; //表示順
	$ExpCavData[$CsvLine][] = ($dept_info['level'] == G_DEPT_LEVEL03) ? $objDac->fld['def_dir1'] : ''; //通常ページ初期ディレクトリ
	
	// 第三組織以外はテンプレート・フォルダを表示しない
	if($dept_info['level'] != G_DEPT_LEVEL03){
		$CsvLine++;
		continue;
	}
	
	$sql = "SELECT class, item2 FROM tbl_handler WHERE class IN (" . HANDLER_CLASS_DIRECTORY . ", " . HANDLER_CLASS_TEMPLATE . ") AND item1 = '" . gd_addslashes($objDac->fld['dept_code']) . "' ORDER BY class DESC, item2";
	$objDac2->execute($sql);
	while ($objDac2->fetch()) {
		// テンプレート項目
		if ($objDac2->fld['class'] == HANDLER_CLASS_TEMPLATE) {
			$template_ary[$CsvLine][] = $objDac2->fld['item2'];
			$tmp_cnt++;
		}
		// ディレクトリ項目
		else if ($objDac2->fld['class'] == HANDLER_CLASS_DIRECTORY) {
			$dir_temp[] = $objDac2->fld['item2'];
			if (preg_match("/\/\*\/?$/", $objDac2->fld['item2'])) {
				$dir = preg_replace("/\/\*\/?$/", "", $objDac2->fld['item2']);
				
				$dir_list_ary[] = $dir . "/";
				
				$directory_list = make_dirtree($dir);
				if ($directory_list === FALSE) {
					DispError("ディレクトリ情報の取得に失敗しました。", 2, "javascript:history.back()");
					exit();
				}
				
				$dir_list = array();
				get_dirlist($dir_list, $directory_list);
				$dir_list_ary[] = $dir_list;
			}
			$dir_cnt++;
		}
	}
	
	//「*」ワイルドカードの対象となるディレクトリ一覧取得
	foreach ((array) $dir_list_ary as $dir_list) {
		foreach ((array) $dir_list as $dir) {
			$list[] = $dir;
		}
	}
	//重複パスの削除
	$dir_list = array_unique($list);
	
	$dir_cnt = 0;
	foreach ((array) $dir_temp as $dir) {
		if (in_array($dir, $dir_list)) {
			continue;
		}
		$directory_ary[$CsvLine][] = $dir;
		$dir_cnt++;
	}
	
	//テンプレート項目の最大数をセットする
	if ($tmp_cnt > $max_template_cnt) {
		$max_template_cnt = $tmp_cnt;
	}
	
	//ディレクトリ項目の最大数をセットする
	if ($dir_cnt > $max_dir_cnt) {
		$max_dir_cnt = $dir_cnt;
	}
	$CsvLine++;
}

// 見出しのテンプレート項目数は少なくともMIN_ROW_CNT_TEMPLATE以上とする
if ($max_template_cnt < MIN_ROW_CNT_TEMPLATE) {
	$max_template_cnt = MIN_ROW_CNT_TEMPLATE;
}
// 見出し行にテンプレート分の項目を追加
for($idx = 1; $idx <= $max_template_cnt; $idx++) {
	$G_SetHead[] = '権限のあるテンプレートID' . $idx;
}
// テンプレート情報を追加
for ($line_cnt = 0; $line_cnt < $CsvLine; $line_cnt++) {
	$temp_cnt = 0;
	// テンプレートが存在する場合
	if (isset($template_ary[$line_cnt])) {
		// 存在する分のテンプレートを出力
		foreach ($template_ary[$line_cnt] as $template) {
			$ExpCavData[$line_cnt][] = $template;
			$temp_cnt++;
		}
		// 不足分の項目を空白で出力
		for (; $temp_cnt < $max_template_cnt; $temp_cnt++) {
			$ExpCavData[$line_cnt][] = '';
		}
	}
	// テンプレートが存在しない場合
	else {
		// 不足分の項目を空白で出力
		for (; $temp_cnt < $max_template_cnt; $temp_cnt++) {
			$ExpCavData[$line_cnt][] = '';
		}
	}
}

// 見出しのディレクトリ項目数は少なくともMIN_ROW_CNT_DIRECTORY以上とする
if ($max_dir_cnt < MIN_ROW_CNT_DIRECTORY) {
	$max_dir_cnt = MIN_ROW_CNT_DIRECTORY;
}
// 見出し行にディレクトリ分の項目を追加
for($idx = 1; $idx <= $max_dir_cnt; $idx++) {
	$G_SetHead[] = '権限のあるフォルダ' . $idx;
}
// ディレクトリ情報を追加
for ($line_cnt = 0; $line_cnt < $CsvLine; $line_cnt++) {
	$dir_cnt = 0;
	// ディレクトリが存在する場合
	if (isset($directory_ary[$line_cnt])) {
		// 存在する分のディレクトリを出力
		foreach ($directory_ary[$line_cnt] as $directory) {
			$ExpCavData[$line_cnt][] = $directory;
			$dir_cnt++;
		}
		// 不足分の項目を空白で出力
		for (; $dir_cnt < $max_dir_cnt; $dir_cnt++) {
			$ExpCavData[$line_cnt][] = '';
		}
	}
	// ディレクトリが存在しない場合
	else {
		// 不足分の項目を空白で出力
		for (; $dir_cnt < $max_dir_cnt; $dir_cnt++) {
			$ExpCavData[$line_cnt][] = '';
		}
	}
}

//出力処理
create_Csv("department.csv", $ExpCavData, $G_SetHead, 0, "", "sjis-win", "\"");
?>
