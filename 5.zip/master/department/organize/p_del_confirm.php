<?php
/*
 * 使用されなくなるファイルのチェック(Ajaxで呼び出す)(公開時に削除する一覧)
 */
/** require **/
require ("../../.htsetting");

// 
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
// 
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$objLinks = new tbl_links($objCnc);
// 
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
//
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
//
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete.inc');
$objEnq = new tbl_enquete($objCnc);
//
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
$objKanko = new tbl_kanko($objCnc);

if (isset($_SESSION['pub_depend']['dellist'])) unset($_SESSION['pub_depend']['dellist']);
$_SESSION['pub_depend']['dellist'] = array();

$cntRelFiles = array();

// 画像・ファイルパスにGET(?～)が付加されている場合は消す
$gp = '/(\?|#).*$/i';
$del_list_data = array();
$checkAry = array();
$page_ids = "";

if (isset($_SESSION['file_list']['del']) && is_array($_SESSION['file_list']['del']) && count($_SESSION['file_list']['del']) > 0) {
	$del_list_data = $_SESSION['file_list']['del'];
}

// ファイル保存先が変更される組織編制対象ページID取得
if (isset($_SESSION['file_list']['page_id']) && is_array($_SESSION['file_list']['page_id']) && count($_SESSION['file_list']['page_id']) > 0) {
	$page_id_ary = array_unique($_SESSION['file_list']['page_id']);
	$page_ids = implode(",", $page_id_ary);
}

foreach ((array) $del_list_data as $pid => $checkAry) {
	$del_file_list = array();
	
	$pTbl = WORK_TABLE;
	
	if ($objPage->selectFromID($pid, WORK_TABLE) === FALSE) {
		// 取得に失敗した場合は公開情報を取得
		if ($objPage->selectFromID($pid, PUBLISH_TABLE) === FALSE) {
			// 完全に取得に失敗した場合はエラー
			print "-1,ページ情報の取得に失敗しました。";
			exit();
		}
		$pTbl = PUBLISH_TABLE;
	}
	
	$work_class = $objPage->fld['work_class'];
	
	foreach ($checkAry as $key => $file_path) {
		
		$file_path = preg_replace($gp, "", $file_path);
		
		// ファイルが既に存在しない
		if (!@file_exists(DOCUMENT_ROOT . RPW . $file_path)) continue;
		
		// 規定のディレクトリの保存されていない画像・ファイルは対象外
		if (!preg_match("/(" . reg_replace(FCK_IMAGES_FORDER) . '|' . reg_replace(FCK_FILELINK_FORDER) . ')$/', cms_dirname($file_path))) continue;
		
		// 自身のページ以外の公開情報で使用されていないかチェック -------------------------------- //
		$objLinks->setTableName(PUBLISH_TABLE);
		$objImages->setTableName(PUBLISH_TABLE);
		
		// リンクテーブルの公開情報より検索
		$where = $objLinks->_addslashesC('path', $file_path, 'LIKE', 'TEXT'); // ファイルパス
		$where .= " AND " . $objLinks->_addslashesC('outer_flg', 0, '=', 'INT'); // 外部参照以外
		$where .= " AND " . $objLinks->_addslashesC('page_id', ($page_ids == "" ? $pid : $page_ids), 'NOT IN', 'INT'); // ページID
		$objLinks->select($where);
		// 使われている場合
		if ($objLinks->getRowCount() > 0) continue;
		
		// イメージテーブルの公開集情報より検索
		$where = $objImages->_addslashesC('src', $file_path, 'LIKE', 'TEXT'); // ファイルパス
		$where .= " AND " . $objImages->_addslashesC('page_id', ($page_ids == "" ? $pid : $page_ids), 'NOT IN', 'INT'); // ページID
		$objImages->select($where);
		// 使われている場合
		if ($objImages->getRowCount() > 0) continue;
		
		// 自身のページ以外の編集情報で使用されていないかチェック -------------------------------- //
		$objLinks->setTableName(WORK_TABLE);
		$objImages->setTableName(WORK_TABLE);
		
		// リンクテーブルの編集情報より検索
		$where = $objLinks->_addslashesC('path', $file_path, 'LIKE', 'TEXT'); // ファイルパス
		$where .= " AND " . $objLinks->_addslashesC('outer_flg', 0, '=', 'INT'); // 外部参照以外
		$where .= " AND " . $objLinks->_addslashesC('page_id', ($page_ids == "" ? $pid : $page_ids), 'NOT IN', 'INT'); // ページID
		$objLinks->select($where);
		// 使われている場合
		if ($objLinks->getRowCount() > 0) continue;
		
		// イメージテーブルの編集情報より検索
		$where = $objImages->_addslashesC('src', $file_path, 'LIKE', 'TEXT'); // ファイルパス
		$where .= " AND " . $objImages->_addslashesC('page_id', ($page_ids == "" ? $pid : $page_ids), 'NOT IN', 'INT'); // ページID
		$objImages->select($where);
		// 使われている場合
		if ($objImages->getRowCount() > 0) continue;
		
		// 削除予定リストに既に登録されていないかチェック ---------------------------------------- //
		if ($objHandler->selectPublishDeleteFile($pid, $file_path) !== FALSE) continue;
		
		// 自身のページの、現在の編集領域で使用されていないかチェック ---------------------------- //
		

		if (in_array($file_path, $cntRelFiles)) continue;
		
		// 他ページのアンケート領域で使用されていないかチェック ---------------------------------- //
		$objEnq->add_where('img_src', $file_path, 'LIKE');
		$objEnq->add_where('page_id', ($page_ids == "" ? $pid : $page_ids), 'NOT IN', 'INT');
		$objEnq->setTableName(PUBLISH_TABLE);
		$objEnq->select();
		// 使用されている場合
		if ($objEnq->getRowCount() > 0) continue;
		$objEnq->add_where('img_src', $file_path, 'LIKE');
		$objEnq->add_where('page_id', ($page_ids == "" ? $pid : $page_ids), 'NOT IN', 'INT');
		$objEnq->setTableName(WORK_TABLE);
		$objEnq->select();
		// 使用されている場合
		if ($objEnq->getRowCount() > 0) continue;
		
		// 他のページの定型情報で使用されていないかチェック -------------------------------------- //
		

		// 公開情報で使用されている場合
		if ($objKanko->checkUseFiles($file_path, PUBLISH_TABLE, "", ($page_ids == "" ? $pid : $page_ids), "IN")) continue;
		
		// 編集情報
		if ($objKanko->checkUseFiles($file_path, WORK_TABLE, "", ($page_ids == "" ? $pid : $page_ids), "IN")) continue;
		
		// 削除が可能なのでリストに追加
		$del_file_list[] = $file_path;
	}
	
	// 重複パスを削除しファイルパスを保持
	if (count($del_file_list) > 0) {
		$_SESSION['pub_depend']['dellist'][$pid]['page_title'] = $objPage->fld['page_title'];
		$_SESSION['pub_depend']['dellist'][$pid]['file_path'] = $objPage->fld['file_path'];
		$_SESSION['pub_depend']['dellist'][$pid]['list'] = array_unique($del_file_list);
	}
}

print "0,true";

?>