<?php
/*
 * 組織編制エクスポート処理
 */

// 設定ファイル読み込み
require ("./.htsetting");

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$obj_dac = new dac($objCnc);
$obj_dac2 = new dac($objCnc);

// 変数の宣言
// CSVファイルの作成用フォルダ
$g_dir_path = DIR_PATH_TEMP . uniqid();
$g_where = '';
// 入力された組織コード
$g_dept_code = 0;
// CSV情報
$g_tmp_page_data = array();
$already_export = array();

// 第三組織が指定されている場合
if ($_POST['cms_dept3'] != '') {
	$g_dept_code = $_POST['cms_dept3'];
}
// 第二組織が指定されている場合
else if ($_POST['cms_dept2'] != '') {
	$g_dept_code = substr($_POST['cms_dept2'], 0, 6) . '%';
}
// 第一組織が指定されている場合
else if ($_POST['cms_dept1'] != '') {
	// ウェブマスターの場合
	if ($_POST['cms_dept1'] == WEB_MASTER_CODE) {
		$g_dept_code = WEB_MASTER_CODE;
	}
	else {
		$g_dept_code = substr($_POST['cms_dept1'], 0, 3) . '%';
	}
}
// 何も指定されていない場合は、全件対象とする
else {
	$g_dept_code = '%';
}

// 指定された組織のページデータの取得処理
$fields = 'p.page_id, p.user_id AS p_user_id, w.user_id AS w_user_id';
$obj_dac->setTableName('tbl_publish_page AS p LEFT JOIN tbl_work_page AS w ON (p.page_id = w.page_id)');
$orderby = 'p.page_id';

// 作成者の指定
$g_where .= '(p.user_id IN (SELECT user_id FROM tbl_user WHERE dept_code LIKE \'' . $g_dept_code . '\') AND w.user_id IS NULL)';
$g_where .= ' OR (w.user_id IN (SELECT user_id FROM tbl_user WHERE dept_code LIKE \'' . $g_dept_code . '\'))';
// サイトトップページは対象外とする
$g_where .= ' AND ' . $obj_dac->_addslashesC('p.file_path', SITE_TOP_PAGE, '!=');

// 抽出（指定された組織が所有しているページの一覧）
$obj_dac->select($g_where, $fields, $orderby);

// 取得したページの数分ループ
$page_id_ary = array();
while ($obj_dac->fetch()) {
	// 編集中のページがある場合
	if ($obj_dac->fld['w_user_id'] != NULL) {
		$page_id_ary[WORK_TABLE][] = $obj_dac->fld['page_id'];
	}
	// 編集中のページが無い場合
	else {
		$page_id_ary[PUBLISH_TABLE][] = $obj_dac->fld['page_id'];
	}
}

// テーブルの数分ループ
foreach ($page_id_ary as $tbl => $page_ids) {
	// 抽出条件の指定
	$fields = 'u.user_id, u.dept_code, u.name, p.page_id, p.file_path, p.page_title, p.cate_code, p.inquiry_memo, p.inquiry_id';
	$obj_dac2->setTableName(($tbl == PUBLISH_TABLE ? 'tbl_publish_page' : 'tbl_work_page') . ' AS p INNER JOIN tbl_user AS u ON (u.user_id = p.user_id)');
	$g_where = 'page_id IN (' . implode(', ', $page_ids) . ')';
	
	// 抽出
	$obj_dac2->select($g_where, $fields, $orderby);
	
	// 取得したページの数分ループ
	while ($obj_dac2->fetch()) {
		$g_tmp_page_data[$obj_dac2->fld['page_id']] = $obj_dac2->fld;
		$g_tmp_page_data[$obj_dac2->fld['page_id']]['tbl'] = $tbl;
	}
}

// CSVファイルの作成
if (!makeCsvFile('organize.csv', $g_tmp_page_data)) {
	// ファイルの削除
	removeDir(DOCUMENT_ROOT . $g_dir_path);
	user_error('CSVファイルの作成に失敗しました。【organize.csv】');
	exit();
}

// 出力したページIDを取得
$already_export = array_keys($g_tmp_page_data);

// 変数の初期化
$g_where = '';
$g_tmp_page_data = array();

// テーブルの数分ループ
$table_ary = array(
	PUBLISH_TABLE, 
	WORK_TABLE
);
foreach ($table_ary as $tbl) {
	// ページの情報を抽出する
	$fields = 'u.user_id, u.dept_code, u.name, p.page_id, p.file_path, p.page_title, p.cate_code, p.inquiry_memo, p.inquiry_id';
	$obj_dac->setTableName(($tbl == PUBLISH_TABLE ? 'tbl_publish_page' : 'tbl_work_page') . ' AS p INNER JOIN tbl_user AS u ON (u.user_id = p.user_id)');
	$orderby = 'p.page_id';
	$g_where = 'p.inquiry_id IN (SELECT i.inquiry_id FROM ' . ($tbl == PUBLISH_TABLE ? 'tbl_publish_inquiry' : 'tbl_work_inquiry') . ' AS i WHERE i.dept_code LIKE \'' . $g_dept_code . '\')';
	// 出力済みのページが存在する場合
	if (count($already_export) != 0) {
		$g_where .= ' AND p.page_id NOT IN (' . implode(', ', $already_export) . ')';
	}
	
	// 抽出（指定された組織が問い合わせ先に指定されているページの一覧）
	$obj_dac->select($g_where, $fields, $orderby);
	
	// 取得したページの数分ループ
	while ($obj_dac->fetch()) {
		$g_tmp_page_data[$obj_dac->fld['page_id']] = $obj_dac->fld;
		$g_tmp_page_data[$obj_dac->fld['page_id']]['tbl'] = $tbl;
	}
}

// CSVファイルの作成
if (!makeCsvFile('inquiry.csv', $g_tmp_page_data)) {
	// ファイルの削除
	removeDir(DOCUMENT_ROOT . $g_dir_path);
	user_error('CSVファイルの作成に失敗しました。【inquiry.csv】');
	exit();
}

// 実際に圧縮する
$zip_path = DOCUMENT_ROOT . $g_dir_path . '/organize.zip';
if (defined("SET_ZIP_EXE")) {
	exec('cd ' . DOCUMENT_ROOT . $g_dir_path . '/organize' . ' & ' . SET_ZIP_EXE . ' -r ' . $zip_path . ' *');
}
else {
	exec('cd ' . DOCUMENT_ROOT . $g_dir_path . '/organize' . '; zip -r ' . $zip_path . ' *');
}

// Zipファイルの存在チェック
if (!@is_file($zip_path)) {
	// ファイルの削除
	removeDir(DOCUMENT_ROOT . $g_dir_path);
	user_error('Zipファイルの作成に失敗しました。【' . $zip_path . '】');
	exit();
}

// Zipファイルの出力
if (($zip_file = @file_get_contents($zip_path)) === FALSE) {
	// ファイルの削除
	removeDir(DOCUMENT_ROOT . $g_dir_path);
	user_error('Zipファイルの読み込みに失敗しました。【' . $zip_path . '】');
	exit();
}
$file_size = @filesize($zip_path);

// ファイルの削除
removeDir(DOCUMENT_ROOT . $g_dir_path);

//ヘッダ出力
header("Content-Type: application/octet-stream");
header("Content-Disposition: attachment; filename=" . basename($zip_path));
header('Content-Length: ' . $file_size);
echo $zip_file;

exit();

/**
 * CSVを作成する
 * @param $csv_file_name CSVファイルの名称
 * @param $tmp_page_data CSVを作成するページのデータ
 * @return 作成ができた場合はTRUE、そうでない場合はFALSEを返す
 */
function makeCsvFile($csv_file_name, $tmp_page_data) {
	// 外部ファイルの読み込み
	global $obj_dac2;
	global $g_dir_path;
	
	// 定数の宣言
	// 見出し文字
	$ORGANIZE_CSV_HEADER = getDefineArray('ORGANIZE_CSV_HEADER');
	// 見出し文字（問い合わせ部分）
	$ORGANIZE_CSV_HEADER_INQUIRY = getDefineArray('ORGANIZE_CSV_HEADER_INQUIRY');
	
	// 変数の宣言
	$exp_csv_data = array();
	$tmp_set_head = array();
	$csv_line = 0;
	// 問い合わせ情報
	$max_inq_cnt = 0;
	$max_item_cnt = 0;
	$tmp_inq_data = array();
	
	// ページIDでソートする
	ksort($tmp_page_data);
	
	// ページの数分ループ
	foreach ($tmp_page_data as $page_id => $fld) {
		// ページID
		$exp_csv_data[$csv_line][] = $fld['page_id'];
		// ページタイトル
		$exp_csv_data[$csv_line][] = $fld['page_title'];
		// ページパス
		$exp_csv_data[$csv_line][] = $fld['file_path'];
		// 組織コード
		$exp_csv_data[$csv_line][] = $fld['dept_code'];
		// ユーザーID
		$exp_csv_data[$csv_line][] = $fld['user_id'];
		// 分類コード
		$exp_csv_data[$csv_line][] = $fld['cate_code'];
		// 問い合わせフリー入力
		$exp_csv_data[$csv_line][] = $fld['inquiry_memo'];
		// 問い合わせ情報の取得
		$obj_dac2->setTableName(($fld['tbl'] == PUBLISH_TABLE ? 'tbl_publish_inquiry' : 'tbl_work_inquiry'));
		$obj_dac2->select($obj_dac2->_addslashesC('inquiry_id', $fld['inquiry_id']));
		$inq_cnt = 0;
		while ($obj_dac2->fetch()) {
			// 問い合わせ組織コード
			$tmp_inq_data[$csv_line][] = $obj_dac2->fld['dept_code'];
			// 問い合わせ担当者名
			$tmp_inq_data[$csv_line][] = $obj_dac2->fld['name'];
			// 問い合わせ電話番号
			$tmp_inq_data[$csv_line][] = $obj_dac2->fld['drxt_number'];
			// 問い合わせ内線番号
			$tmp_inq_data[$csv_line][] = $obj_dac2->fld['anex_number'];
			// 問い合わせFAX番号
			$tmp_inq_data[$csv_line][] = $obj_dac2->fld['fax'];
			// 問い合わせE-Mailアドレス
			$tmp_inq_data[$csv_line][] = $obj_dac2->fld['email'];
			$inq_cnt++;
		}
		// 問い合わせの最大値を更新
		if ($max_inq_cnt < $inq_cnt) {
			$max_inq_cnt = $inq_cnt;
		}
		$csv_line++;
	}
	
	// 問い合わせの最大数分ループ
	for($i = 1; $i <= $max_inq_cnt; $i++) {
		// 問い合わせの見出し文字
		// 問い合わせ組織コード
		$tmp_set_head[] = $ORGANIZE_CSV_HEADER_INQUIRY[0]['label'] . $i;
		// 問い合わせ担当者名
		$tmp_set_head[] = $ORGANIZE_CSV_HEADER_INQUIRY[1]['label'] . $i;
		// 問い合わせ電話番号
		$tmp_set_head[] = $ORGANIZE_CSV_HEADER_INQUIRY[2]['label'] . $i;
		// 問い合わせ内線番号
		$tmp_set_head[] = $ORGANIZE_CSV_HEADER_INQUIRY[3]['label'] . $i;
		// 問い合わせFAX番号
		$tmp_set_head[] = $ORGANIZE_CSV_HEADER_INQUIRY[4]['label'] . $i;
		// 問い合わせE-Mailアドレス
		$tmp_set_head[] = $ORGANIZE_CSV_HEADER_INQUIRY[5]['label'] . $i;
	}
	
	// 問い合わせの項目数を取得
	if ($max_inq_cnt > 0) {
		$max_item_cnt = (count($tmp_set_head) / $max_inq_cnt);
	}
	
	// データを追加
	foreach ($exp_csv_data as $csv_line => $csv_date) {
		// 問い合わせの最大数分ループ
		for($i = 1; $i <= $max_inq_cnt; $i++) {
			// 問い合わせの項目数分ループ
			for($j = ($max_item_cnt * $i - $max_item_cnt); $j < $max_item_cnt * $i; $j++) {
				if (isset($tmp_inq_data[$csv_line][$j])) {
					$exp_csv_data[$csv_line][] = $tmp_inq_data[$csv_line][$j];
				}
				else {
					$exp_csv_data[$csv_line][] = '';
				}
			}
		}
	}
	
	// 出力処理
	$ret = create_Csv($csv_file_name, $exp_csv_data, array_merge($ORGANIZE_CSV_HEADER, $tmp_set_head), 1, $g_dir_path . '/organize', "sjis-win", "\"");
	return $ret;
}
?>
