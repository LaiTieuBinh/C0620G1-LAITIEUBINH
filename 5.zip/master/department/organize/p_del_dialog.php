<?php
/*
 * 使用されなくなる画像があった場合に表示されるダイアログ(公開時に削除する一覧)
 */
/** require **/
require ("./.htsetting");

// zipファイル作成
require ("./zip_download.php");
if (!isset($dl_zip_path) || strlen(trim($dl_zip_path)) < 1) {
	$msg = "Zipファイルの作成に失敗しました。";
	user_error($msg);
	exit();
}

// 削除対象リスト表示用テンプレート
$listTemplate = '<table width="95%" border="0" cellpadding="2" cellspacing="2" class="cms8341-dataTable"';
$listTemplate .= ' style="border-collapse:collapse;border:solid 1px #CCCCCC;margin-bottom: 5px;" >';
$listTemplate .= '<tr>' . '<th align="left">';
$listTemplate .= '{page_title}' . '<br />' . '{file_path}';
$listTemplate .= '</th>' . '</tr>';
$listTemplate .= '<tr>' . '<td>' . '{list}' . '</td>' . '</tr>' . '</table>';

$message = '移動・削除される依存ファイル一覧をまとめたzipファイルのダウンロードを行ってください。';

// 削除対象ファイルリストHTML
$listHTML = "";

if (isset($_SESSION['pub_depend']['dellist']) && count($_SESSION['pub_depend']['dellist']) > 0) {
	foreach ($_SESSION['pub_depend']['dellist'] as $page_id => $deta_ary) {
		$file_path_str = "";
		$listTemplate_tmp = str_replace("{page_title}", $deta_ary['page_title'], $listTemplate);
		$listTemplate_tmp = str_replace("{file_path}", $deta_ary['file_path'], $listTemplate_tmp);
		
		foreach ((array) $deta_ary['list'] as $file) {
			if ($file_path_str != "") $file_path_str .= "<br />\n";
			$file_path_str .= htmlspecialchars($file);
		}
		$listHTML .= str_replace("{list}", $file_path_str, $listTemplate_tmp);
	}
	$message .= '<br><br>どのページからも参照されなくなるファイルがあります。<br>ページ公開後に削除します。よろしいですか。';
}
else {
	$listHTML = '削除対象となる依存ファイルが存在しませんでした。';
}

// タイトル
$titleHTML = "公開後にファイルを削除します";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Expires" content="Thu, 01 Dec 1994 16:00:00 GMT">
<title><?=$titleHTML?></title>
<base target="_self" />
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

// 親ウィンドウへの戻り値
retObj = new Object();
window.returnValue = false;

var download_flg = false;
var download_flg2 = false;

// 「はい」クリック
function cxDeleteYes( ) {

	if (download_flg != true) {
		download_flg2 = true;
		alert("zipファイルのダウンロードが行われていません。\nダウンロードボタンを押下してください。");
		return false;
	}

	var params = "";
	
	// パラメーターの作成
	params = '';
	// Ajax でPHPに接続
	var ajax = new Ajax.Request(
		cms8341admin_path+'/master/department/organize/p_del_submit.php',
		{
			method: 'post',
			asynchronous: false,
			parameters: params
		}
	);
	// PHP からの戻り値(print)を取得
	ret_ajax_pf = ajax.transport.responseText;
	ret = ret_ajax_pf.split(",");
	// エラーフラグ
	var _error = ret[0];
	// 削除フラグ
	var _exec  = ret[1];

	// エラー表示
	if ( _error == "-1" ) {
		alert( _exec );
		return false;
	}	
	cxIframeLayerCallback();
	return false;
}

// 「いいえ」クリック
function cxDeleteNo( ) {

	if (download_flg != true) {
		download_flg2 = true;
		alert("zipファイルのダウンロードが行われていません。\nダウンロードボタンを押下してください。");
		return false;
	}
	
	cxIframeLayerCallback();
	return false;
}

function zip_download(dl_zip_path) {
	location.href = dl_zip_path;
	
	download_flg = true;
	download_flg2 = true;
	return false;
}


window.onbeforeunload = function(event){

	event = event || window.event;

	if (download_flg != true) {
		if (download_flg2 != true) {
			event.returnValue = "移動・削除される依存ファイル一覧をまとめたzipファイルの\nダウンロードが行われていません。\n\nウィンドウを閉じてもよろしいですか?";
		}
	}
	download_flg2 = false;
}

//-->
</script>
</head>
<body bgcolor="#DFDFDF">
<?php /* ヘッダー */?>
<div id="cms8341-headareaZero" style="margin-bottom: 0px !important">
<?php /* メイン */?>
<div id="cms8341-searcharea"
	style="width: 97%; height: 100%; overflow: auto; margin: 10px 7px; background-color: #DFDFDF; padding: 0px; text-align: left; border: solid 1px #343434;">
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	bgcolor="#FFFFFF" align="left" style="border-collapse: collapse;">
	<tr>
		<td align="center" style="padding: 10px 10px 0px 10px">
		<p align="left" style="margin-top: 5px;"><?=$message?></p>
		<div
			style="width: 95%; height: 235px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px 10px 0px 10px; text-align: center; vertical-align: middle; border: solid 1px #999999">
		<table width="100%" border="0" cellpadding="0" cellspacing="0"
			style="border-collapse: collapse;">
			<tr>
				<td align="left" valign="middle">
		<?=$listHTML?>
		</td>
			</tr>
		</table>
		</div>
<?php
if (isset($_SESSION['pub_depend']['dellist']) && count($_SESSION['pub_depend']['dellist']) > 0) {
	?>
		<p style="margin-top: 10px;"><span><a href="javascript:"
			onClick="cxDeleteYes();"><img
			src="<?=RPW?>/admin/images/btn/btn_yes.jpg" alt="はい" width="100"
			height="20" border="0"></a></span> <span style="margin-left: 20px;"><a
			href="javascript:" onClick="cxDeleteNo();"><img
			src="<?=RPW?>/admin/images/btn/btn_no.jpg" alt="いいえ" width="100"
			height="20" border="0"></a></span> <span style="margin-left: 20px;"><a
			id="test_test" href="javascript:" onClick="zip_download('<?=$dl_zip_path?>');"><img
			src="<?=RPW?>/admin/images/btn/btn_download.jpg" alt="ダウンロード"
			width="100" height="20" border="0"></a></span></p>
<?php
}
else {
	?>
		<p style="margin-top: 10px;"><span><a href="javascript:"
			onClick="cxDeleteNo();"><img
			src="<?=RPW?>/admin/images/btn/btn_shuts.jpg" alt="閉じる" width="100"
			height="20" border="0"></a></span> <span style="margin-left: 20px;"><a
			id="test_test" href="javascript:" onClick="zip_download('<?=$dl_zip_path?>');"><img
			src="<?=RPW?>/admin/images/btn/btn_download.jpg" alt="ダウンロード"
			width="100" height="20" border="0"></a></span></p>
<?php
}
?>
		</td>
	</tr>
</table>
</div>
<form id="form" class="cms8341-form" name="form" action="" method="post">
</form>

</body>
</html>