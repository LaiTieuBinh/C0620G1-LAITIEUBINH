<?php
/*
 * 使用されなくなる画像があった場合に表示されるダイアログ(公開時に削除する一覧)
 */
/** require **/
require ("./.htsetting");

$date = date("YmdHis");
$file_path = $objLogin->login['user_id'] . '/organize';
//作成しようとしているフォルダの初期化
$tmp_path = DOCUMENT_ROOT . DIR_PATH_TEMP . $file_path;
removeDir($tmp_path);

if (!mkNewDirectory($tmp_path . '/dammy.txt')) {
	$objCnc->rollback();
	$kohoFunc->error("フォルダの作成に失敗しました。");
}

// 移動対象依存ファイルリスト作成
// ヘッダー情報作成
$header_ary = array(
		'コピー元依存ファイルパス', 
		'コピー先依存ファイルパス'
);
// データ情報初期値
$csv_data_ary = array(
		0 => array(
				'', 
				''
		)
);

if (isset($_SESSION['file_list']['move']) && count($_SESSION['file_list']['move']) > 0) {
	$CsvLine = 0;
	foreach ((array) $_SESSION['file_list']['move'] as $page_id=>$move_data_ary) {
		foreach ((array) $move_data_ary as $move_data) {
			$ary = array(
					$move_data['from'], 
					$move_data['to']
			);
			$csv_data_ary[$CsvLine] = $ary;
			$CsvLine++;
		}
	}
}

$csv_file_path = DIR_PATH_TEMP . $file_path;
// CSVファイル作成
create_Csv('move_file.csv', $csv_data_ary, $header_ary, 1, $csv_file_path, 'shift-jis', "\"");

// 削除対象依存ファイルリスト作成
// ヘッダー情報作成
$header_ary = array(
		'削除対象依存ファイルパス'
);
// データ情報初期値
$csv_data_ary = array(
		0 => array(
				''
		)
);

if (isset($_SESSION['pub_depend']['dellist']) && count($_SESSION['pub_depend']['dellist']) > 0) {
	$del_file_path_list_ary = array();
	foreach ((array) $_SESSION['pub_depend']['dellist'] as $page_id => $data_ary) {
		foreach ((array) $data_ary['list'] as $del_file_path) {
			$del_file_path_list_ary[] = $del_file_path;
		}
	}
	
	// 重複ファイルパスを削除
	$del_file_path_list_ary = array_unique($del_file_path_list_ary);
	$CsvLine = 0;
	foreach ((array) $del_file_path_list_ary as $del_file_path) {
		$ary = array(
				$del_file_path
		);
		$csv_data_ary[$CsvLine] = $ary;
		$CsvLine++;
	}
}

$csv_file_path = DIR_PATH_TEMP . $file_path;
// CSVファイル作成
create_Csv('del_file.csv', $csv_data_ary, $header_ary, 1, $csv_file_path, 'shift-jis', "\"");

$zip_path = DOCUMENT_ROOT . DIR_PATH_TEMP . $file_path . '/' . $date . ".zip";
// ダウンロード用zipファイル
$dl_zip_path = DIR_PATH_TEMP . $file_path . '/' . $date . ".zip";
//Zipの作成に失敗
$msg = "";
if (!create_Zip($tmp_path, $zip_path)) {
	$objCnc->rollback();
	$msg = "Zipファイルの作成に失敗しました。【" . $tmp_path . "】";
	user_error($msg);
	exit();
}

/**
 * Zip圧縮を行う
 *
 * @param $folder_path 圧縮対象フォルダパス
 * @param $zip_path 圧縮後Zipパス
 * @return 作成に成功した場合は、TRUE。そうでない場合は、FALSEを返す。
 */
function create_Zip($folder_path, $zip_path) {
	//引数のチェック
	if ($folder_path == "" || $zip_path == "") return FALSE;
	//フォルダの存在チェック
	if (!@file_exists($folder_path)) return TRUE;
	
	//実際に圧縮する
	if (defined("SET_ZIP_EXE")) {
		exec('cd ' . $folder_path . ' & ' . SET_ZIP_EXE . ' -r ' . $zip_path . ' *');
	}
	else {
		exec('cd ' . $folder_path . '; zip -r ' . $zip_path . ' *');
	}
	
	//Zipファイルの存在チェック
	if (!@file_exists($zip_path)) return FALSE;
	return TRUE;
}
?>