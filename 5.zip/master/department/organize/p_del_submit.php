<?php
/*
 * 公開時に削除する依存ファイル情報の登録
 */
/** require **/
require ("../.htsetting");

if (!isset($objCnc)) global $objCnc;
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);

$objCnc->begin();
// 公開時削除するファイルを handler テーブルに保持
if (isset($_SESSION['pub_depend']['dellist']) && is_array($_SESSION['pub_depend']['dellist']) && count($_SESSION['pub_depend']['dellist']) > 0) {
	
	foreach ($_SESSION['pub_depend']['dellist'] as $PID => $deta_ary) {
		
		foreach ((array) $deta_ary['list'] as $path) {
			
			// 同一データは登録しない
			if ($objHandler->selectPublishDeleteFile($PID, $path) !== FALSE) continue;
			// 指定されたパスを削除予定リストに追加
			$temp_ary = array(
					'class' => HANDLER_CLASS_PUBLISH_DELETE_FILE, 
					'item1' => $PID, 
					'item2' => $path
			);
			if ($objHandler->insert($temp_ary) === FALSE) {
				$objCnc->rollback();
				print "-1,依存ファイル削除設定の登録に失敗しました。";
				exit();
			}
		}
	}
}
$objCnc->commit();

print "0,true";
?>