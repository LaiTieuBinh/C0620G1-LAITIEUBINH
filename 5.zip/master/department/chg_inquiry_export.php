<?php
/*
 *
 */

/** require **/
require ("./.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

$file_name = 'inquiry_page.csv'; //CSV出力ファイル名
$char_code = 'sjis'; //CSV出力文字コード
$esc_char = '"'; //CSVエスケープ文字
//CSV見出し文字
$csv_head = array(
		"ページID", 
		"ページタイトル", 
		"ファイルパス", 
		"お問い合わせ情報"
);
//CSV内容配列
$csv_put_ary = array();

if (isset($_POST['cms_target_before_3']) && $_POST['cms_target_before_3'] != "") {
	$dept_before = $_POST['cms_target_before_3'];
}
elseif (isset($_POST['cms_target_before_2']) && $_POST['cms_target_before_2'] != "") {
	$dept_before = $_POST['cms_target_before_2'];
}
elseif (isset($_POST['cms_target_before_1']) && $_POST['cms_target_before_1'] != "") {
	$dept_before = $_POST['cms_target_before_1'];
}
else {
	DispError("変更対象の組織が選択されていません。", 2, "javascript:history.back()");
	exit();
}

//変換対象となる作業中のページを取得
$fields = ' w.page_id, w.page_title, w.file_path, wi.drxt_number, wi.fax, wi.email, d.dept_name, d.address, d.url';
$where = $objPage->_addslashesC('wi.dept_code', $dept_before, '=');
$table = 'tbl_work_page AS w';
$table .= ' INNER JOIN tbl_work_inquiry AS wi ON (w.inquiry_id = wi.inquiry_id)';
$table .= ' INNER JOIN tbl_department AS d ON (d.dept_code = wi.dept_code)';
$objPage->select($where, $fields, '', '', '', $table);
while ($objPage->fetch()) {
	$fld = $objPage->fld;
	$page_id = $fld['page_id'];
	if (isset($csv_put_ary[$page_id])) {
		$csv_put_ary[$page_id][3] .= "\n\n" . _get_inq_str($fld);
		continue;
	}
	$csv_put_ary[$page_id][0] = $fld['page_id'];
	$csv_put_ary[$page_id][1] = $fld['page_title'];
	$csv_put_ary[$page_id][2] = $fld['file_path'];
	$csv_put_ary[$page_id][3] = _get_inq_str($fld);
}

//変換対象となる公開中のページを取得
$fields = ' p.page_id, p.page_title, p.file_path, pi.drxt_number, pi.fax, pi.email, d.dept_name, d.address, d.url';
$where = $objPage->_addslashesC('pi.dept_code', $dept_before, '=');
$table = 'tbl_publish_page AS p';
$table .= ' INNER JOIN tbl_publish_inquiry AS pi ON (p.inquiry_id = pi.inquiry_id)';
$table .= ' INNER JOIN tbl_department AS d ON (d.dept_code = pi.dept_code)';
$objPage->select($where, $fields, '', '', '', $table);
while ($objPage->fetch()) {
	$fld = $objPage->fld;
	if (isset($csv_put_ary[$fld['page_id']])) {
		continue;
	}
	$csv_put_ary[$fld['page_id']][0] = $fld['page_id'];
	$csv_put_ary[$fld['page_id']][1] = $fld['page_title'];
	$csv_put_ary[$fld['page_id']][2] = $fld['file_path'];
	$csv_put_ary[$fld['page_id']][3] = _get_inq_str($fld);
}

create_Csv($file_name, $csv_put_ary, $csv_head, 0, "", $char_code, $esc_char);

exit();

/**
 * CSVのお問い合わせの文字列取得
 * @param $fld ページ・お問い合わせ・組織情報
 * @return 文字列
 */
function _get_inq_str($fld) {
	$ret_ary = array();
	$ret_ary[] = '組織名：' . $fld['dept_name'];
	$ret_ary[] = '住所：' . $fld['address'];
	$ret_ary[] = '電話番号：' . $fld['drxt_number'];
	$ret_ary[] = 'ファックス番号：' . $fld['fax'];
	$ret_ary[] = 'メールアドレス：' . $fld['email'];
	$ret_ary[] = 'URL：' . $fld['url'];
	return implode("\n", $ret_ary);
}
?>
