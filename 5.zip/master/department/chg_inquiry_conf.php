<?php
/*
 *
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/
//レヴェル
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


/** require **/
require ("./.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
$objDac_Before = new dac($objCnc);
$objDac_After = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInquiry = new tbl_inquiry($objCnc);

/** 定数 **/
define("G_CSV_MAX_LINE", 20000); //csvファイル最大行


/** 変数 **/
$label = '問い合わせ先変更';
$image = '<img src="images/bar_chg_inquiry.jpg" alt="問い合わせ先変更" width="920" height="30">';
//	$back = "javascript:history.back()";
$back = "chg_inquiry.php?bak=1";
$is_page_select = FLAG_OFF;

//同一ページ以外から来た場合セッション削除
if (!isset($_SERVER['HTTP_REFERER']) || preg_replace('/\?.*$/i', '', $_SERVER['HTTP_REFERER']) != HTTP_ROOT . $_SERVER['PHP_SELF']) unset($_SESSION['chg_inq_search']);
// セッションから値の取得 
if (isset($_SESSION['chg_inq_search'])) {
	$inq_search = $_SESSION['chg_inq_search'];
	$dept_before = $_SESSION['chg_inq_search']['dept_before'];
	$dept_after = $_SESSION['chg_inq_search']['dept_after'];
}
//ページ送り・表示件数変更以外
else if (!isset($_POST['cms_dispMode']) || $_POST['cms_dispMode'] == 'init') {
	if (isset($_SESSION['chg_inq'])) unset($_SESSION['chg_inq']);
	/*** SESSIONセット ***/
	//対象項目生成(変更対象の組織)
	if (isset($_POST['cms_target_before_1']) && $_POST['cms_target_before_1'] != "") {
		$_SESSION['chg_inq']['target_before_1'] = $_POST['cms_target_before_1'];
	}
	if (isset($_POST['cms_target_before_2']) && $_POST['cms_target_before_2'] != "") {
		$_SESSION['chg_inq']['target_before_2'] = $_POST['cms_target_before_2'];
	}
	if (isset($_POST['cms_target_before_3']) && $_POST['cms_target_before_3'] != "") {
		$_SESSION['chg_inq']['target_before_3'] = $_POST['cms_target_before_3'];
	}
	//対象項目生成(変更後の組織)
	if (isset($_POST['cms_target_after_1']) && $_POST['cms_target_after_1'] != "") {
		$_SESSION['chg_inq']['target_after_1'] = $_POST['cms_target_after_1'];
	}
	if (isset($_POST['cms_target_after_2']) && $_POST['cms_target_after_2'] != "") {
		$_SESSION['chg_inq']['target_after_2'] = $_POST['cms_target_after_2'];
	}
	if (isset($_POST['cms_target_after_3']) && $_POST['cms_target_after_3'] != "") {
		$_SESSION['chg_inq']['target_after_3'] = $_POST['cms_target_after_3'];
	}
	
	if (isset($_POST['cms_target_before_3']) && $_POST['cms_target_before_3'] != "") {
		$dept_before = $_POST['cms_target_before_3'];
	}
	elseif (isset($_POST['cms_target_before_2']) && $_POST['cms_target_before_2'] != "") {
		$dept_before = $_POST['cms_target_before_2'];
	}
	elseif (isset($_POST['cms_target_before_1']) && $_POST['cms_target_before_1'] != "") {
		$dept_before = $_POST['cms_target_before_1'];
	}
	else {
		DispError("変更対象の組織が選択されていません。", 2, "javascript:history.back()");
		exit();
	}
	
	if (isset($_POST['cms_target_after_3']) && $_POST['cms_target_after_3'] != "") {
		$dept_after = $_POST['cms_target_after_3'];
	}
	elseif (isset($_POST['cms_target_after_2']) && $_POST['cms_target_after_2'] != "") {
		$dept_after = $_POST['cms_target_after_2'];
	}
	elseif (isset($_POST['cms_target_after_1']) && $_POST['cms_target_after_1'] != "") {
		$dept_after = $_POST['cms_target_after_1'];
	}
	else {
		DispError("変更後の組織が選択されていません。", 2, "javascript:history.back()");
		exit();
	}
	// ページ指定
	if (isset($_POST['cms_page_select'])) {
		$_SESSION['chg_inq']['cms_page_select'] = $_POST['cms_page_select'];
	}
}
else {
	DispError("不正なパラメータです。", 2, "javascript:history.back()");
	exit();
}
// ---ページ指定があった場合セッションに値を設定
// ページ指定の値だった場合で且つページ送り・表示件数でない場合はチェックする
if ($_SESSION['chg_inq']['cms_page_select'] == FLAG_ON && !isset($_SESSION['chg_inq_search'])) {
	$errmsg = '';
	if (($page_id_ary = _chk_csv_file($errmsg)) === FALSE) {
		DispError($errmsg, 2, "javascript:history.back()");
		exit();
	}
	$_SESSION['chg_inq_search']['page_id'] = $page_id_ary;
	$_SESSION['chg_inq_search']['dept_before'] = $dept_before;
	$_SESSION['chg_inq_search']['dept_after'] = $dept_after;
	$inq_search = $_SESSION['chg_inq_search'];
}
// ページ指定フラグ
$is_page_select = (isset($_SESSION['chg_inq']['cms_page_select'])) ? $_SESSION['chg_inq']['cms_page_select'] : FLAG_OFF;

// アップロード処理中か確認
$is_lock = lock_file_management('check');
if ($is_lock) {
	DispError("現在アップロード処理中のため問い合わせ先変更を行うことができません。<br>しばらく時間をおいてから再度お試しください。<br>", 2, "javascript:history.back()");
	exit();
}

//変換対象となる公開中のページ数を取得
$sql = "SELECT DISTINCT pp.page_id FROM tbl_publish_page AS pp INNER JOIN tbl_publish_inquiry AS pi ON (pp.inquiry_id = pi.inquiry_id) WHERE pi.dept_code = '" . $dept_before . "'";
if (isset($inq_search['page_id']) && !empty($inq_search['page_id'])) $sql .= ' AND ' . $objDac->_addslashesC('pp.page_id', implode(',', $inq_search['page_id']), 'IN');
$objDac->execute($sql);
$pub_cnt = $objDac->getRowCount();

//変換対象となる作業中のページ数を取得
$sql = "SELECT DISTINCT pw.page_id FROM tbl_work_page AS pw INNER JOIN tbl_work_inquiry AS wi ON (pw.inquiry_id = wi.inquiry_id) WHERE wi.dept_code = '" . $dept_before . "'";
if (isset($inq_search['page_id']) && !empty($inq_search['page_id'])) $sql .= ' AND ' . $objDac->_addslashesC('pw.page_id', implode(',', $inq_search['page_id']), 'IN');
$objDac->execute($sql);
$work_cnt = $objDac->getRowCount();

//変換対象となる組織情報を取得
$sql = "SELECT * FROM tbl_department WHERE dept_code = '" . $dept_before . "'";
$objDac_Before->execute($sql);
if ($objDac_Before->getRowCount() == 0) {
	DispError("選択した変更対象の組織が存在しません。", 2, "javascript:history.back()");
	exit();
}
$objDac_Before->fetch();

//変換後の組織情報を取得
$sql = "SELECT * FROM tbl_department WHERE dept_code = '" . $dept_after . "'";
$objDac_After->execute($sql);
if ($objDac_After->getRowCount() == 0) {
	DispError("選択した変更後の組織が存在しません。", 2, "javascript:history.back()");
	exit();
}
$objDac_After->fetch();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$label?></title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="department.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script src="../../js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function chg_inquiry_conf() {
	if(!confirm("変換を開始します。よろしいですか？")){
		return false;
	}
	$('form').action = 'chg_inquiry_comp.php';
	$('form').submit();
	return false;
}

/**
* ページ番号をPOSTする
* @param page ページ番号
* @return false
*/
function cxPageSet(page){
	$('form').cms_page.value = page;
	$('form').maxrow.value = $('maxrow').value;
	$('form').action = 'chg_inquiry_conf.php';
	$('form').submit();
	return false;
}

/**
* 表示件数を変える
* @param prev_num 表示件数
* @return false
*/
function cxDispNum(prev_num){
	$('form').cms_page.value = 1;
	$('form').maxrow.value = prev_num;
	$('form').action = 'chg_inquiry_conf.php';
	$('form').submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'department';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-approve">
<div><?=$image?></div>
<div class="cms8341-area-corner">
<p>以下の内容で問い合わせ先を一括変換しますがよろしいですか？<br>
※問い合わせ先を変換したページは即公開されます。<br>
<br>
<strong>変換対象となるページ数：（公開・非公開ページ：<?=$pub_cnt?>件、作業中ページ：<?=$work_cnt?>件）</strong></p>
<form id="form" class="cms8341-form" name="form" method="post"
	action="chg_inquiry_comp.php"><strong>変更対象の組織</strong>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" style="margin-bottom: 10px; padding: 1px">
	<tr>
		<th width="200" align="left" valign="middle" scope="row">組織コード</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['dept_code']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">組織名</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['dept_name']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">住所</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['address']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">電話番号</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['tel']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">ファックス番号</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['fax']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">メールアドレス</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['email']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">URL</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['url']?></td>
	</tr>
</table>
<strong>変更後の組織</strong>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" style="margin-bottom: 10px; padding: 1px">
	<tr>
		<th width="200" align="left" valign="middle" scope="row">組織コード</th>
		<td align="left" valign="top"><?=$objDac_After->fld['dept_code']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">組織名</th>
		<td align="left" valign="top"><?=$objDac_After->fld['dept_name']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">住所</th>
		<td align="left" valign="top"><?=$objDac_After->fld['address']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">電話番号</th>
		<td align="left" valign="top"><?=$objDac_After->fld['tel']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">ファックス番号</th>
		<td align="left" valign="top"><?=$objDac_After->fld['fax']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">メールアドレス</th>
		<td align="left" valign="top"><?=$objDac_After->fld['email']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">URL</th>
		<td align="left" valign="top"><?=$objDac_After->fld['url']?></td>
	</tr>
</table>
<?php
// ページ指定があった場合にページリストを表示 ----------------------------------------▼
if ($is_page_select == FLAG_ON) {
	$MAXROW_LIST = getDefineArray("MAXROW_LIST");
	$inq_search['maxrow'] = (isset($_POST['maxrow']) && is_numeric($_POST['maxrow']) ? floor($_POST['maxrow']) : key($MAXROW_LIST));
	$inq_search['cms_page'] = (isset($_POST['cms_page']) && is_numeric($_POST['cms_page']) ? floor($_POST['cms_page']) : 1);
	_search($inq_search);
	if ($objPage->getRowCount() > 0) {
		?>
<input type="hidden" name="maxrow" value="<?=$inq_search['maxrow']?>"> <input
	type="hidden" name="cms_page" value="<?=$inq_search['cms_page']?>"> <input
	type="hidden" name="cms_select_page_id"
	value="<?=implode(',', $inq_search['page_id'])?>">
<p style="margin-bottom: 0px;"><span style="float: right;"><?=mkcombobox($MAXROW_LIST, "maxrow", $inq_search['maxrow'], "cxDispNum(this.value)")?></span></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	style="margin-bottom: 10px; padding: 1px">
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objPage->objP->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objPage->objP->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objPage->objP->getNextLink()?></td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">状態</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">タイトル</th>
	</tr>
<?php
		while ($objPage->fetch()) {
			$fld = $objPage->fld;
			$inq_str = '';
			$prev_mode = 1;
			
			// ---お問い合わせ内容取得
			// 編集情報から取得
			$where = $objInquiry->_addslashesC('inquiry_id', $fld['w_inquiry_id'], '=');
			$where .= ' AND ' . $objInquiry->_addslashesC('wi.dept_code', $inq_search['dept_before'], '=');
			$table = 'tbl_work_inquiry AS wi';
			$table .= ' INNER JOIN tbl_department AS d ON(wi.dept_code = d.dept_code)';
			$objInquiry->select($where, 'wi.*, d.dept_name, d.address, d.url', '', '', '', $table);
			if ($objInquiry->getRowCount() > 0) {
				$prev_mode = 2;
				$page_title = htmlDisplay($fld['w_page_title']);
			}
			// 編集情報から取得できない場合は公開情報から取得
			else {
				$page_title = htmlDisplay($fld['page_title']);
				$where = $objInquiry->_addslashesC('inquiry_id', $fld['inquiry_id'], '=');
				$where .= ' AND ' . $objInquiry->_addslashesC('pi.dept_code', $inq_search['dept_before'], '=');
				$table = 'tbl_publish_inquiry AS pi';
				$table .= ' INNER JOIN tbl_department AS d ON(pi.dept_code = d.dept_code)';
				$objInquiry->select($where, 'pi.*, d.dept_name, d.address, d.url', '', '', '', $table);
			}
			// お問い合わせ内容文字列設定
			while ($objInquiry->fetch()) {
				$inq_str .= _get_inq_str($objInquiry->fld);
			}
			// ---ページのステータス設定
			$ret_ary = get_status_icon($fld);
			?>
	<tr>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/treelist/<?=$ret_ary['wc_img']?>"
			alt="<?=$ret_ary['wc_alt']?>" width="59" height="16" class="icon"></td>
		<td align="left" valign="top">
		<p><strong><a href="javascript:"
			onClick="return cxPreview('cms_CPreview','<?=$fld['page_id']?>','<?=$prev_mode?>');"><?=htmlDisplay($fld['page_title'])?></a></strong></p>
		<p><?=$inq_str?></p>
		</td>
	</tr>
<?php
		}
		?>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	style="margin-bottom: 10px; padding: 1px">
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objPage->objP->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objPage->objP->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objPage->objP->getNextLink()?></td>
	</tr>
</table>
<?php
	}
	else {
		?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-uploadlist"
	style="margin-bottom: 10px; padding: 1px">
	<tr>
		<th align="center" valign="middle" scope="col"
			style="font-weight: normal">&nbsp;</th>
	</tr>
	<tr>
		<td align="center" valign="middle">該当するページはありません。</td>
	</tr>
</table>
<?php
	}
}
// ページ指定があった場合にページリストを表示 ----------------------------------------▲
?>
<p align="center"><a href="javascript:"
	onclick="return chg_inquiry_conf()"><image
	src="./images/btn_change.jpg" alt="変更" width="150" height="20"
	border="0" style="margin-right: 10px"></a> <a href="<?=$back?>"><img
	src="../../images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150"
	height="20" border="0" style="margin-left: 10px"></a></p>
<input type="hidden" name="cms_target_before" value="<?=$dept_before?>">
<input type="hidden" name="cms_target_after" value="<?=$dept_after?>"> <input
	type="hidden" name="cms_is_page_select" value="<?=$is_page_select?>">

</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
</form>
<form name="cms_CPreview" id="cms_CPreview" class="cms8341-form"
	method="post" action="preview.php" target="_new"><input type="hidden"
	name="cms_dispMode" value="2"> <input type="hidden" name="cms_page_id"
	value=""></form>
<!-- cms8341-contents -->

</body>
</html>
<?php
//--- 関数
/**
 * CSVファイルのチェックを行う
 *
 * @param $errmsg エラーメッセージ(参照渡し)
 * @return ページIDの配列
 */
function _chk_csv_file(&$errmsg) {
	//---ファイルサイズチェック
	if ($_FILES['FrmCsvnm']['size'] <= 0) {
		$errmsg = '取り込んだファイルのファイルサイズが0バイトです。';
		return FALSE;
	}
	// CSV形式か
	$extension = strtolower(substr($_FILES['FrmCsvnm']['name'], (strrpos($_FILES['FrmCsvnm']['name'], '.') + 1)));
	if ($extension != 'csv') {
		$errmsg = 'csvファイルを指定してください。【ファイル名：' . $_FILES['FrmCsvnm']['name'] . '】';
		return FALSE;
	}
	//---アップロード
	$frmCsvFnm = DOCUMENT_ROOT . DIR_PATH_UPLOAD . "/temp/" . basename($_FILES['FrmCsvnm']['name']);
	if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $frmCsvFnm) == FALSE) {
		$errmsg = "csvファイルのアップロードに失敗しました。";
		return FALSE;
	}
	//(念のため)ファイル存在チェック
	if (file_exists($frmCsvFnm) == FALSE) {
		$errmsg = "指定されたファイル【" . $frmCsvFnm . "】が存在しません。";
		return FALSE;
	}
	//ファイルを開く
	if (!($CsvFno = fopen($frmCsvFnm, 'r'))) {
		$errmsg = "csvファイルのオープンに失敗しました。";
		return FALSE;
	}
	//一行目(見出し文字)は飛ばす
	$data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE);
	//EOFになるまで読み出し
	$page_id_ary = array();
	while ($data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
		// ページIDが空のとき、数値でないときは続行（検索用ページID配列に入れない）
		if ($data[0] == '' || !preg_match('/^\d+$/', $data[0])) {
			continue;
		}
		$page_id_ary[] = $data[0];
	}
	//ページIDを取得できたか確認
	if (empty($page_id_ary)) {
		$errmsg = "ページIDが1つも指定されていません。";
		return FALSE;
	}
	return $page_id_ary;
}

/**
 * ページ情報の抽出
 *
 * @param $search 検索情報の配列
 * @return TRUE|FALSE
 */
function _search($search) {
	global $objPage;
	
	//変換対象となるページを取得
	$fields = 'DISTINCT p.page_id, p.page_title, p.work_class, p.status, p.inquiry_id, p.close_flg';
	$fields .= ', w.page_title AS w_page_title,w.close_flg AS w_close_flg, w.inquiry_id as w_inquiry_id';
	$table = 'tbl_publish_page AS p';
	$table .= ' LEFT JOIN tbl_work_page AS w ON (p.page_id = w.page_id)';
	$table .= ' LEFT JOIN tbl_work_inquiry AS wi ON (w.inquiry_id = wi.inquiry_id)';
	$table .= ' LEFT JOIN tbl_publish_inquiry AS pi ON (p.inquiry_id = pi.inquiry_id)';
	//抽出条件設定
	$where = $objPage->_addslashesC('p.page_id', implode(',', $search['page_id']), 'IN');
	$where .= ' AND (' . $objPage->_addslashesC('wi.dept_code', $search['dept_before']);
	$where .= ' OR ' . $objPage->_addslashesC('pi.dept_code', $search['dept_before']) . ')';
	//リミット、オフセット設定
	if (isset($search['cms_page']) && isset($search['maxrow'])) {
		$objPage->select($where, 'DISTINCT p.page_id', "", "", "", $table);
		$cnt = $objPage->getRowCount();
		$objPage->objP = new page_control();
		$objPage->objP->limit = $search['maxrow'];
		$objPage->objP->set($search['cms_page'], $cnt);
		$offset = $objPage->objP->getOffset();
		$limit = $objPage->objP->getLimit();
	}
	else {
		$offset = '';
		$limit = '';
	}
	return $objPage->select($where, $fields, '', $offset, $limit, $table);
}
/**
 * お問い合わせの表示用文字列取得
 *
 * @param $inq_fld お問い合わせ・組織情報
 * @return HTML文字列
 */
function _get_inq_str($inq_fld) {
	$ret_ary = array();
	$ret_ary[] = '<strong>お問い合わせ先' . htmlDisplay($inq_fld['inquiry_no']) . '</strong>';
	$ret_ary[] = '組織名：' . htmlDisplay($inq_fld['dept_name']);
	$ret_ary[] = '住所：' . htmlDisplay($inq_fld['address']);
	$ret_ary[] = '電話番号：' . htmlDisplay($inq_fld['drxt_number']);
	$ret_ary[] = 'ファックス番号：' . htmlDisplay($inq_fld['fax']);
	$ret_ary[] = 'メールアドレス：' . htmlDisplay($inq_fld['email']);
	$ret_ary[] = 'URL：' . htmlDisplay($inq_fld['url']);
	return implode("<br>", $ret_ary);
}
?>
