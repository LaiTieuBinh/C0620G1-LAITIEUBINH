<?php
/*
 *
 */
/** require **/
require ("./.htsetting");

/** init **/
$dat = array();
/** get post data **/
$bv = $_POST["behavior"];
$user_id = $_SESSION["hidden"]["user_id"];
$dept_code = $_SESSION["hidden"]["dept_code"];
$class = $_SESSION["hidden"]["class"];
$name = $_SESSION["hidden"]["name"];
$email = $_SESSION["hidden"]["email"];
$login_id = $_SESSION["hidden"]["login_id"];
$password = $_SESSION["hidden"]["password"];
if (isset($_SESSION['hidden']['item1'])) $item1 = $_SESSION['hidden']['item1'];
if (isset($_SESSION['hidden']['c_user_id'])) $c_user_id = $_SESSION['hidden']['c_user_id'];
$sourceEdit_flg = $_SESSION["hidden"]["sourceEdit_flg"];
$approve_edit_flg = $_SESSION['hidden']['approve_edit_flg'];

$login_lock_chbox_flg = (isset($_SESSION['hidden']['login_lock_chbox_flg']) ? $_SESSION['hidden']['login_lock_chbox_flg'] : FLAG_OFF);

//戻り先index
$iDept = getDeptCode($dept_code);
$DspBackURL = "index.php?level=" . $iDept["level"] . "&dept_code=" . $dept_code . "#" . $iDept['dept1_code'];

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

switch ($bv) {
	case 1 :
		require ("./include/insert.inc");
		break;
	case 2 :
		require ("./include/update.inc");
		break;
	case 3 :
		require ("./include/delete.inc");
		break;
	default :
		DispError("パラメータ取得エラー（behavior）", 3, "javascript:history.back()");
		exit();
		break;
}
?>