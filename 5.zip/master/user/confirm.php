<?php
/*
 *
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/
//クラスイメージPath
$G_AreClassImg[] = array(
		"images/author.gif", 
		"images/approve01.gif", 
		"images/approve02.gif", 
		"images/approve03.gif", 
		"images/webmaster.gif", 
		"images/open.gif"
);
$G_AreClassImg[] = array(
		"ページ作成者", 
		"第1承認者", 
		"第2承認者", 
		"第3承認者", 
		"ウェブマスター", 
		"公開責任者"
);

//レヴェル
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


/** require **/
require ("./.htsetting");

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/** init **/
$dat = array();
unset($_SESSION["hidden"]);
$form_action = 'submit.php';
$cUser = 0;
$c_user = '';
$back = "javascript:history.back()";

/** function **/
function getPostData($objDac) {
	$dat = array();
	if (isset($_POST['user_id'])) $dat['user_id'] = $_POST['user_id'];
	if (isset($_POST['dept_code'])) $dat['dept_code'] = $_POST['dept_code'];
	elseif (isset($_POST['cms_target3']) && $_POST['cms_target3'] != "") $dat['dept_code'] = $_POST['cms_target3'];
	elseif (isset($_POST['cms_target2']) && $_POST['cms_target2'] != "") $dat['dept_code'] = $_POST['cms_target2'];
	elseif (isset($_POST['cms_target1']) && $_POST['cms_target1'] != "") $dat['dept_code'] = $_POST['cms_target1'];
	if (isset($_POST['class'])) $dat['class'] = $_POST['class'];
	if (isset($_POST['name'])) $dat['name'] = $_POST['name'];
	if (isset($_POST['email'])) $dat['email'] = $_POST['email'];
	if (isset($_POST['login_id'])) $dat['login_id'] = $_POST['login_id'];
	if (isset($_POST['password'])) $dat['password'] = $_POST['password'];
	//		if (isset($_POST['item1']))     $dat['item1']     = $_POST['item1'];
	if (isset($_POST['o_user_flg'])) $dat['item1'] = $_POST['o_user_flg'];
	if (isset($_POST['sourceEdit_flg'])) {
		$dat['sourceEdit_flg'] = $_POST['sourceEdit_flg'];
	}
	else {
		$dat['sourceEdit_flg'] = 0;
	}
	if (isset($_POST['approve_edit_flg'])) {
		$dat['approve_edit_flg'] = $_POST['approve_edit_flg'];
	}
	else {
		$dat['approve_edit_flg'] = 0;
	}
	
	if (isset($_POST['login_lock_chbox_flg'])) $dat['login_lock_chbox_flg'] = FLAG_ON;
	if (isset($_POST['login_lock_flg'])) $dat['login_lock_flg'] = $_POST['login_lock_flg'];
	
	//
	$msg = "";
	if (isset($iDept)) unset($iDept);
	if (!isset($dat['class']) || $dat['class'] == "") {
		$msg .= "ユーザー権限が選択されていません。<br>";
	}
	if ($dat['class'] == USER_CLASS_WEBMASTER) {
		$dat['dept_code'] = WEB_MASTER_CODE;
	}
	elseif (!isset($dat['dept_code']) || $dat['dept_code'] == "") {
		$msg .= "所属組織が選択されていません。<br>";
	}
	else {
		$sql = "SELECT * FROM tbl_department" . " WHERE dept_code = '" . gd_addslashes($dat['dept_code']) . "'";
		$objDac->execute($sql);
		if (!$objDac->fetch()) {
			$msg .= "指定された所属組織に誤りがあります（" . $dat["dept_code"] . "）<br>";
		}
		else {
			$iDept = getDeptCode($dat['dept_code']);
			if ($dat['class'] == 1 && $iDept['level'] != G_DEPT_LEVEL03) {
				$msg .= "作成者の所属が係まで選択されていません。<br>";
			}
			elseif ($dat['class'] == 'app') {
				switch ($iDept['level']) {
					case G_DEPT_LEVEL01 :
						$dat['class'] = USER_CLASS_APPROVER3;
						break;
					case G_DEPT_LEVEL02 :
						$dat['class'] = USER_CLASS_APPROVER2;
						break;
					case G_DEPT_LEVEL03 :
						$dat['class'] = USER_CLASS_APPROVER1;
						break;
				}
			}
		}
	}
	if (!isset($dat["name"]) || $dat["name"] == "") {
		$msg .= "ユーザー名が入力されていません。<br>";
	}
	elseif (!checkMachineCode($dat["name"])) {
		$msg .= "ユーザー名に機種依存文字が使用されています。<br>";
	}
	if (!isset($dat["email"]) || $dat["email"] == "") {
		$msg .= "メールアドレスが入力されていません。<br>";
		//形式チェック
	//1: 文字列先頭から@直前までに、@以外の任意の文字が１文字以上あること
	//2: @は1つだけ指定されていること。
	//3: @の後にはドット以外の文字が１文字以上あること。
	//4: ドット後に任意の文字が１文字以上あること。
	}
	elseif (!preg_match("/^[\w\_\-][\w\_\-\.]*@[\w\_\-]+\.([\w\_\-]+\.)*\w+$/i", $dat["email"])) {
		$msg .= "メールアドレスとしてふさわしくない値が入力されています。<br>";
	}
	if (!isset($dat["login_id"]) || $dat["login_id"] == "") {
		$msg .= "ログインIDが入力されていません。<br>";
	}
	else {
		$sql = "SELECT user_id FROM tbl_user WHERE login_id = '" . gd_addslashes($dat['login_id']) . "'";
		if ($dat['user_id'] != "") $sql .= " AND user_id <> " . $dat['user_id'];
		$objDac->execute($sql);
		if ($objDac->fetch() && $objDac->fld['user_id'] != "") {
			$msg .= "入力されたログインIDはすでに存在しています。<br>";
		}
	}
	if (!isset($dat["password"]) || $dat["password"] == "") {
		$msg .= "パスワードが入力されていません。<br>";
	}
	//パスワードの内容チェック
	else {
		// パスワード入力内容チェック実行
		$check_result_flg_ary = checkPasswordString($dat['password']);
		// チェック結果を確認
		foreach ((array) $check_result_flg_ary as $check_type => $result_ary) {
			// チェック結果フラグが有効な場合
			if ($result_ary['result_flg'] == FLAG_ON) {
				// エラーメッセージを取得
				$msg .= htmlDisplay($result_ary['err_msg']) . '<br>';
			}
		}
	}
	
	if ($dat['class'] == USER_CLASS_WRITER && (!isset($dat['sourceEdit_flg']) || $dat['sourceEdit_flg'] == '')) {
		$msg .= "ソースモードが選択されていません。<br>";
	}
	//
	if ($msg != "") {
		if ($_POST['behavior'] == 1) DispError($msg, 3, "user/edit.php?back=1");
		else DispError($msg, 3, "javascript:history.back()");
		exit();
	}
	return $dat;
}

/** get post date **/
if (isset($_POST["behavior"])) {
	$bv = $_POST["behavior"];
}
else {
	DispError("パラメータ取得エラー(behavior)", 3, "javascript:history.back()");
	exit();
}
if (!isset($_POST["user_id"])) {
	DispError("パラメータ取得エラー(user_id)", 3, "javascript:history.back()");
	exit();
}
switch ($bv) {
	case 1 :
		$_SESSION['hidden'] = $_POST;
		$msg = '<p>この情報で登録してもよろしいですか？</p>';
		$back = "edit.php?back=1";
		$image = '<input type="image" src="../images/btn_add.jpg" alt="追加" width="150" height="20" border="0" style="margin-right:10px">';
		$dat = getPostData($objDac);
		break;
	case 2 :
		$msg = '<p>この情報で登録してもよろしいですか？</p>';
		$image = '<input type="image" src="../images/btn_fix.jpg" alt="修正" width="150" height="20" border="0" style="margin-right:10px">';
		$dat = getPostData($objDac);
		break;
	case 3 :
		$msg = '<p>この情報を削除してもよろしいですか？</p>';
		$image = '<input type="image" src="../images/btn_del.jpg" alt="削除" width="150" height="20" border="0" style="margin-right:10px">';
		$sql = "SELECT tbl_user.*, h.item1 " . "FROM tbl_user LEFT JOIN (SELECT item1 FROM tbl_handler WHERE class = " . HANDLER_CLASS_OEPN_FLG . ") AS h ON tbl_user.user_id = h.item1 " . "WHERE user_id = " . $_POST["user_id"];
		$objDac->execute($sql);
		if (!$objDac->fetch()) {
			DispError("指定されたユーザー情報が存在しません。", 3, "javascript:history.back()");
			exit();
		}
		$dat = $objDac->fld;
		if (isset($_POST['c_user_id']) && $_POST['c_user_id'] != '') {
			$dat['c_user_id'] = $_POST['c_user_id'];
			$cUser = 2;
			$sql = "SELECT name FROM tbl_user WHERE user_id = " . $dat['c_user_id'];
			$objDac->execute($sql);
			if (!$objDac->fetch()) {
				DispError("ユーザー情報取得エラー", 3, "javascript:history.back()");
				exit();
			}
			$c_user = $objDac->fld['name'];
		}
		elseif ($dat['class'] == USER_CLASS_WRITER) {
			$sql = "SELECT COUNT(page_id) AS rc FROM tbl_publish_page WHERE user_id = " . $dat["user_id"];
			$objDac->execute($sql);
			if ($objDac->fetch() && $objDac->fld['rc'] > 0) {
				$form_action = 'confirm.php';
				$msg = '<p>このユーザーの所有ページを引き継がせるユーザーを選択してください。</p>';
				$image = '<input type="image" src="../images/btn_conf.jpg" alt="確認" width="150" height="20" border="0" style="margin-right:10px">';
				$cUser = 1;
				$sql = "SELECT user_id, name FROM tbl_user" . " WHERE dept_code = '" . gd_addslashes($dat['dept_code']) . "'" . " AND class = " . USER_CLASS_WRITER . " AND user_id <> " . $dat['user_id'];
				$objDac->execute($sql);
				if ($objDac->getRowCount() > 0) {
					$c_user = '<select name="c_user_id">' . "\n";
					while ($objDac->fetch()) {
						$c_user .= '<option value="' . $objDac->fld['user_id'] . '">' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
					}
					$c_user .= '</select>';
				}
				else {
					$msg = '<p>所有ページを引き継がせるための作成者がいないため、このユーザーを削除できません。</p>';
					DispError($msg, 3, "javascript:history.back()");
					exit();
				}
			}
		}
		elseif ($dat['class'] == USER_CLASS_WEBMASTER && $dat['item1'] != "") {
			$sql = "SELECT COUNT(approve_id) AS rc FROM tbl_approve WHERE approve4 = " . $dat["user_id"];
			$objDac->execute($sql);
			if ($objDac->fetch() && $objDac->fld['rc'] > 0) {
				$msg = '<p>承認フローに公開責任者として設定されているため、このユーザーを削除できません。</p>';
				DispError($msg, 3, "javascript:history.back()");
				exit();
			}
		}
		break;
	default :
		DispError("パラメータエラー（behavior）", 3, "javascript:history.back()");
		exit();
		break;
}
//ウェブマスターの存在チェック
if ($bv == 3 || ($bv == 2 && isset($dat['item1']) && $dat['item1'] != "")) {
	$sql = "SELECT COUNT(u.user_id) AS rc FROM tbl_user AS u" . " LEFT JOIN (SELECT item1 FROM tbl_handler WHERE class=" . HANDLER_CLASS_OEPN_FLG . ") AS h ON (u.user_id = h.item1)" . " WHERE u.class = '" . USER_CLASS_WEBMASTER . "' AND u.user_id <> " . $dat['user_id'] . " AND h.item1 IS NULL";
	$objDac->execute($sql);
	if (!$objDac->fetch() || $objDac->fld['rc'] < 1) {
		if ($bv == 2) $msg = "ウェブマスターがいなくなるため、このユーザーを公開責任者に変更できません。";
		elseif ($bv == 3) $msg = "ウェブマスターがいなくなるため、このユーザーを削除できません。";
		DispError($msg, 3, "javascript:history.back()");
		exit();
	}
}
//公開責任者でない場合は、権限コード通りの値を取得
if (isset($dat['item1']) == FALSE || $dat['item1'] == "") {
	$DspClassImg = $G_AreClassImg[0][($dat['class'] - 1)];
	$DspClassArt = $G_AreClassImg[1][($dat['class'] - 1)];
}
else {
	$DspClassImg = $G_AreClassImg[0][5];
	$DspClassArt = $G_AreClassImg[1][5];
}
// 承認フローで使用されていたら変更不可
$sql = "SELECT COUNT(approve_id) AS rc FROM tbl_approve WHERE approve4 = " . $dat["user_id"];
$objDac->execute($sql);
if ($objDac->fetch() && $objDac->fld['rc'] > 0) {
	$DspClassImg = $G_AreClassImg[0][5];
	$DspClassArt = $G_AreClassImg[1][5];
}

/*---組織名称の取得---*/
$iDept = getDeptCode($dat['dept_code']);
$DspDeptNm = "";
if ($dat['class'] == USER_CLASS_WEBMASTER) {
	$DspDeptNm = "ウェブマスター";
}
else {
	//部
	$sql = "SELECT name FROM tbl_department" . " WHERE dept_code = '" . gd_addslashes($iDept['dept1_code']) . "'";
	$objDac->execute($sql);
	if ($objDac->fetch()) $DspDeptNm .= $objDac->fld['name'];
	// 課
	if ($iDept['level'] > G_DEPT_LEVEL01) {
		$sql = "SELECT name FROM tbl_department" . " WHERE dept_code = '" . gd_addslashes($iDept['dept2_code']) . "'";
		$objDac->execute($sql);
		if ($objDac->fetch()) $DspDeptNm .= " > " . $objDac->fld['name'];
	}
	// 係
	if ($iDept['level'] > G_DEPT_LEVEL02) {
		$sql = "SELECT name FROM tbl_department" . " WHERE dept_code = '" . gd_addslashes($iDept['dept3_code']) . "'";
		$objDac->execute($sql);
		if ($objDac->fetch()) $DspDeptNm .= " > " . $objDac->fld['name'];
	}
}
//ソースモード
$DspSourceEdit = ($dat['sourceEdit_flg'] == 1) ? 'ON' : 'OFF';

//ページ編集権限
$DspApproveEdit = ($dat['approve_edit_flg'] == 1) ? 'ON' : 'OFF';

// ログインロックエラーカウント&ロック機能
$LOGIN_LOCK_INFO_ARY = getDefineArray('LOGIN_LOCK_INFO_ARY');
$DspLoginLock = $LOGIN_LOCK_INFO_ARY[LOGIN_LOCK_MODE_NOT_LOCK];
// ログインロックチェック（削除確認時）
if (isset($dat['login_error_count']) && isset($dat['login_error_datetime'])) {
	if (isUserLock($dat['login_error_count'], $dat['login_error_datetime'])) {
		// ログインロック中表記取得
		$DspLoginLock = $LOGIN_LOCK_INFO_ARY[LOGIN_LOCK_MODE_LOCK];
	}
}
// ログインロック解除フラグ【有効】（新規・更新確認時）
else if (isset($dat['login_lock_chbox_flg'])) {
	// ログインロック中表記取得
	$DspLoginLock = $LOGIN_LOCK_INFO_ARY[LOGIN_LOCK_MODE_LOCK];
}
// ログインロック解除フラグ【無効】（新規・更新確認時）
else if (isset($dat['login_lock_flg']) && $dat['login_lock_flg'] == FLAG_ON && !isset($dat['login_lock_chbox_flg'])) {
	// ログインロック解除表記取得
	$DspLoginLock = $LOGIN_LOCK_INFO_ARY[LOGIN_LOCK_MODE_UNLOCK];
}

$_SESSION["hidden"] = $dat;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ユーザー情報確認</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="user.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'user';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-user">
<div><img src="images/bar_conf.jpg" alt="ユーザー情報確認" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?=$msg?>
<form id="form" class="cms8341-form" name="form"
	action="<?=$form_action?>" method="post">
<p align="left" id="cms8341-pankuzu"><?=$DspDeptNm?></p>
<p align="left"><img src="<?=$DspClassImg?>" alt="<?=$DspClassArt?>"
	width="100" height="20"></p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable"><?php
	if ($bv != 1) {
		?>
<tr>
		<th width="150" align="left" valign="top" scope="row">ユーザーID</th>
		<td align="left" valign="top"><?=htmlDisplay($dat['user_id'])?></td>
	</tr><?php
	}
	?>
<tr>
		<th width="150" align="left" valign="top" scope="row">ユーザー名 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay($dat['name'])?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">メールアドレス <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay($dat['email'])?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">ログインID <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay($dat['login_id'])?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">パスワード <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay($dat['password'])?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">認証ロック</th>
		<td align="left" valign="top"><?php echo($DspLoginLock); ?></td>
	</tr>
<?php
if ($dat['class'] != USER_CLASS_WEBMASTER) {
	?>
<tr>
		<th width="150" align="left" valign="top" scope="row">ソースモード <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=$DspSourceEdit?></td>
	</tr>
<?php
	if ($dat['class'] != USER_CLASS_WRITER) {
		?>
<tr>
		<th width="150" align="left" valign="top" scope="row">ページ編集権限 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=$DspApproveEdit?></td>
	</tr>
<?php
	}
	?>
<?php
}
?>
<?php

if ($cUser != 0 && $c_user != '') {
	?>
<tr>
		<th width="150" align="left" valign="top" scope="row">所有者変更 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=$c_user?></td>
	</tr><?php
}
?>
</table>
<p align="center"><?=$image?><a href="<?=$back?>"><img
	src="../images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0" style="margin-left: 10px"></a></p>

</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<input type="hidden" name="behavior" value="<?=$bv?>">
<input type="hidden" name="user_id" value="<?=$dat['user_id']?>">
</form>
</body>
</html>
