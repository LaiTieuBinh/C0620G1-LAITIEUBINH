<?php
/*
 * ユーザ管理　一覧画面(index.php)
 */
$StrDbg = "";
$GLOBALS["StrDbg"] = "";

/*---------------------------------------------
	定数 
----------------------------------------------*/
//表示＆組織レベル
define("G_DEPT_LEVEL00", 0); //初期画面
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


//エクスプローラー風プラマイ記号イメージPath
define("G_LIST_IMG_P", "../images/dir_plus.jpg"); //プラス
define("G_LIST_IMG_M", "../images/dir_minus.jpg"); //マイナス


//クラスイメージPath
$G_AreClassImg[] = array(
		"images/author.gif", 
		"images/approve01.gif", 
		"images/approve02.gif", 
		"images/approve03.gif"
);
$G_AreClassImg[] = array(
		"ページ作成者", 
		"第1承認者", 
		"第2承認者", 
		"第3承認者"
);

/*---------------------------------------------------------------------------------
	imprt.php
---------------------------------------------------------------------------------*/

/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

/*---引数の取得---*/
$args = ($_SERVER['REQUEST_METHOD'] == 'GET') ? $_GET : $_POST;
//表示レベル
if (isset($_REQUEST["level"]) == TRUE) {
	$PrmLevel = $args['level'];
	if (($PrmLevel != G_DEPT_LEVEL00) & ($PrmLevel != G_DEPT_LEVEL01) & ($PrmLevel != G_DEPT_LEVEL02) & ($PrmLevel != G_DEPT_LEVEL03)) {
		DispError("有効ではないパラメーターが指定されました。", 3, "javascript:history.back()");
		exit();
	}
}
else {
	//未指定の場合は初期画面表示
	$PrmLevel = G_DEPT_LEVEL00;
}
//組織コード
$PrmDeptCode = "";
if (($PrmLevel == G_DEPT_LEVEL01) || ($PrmLevel == G_DEPT_LEVEL02) || ($PrmLevel == G_DEPT_LEVEL03)) {
	if (isset($_REQUEST["dept_code"]) == TRUE) {
		$PrmDeptCode = $args['dept_code'];
	}
	else {
		//未指定の場合は初期画面表示
		$PrmLevel = G_DEPT_LEVEL00;
	}
}

/*--- データアクセスクラス ---*/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*--- ウェブマスタの取得---*/
$sql = "SELECT user_id, dept_code, name, item1, login_error_count, login_error_datetime FROM tbl_user AS u " . "LEFT JOIN (SELECT item1 FROM tbl_handler WHERE class=" . HANDLER_CLASS_OEPN_FLG . ") AS h ON u.user_id = h.item1 " . "WHERE (dept_code = '" . WEB_MASTER_CODE . "') " . "ORDER BY user_id";
$objDac->execute($sql);
//ウェブマスタデータの作成
$DspWebMst = "";
while ($objDac->fetch()) {
	$lock_img_str = '';
	// ログインロックチェック
	if (isUserLock($objDac->fld['login_error_count'], $objDac->fld['login_error_datetime'])) {
		// ログインロック中であればアイコン表示
		$lock_img_str = '<img src="' . RPW . '/admin/images/icon/icon_lock.gif" alt="ログインロック" width="16" height="14">';
	}
	if (strlen($objDac->fld['item1']) <= 0) {
		$DspWebMst = $DspWebMst . "<p align=\"left\">" . $lock_img_str . "<img src=\"images/webmaster.gif\" alt=\"ウェブマスター\" width=\"100\" height=\"20\">　" . "<a href=\"" . "detail.php?user_id=" . $objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL00 . "&dept_code=" . WEB_MASTER_CODE . "\">" . htmlspecialchars($objDac->fld['name']) . "</a></p>\n";
	}
	else {
		$DspWebMst = $DspWebMst . "<p align=\"left\">" . $lock_img_str . "<img src=\"images/open.gif\" alt=\"公開責任者\" width=\"100\" height=\"20\">　" . "<a href=\"" . "detail.php?user_id=" . $objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL00 . "&dept_code=" . WEB_MASTER_CODE . "\">" . htmlspecialchars($objDac->fld['name']) . "</a></p>\n";
	}
}

/*---一覧の取得---*/
//取得レベルに応じた表示データの作成
$DspLstUser = "";
switch ($PrmLevel) {
	case G_DEPT_LEVEL00 : //初期画面
		G_SetDspList_Level00($objDac, $DspLstUser);
		break;
	case G_DEPT_LEVEL01 : //部
		G_SetDspList_Level01($objDac, $PrmDeptCode, $G_AreClassImg, G_LIST_IMG_P, $DspLstUser);
		break;
	case G_DEPT_LEVEL02 : //課
		//課リストを作成
		G_SetDspList_Level02($objDac, $PrmDeptCode, $G_AreClassImg, G_LIST_IMG_P, $DspLstUser);
		break;
	case G_DEPT_LEVEL03 : //係
		//係リストを作成
		G_SetDspList_Level03($objDac, $PrmDeptCode, $G_AreClassImg, G_LIST_IMG_P, $DspLstUser);
		break;
}

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	レベル０、初期画面表示データ作成

【引数】	$i_objDac		取得されたデーターオブジェクト
		$o_DspLstUser	表示する一覧データ
		
【戻値】	True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspList_Level00($i_objDac, &$o_DspLstUser) {
	
	/*---展開されたデータを作成---*/
	$sql = "SELECT tbl_department.sort_order, tbl_department.level, tbl_department.dept_code, tbl_department.dept_name, Count(tbl_user.dept_code) AS dept_cnt, " . "tbl_user.user_id " . "FROM tbl_user RIGHT JOIN tbl_department ON tbl_user.dept_code = tbl_department.dept_code " . "GROUP BY tbl_department.sort_order, tbl_department.level, tbl_department.dept_code, tbl_department.dept_name " . "HAVING (tbl_department.level=" . G_DEPT_LEVEL01 . ") " . "ORDER BY tbl_department.dept_code, tbl_department.level, tbl_department.sort_order, tbl_user.class, tbl_user.user_id";
	
	//取得
	$i_objDac->execute($sql);
	
	//データ作成
	while ($i_objDac->fetch()) {
		$deptInfo = getDeptCode($i_objDac->fld['dept_code']);
		$o_DspLstUser .= "<p align=\"left\" class=\"dir_first\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL01 . "&dept_code=" . $i_objDac->fld['dept_code'] . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . G_LIST_IMG_P . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
	}

}

/*-----------------------------------------------------------------------------
	レベル１　「部」の展開

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_PrmDeptCode	引数で指定された組織コード
		$i_AreClassImg	画像のイメージパスが格納されているテーブル
		$i_ExpImg		展開部分のプラマイ記号
		$o_DspLstUser	表示する一覧データ
		
【戻値】	True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspList_Level01($i_objDac, $i_PrmDeptCode, $i_AreClassImg, $i_ExpImg, &$o_DspLstUser) {
	
	/*--- 組織コード部の切り出し ---*/
	$dept_01 = substr($i_PrmDeptCode, 0, CODE_DIGIT_DEPT);
	
	/*---対象となる部に所属しているユーザーを取得---*/
	$sql = "SELECT tbl_user.dept_code, tbl_user.class, tbl_user.user_id, tbl_user.name, tbl_user.login_error_count, tbl_user.login_error_datetime, tbl_department.dept_name " . "FROM tbl_user INNER JOIN tbl_department ON tbl_user.dept_code = tbl_department.dept_code " . "WHERE (((tbl_user.dept_code)='" . $i_PrmDeptCode . "')) " . "ORDER BY tbl_user.dept_code, tbl_user.class, tbl_user.user_id";
	//取得
	$i_objDac->execute($sql);
	$down_user_list = "";
	while ($i_objDac->fetch()) {
		$lock_img_str = '';
		// ログインロックチェック
		if (isUserLock($i_objDac->fld['login_error_count'], $i_objDac->fld['login_error_datetime'])) {
			// ログインロック中であればアイコン表示
			$lock_img_str = '<img src="' . RPW . '/admin/images/icon/icon_lock.gif" alt="ログインロック" width="16" height="14">';
		}
		$down_user_list .= "<p align=\"left\" class=\"dir_second\">" . $lock_img_str . "<img src=\"" . $i_AreClassImg[0][($i_objDac->fld['class'] - 1)] . "\" alt=\"" . $i_AreClassImg[1][($i_objDac->fld['class'] - 1)] . "\" width=\"100\" height=\"20\">　" . "<a href=\"" . "detail.php?user_id=" . $i_objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL01 . "&dept_code=" . $i_PrmDeptCode . "\">" . htmlspecialchars($i_objDac->fld['name']) . "</a>" . "（" . htmlspecialchars($i_objDac->fld['dept_name']) . "）" . "</p>\n";
	}
	
	/*---対象となる部の課を取得する---*/
	$sql = "SELECT tbl_department.dept_code, tbl_department.name, tbl_department.dept_name " . "FROM tbl_department " . "WHERE (((tbl_department.level)=" . G_DEPT_LEVEL02 . ") AND ((tbl_department.dept_code) Like '" . $dept_01 . "%')) " . "ORDER BY tbl_department.level, tbl_department.dept_code, tbl_department.sort_order, tbl_department.dept_id";
	//取得
	$i_objDac->execute($sql);
	//データ作成
	$down_list = "";
	while ($i_objDac->fetch()) {
		$deptInfo = getDeptCode($i_objDac->fld['dept_code']);
		$exp_img = $i_ExpImg;
		$down_list .= "<p align=\"left\" class=\"dir_second\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL02 . "&dept_code=" . $i_objDac->fld['dept_code'] . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . $exp_img . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
	}
	
	/*---リスト全体を作成---*/
	$sql = "SELECT tbl_department.dept_code, tbl_department.name, tbl_department.dept_name " . "FROM tbl_department " . "WHERE (((tbl_department.level)=" . G_DEPT_LEVEL01 . "))" . "ORDER BY tbl_department.level, tbl_department.dept_code, tbl_department.sort_order, tbl_department.dept_id";
	//取得
	$i_objDac->execute($sql);
	//データ作成
	while ($i_objDac->fetch()) {
		$deptInfo = getDeptCode($i_objDac->fld['dept_code']);
		if (strcmp($i_PrmDeptCode, $i_objDac->fld['dept_code']) == 0) {
			//展開された部
			$o_DspLstUser .= "<p align=\"left\" class=\"dir_first\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL00 . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . G_LIST_IMG_M . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
			//部に所属するユーザーを結合
			$o_DspLstUser .= $down_user_list;
			//部に所属する課を結合
			$o_DspLstUser .= $down_list;
		
		}
		else {
			//展開された部以外のデータ
			$o_DspLstUser .= "<p align=\"left\" class=\"dir_first\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL01 . "&dept_code=" . $i_objDac->fld['dept_code'] . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . $i_ExpImg . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
		}
	}

}

/*-----------------------------------------------------------------------------
	レベル２　「課」の展開

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_PrmDeptCode	引数で指定された組織コード
		$i_AreClassImg	画像のイメージパスが格納されているテーブル
		$i_ExpImg		展開部分のプラマイ記号
		$o_DspLstUser	表示する一覧データ
		
【戻値】	True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspList_Level02($i_objDac, $i_PrmDeptCode, $i_AreClassImg, $i_ExpImg, &$o_DspLstUser) {
	
	/*---部コードの切り出し---*/
	$dept_01 = substr($i_PrmDeptCode, 0, CODE_DIGIT_DEPT); //組織コード１の切り出し
	$dept_01_like = $dept_01;
	$dept_01 = str_pad($dept_01, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
	/*---係コードの切り出し---*/
	$dept_02 = substr($i_PrmDeptCode, 0, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT)); //組織コード２の切り出し
	

	/*---対象となる部と課に所属しているユーザーを取得---*/
	$sql = "SELECT tbl_department.level, tbl_user.dept_code, tbl_user.class, tbl_user.user_id, tbl_user.name, tbl_user.login_error_count, tbl_user.login_error_datetime, tbl_department.dept_name " . "FROM tbl_user INNER JOIN tbl_department ON tbl_user.dept_code = tbl_department.dept_code " . "WHERE (((tbl_department.level)=" . G_DEPT_LEVEL01 . " ) AND ((tbl_user.dept_code)='" . $dept_01 . "')) OR " . "(((tbl_department.level)=" . G_DEPT_LEVEL02 . ") AND ((tbl_user.dept_code) Like '" . $dept_02 . "%')) " . "ORDER BY tbl_department.level, tbl_user.dept_code, tbl_user.class, tbl_user.user_id";
	//取得
	$i_objDac->execute($sql);
	$dn_user_dept01 = "";
	$dn_user_dept02 = "";
	while ($i_objDac->fetch()) {
		$lock_img_str = '';
		// ログインロックチェック
		if (isUserLock($i_objDac->fld['login_error_count'], $i_objDac->fld['login_error_datetime'])) {
			// ログインロック中であればアイコン表示
			$lock_img_str = '<img src="' . RPW . '/admin/images/icon/icon_lock.gif" alt="ログインロック" width="16" height="14">';
		}
		if ($i_objDac->fld['level'] == G_DEPT_LEVEL01) {
			$dn_user_dept01 .= "<p align=\"left\" class=\"dir_second\">" . $lock_img_str . "<img src=\"" . $i_AreClassImg[0][($i_objDac->fld['class'] - 1)] . "\" alt=\"" . $i_AreClassImg[1][($i_objDac->fld['class'] - 1)] . "\" width=\"100\" height=\"20\">　" . "<a href=\"" . "detail.php?user_id=" . $i_objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL02 . "&dept_code=" . $i_PrmDeptCode . "\">" . htmlspecialchars($i_objDac->fld['name']) . "</a>" . "（" . htmlspecialchars($i_objDac->fld['dept_name']) . "）" . "</p>\n";
		}
		else {
			$dn_user_dept02 .= "<p align=\"left\" class=\"dir_third\">" . $lock_img_str . "<img src=\"" . $i_AreClassImg[0][($i_objDac->fld['class'] - 1)] . "\" alt=\"" . $i_AreClassImg[1][($i_objDac->fld['class'] - 1)] . "\" width=\"100\" height=\"20\">　" . "<a href=\"" . "detail.php?user_id=" . $i_objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL02 . "&dept_code=" . $i_PrmDeptCode . "\">" . htmlspecialchars($i_objDac->fld['name']) . "</a>" . "（" . htmlspecialchars($i_objDac->fld['dept_name']) . "）" . "</p>\n";
		}
	
	}
	
	/*---対象となる部の課の係を取得する---*/
	$sql = "SELECT tbl_department.dept_code, tbl_department.name, tbl_department.dept_name " . "FROM tbl_department " . "WHERE (((tbl_department.level)=" . G_DEPT_LEVEL03 . ") AND ((tbl_department.dept_code) Like '" . $dept_02 . "%')) " . "ORDER BY tbl_department.level, tbl_department.dept_code, tbl_department.sort_order, tbl_department.dept_id";
	//取得
	$i_objDac->execute($sql);
	//データ作成
	$down_list = "";
	while ($i_objDac->fetch()) {
		$deptInfo = getDeptCode($i_objDac->fld['dept_code']);
		$exp_img = $i_ExpImg;
		$down_list = $down_list . "<p align=\"left\" class=\"dir_third\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL03 . "&dept_code=" . $i_objDac->fld['dept_code'] . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . $exp_img . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
	}
	
	/*---一覧の作成---*/
	$sql = "SELECT tbl_department.dept_code, tbl_department.name, tbl_department.dept_name, tbl_department.level " . "FROM tbl_department " . "WHERE (((tbl_department.level)=" . G_DEPT_LEVEL01 . ")) OR " . "(((tbl_department.level)=" . G_DEPT_LEVEL02 . ") AND ((tbl_department.dept_code) Like '" . $dept_01_like . "%'))" . "ORDER BY tbl_department.dept_code, tbl_department.level, tbl_department.sort_order, tbl_department.dept_id;";
	//取得
	$i_objDac->execute($sql);
	//データ作成
	while ($i_objDac->fetch()) {
		//部データ
		if (G_DEPT_LEVEL01 == $i_objDac->fld['level']) {
			$deptInfo = getDeptCode($i_objDac->fld['dept_code']);
			//選択された部データ展開部
			if (strcmp($dept_01, $i_objDac->fld['dept_code']) == 0) {
				$o_DspLstUser = $o_DspLstUser . "<p align=\"left\" class=\"dir_first\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL00 . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . G_LIST_IMG_M . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
				//部に所属するユーザーデータの結合
				$o_DspLstUser .= $dn_user_dept01;
			}
			else {
				$o_DspLstUser .= "<p align=\"left\" class=\"dir_first\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL01 . "&dept_code=" . $i_objDac->fld['dept_code'] . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . $i_ExpImg . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
			}
		}
		//課データ
		if (G_DEPT_LEVEL02 == $i_objDac->fld['level']) {
			//展開された係展開部
			if (strcmp($i_PrmDeptCode, $i_objDac->fld['dept_code']) == 0) {
				$o_DspLstUser .= "<p align=\"left\" class=\"dir_second\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL01 . "&dept_code=" . $dept_01 . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . G_LIST_IMG_M . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
				//課に所属するユーザーデータの結合
				$o_DspLstUser .= $dn_user_dept02;
				//課に所属する係データの結合
				$o_DspLstUser .= $down_list;
			
			}
			else {
				$o_DspLstUser .= "<p align=\"left\" class=\"dir_second\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL02 . "&dept_code=" . $i_objDac->fld['dept_code'] . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . G_LIST_IMG_P . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
			}
		}
	}

}

/*-----------------------------------------------------------------------------
	レベル３　「係」の展開

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_PrmDeptCode	引数で指定された組織コード
		$i_AreClassImg	画像のイメージパスが格納されているテーブル
		$i_ExpImg		展開部分のプラマイ記号
		$o_DspLstUser	表示する一覧データ
		
【戻値】	True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspList_Level03($i_objDac, $i_PrmDeptCode, $i_AreClassImg, $i_ExpImg, &$o_DspLstUser) {
	
	/*---部コードの切り出し---*/
	$dept_01 = substr($i_PrmDeptCode, 0, CODE_DIGIT_DEPT); //組織コード１の切り出し
	$dept_01_like = $dept_01;
	$dept_01 = str_pad($dept_01, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
	
	/*---係コードの切り出し---*/
	$dept_02 = substr($i_PrmDeptCode, 0, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT)); //組織コード２の切り出し
	$dept_02_like = $dept_02;
	$dept_02 = str_pad($dept_02, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
	
	/*---対象となる部と課と係所属しているユーザーを取得---*/
	$sql = "SELECT tbl_department.level, tbl_user.dept_code, tbl_user.class, tbl_user.user_id, tbl_user.name, tbl_user.login_error_count, tbl_user.login_error_datetime, tbl_department.dept_name " . "FROM tbl_user INNER JOIN tbl_department ON tbl_user.dept_code = tbl_department.dept_code " . "WHERE " . "(((tbl_user.dept_code) Like '" . $dept_01_like . "%') AND ((tbl_department.level)=" . G_DEPT_LEVEL01 . ")) OR " . "(((tbl_user.dept_code) Like '" . $dept_02_like . "%') AND ((tbl_department.level)=" . G_DEPT_LEVEL02 . ")) OR " . "(((tbl_user.dept_code) = '" . $i_PrmDeptCode . "') AND ((tbl_department.level)=" . G_DEPT_LEVEL03 . ")) " . "ORDER BY tbl_department.level, tbl_user.dept_code, tbl_user.class, tbl_user.user_id";
	//取得
	$i_objDac->execute($sql);
	$dn_user_dept01 = "";
	$dn_user_dept02 = "";
	$dn_user_dept03 = "";
	while ($i_objDac->fetch()) {
		$lock_img_str = '';
		// ログインロックチェック
		if (isUserLock($i_objDac->fld['login_error_count'], $i_objDac->fld['login_error_datetime'])) {
			// ログインロック中であればアイコン表示
			$lock_img_str = '<img src="' . RPW . '/admin/images/icon/icon_lock.gif" alt="ログインロック" width="16" height="14">';
		}
		switch ($i_objDac->fld['level']) {
			case G_DEPT_LEVEL01 : //部
				$dn_user_dept01 .= "<p align=\"left\" class=\"dir_second\">" . $lock_img_str . "<img src=\"" . $i_AreClassImg[0][($i_objDac->fld['class'] - 1)] . "\" alt=\"" . $i_AreClassImg[1][($i_objDac->fld['class'] - 1)] . "\" width=\"100\" height=\"20\">　" . "<a href=\"" . "detail.php?user_id=" . $i_objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL03 . "&dept_code=" . $i_PrmDeptCode . "\">" . htmlspecialchars($i_objDac->fld['name']) . "</a>" . "（" . htmlspecialchars($i_objDac->fld['dept_name']) . "）" . "</p>\n";
				break;
			case G_DEPT_LEVEL02 : //課
				$dn_user_dept02 .= "<p align=\"left\" class=\"dir_third\">" . $lock_img_str . "<img src=\"" . $i_AreClassImg[0][($i_objDac->fld['class'] - 1)] . "\" alt=\"" . $i_AreClassImg[1][($i_objDac->fld['class'] - 1)] . "\" width=\"100\" height=\"20\">　" . "<a href=\"" . "detail.php?user_id=" . $i_objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL03 . "&dept_code=" . $i_PrmDeptCode . "\">" . htmlspecialchars($i_objDac->fld['name']) . "</a>" . "（" . htmlspecialchars($i_objDac->fld['dept_name']) . "）" . "</p>\n";
				break;
			case G_DEPT_LEVEL03 : //係
				$dn_user_dept03 .= "<p align=\"left\" class=\"dir_fourth\">" . $lock_img_str . "<img src=\"" . $i_AreClassImg[0][($i_objDac->fld['class'] - 1)] . "\" alt=\"" . $i_AreClassImg[1][($i_objDac->fld['class'] - 1)] . "\" width=\"100\" height=\"20\">　" . "<a href=\"" . "detail.php?user_id=" . $i_objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL03 . "&dept_code=" . $i_PrmDeptCode . "\">" . htmlspecialchars($i_objDac->fld['name']) . "</a>" . "（" . htmlspecialchars($i_objDac->fld['dept_name']) . "）" . "</p>\n";
				break;
		}
	
	}
	
	/*---一覧の作成---*/
	$sql = "SELECT tbl_department.dept_code, tbl_department.level, tbl_department.sort_order, tbl_department.name, tbl_department.dept_name " . "FROM tbl_department " . "WHERE (((tbl_department.level)=" . G_DEPT_LEVEL01 . ")) OR " . "(((tbl_department.dept_code) Like '" . $dept_01_like . "%') AND ((tbl_department.level)=" . G_DEPT_LEVEL02 . ")) OR " . "(((tbl_department.dept_code) Like '" . $dept_02_like . "%') AND ((tbl_department.level)=" . G_DEPT_LEVEL03 . ")) " . "ORDER BY tbl_department.dept_code, tbl_department.level, tbl_department.sort_order, tbl_department.level, tbl_department.sort_order, tbl_department.dept_id";
	//取得
	$i_objDac->execute($sql);
	//データ作成
	while ($i_objDac->fetch()) {
		$deptInfo = getDeptCode($i_objDac->fld['dept_code']);
		switch ($i_objDac->fld['level']) {
			case G_DEPT_LEVEL01 : //部
				if (strcmp($dept_01, $i_objDac->fld['dept_code']) == 0) {
					//選択された部データ展開部
					$o_DspLstUser .= "<p align=\"left\" class=\"dir_first\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL00 . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . G_LIST_IMG_M . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
					//部に所属するユーザーデータの結合
					$o_DspLstUser .= $dn_user_dept01;
				}
				else {
					$o_DspLstUser .= "<p align=\"left\" class=\"dir_first\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL01 . "&dept_code=" . $i_objDac->fld['dept_code'] . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . $i_ExpImg . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
				}
				break;
			case G_DEPT_LEVEL02 : //課
				if (strcmp($dept_02, $i_objDac->fld['dept_code']) == 0) {
					//選択された課データの展開部
					$o_DspLstUser .= "<p align=\"left\" class=\"dir_second\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL01 . "&dept_code=" . $dept_01 . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . G_LIST_IMG_M . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
					//課に所属するユーザーデータの結合
					$o_DspLstUser .= $dn_user_dept02;
				
				}
				else {
					$o_DspLstUser .= "<p align=\"left\" class=\"dir_second\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL02 . "&dept_code=" . $i_objDac->fld['dept_code'] . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . G_LIST_IMG_P . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
				}
				break;
			case G_DEPT_LEVEL03 : //係
				if (strcmp($i_PrmDeptCode, $i_objDac->fld['dept_code']) == 0) {
					//選択された係データの展開部
					$o_DspLstUser .= "<p align=\"left\" class=\"dir_third\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL02 . "&dept_code=" . $dept_02 . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . G_LIST_IMG_M . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
					//係に所属するユーザーデータの結合
					$o_DspLstUser .= $dn_user_dept03;
				}
				else {
					$o_DspLstUser .= "<p align=\"left\" class=\"dir_third\">" . "<a name=\"" . $i_objDac->fld['dept_code'] . "\"></a>" . "<a href=\"./index.php?level=" . G_DEPT_LEVEL03 . "&dept_code=" . $i_objDac->fld['dept_code'] . "#" . $deptInfo['dept1_code'] . "\">" . "<img src=\"" . $i_ExpImg . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\"></a>" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
				}
		}
	}

}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ユーザー一覧</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="user.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'user';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-users">
<div><img src="images/bar_user.jpg" alt="ユーザー一覧" width="920" height="30"></div>
<div class="cms8341-area-corner">
<?=$DspWebMst?>
<?=$DspLstUser?>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<form id="fUser" class="cms8341-form" name="fUser" action="edit.php"
	method="post"><input type="hidden" id="user_id" name="user_id" value="">
<input type="hidden" id="behavior" name="behavior" value="1"></form>
</body>
</html>