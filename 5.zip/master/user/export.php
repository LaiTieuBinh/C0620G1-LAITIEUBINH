<?php
/*
 * ユーザーテーブルの情報をエクスポートする
 */
//設定ファイル読み込み
require ("./.htsetting");
//データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

//定数 
//見出し文字
$G_SetHead = array(
		"組織コード1", 
		"組織コード2", 
		"組織コード3", 
		"ユーザーID", 
		"ユーザー名", 
		"メールアドレス", 
		"ログインID", 
		"パスワード", 
		"権限コード", 
		"管理者権限", 
		"ソース編集フラグ", 
		"ページ編集フラグ",
		"認証ロック",
		"最終ログインエラー日",
);
//公開責任者フラグ
define("G_OPEN_FLG", 1);

//データの取得
$sql = "SELECT * FROM tbl_user AS u LEFT JOIN (SELECT item1 FROM tbl_handler WHERE class = 3) AS h ON u.user_id = h.item1 ORDER BY user_id";
$objDac->execute($sql);
if ($objDac->getRowCount() <= 0) {
	DispError("ユーザー情報が一件も登録されていません。" . $sql, 3, "javascript:history.back()");
	exit();
}

//出力データの作成
$ExpCavData = array();
$CsvLine = 0;
while ($objDac->fetch()) {
	$ExpCavData[$CsvLine][] = substr($objDac->fld['dept_code'], 0, CODE_DIGIT_DEPT); //組織コード1(部)
	$ExpCavData[$CsvLine][] = substr($objDac->fld['dept_code'], CODE_DIGIT_DEPT, CODE_DIGIT_DEPT); //組織コード2(課)
	$ExpCavData[$CsvLine][] = substr($objDac->fld['dept_code'], (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), CODE_DIGIT_DEPT); //組織コード3(係)
	$ExpCavData[$CsvLine][] = $objDac->fld['user_id']; //ユーザーID
	$ExpCavData[$CsvLine][] = $objDac->fld['name']; //ユーザー名
	$ExpCavData[$CsvLine][] = $objDac->fld['email']; //メールアドレス
	$ExpCavData[$CsvLine][] = $objDac->fld['login_id']; //ログインＩＤ
	$ExpCavData[$CsvLine][] = $objDac->fld['password']; //パスワード
	$ExpCavData[$CsvLine][] = $objDac->fld['class']; //権限コード
	//公開責任者フラグ
	//ひも付けテーブルの公開責任者権限に対象ユーザーIDが登録されている場合は、公開責任者フラグをセットする
	if (strlen($objDac->fld['item1']) > 0) $ExpCavData[$CsvLine][] = G_OPEN_FLG;
	else $ExpCavData[$CsvLine][] = "";
	$ExpCavData[$CsvLine][] = $objDac->fld['sourceEdit_flg']; //ソース編集フラグ
	$ExpCavData[$CsvLine][] = $objDac->fld['approve_edit_flg']; //ページ編集フラグ
	
	$DspLoginLock = '0';
	$DspLoginErrorDate = '';
	// ログインロックチェック
	if (isUserLock($objDac->fld['login_error_count'], $objDac->fld['login_error_datetime'])) {
		$DspLoginLock = '1';
		// 最終エラー日時取得
		$DspLoginErrorDate = $objDac->fld['login_error_datetime'];
	}
	// 認証ロック
	$ExpCavData[$CsvLine][] = $DspLoginLock;
	// 最終ログインエラー日
	$ExpCavData[$CsvLine][] = $DspLoginErrorDate;
	
	$CsvLine++;
}

//CSV出力処理
create_Csv("user.csv", $ExpCavData, $G_SetHead, 0, "", "sjis-win", "\"");
?>
