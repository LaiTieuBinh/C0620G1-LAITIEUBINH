<?php
/*
 *
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/
//クラスイメージPath
$G_AreClassImg[] = array(
		"images/author.gif", 
		"images/approve01.gif", 
		"images/approve02.gif", 
		"images/approve03.gif", 
		"images/webmaster.gif", 
		"images/open.gif"
);
$G_AreClassImg[] = array(
		"ページ作成者", 
		"第1承認者", 
		"第2承認者", 
		"第3承認者", 
		"ウェブマスター", 
		"公開責任者"
);

//レヴェル
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


/** require **/
require ("./.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/** init **/
$dat = array();
$onLoad = '';
$back = "javascript:history.back()";
$o_user_flg = "";

//main
if (isset($_POST["behavior"])) $bv = $_POST["behavior"];
else $bv = 1;
switch ($bv) {
	case 1 : // 新規登録
		$label = 'ユーザー追加';
		$image = '<img src="images/bar_add.jpg" alt="ユーザー追加" width="920" height="30">';
		$back = 'index.php';
		$dat = array(
				"user_id" => "", 
				"name" => "", 
				"email" => "", 
				"login_id" => "", 
				"password" => "", 
				"dept_code" => "", 
				"class" => USER_CLASS_WRITER, 
				"item1" => "", 
				"sourceEdit_flg" => 0, 
				"approve_edit_flg" => 0,
				"login_lock_chbox_flg" => FLAG_OFF,
		);
		if (isset($_GET['back']) && $_GET['back'] == 1 && isset($_SESSION['hidden'])) {
			if (isset($_SESSION['hidden']['class'])) $dat['class'] = $_SESSION['hidden']['class'];
			if (isset($_SESSION['hidden']['name'])) $dat['name'] = $_SESSION['hidden']['name'];
			if (isset($_SESSION['hidden']['email'])) $dat['email'] = $_SESSION['hidden']['email'];
			if (isset($_SESSION['hidden']['login_id'])) $dat['login_id'] = $_SESSION['hidden']['login_id'];
			if (isset($_SESSION['hidden']['password'])) $dat['password'] = $_SESSION['hidden']['password'];
			if (isset($_SESSION['hidden']['password'])) $dat['password'] = $_SESSION['hidden']['password'];
			if (isset($_SESSION['hidden']['item1'])) $dat['item1'] = $_SESSION['hidden']['item1'];
			elseif (isset($_SESSION['hidden']['o_user_flg'])) $dat['item1'] = $_SESSION['hidden']['o_user_flg'];
			if ($dat['item1'] != "") $o_user_flg = ' checked';
			if (isset($_SESSION['hidden']['dept_code'])) $dat['dept_code'] = $_SESSION['hidden']['dept_code'];
			elseif (isset($_SESSION['hidden']['cms_target3']) && $_SESSION['hidden']['cms_target3'] != "") $dat['dept_code'] = $_SESSION['hidden']['cms_target3'];
			elseif (isset($_SESSION['hidden']['cms_target2']) && $_SESSION['hidden']['cms_target2'] != "") $dat['dept_code'] = $_SESSION['hidden']['cms_target2'];
			elseif (isset($_SESSION['hidden']['cms_target1']) && $_SESSION['hidden']['cms_target1'] != "") $dat['dept_code'] = $_SESSION['hidden']['cms_target1'];
			if ($dat['dept_code'] != "") $iDept_h = getDeptCode($dat['dept_code']);
			if (isset($_SESSION['hidden']['sourceEdit_flg'])) $dat['sourceEdit_flg'] = $_SESSION['hidden']['sourceEdit_flg'];
			if (isset($_SESSION['hidden']['approve_edit_flg'])) $dat['approve_edit_flg'] = $_SESSION['hidden']['approve_edit_flg'];
		}
		//権限ラジオボックス生成
		$checkClass = array(
				'5' => '', 
				'app' => '', 
				'1' => ''
		);
		if ($dat['class'] == 1 || $dat['class'] == 5) $checkClass[$dat['class']] = ' checked';
		else $checkClass['app'] = ' checked';
		$cms_radio = '<input type="radio" name="class" id="class_1" value="5" onClick="javascript:cxChangeClass()"' . $checkClass['5'] . '>' . '&nbsp;<label for="class_1">ウェブマスター</label>&nbsp;&nbsp;' . '<input type="radio" name="class" id="class_2" value="app" onClick="javascript:cxChangeClass()"' . $checkClass['app'] . '>' . '&nbsp;<label for="class_2">承認者</label>&nbsp;&nbsp;' . '<input type="radio" name="class" id="class_3" value="1" onClick="javascript:cxChangeClass()"' . $checkClass['1'] . '>' . '&nbsp;<label for="class_3">作成者</label>&nbsp;&nbsp;';
		//組織プルダウン生成
		$dept_s1 = '<select id="cms_target1" name="cms_target1" onChange="javascript:cxChangeDept(1, this.value)" style="width:150px;">';
		$dept_s2 = '<select id="cms_target2" name="cms_target2" onChange="javascript:cxChangeDept(2, this.value)" style="width:150px;">';
		$dept_s3 = '<select id="cms_target3" name="cms_target3" style="width:150px;">';
		$dept_opn = '<option value="" selected>----------------</option>';
		$dept_opd = '<option value="">指定なし</option>';
		$dept_ops = '<option value="" selected>指定なし</option>';
		$dept_op1 = '';
		$dept_op2 = '';
		$dept_op3 = '';
		$dept_e = '</select>&nbsp;&nbsp;';
		$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level = 1" . " ORDER BY dept_code, sort_order, dept_id";
		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$sel = (isset($iDept_h) && ($iDept_h['dept1_code'] == $objDac->fld['dept_code'])) ? ' selected' : '';
			$dept_op1 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $sel . '>' . $objDac->fld['name'] . '</option>';
		}
		if (isset($iDept_h) && $iDept_h['level'] >= 1) {
			$dept_op2 .= $dept_opd;
			$sql = "SELECT dept_code, name FROM tbl_department" . " WHERE level = 2 AND dept_code LIKE '" . $iDept_h['dept1'] . "%'" . " ORDER BY dept_code, sort_order, dept_id";
			$objDac->execute($sql);
			while ($objDac->fetch()) {
				$sel = ($iDept_h['dept2_code'] == $objDac->fld['dept_code']) ? ' selected' : '';
				$dept_op2 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $sel . '>' . $objDac->fld['name'] . '</option>';
			}
		}
		else {
			$dept_op2 .= $dept_opn;
		}
		if (isset($iDept_h) && $iDept_h['level'] >= 2) {
			$dept_op3 .= $dept_opd;
			$sql = "SELECT dept_code, name FROM tbl_department" . " WHERE level = 3 AND dept_code LIKE '" . $iDept_h['dept1'] . $iDept_h['dept2'] . "%'" . " ORDER BY dept_code, sort_order, dept_id";
			$objDac->execute($sql);
			while ($objDac->fetch()) {
				$sel = ($iDept_h['dept3_code'] == $objDac->fld['dept_code']) ? ' selected' : '';
				$dept_op3 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $sel . '>' . $objDac->fld['name'] . '</option>';
			}
		}
		else {
			$dept_op3 .= $dept_opn;
		}
		//
		$target1 = $dept_s1 . $dept_opd . $dept_op1 . $dept_e;
		$target2 = $dept_s2 . $dept_op2 . $dept_e;
		$target3 = $dept_s3 . $dept_op3 . $dept_e;
		$cms_target = $target1 . $target2 . $target3;
		$onLoad = ' onLoad="cxChangeClass();"';
		break;
	case 2 : // 更新
		if (!isset($_POST["user_id"])) {
			DispError("パラメータ取得エラー(user_id)", 3, "javascript:history.back()");
			exit();
		}
		$label = 'ユーザー情報修正';
		$image = '<img src="images/bar_fix.jpg" alt="ユーザー情報修正" width="920" height="30">';
		$sql = "SELECT tbl_user.*, h.item1 " . "FROM tbl_user LEFT JOIN (SELECT item1 FROM tbl_handler WHERE class = " . HANDLER_CLASS_OEPN_FLG . ") AS h ON tbl_user.user_id = h.item1 " . "WHERE (user_id = " . gd_addslashes($_POST["user_id"]) . ")";
		$objDac->execute($sql);
		if (!$objDac->fetch()) {
			DispError("指定されたユーザー情報が存在しません。", 3, "javascript:history.back()");
			exit();
		}
		$dat = $objDac->fld;
		//公開責任者でない場合は、権限コード通りの値を取得
		if (isset($dat['item1']) == FALSE || $dat['item1'] == "") {
			$DspClassImg = $G_AreClassImg[0][($dat['class'] - 1)];
			$DspClassArt = $G_AreClassImg[1][($dat['class'] - 1)];
		}
		else {
			$DspClassImg = $G_AreClassImg[0][5];
			$DspClassArt = $G_AreClassImg[1][5];
			$o_user_flg = " checked";
			// 承認フローで使用されていたら変更不可
			$sql = "SELECT COUNT(approve_id) AS rc FROM tbl_approve WHERE approve4 = " . $dat["user_id"];
			$objDac->execute($sql);
			if ($objDac->fetch() && $objDac->fld['rc'] > 0) {
				$o_user_flg .= " disabled";
			}
		}
		/*---組織名称の取得---*/
		$iDept = getDeptCode($dat['dept_code']);
		$DspDeptNm = "";
		if ($dat['class'] == USER_CLASS_WEBMASTER) {
			$DspDeptNm = "ウェブマスター";
		}
		else {
			//部
			$sql = "SELECT name FROM tbl_department" . " WHERE dept_code = '" . gd_addslashes($iDept['dept1_code']) . "'";
			$objDac->execute($sql);
			if ($objDac->fetch()) $DspDeptNm .= $objDac->fld['name'];
			// 課
			if ($iDept['level'] > G_DEPT_LEVEL01) {
				$sql = "SELECT name FROM tbl_department" . " WHERE dept_code = '" . gd_addslashes($iDept['dept2_code']) . "'";
				$objDac->execute($sql);
				if ($objDac->fetch()) $DspDeptNm .= " > " . $objDac->fld['name'];
			}
			// 係
			if ($iDept['level'] > G_DEPT_LEVEL02) {
				$sql = "SELECT name FROM tbl_department" . " WHERE dept_code = '" . gd_addslashes($iDept['dept3_code']) . "'";
				$objDac->execute($sql);
				if ($objDac->fetch()) $DspDeptNm .= " > " . $objDac->fld['name'];
			}
		}
		break;
	default :
		DispError("パラメータエラー（behavior）", 3, "javascript:history.back()");
		exit();
		break;
}

//ソースモード
if ($dat['sourceEdit_flg'] == 1) $checked_se = array(
		0 => '', 
		1 => ' checked'
);
else $checked_se = array(
		0 => ' checked', 
		1 => ''
);

//ページ編集権限
if ($dat['approve_edit_flg'] == 1) $checked_pe = array(
		0 => '', 
		1 => ' checked'
);
else $checked_pe = array(
		0 => ' checked', 
		1 => ''
);

$login_lock_flg = FLAG_OFF;
$login_unlock_chbox_str = '';
if (isset($dat['login_error_count']) && isset($dat['login_error_datetime'])) {
	// ログインロック中表記取得
	$LOGIN_LOCK_INFO_ARY = getDefineArray('LOGIN_LOCK_INFO_ARY');
	$mk_ch_box_ary = $LOGIN_LOCK_INFO_ARY;
	unset($mk_ch_box_ary[LOGIN_LOCK_MODE_UNLOCK]);
	unset($mk_ch_box_ary[LOGIN_LOCK_MODE_NOT_LOCK]);
	$select = array();
	// ログインロックチェック
	if (isUserLock($dat['login_error_count'], $dat['login_error_datetime'])) {
		$login_lock_flg = FLAG_ON;
		$select = array(LOGIN_LOCK_MODE_LOCK);
	}
	// ログインロック解除用チェックボックス生成
	$login_unlock_chbox_str = mkcheckbox($mk_ch_box_ary, 'login_lock_chbox_flg', $select);
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$label?></title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="user.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script src="./js/edit.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg" <?=$onLoad?>>
<?php
// ヘッダーメニュー挿入
$headerMode = 'user';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-approve">
<div><?=$image?></div>
<div class="cms8341-area-corner">
<form id="form" class="cms8341-form" name="form" method="post"
	action="confirm.php"><?php
	if ($bv == 2) {
		?>
<p align="left" id="cms8341-pankuzu"><?=$DspDeptNm?></p>
<p align="left"><img src="<?=$DspClassImg?>" alt="<?=$DspClassArt?>"
	width="100" height="20">
<?php
		if ($dat['class'] == USER_CLASS_WEBMASTER) {
			?>&nbsp;&nbsp;
<input type="checkbox" name="o_user_flg" id="o_user_flg" value="1"
	<?=$o_user_flg?>>&nbsp;<label for="o_user_flg">公開責任者</label></p>
<?php
		}
		?>
<input type="hidden" name="dept_code"
	value="<?=htmlspecialchars($dat['dept_code'])?>"> <input
	type="hidden" name="class"
	value="<?=htmlspecialchars($dat['class'])?>"><?php
	}
	?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
<?php
if ($bv == 1) {
	?>
<tr>
		<th width="150" align="left" valign="middle" scope="row">権限 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=$cms_radio?>&nbsp;
<input type="checkbox" name="o_user_flg" id="o_user_flg" value="1"
			<?=$o_user_flg?>>&nbsp;<label for="o_user_flg">公開責任者</label></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">所属組織 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=$cms_target?></td>
	</tr><?php
}
else {
	?>
<tr>
		<th width="150" align="left" valign="top" scope="row">ユーザーID</th>
		<td align="left" valign="top"><?=$dat['user_id']?></td>
	</tr><?php
}
?>
<tr>
		<th width="150" align="left" valign="middle" scope="row">ユーザー名 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><input id="name" name="name" type="text"
			style="width: 200px" value="<?=htmlspecialchars($dat['name'])?>"></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">メールアドレス <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><input id="email" name="email"
			type="text" style="width: 400px"
			value="<?=htmlspecialchars($dat['email'])?>" class="no-ime"></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">ログインID <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><input id="login_id" name="login_id"
			type="text" style="width: 200px"
			value="<?=htmlspecialchars($dat['login_id'])?>" class="no-ime"></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">パスワード <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><input id="password" name="password"
			type="text" style="width: 200px"
			value="<?=htmlspecialchars($dat['password'])?>" class="no-ime">
			<?php
				if (PASSWORD_AUTO_CREATE_FLG) {
					print '<a href="javascript:" onClick="return cxCreatePassword()"><img style="margin-left: 10px;" class="cms8341-verticalMiddle" src="' . RPW . '/admin/images/btn/btn_auto_create.jpg" alt="自動生成" width="100" height="20" hspace="0" border="0"></a>';
				}
			?>
			</td>
	</tr>
	<?php
		if ($login_unlock_chbox_str != '') {
	?>
	<tr>
		<th width="150" align="left" valign="middle" scope="row">認証ロック</th>
		<td align="left" valign="top"><?php echo($login_unlock_chbox_str); ?></td>
	</tr>
	
	<?php
		}
	?>
<?php
if ($bv == 1 || $dat['class'] != USER_CLASS_WEBMASTER) {
	?>
<tr>
		<th width="150" align="left" valign="middle" scope="row">ソースモード <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><input type="radio"
			name="sourceEdit_flg" value="1" id="se_1" <?=$checked_se[1]?>>&nbsp;<label
			for="se_1">ON</label> &nbsp;&nbsp;<input type="radio"
			name="sourceEdit_flg" value="0" id="se_0" <?=$checked_se[0]?>>&nbsp;<label
			for="se_0">OFF</label></td>
	</tr>
<?php
	if ($bv == 1 || $dat['class'] != USER_CLASS_WRITER) {
		?>
<tr>
		<th width="150" align="left" valign="middle" scope="row">ページ編集権限 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><input type="radio"
			name="approve_edit_flg" value="1" id="ae_1" <?=$checked_pe[1]?>>&nbsp;<label
			for="ae_1">ON</label> &nbsp;&nbsp;<input type="radio"
			name="approve_edit_flg" value="0" id="ae_0" <?=$checked_pe[0]?>>&nbsp;<label
			for="ae_0">OFF</label></td>
	</tr>
<?php
	}
	?>
<?php
}
else {
	?>
<input type="hidden" name="sourceEdit_flg" value="0">
<?php
}
?>
</table>
<p align="center"><input type="image" src="../images/btn_conf.jpg"
	alt="確認" width="150" height="20" border="0" style="margin-right: 10px">
<a href="<?=$back?>"><img src="../../images/btn/btn_cansel_large.jpg"
	alt="キャンセル" width="150" height="20" border="0"
	style="margin-left: 10px"></a></p>
<input type="hidden" name="behavior" value="<?=$bv?>"> <input
	type="hidden" name="user_id" value="<?=$dat['user_id']?>">
<?php 
	print '<input type="hidden" id="login_lock_flg" name="login_lock_flg" value="' . $login_lock_flg. '">';
?>
	</form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
