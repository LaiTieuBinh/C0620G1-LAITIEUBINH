<?php
/*
 * カテゴリ管理　表示順序変更画面(sortorder.php)
 */
$StrDbg = "";
$GLOBALS["StrDbg"] = "";

/*---------------------------------------------
	定数 
----------------------------------------------*/

//表示&カテゴリレベル
define("G_CATE_LEVEL00", 0); //初期画面
define("G_CATE_LEVEL01", 1); //第1レベル
define("G_CATE_LEVEL02", 2); //第2レベル
define("G_CATE_LEVEL03", 3); //第3レベル
define("G_CATE_LEVEL04", 4); //第4レベル


//エラーコード
define("G_ERR_CATE", 1); //エラー関数　第二引数値


/*---------------------------------------------------------------------------------
	form.php
	
	パラメーター
	level:指定されたカテゴリレベル
	cate_code：指定されたカテゴリコード
	d_l:一覧画面の表示レベル
	d_c：一覧画面で対象となっているカテゴリコード
	
---------------------------------------------------------------------------------*/

/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

/*---引数の取得---*/
$args = ($_SERVER['REQUEST_METHOD'] == 'GET') ? $_GET : $_POST;
//処理モード
//レベル
if (isset($args["level"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
	exit();
}
else {
	if ((strcmp($args["level"], G_CATE_LEVEL00) != 0) && (strcmp($args["level"], G_CATE_LEVEL01) != 0) && (strcmp($args["level"], G_CATE_LEVEL02) != 0) && (strcmp($args["level"], G_CATE_LEVEL03) != 0) && (strcmp($args["level"], G_CATE_LEVEL04) != 0)) {
		DispError("無効なパラメーターが指定されています。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
}
//カテゴリコード
if (strcmp($args["level"], G_CATE_LEVEL00) == 0) {
	$PrmCateCode = "";
}
else {
	if (isset($args["cate_code"]) == FALSE) {
		DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
	$PrmCateCode = $args["cate_code"];
}
//表示レベル、カテゴリコード
if (isset($args["d_l"]) == FALSE) {
	$d_l = G_CATE_LEVEL00;
}
else {
	$d_l = $args["d_l"];
}
if (isset($args["d_c"]) == FALSE) {
	$d_c = "";
}
else {
	$d_c = $args["d_c"];
}

/*--- データアクセスクラス ---*/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*---画面作成---*/
//上位カテゴリ名
if ($args["level"] == G_CATE_LEVEL00) {
	$DspCateTitle = "トップ";
}
else {
	$DspCateTitle = G_GetCateName($objDac, $args["level"], $PrmCateCode);
}

/*---表示項目の取得---*/
//	$BakURL = "javascript:history.back()";
$cateInfo = getCateCode($d_c);
$BakURL = "./index.php?level=" . $d_l . "&cate_code=" . $d_c . "#" . $cateInfo['cate1_code'];
$ResURL = "./sortorder.php?level=" . $args["level"] . "&cate_code=" . $PrmCateCode . "&d_l=" . $d_l . "&d_c=" . $d_c;
//画面項目の取得
$DspList = "";
$DspLstCnt = G_GetCateList($objDac, $args["level"], $PrmCateCode, $DspList, $DspMsg);

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	表示リストの作成

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateLevel	指定されたカテゴリレベル
		$i_CateCode		指定されたカテゴリコード
		$o_DspList		表示リストの格納先
		$o_DspMsg		表示されるメッセージ
		
【戻値】	取得されたデータ数	
		
【備考】
-----------------------------------------------------------------------------*/
function G_GetCateList($i_objDac, $i_CateLevel, $i_CateCode, &$o_DspList, &$o_DspMsg) {
	
	//---SQL部品の作成
	$sql_level = 0;
	$sql_like = "";
	$sql = "";
	switch ($i_CateLevel) {
		case G_CATE_LEVEL00 : //レベル0
			$sql = "SELECT tbl_category.* FROM tbl_category " . "WHERE (((tbl_category.level)=" . G_CATE_LEVEL01 . "))" . "ORDER BY tbl_category.sort_order, tbl_category.cate_id";
			break;
		case G_CATE_LEVEL01 : //レベル1
			$sql_like = substr($i_CateCode, 0, CODE_DIGIT_CATE); //カテゴリコード1
			$sql_level = 0;
			$sql_level = G_CATE_LEVEL02;
			break;
		case G_CATE_LEVEL02 : //レベル2
			$sql_like = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE)); //カテゴリコード2
			$sql_level = G_CATE_LEVEL03;
			break;
		case G_CATE_LEVEL03 : //レベル3
			$sql_like = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE)); //カテゴリコード3
			$sql_level = G_CATE_LEVEL04;
			break;
	}
	
	//--SQL
	if (strcmp($i_CateLevel, G_CATE_LEVEL00) != 0) {
		$sql = "SELECT tbl_category.* FROM tbl_category " . "WHERE (((tbl_category.level)=" . $sql_level . ") AND ((tbl_category.cate_code) Like '" . $sql_like . "%'))" . "ORDER BY tbl_category.sort_order, tbl_category.cate_id";
	}
	
	//---取得
	$i_objDac->execute($sql);
	
	//---成形
	$o_DspList = "";
	$dat_cnt = 0;
	while ($i_objDac->fetch()) {
		// 大規模災害用の分類の場合は除外
		if ($i_objDac->fld['disaster_flg'] == FLAG_ON) {
			continue;
		}
		$o_DspList .= "<tr>\n";
		//入力エリア
		$o_DspList .= "<td width=\"150\" align=\"center\" valign=\"middle\">";
		$o_DspList .= "<input type=\"text\" style=\"width:100px;text-align:center\" name = \"" . $i_objDac->fld['cate_id'] . "\"value=\"" . $i_objDac->fld['sort_order'] . "\"></td>\n";
		//カテゴリ名
		$o_DspList .= "<td align=\"left\" valign=\"top\">" . htmlspecialchars($i_objDac->fld['name']) . "</td>\n";
		$o_DspList .= "</tr>\n";
		$dat_cnt = $dat_cnt + 1;
	}
	
	//---一件も下位カテゴリが存在しなかった
	if (strlen($o_DspList) <= 0) {
		$o_DspMsg = "<p>対象となる分類が存在しませんでした。</p>";
	}
	
	return ($dat_cnt);

}
/*-----------------------------------------------------------------------------
	カテゴリ名の取得

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateLevel	指定されたカテゴリレベル
		$i_CateCode		指定されたカテゴリコード
		
【戻値】	取得したカテゴリ名	
		
【備考】
-----------------------------------------------------------------------------*/
function G_GetCateName($i_objDac, $i_CateLevel, $i_CateCode) {
	
	//---とりあえず、全コード作っておく
	//カテゴリコード1
	$cate_01 = substr($i_CateCode, 0, CODE_DIGIT_CATE);
	$cate_01 = str_pad($cate_01, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
	//カテゴリコード2
	$cate_02 = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE));
	$cate_02 = str_pad($cate_02, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
	//カテゴリコード3
	$cate_03 = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE));
	$cate_03 = str_pad($cate_03, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
	//カテゴリコード4
	$cate_04 = $i_CateCode;
	
	//---SQL部品の作成
	$sel_tbl = "";
	$from_tbl = "";
	$where_tbl = "";
	switch ($i_CateLevel) {
		case G_CATE_LEVEL01 : //レベル1
			$sel_tbl = "tbl_category.cate_code, tbl_category.name ";
			$from_tbl = "tbl_category ";
			$where_tbl = "((tbl_category.cate_code)='" . $cate_01 . "')";
			break;
		case G_CATE_LEVEL02 : //レベル2
			$sel_tbl = "tbl_category.cate_code, tbl_category.name, tbl_category_1.cate_code, tbl_category_1.name AS cate_nm02 ";
			$from_tbl = "tbl_category, tbl_category AS tbl_category_1 ";
			$where_tbl = "(((tbl_category.cate_code)='" . $cate_01 . "') AND ((tbl_category_1.cate_code)='" . $cate_02 . "'))";
			break;
		case G_CATE_LEVEL03 : //レベル3
			$sel_tbl = "tbl_category.cate_code, tbl_category.name, tbl_category_1.cate_code, tbl_category_1.name AS cate_nm02, " . "tbl_category_2.cate_code, tbl_category_2.name AS cate_nm03 ";
			$from_tbl = "tbl_category, tbl_category AS tbl_category_1, tbl_category AS tbl_category_2 ";
			$where_tbl = "(((tbl_category.cate_code)='" . $cate_01 . "') AND ((tbl_category_1.cate_code)='" . $cate_02 . "') AND " . " ((tbl_category_2.cate_code)='" . $cate_03 . "'))";
			break;
		case G_CATE_LEVEL04 : //レベル4
			$sel_tbl = "tbl_category.cate_code, tbl_category.name, tbl_category_1.cate_code, tbl_category_1.name As cate_nm02 , " . "tbl_category_2.cate_code, tbl_category_2.name As cate_nm03, tbl_category_3.cate_code, tbl_category_3.name As cate_nm04 ";
			$from_tbl = "tbl_category, tbl_category AS tbl_category_1, tbl_category AS tbl_category_2, tbl_category AS tbl_category_3 ";
			$where_tbl = "(((tbl_category.cate_code)='" . $cate_01 . "') AND ((tbl_category_1.cate_code)='" . $cate_02 . "') " . "AND ((tbl_category_2.cate_code)='" . $cate_03 . "') AND ((tbl_category_3.cate_code)='" . $cate_04 . "'))";
			break;
	}
	
	//--SQL結合
	$sql = "SELECT " . $sel_tbl . "FROM " . $from_tbl . "WHERE " . $where_tbl;
	
	//---取得
	$i_objDac->execute($sql);
	//---成形
	$cate_name = "";
	while ($i_objDac->fetch()) {
		switch ($i_CateLevel) {
			case G_CATE_LEVEL01 : //レベル1
				$cate_name = htmlspecialchars($i_objDac->fld['name']);
				break;
			case G_CATE_LEVEL02 : //レベル2
				$cate_name = htmlspecialchars($i_objDac->fld['name']) . " &gt; " . htmlspecialchars($i_objDac->fld['cate_nm02']);
				break;
			case G_CATE_LEVEL03 : //レベル3
				$cate_name = htmlspecialchars($i_objDac->fld['name']) . " &gt; " . htmlspecialchars($i_objDac->fld['cate_nm02']) . " &gt; " . htmlspecialchars($i_objDac->fld['cate_nm03']);
				break;
			case G_CATE_LEVEL04 : //レベル4
				$cate_name = htmlspecialchars($i_objDac->fld['name']) . " &gt; " . htmlspecialchars($i_objDac->fld['cate_nm02']) . " &gt; " . htmlspecialchars($i_objDac->fld['cate_nm03']) . " &gt; " . htmlspecialchars($i_objDac->fld['cate_nm04']);
				break;
		}
		break;
	}
	
	//---戻値
	return ($cate_name);

}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>分類表示順変更</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="category.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?=$GLOBALS["StrDbg"]?>

<?php
// ヘッダーメニュー挿入
$headerMode = 'category';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-categoryform">
<div><img src="images/bar_listorder.jpg" alt="分類表示順変更" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<p align="left" id="cms8341-pankuzu"><?=$DspCateTitle?></p>
<?=$DspMsg?>
<form class="cms8341-form" method="POST" action="./sortorder_comp.php"
	name="Form">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
<?php
if (strlen($DspList) > 0) {
	?>
<th width="150" align="center" valign="middle" scope="col">表示順 <span
			class="cms_require">（必須）</span></th>
		<th align="center" valign="middle" scope="col">分類名</th>
<?php
}
?>
</tr>
<?=$DspList?> 
</table>
<?php
if (strlen($DspList) > 0) {
	?>
<p align="center"><input type="image" src="images/btn_listorder.jpg"
	alt="表示順を変更" width="150" height="20" border="0"
	style="margin-right: 10px"> <a href="<?=$ResURL?>"><img
	src="images/btn_reset.jpg" alt="リセット" width="150" height="20"
	border="0" style="margin-left: 10px"></a></p>
<?php
}
?>
<p align="left"><a href="<?=$BakURL?>"><img
	src="../images/btn_small_back.jpg" alt="戻る" width="120" height="20"
	border="0"></a></p>
<?php
if (strlen($DspList) > 0) {
	?>
<INPUT TYPE="HIDDEN" NAME="level" VALUE="<?=$args["level"]?>"> <INPUT
	TYPE="HIDDEN" NAME="cate_code" VALUE="<?=$PrmCateCode?>"> <INPUT
	TYPE="HIDDEN" NAME="d_l" VALUE="<?=$d_l?>"> <INPUT TYPE="HIDDEN"
	NAME="d_c" VALUE="<?=$d_c?>">
<?php
}
?>
</form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
