<?php
/*
 * カテゴリ管理　一覧画面(index.php)
 */
$StrDbg = "";
$GLOBALS["StrDbg"] = "";

/*---------------------------------------------
	定数 
----------------------------------------------*/

//表示&カテゴリレベル
define("G_CATE_LEVEL00", 0); //初期画面
define("G_CATE_LEVEL01", 1); //第1レベル
define("G_CATE_LEVEL02", 2); //第2レベル
define("G_CATE_LEVEL03", 3); //第3レベル
define("G_CATE_LEVEL04", 4); //第4レベル


//エクスプローラー風プラマイ記号イメージPath
define("G_LIST_IMG_P", "../images/dir_plus.jpg"); //プラス
define("G_LIST_IMG_M", "../images/dir_minus.jpg"); //マイナス


//エラーコード
define("G_ERR_CATE", 1); //エラー関数　第二引数値


//ボタン画像
define("G_LIST_BTN_DEL", '<img src="./images/btn_category_del.jpg" alt="削除" width="60" height="20" border="0">');
define("G_LIST_BTN_FIX", '<img src="./images/btn_category_fix.jpg" alt="修正" width="60" height="20" border="0">');
define("G_LIST_BTN_SORT", '<img src="./images/btn_category_sort.jpg" alt="下位分類の表示順変更" width="150" height="20" border="0">');
define("G_LIST_BTN_ADD", '<img src="./images/btn_category_add.jpg" alt="下位分類を追加" width="150" height="20" border="0">');

/*---------------------------------------------------------------------------------
	index.php
	
	パラメーター
	level:表示されるレベル
				0 or "" ：初期画面(top→1)
				1：表示レベル1(top→1→2)
				2：表示レベル2(top→1→2→3)
				3：表示レベル1(top→1→2→3→4)
	cate_code
		展開されているカテゴリーコード
	
---------------------------------------------------------------------------------*/

/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

/*---引数の取得---*/
$args = ($_SERVER['REQUEST_METHOD'] == 'GET') ? $_GET : $_POST;
//表示レベル
if (isset($_REQUEST["level"]) == TRUE) {
	$PrmLevel = $args['level'];
	if (($PrmLevel != G_CATE_LEVEL00) & ($PrmLevel != G_CATE_LEVEL01) & ($PrmLevel != G_CATE_LEVEL02) & ($PrmLevel != G_CATE_LEVEL03)) {
		DispError("有効ではないパラメーターが指定されました。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
}
else {
	//未指定の場合は初期画面表示
	$PrmLevel = G_CATE_LEVEL00;
}
//カテゴリーコード
$PrmCateCode = "";
if ($PrmLevel == G_CATE_LEVEL00) {
	$PrmCateCode = "";
}
else {
	if (isset($_REQUEST["cate_code"]) == TRUE) {
		$PrmCateCode = $args['cate_code'];
	}
	else {
		//未指定の場合は初期画面表示
		$PrmLevel = G_CATE_LEVEL00;
	}
}

/*--- データアクセスクラス ---*/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*---一覧の取得---*/
//取得レベルに応じた表示データの作成
$DspLst = "";
$TopAddURL = "";
switch ($PrmLevel) {
	case G_CATE_LEVEL00 : //表示レベル0 初期画面
		G_SetDspList_Level00($objDac, $DspLst, $TopAddURL);
		break;
	case G_CATE_LEVEL01 : //表示レベル1
		G_SetDspList_Level01($objDac, $PrmCateCode, $DspLst, $TopAddURL);
		break;
	case G_CATE_LEVEL02 : //表示レベル2
		G_SetDspList_Level02($objDac, $PrmCateCode, $DspLst, $TopAddURL);
		break;
	case G_CATE_LEVEL03 : //表示レベル3
		G_SetDspList_Level03($objDac, $PrmCateCode, $DspLst, $TopAddURL);
		break;
}

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	レベル1 初期画面表示データ作成

【引数】	$i_objDac		取得されたデーターオブジェクト
		$o_DspLst	表示する一覧データ
		$o_TopAddURL	TOP URL
		
【戻値】	True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspList_Level00($i_objDac, &$o_DspLst, &$o_TopAddURL) {
	
	/*---展開されたデータを作成---*/
	$sql = "SELECT * " . "FROM tbl_category " . "WHERE ((tbl_category.level)=1) " . "ORDER BY tbl_category.cate_code, tbl_category.level, tbl_category.sort_order, tbl_category.cate_id";
	
	//取得
	$i_objDac->execute($sql);
	
	//データ作成
	while ($i_objDac->fetch()) {
		// 大規模災害用の分類の場合は除外
		if ($i_objDac->fld['disaster_flg'] == FLAG_ON) {
			continue;
		}
		$cateInfo = getCateCode($i_objDac->fld['cate_code']);
		$o_DspLst .= "<p align=\"left\" class=\"dir_first\">";
		$o_DspLst .= "<a name=\"" . $i_objDac->fld['cate_code'] . "\"></a>";
		$o_DspLst .= "<a href=\"./index.php?level=" . G_CATE_LEVEL01 . "&cate_code=" . $i_objDac->fld['cate_code'] . "#" . $cateInfo['cate1_code'] . "\">";
		//		$o_DspLst .= "<a href=\"./index.php?level=" . G_CATE_LEVEL01 . "&cate_code=" . $i_objDac->fld['cate_code'] ."\">";
		$o_DspLst .= "<img src=\"../images/dir_plus.jpg\" alt=\"\" width=\"60\" height=\"20\" border=\"0\">";
		$o_DspLst .= "</a>";
		$o_DspLst .= htmlspecialchars($i_objDac->fld['name']);
		$o_DspLst .= "（" . $i_objDac->fld['cate_code'] . "）　";
		$o_DspLst .= "<a href=\"./form.php?mode=new&level=" . G_CATE_LEVEL01 . "&cate_code=" . $i_objDac->fld['cate_code'] . "&d_l=" . G_CATE_LEVEL00 . "&d_c=\">" . G_LIST_BTN_ADD . "</a>　";
		$o_DspLst .= "<a href=\"./form.php?mode=upd&level=" . G_CATE_LEVEL01 . "&cate_code=" . $i_objDac->fld['cate_code'] . "&cate_id=" . $i_objDac->fld['cate_id'] . "&d_l=" . G_CATE_LEVEL00 . "&d_c=\">" . G_LIST_BTN_FIX . "</a>　";
		$o_DspLst .= "<a href=\"./confirm.php?mode=del&level=" . G_CATE_LEVEL01 . "&cate_code=" . $i_objDac->fld['cate_code'] . "&cate_id=" . $i_objDac->fld['cate_id'] . "&d_l=" . G_CATE_LEVEL00 . "&d_c=\">" . G_LIST_BTN_DEL . "</a>　";
		$o_DspLst .= "</p>";
	}
	//---TOP URL
	$o_TopAddURL = "./form.php?mode=new&d_l=0&level=0&cate_code=";
}

/*-----------------------------------------------------------------------------
	レベル１の展開

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_PrmCateCode	引数で指定された組織コード
		$o_DspLst		表示する一覧データ
		$o_TopAddURL	TOP URL
		
【戻値】	True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspList_Level01($i_objDac, $i_PrmCateCode, &$o_DspLst, &$o_TopAddURL) {
	
	/*---レベル１コードを取得を取得---*/
	$cate_01 = substr($i_PrmCateCode, 0, CODE_DIGIT_CATE);
	
	/*---展開されたデータを作成---*/
	//--- 2006-11-09 Y.Adachi Upd Start
	//	$sql = "SELECT *  FROM tbl_category " .
	//		"WHERE (((tbl_category.level)=" . G_CATE_LEVEL01 . ")) OR " . 
	//		"((((tbl_category.level)=" . G_CATE_LEVEL02 . ") And (tbl_category.cate_code Like '". mysql_real_escape_string($cate_01) ."%'))) " .
	//		"ORDER BY tbl_category.cate_code, tbl_category.level, tbl_category.sort_order, tbl_category.cate_id";
	$sql = "SELECT *  FROM tbl_category " . "WHERE (((tbl_category.level)=" . G_CATE_LEVEL01 . ")) OR " . "((((tbl_category.level)=" . G_CATE_LEVEL02 . ") And (tbl_category.cate_code Like '" . gd_addslashes($cate_01) . "%'))) " . "ORDER BY tbl_category.cate_code, tbl_category.level, tbl_category.sort_order, tbl_category.cate_id";
	//--- 2006-11-09 Y.Adachi Upd End
	

	//取得
	$i_objDac->execute($sql);
	
	//データ作成
	$leve_sec = "";
	$exp_img = "";
	$cate_01 = str_pad($cate_01, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
	$bak_level = 0;
	$nxt_level = 0;
	while ($i_objDac->fetch()) {
		// 大規模災害用の分類の場合は除外
		if ($i_objDac->fld['disaster_flg'] == FLAG_ON) {
			continue;
		}
		$cateInfo = getCateCode($i_objDac->fld['cate_code']);
		$sort_flg = 0;
		switch ($i_objDac->fld['level']) {
			case G_CATE_LEVEL01 : //レベル１
				$leve_sec = "dir_first";
				if (strcmp($cate_01, $i_objDac->fld['cate_code']) == 0) {
					$exp_img = G_LIST_IMG_M;
					$bak_level = G_CATE_LEVEL00;
					$sort_flg = 1;
				}
				else {
					$exp_img = G_LIST_IMG_P;
					$bak_level = G_CATE_LEVEL01;
				}
				$nxt_level = G_CATE_LEVEL01;
				break;
			case G_CATE_LEVEL02 : //レベル２
				$leve_sec = "dir_second";
				$bak_level = G_CATE_LEVEL02;
				$exp_img = G_LIST_IMG_P;
				$nxt_level = G_CATE_LEVEL02;
				break;
		}
		
		$o_DspLst .= "<p align=\"left\" class=\"" . $leve_sec . "\">";
		$o_DspLst .= "<a name=\"" . $i_objDac->fld['cate_code'] . "\"></a>";
		$o_DspLst .= "<a href=\"./index.php?level=" . $bak_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "#" . $cateInfo['cate1_code'] . "\">";
		//		$o_DspLst .= "<a href=\"./index.php?level=" . $bak_level . "&cate_code=" . $i_objDac->fld['cate_code'] ."\">";
		$o_DspLst .= "<img src=\"" . $exp_img . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\">";
		$o_DspLst .= "</a>";
		$o_DspLst .= htmlspecialchars($i_objDac->fld['name']);
		$o_DspLst .= "（" . $i_objDac->fld['cate_code'] . "）　";
		$o_DspLst .= "<a href=\"./form.php?mode=new&level=" . $nxt_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "&d_l=" . G_CATE_LEVEL01 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_ADD . "</a>　";
		$o_DspLst .= "<a href=\"./form.php?mode=upd&level=" . $nxt_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "&cate_id=" . $i_objDac->fld['cate_id'] . "&d_l=" . G_CATE_LEVEL01 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_FIX . "</a>　";
		$o_DspLst .= "<a href=\"./confirm.php?mode=del&level=" . $nxt_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "&cate_id=" . $i_objDac->fld['cate_id'] . "&d_l=" . G_CATE_LEVEL01 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_DEL . "</a>　";
		
		if ($sort_flg == 1) {
			$o_DspLst .= "<a href=\"./sortorder.php?level=" . $nxt_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "&d_l=" . G_CATE_LEVEL01 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_SORT . "</a>";
		}
		$o_DspLst .= "</p>";
	
	}
	
	//---TOP URL
	$o_TopAddURL = "./form.php?mode=new&d_c=" . $i_PrmCateCode . "&d_l=" . G_CATE_LEVEL01 . "&level=0&cate_code=" . $i_PrmCateCode;

}

/*-----------------------------------------------------------------------------
	レベル２の展開

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_PrmCateCode	引数で指定された組織コード
		$o_DspLst		表示する一覧データ
		$o_TopAddURL	TOP URL
		
【戻値】	True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspList_Level02($i_objDac, $i_PrmCateCode, &$o_DspLst, &$o_TopAddURL) {
	
	/*---カテゴリコードの取得---*/
	//レベル1
	$cate_01 = substr($i_PrmCateCode, 0, CODE_DIGIT_CATE);
	//レベル2
	$cate_02 = substr($i_PrmCateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE));
	
	/*---展開されたデータを作成---*/
	$sql = "SELECT * FROM tbl_category " . "WHERE (" . "(tbl_category.level=" . G_CATE_LEVEL01 . ") OR " . "((tbl_category.level=" . G_CATE_LEVEL02 . ") And (tbl_category.cate_code Like '" . $cate_01 . "%')) OR " . "((tbl_category.level=" . G_CATE_LEVEL03 . ") And (tbl_category.cate_code Like '" . $cate_02 . "%'))" . ")" . "ORDER BY tbl_category.cate_code, tbl_category.level, tbl_category.sort_order, tbl_category.cate_id";
	
	//取得
	$i_objDac->execute($sql);
	
	/*---カテゴリコードの取得---*/
	//レベル1
	$cate_01 = str_pad($cate_01, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
	//レベル2
	$cate_02 = str_pad($cate_02, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
	
	//データ作成
	$leve_sec = "";
	$exp_img = "";
	$bak_level = 0;
	$nxt_level = 0;
	while ($i_objDac->fetch()) {
		// 大規模災害用の分類の場合は除外
		if ($i_objDac->fld['disaster_flg'] == FLAG_ON) {
			continue;
		}
		$cateInfo = getCateCode($i_objDac->fld['cate_code']);
		$sort_flg = 0;
		switch ($i_objDac->fld['level']) {
			case G_CATE_LEVEL01 : //レベル１
				$leve_sec = "dir_first";
				if (strcmp($cate_01, $i_objDac->fld['cate_code']) == 0) {
					$exp_img = G_LIST_IMG_M;
					$bak_level = G_CATE_LEVEL00;
					$sort_flg = 1;
				}
				else {
					$exp_img = G_LIST_IMG_P;
					$bak_level = G_CATE_LEVEL01;
				}
				$nxt_level = G_CATE_LEVEL01;
				break;
			case G_CATE_LEVEL02 : //レベル２
				$leve_sec = "dir_second";
				if (strcmp($cate_02, $i_objDac->fld['cate_code']) == 0) {
					$exp_img = G_LIST_IMG_M;
					$bak_level = G_CATE_LEVEL01;
					$sort_flg = 1;
				}
				else {
					$exp_img = G_LIST_IMG_P;
					$bak_level = G_CATE_LEVEL02;
				}
				$nxt_level = G_CATE_LEVEL02;
				break;
			case G_CATE_LEVEL03 : //レベル３
				$leve_sec = "dir_third";
				$bak_level = G_CATE_LEVEL03;
				$exp_img = G_LIST_IMG_P;
				$nxt_level = G_CATE_LEVEL03;
				break;
		}
		
		$o_DspLst .= "<p align=\"left\" class=\"" . $leve_sec . "\">";
		$o_DspLst .= "<a name=\"" . $i_objDac->fld['cate_code'] . "\"></a>";
		$o_DspLst .= "<a href=\"./index.php?level=" . $bak_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "#" . $cateInfo['cate1_code'] . "\">";
		//		$o_DspLst .= "<a href=\"./index.php?level=" . $bak_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "\">";
		$o_DspLst .= "<img src=\"" . $exp_img . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\">";
		$o_DspLst .= "</a>";
		$o_DspLst .= htmlspecialchars($i_objDac->fld['name']);
		$o_DspLst .= "（" . $i_objDac->fld['cate_code'] . "）　";
		$o_DspLst .= "<a href=\"./form.php?mode=new&level=" . $nxt_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "&d_l=" . G_CATE_LEVEL02 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_ADD . "</a>　";
		$o_DspLst .= "<a href=\"./form.php?mode=upd&level=" . $nxt_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "&cate_id=" . $i_objDac->fld['cate_id'] . "&d_l=" . G_CATE_LEVEL02 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_FIX . "</a>　";
		$o_DspLst .= "<a href=\"./confirm.php?mode=del&level=" . $nxt_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "&cate_id=" . $i_objDac->fld['cate_id'] . "&d_l=" . G_CATE_LEVEL02 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_DEL . "</a>　";
		
		if ($sort_flg == 1) {
			$o_DspLst .= "<a href=\"./sortorder.php?level=" . $nxt_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "&d_l=" . G_CATE_LEVEL02 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_SORT . "</a>";
		}
		
		$o_DspLst .= "</p>";
	
	}
	
	//---TOP URL
	$o_TopAddURL = "./form.php?mode=new&d_c=" . $i_PrmCateCode . "&d_l=" . G_CATE_LEVEL02 . "&level=0&cate_code=" . $i_PrmCateCode;

}

/*-----------------------------------------------------------------------------
	レベル３の展開

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_PrmCateCode	引数で指定された組織コード
		$o_DspLst		表示する一覧データ
		$o_TopAddURL	TOP URL
		
【戻値】	True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspList_Level03($i_objDac, $i_PrmCateCode, &$o_DspLst, &$o_TopAddURL) {
	
	/*---カテゴリコードの取得---*/
	//レベル1
	$cate_01 = substr($i_PrmCateCode, 0, CODE_DIGIT_CATE);
	//レベル2
	$cate_02 = substr($i_PrmCateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE));
	//レベル3
	$cate_03 = substr($i_PrmCateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE));
	
	/*---展開されたデータを作成---*/
	$sql = "SELECT * FROM tbl_category " . "WHERE (" . "(tbl_category.level=" . G_CATE_LEVEL01 . ") OR " . "((tbl_category.level=" . G_CATE_LEVEL02 . ") And (tbl_category.cate_code Like '" . $cate_01 . "%')) OR " . "((tbl_category.level=" . G_CATE_LEVEL03 . ") And (tbl_category.cate_code Like '" . $cate_02 . "%')) OR " . "((tbl_category.level=" . G_CATE_LEVEL04 . ") And (tbl_category.cate_code Like '" . $cate_03 . "%'))" . ")" . "ORDER BY tbl_category.cate_code, tbl_category.level, tbl_category.sort_order, tbl_category.cate_id";
	
	//取得
	$i_objDac->execute($sql);
	
	/*---カテゴリコードの取得---*/
	//レベル1
	$cate_01 = str_pad($cate_01, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
	//レベル2
	$cate_02 = str_pad($cate_02, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
	//レベル3
	$cate_03 = str_pad($cate_03, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
	
	//データ作成
	$leve_sec = "";
	$exp_img = "";
	$bak_level = 0;
	$nxt_level = 0;
	while ($i_objDac->fetch()) {
		// 大規模災害用の分類の場合は除外
		if ($i_objDac->fld['disaster_flg'] == FLAG_ON) {
			continue;
		}
		$cateInfo = getCateCode($i_objDac->fld['cate_code']);
		$sort_flg = 0;
		switch ($i_objDac->fld['level']) {
			case G_CATE_LEVEL01 : //レベル１
				$leve_sec = "dir_first";
				if (strcmp($cate_01, $i_objDac->fld['cate_code']) == 0) {
					$exp_img = G_LIST_IMG_M;
					$bak_level = G_CATE_LEVEL00;
					$sort_flg = 1;
				}
				else {
					$exp_img = G_LIST_IMG_P;
					$bak_level = G_CATE_LEVEL01;
				}
				$nxt_level = G_CATE_LEVEL01;
				break;
			case G_CATE_LEVEL02 : //レベル２
				$leve_sec = "dir_second";
				if (strcmp($cate_02, $i_objDac->fld['cate_code']) == 0) {
					$exp_img = G_LIST_IMG_M;
					$bak_level = G_CATE_LEVEL01;
					$sort_flg = 1;
				}
				else {
					$exp_img = G_LIST_IMG_P;
					$bak_level = G_CATE_LEVEL02;
				}
				$nxt_level = G_CATE_LEVEL02;
				break;
			case G_CATE_LEVEL03 : //レベル２
				$leve_sec = "dir_third";
				if (strcmp($cate_03, $i_objDac->fld['cate_code']) == 0) {
					$exp_img = G_LIST_IMG_M;
					$bak_level = G_CATE_LEVEL02;
					$sort_flg = 1;
				}
				else {
					$exp_img = G_LIST_IMG_P;
					$bak_level = G_CATE_LEVEL03;
				}
				$nxt_level = G_CATE_LEVEL03;
				break;
			case G_CATE_LEVEL04 : //レベル３
				$o_DspLst .= "<p align=\"left\" class=\"dir_fourth\">";
				$o_DspLst .= "<img src=\"../images/dir_none.jpg\" alt=\"\" width=\"60\" height=\"20\">";
				$o_DspLst .= htmlspecialchars($i_objDac->fld['name']);
				$o_DspLst .= "（" . $i_objDac->fld['cate_code'] . "）　";
				$o_DspLst .= "<a href=\"./form.php?mode=upd&level=" . G_CATE_LEVEL04 . "&cate_code=" . $i_objDac->fld['cate_code'] . "&cate_id=" . $i_objDac->fld['cate_id'] . "&d_l=" . G_CATE_LEVEL03 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_FIX . "</a>　";
				$o_DspLst .= "<a href=\"./confirm.php?mode=del&level=" . G_CATE_LEVEL04 . "&cate_code=" . $i_objDac->fld['cate_code'] . "&cate_id=" . $i_objDac->fld['cate_id'] . "&d_l=" . G_CATE_LEVEL03 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_DEL . "</a>　";
				break;
		}
		
		if ($i_objDac->fld['level'] != G_CATE_LEVEL04) {
			$o_DspLst .= "<p align=\"left\" class=\"" . $leve_sec . "\">";
			$o_DspLst .= "<a name=\"" . $i_objDac->fld['cate_code'] . "\"></a>";
			$o_DspLst .= "<a href=\"./index.php?level=" . $bak_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "#" . $cateInfo['cate1_code'] . "\">";
			//			$o_DspLst .= "<a href=\"./index.php?level=" . $bak_level . "&cate_code=" . $i_objDac->fld['cate_code'] ."\">";
			$o_DspLst .= "<img src=\"" . $exp_img . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\">";
			$o_DspLst .= "</a>";
			$o_DspLst .= htmlspecialchars($i_objDac->fld['name']);
			$o_DspLst .= "（" . $i_objDac->fld['cate_code'] . "）　";
			$o_DspLst .= "<a href=\"./form.php?mode=new&level=" . $nxt_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "&d_l=" . G_CATE_LEVEL03 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_ADD . "</a>　";
			$o_DspLst .= "<a href=\"./form.php?mode=upd&level=" . $nxt_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "&cate_id=" . $i_objDac->fld['cate_id'] . "&d_l=" . G_CATE_LEVEL03 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_FIX . "</a>　";
			$o_DspLst .= "<a href=\"./confirm.php?mode=del&level=" . $nxt_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "&cate_id=" . $i_objDac->fld['cate_id'] . "&d_l=" . G_CATE_LEVEL03 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_DEL . "</a>　";
			
			if ($sort_flg == 1) {
				$o_DspLst .= "<a href=\"./sortorder.php?level=" . $nxt_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "&d_l=" . G_CATE_LEVEL03 . "&d_c=" . $i_PrmCateCode . "\">" . G_LIST_BTN_SORT . "</a>";
			}
			
			$o_DspLst .= "</p>";
		}
	
	}
	
	//---TOP URL
	$o_TopAddURL = "./form.php?mode=new&d_c=" . $i_PrmCateCode . "&d_l=" . G_CATE_LEVEL03 . "&level=0&cate_code=" . $i_PrmCateCode;

}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>分類一覧</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="category.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">

<?=$GLOBALS["StrDbg"]?>

<?php
// ヘッダーメニュー挿入
$headerMode = 'category';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-categories">
<div><img src="images/bar_category.jpg" alt="分類一覧" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<p align="left"><img src="images/label_top.gif" alt="トップ" width="50"
	height="20"> <a href="<?=$TopAddURL?>"><?=G_LIST_BTN_ADD?></a> <a
	href="./sortorder.php?level=0"><?=G_LIST_BTN_SORT?></a></p>
<?=$DspLst?>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
