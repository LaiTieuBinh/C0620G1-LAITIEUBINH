<?php
/*
 * カテゴリ管理　表示順序更新処理(sortorder_comp.php)
 */
$StrDbg = "";
$GLOBALS["StrDbg"] = "";

/*---------------------------------------------
	定数 
----------------------------------------------*/

//表示&カテゴリレベル
define("G_CATE_LEVEL00", 0); //初期画面
define("G_CATE_LEVEL01", 1); //第1レベル
define("G_CATE_LEVEL02", 2); //第2レベル
define("G_CATE_LEVEL03", 3); //第3レベル
define("G_CATE_LEVEL04", 4); //第4レベル


//エラーコード
define("G_ERR_CATE", 1); //エラー関数　第二引数値


/*---------------------------------------------------------------------------------
	form.php
	
	パラメーター
	level:指定されたカテゴリレベル
	cate_code：指定されたカテゴリコード
	d_l:一覧画面の表示レベル
	d_c：一覧画面で対象となっているカテゴリコード
	
---------------------------------------------------------------------------------*/

/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

/*---引数の取得---*/
$args = ($_SERVER['REQUEST_METHOD'] == 'GET') ? $_GET : $_POST;
//処理モード
//レベル
if (isset($args["level"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
	exit();
}
else {
	if ((strcmp($args["level"], G_CATE_LEVEL00) != 0) && (strcmp($args["level"], G_CATE_LEVEL01) != 0) && (strcmp($args["level"], G_CATE_LEVEL02) != 0) && (strcmp($args["level"], G_CATE_LEVEL03) != 0) && (strcmp($args["level"], G_CATE_LEVEL04) != 0)) {
		DispError("無効なパラメーターが指定されています。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
}
//カテゴリコード
if (strcmp($args["level"], G_CATE_LEVEL00) == 0) {
	$PrmCateCode = "";
}
else {
	if (isset($args["cate_code"]) == FALSE) {
		DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
	$PrmCateCode = $args["cate_code"];
}
//表示レベル、カテゴリコード
if (isset($args["d_l"]) == FALSE) {
	$d_l = G_CATE_LEVEL00;
}
else {
	$d_l = $args["d_l"];
}
if (isset($args["d_c"]) == FALSE) {
	$d_c = "";
}
else {
	$d_c = $args["d_c"];
}

/*--- データアクセスクラス ---*/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

//---画面項目の取得とチェック
$ArrItem = array();
if (G_GetFrmItemChkItem($objDac, $args["level"], $PrmCateCode, $args, $ArrItem, $ErrMsg) == FALSE) {
	//Err
	DispError($ErrMsg, G_ERR_CATE, "javascript:history.back()");
	exit();
}

//---ソートの更新
// トランザクション開始
$objCnc->begin();
foreach ($ArrItem as $key => $order) {
	//カテゴリテーブルの存在チェック
	if (FALSE == G_GetCateDat($objDac, $key)) {
		//ロールバック
		$objCnc->rollback();
		DispError("存在しない分類の表示順が指定されました。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
	//更新
	G_TblCateUpD($objDac, $key, $order);
}

// コミット
$objCnc->commit();

/*---一覧画面へと戻る---*/
$cateInfo = getCateCode($d_c);
header("Location: " . "./index.php?level=" . $d_l . "&cate_code=" . $d_c . "#" . $cateInfo['cate1_code']);

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	カテゴリテーブルの更新

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateID		更新をするカテゴリID
		$i_SortOrder	更新するカテゴリのソート順
		
【戻値】	なし
		
【備考】
-----------------------------------------------------------------------------*/
function G_TblCateUpD($i_objDac, $i_CateID, $i_SortOrder) {
	
	$sql = "UPDATE tbl_category SET  sort_order = '" . $i_SortOrder . "' WHERE( cate_id = " . $i_CateID . " )";
	//実行
	$i_objDac->execute(mb_convert_encoding($sql, "utf-8", "auto"));

}
/*-----------------------------------------------------------------------------
	指定されたカテゴリＩＤからカテゴリデータを取得する

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_GetCateID	取得するカテゴリID
		
【戻値】	TRUE	データが取得できた
		FALSE	データが取得できなかった
		
【備考】
-----------------------------------------------------------------------------*/
function G_GetCateDat($i_objDac, $i_GetCateID) {
	
	$ret = FALSE;
	
	//--- 2006-11-09 Y.Adachi Upd Start
	//	$sql = 	"SELECT tbl_category.cate_id, tbl_category.cate_code, tbl_category.name " . 
	//			"FROM tbl_category " .
	//			"WHERE (((tbl_category.cate_id)=" . mysql_real_escape_string($i_GetCateID) . "))";
	$sql = "SELECT tbl_category.cate_id, tbl_category.cate_code, tbl_category.name " . "FROM tbl_category " . "WHERE (((tbl_category.cate_id)=" . gd_addslashes($i_GetCateID) . "))";
	// 大規模災害用の分類の場合は除外
	$sql .= ' AND ' . $i_objDac->_addslashesC('disaster_flg', FLAG_ON, '<>', 'INT');
	//--- 2006-11-09 Y.Adachi Upd End
	$i_objDac->execute($sql);
	
	if ($i_objDac->getRowCount() > 0) {
		$ret = TRUE;
	}
	
	return ($ret);
}

/*-----------------------------------------------------------------------------
	入力項目の取得とチェック

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateLevel	指定されたカテゴリレベル
		$i_CateCode		指定されたカテゴリコード
		$i_Args			画面から取得された値
		$o_ArrItem		画面項目の格納先
		$o_ErrMsg		エラーメッセージ
		
【戻値】	FALSE	エラーが存在した
		TRUE	エラーなし
		
【備考】
-----------------------------------------------------------------------------*/
function G_GetFrmItemChkItem($i_objDac, $i_CateLevel, $i_CateCode, $i_Args, &$o_ArrItem, &$o_ErrMsg) {
	
	//---SQL部品の作成
	$sql_level = 0;
	$sql_like = "";
	$sql = "";
	switch ($i_CateLevel) {
		case G_CATE_LEVEL00 : //レベル0
			$sql = "SELECT tbl_category.* FROM tbl_category " . "WHERE (((tbl_category.level)=" . G_CATE_LEVEL01 . "))" . "ORDER BY tbl_category.sort_order, tbl_category.cate_id";
			break;
		case G_CATE_LEVEL01 : //レベル1
			$sql_like = substr($i_CateCode, 0, CODE_DIGIT_CATE); //カテゴリコード1
			$sql_level = 0;
			$sql_level = G_CATE_LEVEL02;
			break;
		case G_CATE_LEVEL02 : //レベル2
			$sql_like = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE)); //カテゴリコード2
			$sql_level = G_CATE_LEVEL03;
			break;
		case G_CATE_LEVEL03 : //レベル3
			$sql_like = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE)); //カテゴリコード3
			$sql_level = G_CATE_LEVEL04;
			break;
	}
	
	//--SQL
	if (strcmp($i_CateLevel, G_CATE_LEVEL00) != 0) {
		$sql = "SELECT tbl_category.* FROM tbl_category " . "WHERE (((tbl_category.level)=" . $sql_level . ") AND ((tbl_category.cate_code) Like '" . $sql_like . "%'))";
		"ORDER BY tbl_category.sort_order, tbl_category.cate_id";
	}
	
	//---取得
	$i_objDac->execute($sql);
	
	//---画面項目との連携
	while ($i_objDac->fetch()) {
		//存在する項目のみをチェックする（この処理中に追加、削除された項目は無効
		if (isset($i_Args[$i_objDac->fld['cate_id']]) == TRUE) {
			//項目確保
			$sort_order = $i_Args[$i_objDac->fld['cate_id']];
			//未入力		
			if (strlen($sort_order) <= 0) {
				$o_ErrMsg = "表示順序の省略はできません。";
				return FALSE;
			}
			//半角数値チェック
			if (!(preg_match("/^[0-9]+$/", $sort_order))) {
				$o_ErrMsg = "表示順序は半角数値のみ有効です。";
				return FALSE;
			}
			//配列にセット
			$o_ArrItem[$i_objDac->fld['cate_id']] = $sort_order;
		
		}
	}
	
	return TRUE;

}

/*
<html>
<head>
<title>test</title>
</head>
<body>
<?php 

while(list($key, $value) = each($ArrItem)){
    $order = $value;
    print "[".$key."]=" . $order . "<br>";
}

?>
</body>
</html>
*/

?>
