<?php
/*
 * カテゴリ管理　登録・更新・削除処理(comp.php)
 */
$StrDbg = "";
$GLOBALS["StrDbg"] = "";

/*---------------------------------------------
	定数 
----------------------------------------------*/

//表示&カテゴリレベル
define("G_CATE_LEVEL00", 0); //初期画面
define("G_CATE_LEVEL01", 1); //第1レベル
define("G_CATE_LEVEL02", 2); //第2レベル
define("G_CATE_LEVEL03", 3); //第3レベル
define("G_CATE_LEVEL04", 4); //第4レベル


//処理モード
define("G_CATE_MODE_NEW", "new"); //新規登録処理
define("G_CATE_MODE_UPD", "upd"); //更新処理
define("G_CATE_MODE_DEL", "del"); //更新処理


//エラーコード
define("G_ERR_CATE", 1); //エラー関数　第二引数値


/*---------------------------------------------------------------------------------
	confirm.php
	
	パラメーター
	mode：処理モード
				new 新規
				upd	更新
				del	削除
	level:指定されたカテゴリレベル
				mode=new	一覧画面で「下位カテゴリを追加」がクリックされたカテゴリレベル
				mode=upd	一覧画面で「修正」がクリックされたカテゴリの属するカテゴリレベル
				mode=del	一覧画面で「削除」がクリックされたカテゴリの属するカテゴリレベル
	cate_code：カテゴリコード
				mode=new	一覧画面で「下位カテゴリを追加」がクリックされたカテゴリコード
							ただし、level=G_CATE_LEVEL00の時は省略
				mode=upd	一覧画面で「修正」がクリックされたカテゴリの上位カテゴリコード
				mode=del	一覧画面で「削除」がクリックされたカテゴリの上位カテゴリコード
	cate_id：カテゴリＩＤ
				mode=new	なし
				mode=upd	更新処理を行なうカテゴリＩＤ
				mode=del	削除処理を行なうカテゴリＩＤ
	d_l：一覧表示カテゴリレベル
	d_c：一覧表示カテゴリコード
	
---------------------------------------------------------------------------------*/

/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

/*---引数の取得---*/
$args = ($_SERVER['REQUEST_METHOD'] == 'GET') ? $_GET : $_POST;
//処理モード
if (isset($args["mode"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
	exit();
}
else {
	if ((strcmp($args["mode"], G_CATE_MODE_NEW) != 0) && (strcmp($args["mode"], G_CATE_MODE_UPD) != 0) && (strcmp($args["mode"], G_CATE_MODE_DEL) != 0)) {
		DispError("無効なパラメーターが指定されています。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
}
//レベル
if (isset($args["level"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
	exit();
}
else {
	if ((strcmp($args["level"], G_CATE_LEVEL00) != 0) && (strcmp($args["level"], G_CATE_LEVEL01) != 0) && (strcmp($args["level"], G_CATE_LEVEL02) != 0) && (strcmp($args["level"], G_CATE_LEVEL03) != 0) && (strcmp($args["level"], G_CATE_LEVEL04) != 0)) {
		DispError("無効なパラメーターが指定されています。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
}
//カテゴリコード
if (isset($args["cate_code"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。7", G_ERR_CATE, "javascript:history.back()");
	exit();
}
//カテゴリＩＤ
$GetCateID = "";
if ((strcmp($args["mode"], G_CATE_MODE_UPD) == 0) || (strcmp($args["mode"], G_CATE_MODE_DEL) == 0)) {
	if (isset($args["cate_id"]) == FALSE) {
		DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
	else {
		$GetCateID = $args["cate_id"];
	}
}
//一覧表示レベル
if (isset($args["d_l"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
	exit();
}
else {
	if ((strcmp($args["d_l"], G_CATE_LEVEL00) != 0) && (strcmp($args["d_l"], G_CATE_LEVEL01) != 0) && (strcmp($args["d_l"], G_CATE_LEVEL02) != 0) && (strcmp($args["d_l"], G_CATE_LEVEL03) != 0) && (strcmp($args["d_l"], G_CATE_LEVEL04) != 0)) {
		DispError("無効なパラメーターが指定されています。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
}
//表示カテゴリコード
$DspD_C = "";
if (isset($args["d_c"]) == TRUE) {
	$DspD_C = $args["d_c"];
}

/*---画面項目の取得---*/
//---登録・更新時
if ((strcmp($args["mode"], G_CATE_MODE_NEW) == 0) || (strcmp($args["mode"], G_CATE_MODE_UPD) == 0)) {
	//カテゴリ名
	if (isset($args["newcatenm"]) == FALSE) {
		DispError("分類名の省略はできません。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
	else {
		if (strlen($args["newcatenm"]) <= 0) {
			DispError("分類名の省略はできません。", G_ERR_CATE, "javascript:history.back()");
			exit();
		}
		//機種依存チェック
		$EncCateName = mb_convert_encoding($args["newcatenm"], "utf-8", "auto");
		if (FALSE == checkMachineCode($args["newcatenm"])) {
			DispError("分類名に機種依存文字が指定されています。機種依存文字の指定はできません。", G_ERR_CATE, "javascript:history.back()");
			exit();
		}
	}
	//カテゴリコード
	if (isset($args["newcatecd"]) == FALSE) {
		DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
	else {
		if (strlen($args["newcatecd"]) <= 0) {
			DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
			exit();
		}
	}
	//ソート順
	if (strcmp($args["mode"], G_CATE_MODE_NEW) == 0) {
		if (isset($args["newsortod"]) == FALSE) {
			DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
			exit();
		}
		else {
			if (strlen($args["newsortod"]) <= 0) {
				DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
				exit();
			}
		}
	}
}

/*--- データアクセスクラス ---*/
global $objCnc;
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objDac = new dac($objCnc);

// トランザクション開始
$objCnc->begin();

//カテゴリテーブルへの登録・更新・削除
switch ($args["mode"]) {
	case G_CATE_MODE_NEW : //新規
		//新規登録処理
		if (FALSE == G_TblCateNew($objDac, $args["level"], $args["newcatecd"], $args["newcatenm"], $args["newsortod"])) {
			//エラーページの表示
			DispError("分類情報の登録に失敗しました。", G_ERR_CATE, "javascript:history.back()");
			exit();
		}
		break;
	case G_CATE_MODE_UPD : //更新
		//---レコードチェック
		//更新するカテゴリデータの取得
		if (FALSE == G_GetCateDat($objDac, $args["cate_id"], $cate_cd, $cate_nm)) {
			DispError("指定された分類ＩＤのデータが存在しませんでした。", G_ERR_CATE, "javascript:history.back()");
			exit();
		}
		//更新処理
		if (FALSE == G_TblCateUpD($objDac, $args["cate_id"], $args["newcatenm"])) {
			//エラーページの表示
			DispError("分類情報の更新に失敗しました。", G_ERR_CATE, "javascript:history.back()");
			exit();
		}
		break;
	case G_CATE_MODE_DEL : //削除
		//---レコードチェック
		//削除されるカテゴリデータの取得
		if (FALSE == G_GetCateDat($objDac, $args["cate_id"], $cate_cd, $cate_nm)) {
			DispError("指定された分類ＩＤのデータが存在しませんでした。", G_ERR_CATE, "javascript:history.back()");
			exit();
		}
		//以下のテーブルで使用されているカテゴリの削除は不可とする。
		//⇒「work_page」テーブルの「cate_code」
		//削除するカテゴリ下位データも「work_page」に存在していた場合はエラー
		if (0 < G_ChkCateCodeTblWorkPage($objDac, $cate_cd, $args["level"])) {
			DispError("指定された分類、または、下位分類がwork_pageで使用されています。", G_ERR_CATE, "javascript:history.back()");
			exit();
		}
		//⇒「publish_page」テーブルの「cate_code」	
		if (0 < G_ChkCateCodeTblPublishPage($objDac, $cate_cd, $args["level"])) {
			DispError("指定された分類、または、下位分類がpublish_pageで使用されています。", G_ERR_CATE, "javascript:history.back()");
			exit();
		}
		//削除処理
		if (FALSE == G_TblCateDel($objDac, $cate_cd, $args["level"])) {
			//エラーページの表示
			DispError("分類情報の更新に失敗しました。[" . $GLOBALS["StrDbg"], G_ERR_CATE, "javascript:history.back()");
			exit();
		}
		//---削除の場合はTOPに戻る
		$args["d_l"] = G_CATE_LEVEL00;
		$DspD_C = "";
		break;
}

//--- コミット
$objCnc->commit();

/*---一覧画面へと戻る---*/
$cateInfo = getCateCode($DspD_C);
header("Location: " . "./index.php?level=" . $args["d_l"] . "&cate_code=" . $DspD_C . "#" . $cateInfo['cate1_code']);

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	カテゴリテーブルの削除
	
【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateID		削除するカテゴリコード
		$i_CateLevel	削除するカテゴリのレベル
		
【戻値】	処理結果 False 失敗
		
【備考】
-----------------------------------------------------------------------------*/
function G_TblCateDel($i_objDac, $i_CateCode, $i_CateLevel) {
	
	$str_like = "";
	switch ($i_CateLevel) {
		case G_CATE_LEVEL01 : //レベル1
			$str_like = substr($i_CateCode, 0, CODE_DIGIT_CATE);
			break;
		case G_CATE_LEVEL02 : //レベル2
			$str_like = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE));
			break;
		case G_CATE_LEVEL03 : //レベル3
			$str_like = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE));
			break;
		case G_CATE_LEVEL04 : //レベル4
			$str_like = $i_CateCode;
			break;
	}
	
	$sql = "DELETE FROM tbl_category WHERE (((tbl_category.cate_code) Like '" . $str_like . "%'))";
	
	//実行
	return ($i_objDac->execute(mb_convert_encoding($sql, "utf-8", "auto")));

}

/*-----------------------------------------------------------------------------
	カテゴリテーブルの更新

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateID		更新をするカテゴリID
		$i_CateName		更新するカテゴリのカテゴリ名
		
【戻値】	処理結果 False 失敗
		
【備考】
-----------------------------------------------------------------------------*/
function G_TblCateUpD($i_objDac, $i_CateID, $i_CateName) {
	
	$sql = "UPDATE tbl_category SET  name = '" . $i_CateName . "' WHERE( cate_id = " . $i_CateID . " )";
	//実行
	return ($i_objDac->execute(mb_convert_encoding($sql, "utf-8", "auto")));

}

/*-----------------------------------------------------------------------------
	カテゴリテーブルに新規追加

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateLevel	登録するカテゴリのレベル
		$i_CateCode		登録するカテゴリのカテゴリコード
		$i_CateName		登録するカテゴリのカテゴリ名
		$i_SortOrder	登録するカテゴリのソート順序
		
【戻値】	処理結果 False 失敗
		
【備考】
-----------------------------------------------------------------------------*/
function G_TblCateNew($i_objDac, $i_CateLevel, $i_CateCode, $i_CateName, $i_SortOrder) {
	
	$level = $i_CateLevel + 1;
	
	$sql = "INSERT INTO tbl_category ( level, cate_code, name, sort_order) VALUES (";
	$sql = $sql . gd_addslashes($level) . ", "; //レベル
	$sql = $sql . "'" . gd_addslashes($i_CateCode) . "', "; //カテゴリコード
	$sql = $sql . "'" . gd_addslashes($i_CateName) . "', "; //カテゴリ名
	$sql = $sql . gd_addslashes($i_SortOrder); //ソート順
	$sql = $sql . ");";
	
	//実行
	return ($i_objDac->execute(mb_convert_encoding($sql, "utf-8", "auto")));

}

/*-----------------------------------------------------------------------------
	指定されたカテゴリコードの下位カテゴリがカテゴリ情報に存在するかをチェックする

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateLevel	チェックするカテゴリコードのレヴェル
		$i_CateCode		チェックするカテゴリコード
		
【戻値】	データ件数
		
【備考】
-----------------------------------------------------------------------------*/
function G_ChkCateCodeUnderCate($i_objDac, $i_CateLevel, $i_CateCode) {
	
	//---カテゴリコード
	$like_cate = "";
	switch ($i_CateLevel) {
		case G_CATE_LEVEL01 : //レベル1
			$like_cate = substr($i_CateCode, 0, CODE_DIGIT_CATE);
			break;
		case G_CATE_LEVEL02 : //レベル2
			$like_cate = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE));
			break;
		case G_CATE_LEVEL03 : //レベル3
			$like_cate = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE));
			break;
		case G_CATE_LEVEL04 : //レベル4
			//レベル４の下位は存在しないため、削除してもOK
			return (0);
	}
	//---カテゴリレベル
	$chk_lebel = $i_CateLevel + 1;
	
	$sql = "SELECT tbl_category.cate_id, tbl_category.cate_code, tbl_category.level " . "FROM tbl_category " . "WHERE (((tbl_category.cate_code) Like '" . $like_cate . "*') AND ((tbl_category.level)=" . $chk_lebel . "))";
	//取得
	$i_objDac->execute($sql);
	//件数
	return ($i_objDac->getRowCount());

}

/*-----------------------------------------------------------------------------
	指定されたカテゴリコードの存在チェック　「publish_page」

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateCode		チェックするカテゴリコード
		$i_CateLevel	チェックするカテゴリレベル
		
【戻値】	データ件数
		
【備考】
-----------------------------------------------------------------------------*/
function G_ChkCateCodeTblPublishPage($i_objDac, $i_CateCode, $i_CateLevel) {
	
	$str_like = "";
	switch ($i_CateLevel) {
		case G_CATE_LEVEL01 : //レベル1
			$str_like = substr($i_CateCode, 0, CODE_DIGIT_CATE);
			break;
		case G_CATE_LEVEL02 : //レベル2
			$str_like = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE));
			break;
		case G_CATE_LEVEL03 : //レベル3
			$str_like = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE));
			break;
		case G_CATE_LEVEL04 : //レベル4
			$str_like = $i_CateCode;
			break;
	}
	
	$sql = "SELECT tbl_publish_page.cate_code " . "FROM tbl_category RIGHT JOIN tbl_publish_page ON tbl_category.cate_code = tbl_publish_page.cate_code " . "WHERE (((tbl_category.cate_code) Like '" . $str_like . "%'))";
	
	//取得
	$i_objDac->execute($sql);
	//件数
	return ($i_objDac->getRowCount());

}
/*-----------------------------------------------------------------------------
	指定されたカテゴリコードの存在チェック　「work_page」

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateCode		チェックするカテゴリコード
		$i_CateLevel	チェックするカテゴリレベル
		
【戻値】	データ件数
		
【備考】
-----------------------------------------------------------------------------*/
function G_ChkCateCodeTblWorkPage($i_objDac, $i_CateCode, $i_CateLevel) {
	
	$str_like = "";
	switch ($i_CateLevel) {
		case G_CATE_LEVEL01 : //レベル1
			$str_like = substr($i_CateCode, 0, CODE_DIGIT_CATE);
			break;
		case G_CATE_LEVEL02 : //レベル2
			$str_like = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE));
			break;
		case G_CATE_LEVEL03 : //レベル3
			$str_like = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE));
			break;
		case G_CATE_LEVEL04 : //レベル4
			$str_like = $i_CateCode;
			break;
	}
	
	$sql = "SELECT tbl_category.cate_code " . "FROM tbl_category RIGHT JOIN tbl_work_page ON tbl_category.cate_code = tbl_work_page.cate_code " . "WHERE (((tbl_category.cate_code) Like '" . $str_like . "%'))";
	
	//取得
	$i_objDac->execute($sql);
	//件数
	return ($i_objDac->getRowCount());

}
/*-----------------------------------------------------------------------------
	指定されたカテゴリＩＤからカテゴリデータを取得する

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_GetCateID	取得するカテゴリID
		$o_CateCode		取得されたカテゴリコード
		$o_CateNm		取得されたカテゴリ名
		
【戻値】	TRUE	データが取得できた
		FALSE	データが取得できなかった
		
【備考】
-----------------------------------------------------------------------------*/
function G_GetCateDat($i_objDac, $i_GetCateID, &$o_CateCode, &$o_CateNm) {
	
	$ret = FALSE;
	
	$sql = "SELECT tbl_category.cate_id, tbl_category.cate_code, tbl_category.name " . "FROM tbl_category " . "WHERE (((tbl_category.cate_id)=" . gd_addslashes($i_GetCateID) . "))";
	$i_objDac->execute($sql);
	while ($i_objDac->fetch()) {
		$ret = TRUE;
		$o_CateCode = $i_objDac->fld['cate_code'];
		$o_CateNm = $i_objDac->fld['name'];
		break;
	}
	
	return ($ret);
}

/*-----------------------------------------------------------------------------
	指定されたカテゴリＩＤからカテゴリデータを取得する

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_GetCateID	取得するカテゴリID
		$o_CateCode		取得されたカテゴリコード
		$o_CateNm		取得されたカテゴリ名
		
【戻値】	TRUE	データが取得できた
		FALSE	データが取得できなかった
		
【備考】
-----------------------------------------------------------------------------*/
function G_GetCateDat_old($i_objDac, $i_GetCateID) {
	
	$ret = FALSE;
	
	$sql = "SELECT tbl_category.cate_id, tbl_category.cate_code, tbl_category.name " . "FROM tbl_category " . "WHERE (((tbl_category.cate_id)=" . gd_addslashes($i_GetCateID) . "))";
	$i_objDac->execute($sql);
	
	if ($i_objDac->getRowCount() > 0) {
		$ret = TRUE;
	}
	
	return ($ret);
}

?>
