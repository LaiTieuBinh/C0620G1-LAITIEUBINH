<?php
/*
 * カテゴリ管理　登録・更新画面(form.php)
 */
$StrDbg = "";
$GLOBALS["StrDbg"] = "";

/*---------------------------------------------
	定数 
----------------------------------------------*/

//表示&カテゴリレベル
define("G_CATE_LEVEL00", 0); //初期画面
define("G_CATE_LEVEL01", 1); //第1レベル
define("G_CATE_LEVEL02", 2); //第2レベル
define("G_CATE_LEVEL03", 3); //第3レベル
define("G_CATE_LEVEL04", 4); //第4レベル


//処理モード
define("G_CATE_MODE_NEW", "new"); //新規登録処理
define("G_CATE_MODE_UPD", "upd"); //更新処理


//エラーコード
define("G_ERR_CATE", 1); //エラー関数　第二引数値


/*---------------------------------------------------------------------------------
	form.php
	
	パラメーター
	mode：処理モード
				new 新規
				upd	更新
	level:指定されたカテゴリレベル
				mode=new	一覧画面で「下位カテゴリを追加」がクリックされたカテゴリレベル
				mode=upd	一覧画面で「修正」がクリックされたカテゴリの属するカテゴリレベル
	cate_code：カテゴリコード
				mode=new	一覧画面で「下位カテゴリを追加」がクリックされたカテゴリコード
							ただし、level=G_CATE_LEVEL00の時は省略
				mode=upd	一覧画面で「修正」がクリックされたカテゴリの上位カテゴリコード
	cate_id：カテゴリＩＤ
				mode=new	なし
				mode=upd	更新処理を行なうカテゴリＩＤ
	d_l：一覧表示カテゴリレベル
	d_c：一覧表示カテゴリコード
	
---------------------------------------------------------------------------------*/

/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

/*---引数の取得---*/
$args = ($_SERVER['REQUEST_METHOD'] == 'GET') ? $_GET : $_POST;
//処理モード
if (isset($args["mode"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
	exit();
}
else {
	if ((strcmp($args["mode"], G_CATE_MODE_NEW) != 0) && (strcmp($args["mode"], G_CATE_MODE_UPD) != 0)) {
		DispError("無効なパラメーターが指定されています。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
}
//レベル
if (isset($args["level"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
	exit();
}
else {
	if ((strcmp($args["level"], G_CATE_LEVEL00) != 0) && (strcmp($args["level"], G_CATE_LEVEL01) != 0) && (strcmp($args["level"], G_CATE_LEVEL02) != 0) && (strcmp($args["level"], G_CATE_LEVEL03) != 0) && (strcmp($args["level"], G_CATE_LEVEL04) != 0)) {
		DispError("無効なパラメーターが指定されています。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
}
//カテゴリコード
if (isset($args["cate_code"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
	exit();
}
//カテゴリＩＤ
$GetCateID = "";
if (strcmp($args["mode"], G_CATE_MODE_UPD) == 0) {
	if (isset($args["cate_id"]) == FALSE) {
		DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
	else {
		$GetCateID = $args["cate_id"];
	}
}
//表示カテゴリレベル
if (isset($args["d_l"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", G_ERR_CATE, "javascript:history.back()");
	exit();
}
else {
	if ((strcmp($args["d_l"], G_CATE_LEVEL00) != 0) && (strcmp($args["d_l"], G_CATE_LEVEL01) != 0) && (strcmp($args["d_l"], G_CATE_LEVEL02) != 0) && (strcmp($args["d_l"], G_CATE_LEVEL03) != 0) && (strcmp($args["d_l"], G_CATE_LEVEL04) != 0)) {
		DispError("無効なパラメーターが指定されています。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
}
//表示カテゴリコード
$DspD_C = "";
if (isset($args["d_c"]) == TRUE) {
	$DspD_C = $args["d_c"];
}

/*--- データアクセスクラス ---*/
global $objCnc;
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*---画面作成---*/
$DspTitle = ""; //タイトル
$DspTitleImg = ""; //タイトルイメージ
if (strcmp($args["mode"], G_CATE_MODE_NEW) == 0) {
	$DspTitle = "分類追加";
	$DspTitleImg = "bar_add.jpg";
}
else {
	$DspTitle = "分類修正";
	$DspTitleImg = "bar_fix.jpg";
}
//上位カテゴリ名
if ($args["level"] == G_CATE_LEVEL00) {
	$DspCateTitle = "トップ";
}
else {
	$DspCateTitle = G_GetCateName($objDac, $args["level"], $args["cate_code"]);
}

/*---表示項目の取得---*/
$DspCateCode = "";
$DspCateName = "";
$NextURL = "./confirm.php";
$CanURL = "./index.php?level=" . $args["d_l"] . "&cate_code=" . $DspD_C;
$HideSortOrder = 0;
if (strcmp($args["mode"], G_CATE_MODE_NEW) == 0) {
	//---新規登録
	//新規カテゴリーコードの取得
	$DspCateCode = G_GetCateCode_Add($objDac, $args["level"], $args["cate_code"], $HideSortOrder);
}
else {
	//---更新
	//データの取得
	if (FALSE == G_GetCateDat($objDac, $GetCateID, $DspCateCode, $DspCateName)) {
		DispError("指定された分類ＩＤのデータが存在しませんでした。", G_ERR_CATE, "javascript:history.back()");
		exit();
	}
}

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	カテゴリ名の取得

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateLevel	指定されたカテゴリレベル
		$i_CateCode		指定されたカテゴリコード
		
【戻値】	取得したカテゴリ名	
		
【備考】
-----------------------------------------------------------------------------*/
function G_GetCateName($i_objDac, $i_CateLevel, $i_CateCode) {
	
	//---とりあえず、全コード作っておく
	//カテゴリコード1
	$cate_01 = substr($i_CateCode, 0, CODE_DIGIT_CATE);
	$cate_01 = str_pad($cate_01, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
	//カテゴリコード2
	$cate_02 = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE));
	$cate_02 = str_pad($cate_02, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
	//カテゴリコード3
	$cate_03 = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE));
	$cate_03 = str_pad($cate_03, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
	//カテゴリコード4
	$cate_04 = $i_CateCode;
	
	//---SQL部品の作成
	$sel_tbl = "";
	$from_tbl = "";
	$where_tbl = "";
	switch ($i_CateLevel) {
		case G_CATE_LEVEL01 : //レベル1
			$sel_tbl = "tbl_category.cate_code, tbl_category.name ";
			$from_tbl = "tbl_category ";
			$where_tbl = "((tbl_category.cate_code)='" . $cate_01 . "')";
			break;
		case G_CATE_LEVEL02 : //レベル2
			$sel_tbl = "tbl_category.cate_code, tbl_category.name, tbl_category_1.cate_code, tbl_category_1.name AS cate_nm02 ";
			$from_tbl = "tbl_category, tbl_category AS tbl_category_1 ";
			$where_tbl = "(((tbl_category.cate_code)='" . $cate_01 . "') AND ((tbl_category_1.cate_code)='" . $cate_02 . "'))";
			break;
		case G_CATE_LEVEL03 : //レベル3
			$sel_tbl = "tbl_category.cate_code, tbl_category.name, tbl_category_1.cate_code, tbl_category_1.name AS cate_nm02, " . "tbl_category_2.cate_code, tbl_category_2.name AS cate_nm03 ";
			$from_tbl = "tbl_category, tbl_category AS tbl_category_1, tbl_category AS tbl_category_2 ";
			$where_tbl = "(((tbl_category.cate_code)='" . $cate_01 . "') AND ((tbl_category_1.cate_code)='" . $cate_02 . "') AND " . " ((tbl_category_2.cate_code)='" . $cate_03 . "'))";
			break;
		case G_CATE_LEVEL04 : //レベル4
			$sel_tbl = "tbl_category.cate_code, tbl_category.name, tbl_category_1.cate_code, tbl_category_1.name As cate_nm02 , " . "tbl_category_2.cate_code, tbl_category_2.name As cate_nm03, tbl_category_3.cate_code, tbl_category_3.name As cate_nm04 ";
			$from_tbl = "tbl_category, tbl_category AS tbl_category_1, tbl_category AS tbl_category_2, tbl_category AS tbl_category_3 ";
			$where_tbl = "(((tbl_category.cate_code)='" . $cate_01 . "') AND ((tbl_category_1.cate_code)='" . $cate_02 . "') " . "AND ((tbl_category_2.cate_code)='" . $cate_03 . "') AND ((tbl_category_3.cate_code)='" . $cate_04 . "'))";
			break;
	}
	
	//--SQL結合
	$sql = "SELECT " . $sel_tbl . "FROM " . $from_tbl . "WHERE " . $where_tbl;
	
	//---取得
	$i_objDac->execute($sql);
	//---成形
	$cate_name = "";
	while ($i_objDac->fetch()) {
		switch ($i_CateLevel) {
			case G_CATE_LEVEL01 : //レベル1
				$cate_name = htmlspecialchars($i_objDac->fld['name']);
				break;
			case G_CATE_LEVEL02 : //レベル2
				$cate_name = htmlspecialchars($i_objDac->fld['name']) . " &gt; " . htmlspecialchars($i_objDac->fld['cate_nm02']);
				break;
			case G_CATE_LEVEL03 : //レベル3
				$cate_name = htmlspecialchars($i_objDac->fld['name']) . " &gt; " . htmlspecialchars($i_objDac->fld['cate_nm02']) . " &gt; " . htmlspecialchars($i_objDac->fld['cate_nm03']);
				break;
			case G_CATE_LEVEL04 : //レベル4
				$cate_name = htmlspecialchars($i_objDac->fld['name']) . " &gt; " . htmlspecialchars($i_objDac->fld['cate_nm02']) . " &gt; " . htmlspecialchars($i_objDac->fld['cate_nm03']) . " &gt; " . htmlspecialchars($i_objDac->fld['cate_nm04']);
				break;
		}
		break;
	}
	
	//---戻値
	return ($cate_name);

}

/*-----------------------------------------------------------------------------
	新規登録時のカテゴリコードを作成する

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_CateLevel	指定されたカテゴリレベル
		$i_CateCode		指定されたカテゴリコード
		$o_SortOrder	取得されたデータ件数プラス１の値（ソート数になる）
		
【戻値】	作成されたカテゴリコード
		
【備考】

-----------------------------------------------------------------------------*/
function G_GetCateCode_Add($i_objDac, $i_CateLevel, $i_CateCode, &$o_SortOrder) {
	
	$cate_cd = "";
	switch ($i_CateLevel) {
		case G_CATE_LEVEL00 : //レベル1に追加
			//---既存のレベル１のデータ件数を取得し、プラス１をしたものをコードとする
			$sql = "SELECT MAX(cate_code) AS dat_cnt FROM tbl_category " . "WHERE (((tbl_category.level)=" . G_CATE_LEVEL01 . "))";
			$i_objDac->execute($sql);
			$dat_cnt = 0;
			while ($i_objDac->fetch()) {
				$dat_cnt = $i_objDac->fld['dat_cnt'];
				$dat_cnt = substr($dat_cnt, 0, CODE_DIGIT_CATE);
				$dat_cnt = (int)$dat_cnt;
				break;
			}
			//コード成形
			$dat_cnt = $dat_cnt + 1;
			$cate_cd = str_pad($dat_cnt, CODE_DIGIT_CATE, "0", STR_PAD_LEFT);
			$cate_cd = str_pad($cate_cd, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
			//---ソートオーダーの取得
			$sql = "SELECT MAX(sort_order) AS sort_max FROM tbl_category WHERE (((tbl_category.level)=" . G_CATE_LEVEL01 . "))";
			$i_objDac->execute($sql);
			$o_SortOrder = 0;
			while ($i_objDac->fetch()) {
				$o_SortOrder = (int)$i_objDac->fld['sort_max'];
				break;
			}
			$o_SortOrder = $o_SortOrder + 1;
			break;
		case G_CATE_LEVEL01 : //レベル2に追加
			//---$i_CateCode前３桁を含む、既存のレベル２のデータ件数を取得し、プラス１をしたものをコードとする
			//カテゴリコード１の切り出し
			$cate_01 = substr($i_CateCode, 0, CODE_DIGIT_CATE);
			//データ件数取得
			$dat_cnt = G_GetCateDatCnt($i_objDac, G_CATE_LEVEL02, $cate_01);
			//最大値コードから件数のみを取得
			if (strlen($dat_cnt) > 0) {
				$dat_cnt = substr($dat_cnt, CODE_DIGIT_CATE, CODE_DIGIT_CATE);
				$dat_cnt = (int)$dat_cnt;
			}
			else {
				$dat_cnt = 0;
			}
			//コード成形
			$dat_cnt = $dat_cnt + 1;
			$cate_cd = str_pad($dat_cnt, CODE_DIGIT_CATE, "0", STR_PAD_LEFT);
			$cate_cd = $cate_01 . str_pad($cate_cd, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
			//---ソートオーダーの取得
			$o_SortOrder = G_GetCateMaxSortOrder($i_objDac, G_CATE_LEVEL02, $cate_01);
			$o_SortOrder = (int)$o_SortOrder + 1;
			break;
		case G_CATE_LEVEL02 : //レベル3に追加
			//---$i_CateCode前６桁を含む、既存のレベル３のデータ件数を取得し、プラス１をしたものをコードとする
			//カテゴリコード１～２の切り出し
			$cate_02 = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE));
			//データ件数取得
			$dat_cnt = G_GetCateDatCnt($i_objDac, G_CATE_LEVEL03, $cate_02);
			//最大値コードから件数のみを取得
			if (strlen($dat_cnt) > 0) {
				$dat_cnt = substr($dat_cnt, (CODE_DIGIT_CATE + CODE_DIGIT_CATE), CODE_DIGIT_CATE);
				$dat_cnt = (int)$dat_cnt;
			}
			else {
				$dat_cnt = 0;
			}
			//コード成形
			$dat_cnt = $dat_cnt + 1;
			$cate_cd = str_pad($dat_cnt, CODE_DIGIT_CATE, "0", STR_PAD_LEFT);
			$cate_cd = $cate_02 . str_pad($cate_cd, (CODE_DIGIT_CATE + CODE_DIGIT_CATE), "0", STR_PAD_RIGHT);
			//---ソートオーダーの取得
			$o_SortOrder = G_GetCateMaxSortOrder($i_objDac, G_CATE_LEVEL03, $cate_02);
			$o_SortOrder = (int)$o_SortOrder + 1;
			break;
		case G_CATE_LEVEL03 : //レベル4に追加
			//---$i_CateCode前９桁を含む、既存のレベル４のデータ件数を取得し、プラス１をしたものをコードとする
			//カテゴリコード１～３の切り出し
			$cate_03 = substr($i_CateCode, 0, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE));
			//データ件数取得
			$dat_cnt = G_GetCateDatCnt($i_objDac, G_CATE_LEVEL04, $cate_03);
			//最大値コードから件数のみを取得
			if (strlen($dat_cnt) > 0) {
				$dat_cnt = substr($dat_cnt, (CODE_DIGIT_CATE + CODE_DIGIT_CATE + CODE_DIGIT_CATE), CODE_DIGIT_CATE);
				$dat_cnt = (int)$dat_cnt;
			}
			else {
				$dat_cnt = 0;
			}
			//コード成形
			$dat_cnt = $dat_cnt + 1;
			$cate_cd = str_pad($dat_cnt, CODE_DIGIT_CATE, "0", STR_PAD_LEFT);
			$cate_cd = $cate_03 . $cate_cd;
			//---ソートオーダーの取得
			$o_SortOrder = G_GetCateMaxSortOrder($i_objDac, G_CATE_LEVEL04, $cate_03);
			$o_SortOrder = (int)$o_SortOrder + 1;
			break;
	}
	
	//データ件数プラス１の値が、そのままソートオーダー数
	//	$o_SortOrder= $dat_cnt;
	

	return ($cate_cd);

}

/*-----------------------------------------------------------------------------
	カテゴリデータから指定された条件のデータ件数を取得

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_GetLevel		取得するカテゴリレベル
		$i_LikeStr		取得するカテゴリコード
		
【戻値】	データ件数
		
【備考】
-----------------------------------------------------------------------------*/
function G_GetCateDatCnt($i_objDac, $i_GetLevel, $i_LikeStr) {
	
	$sql = "SELECT Max(tbl_category.cate_code) AS dat_cnt " . "FROM tbl_category " . "WHERE (((tbl_category.cate_code) Like '" . gd_addslashes($i_LikeStr) . "%') AND " . "((tbl_category.level)=" . gd_addslashes($i_GetLevel) . "))";
	
	$i_objDac->execute($sql);
	
	$max_code = "";
	while ($i_objDac->fetch()) {
		$max_code = $i_objDac->fld['dat_cnt'];
		break;
	}
	return ($max_code);
}

/*-----------------------------------------------------------------------------
	カテゴリデータから指定された条件のソート順序最大値を取得

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_GetLevel		取得するカテゴリレベル
		$i_LikeStr		取得するカテゴリコード
		
【戻値】	データ件数
		
【備考】
-----------------------------------------------------------------------------*/
function G_GetCateMaxSortOrder($i_objDac, $i_GetLevel, $i_LikeStr) {
	
	$sql = "SELECT Max(tbl_category.sort_order) AS sort_max " . "FROM tbl_category " . "WHERE (((tbl_category.cate_code) Like '" . gd_addslashes($i_LikeStr) . "%') AND " . "((tbl_category.level)=" . gd_addslashes($i_GetLevel) . "))";
	
	$i_objDac->execute($sql);
	
	$sort_max = "";
	while ($i_objDac->fetch()) {
		$sort_max = (int)$i_objDac->fld['sort_max'];
		break;
	}
	return ($sort_max);
}

/*-----------------------------------------------------------------------------
	指定されたカテゴリＩＤからカテゴリＩＤを取得する

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_GetCateID	取得するカテゴリID
		$o_CateCode		取得されたカテゴリコード
		$o_CateNm		取得されたカテゴリ名
		
【戻値】	TRUE	データが取得できた
		FALSE	データが取得できなかった
		
【備考】
-----------------------------------------------------------------------------*/
function G_GetCateDat($i_objDac, $i_GetCateID, &$o_CateCode, &$o_CateNm) {
	
	$ret = FALSE;
	
	$sql = "SELECT tbl_category.cate_id, tbl_category.cate_code, tbl_category.name " . "FROM tbl_category " . "WHERE (((tbl_category.cate_id)=" . gd_addslashes($i_GetCateID) . "))";
	$i_objDac->execute($sql);
	while ($i_objDac->fetch()) {
		$ret = TRUE;
		$o_CateCode = $i_objDac->fld['cate_code'];
		$o_CateNm = htmlspecialchars($i_objDac->fld['name']);
		break;
	}
	
	return ($ret);
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$DspTitle?>
</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="category.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?=$GLOBALS["StrDbg"]?>
<?php
$headerMode = 'category';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-categoryform">
<div><img src="images/<?=$DspTitleImg?>" alt="<?=$DspTitle?>"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<p align="left" id="cms8341-pankuzu"><?=$DspCateTitle?></p>
<form class="cms8341-form" method="POST" action="<?=$NextURL?>"
	name="Form">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="150" align="left" valign="top" scope="row">分類コード</th>
		<td align="left" valign="top"><?=$DspCateCode?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">分類名 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><input type="text" style="width: 540px;"
			name="txtcatenm" value="<?=$DspCateName?>"></td>
	</tr>
</table>
<p align="center"><input type="image" src="../images/btn_conf.jpg"
	alt="確認" width="150" height="20" border="0" style="margin-right: 10px">
<a href="<?=$CanURL?>"><img src="../../images/btn/btn_cansel_large.jpg"
	alt="キャンセル" width="150" height="20" border="0"
	style="margin-left: 10px"></a></p>
<INPUT TYPE="HIDDEN" NAME="newcatecd" VALUE="<?=$DspCateCode?>"> <INPUT
	TYPE="HIDDEN" NAME="newsortod" VALUE="<?=$HideSortOrder?>"> <INPUT
	TYPE="HIDDEN" NAME="mode" VALUE="<?=$args["mode"]?>"> <INPUT
	TYPE="HIDDEN" NAME="level" VALUE="<?=$args["level"]?>"> <INPUT
	TYPE="HIDDEN" NAME="cate_code" VALUE="<?=$args["cate_code"]?>"> <INPUT
	TYPE="HIDDEN" NAME="cate_id" VALUE="<?=$GetCateID?>"> <INPUT
	TYPE="HIDDEN" NAME="d_l" VALUE="<?=$args["d_l"]?>"> <INPUT
	TYPE="HIDDEN" NAME="d_c" VALUE="<?=$DspD_C?>"></form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
