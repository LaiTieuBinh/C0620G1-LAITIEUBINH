<?php
/*
 *
 */
/** require **/
require ("./.htsetting");
require_once ('./include/sampleFunc.php');

$func = new sampleFunc();
$dept_code = (isset($_GET['dept_code'])) ? $_GET['dept_code'] : "";
$html = $func->create_tree($dept_code);

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>組織／ユーザー管理</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="sample.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cx_open(dept_code){
	obj = $('img_'+dept_code);
	src = String(obj.src);
	if(src.match(/dir_plus/i)){
		obj.src = cms8341admin_path+'/master/images/dir_minus.jpg';
		Element.show($('div_'+dept_code));
		var params = 'Command=cx_open&dept_code=' + dept_code;
		new Ajax.Updater( 
		    'div_'+dept_code, 
			'./include/sample_connector.php',
		    { 
		        method: "post", 
		        parameters: params, 
		        onFailure: function(request) { 
		            alert('読み込みに失敗しました'); 
		        }, 
		        onException: function (request) { 
		            alert('読み込み中にエラーが発生しました'); 
		        } 
		    } 
		); 
	} else {
		Element.hide($('div_'+dept_code));
		obj.src = cms8341admin_path+'/master/images/dir_plus.jpg';
		$('div_'+dept_code).innerHTML = "";
	}

	return;
}


//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'deptuser';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-users">
<div><img src="images/bar_sample.jpg" alt="組織／ユーザー一覧" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?=$html?>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
