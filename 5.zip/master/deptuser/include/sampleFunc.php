<?php
/*
 *
 */
require_once (APPLICATION_ROOT . '/common/dbcontrol/b_dac.inc');

//表示＆組織レベル
define("G_DEPT_LEVEL00", 0); //初期
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


class sampleFunc {
	private $html;
	private $dept_def = '<p aling="left" class="dir_#level#">#image#<a href="./department/detail.php?dept_id=#dept_id#&level=#level#&dept_code=#dept_code#">#name#</a></p><div id="div_#dept_code#" style="display:none"></div>';
	private $user_def = '<p aling="left" class="dir_#level#"><img src="#image_path#" alt="#image_alt#" width="100" height="20" border="0">&nbsp;<a href="./user/detail.php?user_id=#user_id#&level=#level#&dept_code=#dept_code#">#name#</a></p>';
	private $image_none = '<img id="img_#dept_code#" src="../images/dir_none.jpg" alt="" width="60" height="20" border="0">';
	private $image_plus = '<a href="javascript:" onClick="cx_open(\'#dept_code#\')"><img id="img_#dept_code#" src="../images/dir_plus.jpg" alt="" width="60" height="20" border="0"></a>';
	private $image_minus = '<a href="javascript:" onClick="cx_open(\'#dept_code#\')"><img id="img_#dept_code#" src="../images/dir_minus.jpg" alt="" width="60" height="20" border="0"></a>';
	//クラスイメージPath
	private $user_img = array(
			USER_CLASS_WRITER => "images/author.gif", 
			USER_CLASS_APPROVER1 => "images/approve01.gif", 
			USER_CLASS_APPROVER2 => "images/approve02.gif", 
			USER_CLASS_APPROVER3 => "images/approve03.gif", 
			USER_CLASS_WEBMASTER => "images/webmaster.gif", 
			USER_CLASS_OPEN => "images/open.gif"
	);
	private $user_alt = array(
			USER_CLASS_WRITER => "ページ作成者", 
			USER_CLASS_APPROVER1 => "第1承認者", 
			USER_CLASS_APPROVER2 => "第2承認者", 
			USER_CLASS_APPROVER3 => "第3承認者", 
			USER_CLASS_WEBMASTER => "ウェブマスター", 
			USER_CLASS_OPEN => "公開責任者"
	);
	
	function __construct() {
		$this->html = "";
	}
	
	function create_tree($dept_code = "") {
		$ret = $this->create();
		$level = $this->get_dept_level($dept_code);
		for($i = 0; $i < $level; $i++) {
			$tgt_dept_code = substr($dept_code, 0, ($i + 1) * CODE_DIGIT_DEPT);
			$tgt_dept_code = $tgt_dept_code . str_repeat("0", CODE_DIGIT_DEPT * (3 - ($i + 1)));
			$tmp = $this->create($tgt_dept_code);
			$ret = str_replace('<div id="div_' . $tgt_dept_code . '" style="display:none">', '<div id="div_' . $tgt_dept_code . '">' . $tmp, $ret);
		}
		
		return $ret;
	}
	
	function create($dept_code = "") {
		global $objCnc;
		$this->html = "";
		
		$objDac = new b_dac($objCnc, "tbl_department", "dept_id");
		$objDac2 = new b_dac($objCnc, "tbl_department", "dept_id");
		
		$level = $this->get_dept_level($dept_code);
		
		$objDac->add_where("level", $level + 1);
		if ($dept_code != "") {
			$w_dept_code = substr($dept_code, 0, CODE_DIGIT_DEPT * $level);
			$objDac->add_where("dept_code", $w_dept_code . "%", "LIKE");
		}
		$user_str = $this->get_user_list($dept_code);
		$this->html .= $user_str . "\n";
		$objDac->select();
		while ($objDac->fetch()) {
			$dept_str = $this->dept_def;
			$fld = $objDac->fld;
			
			$objDac2->add_where("level", $fld['level'] + 1);
			$w_dept_code = substr($fld['dept_code'], 0, CODE_DIGIT_DEPT * $fld['level']);
			$objDac2->add_where("dept_code", $w_dept_code . "%", "LIKE");
			$objDac2->select();
			if ($user_str == "" && $objDac2->getRowCount() == 0) {
				$dept_str = str_replace("#image#", $this->image_none, $dept_str);
			}
			else {
				$dept_str = str_replace("#image#", $this->image_plus, $dept_str);
			}
			foreach ($fld as $col => $val) {
				$dept_str = str_replace("#" . $col . "#", $val, $dept_str);
			}
			$this->html .= $dept_str . "\n";
		}
		
		return $this->html;
	}
	
	function get_user_list($dept_code) {
		global $objCnc;
		$ret = "";
		if ($dept_code == "") {
			$dept_code = WEB_MASTER_CODE;
			$level = 0;
		}
		else {
			$level = $this->get_dept_level($dept_code);
		}
		$objDac = new b_dac($objCnc, "tbl_user", "user_id");
		$objDac->add_where("dept_code", $dept_code);
		$objDac->select("", "*", "class desc");
		while ($objDac->fetch()) {
			$fld = $objDac->fld;
			if ($dept_code == WEB_MASTER_CODE) {
				$objDac2 = new b_dac($objCnc, "tbl_handler");
				$objDac2->add_where("class", HANDLER_CLASS_OEPN_FLG);
				$objDac2->add_where("item1", $fld['user_id']);
				$objDac2->select();
				$isOpenUser = ($objDac2->fetch()) ? TRUE : FALSE;
				if ($isOpenUser) $fld['class'] = USER_CLASS_OPEN;
			}
			$user_str = $this->user_def;
			$user_str = str_replace("#level#", $level + 1, $user_str);
			$user_str = str_replace("#image_path#", $this->user_img[$fld['class']], $user_str);
			$user_str = str_replace("#image_alt#", $this->user_alt[$fld['class']], $user_str);
			foreach ($fld as $col => $val) {
				$user_str = str_replace("#" . $col . "#", $val, $user_str);
			}
			$ret .= $user_str . "\n";
		
		}
		
		return $ret;
	}
	
	function get_dept_level($dept_code) {
		if ($dept_code == "") return 0;
		$dept2_code = substr($dept_code, 3, 3);
		if ($dept2_code == "000") return 1;
		$dept3_code = substr($dept_code, 6, 3);
		if ($dept3_code == "000") return 2;
		return 3;
	}
}

?>
