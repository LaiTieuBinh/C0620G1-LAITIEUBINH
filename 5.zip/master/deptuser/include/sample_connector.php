<?php
/*
 *
 */
/** Ajax用の関数呼び出し **/
require_once ("../../../../../cms8341_sys/common/setting.inc");
// session
require_once (APPLICATION_ROOT . "/common/session/session.inc");
// commands
require_once (APPLICATION_ROOT . "/common/dbcontrol/commands.inc");

require_once ('./sample_connector.php');
require_once ('./sampleFunc.php');

$func = new sampleFunc();

// Commandが設定されていなければエラー
if (!isset($_POST['Command'])) return;

$ret = FALSE;
switch ($_POST['Command']) {
	case 'cx_open' :
		$ret = $func->create($_POST['dept_code']);
		break;
}
if ($ret !== FALSE) print $ret;
exit();

?>
