<?php
/*
 *
 */
/** require **/
require ("./.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac1 = new dac($objCnc);
$objDac2 = new dac($objCnc);
$objPage = new dac($objCnc);

if (isset($_POST['cms_target_before']) && $_POST['cms_target_before'] != "") {
	$dept_before = $_POST['cms_target_before'];
}
else {
	DispError("変更対象の組織が指定されていません。", 2, "javascript:history.back()");
	exit();
}

if (isset($_POST['cms_target_after']) && $_POST['cms_target_after'] != "") {
	$dept_after = $_POST['cms_target_after'];
}
else {
	DispError("変更後の組織が指定されていません。", 2, "javascript:history.back()");
	exit();
}

/** init **/
$label = '問い合わせ先変更';
$image = '<img src="images/bar_chg_inquiry.jpg" alt="問い合わせ先変更" width="920" height="30">';
$back = HTTP_ROOT . RPW . "/admin/master/sample/department/chg_inquiry.php";

//変換後の組織情報を取得
$sql = "SELECT * FROM tbl_department WHERE dept_code = '" . $dept_after . "'";
$objDac1->execute($sql);
if ($objDac1->getRowCount() == 0) {
	$objCnc->rollback();
	DispError("変更後で指定されている組織が存在しません。", 2, "javascript:history.back()");
	exit();
}
$objDac1->fetch();

//即公開用に影響を受けるページ情報を取得
$sql = "SELECT p.page_id, p.file_path, p.work_class, p.close_flg FROM tbl_publish_page as p INNER JOIN (SELECT DISTINCT inquiry_id, dept_code FROM tbl_publish_inquiry) as i" . " ON p.inquiry_id = i.inquiry_id" . " WHERE i.dept_code = '" . $dept_before . "'";
$objPage->execute($sql);

// トランザクション開始
$objCnc->begin();

//公開テーブルの変更
$sql = "UPDATE tbl_publish_inquiry SET ";
$sql .= "dept_code='" . $objDac1->fld['dept_code'] . "' ";
$sql .= ", drxt_number='" . $objDac1->fld['tel'] . "' ";
$sql .= ", fax='" . $objDac1->fld['fax'] . "' ";
$sql .= ", email='" . $objDac1->fld['email'] . "' ";
$sql .= "WHERE dept_code = '" . $dept_before . "' ";

if ($objDac2->execute($sql) === FALSE) {
	$objCnc->rollback();
	DispError("公開ページの問い合わせ先変換エラー", 2, "javascript:history.back()");
	exit();
}

//作業テーブルの変更
$sql = "UPDATE tbl_work_inquiry SET ";
$sql .= "dept_code='" . $objDac1->fld['dept_code'] . "' ";
$sql .= ", drxt_number='" . $objDac1->fld['tel'] . "' ";
$sql .= ", fax='" . $objDac1->fld['fax'] . "' ";
$sql .= ", email='" . $objDac1->fld['email'] . "' ";
$sql .= "WHERE dept_code = '" . $dept_before . "' ";

if ($objDac2->execute($sql) === FALSE) {
	$objCnc->rollback();
	DispError("作業中ページの問い合わせ先変換エラー", 2, "javascript:history.back()");
	exit();
}

$objCnc->commit();

//*****************************************************//
//ページ生成、公開サーバへのアップロード処理 **********//
//*****************************************************//
if (!SFTP_FLG) {
	$ftpCnc = connectFTP("cms");
	if (ENABLE_OPTION_ADVERT) $ftpCgiCnc = connectFTP("click_cgi");
}
// 外部連携自動出力用テンプレートID配列削除・初期化
unset($_SESSION['template_id_of_output_page']);
$_SESSION['template_id_of_output_page'] = array();
$out_errmsg = '';
while ($objPage->fetch()) {
	// 公開中ページ以外は公開しない
	if ($objPage->fld['work_class'] == WORK_CLASS_NEW) continue;
	if ($objPage->fld['close_flg'] != FLAG_OFF) continue;
	
	if (SFTP_FLG) {
		$ftpCnc = connectFTP("cms");
		if (ENABLE_OPTION_ADVERT) $ftpCgiCnc = connectFTP("click_cgi");
	}
	// ページ出力されていない公開中ページの場合
	if (isset($objPage->fld['output_html_flg']) && $objPage->fld['output_html_flg'] == FLAG_OFF) {
		// 外部連携自動出力用にテンプレートIDを保持
		if (!in_array($objPage->fld['template_id'], $_SESSION['template_id_of_output_page'])) {
			$_SESSION['template_id_of_output_page'][] = $objPage->fld['template_id'];
		}
		continue;
	}
	
	// HTML生成
	if (create_html($objPage->fld['page_id'], $objPage->fld['file_path'], $objCnc, $ftpCnc, $out_errmsg, false) === false) {
		DispError($out_errmsg, 2, "javascript:history.back()");
		exit();
	}
	if (SFTP_FLG && FTP_UPLOAD_FLG) {
		cx_ftp_close($ftpCnc);
		if (ENABLE_OPTION_ADVERT) cx_ftp_close($ftpCgiCnc);
	}
}

// 外部連携自動出力機能
if (ENABLE_OPTION_OUTPUT && count($_SESSION['template_id_of_output_page']) > 0) {
	$template_id_ary = $_SESSION['template_id_of_output_page'];
	$output_err_msg = "";
	if (!auto_upload_output($template_id_ary, $output_err_msg)) {
		// 外部連携自動出力用テンプレートID配列削除
		unset($_SESSION['template_id_of_output_page']);
		DispError($output_err_msg, 2, "javascript:history.back()");
		exit();
	}
}
// 外部連携自動出力用テンプレートID配列削除
unset($_SESSION['template_id_of_output_page']);

if (FTP_UPLOAD_FLG && !SFTP_FLG) {
	// FTP ストリームを閉じる
	cx_ftp_close($ftpCnc);
	if (ENABLE_OPTION_ADVERT) cx_ftp_close($ftpCgiCnc);
}

header("Location: " . $back);
exit();
?>
