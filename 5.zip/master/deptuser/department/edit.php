<?php
/*
 *
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/
//レヴェル
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


/** require **/
require ("./.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
/*--- 共通関数読み込み ---*/
require ("./include/common.inc");

/** init **/
$dat = array();
$aryTemp = array();
$temp_cbox = "";
$dir_list = "";
$outer = "";
$FAQanswer = "";
$output = "";
$auto_output = "";
$def_dir_display = 'none';
$def_outer_display = 'none';
$def_FAQanswer_display = 'none';
$def_output_display = 'none';
$back = "../index.php";

//main
if (isset($_POST["behavior"])) $bv = $_POST["behavior"];
else $bv = 1;
switch ($bv) {
	case 1 : // 新規登録
		$label = '組織情報追加';
		$image = '<img src="images/bar_add.jpg" alt="組織情報追加" width="920" height="30">';
		$dat = array(
				"dept_id" => "", 
				"level" => "", 
				"dept_code" => "", 
				"name" => "", 
				"dept_name" => "", 
				"tel" => "", 
				"fax" => "", 
				"email" => "", 
				'dept' => '', 
				'def_dir1' => '', 
				'address' => '', 
				'url' => ''
		);
		if (isset($_GET['back']) && $_GET['back'] == 1 && isset($_SESSION['hidden'])) {
			if (isset($_SESSION['hidden']['name'])) $dat['name'] = $_SESSION['hidden']['name'];
			if (isset($_SESSION['hidden']['address'])) $dat['address'] = $_SESSION['hidden']['address'];
			if (isset($_SESSION['hidden']['tel'])) $dat['tel'] = $_SESSION['hidden']['tel'];
			if (isset($_SESSION['hidden']['fax'])) $dat['fax'] = $_SESSION['hidden']['fax'];
			if (isset($_SESSION['hidden']['email'])) $dat['email'] = $_SESSION['hidden']['email'];
			if (isset($_SESSION['hidden']['url'])) $dat['url'] = $_SESSION['hidden']['url'];
			if (isset($_SESSION['hidden']['temp_id'])) $aryTemp = $_SESSION['hidden']['temp_id'];
			if (isset($_SESSION['hidden']['dir_list'])) $dir_list = $_SESSION['hidden']['dir_list'];
			if (isset($_SESSION['hidden']['dept_code'])) $dat['dept_code'] = $_SESSION['hidden']['dept_code'];
			elseif (isset($_SESSION['hidden']['cms_target2']) && $_SESSION['hidden']['cms_target2'] != "") $dat['dept_code'] = $_SESSION['hidden']['cms_target2'];
			elseif (isset($_SESSION['hidden']['cms_target1']) && $_SESSION['hidden']['cms_target1'] != "") $dat['dept_code'] = $_SESSION['hidden']['cms_target1'];
			if ($dat['dept_code'] != "") $iDept_h = getDeptCode($dat['dept_code']);
			if (isset($_SESSION['hidden']['dept'])) $dat['dept'] = $_SESSION['hidden']['dept'];
			if (isset($_SESSION['hidden']['def_dir1'])) $dat['def_dir1'] = $_SESSION['hidden']['def_dir1'];
			if (isset($_SESSION['hidden']['def_outer'])) $dat['def_outer'] = $_SESSION['hidden']['def_outer'];
			if (isset($_SESSION['hidden']['def_FAQanswer'])) $dat['def_FAQanswer'] = $_SESSION['hidden']['def_FAQanswer'];
		}
		//組織プルダウン生成
		$dept_s1 = '<select id="cms_target1" name="cms_target1" onChange="javascript:cxChangeDept(1, this.value)" style="width:150px;">';
		$dept_s2 = '<select id="cms_target2" name="cms_target2" onChange="javascript:cxChangeDept(2, this.value)" style="width:150px;">';
		$dept_opn = '<option value="" selected>----------------</option>';
		$dept_opd = '<option value="">指定なし</option>';
		$dept_ops = '<option value="" selected>指定なし</option>';
		$dept_op1 = '';
		$dept_op2 = '';
		$dept_e = '</select>&nbsp;&nbsp;';
		$sql = "SELECT dept_code, name FROM tbl_department WHERE level = 1" . " ORDER BY dept_code, sort_order, dept_id";
		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$sel = (isset($iDept_h) && ($iDept_h['dept1_code'] == $objDac->fld['dept_code'])) ? ' selected' : '';
			$dept_op1 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $sel . '>' . $objDac->fld['name'] . '</option>';
		}
		if (isset($iDept_h) && $iDept_h['level'] >= G_DEPT_LEVEL01) {
			$sql = "SELECT dept_code, name FROM tbl_department" . " WHERE level = 2 AND dept_code LIKE '" . $iDept_h['dept1'] . "%'" . " ORDER BY dept_code, sort_order, dept_id";
			$objDac->execute($sql);
			while ($objDac->fetch()) {
				$sel = ($iDept_h['dept2_code'] == $objDac->fld['dept_code']) ? ' selected' : '';
				$dept_op2 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $sel . '>' . $objDac->fld['name'] . '</option>';
			}
		}
		//
		$target1 = $dept_s1 . $dept_ops . $dept_op1 . $dept_e;
		$target2 = $dept_s2 . $dept_opn . $dept_op2 . $dept_e;
		$cms_target = $target1 . $target2;
		// 組織コードテキストボックス
		$box = '<input type="text" name="dept" id="dept" value="' . htmlspecialchars($dat['dept']) . '" size="5" maxlength="' . CODE_DIGIT_DEPT . '" class="no-ime">';
		$box_s1 = '<span id="code_box1">';
		$box_s2 = '<span id="code_box2">';
		$box_s3 = '<span id="code_box3">';
		$box_e = '</span>&nbsp;';
		if (isset($iDept_h) && $iDept_h['level'] == G_DEPT_LEVEL01) $code_box = $box_s1 . $iDept_h['dept1'] . $box_e . $box_s2 . $box . $box_e . $box_s3 . str_repeat("0", CODE_DIGIT_DEPT) . $box_e;
		elseif (isset($iDept_h) && $iDept_h['level'] == G_DEPT_LEVEL02) $code_box = $box_s1 . $iDept_h['dept1'] . $box_e . $box_s2 . $iDept_h['dept2'] . $box_e . $box_s3 . $box . $box_e;
		else $code_box = $box_s1 . $box . $box_e . $box_s2 . str_repeat("0", CODE_DIGIT_DEPT) . $box_e . $box_s3 . str_repeat("0", CODE_DIGIT_DEPT) . $box_e;
		// 初期ディレクトリの表示
		if (isset($iDept_h) && $iDept_h['level'] == G_DEPT_LEVEL02) {
			$def_dir_display = 'block';
			$def_outer_display = 'block';
			if (ENABLE_OPTION_FAQ) $def_FAQanswer_display = 'block';
			if (ENABLE_OPTION_OUTPUT) $def_output_display = 'block';
		}
		if (!isset($dat['def_outer']) || $dat['def_outer'] == FLAG_OFF) {
			$outer = '<input type="radio" id="cms_outer_y" name="def_outer" value="1"><label for="cms_outer_y">ON</label>';
			$outer .= '<input type="radio" id="cms_outer_n" name="def_outer" value="0" checked><label for="cms_outer_n">OFF</label>';
		}
		else {
			$outer = '<input type="radio" id="cms_outer_y" name="def_outer" value="1" checked><label for="cms_outer_y">ON</label>';
			$outer .= '<input type="radio" id="cms_outer_n" name="def_outer" value="0"><label for="cms_outer_n">OFF</label>';
		}
		// FAQ振分権限
		if (!isset($dat['def_FAQanswer']) || $dat['def_FAQanswer'] == FLAG_OFF) {
			$FAQanswer = '<input type="radio" id="cms_FAQanswer_y" name="def_FAQanswer" value="1"><label for="cms_FAQanswer_y">ON</label>';
			$FAQanswer .= '<input type="radio" id="cms_FAQanswer_n" name="def_FAQanswer" value="0" checked><label for="cms_FAQanswer_n">OFF</label>';
		}
		else {
			$FAQanswer = '<input type="radio" id="cms_FAQanswer_y" name="def_FAQanswer" value="1" checked><label for="cms_FAQanswer_y">ON</label>';
			$FAQanswer .= '<input type="radio" id="cms_FAQanswer_n" name="def_FAQanswer" value="0"><label for="cms_FAQanswer_n">OFF</label>';
		}
		$onLoad = ' onLoad="cxChangeClass();"';
		break;
	case 2 : // 更新
		if (!isset($_POST["dept_id"])) {
			DispError("パラメータ取得エラー(user_id)", 2, "javascript:history.back()");
			exit();
		}
		$label = '組織情報修正';
		$image = '<img src="images/bar_fix.jpg" alt="組織情報修正" width="920" height="30">';
		$sql = "SELECT d.*, h1.item2 AS def_dir1" . " FROM tbl_department AS d" . " LEFT JOIN tbl_handler AS h1 ON (h1.class = " . HANDLER_CLASS_DEF_DIR1 . " AND h1.item1 = d.dept_code)" . " WHERE d.dept_id = " . gd_addslashes($_POST["dept_id"]);
		$objDac->execute($sql);
		if (!$objDac->fetch()) {
			DispError("指定された組織情報が存在しません。", 2, "javascript:history.back()");
			exit();
		}
		$dat = $objDac->fld;
		$back .= "?dept_code=" . $dat['dept_code'];
		/*---組織名称の取得---*/
		$iDept = getDeptCode($dat['dept_code']);
		$DspDeptNm = "";
		//部
		$sql = "SELECT name FROM tbl_department" . " WHERE dept_code = '" . gd_addslashes($iDept['dept1_code']) . "'";
		$objDac->execute($sql);
		if ($objDac->fetch()) $DspDeptNm .= $objDac->fld['name'];
		// 課
		if ($iDept['level'] > G_DEPT_LEVEL01) {
			$sql = "SELECT name FROM tbl_department" . " WHERE dept_code = '" . gd_addslashes($iDept['dept2_code']) . "'";
			$objDac->execute($sql);
			if ($objDac->fetch()) $DspDeptNm .= " > " . $objDac->fld['name'];
		}
		// 係
		if ($iDept['level'] > G_DEPT_LEVEL02) {
			$sql = "SELECT name FROM tbl_department" . " WHERE dept_code = '" . gd_addslashes($iDept['dept3_code']) . "'";
			$objDac->execute($sql);
			if ($objDac->fetch()) $DspDeptNm .= " > " . $objDac->fld['name'];
		}
		/*---テンプレート一覧の取得---*/
		$sql = "SELECT item2 FROM tbl_handler" . " WHERE class = " . HANDLER_CLASS_TEMPLATE . " AND item1 = '" . gd_addslashes($dat['dept_code']) . "'";
		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$aryTemp[] = $objDac->fld['item2'];
		}
		/*---ディレクトリ一覧の取得---*/
		$sql = "SELECT item2 FROM tbl_handler" . " WHERE class = " . HANDLER_CLASS_DIRECTORY . " AND item1 = '" . gd_addslashes($dat['dept_code']) . "'";
		$objDac->execute($sql);
		$objDac->fetchrow = 0;
		$dir_list_ary = array();
		while ($objDac->fetch()) {
			$dir_list_ary[] = $objDac->fld['item2'];
		}
		$dir_list_ary = array_unique($dir_list_ary);
		natsort($dir_list_ary);
		if (count($dir_list_ary) > 0) {
			//表示用ディレクトリ一覧取得
			$dir_list_ary = get_disp_dir($dir_list_ary);
			if ($dir_list_ary === FALSE) {
				DispError("フォルダ一覧の取得に失敗しました。", 2, "javascript:history.back()");
				exit();
			}
		}
		$dir_list = implode("\n", $dir_list_ary);
		
		// 初期ディレクトリの表示
		if ($iDept['level'] == G_DEPT_LEVEL03) $def_dir_display = 'block';
		// 外部ファイル取り込み権限
		if ($iDept['level'] == G_DEPT_LEVEL03) {
			$def_outer_display = 'block';
			$where = "class = " . HANDLER_CLASS_OUTER_IMPORT . " AND item1 = '" . gd_addslashes($dat['dept_code']) . "'";
			$objDac->setTableName("tbl_handler");
			$objDac->select($where);
			if ($objDac->getRowCount() == 0) {
				$outer = '<input type="radio" id="cms_outer_y" name="def_outer" value="1"><label for="cms_outer_y">許可する</label>';
				$outer .= '<input type="radio" id="cms_outer_n" name="def_outer" value="0" checked><label for="cms_outer_n">許可しない</label>';
			}
			else {
				$outer = '<input type="radio" id="cms_outer_y" name="def_outer" value="1" checked><label for="cms_outer_y">許可する</label>';
				$outer .= '<input type="radio" id="cms_outer_n" name="def_outer" value="0"><label for="cms_outer_n">許可しない</label>';
			}
		}
		// FAQ振分権限
		if ($iDept['level'] == G_DEPT_LEVEL03) {
			if (ENABLE_OPTION_FAQ) $def_FAQanswer_display = 'block';
			if (ENABLE_OPTION_OUTPUT) $def_output_display = 'block';
			$where = "class = " . HANDLER_CLASS_FAQ_ANSWER . " AND item1 = '" . gd_addslashes($dat['dept_code']) . "'";
			$objDac->setTableName("tbl_handler");
			$objDac->select($where);
			if ($objDac->getRowCount() == 0) {
				$FAQanswer = '<input type="radio" id="cms_FAQanswer_y" name="def_FAQanswer" value="1"><label for="cms_FAQanswer_y">許可する</label>';
				$FAQanswer .= '<input type="radio" id="cms_FAQanswer_n" name="def_FAQanswer" value="0" checked><label for="cms_FAQanswer_n">許可しない</label>';
			}
			else {
				$FAQanswer = '<input type="radio" id="cms_FAQanswer_y" name="def_FAQanswer" value="1" checked><label for="cms_FAQanswer_y">許可する</label>';
				$FAQanswer .= '<input type="radio" id="cms_FAQanswer_n" name="def_FAQanswer" value="0"><label for="cms_FAQanswer_n">許可しない</label>';
			}
		}
		break;
	default :
		DispError("パラメータエラー（behavior）", 2, "javascript:history.back()");
		exit();
		break;
}
unset($_SESSION['hidden']);

// テンプレートのチェックボックスを生成
$sql = "SELECT t.template_id, t.name FROM tbl_template AS t" . " WHERE t.template_ver=(SELECT MAX(t2.template_ver) FROM tbl_template t2 WHERE t.template_id=t2.template_id)" . " ORDER BY t.sort_order, t.template_id";
$objDac->execute($sql);
while ($objDac->fetch()) {
	$id = $objDac->fld['template_id'];
	if ($id == TEMPLATE_ID_NONE) continue;
	$name = $objDac->fld['name'];
	$temp_ary[$id] = $name;
}

$temp_cbox = mkcheckbox($temp_ary, "temp_id", $aryTemp, 2, '', '', true);

$ck_op_ary = array();
$ck_auto_op_ary = array();
$sel_op_ary = array();
$op_ary = getOutput();
foreach ($op_ary as $op_fld) {
	if (isset($op_fld['output_kind']) && $op_fld['output_kind'] == OUTPUT_KIND_AUTO) {
		// 外部連携自動出力形式項目ID取得
		$ck_auto_op_ary[$op_fld['output_id']] = $op_fld['name'];
	}
	else {
		// 外部連携手動出力形式項目ID取得
		$ck_op_ary[$op_fld['output_id']] = $op_fld['name'];
	}
}
if (isset($dat['dept_code'])) {
	$ophndl_ary = getOutputTemplateFromDeptCode($dat['dept_code']);
	foreach ($ophndl_ary as $ophndl_fld) {
		$sel_op_ary[] = $ophndl_fld['output_id'];
	}
}
if (count($ck_op_ary) > 0) {
	$output = mkcheckbox($ck_op_ary, "output_id", $sel_op_ary, 2, '', '', true);
}
if (count($ck_auto_op_ary) > 0) {
	$auto_output = mkcheckbox($ck_auto_op_ary, "output_id", $sel_op_ary, 2, '', '', true);
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$label?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="department.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
var code_zero = '<?=str_repeat("0", CODE_DIGIT_DEPT)?>';
var code_box = '<input type="text" name="dept" id="dept" value="" size="5" maxlength="<?=CODE_DIGIT_DEPT?>" class="no-ime">';
var enable_faq_flg = <?=(ENABLE_OPTION_FAQ) ? FLAG_ON : FLAG_OFF?>;
var enable_output_flg = <?=(ENABLE_OPTION_OUTPUT) ? FLAG_ON : FLAG_OFF?>;
//-->
</script>
<script src="./js/edit.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'deptuser';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-approve">
<div><?=$image?></div>
<div class="cms8341-area-corner">
<form id="form" class="cms8341-form" name="form" method="post"
	action="confirm.php"><?php
	if ($bv == 2) {
		?>
<p align="left" id="cms8341-pankuzu"><?=$DspDeptNm?></p>
<input type="hidden" name="dept_code"
	value="<?=htmlspecialchars($dat['dept_code'])?>">
<?php
	}
	?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable"><?php
	if ($bv == 1) {
		?>
<tr>
		<th align="left" valign="middle" scope="row">上階層組織 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=$cms_target?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">組織コード <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=$code_box?></td>
	</tr><?php
	}
	else {
		?>
<tr>
		<th align="left" valign="top" scope="row">組織コード</th>
		<td align="left" valign="top"><?=$dat['dept_code']?></td>
	</tr><?php
	}
	?>
<tr>
		<th width="230" align="left" valign="middle" scope="row">組織名 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><input id="name" name="name" type="text"
			style="width: 400px" value="<?=htmlspecialchars($dat['name'])?>"></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">住所</th>
		<td align="left" valign="top"><input id="address" name="address"
			type="text" style="width: 400px"
			value="<?=htmlspecialchars($dat['address'])?>"></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">電話番号</th>
		<td align="left" valign="top"><input id="tel" name="tel" type="text"
			style="width: 400px" value="<?=htmlspecialchars($dat['tel'])?>"></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">FAX番号</th>
		<td align="left" valign="top"><input id="fax" name="fax" type="text"
			style="width: 400px" value="<?=htmlspecialchars($dat['fax'])?>"></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">メールアドレス</th>
		<td align="left" valign="top"><input id="email" name="email"
			type="text" style="width: 400px"
			value="<?=htmlspecialchars($dat['email'])?>" class="no-ime"></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">URL</th>
		<td align="left" valign="top"><input id="url" name="url" type="text"
			style="width: 400px" value="<?=htmlspecialchars($dat['url'])?>"
			class="no-ime"></td>
	</tr>
<?php
if ($bv == 1 || $iDept['level'] == G_DEPT_LEVEL03) { /*--- 2007-09-10 M.Takano Upd Start */	?>
<tr id="tr_def_outer" style="display:<?=$def_outer_display?>">
		<th align="left" valign="middle" scope="row">外部ファイル取り込み権限<br>
		<span class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=$outer?></td>
	</tr>
	<tr id="tr_def_FAQanswer" style="display:<?=$def_FAQanswer_display?>">
		<th align="left" valign="middle" scope="row">FAQ振分権限 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=$FAQanswer?></td>
	</tr>
	<tr id="tr_def_output" style="display:<?=$def_output_display?>">
		<th align="left" valign="middle" scope="row">外部データ連携権限</th>
		<td align="left" valign="top">
<?php
	if ($output != "" || $auto_output != "") {
		?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable">
<?php
		if ($output != "") {
			?>
<tr>
				<th align="left" valign="middle" scope="row" width="20%">手動出力</th>
				<td align="left" valign="top"><?=$output?></td>
			</tr>
<?php
		}
		?>
<?php

		if ($auto_output != "") {
			?>
<tr>
				<th align="left" valign="middle" scope="row" width="20%">自動出力</th>
				<td align="left" valign="top"><?=$auto_output?></td>
			</tr>
<?php
		}
		?>
</table>
<?php
	}
	?>
</td>
	</tr>
	<tr id="tr_def_dir1" style="display:<?=$def_dir_display?>">
		<th align="left" valign="middle" scope="row">通常ページ初期フォルダ</th>
		<td align="left" valign="top"><input id="def_dir1" name="def_dir1"
			type="text" style="width: 400px"
			value="<?=htmlspecialchars($dat['def_dir1'])?>" class="no-ime"></td>
	</tr>
<?php
} /*--- 2007-09-10 M.Takano Upd End */?>
<tr>
		<th align="left" valign="middle" scope="row">テンプレート一覧</th>
		<td align="left" valign="top">
		<p><a href="javascript:" onClick="return cxCheckAll();"><img
			src="<?=RPW?>/admin/images/upload/btn_allselect.jpg" alt="全て選択する"
			width="120" height="20" border="0"></a> <a href="javascript:"
			onClick="return cxReleaseAll();"><img
			src="<?=RPW?>/admin/images/upload/btn_allcansel.jpg" alt="全て解除する"
			width="120" height="20" hspace="20" border="0"></a></p>
<?=$temp_cbox?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">フォルダ一覧</th>
		<td align="left" valign="top"><textarea id="dir_list" name="dir_list"
			cols="50" rows="5"><?=htmlspecialchars($dir_list)?></textarea></td>
	</tr>
<?php
if ($bv == 2) {
	?>
<tr>
		<th width="150" align="left" valign="top" scope="row">公開設定</th>
		<td align="left" valign="middle"><input type="checkbox" id="public"
			name="public" value="1"><label for="public">即公開する</label></td>
	</tr>
<?php
}
?>
</table>
<p align="center"><input type="image"
	src="<?=RPW?>/admin/master/images/btn_conf.jpg" alt="確認" width="150"
	height="20" border="0" style="margin-right: 10px"> <a href="<?=$back?>"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px"></a></p>
<input type="hidden" name="behavior" value="<?=$bv?>"> <input
	type="hidden" name="dept_id" value="<?=$dat['dept_id']?>"></form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
