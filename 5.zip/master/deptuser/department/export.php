<?php
/*
 * 組織テーブルの情報をエクスポートする
 */
//設定ファイル読み込み
require ("./.htsetting");
require ("./include/common.inc");

//データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
$objDac2 = new dac($objCnc);

//定数 
//見出し文字
$G_SetHead = array(
		"組織コード1", 
		"組織コード2", 
		"組織コード3", 
		"組織名", 
		"問い合せ先TEL", 
		"問い合せ先FAX", 
		"問い合せ先Eメール", 
		"問い合せ先住所", 
		"問い合せ先URL", 
		"表示順", 
		"通常ページ初期フォルダ", 
		"権限のあるテンプレートID1", 
		"権限のあるテンプレートID2", 
		"権限のあるテンプレートID3", 
		"権限のあるテンプレートID4", 
		"権限のあるテンプレートID5", 
		"権限のあるテンプレートID6", 
		"権限のあるテンプレートID7", 
		"権限のあるテンプレートID8", 
		"権限のあるテンプレートID9", 
		"権限のあるテンプレートID10", 
		"権限のあるテンプレートID11", 
		"権限のあるテンプレートID12", 
		"権限のあるテンプレートID13", 
		"権限のあるテンプレートID14", 
		"権限のあるテンプレートID15", 
		"権限のあるテンプレートID16", 
		"権限のあるテンプレートID17", 
		"権限のあるテンプレートID18", 
		"権限のあるテンプレートID19", 
		"権限のあるテンプレートID20", 
		"権限のあるテンプレートID21", 
		"権限のあるテンプレートID22", 
		"権限のあるテンプレートID23", 
		"権限のあるテンプレートID24", 
		"権限のあるテンプレートID25", 
		"権限のあるテンプレートID26", 
		"権限のあるテンプレートID27", 
		"権限のあるテンプレートID28", 
		"権限のあるテンプレートID29", 
		"権限のあるテンプレートID30"
);
//tbl_handler項目数
define("MAX_ROW_CNT_TEMPLATE", 30); //テンプレート項目の最大列数
define("MIN_ROW_CNT_DIRECTORY", 5); //ディレクトリ項目の最少列数（見出しのための制限）


//tbl_departmentとtbl_handlerの取得
$sql = "SELECT d.*, h1.item2 AS def_dir1 FROM tbl_department AS d LEFT JOIN tbl_handler AS h1 ON (h1.class = " . HANDLER_CLASS_DEF_DIR1 . " AND h1.item1 = d.dept_code) ORDER BY d.dept_code, d.level, d.dept_id";
$objDac->execute($sql);
if ($objDac->getRowCount() <= 0) {
	DispError("組織情報が一件も登録されていません。", 2, "javascript:history.back()");
	exit();
}
//組織情報の作成
$ExpCavData = array();
$max_dir_cnt = 0;
$CsvLine = 0;
while ($objDac->fetch()) {
	$tmp_cnt = 0;
	$dir_cnt = 0;
	$dir_list_ary = array();
	$list = array();
	$dir_temp = array();
	
	$ExpCavData[$CsvLine][] = substr($objDac->fld['dept_code'], 0, CODE_DIGIT_DEPT); //組織コード1(部)
	$ExpCavData[$CsvLine][] = substr($objDac->fld['dept_code'], CODE_DIGIT_DEPT, CODE_DIGIT_DEPT); //組織コード2(課)
	$ExpCavData[$CsvLine][] = substr($objDac->fld['dept_code'], (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), CODE_DIGIT_DEPT); //組織コード3(係)
	$ExpCavData[$CsvLine][] = $objDac->fld['name']; //組織名
	$ExpCavData[$CsvLine][] = $objDac->fld['tel']; //問い合せ先TEL
	$ExpCavData[$CsvLine][] = $objDac->fld['fax']; //問い合せ先FAX
	$ExpCavData[$CsvLine][] = $objDac->fld['email']; //問い合せ先Eメール
	$ExpCavData[$CsvLine][] = $objDac->fld['address']; //問い合せ先住所
	$ExpCavData[$CsvLine][] = $objDac->fld['url']; //問い合せ先URL
	$ExpCavData[$CsvLine][] = $objDac->fld['sort_order']; //表示順
	$ExpCavData[$CsvLine][] = $objDac->fld['def_dir1']; //通常ページ初期ディレクトリ
	

	$sql = "SELECT class, item2 FROM tbl_handler WHERE class IN (" . HANDLER_CLASS_DIRECTORY . ", " . HANDLER_CLASS_TEMPLATE . ") AND item1 = '" . gd_addslashes($objDac->fld['dept_code']) . "' ORDER BY class DESC, item2";
	$objDac2->execute($sql);
	while ($objDac2->fetch()) {
		//テンプレート項目
		if ($objDac2->fld['class'] == HANDLER_CLASS_TEMPLATE) {
			//制限数より多い登録は飛ばす
			if ($tmp_cnt >= MAX_ROW_CNT_TEMPLATE) continue;
			$ExpCavData[$CsvLine][] = $objDac2->fld['item2'];
			$tmp_cnt++;
		} //ディレクトリ項目
		else if ($objDac2->fld['class'] == HANDLER_CLASS_DIRECTORY) {
			//ディレクトリ項目最初のとき：テンプレート項目分の列を埋める
			if ($dir_cnt == 0) {
				for($i = 0; $i < (MAX_ROW_CNT_TEMPLATE - $tmp_cnt); $i++) {
					$ExpCavData[$CsvLine][] = "";
				}
			}
			
			$dir_temp[] = $objDac2->fld['item2'];
			if (preg_match("/\/\*\/?$/", $objDac2->fld['item2'])) {
				$dir = preg_replace("/\/\*\/?$/", "", $objDac2->fld['item2']);
				
				$dir_list_ary[] = $dir . "/";
				
				$directory_list = make_dirtree($dir);
				if ($directory_list === FALSE) {
					DispError("ディレクトリ情報の取得に失敗しました。", 2, "javascript:history.back()");
					exit();
				}
				
				$dir_list = array();
				get_dirlist($dir_list, $directory_list);
				$dir_list_ary[] = $dir_list;
			}
			
			$dir_cnt++;
		}
	}
	
	//「*」ワイルドカードの対象となるディレクトリ一覧取得
	foreach ((array) $dir_list_ary as $dir_list) {
		foreach ((array) $dir_list as $dir) {
			$list[] = $dir;
		}
	}
	//重複パスの削除
	$dir_list = array_unique($list);
	
	$dir_cnt = 0;
	foreach ((array) $dir_temp as $dir) {
		if (in_array($dir, $dir_list)) {
			continue;
		}
		
		$ExpCavData[$CsvLine][] = $dir;
		$dir_cnt++;
	}
	
	//ディレクトリ項目の最大数をセットする
	if ($dir_cnt > $max_dir_cnt) $max_dir_cnt = $dir_cnt;
	$CsvLine++;
}
//見出しのディレクトリ項目数は少なくともMIN_ROW_CNT_DIRECTORY以上とする
if ($max_dir_cnt < MIN_ROW_CNT_DIRECTORY) $max_dir_cnt = MIN_ROW_CNT_DIRECTORY;
//見出し行にディレクトリ分の項目を追加
for($idx = 1; $idx <= $max_dir_cnt; $idx++) {
	$G_SetHead[] = "権限のあるフォルダ" . $idx;
}

//出力処理
create_Csv("department.csv", $ExpCavData, $G_SetHead, 0, "", "sjis-win", "\"");
?>
