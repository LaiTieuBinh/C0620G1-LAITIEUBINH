/*
 *
 */
//通信失敗処理
function cxFailure() {
	alert('情報取得中に通信エラーが発生しました');
}
//
function cxChangeDept(lv, target, val) {
	//reset
	if(target=="1"){
		target_str = '_before_';
	}else{
		target_str = '_after_';
	}
	if(val=="") {
		var t = lv + 1;
		for(var i=t;i<=3;i++) {
			var obj = $('cms_target'+target_str+i);
			while(obj.length>1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "----------------";
		}
	} else {
		//get data
		lv++;
		var prm = 'level='+lv+'&code='+val;
		if(target=="1"){
			cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK_Before);
		}else{
			cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK_After);
		}
	}
}

function cxGetDeptComboOK_Before(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Department') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    var code = xmlDoc.attributes.getNamedItem('code').value;
    for (var i = level; i <= 3; i++) {
        var obj = $('cms_target_before_' + i);
        while (obj.length > 1) {
            obj.options[1] = null;
        }
        if (i == level) {
            obj.options[0].text = "指定なし";
        } else {
            obj.options[0].text = "----------------";
        }
    }
    if (level < 4) {
        var obj = $('cms_target_before_' + level);
        var xmlDocfix = xmlDoc.childElementCount;
        for (var i=0; i<xmlDocfix; i++) {
            nodeL = xmlDoc.firstElementChild;
            obj.length++;
            obj.options[i+1].text = nodeL.textContent;
            var val = nodeL.attributes.getNamedItem('value').value;
            obj.options[i+1].value = val;
            xmlDoc.removeChild(xmlDoc.firstElementChild);
        }
    }
}

function cxGetDeptComboOK_After(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Department') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    var code = xmlDoc.attributes.getNamedItem('code').value;
    for (var i = level; i <= 3; i++) {
        var obj = $('cms_target_after_' + i);
        while (obj.length > 1) {
            obj.options[1] = null;
        }
        if (i == level) {
            obj.options[0].text = "指定なし";
        } else {
            obj.options[0].text = "----------------";
        }
    }
    if (level < 4) {
        var obj = $('cms_target_after_' + level);
        var xmlDocfix = xmlDoc.childElementCount;
        for (var i=0; i<xmlDocfix; i++) {
            nodeL = xmlDoc.firstElementChild;
            obj.length++;
            obj.options[i+1].text = nodeL.textContent;
            var val = nodeL.attributes.getNamedItem('value').value;
            obj.options[i+1].value = val;
            xmlDoc.removeChild(xmlDoc.firstElementChild);
        }
    }
}
