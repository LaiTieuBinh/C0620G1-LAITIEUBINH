/*
 *
 */
//通信失敗処理
function cxFailure() {
	alert('情報取得中に通信エラーが発生しました');
}
//
function cxChangeDept(lv, val) {
//--- 2007-09-10 M.Takano Upd Start
	if (lv == 2 && val != '') {	//初期ディレクトリの表示
		if (enable_faq_flg == FLAG_ON) $('tr_def_FAQanswer').style.display = 'block';
		$('tr_def_outer').style.display = 'block';
		$('tr_def_dir1').style.display = 'block';
		if (enable_output_flg == FLAG_ON) $('tr_def_output').style.display = 'block';
	} else {		//初期ディレクトリの非表示
		if (enable_faq_flg == FLAG_ON) $('tr_def_FAQanswer').style.display = 'none';
		$('tr_def_outer').style.display = 'none';
		$('tr_def_dir1').style.display = 'none';
		if (enable_output_flg == FLAG_ON) $('tr_def_output').style.display = 'none';
	}
//--- 2007-09-10 M.Takano Upd End
	//reset
	if(val=="") {
		var t = lv + 1;
		for(var i=t;i<=2;i++) {
			var obj = $('cms_target'+i);
			while(obj.length>1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "----------------";
			$('code_box'+i).innerHTML = code_zero;
		}
		$('code_box3').innerHTML = code_zero;
		$('code_box'+lv).innerHTML = code_box;
	} else {
		//get data
		lv++;
		var prm = 'level='+lv+'&code='+val;
		cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
	}
}
function cxGetDeptComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Department') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    var code = xmlDoc.attributes.getNamedItem('code').value;
    for (var i = level; i <= 2; i++) {
        var obj = $('cms_target' + i);
        while (obj.length > 1) {
            obj.options[1] = null;
        }
        if (i == level) {
            obj.options[0].text = "指定なし";
        } else {
            obj.options[0].text = "----------------";
        }
        $('code_box' + i).innerHTML = code_zero;
    }
    $('code_box3').innerHTML = code_zero;
    if (level < 3) {
        var obj = $('cms_target' + level);
        var xmlDocfix = xmlDoc.childElementCount;
        for (var i=0; i<xmlDocfix; i++) {
            nodeL = xmlDoc.firstElementChild;
            obj.length++;
            obj.options[i+1].text = nodeL.textContent;
            var val = nodeL.attributes.getNamedItem('value').value;
            obj.options[i+1].value = val;
            xmlDoc.removeChild(xmlDoc.firstElementChild);
        }
    }
    $('code_box' + (level - 1)).innerHTML = code;
    $('code_box' + level).innerHTML = code_box;
}
function cxCheckAll() {
	var alElem = document['form']['temp_id[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = true;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = true;
			}
		}
	}
}
function cxReleaseAll() {
	var alElem = document['form']['temp_id[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = false;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = false;
			}
		}
	}
}
