<?php
/*
 *
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/
//レヴェル
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


/** require **/
require ("./.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

if ((!isset($_GET['bak']) || $_GET['bak'] != 1) && isset($_SESSION['chg_inq'])) {
	unset($_SESSION['chg_inq']);
}
/** init **/
$label = '問い合わせ先変更';
$image = '<img src="images/bar_chg_inquiry.jpg" alt="問い合わせ先変更" width="920" height="30">';
$back = "index.php";

//対象項目生成(変更対象の組織)
$dept_code = array();
$dept_code['cms_target_before_1'] = (isset($_SESSION['chg_inq']['target_before_1']) ? $_SESSION['chg_inq']['target_before_1'] : "");
$dept_code['cms_target_before_2'] = (isset($_SESSION['chg_inq']['target_before_2']) ? $_SESSION['chg_inq']['target_before_2'] : "");
$dept_code['cms_target_before_3'] = (isset($_SESSION['chg_inq']['target_before_3']) ? $_SESSION['chg_inq']['target_before_3'] : "");

$cms_target_b = create_dept_list("cms_target_before_", $dept_code, "150", array(), 1);

//対象項目生成(変更後の組織)
$dept_code = array();
$dept_code['cms_target_after_1'] = (isset($_SESSION['chg_inq']['target_after_1']) ? $_SESSION['chg_inq']['target_after_1'] : "");
$dept_code['cms_target_after_2'] = (isset($_SESSION['chg_inq']['target_after_2']) ? $_SESSION['chg_inq']['target_after_2'] : "");
$dept_code['cms_target_after_3'] = (isset($_SESSION['chg_inq']['target_after_3']) ? $_SESSION['chg_inq']['target_after_3'] : "");

$cms_target_a = create_dept_list("cms_target_after_", $dept_code, "150", array(), 2);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$label?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="department.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
var code_zero = '<?=str_repeat("0", CODE_DIGIT_DEPT)?>';
var code_box = '<input type="text" name="dept" id="dept" value="" size="5" maxlength="<?=CODE_DIGIT_DEPT?>" class="no-ime">';
//-->
</script>
<script src="./js/chg_inquiry.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'deptuser';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-approve">
<div><?=$image?></div>
<div class="cms8341-area-corner">
<p>ページの問い合わせ先を一括で変更します。<br>
※問い合わせ先の変更対象となる情報は「組織名」「住所」「電話番号」「ファックス番号」「メールアドレス」「URL」です。</p>
<form id="form" class="cms8341-form" name="form" method="post"
	action="chg_inquiry_conf.php">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="left" valign="middle" scope="row">変更対象の組織 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=$cms_target_b?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">変更後の組織 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=$cms_target_a?></td>
	</tr>
</table>
<p align="center"><input type="image"
	src="<?=RPW?>/admin/master/images/btn_conf.jpg" alt="確認" width="150"
	height="20" border="0" style="margin-right: 10px"> <a href="<?=$back?>"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px"></a></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
<?php

function create_dept_list($name, $selectValue, $width, $disabled, $target) {
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
	$objDac = new dac($objCnc);
	
	$disabled[$name . '1'] = (!isset($disabled[$name . '1']) ? "" : " " . trim($disabled[$name . '1']));
	$disabled[$name . '2'] = (!isset($disabled[$name . '2']) ? "" : " " . trim($disabled[$name . '2']));
	$disabled[$name . '3'] = (!isset($disabled[$name . '3']) ? "" : " " . trim($disabled[$name . '3']));
	
	$dept_s1 = '<select id="' . $name . '1" name="' . $name . '1" onChange="javascript:cxChangeDept(1,' . $target . ' ,this.value)" style="width:' . $width . 'px;"' . $disabled[$name . '1'] . '>' . "\n";
	$dept_s2 = '<select id="' . $name . '2" name="' . $name . '2" onChange="javascript:cxChangeDept(2,' . $target . ' ,this.value)" style="width:' . $width . 'px;"' . $disabled[$name . '2'] . '>' . "\n";
	$dept_s3 = '<select id="' . $name . '3" name="' . $name . '3" onChange="javascript:cxChangeDept(3,' . $target . ' ,this.value)" style="width:' . $width . 'px;"' . $disabled[$name . '3'] . '>' . "\n";
	$dept_opn = '<option value="">指定なし</option>' . "\n";
	$dept_e = '</select>&nbsp;&nbsp;';
	$dept_op1 = $dept_opn;
	$dept_op2 = $dept_opn;
	$dept_op3 = $dept_opn;
	$dept_def = $dept_opn;
	// 第一組織プルダウンの生成
	$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level=1 ORDER BY sort_order, dept_code";
	$objDac->execute($sql);
	while ($objDac->fetch()) {
		$selected = ($objDac->fld['dept_code'] == $selectValue[$name . '1']) ? ' selected' : '';
		$dept_op1 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
		$dept_def .= '<option value="' . $objDac->fld['dept_code'] . '">' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
	}
	// 第二組織プルダウンの生成（第一組織が指定されている場合）
	if ($selectValue[$name . '1'] != '') {
		$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level=2 AND dept_code REGEXP '^" . substr($selectValue[$name . '1'], 0, CODE_DIGIT_DEPT) . "' ORDER BY sort_order, dept_code";
		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$selected = ($objDac->fld['dept_code'] == $selectValue[$name . '2']) ? ' selected' : '';
			$dept_op2 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
		}
	}
	// 第三組織プルダウンの生成（第二組織が指定されている場合）
	if ($selectValue[$name . '2'] != '') {
		$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level=3 AND dept_code REGEXP '^" . substr($selectValue[$name . '2'], 0, (CODE_DIGIT_DEPT * 2)) . "' ORDER BY sort_order, dept_code";
		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$selected = ($objDac->fld['dept_code'] == $selectValue[$name . '3']) ? ' selected' : '';
			$dept_op3 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
		}
	}
	$target1 = $dept_s1 . $dept_op1 . $dept_e;
	$target2 = $dept_s2 . $dept_op2 . $dept_e;
	$target3 = $dept_s3 . $dept_op3 . $dept_e;
	$targetDef = '<div id="' . $name . '_def" style="display:none">' . $dept_def . '</div>';
	$combo_dept = $target1 . $target2 . $target3 . $targetDef;
	return $combo_dept;
}

?>