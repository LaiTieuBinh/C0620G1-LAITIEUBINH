<?php
/*
 * 組織管理管理　詳細画面(detail.php)
 */
$GLOBALS["StrDbg"] = "";

/*---------------------------------------------
	定数 
----------------------------------------------*/

//レヴェル
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


/*---------------------------------------------------------------------------------
	detail.php
---------------------------------------------------------------------------------*/

/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");
/*--- 共通関数読み込み ---*/
require ("./include/common.inc");

/*---引数の取得---*/
$args = ($_SERVER['REQUEST_METHOD'] == 'GET') ? $_GET : $_POST;
//表示レベル
if (isset($args["dept_id"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", 2, "javascript:history.back()");
	exit();
}
if (isset($args["level"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", 2, "javascript:history.back()");
	exit();
}
if (isset($args["dept_code"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", 2, "javascript:history.back()");
	exit();
}

/*--- データアクセスクラス ---*/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output.inc');
$objDac = new dac($objCnc);
$objTmp = new dac($objCnc);
$objOp = new tbl_output($objCnc);

/*--- 指定された組織情報の取得---*/
$sql = "SELECT d.*, h1.item2 AS def_dir1" . " FROM tbl_department AS d" . " LEFT JOIN tbl_handler AS h1 ON (h1.class = " . HANDLER_CLASS_DEF_DIR1 . " AND h1.item1 = d.dept_code)" . " WHERE d.dept_id = " . gd_addslashes($args["dept_id"]);

//取得
$objDac->execute($sql);
if ($objDac->getRowCount() <= 0) {
	DispError("指定された組織情報が存在しません。", 2, "javascript:history.back()");
	exit();
}
else {
	while ($objDac->fetch()) {
		$DspDeptCode = $objDac->fld['dept_code'];
		$DspDeptNm = $objDac->fld['name'];
		$DspDeptTel = $objDac->fld['tel'];
		$DspDeptFax = $objDac->fld['fax'];
		$DspDeptEm = $objDac->fld['email'];
		$DeptLevel = $objDac->fld['level'];
		$DspDefDir1 = $objDac->fld['def_dir1'];
		$DspDeptUrl = $objDac->fld['url'];
		$DspDeptAddress = $objDac->fld['address'];
	}
}

/*---組織名称の取得---*/
$DspDeptName = "";
$dept_01 = substr($DspDeptCode, 0, CODE_DIGIT_DEPT); //組織コード１の切り出し
$dept_01 = str_pad($dept_01, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
switch ($DeptLevel) {
	case G_DEPT_LEVEL01 : //部
		$DspDeptName = htmlspecialchars($DspDeptNm);
		break;
	case G_DEPT_LEVEL02 : //課
		$sql = "SELECT tbl_department.dept_code, tbl_department.name " . "FROM tbl_department " . "WHERE (((tbl_department.dept_code)='" . $dept_01 . "'))" . "ORDER BY tbl_department.dept_code";
		//取得
		$objDac->execute($sql);
		//部 + 課
		while ($objDac->fetch()) {
			$DspDeptName = htmlspecialchars($objDac->fld['name']) . " &gt; " . htmlspecialchars($DspDeptNm);
		}
		break;
	case G_DEPT_LEVEL03 : //係
		$dept_02 = substr($DspDeptCode, 0, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT)); //組織コード2の切り出し
		$dept_02 = str_pad($dept_02, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
		$sql = "SELECT tbl_department.dept_code, tbl_department.name as dept_nm01, tbl_department_1.dept_code, tbl_department_1.name as dept_nm02 " . "FROM tbl_department, tbl_department AS tbl_department_1 " . "WHERE (((tbl_department.dept_code)='" . $dept_01 . "') AND ((tbl_department_1.dept_code)='" . $dept_02 . "'))";
		"ORDER BY tbl_department.dept_code";
		//取得
		$objDac->execute($sql);
		//部 + 課 + 係
		while ($objDac->fetch()) {
			$DspDeptName = htmlspecialchars($objDac->fld['dept_nm01']) . " &gt; " . htmlspecialchars($objDac->fld['dept_nm02']) . " &gt; " . htmlspecialchars($DspDeptNm);
		}
		$where = "class = " . HANDLER_CLASS_OUTER_IMPORT . " AND item1 = '" . gd_addslashes($DspDeptCode) . "'";
		$objDac->setTableName("tbl_handler");
		$objDac->select($where);
		if ($objDac->getRowCount() == 0) {
			$DspDefOuter = "許可しない";
		}
		else {
			$DspDefOuter = "許可する";
		}
		$where = "class = " . HANDLER_CLASS_FAQ_ANSWER . " AND item1 = '" . gd_addslashes($DspDeptCode) . "'";
		$objDac->setTableName("tbl_handler");
		$objDac->select($where);
		if ($objDac->getRowCount() == 0) {
			$DspDefFAQAnswer = "許可しない";
		}
		else {
			$DspDefFAQAnswer = "許可する";
		}
		
		$output = "";
		$auto_output = "";
		$ophndl_ary = getOutputTemplateFromDeptCode($DspDeptCode);
		foreach ($ophndl_ary as $ophndl_fld) {
			$op_fld = getOutput($ophndl_fld['output_id']);
			if (isset($op_fld['output_kind']) && $op_fld['output_kind'] == OUTPUT_KIND_AUTO) {
				// 外部連携自動出力形式表示用文字列作成
				$auto_output .= htmlDisplay($op_fld['name']) . "<br>";
			}
			else {
				// 外部連携手動出力形式表示用文字列作成
				$output .= htmlDisplay($op_fld['name']) . "<br>";
			}
		}
		
		break;
}

// テンプレートのチェックボックスを生成
$DspLstTmp = "";
$fields = "t.template_id, t.name";
$objDac->setTableName("tbl_template AS t INNER JOIN tbl_handler AS h ON (t.template_id = h.item2)");
$where = "t.template_ver=(SELECT MAX(t2.template_ver) FROM tbl_template t2 WHERE t.template_id=t2.template_id)";
$where .= " AND " . $objDac->_addslashesC("h.class", HANDLER_CLASS_TEMPLATE);
$where .= " AND " . $objDac->_addslashesC("h.item1", $DspDeptCode);
$where .= "GROUP BY t.template_id,t.name";
$orderBy = "t.sort_order, t.template_id";
$objDac->select($where, $fields, $orderBy);
while ($objDac->fetch()) {
	$DspLstTmp = $DspLstTmp . htmlspecialchars($objDac->fld['name']) . "<br>";
}

/*---指定された組織コードでtbl_handlerのディレクトリーを取得する---*/
$sql = "SELECT tbl_handler.item2 FROM tbl_handler " . "WHERE (((tbl_handler.class)=1) AND ((tbl_handler.item1)='" . $DspDeptCode . "')) " . "ORDER BY tbl_handler.item2";
//取得
$objDac->execute($sql);
$DspLstDir = "";
$DspLstDirAry = array();
while ($objDac->fetch()) {
	$DspLstDirAry[] = htmlspecialchars($objDac->fld['item2']);
}
$DspLstDirAry = array_unique($DspLstDirAry);
natsort($DspLstDirAry);

//表示用フォルダ一覧取得
if (count($DspLstDirAry) > 0) {
	$DspLstDirAry = get_disp_dir($DspLstDirAry);
	if ($DspLstDirAry === FALSE) {
		DispError("フォルダ一覧の取得に失敗しました。", 2, "javascript:history.back()");
		exit();
	}
}
$DspLstDir = implode("<br>", $DspLstDirAry);

//戻り先URL
$deptInfo = getDeptCode($args["dept_code"]);
$DspBackURL = "../index.php?dept_code=" . $args["dept_code"];

/*-----------------------------------------------------------------------------
	テンプレート名の取得

【引数】	$i_TmpID	テンポラリー名を取得するテンポラリーID
		
【戻値】	取得されたテンポラリー名
		
【備考】
-----------------------------------------------------------------------------*/
function G_GetTmpName($i_objTmp, $i_TmpID) {
	
	$sql = "SELECT tbl_template.template_id, tbl_template.name FROM tbl_template " . "WHERE (((tbl_template.template_id)=" . $i_TmpID . "))" . "ORDER BY tbl_template.template_ver DESC";
	
	$i_objTmp->execute($sql);
	$tmp_nm = "";
	while ($i_objTmp->fetch()) {
		$tmp_nm = htmlspecialchars($i_objTmp->fld['name']);
		break;
	}
	return ($tmp_nm);
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>組織情報詳細</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="department.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin//js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxGo(bv) {
	$('behavior').value = bv;
	if (bv == 2) {
		$('form').action = 'edit.php';
	} else if (bv == 3) {
		$('form').action = 'confirm.php';
	} else {
		alert('パラメータエラー（behavior）');
		return false;
	}
	document.form.submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?=$GLOBALS["StrDbg"]?>

<?php
// ヘッダーメニュー挿入
$headerMode = 'deptuser';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-department">
<div><img src="images/bar_detail.jpg" alt="組織情報詳細" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<p align="left" id="cms8341-pankuzu"><?=$DspDeptName?></p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="230" align="left" valign="top" scope="row">組織コード</th>
		<td align="left" valign="top"><?=$DspDeptCode?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">組織名</th>
		<td align="left" valign="top"><?=htmlspecialchars($DspDeptNm)?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">住所</th>
		<td align="left" valign="top"><?=htmlspecialchars($DspDeptAddress)?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">電話番号</th>
		<td align="left" valign="top"><?=htmlspecialchars($DspDeptTel)?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">FAX番号</th>
		<td align="left" valign="top"><?=htmlspecialchars($DspDeptFax)?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">メールアドレス</th>
		<td align="left" valign="top"><?=htmlspecialchars($DspDeptEm)?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">URL</th>
		<td align="left" valign="top"><?=htmlspecialchars($DspDeptUrl)?></td>
	</tr>
<?php
if ($DeptLevel == G_DEPT_LEVEL03) { /*--- 2007-09-10 M.Takano Upd Start */	?>
<tr>
		<th align="left" valign="top" scope="row">外部ファイル取り込み権限</th>
		<td align="left" valign="top"><?=htmlDisplay($DspDefOuter)?></td>
	</tr>
<?php
	if (ENABLE_OPTION_FAQ) {
		?>
<tr>
		<th align="left" valign="top" scope="row">FAQ振分権限</th>
		<td align="left" valign="top"><?=htmlDisplay($DspDefFAQAnswer)?></td>
	</tr>
<?php
	}
	?>
<?php

	if (ENABLE_OPTION_OUTPUT) {
		?>
<tr>
		<th align="left" valign="top" scope="row">外部データ連携権限</th>
		<td align="left" valign="top">
<?php
		if ($output != "" || $auto_output != "") {
			?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable">
<?php
			if ($output != "") {
				?>
<tr>
				<th align="left" valign="middle" scope="row" width="20%">手動出力</th>
				<td align="left" valign="top"><?=$output?></td>
			</tr>
<?php
			}
			?>
<?php

			if ($auto_output != "") {
				?>
<tr>
				<th align="left" valign="middle" scope="row" width="20%">自動出力</th>
				<td align="left" valign="top"><?=$auto_output?></td>
			</tr>
<?php
			}
			?>
</table>
<?php
		}
		?>
</td>
	</tr>
<?php
	}
	?><tr>
		<th align="left" valign="top" scope="row">通常ページ初期フォルダ</th>
		<td align="left" valign="top"><?=htmlDisplay($DspDefDir1)?></td>
	</tr>
<?php
} //--- 2007-09-10 M.Takano Upd End ?>
<tr>
		<th align="left" valign="top" scope="row">テンプレート一覧</th>
		<td align="left" valign="top">
<?=$DspLstTmp?>
</td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">フォルダ一覧</th>
		<td align="left" valign="top">
<?=$DspLstDir?>
</td>
	</tr>
</table>
<p align="center"><a href="javascript:" onClick="return cxGo(2)"><img
	src="<?=RPW?>/admin/master/images/btn_fix.jpg" alt="修正" width="150"
	height="20" border="0" style="margin-right: 10px"></a> <a
	href="javascript:" onClick="return cxGo(3);"><img
	src="<?=RPW?>/admin/master/images/btn_del.jpg" alt="削除" width="150"
	height="20" border="0" style="margin-right: 10px"></a> <a
	href="<?=$DspBackURL?>"><img
	src="<?=RPW?>/admin/master/images/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0"></a></p>
</div>
<div><img src="<?=RPW?>/admin/master/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<form id="form" class="cms8341-form" name="form" action="" method="post">
<input type="hidden" id="dept_id" name="dept_id"
	value="<?=htmlspecialchars($args['dept_id'])?>"> <input
	type="hidden" id="behavior" name="behavior" value=""></form>
</body>
</html>
