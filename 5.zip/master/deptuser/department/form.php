<?php
/*
 * 組織管理　組織情報のインポート(form.php)
 */
$GLOBALS["StrDbg"] = "";

/*---------------------------------------------
	定数 
----------------------------------------------*/
//csvファイルupload先
define("CSV_UPLOAD", "./tmp/");

//csvファイル最大行
define("G_CSV_MAX_LINE", 40000);

//--- 2007-09-11 M.Takano Upd Start
//必須項目チェックフラグ（0:必須チェックなし　1:必須チェックあり)
//組織コード1,組織コード2,組織コード3,組織名,問い合せ先TEL,問い合せ先FAX,問い合せ先Eメール,問い合せ先住所,問い合せ先URL,表示順
$ChkItemFlg = array(
		1, 
		1, 
		1, 
		1, 
		0, 
		0, 
		0, 
		0, 
		0, 
		1, 
		1
);
//項目名
$ChkItemNm = array(
		"組織コード1", 
		"組織コード2", 
		"組織コード3", 
		"組織名", 
		"問い合せ先TEL", 
		"問い合せ先FAX", 
		"問い合せ先Eメール", 
		"問い合せ先住所", 
		"問い合せ先URL", 
		"表示順", 
		"通常ページ初期フォルダ"
);

define("G_CSV_ITM_CNT", 11); //組織情報項目数
define("MAX_ROW_CNT_TEMPLATE", 30); //テンプレート項目の最大列数
define("MIN_ROW_CNT_DIRECTORY", 5); //ディレクトリ項目の最少列数（見出しのための制限）


//レヴェル
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


/*---------------------------------------------------------------------------------
	form.php
---------------------------------------------------------------------------------*/
//--- 設定ファイル読み込み
require ("./.htsetting");

require ("./include/common.inc");

//---引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError("インポートをするcsvファイルを指定してください。", 2, "javascript:history.back()");
	exit();
}

// 拡張子チェック
$sExtension = substr($frmCsvFnm, (strrpos($frmCsvFnm, '.') + 1));
$sExtension = strtolower($sExtension);
if ($sExtension != "csv") {
	DispError("csvファイルを指定してください。", 2, "javascript:history.back()");
	exit();
}

//---ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError("csvファイルのファイルサイズが0バイトです。", 2, "javascript:history.back()");
	exit();
}

//---アップロード
$frmCsvFnm = CSV_UPLOAD . $frmCsvFnm;
if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $frmCsvFnm) == FALSE) {
	DispError("csvファイルのアップロードに失敗しました。", 2, "javascript:history.back()");
	exit();
}
//(念のため)ファイル存在チェック
if (file_exists($frmCsvFnm) == FALSE) {
	$wk_str = "指定されたファイル【" . $frmCsvFnm . "】が存在しません。";
	DispError($wk_str, 2, "javascript:history.back()");
	exit();
}

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
$objSelNm = new dac($objCnc);

/*---csvを読込み、tbl_departmentとtbl_handlerに追加していく---*/
// トランザクション開始
$objCnc->begin();

//組織情報の全削除
$sql = "DELETE FROM tbl_department";
$objDac->execute($sql);
//ハンドラテーブルのディレクトリ項目、テンプレート項目全削除
$sql = "DELETE FROM tbl_handler" . " WHERE class IN (" . HANDLER_CLASS_DIRECTORY . ", " . HANDLER_CLASS_TEMPLATE . ", " . HANDLER_CLASS_DEF_DIR1 . ")";
$objDac->execute($sql);

//ファイルを開く
if (!($CsvFno = csvRead_UTF8($frmCsvFnm))) {
	//エラーページの表示
	DispError("csvファイルのオープンに失敗しました。", 2, "javascript:history.back()");
	exit();
}
//一行目（）は飛ばす
$data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE);
//EOFになるまで読み出し
$err_msg = "";
while ($data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
	// 行の項目数が組織情報の項目数よりも少なければ空で埋める
	while (count($data) <= G_CSV_ITM_CNT + MAX_ROW_CNT_TEMPLATE) {
		$data[] = "";
	}
	
	if ($data[10] != "" && substr($data[10], -1, 1) != "/") $data[10] .= "/";
	//		if($data[9] != "" && substr($data[9],-1,1) != "/")$data[9] .= "/";
	//各項目のチェック
	if (FALSE == G_ChkCsvItem($data, $ChkItemFlg, $ChkItemNm, $objDac, $err_msg, $dept_code)) {
		//ファイルClose
		fclose($CsvFno);
		//ファイルを削除
		unlink($frmCsvFnm);
		//ロールバック
		$objCnc->rollback();
		//エラーページの表示
		DispError($err_msg, 2, "javascript:history.back()");
		exit();
	}
	
	// 組織コードにウェブマスターが指定されていたら登録はしない
	if ($dept_code == WEB_MASTER_CODE) {
		continue;
	}
	
	//tbl_departmentに追加
	if (FALSE == G_TblDeptAdd($data, $dept_code, $objDac)) {
		//ファイルClose
		fclose($CsvFno);
		//ファイルを削除
		unlink($frmCsvFnm);
		//ロールバック
		$objCnc->rollback();
		//エラーページの表示
		DispError("組織情報の登録に失敗しました。", 2, "javascript:history.back()");
		exit();
	}
	//tbl_handlerに追加
	if (FALSE == G_TblHandlerAdd($data, $dept_code, $objDac)) {
		//ファイルClose
		fclose($CsvFno);
		//ファイルを削除
		unlink($frmCsvFnm);
		//ロールバック
		$objCnc->rollback();
		//エラーページの表示
		DispError("ハンドラー情報の登録に失敗しました。", 2, "javascript:history.back()");
		exit();
	}
}

//ファイルClose
fclose($CsvFno);
//ファイルを削除
if (unlink($frmCsvFnm) == FALSE) {
	//ロールバック
	$objCnc->rollback();
	//エラーページの表示
	DispError("csvファイルの削除に失敗しました。", 2, "javascript:history.back()");
	exit();
}

//---dept_name(部+課+係)の取得
$err_msg = "";
if (FALSE == G_GetDeptNmIntoTblDept($objDac, $objSelNm, $err_msg)) {
	//ロールバック
	$objCnc->rollback();
	//エラーページの表示
	if (strlen($err_msg) > 0) {
		DispError($err_msg, 2, "javascript:history.back()");
	}
	else {
		DispError("組織名の取得に失敗しました。", 2, "javascript:history.back()");
	}
	exit();
}

/*--[tbl_user]に指定されているuserIDが[tbl_department]に存在しない場合はエラー---*/
$sql = "SELECT tbl_user.user_id " . "FROM tbl_user LEFT JOIN tbl_department ON tbl_user.dept_code = tbl_department.dept_code " . "WHERE (((tbl_department.dept_code) Is Null) AND ((tbl_user.dept_code)<>'" . WEB_MASTER_CODE . "'))";
//[tbl_department]に存在しないuser_idのみ取得
$objDac->execute($sql);
if ($objDac->getRowCount() > 0) {
	//ロールバック
	$objCnc->rollback();
	//エラーページの表示
	DispError("組織情報に存在しない組織コードがユーザー情報で使用されています。", 2, "javascript:history.back()");
	exit();
}

// tbl_faqに指定されているfaq_idがtbl_departmentに存在しない場合はエラー
if (ENABLE_OPTION_FAQ) {
	$sql = "SELECT f.faq_id FROM tbl_faq AS f LEFT JOIN tbl_department AS d ON (f.charge = d.dept_code) WHERE ((d.dept_code IS NULL))";
	$obj_Dac->execute($sql);
	if ($obj_Dac->getRowCount() > 0) {
		// ロールバック
		$objCnc->rollback();
		// エラーページの表示
		DispError('担当するお問い合わせ情報が存在するため、この組織を削除できません。', 2, 'javascript:history.back()');
		exit;
	}
}

// コミット
$objCnc->commit();

/*---一覧画面へと戻る---*/
header("Location: " . "./index.php");

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	CSV項目のチェック

【引数】	$i_OneData		配列で指定されたcsvデータ（全項目)
		$i_ChkItemFlg	必須チェックフラグ
		$i_ChkItemNm	項目名
		$i_objDac		DB
		$o_ErrMsg		エラーメッセージ
		$o_DeptCode		結合された組織コード
		
【戻値】	True	すべてのチェックが正常に終了
		False	エラーが存在した
		
【備考】
-----------------------------------------------------------------------------*/
function G_ChkCsvItem($i_OneData, $i_ChkItemFlg, $i_ChkItemNm, $i_objDac, &$o_ErrMsg, &$o_DeptCode) {
	$ARY_NO_CREATE_DIR = getDefineArray("ARY_NO_CREATE_DIR");
	$dept_cd = array(
			"", 
			"", 
			""
	);
	
	/*---組織コード１（部）($i_OneData[0])～組織コード３（係）チェック($i_OneData[2])---*/
	for($idx = 0; $idx <= 2; $idx++) {
		//必須チェック
		if ($i_ChkItemFlg[$idx] == 1) {
			if (strlen($i_OneData[$idx]) <= 0) {
				$o_ErrMsg = "組織コード" . ($idx + 1) . "が指定されていないデーターが存在します。";
				return FALSE;
			}
			//桁数チェック
			if (strlen($i_OneData[$idx]) > CODE_DIGIT_DEPT) {
				$o_ErrMsg = "組織コード" . ($idx + 1) . "に" . CODE_DIGIT_DEPT . "桁を越えて指定されているデーターが存在します。" . "【" . $i_OneData[$idx] . "】";
				return FALSE;
			}
			if (strlen($i_OneData[$idx]) < CODE_DIGIT_DEPT) {
				//少ない場合は、0埋め
				$dept_cd[$idx] = str_pad($i_OneData[$idx], CODE_DIGIT_DEPT, "0", STR_PAD_LEFT);
			}
			else {
				$dept_cd[$idx] = $i_OneData[$idx];
			}
			if (FALSE == checkMachineCode($dept_cd[$idx])) {
				$o_ErrMsg = "機種依存文字が指定されている組織コード" . ($idx + 1) . "が存在します。";
				return FALSE;
			}
		}
	}
	
	/*---他組織項目の必須チェック---*/
	//21:09 2006/09/28
	for($idx = 3; $idx < 10; $idx++) {
		if ($i_ChkItemFlg[$idx] == 1) {
			if (strlen($i_OneData[$idx]) <= 0) {
				$o_ErrMsg = $i_ChkItemNm[$idx] . "が指定されていないデーターが存在します。";
				return FALSE;
			}
		}
		if (FALSE == checkMachineCode($i_OneData[$idx])) {
			$o_ErrMsg = "機種依存文字が指定されている" . $i_ChkItemNm[$idx] . "が存在します。【" . $i_OneData[$idx] . "】";
			return FALSE;
		}
	}
	
	/*---（第3階層）初期ディレクトリの必須チェック---*/
	if ($i_OneData[2] != str_repeat("0", CODE_DIGIT_DEPT)) {
		for($idx = 10; $idx < G_CSV_ITM_CNT; $idx++) {
			if ($i_ChkItemFlg[$idx] == 1) {
				if (strlen($i_OneData[$idx]) <= 0) continue;
				if (preg_match('/^[^\/]/', $i_OneData[$idx])) {
					$o_ErrMsg = $i_ChkItemNm[$idx] . "は/（スラッシュ）から始まるパスを入力してください。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				if ((preg_match('/[^0-9a-zA-Z\~\.\-\_\/]/', $i_OneData[$idx]))) {
					$o_ErrMsg = $i_ChkItemNm[$idx] . "にフォルダ名としてふさわしくない文字が使用されています。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				// 作成禁止ディレクトリは権限を与えない
				foreach ((array) $ARY_NO_CREATE_DIR as $no_dir) {
					if (preg_match("/^" . reg_replace($no_dir) . "/i", $i_OneData[$idx])) {
						$o_ErrMsg = $i_ChkItemNm[$idx] . "に権限を与えられないフォルダが指定されています。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
						return FALSE;
					}
				}
				
				if (!@is_dir(DOCUMENT_ROOT . RPW . $i_OneData[$idx])) {
					if (strlen(LIMIT_DIR_STRUCTURE) != 0) {
						$dir_structure = preg_replace("/\/$/", "", $i_OneData[$idx]);
						$dir_array = explode("/", $dir_structure);
						$temp_ary = array(
								FCK_FILELINK_FORDER, 
								FCK_IMAGES_FORDER
						);
						$limitDirAdd = (count($dir_array) > 0 && in_array("/" . $dir_array[count($dir_array) - 1], $temp_ary)) ? 1 : 0;
						if (count($dir_array) > LIMIT_DIR_STRUCTURE + $limitDirAdd) {
							$o_ErrMsg = $i_ChkItemNm[$idx] . "はフォルダ作成に制限があるため、初期ディレクトリに指定できません。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
							return FALSE;
						}
					}
				}
			}
			if (FALSE == checkMachineCode($i_OneData[$idx])) {
				$o_ErrMsg = "機種依存文字が指定されている" . $i_ChkItemNm[$idx] . "が存在します。【" . $i_OneData[$idx] . "】";
				return FALSE;
			}
		}
		
		for($idx = G_CSV_ITM_CNT; $idx < (G_CSV_ITM_CNT + MAX_ROW_CNT_TEMPLATE); $idx++) {
			if (strlen($i_OneData[$idx]) > 0) {
				$where = $i_objDac->_addslashesC("template_id", $i_OneData[$idx], "=");
				$i_objDac->setTableName("tbl_template");
				$i_objDac->select($where);
				if ($i_objDac->getRowCount() == 0) {
					$o_ErrMsg = "指定されたテンプレートは存在しません。【テンプレートID:" . $i_OneData[$idx] . "】";
					return FALSE;
				}
			}
		}
		
		for($idx = (G_CSV_ITM_CNT + MAX_ROW_CNT_TEMPLATE); $idx < count($i_OneData); $idx++) {
			if (strlen($i_OneData[$idx]) > 0) {
				if (preg_match('/^[^\/]/', $i_OneData[$idx])) {
					$o_ErrMsg = "権限のあるフォルダは/（スラッシュ）から始まるパスを入力してください。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				if ((preg_match('/[^0-9a-zA-Z\~\.\-\_\/\*]/', $i_OneData[$idx]))) {
					$o_ErrMsg = "権限のあるフォルダにフォルダ名としてふさわしくない文字が使用されています。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				
				// 作成禁止ディレクトリは権限を与えない
				foreach ((array) $ARY_NO_CREATE_DIR as $no_dir) {
					if (preg_match("/^" . reg_replace($no_dir) . "/i", $i_OneData[$idx])) {
						$o_ErrMsg = "権限のあるフォルダに権限を与えられないフォルダが指定されています。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
						return FALSE;
					}
				}
				
				if (strpos($i_OneData[$idx], '*') != strrpos($i_OneData[$idx], '*')) {
					$o_ErrMsg = "権限のあるフォルダに「*」が複数指定されています。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				if (preg_match('/([0-9a-zA-Z\~\.\-\_]\*|\*[0-9a-zA-Z\~\.\-\_])/', $i_OneData[$idx])) {
					$o_ErrMsg = "権限のあるフォルダに「*」を使用する場合前後には「/」のみとしてください。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				if (preg_match('/\*\/[0-9a-zA-Z\~\.\-\_\/\*]/', $i_OneData[$idx])) {
					$o_ErrMsg = "権限のあるフォルダに「*」を使用する場合「*」以下は指定しないでください。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
					return FALSE;
				}
				
				if (!@is_dir(DOCUMENT_ROOT . RPW . $i_OneData[$idx])) {
					if (strlen(LIMIT_DIR_STRUCTURE) != 0) {
						$dir_structure = preg_replace("/\/$/", "", $i_OneData[$idx]);
						$dir_array = explode("/", $dir_structure);
						$temp_ary = array(
								FCK_FILELINK_FORDER, 
								FCK_IMAGES_FORDER
						);
						$limitDirAdd = (count($dir_array) > 0 && in_array("/" . $dir_array[count($dir_array) - 1], $temp_ary)) ? 1 : 0;
						if (count($dir_array) > LIMIT_DIR_STRUCTURE + $limitDirAdd) {
							$o_ErrMsg = "フォルダ作成に制限があるため、権限を付加できません。【" . $dept_cd[0] . $dept_cd[1] . $dept_cd[2] . "】";
							return FALSE;
						}
					}
				}
			}
		}
	}
	
	/*---組織コード(部)(課)(係)---*/
	$o_DeptCode = $dept_cd[0] . $dept_cd[1] . $dept_cd[2]; //3+3+3
	if (strlen($o_DeptCode) > 0) {
		//tbl_departmentに重複チェック
		$sql = "SELECT dept_id FROM tbl_department WHERE dept_code='" . $o_DeptCode . "'";
		$i_objDac->execute($sql);
		if ($i_objDac->getRowCount() > 0) {
			$o_ErrMsg = "すでに存在する組織コード（部、課、係）の指定されているデーターが存在します。【" . $dept_cd[0] . "," . $dept_cd[1] . "," . $dept_cd[2] . "】";
			return FALSE;
		}
	}
	
	/*---問い合せEメール $i_OneData[6] ---*/
	//形式チェック
	//1: 文字列先頭から@直前までに、@以外の任意の文字が１文字以上あること
	//2: @は1つだけ指定されていること。
	//3: @の後にはドット以外の文字が１文字以上あること。
	//4: ドット後に任意の文字が１文字以上あること。
	/*	if( strlen($i_OneData[6]) > 0 ){
		if(FALSE == preg_match("/^[_a-z0-9-]+(￥.[_a-z0-9-]+)*@[a-z0-9-]+([￥.][a-z0-9-]+)+$/i", $i_OneData[6])){
			$o_ErrMsg = "メールアドレスとしてふさわしくない値が指定されているデーターが存在します。【" . $i_OneData[6] ."】";
			return FALSE;
		}
	}*/
	
	/*---表示順 $i_OneData[9] ---*/
	//半角数値チェック
	if (!(preg_match("/^[0-9]+$/", $i_OneData[9]))) {
		$o_ErrMsg = "半角数値以外の値が指定されている表示順が存在します。";
		return FALSE;
	}
	
	return TRUE;

}

/*-----------------------------------------------------------------------------
	tbl_departmentにCSVデータを追加

【引数】	$i_OneData	配列で指定されたcsvデータ（全項目)
		$i_DeptCode	結合された組織コード
		$i_objDac	DB
		
【戻値】	True	正常に終了
		False	エラー
		
【備考】
-----------------------------------------------------------------------------*/
function G_TblDeptAdd($i_OneData, $i_DeptCode, $i_objDac) {
	$dir_list = "";
	$dir_list_ary = array();
	
	/*---levelの取得---*/
	$level = 0;
	//部
	if ((((int)$i_OneData[0]) > 0) && (((int)$i_OneData[1]) <= 0) && (((int)$i_OneData[2]) <= 0)) {
		$level = G_DEPT_LEVEL01;
		//課
	}
	elseif ((((int)$i_OneData[0]) > 0) && (((int)$i_OneData[1]) > 0) && (((int)$i_OneData[2]) <= 0)) {
		$level = G_DEPT_LEVEL02;
		//係
	}
	else {
		$level = G_DEPT_LEVEL03;
	}
	
	//SQL作成
	$sql = "INSERT INTO tbl_department ( level, dept_code, name, tel, fax, email, address, url, sort_order) VALUES (";
	$sql = $sql . $level . ", "; //レベル
	$sql = $sql . "'" . $i_DeptCode . "'" . ", "; //組織コード
	$sql = $sql . "'" . gd_addslashes($i_OneData[3]) . "'" . ", "; //名前
	$sql = $sql . "'" . gd_addslashes($i_OneData[4]) . "'" . ", "; //問い合せTEL
	$sql = $sql . "'" . gd_addslashes($i_OneData[5]) . "'" . ", "; //問い合せFAX
	$sql = $sql . "'" . gd_addslashes($i_OneData[6]) . "'" . ", "; //問い合せＥメール
	$sql = $sql . "'" . gd_addslashes($i_OneData[7]) . "'" . ", "; //問い合せ住所
	$sql = $sql . "'" . gd_addslashes($i_OneData[8]) . "'" . ", "; //問い合せURL
	$sql = $sql . $i_OneData[9]; //sort_order
	$sql = $sql . ")";
	
	//実行
	return ($i_objDac->execute($sql, "utf-8", "auto"));
}

/*-----------------------------------------------------------------------------
	tbl_handlerにCSVデータを追加

【引数】	$i_OneData	配列で指定されたcsvデータ（全項目)
		$i_DeptCode	結合された組織コード
		$i_objDac	DB
		
【戻値】	True	正常に終了
		False	エラー
		
【備考】
-----------------------------------------------------------------------------*/
function G_TblHandlerAdd($i_OneData, $i_DeptCode, $i_objDac) {
	$ARY_NO_CREATE_DIR = getDefineArray("ARY_NO_CREATE_DIR");
	
	/*---「通常ページ初期ディレクトリ」項目処理---*/
	if (strlen($i_OneData[10]) > 0) {
		$i_OneData[10] = preg_replace("/\/+/", "/", $i_OneData[10]);
		//SQL作成
		$sql = "INSERT INTO tbl_handler ( class, item1, item2) VALUES (" . HANDLER_CLASS_DEF_DIR1 . // Class
", '" . gd_addslashes($i_DeptCode) . "'" . // item1
", '" . gd_addslashes($i_OneData[10]) . "'" . // item2
")";
		//実行
		if (FALSE == $i_objDac->execute(mb_convert_encoding($sql, "utf-8", "auto"))) {
			return FALSE;
		}
	}
	
	/*---「権限のあるテンプレートID」項目処理---*/
	$min_idx = G_CSV_ITM_CNT;
	$max_idx = (G_CSV_ITM_CNT + MAX_ROW_CNT_TEMPLATE);
	if (count($i_OneData) < $max_idx) $max_idx = count($i_OneData);
	for($idx = $min_idx; $idx < $max_idx; $idx++) {
		if (strlen($i_OneData[$idx]) > 0) {
			//SQL作成
			$sql = "INSERT INTO tbl_handler ( class, item1, item2) VALUES (" . HANDLER_CLASS_TEMPLATE . // Class
", '" . gd_addslashes($i_DeptCode) . "'" . // item1
", '" . gd_addslashes($i_OneData[$idx]) . "'" . // item2
")";
			//実行
			if (FALSE == $i_objDac->execute(mb_convert_encoding($sql, "utf-8", "auto"))) {
				return FALSE;
			}
		}
	}
	
	/*---「権限のあるディレクトリ」項目処理---*/
	$dir_list_ary = array();
	$list = array();
	$dirData = array_slice($i_OneData, (G_CSV_ITM_CNT + MAX_ROW_CNT_TEMPLATE));
	// 初期ディレクトリに指定されたは強制的に登録する
	if (!in_array($i_OneData[10], $dirData)) $i_OneData[] = $i_OneData[10];
	//	if ($i_OneData[9] != $i_OneData[8] && !in_array($i_OneData[9], $dirData)) $i_OneData[] = $i_OneData[9];
	for($idx = (G_CSV_ITM_CNT + MAX_ROW_CNT_TEMPLATE); $idx < count($i_OneData); $idx++) {
		if (strlen($i_OneData[$idx]) > 0) {
			$dir = $i_OneData[$idx];
			$dir = preg_replace("/\/+/", "/", $dir);
			
			//「*」ワイルドカードを使用した権限登録
			if (preg_match("/\/\*\/?$/", $dir)) {
				// 「*」権限追加
				$dir_list_ary[] = mb_convert_encoding(preg_replace("/\/\*\/?$/", "/*", $dir), "utf-8", "auto");
				// 「*」以下のパスを削除
				$dir = preg_replace("/\/\*\/?$/", "", $dir);
			}
			
			$dir_list_ary[] = mb_convert_encoding((substr($dir, -1, 1) == "/" ? $dir : $dir . "/"), "utf-8", "auto");
		}
	}
	
	//重複パスの削除
	$dir_list_ary = array_unique($dir_list_ary);
	natsort($dir_list_ary);
	//権限登録
	if (!insert_handler_directory($i_DeptCode, $dir_list_ary, HANDLER_DIR_SPECIAL_INS)) {
		return FALSE;
	}
	// フォルダ作成
	foreach ((array) $dir_list_ary as $dir_path) {
		//ワイルドカードを使用していたならディレクトリを作成しない
		if (preg_match("/^.*\*.*$/", $dir_path)) continue;
		
		$dummy = (substr($dir_path, -1, 1) == "/") ? "dummy.txt" : "/dummy.txt";
		mkNewDirectory(DOCUMENT_ROOT . RPW . $dir_path . $dummy);
	}
	
	return TRUE;
}

/*-----------------------------------------------------------------------------
	組織名の取得

【引数】	$i_objDac	DB
		$i_objSDec	DB
		$o_ErrMsg	エラーメッセージ
		
【戻値】	True	正常に終了
		False	エラー
		
【備考】
-----------------------------------------------------------------------------*/
function G_GetDeptNmIntoTblDept($i_objDac, $i_objSDec, &$o_ErrMsg) {
	
	/*--- tbl_department全件処理---*/
	$sql = "SELECT tbl_department.dept_code, tbl_department.name, tbl_department.level " . "FROM tbl_department " . "ORDER BY tbl_department.dept_code";
	//取得
	$i_objDac->execute($sql);
	
	while ($i_objDac->fetch()) {
		$dept_nm = "";
		//レベルに応じて部、課、係名を取得する
		if ($i_objDac->fld['level'] == G_DEPT_LEVEL01) {
			//部
			$dept_nm = $i_objDac->fld['name'];
		}
		else {
			if (($i_objDac->fld['level'] != G_DEPT_LEVEL02) && ($i_objDac->fld['level'] != G_DEPT_LEVEL03)) {
				$o_ErrMsg = "有効ではないレベルが指定されている組織データーが存在しました。";
				return FALSE;
			}
			//対応する部コードの作成
			$dept_01 = substr($i_objDac->fld['dept_code'], 0, CODE_DIGIT_DEPT); //組織コード１の切り出し
			$dept_01 = str_pad($dept_01, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
			if ($i_objDac->fld['level'] == G_DEPT_LEVEL02) {
				$sql = "SELECT tbl_department.dept_code, tbl_department.name " . "FROM tbl_department " . "WHERE (((tbl_department.dept_code)='" . $dept_01 . "'))" . "ORDER BY tbl_department.dept_code";
				//取得
				$i_objSDec->execute($sql);
				if ($i_objSDec->getRowCount() <= 0) {
					$o_ErrMsg = "上位の組織名が取得できません。【" . $i_objDac->fld['dept_code'] . "】";
					return FALSE;
				}
				//部 + 課
				while ($i_objSDec->fetch()) {
					$dept_nm = $i_objSDec->fld['name'] . $i_objDac->fld['name'];
				}
			}
			else {
				//対応する課コードの作成
				$dept_02 = substr($i_objDac->fld['dept_code'], 0, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT)); //組織コード2の切り出し
				$dept_02 = str_pad($dept_02, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
				$sql = "SELECT tbl_department.dept_code, tbl_department.name as dept_nm01, tbl_department_1.dept_code, tbl_department_1.name as dept_nm02 " . "FROM tbl_department, tbl_department AS tbl_department_1 " . "WHERE (((tbl_department.dept_code)='" . $dept_01 . "') AND ((tbl_department_1.dept_code)='" . $dept_02 . "'))";
				"ORDER BY tbl_department.dept_code";
				//取得
				$i_objSDec->execute($sql);
				if ($i_objSDec->getRowCount() <= 0) {
					$o_ErrMsg = "上位の組織名が取得できません。【" . $i_objDac->fld['dept_code'] . "】";
					return FALSE;
				}
				//部 + 課 + 係
				while ($i_objSDec->fetch()) {
					$dept_nm = $i_objSDec->fld['dept_nm01'] . $i_objSDec->fld['dept_nm02'] . $i_objDac->fld['name'];
				}
			}
		}
		//組織テーブルの更新
		$sql = "UPDATE tbl_department SET dept_name = '$dept_nm' WHERE( dept_code = '" . $i_objDac->fld['dept_code'] . "' )";
		//実行
		$i_objSDec->execute($sql);
		//ユーザテーブルの更新
		$sql = "UPDATE tbl_user SET dept_name = '$dept_nm' WHERE( dept_code = '" . $i_objDac->fld['dept_code'] . "' )";
		//実行
		$i_objSDec->execute($sql);
	}
	
	return TRUE;

}

?>
