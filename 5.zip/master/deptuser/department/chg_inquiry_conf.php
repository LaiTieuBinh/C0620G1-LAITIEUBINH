<?php
/*
 *
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/
//レヴェル
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


/** require **/
require ("./.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
$objDac_Before = new dac($objCnc);
$objDac_After = new dac($objCnc);

if (isset($_SESSION['chg_inq'])) unset($_SESSION['chg_inq']);
/*** SESSIONセット ***/
//対象項目生成(変更対象の組織)
if (isset($_POST['cms_target_before_1']) && $_POST['cms_target_before_1'] != "") {
	$_SESSION['chg_inq']['target_before_1'] = $_POST['cms_target_before_1'];
}
if (isset($_POST['cms_target_before_2']) && $_POST['cms_target_before_2'] != "") {
	$_SESSION['chg_inq']['target_before_2'] = $_POST['cms_target_before_2'];
}
if (isset($_POST['cms_target_before_3']) && $_POST['cms_target_before_3'] != "") {
	$_SESSION['chg_inq']['target_before_3'] = $_POST['cms_target_before_3'];
}
//対象項目生成(変更後の組織)
if (isset($_POST['cms_target_after_1']) && $_POST['cms_target_after_1'] != "") {
	$_SESSION['chg_inq']['target_after_1'] = $_POST['cms_target_after_1'];
}
if (isset($_POST['cms_target_after_2']) && $_POST['cms_target_after_2'] != "") {
	$_SESSION['chg_inq']['target_after_2'] = $_POST['cms_target_after_2'];
}
if (isset($_POST['cms_target_after_3']) && $_POST['cms_target_after_3'] != "") {
	$_SESSION['chg_inq']['target_after_3'] = $_POST['cms_target_after_3'];
}

if (isset($_POST['cms_target_before_3']) && $_POST['cms_target_before_3'] != "") {
	$dept_before = $_POST['cms_target_before_3'];
}
elseif (isset($_POST['cms_target_before_2']) && $_POST['cms_target_before_2'] != "") {
	$dept_before = $_POST['cms_target_before_2'];
}
elseif (isset($_POST['cms_target_before_1']) && $_POST['cms_target_before_1'] != "") {
	$dept_before = $_POST['cms_target_before_1'];
}
else {
	DispError("変更対象の組織が選択されていません。", 2, "javascript:history.back()");
	exit();
}

if (isset($_POST['cms_target_after_3']) && $_POST['cms_target_after_3'] != "") {
	$dept_after = $_POST['cms_target_after_3'];
}
elseif (isset($_POST['cms_target_after_2']) && $_POST['cms_target_after_2'] != "") {
	$dept_after = $_POST['cms_target_after_2'];
}
elseif (isset($_POST['cms_target_after_1']) && $_POST['cms_target_after_1'] != "") {
	$dept_after = $_POST['cms_target_after_1'];
}
else {
	DispError("変更後の組織が選択されていません。", 2, "javascript:history.back()");
	exit();
}

/** init **/
$label = '問い合わせ先変更';
$image = '<img src="images/bar_chg_inquiry.jpg" alt="問い合わせ先変更" width="920" height="30">';
//	$back = "javascript:history.back()";
$back = "chg_inquiry.php?bak=1";

//変換対象となる公開中のページ数を取得
$sql = "SELECT DISTINCT pp.page_id FROM tbl_publish_page AS pp INNER JOIN tbl_publish_inquiry AS pi ON (pp.inquiry_id = pi.inquiry_id) WHERE pi.dept_code = '" . $dept_before . "'";
$objDac->execute($sql);
$pub_cnt = $objDac->getRowCount();

//変換対象となる作業中のページ数を取得
$sql = "SELECT DISTINCT pw.page_id FROM tbl_work_page AS pw INNER JOIN tbl_work_inquiry AS wi ON (pw.inquiry_id = wi.inquiry_id) WHERE wi.dept_code = '" . $dept_before . "'";
$objDac->execute($sql);
$work_cnt = $objDac->getRowCount();

//変換対象となる組織情報を取得
$sql = "SELECT * FROM tbl_department WHERE dept_code = '" . $dept_before . "'";
$objDac_Before->execute($sql);
if ($objDac_Before->getRowCount() == 0) {
	DispError("選択した変更対象の組織が存在しません。", 2, "javascript:history.back()");
	exit();
}
$objDac_Before->fetch();

//変換後の組織情報を取得
$sql = "SELECT * FROM tbl_department WHERE dept_code = '" . $dept_after . "'";
$objDac_After->execute($sql);
if ($objDac_After->getRowCount() == 0) {
	DispError("選択した変更後の組織が存在しません。", 2, "javascript:history.back()");
	exit();
}
$objDac_After->fetch();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$label?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="department.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function chg_inquiry_conf() {
	return confirm("変換を開始します。よろしいですか？");
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'deptuser';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-approve">
<div><?=$image?></div>
<div class="cms8341-area-corner">
<p>以下の内容で問い合わせ先を一括変換しますがよろしいですか？<br>
※問い合わせ先を変換したページは即公開されます。<br>
<br>
<strong>変換対象となるページ数：（公開・非公開ページ：<?=$pub_cnt?>件、作業中ページ：<?=$work_cnt?>件）</strong></p>
<form id="form" class="cms8341-form" name="form" method="post"
	action="chg_inquiry_comp.php" onsubmit="return chg_inquiry_conf(this)">
<strong>変更対象の組織</strong>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="200" align="left" valign="middle" scope="row">組織コード</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['dept_code']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">組織名</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['dept_name']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">住所</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['address']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">電話番号</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['tel']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">ファックス番号</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['fax']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">メールアドレス</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['email']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">URL</th>
		<td align="left" valign="top"><?=$objDac_Before->fld['url']?></td>
	</tr>
</table>
<br>
<strong>変更後の組織</strong>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="200" align="left" valign="middle" scope="row">組織コード</th>
		<td align="left" valign="top"><?=$objDac_After->fld['dept_code']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">組織名</th>
		<td align="left" valign="top"><?=$objDac_After->fld['dept_name']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">住所</th>
		<td align="left" valign="top"><?=$objDac_After->fld['address']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">電話番号</th>
		<td align="left" valign="top"><?=$objDac_After->fld['tel']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">ファックス番号</th>
		<td align="left" valign="top"><?=$objDac_After->fld['fax']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">メールアドレス</th>
		<td align="left" valign="top"><?=$objDac_After->fld['email']?></td>
	</tr>
	<tr>
		<th align="left" valign="middle" scope="row">URL</th>
		<td align="left" valign="top"><?=$objDac_After->fld['url']?></td>
	</tr>
</table>
<p align="center"><input type="image" src="./images/btn_change.jpg"
	alt="変更" width="150" height="20" border="0" style="margin-right: 10px">
<a href="<?=$back?>"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px"></a></p>
<input type="hidden" name="cms_target_before" value="<?=$dept_before?>">
<input type="hidden" name="cms_target_after" value="<?=$dept_after?>"></form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
