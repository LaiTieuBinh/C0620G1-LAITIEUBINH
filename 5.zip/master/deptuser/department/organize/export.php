<?php
/*
 * 組織編制エクスポート処理
 */
//見出し文字
$G_SetHead = "ページID,ページタイトル,ファイルパス,組織コード,ユーザーID\n";

//--- 設定ファイル読み込み
require ("./.htsetting");
$bk_url = RPW . "/admin/master/department/organize/index.php";

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objDac = new dac($objCnc);
$objDacTools = new dac_tools($objCnc);

/*---CSVファイルの作成---*/
//tbl_user + tbl_publish_pageの取得
$fields = "u.user_id, u.dept_code, u.name, p.page_id, p.file_path, p.page_title";
$objDac->setTableName("tbl_publish_page AS p INNER JOIN tbl_user AS u ON (u.user_id = p.user_id)");
$where = $objDac->_addslashesC("p.status", STATUS_PUBLISH);
if ($_POST['cms_dept3'] != "") {
	$where .= " AND " . $objDac->_addslashesC('u.dept_code', substr($_POST['cms_dept3'], 0, 9) . '%', "LIKE", "TEXT");
}
elseif ($_POST['cms_dept2'] != "") {
	$where .= " AND " . $objDac->_addslashesC('u.dept_code', substr($_POST['cms_dept2'], 0, 6) . '%', "LIKE", "TEXT");
}
elseif ($_POST['cms_dept1'] != "") {
	$where .= " AND " . $objDac->_addslashesC('u.dept_code', substr($_POST['cms_dept1'], 0, 3) . '%', "LIKE", "TEXT");
}
$where .= " AND " . $objDac->_addslashesC("u.class", USER_CLASS_WRITER);
$orderby = "p.page_id";
$objDac->select($where, $fields, $orderby);
if ($objDac->getRowCount() <= 0) {
	DispError("ページ情報がありません。", 2, $bk_url);
	exit();
}
//ユーザー情報の作成
//見出し
$ExpCavData = $G_SetHead;
while ($objDac->fetch()) {
	$ExpCavData .= csvWrite($objDac->fld['page_id']); //ページID
	$ExpCavData .= "," . csvWrite($objDac->fld['page_title']); //ページタイトル
	$ExpCavData .= "," . csvWrite($objDac->fld['file_path']); //ページパス
	$ExpCavData .= "," . csvWrite($objDac->fld['dept_code']); //組織コード
	$ExpCavData .= "," . csvWrite($objDac->fld['user_id']); //ユーザーID
	$ExpCavData .= "\n";
}

header("Content-Disposition: attachment; filename=organize.csv");
header('Content-type: text/comma-separated-values');
print mb_convert_encoding($ExpCavData, "sjis-win", "utf-8");

?>
