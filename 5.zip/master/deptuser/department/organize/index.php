<?php
/*
 *
 */
/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");
require_once ("./include/organizeFunc.inc");
$organizeFunc = new organizeFunc();

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

$dept_html = "";
$dept1_ary = array(
		"" => "----------------"
);
$dept2_ary = array(
		"" => "----------------"
);
$dept3_ary = array(
		"" => "----------------"
);

$objDac->setTableName("tbl_department");
$where = $objDac->_addslashesC("level", 1);
$objDac->select($where);
while ($objDac->fetch()) {
	$fld = $objDac->fld;
	$dept1_ary[$fld['dept_code']] = $fld['name'];
}
$dept_html = mkcombobox($dept1_ary, "cms_dept1", "", "cxChangeDept(1, this.value)", "150px");
$dept_html .= mkcombobox($dept2_ary, "cms_dept2", "", "cxChangeDept(2, this.value)", "150px");
$dept_html .= mkcombobox($dept3_ary, "cms_dept3", "", "", "150px");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>組織編成</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
// 組織プルダウン処理
function cxChangeDept(lv, val) {
	//reset
	if(val=="") {
		var t = lv + 1;
		for(var i=t;i<=3;i++) {
			var obj = $('cms_dept'+i);
			while(obj.length>1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "----------------";
		}
	} else {
		//get data
		lv++;
		var prm = 'level='+lv+'&code='+val;
		cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
	}
}
function cxGetDeptComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Department') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for (var i=level; i<=3; i++) {
		var obj = $('cms_dept'+i);
		while (obj.length > 1) {
			obj.options[1] = null;
		}
		if(i==level) {
			obj.options[0].text = "指定なし";
		} else {
			obj.options[0].text = "----------------";
		}
	}
	var obj = $('cms_dept'+level);
        var xmlDocfix = xmlDoc.childElementCount;
        for (var i = 0; i < xmlDocfix; i++) {
            nodeL = xmlDoc.firstElementChild;
            obj.length++;
            obj.options[i + 1].text = nodeL.textContent;
            var val = nodeL.attributes.getNamedItem('value').value;
            obj.options[i + 1].value = val;
            xmlDoc.removeChild(xmlDoc.firstElementChild);
        }
}
function cxExport(){
	$('export_form').submit();
	return false;
}
function cxImport(){
	pos = $('FrmCsvnm').value.lastIndexOf(".");
	if($('FrmCsvnm').value.slice(pos+1) != "csv"){
		alert("CSVファイルを指定してください");
		return false;
	}
	$('import_form').submit();
	return false;
}
//-->
</script>


</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'deptuser';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-user">
<div><img src="./images/bar_organize_export.jpg" alt="組織編制、ページ情報エクスポート"
	width="920" height="30"></div>
<div class="cms8341-area-box">
<div align="center">
<table border="0" cellspacing="0" cellpadding="5">
	<tr>
		<td>
		<p align="left">エクスポートする組織コードを選択してください。</p>
		<form method="POST" name="export_form" id="export_form"
			class="cms8341_form" action="./export.php"
			enctype="multipart/form-data">
		<p align="left">
<?=$dept_html?>
</p>
		
		</td>
	</tr>
</table>
</div>
<p align="center"><a href="javascript:" onClick="return cxExport()"><img
	src="<?=RPW?>/admin/images/btn/btn_export.jpg" alt="エクスポート" width="150"
	height="20" border="0" style="margin-right: 10px"></a></p>
</form>
</div>
</div>
<div align="center" style="margin-top: 20px;">
<div><img src="./images/bar_organize_import.jpg" alt="組織編制、ページ情報のインポート"
	width="920" height="30"></div>
<div class="cms8341-area-box">
<div align="center">
<table border="0" cellspacing="0" cellpadding="5">
	<tr>
		<td>
		<p align="left">ページ情報CSVファイルを指定してください。</p>
		<p align="left">
		
		
		<form method="POST" name="import_form" id="import_form"
			class="import-form" action="./confirm.php"
			enctype="multipart/form-data"><input name="FrmCsvnm" id="FrmCsvnm"
			type="file" style="width: 540px">
		</p>
		
		</td>
	</tr>
</table>
</div>
<p align="center"><a href="javascript:" onClick="return cxImport()"><img
	src="<?=RPW?>/admin/images/btn/btn_start.jpg" alt="取り込み開始" width="150"
	height="20" border="0" style="margin-right: 10px"></a></p>
</form>
</div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
