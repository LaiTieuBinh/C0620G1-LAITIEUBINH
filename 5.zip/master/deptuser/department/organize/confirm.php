<?php
/*
 *
 */
//項目名
$ChkItemNm = array(
		"ページID", 
		"ページタイトル", 
		"ファイルパス", 
		"組織コード", 
		"ユーザーID"
);

//--- 設定ファイル読み込み
require ("./.htsetting");
global $objCnc;
require_once ("./include/organizeFunc.inc");
$organizeFunc = new organizeFunc();
$dataFiles = array();

$status_ary = array(
		STATUS_COMP => "一時保存", 
		STATUS_PUBLISH_WAIT => "公開待ち"
);
$status_str = mkradiobutton($status_ary, "status", STATUS_COMP, 2);

// ファイルを一時保存用ディレクトリにアップロードする
$tmpUpFile = $organizeFunc->upload_file();
$organizeFunc->check($tmpUpFile, $dataFiles);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>組織編制確認</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
/**
 * 取り込みボタンを押した時の処理
 */
function cxSubmit(){
	$('cms8341-progressmsg').innerHTML = '処理中．．．';
	cxLayer('cms8341-progress',1,500,500);
	$('form').submit();
	return false;
}
//-->
</script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'deptuser';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">
<div><img src="./images/bar_organize_confirm.jpg" alt="組織編制確認"
	width="920" height="30"></div>
<div class="cms8341-area-corner">以下のように変更を行います。
<form name="form" class="cms8341-form" method="post" action="submit.php">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
<?php
$isSubmit = FALSE;
if (count($dataFiles) == 0) {
	print '<td align="center" valign="middle">更新するページはありません</td>';
}
else {
	print '<th width="5%" align="center" valign="middle" style="font-weight:normal" scope="col">可否</th>';
	print '<th width="15%" align="center" valign="middle" style="font-weight:normal" scope="col">変更点</th>';
	print '<th width="80%"  align="center" valign="middle" style="font-weight:normal" scope="col">変更ファイル</th>';
	print '</tr>';
}
foreach ($dataFiles as $data) {
	print '<tr>' . "\n";
	print '<td align="center" valign="middle">' . $data['result'] . '</td>' . "\n";
	print '<td align="center" valign="middle">';
	foreach (explode(",", $data['update']) as $update) {
		switch ($update) {
			case '' :
				break;
			case CSV_PAGE_TITLE :
				print '<img src="./images/result_page_title.jpg" alt="ページタイトル変更" /><br/>';
				break;
			case CSV_FILEPATH :
				print '<img src="./images/result_file_path.jpg" alt="ファイルパス変更" /><br/>';
				$file_path = '';
				break;
			case CSV_DEPT_CODE :
				print '<img src="./images/result_dept_code.jpg" alt="組織コード変更" /><br/>';
				break;
			case CSV_USER_ID :
				print '<img src="./images/result_user_id.jpg" alt="ユーザーID変更" /><br/>';
				break;
			default :
				break;
		}
	}
	print '</td>' . "\n";
	print '<td align="left" valign="top" nowrap><p>' . "\n";
	print '<strong>' . htmlDisplay($data['disp_' . CSV_PAGE_TITLE]) . '</strong><br>' . "\n";
	if (isset($data['disp_' . CSV_FILEPATH])) {
		print $data['disp_' . CSV_FILEPATH] . "<br>\n";
	}
	if (isset($data['disp_' . CSV_DEPT_CODE])) {
		print htmlDisplay($data['disp_' . CSV_DEPT_CODE]) . "<br>\n";
	}
	if (isset($data['disp_' . CSV_USER_ID])) {
		print htmlDisplay($data['disp_' . CSV_USER_ID]) . "<br>\n";
	}
	
	print '<br><span class="cms8341-error">' . $data['reason'] . '</span>' . "\n";
	print '</p></td>' . "\n";
	print '</tr>' . "\n";
	if ($data['result'] == CSV_DATA_OK) $isSubmit = TRUE;
}
?>






</table>
<?php
if (count($dataFiles) > 0 && $isSubmit === TRUE) {
	?>
<br>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="20%">取り込み後のステータス</th>
		<td><?=$status_str?></td>
	</tr>
</table>
<?php
}
?>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center">
<?php
if (count($dataFiles) > 0 && $isSubmit === TRUE) {
	print '<a href="javascript:" onClick="return cxSubmit()"><img src="' . RPW . '/admin/images/btn/btn_start.jpg" alt="取り込み開始" width="150" height="20" border="0" style="margin-right:10px;"></a>';
}
?>
<a href="./index.php"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px;"></a></p>
<input type="hidden" name="csv_file" id="csv_file"
	value="<?=$tmpUpFile?>"></form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!--***処理中プロパティレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0" style="background-image:url(<?=RPW?>/admin/images/layer/titlebar_bg.jpg);height:30px;">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg">メッセージ</div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理中プロパティレイヤー ここまで********************************-->
</body>
</html>
