/*
 *
 */
//通信失敗処理
function cxFailure() {
	alert('情報取得中に通信エラーが発生しました');
}
//
function cxChangeDept(lv, val) {
	//reset
	if(val=="") {
		var t = lv + 1;
		for(var i=t;i<=3;i++) {
			var obj = $('cms_target'+i);
			while(obj.length>1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "----------------";
		}
	} else {
		//get data
		lv++;
		var prm = 'level='+lv+'&code='+val;
		cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
	}
}
function cxGetDeptComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Department') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    for (var i = level; i <= 3; i++) {
        var obj = $('cms_target' + i);
        while (obj.length > 1) {
            obj.options[1] = null;
        }
        if (i == level) {
            obj.options[0].text = "指定なし";
        } else {
            obj.options[0].text = "----------------";
        }
    }
    var obj = $('cms_target' + level);
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i=0; i<xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        cmb.length++;
        cmb.options[i+1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        cmb.options[i+1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}
function cxChangeClass() {
	// ウェブマスタがチェックされたとき
	// 所属組織プルダウンのクリア、公開責任者チェックボックス有効
	if ($('class_1').checked == true) {
		for (var i=1; i<=3; i++) {
			var obj = $('cms_target'+i);
			if (i == 1) {
				obj.options[0].selected = true;
			} else {
				while (obj.length > 1) {
					obj.options[1] = null;
				}
				obj.options[0].text = "----------------";
			}
			obj.disabled = true;
		}
		$('o_user_flg').disabled = false;
	// ウェブマスタ以外がチェックされたとき
	// 所属組織プルダウン有効、公開責任者チェックボックス無効
	} else {
		for (var i=1; i<=3; i++) {
			var obj = $('cms_target'+i);
			obj.disabled = false;
		}
		$('o_user_flg').checked = false;
		$('o_user_flg').disabled = true;
	}
	// 作成者か承認者チェックされたとき、ソースモードのラジオボタン有効
	if ($('class_3').checked == true || $('class_2').checked == true) {
		$('se_0').disabled = false;
		$('se_1').disabled = false;
	// 作成者以外がチェックされたとき、ソースモードのラジオボタン無効
	} else {
		$('se_0').disabled = true;
		$('se_1').disabled = true;
	}
	//承認者がチェックされたとき、編集権限のラジオボタン有効
	if ($('class_2').checked == true){
		$('ae_0').disabled = false;
		$('ae_1').disabled = false;
	} else {
		$('ae_0').disabled = true;
		$('ae_1').disabled = true;
	}
}
