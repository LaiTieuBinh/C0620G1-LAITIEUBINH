<?php
/*
 * ユーザ管理　ユーザー情報のインポート(form.php)
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/
//ウェブマスターdept_code
//--- 2006-11-09 Y.Adachi Del Start
//define("WEB_MASTER_CODE", "000000000");
//--- 2006-11-09 Y.Adachi Del End


//csvファイルupload先
define("CSV_UPLOAD", "./tmp/");

//csvファイル最大行
define("G_CSV_MAX_LINE", 20000);

//必須項目チェックフラグ（0:必須チェックなし　1:必須チェックあり)
//--- 2006-11-09 Y.Adachi Upd Start
////[組織コード1(部)][組織コード2(課)][組織コード3(係)][ユーザーID][ユーザー名][Eメール][ログインID][パスワード][権限コード]
//$ChkItemFlg = array(1,1,1,1,1,1,1,1,1);
//[組織コード1(部)][組織コード2(課)][組織コード3(係)][ユーザーID][ユーザー名][Eメール][ログインID][パスワード][権限コード][公開責任者フラグ][ソース編集フラグ][ページ編集フラグ]
$ChkItemFlg = array(
		1, 
		1, 
		1, 
		1, 
		1, 
		1, 
		1, 
		1, 
		1, 
		0, 
		1, 
		1
);
//--- 2006-11-09 Y.Adachi Upd End


//表示＆組織レベル
define("G_DEPT_LEVEL00", 0); //ウェブマスタ
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


//--- 2006-11-09 Y.Adachi Add Start
define("G_CSV_ITM_CNT", 11); //ユーザー情報項目数
define("G_OPEN_FLG", 1); //公開責任者フラグ
//--- 2006-11-09 Y.Adachi Add End


/*---------------------------------------------------------------------------------
	form.php
---------------------------------------------------------------------------------*/
//--- 設定ファイル読み込み
require ("./.htsetting");

//---引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError("インポートをするcsvファイルを指定してください。", 3, "javascript:history.back()");
	exit();
}
// 拡張子チェック
$sExtension = substr($frmCsvFnm, (strrpos($frmCsvFnm, '.') + 1));
$sExtension = strtolower($sExtension);
if ($sExtension != "csv") {
	DispError("csvファイルを指定してください。", 2, "javascript:history.back()");
	exit();
}
//---ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError("csvファイルのファイルサイズが0バイトです。", 2, "javascript:history.back()");
	exit();
}

//---アップロード
$frmCsvFnm = CSV_UPLOAD . $frmCsvFnm;
if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $frmCsvFnm) == FALSE) {
	DispError("csvファイルのアップロードに失敗しました。", 3, "javascript:history.back()");
	exit();
}
//(念のため)ファイル存在チェック
if (file_exists($frmCsvFnm) == FALSE) {
	$wk_str = "指定されたファイル【" . $frmCsvFnm . "】が存在しません。";
	DispError($wk_str, 3, "javascript:history.back()");
	exit();
}

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*---csvを読込み、tbl_userに追加していく---*/
// トランザクション開始
$objCnc->begin();

//ユーザー情報の全削除
$sql = "DELETE FROM tbl_user";
$objDac->execute($sql);

//--- 2006-11-09 Y.Adachi Add Start
//ひも付け情報のclass3の情報の全削除
$sql = "DELETE FROM tbl_handler WHERE class = 3";
$objDac->execute($sql);
//--- 2006-11-09 Y.Adachi Add End


//ファイルを開く
if (!($CsvFno = csvRead_UTF8($frmCsvFnm))) {
	//エラーページの表示
	DispError("csvファイルのオープンに失敗しました。", 3, "javascript:history.back()");
	exit();
}
//EOFになるまで読み出し
$fst_line = 0;
$err_msg = "";
while ($data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
	//一行目は飛ばす
	if ($fst_line > 0) {
		// 行の項目数が組織情報の項目数よりも少なければ空で埋める
		while (count($data) <= G_CSV_ITM_CNT) {
			$data[] = "";
		}
		
		//各項目のチェック
		if (strlen($err_msg) <= 0) {
			G_ChkCsvItem($data, $err_msg, $dept_code, $dept_name, $ChkItemFlg, $objDac);
		}
		
		//tbl_userに追加
		if (strlen($err_msg) <= 0) {
			if (FALSE == G_TblUserAdd($data, $dept_code, $dept_name, $objDac)) {
				$err_msg = "ユーザー情報の登録に失敗しました。" . "ユーザーID【" . $data[3] . "】";
			}
		}
		
		//tbl_handlerに追加
		if (strlen($err_msg) <= 0) {
			//対象のユーザーが公開責任者の場合はひも付けテーブルへ登録する
			if ($data[9] == G_OPEN_FLG) {
				if (FALSE == G_TblHandlerAdd($data, $objDac)) {
					$err_msg = "ひも付け情報の登録に失敗しました。" . "ユーザーID【" . $data[3] . "】";
				}
			}
		}
		
		if (strlen($err_msg) > 0) {
			//ファイルClose
			fclose($CsvFno);
			//ファイルを削除
			unlink($frmCsvFnm);
			//ロールバック
			$objCnc->rollback();
			//エラーページの表示
			DispError($err_msg, 3, "javascript:history.back()");
			exit();
		}
		//--- 2006-11-09 Y.Adachi Upd End
	

	}
	$fst_line = 1;
}

//ファイルClose
fclose($CsvFno);
//ファイルを削除
if (unlink($frmCsvFnm) == FALSE) {
	//ロールバック
	$objCnc->rollback();
	//エラーページの表示
	DispError("csvファイルの削除に失敗しました。", 3, "javascript:history.back()");
	exit();
}

/*--[tbl_publish_page]に指定されているuserIDが[tbl_user]に存在しない場合はエラー---*/
$sql = "SELECT DISTINCT tbl_publish_page.user_id " . "FROM tbl_publish_page LEFT JOIN tbl_user ON tbl_publish_page.user_id = tbl_user.user_id " . "WHERE (((tbl_user.user_id) Is Null))";
//[tbl_user]に存在しないuser_idのみ取得
$objDac->execute($sql);
if ($objDac->getRowCount() > 0) {
	//エラー表示用にユーザーID格納
	$not_user_id = array();
	while ($objDac->fetch())
		$not_user_id[] = $objDac->fld['user_id'];
		//ロールバック
	$objCnc->rollback();
	//エラーページの表示
	DispError("ユーザー情報に存在しないユーザーが作成したページが存在します。" . "ユーザーID【" . implode(',', $not_user_id) . "】", 3, "javascript:history.back()");
	exit();
}

//--- 2006-11-09 Y.Adachi Add Start
/*--[tbl_approve]に指定されているuserIDが[tbl_user]に存在しない場合はエラー---*/
$sql = "SELECT DISTINCT tbl_user.user_id " . "FROM (SELECT DISTINCT approve4 FROM tbl_approve WHERE approve4 IS NOT NULL AND approve4 <> " . WEB_MASTER_CODE . ") AS a " . "LEFT JOIN tbl_user ON a.approve4 = tbl_user.user_id " . "WHERE tbl_user.user_id Is Null";
//[tbl_user]に存在しないuser_idのみ取得
$objDac->execute($sql);
if ($objDac->getRowCount() > 0) {
	//エラー表示用にユーザーID格納
	$not_user_id = array();
	while ($objDac->fetch())
		$not_user_id[] = $objDac->fld['user_id'];
		//ロールバック
	$objCnc->rollback();
	//エラーページの表示
	DispError("ユーザー情報に存在しないユーザーIDが承認フローで使用されています。" . "ユーザーID【" . implode(',', $not_user_id) . "】", 3, "javascript:history.back()");
	exit();
}
//--- 2006-11-09 Y.Adachi Add End


// コミット
$objCnc->commit();

/*---一覧画面へと戻る---*/
header("Location: " . "./index.php");

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	CSV項目のチェック

【引数】	$i_OneData		配列で指定されたcsvデータ（全項目)
		$o_ErrMsg		エラーメッセージ
		$o_DeptCode		結合された組織コード
		$i_ChkItemFlg	必須チェックフラグ
		$i_objDac		DB
		
【戻値】	True	すべてのチェックが正常に終了
		False	エラーが存在した
		
【備考】
-----------------------------------------------------------------------------*/
function G_ChkCsvItem($i_OneData, &$o_ErrMsg, &$o_DeptCode, &$o_DeptName, $i_ChkItemFlg, $i_objDac) {
	
	$dept_cd = array(
			"", 
			"", 
			""
	);
	
	/*---組織コード１（部）($i_OneData[0])～組織コード３（係）チェック($i_OneData[2])---*/
	for($idx = 0; $idx <= 2; $idx++) {
		//必須チェック
		if ($i_ChkItemFlg[$idx] == 1) {
			if (strlen($i_OneData[$idx]) <= 0) {
				$o_ErrMsg = "組織コード" . ($idx + 1) . "が指定されていないデーターが存在します。" . "ユーザーID【" . $i_OneData[3] . "】";
				return FALSE;
			}
			//桁数チェック
			if (strlen($i_OneData[$idx]) > CODE_DIGIT_DEPT) {
				$o_ErrMsg = "組織コード" . ($idx + 1) . "に" . CODE_DIGIT_DEPT . "桁を越えて指定されているデーターが存在します。" . "[" . $i_OneData[$idx] . "]" . "ユーザーID【" . $i_OneData[3] . "】";
				return FALSE;
			}
			if (strlen($i_OneData[$idx]) < CODE_DIGIT_DEPT) {
				//少ない場合は、0埋め
				$dept_cd[$idx] = str_pad($i_OneData[$idx], CODE_DIGIT_DEPT, "0", STR_PAD_LEFT);
			}
			else {
				$dept_cd[$idx] = $i_OneData[$idx];
			}
			//機種依存文字チェック
			//					if( FALSE == checkMachineCode(mb_convert_encoding($dept_cd[$idx],"utf-8", "auto"))){
			if (FALSE == checkMachineCode($dept_cd[$idx])) {
				$o_ErrMsg = "機種依存文字が指定されている組織コード" . ($idx + 1) . "が存在します。" . "ユーザーID【" . $i_OneData[3] . "】";
				return FALSE;
			}
		}
	}
	
	/*---組織コード(部)(課)(係)＋組織名を取得---*/
	$o_DeptCode = $dept_cd[0] . $dept_cd[1] . $dept_cd[2]; //3+3+3
	$o_DeptName = '';
	if (strlen($o_DeptCode) > 0) {
		//tbl_departmentに存在チェック(WebMaster以外)
		if (strcmp(WEB_MASTER_CODE, $o_DeptCode) != 0) {
			$sql = "SELECT dept_code, dept_name FROM tbl_department " . "WHERE (dept_code='" . $o_DeptCode . "')";
			$i_objDac->execute($sql);
			if (!$i_objDac->fetch()) {
				$o_ErrMsg = "存在しない組織コードが指定されているデーターが存在します。【" . $o_DeptCode . "】" . "ユーザーID【" . $i_OneData[3] . "】";
				return FALSE;
			}
			//--- 2006-11-14 M.Takano Add
			$o_DeptName = $i_objDac->fld['dept_name'];
		}
	}
	
	/*---組織レベルの取得---*/
	$dept_level = 0;
	if ((((int)$dept_cd[0]) <= 0) & (((int)$dept_cd[1]) <= 0) & (((int)$dept_cd[2]) <= 0)) {
		$dept_level = G_DEPT_LEVEL00; //AllZero ウェブマスター
	}
	else {
		if ((((int)$dept_cd[0]) > 0) & (((int)$dept_cd[1]) <= 0) & (((int)$dept_cd[2]) <= 0)) {
			$dept_level = G_DEPT_LEVEL01; //前３桁のみ指定 部に属している
		}
		else {
			if ((((int)$dept_cd[0]) > 0) & (((int)$dept_cd[1]) > 0) & (((int)$dept_cd[2]) <= 0)) {
				$dept_level = G_DEPT_LEVEL02; //３桁+３桁指定 課に属している
			}
			else {
				if ((((int)$dept_cd[0]) > 0) & (((int)$dept_cd[1]) > 0) & (((int)$dept_cd[2]) > 0)) {
					$dept_level = G_DEPT_LEVEL03; //３桁+３桁+３桁指定 係に属している
				}
				else {
					//それ以外はエラー
					$o_ErrMsg = "存在しない組織コードが指定されているデーターが存在します。【" . $o_DeptCode . "】" . "ユーザーID【" . $i_OneData[3] . "】";
					return FALSE;
				}
			}
		}
	}
	
	/*---ユーザーID $i_OneData[3] ---*/
	//必須チェック
	if ($i_ChkItemFlg[3] == 1) {
		if (strlen($i_OneData[3]) <= 0) {
			$o_ErrMsg = "ユーザーIDが指定されていないデーターが存在します。";
			return FALSE;
		}
	}
	if (strlen($i_OneData[3]) > 0) {
		//tbl_userに重複チェック
		$sql = "SELECT user_id FROM tbl_user " . "WHERE (user_id=" . $i_OneData[3] . ")";
		$i_objDac->execute($sql);
		if ($i_objDac->getRowCount() > 0) {
			$o_ErrMsg = "すでに存在するユーザーIDが指定されているデーターが存在します。【" . $i_OneData[3] . "】";
			return FALSE;
		}
	}
	//半角数値チェック
	if (!(preg_match("/^[0-9]+$/", $i_OneData[3]))) {
		$o_ErrMsg = "半角数値以外の値が指定されているユーザーIDが存在します。【" . $i_OneData[3] . "】";
		return FALSE;
	}
	
	//機種依存文字チェック
	//	if( FALSE == checkMachineCode($i_OneData[3])){
	if (FALSE == checkMachineCode($i_OneData[3])) {
		$o_ErrMsg = "機種依存文字が指定されているユーザーIDが存在します。【" . $i_OneData[3] . "】";
		return FALSE;
	}
	
	/*---ユーザー名 $i_OneData[4] ---*/
	if ($i_ChkItemFlg[4] == 1) {
		if (strlen($i_OneData[4]) <= 0) {
			$o_ErrMsg = "ユーザー名が指定されていないデーターが存在します。【" . $i_OneData[4] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
			return FALSE;
		}
	}
	//機種依存文字チェック
	//	if( FALSE == checkMachineCode($i_OneData[4])){
	if (FALSE == checkMachineCode($i_OneData[4])) {
		$o_ErrMsg = "機種依存文字が指定されているユーザー名が存在します。【" . $i_OneData[4] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
		return FALSE;
	}
	
	/*---Eメール $i_OneData[5] ---*/
	if ($i_ChkItemFlg[5] == 1) {
		if (strlen($i_OneData[5]) <= 0) {
			$o_ErrMsg = "メールアドレスが指定されていないデーターが存在します。【" . $i_OneData[5] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
			return FALSE;
		}
	}
	/*	if( strlen($i_OneData[5]) > 0 ){
		//形式チェック
		//1: 文字列先頭から@直前までに、@以外の任意の文字が１文字以上あること
		//2: @は1つだけ指定されていること。
		//3: @の後にはドット以外の文字が１文字以上あること。
		//4: ドット後に任意の文字が１文字以上あること。
//		if(FALSE == preg_match("/^[_a-z0-9-]+(￥.[_a-z0-9-]+)*@[a-z0-9-]+([￥.][a-z0-9-]+)+$/i", $i_OneData[5])){
		if(FALSE == preg_match("/^[\w\_\-][\w\_\-\.]*@[\w\_\-]+\.([\w\_\-]+\.)*\w+$/i", $i_OneData[5])){
			$o_ErrMsg = "メールアドレスとしてふさわしくない値が指定されているデーターが存在します。【" . $i_OneData[5] ."】";
			return FALSE;
		}
	}*/
	//機種依存文字チェック
	//	if( FALSE == checkMachineCode($i_OneData[5])){
	if (FALSE == checkMachineCode($i_OneData[5])) {
		$o_ErrMsg = "機種依存文字が指定されているメールアドレスが存在します。【" . $i_OneData[5] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
		return FALSE;
	}
	
	/*---ログインID $i_OneData[6] ---*/
	//必須チェック
	if ($i_ChkItemFlg[6] == 1) {
		if (strlen($i_OneData[6]) <= 0) {
			$o_ErrMsg = "ログインIDが指定されていないデーターが存在します。【" . $i_OneData[6] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
			return FALSE;
		}
	}
	if (strlen($i_OneData[6]) > 0) {
		//tbl_userに重複チェック
		$sql = "SELECT login_id FROM tbl_user " . "WHERE (login_id='" . $i_OneData[6] . "')";
		$i_objDac->execute($sql);
		if ($i_objDac->getRowCount() > 0) {
			$o_ErrMsg = "すでに存在するログインIDが指定されているデーターが存在します。【" . $i_OneData[6] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
			return FALSE;
		}
	}
	//機種依存文字チェック
	//	if( FALSE == checkMachineCode($i_OneData[6])){
	if (FALSE == checkMachineCode($i_OneData[6])) {
		$o_ErrMsg = "機種依存文字が指定されているログインIDが存在します。【" . $i_OneData[6] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
		return FALSE;
	}
	
	/*---パスワード $i_OneData[7] ---*/
	//必須チェック
	if ($i_ChkItemFlg[7] == 1) {
		if (strlen($i_OneData[7]) <= 0) {
			$o_ErrMsg = "パスワードが指定されていないデーターが存在します。【" . $i_OneData[7] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
			return FALSE;
		}
	}
	//半角英数字チェック
	if (!preg_match('/^[a-zA-Z0-9]+$/', $i_OneData[7])) $o_ErrMsg = "パスワードに使用できない文字が含まれています。使用できる文字は半角英数字のみです。【" . $i_OneData[7] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
	//機種依存文字チェック
	//	if( FALSE == checkMachineCode($i_OneData[7])){
	if (FALSE == checkMachineCode($i_OneData[7])) {
		$o_ErrMsg = "機種依存文字が指定されているパスワードが存在します。【" . $i_OneData[7] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
		return FALSE;
	}
	
	/*---権限コード $i_OneData[8] ---*/
	//必須チェック
	if ($i_ChkItemFlg[8] == 1) {
		if (strlen($i_OneData[8]) <= 0) {
			$o_ErrMsg = "権限コードが指定されていないデーターが存在します。【" . $i_OneData[8] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
			return FALSE;
		}
	}
	//権限コードチェック
	if (($i_OneData[8] != USER_CLASS_WRITER) & ($i_OneData[8] != USER_CLASS_APPROVER1) & ($i_OneData[8] != USER_CLASS_APPROVER2) & ($i_OneData[8] != USER_CLASS_APPROVER3) & ($i_OneData[8] != USER_CLASS_WEBMASTER)) {
		$o_ErrMsg = "権限コードとして認められない値が指定されているデーターが存在します。【" . $i_OneData[8] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
		return FALSE;
	}
	//機種依存文字チェック
	//	if( FALSE == checkMachineCode($i_OneData[8])){
	if (FALSE == checkMachineCode($i_OneData[8])) {
		$o_ErrMsg = "機種依存文字が指定されている権限コードが存在します。【" . $i_OneData[8] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
		return FALSE;
	}
	
	//--- 2006-11-09 Y.Adachi Add Start
	/*---公開責任者フラグ $i_OneData[9] ---*/
	if (strlen($i_OneData[9]) > 0) {
		//公開責任者フラグチェック
		if ($i_OneData[9] != G_OPEN_FLG) {
			$o_ErrMsg = "公開責任者フラグとして認められない値が指定されているデーターが存在します。【" . $i_OneData[9] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
			return FALSE;
		}
		//機種依存文字チェック
		if (FALSE == checkMachineCode($i_OneData[9])) {
			$o_ErrMsg = "機種依存文字が指定されている公開責任者フラグが存在します。【" . $i_OneData[9] . "】" . "ユーザーID【" . $i_OneData[3] . "】";
			return FALSE;
		}
		//公開責任者フラグと権限チェック
		if ($i_OneData[8] != USER_CLASS_WEBMASTER) {
			$o_ErrMsg = "公開責任者となるユーザーには、権限コード「" . USER_CLASS_WEBMASTER . "」のみ指定が可能です。" . "ユーザーID【" . $i_OneData[3] . "】";
			return FALSE;
		}
	}
	//--- 2006-11-09 Y.Adachi Add End
	

	//組織レベルと追加ユーザーのチェック
	switch ($dept_level) {
		case G_DEPT_LEVEL00 : //ウェブマスタ
			if ($i_OneData[8] != USER_CLASS_WEBMASTER) {
				//ウェブマスタのみ指定可能
				//$o_ErrMsg = "ウェブマスタ権限が、対応しない組織コードのユーザに指定されているデーターが存在します。";
				$o_ErrMsg = "ユーザーID【" . $i_OneData[3] . "】のユーザーに対して指定可能な権限コードはウェブマスタ【" . USER_CLASS_WEBMASTER . "】のみとなります。";
				return FALSE;
			}
			break;
		case G_DEPT_LEVEL01 : //部
			if ($i_OneData[8] != USER_CLASS_APPROVER3) {
				//第3承認者のみ指定可能
				//$o_ErrMsg = "第三承認者権限が、対応しない組織コードのユーザに指定されているデーターが存在します。";
				$o_ErrMsg = "ユーザーID【" . $i_OneData[3] . "】のユーザーに対して指定可能な権限コードは第3承認者【" . USER_CLASS_APPROVER3 . "】のみとなります。";
				return FALSE;
			}
			break;
		case G_DEPT_LEVEL02 : //課
			if ($i_OneData[8] != USER_CLASS_APPROVER2) {
				//第2承認者のみ指定可能
				//$o_ErrMsg = "第二承認者権限が、対応しない組織コードのユーザに指定されているデーターが存在します。";
				$o_ErrMsg = "ユーザーID【" . $i_OneData[3] . "】のユーザーに対して指定可能な権限コードは第2承認者【" . USER_CLASS_APPROVER2 . "】のみとなります。";
				return FALSE;
			}
			break;
		case G_DEPT_LEVEL03 : //係
			if (($i_OneData[8] != USER_CLASS_APPROVER1) & ($i_OneData[8] != USER_CLASS_WRITER)) {
				//ページ作成者・第一承認者のみ指定可能
				//$o_ErrMsg = "ページ作成者、もしくは、第一承認者権限が、対応しない組織コードのユーザに指定されているデーターが存在します。";
				$o_ErrMsg = "ユーザーID【" . $i_OneData[3] . "】のユーザーに対して指定可能な権限コードはページ作成者【" . USER_CLASS_WRITER . "】／第一承認者【" . USER_CLASS_APPROVER1 . "】のみとなります。";
				return FALSE;
			}
			break;
	}
	
	if (!($i_OneData[10] == FLAG_OFF || $i_OneData[10] == FLAG_ON)) {
		$o_ErrMsg = "ユーザーID【" . $i_OneData[3] . "】のユーザーに対して指定可能なソース編集フラグに不正な値が入っています。";
		return FALSE;
	}
	
	return TRUE;

}

/*-----------------------------------------------------------------------------
	tbl_userにCSVデータを追加

【引数】	$i_OneData	配列で指定されたcsvデータ（全項目)
		$o_ErrMsg	エラーメッセージ
		$i_DeptCode	結合された組織コード
		$i_objDac	DB
		
【戻値】	True	正常に終了
		False	エラー
		
【備考】
-----------------------------------------------------------------------------*/
function G_TblUserAdd($i_OneData, $i_DeptCode, $i_DeptName, $i_objDac) {
	$sql = "INSERT INTO tbl_user ( user_id, name, email, login_id, password, dept_code, dept_name, class, sourceEdit_flg, pass_last_upd, approve_edit_flg) VALUES (";
	$sql = $sql . $i_OneData[3] . ", "; //ユーザーID
	$sql = $sql . "'" . gd_addslashes($i_OneData[4]) . "'" . ", "; //ユーザー名
	$sql = $sql . "'" . gd_addslashes($i_OneData[5]) . "'" . ", "; //メアド
	$sql = $sql . "'" . gd_addslashes($i_OneData[6]) . "'" . ", "; //ログインID
	$sql = $sql . "'" . gd_addslashes($i_OneData[7]) . "'" . ", "; //パスワード
	$sql = $sql . "'" . $i_DeptCode . "'" . ", "; //組織コード
	$sql = $sql . "'" . gd_addslashes($i_DeptName) . "'" . ", "; //組織名
	$sql = $sql . $i_OneData[8] . ", "; //権限コード
	$sql = $sql . $i_OneData[10]; //ソース編集フラグ
	$sql = $sql . ", '" . date("Y/m/d H:i:s") . "',"; // パスワード最終更新日
	$sql = $sql . $i_OneData[11]; //ページ編集フラグ
	$sql = $sql . ");";
	
	//実行
	return ($i_objDac->execute($sql, "utf-8", "auto"));
}

/*-----------------------------------------------------------------------------
	tbl_handler に公開責任者権限を追加

【引数】	$i_OneData	配列で指定されたcsvデータ（全項目)
			$o_ErrMsg	エラーメッセージ
			$i_objDac	DB
		
【戻値】	True	正常に終了
			False	エラー
		
【備考】
-----------------------------------------------------------------------------*/
function G_TblHandlerAdd($i_OneData, $i_objDac) {
	
	//SQL作成
	$sql = "INSERT INTO tbl_handler ( class, item1 ) VALUES (";
	$sql = $sql . HANDLER_CLASS_OEPN_FLG . ", "; //紐付けクラス
	$sql = $sql . $i_OneData[3]; //ユーザーID
	$sql = $sql . ");";
	
	//実行
	return ($i_objDac->execute(mb_convert_encoding($sql, "utf-8", "auto")));

}

?>
