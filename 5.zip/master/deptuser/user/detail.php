<?php
/*
 * ユーザ管理　詳細画面(detail.php)
 */
$StrDbg = "";
$GLOBALS["StrDbg"] = "";

/*---------------------------------------------
	定数 
----------------------------------------------*/

//クラスイメージPath
$G_AreClassImg[] = array(
		"images/author.gif", 
		"images/approve01.gif", 
		"images/approve02.gif", 
		"images/approve03.gif", 
		"images/webmaster.gif", 
		"images/open.gif"
);
$G_AreClassImg[] = array(
		"ページ作成者", 
		"第1承認者", 
		"第2承認者", 
		"第3承認者", 
		"ウェブマスター", 
		"公開責任者"
);

//レヴェル
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


/*---------------------------------------------------------------------------------
	detail.php
---------------------------------------------------------------------------------*/

/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

/*---引数の取得---*/
$args = ($_SERVER['REQUEST_METHOD'] == 'GET') ? $_GET : $_POST;
//表示レベル
if (isset($args["user_id"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", 3, "javascript:history.back()");
	exit();
}
if (isset($args["level"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", 3, "javascript:history.back()");
	exit();
}
if (isset($args["dept_code"]) == FALSE) {
	DispError("必要なパラメーターが指定されていません。", 3, "javascript:history.back()");
	exit();
}

/*--- データアクセスクラス ---*/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*--- 指定されたユーザーの取得---*/
$sql = "SELECT tbl_user.*, tbl_department.name as dept_nm, tbl_department.level, h.item1 " . "FROM tbl_user LEFT JOIN tbl_department ON tbl_user.dept_code = tbl_department.dept_code " . "LEFT JOIN (SELECT item1 FROM tbl_handler WHERE class = " . HANDLER_CLASS_OEPN_FLG . ") AS h ON tbl_user.user_id = h.item1 " . "WHERE (user_id = " . gd_addslashes($args["user_id"]) . ")";
//取得
$objDac->execute($sql);
if ($objDac->getRowCount() <= 0) {
	DispError("指定されたユーザー情報が存在しません。", 3, "javascript:history.back()");
	exit();
}
else {
	while ($objDac->fetch()) {
		//表示データの作成
		//公開責任者でない場合は、権限コード通りの値を取得
		if (isset($objDac->fld['item1']) == FALSE || $objDac->fld['item1'] == "") {
			$DspClassImg = $G_AreClassImg[0][($objDac->fld['class'] - 1)];
			$DspClassArt = $G_AreClassImg[1][($objDac->fld['class'] - 1)];
		}
		else {
			$DspClassImg = $G_AreClassImg[0][5];
			$DspClassArt = $G_AreClassImg[1][5];
		}
		$DspUserNm = $objDac->fld['name'];
		$DspMailAdd = $objDac->fld['email'];
		$DspLogin = $objDac->fld['login_id'];
		$DspPassW = $objDac->fld['password'];
		$DeptLevel = $objDac->fld['level'];
		$UserClass = $objDac->fld['class'];
		$DeptCode = $objDac->fld['dept_code'];
		$DeptName = $objDac->fld['dept_nm'];
		$DspSourceEdit = ($objDac->fld['sourceEdit_flg'] == 1) ? 'ON' : 'OFF';
		$DspApproveEdit = ($objDac->fld['approve_edit_flg'] == 1) ? 'ON' : 'OFF';
		$DspPassLastUpd = $objDac->fld['pass_last_upd'];
	}
}

/*---ユーザーID---*/
$DspUserID = $args["user_id"];

/*---組織名称の取得---*/
$DspDeptNm = "";
if ($UserClass == USER_CLASS_WEBMASTER) {
	$DspDeptNm = "ウェブマスター";
}
else {
	$DspDeptName = "";
	$dept_01 = substr($DeptCode, 0, CODE_DIGIT_DEPT); //組織コード１の切り出し
	$dept_01 = str_pad($dept_01, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
	switch ($DeptLevel) {
		case G_DEPT_LEVEL01 : //部
			$DspDeptNm = htmlspecialchars($DeptName);
			break;
		case G_DEPT_LEVEL02 : //課
			$sql = "SELECT tbl_department.dept_code, tbl_department.name " . "FROM tbl_department " . "WHERE (((tbl_department.dept_code)='" . $dept_01 . "'))" . "ORDER BY tbl_department.dept_code";
			//取得
			$objDac->execute($sql);
			//部 + 課
			while ($objDac->fetch()) {
				$DspDeptNm = htmlspecialchars($objDac->fld['name']) . " &gt; " . htmlspecialchars($DeptName);
			}
			break;
		case G_DEPT_LEVEL03 : //係
			$dept_02 = substr($DeptCode, 0, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT)); //組織コード2の切り出し
			$dept_02 = str_pad($dept_02, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
			$sql = "SELECT tbl_department.dept_code, tbl_department.name as dept_nm01, tbl_department_1.dept_code, tbl_department_1.name as dept_nm02 " . "FROM tbl_department, tbl_department AS tbl_department_1 " . "WHERE (((tbl_department.dept_code)='" . $dept_01 . "') AND ((tbl_department_1.dept_code)='" . $dept_02 . "'))";
			"ORDER BY tbl_department.dept_code";
			//取得
			$objDac->execute($sql);
			//部 + 課 + 係
			while ($objDac->fetch()) {
				$DspDeptNm = htmlspecialchars($objDac->fld['dept_nm01']) . " &gt; " . htmlspecialchars($objDac->fld['dept_nm02']) . " &gt; " . htmlspecialchars($DeptName);
			}
			break;
	}
}

//削除の可否を取得
//削除可否フラグ 初期は可
$UserDeleteFlg = true;
//SQL文の作成（work・publishにある、表示するユーザが作成したページを取得）
$tbl_array = array(
		'tbl_publish_page', 
		'tbl_work_page'
);
foreach ($tbl_array as $tbl_name) {
	$sql = "SELECT page_id FROM " . $tbl_name . " WHERE " . $objDac->_addslashesC('user_id', $DspUserID, '=', 'INT');
	$objDac->execute($sql);
	//表示するユーザが作成したページがある場合は、削除不可
	if ($objDac->getRowCount() != 0) {
		$UserDeleteFlg = false;
		break;
	}
}

//戻り先URL
$deptInfo = getDeptCode($args["dept_code"]);
$DspBackURL = "../index.php?dept_code=" . $args["dept_code"];

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ユーザー情報詳細</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="user.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxGo(bv) {
	$('behavior').value = bv;
	if (bv == 2) {
		$('form').action = 'edit.php';
	} else if (bv == 3) {
		$('form').action = 'confirm.php';
	} else {
		alert('パラメータエラー（behavior）');
		return false;
	}
	document.form.submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'deptuser';
include (APPLICATION_ROOT . "/common/inc/master_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-user">
<div><img src="images/bar_detail.jpg" alt="ユーザー情報詳細" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<p align="left" id="cms8341-pankuzu"><?=$DspDeptNm?></p>
<p align="left"><img src="<?=$DspClassImg?>" alt="<?=$DspClassArt?>"
	width="100" height="20"></p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="150" align="left" valign="top" scope="row">ユーザーID</th>
		<td align="left" valign="top"><?=htmlspecialchars($DspUserID)?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">ユーザー名</th>
		<td align="left" valign="top"><?=htmlspecialchars($DspUserNm)?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">メールアドレス</th>
		<td align="left" valign="top"><?=htmlspecialchars($DspMailAdd)?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">ログインID</th>
		<td align="left" valign="top"><?=htmlspecialchars($DspLogin)?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">パスワード</th>
		<td align="left" valign="top"><?=htmlspecialchars($DspPassW)?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">パスワード最終変更日</th>
		<td align="left" valign="top"><?=htmlspecialchars($DspPassLastUpd)?></td>
	</tr>
<?php
if ($UserClass != USER_CLASS_WEBMASTER) {
	?>
<tr>
		<th width="150" align="left" valign="top" scope="row">ソースモード</th>
		<td align="left" valign="top"><?=$DspSourceEdit?></td>
	</tr>
<?php
	if ($UserClass != USER_CLASS_WRITER) {
		?>
<tr>
		<th width="150" align="left" valign="top" scope="row">ページ編集権限</th>
		<td align="left" valign="top"><?=$DspApproveEdit?></td>
	</tr>
<?php
	}
	?>
<?php
}
?>
</table>
<p align="center"><a href="javascript:" onClick="return cxGo(2)"><img
	src="<?=RPW?>/admin/master/images/btn_fix.jpg" alt="修正" width="150"
	height="20" border="0" style="margin-right: 10px"></a>
<?php
if ($UserDeleteFlg) {
	?>
<a href="javascript:" onClick="return cxGo(3);"><img
	src="<?=RPW?>/admin/master/images/btn_del.jpg" alt="削除" width="150"
	height="20" border="0" style="margin-right: 10px"></a>
<?php
}
else {
	?>
<img src="<?=RPW?>/admin/master/images/btn_del_off.jpg" alt="削除"
	width="150" height="20" border="0" style="margin-right: 10px">
<?php
}
?>
<a href="<?=$DspBackURL?>"><img
	src="<?=RPW?>/admin/master/images/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<form id="form" class="cms8341-form" name="form" action="" method="post">
<input type="hidden" id="user_id" name="user_id"
	value="<?=htmlspecialchars($DspUserID)?>"> <input type="hidden"
	id="behavior" name="behavior" value=""></form>
</div>
</body>
</html>
