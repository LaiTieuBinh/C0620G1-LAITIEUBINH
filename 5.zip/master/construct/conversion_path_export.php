<?php
/*
 * 自動リンクページ情報エクスポート処理
 */
//見出し文字
$head_str = "\"変換前\",\"変換後\"\n";

//--- 設定ファイル読み込み
require ("./.htsetting");
global $objCnc;

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/b_dac.inc');
$objDac = new b_dac($objCnc);
$objDac->setTableName("tbl_conversion_path");

// データ取得
$objDac->select();
if ($objDac->getRowCount() <= 0) {
	DispError("変換パス情報が一件も登録されていません。", 3, "javascript:history.back()");
	exit();
}

// CSV内容生成
$output_str = $head_str;
while ($objDac->fetch()) {
	$output_str .= csvWrite($objDac->fld["before"]);
	$output_str .= "," . csvWrite($objDac->fld["after"]);
	$output_str .= "\n";
}

/*---一覧画面へと戻る---*/
header("Content-Disposition: attachment; filename=conversion_path.csv");
header('Content-type: text/comma-separated-values');

// SHIFT_JISに変換して出力
print UTF8toSJIS($output_str);

?>
