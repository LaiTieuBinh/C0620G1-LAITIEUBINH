<?php
/*
 *
 */

//--- 設定ファイル読み込み
require ("../.htsetting");

$define = (isset($_GET['target'])) ? $_GET['target'] : 'PUBLISH';
if (!defined('MAIL_BODY_' . $define) || !defined('MAIL_SUBJECT_' . $define)) {
	DispError("パラメータが不正です。", 2, "javascript:history.back()");
	exit();
}
$body = constant('MAIL_BODY_' . $define);
$subject = constant('MAIL_SUBJECT_' . $define);
$MAIL_INFO_ARY = getDefineArray('MAIL_INFO_ARY');
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>メール設定</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<script><!--
function disp(){
	var btn_ele = document.getElementById('rep_disp');
	var ele = document.getElementById('rep_info');
	if(ele.style.display == 'none'){
		ele.style.display = 'block';
		btn_ele.value = '非表示';
	}
	else{
		ele.style.display = 'none';
		btn_ele.value = '置換文字一覧表示';
	}
}
//--></script>
</head>

<body id="cms8341-mainbg">
<div align="center" id="cms8341-user">
<div class="cms8341-area-corner">
<form id="mail_form" class="cms8341-form" name="mail_form" method="post"
	action="submit.php">
<p><?=mkcombobox($MAIL_INFO_ARY, 'cms_mail', $define, 'location.href=\'./index.php?target=\'+this.value')?></p>

<input id="rep_disp" type="button" value="置換文字一覧表示" onclick="disp();">
<div id="rep_info" style="display: none;">
<table width="100%" border="1" cellpadding="1" cellspacing="0">
	<tr>
		<th>分岐処理</th>
		<td>&lt;!--%IF_EXIST NAME=@@●●●@@%--&gt;<br>
		@@●●●@@に値が存在した場合に表示される所<br>
		&lt;!--%ELSE%--><br>
		@@●●●@@に値が存在しない場合に表示される所<br>
		&lt;!--%END IF_EXIST NAME=@@●●●@@%--&gt;<br>
		</td>
	</tr>
	<tr>
		<th>繰り返し処理</th>
		<td>&lt;!--%LOOP NAME=@@●●●@@%--&gt;<br>
		繰り返し表示される所<br>
		@@～@@##～## → ※(@@～@@は共通の置換アイテム、##～##は繰り返し処理内の置換アイテム)<br>
		&lt;!--%END LOOP NAME=@@●●●@@%--&gt;<br>
		</td>
	</tr>
	<tr>
		<th>日付フォーマット指定</th>
		<td>% ～ %内に日付のフォーマット指定ができます。<br>
		【例】@@publish_start%Y年m月j日H時%@@ → 2010年6月24日11時</td>
	</tr>
</table>
<table width="100%" border="1" cellpadding="1" cellspacing="0">
	<tr>
		<th>置換文字</th>
		<th>置換内容</th>
	</tr>
	<tr>
		<td>@@url@@</td>
		<td>公開側URL</td>
	</tr>
	<tr>
		<td>@@cms_url@@</td>
		<td>CMS側URL</td>
	</tr>
	<tr>
		<td>@@now_date@@</td>
		<td>現在時刻</td>
	</tr>
	<tr>
		<td>@@dept_name@@</td>
		<td>対象組織名</td>
	</tr>
	<tr>
		<td>@@user_name@@</td>
		<td>対象ユーザ名</td>
	</tr>
	<tr>
		<td>@@login_dept_name@@</td>
		<td>ログインユーザ組織名</td>
	</tr>
	<tr>
		<td>@@login_user_name@@</td>
		<td>ログインユーザ名</td>
	</tr>
	<tr>
		<td>@@request_dept_name@@</td>
		<td>確認依頼した組織名</td>
	</tr>
	<tr>
		<td>@@request_user_name@@</td>
		<td>確認依頼したユーザ名</td>
	</tr>
	<tr>
		<td>@@group_name@@</td>
		<td>確認グループ名</td>
	</tr>
	<tr>
		<td>@@approve_name@@</td>
		<td>確認者名</td>
	</tr>
	<tr>
		<td>@@approve_note@@</td>
		<td>依頼内容</td>
	</tr>
	<tr>
		<td>@@denail_note@@</td>
		<td>差し戻し理由</td>
	</tr>
	<tr>
		<td>@@skip_status@@</td>
		<td>スキップ確認後のステータス</td>
	</tr>
	<tr>
		<td>@@request_page_group@@</td>
		<td>確認依頼ページ(配列) 【@@request_page_group@@の繰り返し処理内に使える置換文字】<br>
		※##work_class##・・・依頼ステータス(新規/更新/非公開依頼/削除依頼)<br>
		※##page_title##・・・対象ページタイトル<br>
		※##file_path##・・・対象ページファイルパス<br>
		※##user_name##・・・対象ページ最終更新者</td>
	</tr>

	<tr>
		<td>@@publish_start@@</td>
		<td>対象ページ公開開始日</td>
	</tr>
	<tr>
		<td>@@publish_end@@</td>
		<td>対象ページ公開終了日</td>
	</tr>
	<tr>
		<td>@@page_title@@</td>
		<td>対象ページタイトル</td>
	</tr>
	<tr>
		<td>@@file_path@@</td>
		<td>対象ページファイルパス</td>
	</tr>
	<tr>
		<td>@@mobile_file_path@@</td>
		<td>携帯用ページファイルパス</td>
	</tr>
	<tr>
		<td>@@work_class@@</td>
		<td>対象ページの状態(新規/更新)</td>
	</tr>
	<tr>
		<td>@@dellink_page_title@@</td>
		<td>リンク切れの起こるページタイトル</td>
	</tr>
	<tr>
		<td>@@dellink_file_path@@</td>
		<td>リンク切れの起こるページファイルパス</td>
	</tr>
	<tr>
		<td>@@dept_tel@@</td>
		<td>対象組織電話番号</td>
	</tr>
	<tr>
		<td>@@questioner_name@@</td>
		<td>FAQ質問者名前</td>
	</tr>
	<tr>
		<td>@@question_context@@</td>
		<td>FAQ質問内容</td>
	</tr>
	<tr>
		<td>@@answer_context@@</td>
		<td>FAQ回答内容</td>
	</tr>
	<tr>
		<td>@@faq_regist_datatime@@</td>
		<td>お問い合わせ日時</td>
	</tr>
	<tr>
		<td>@@question_title@@</td>
		<td>お問い合わせ内容</td>
	</tr>
	<tr>
		<td>@@faq_comment@@</td>
		<td>お問い合わせ振分時コメント内容</td>
	</tr>
	<tr>
		<td>@@output_name@@</td>
		<td>外部出力先</td>
	</tr>
	<tr>
		<td>@@question_title_group@@</td>
		<td>お問い合わせタイトル一覧(配列)<br>
		【@@question_title_group@@の繰り返し処理内に使える置換文字】<br>
		※##question_title##・・・お問い合わせタイトル</td>
	</tr>
	<tr>
		<td>@@target_dept_name@@</td>
		<td>自動リンクチェック対象組織</td>
	</tr>
	<tr>
		<td>@@page_group_info@@</td>
		<td>公開終了ページが近いページ一覧(配列)<br>
		【@@page_group_info@@の繰り返し処理内に使える置換文字】<br>
		※##page_title##・・・対象ページタイトル<br>
		※##file_path##・・・対象ページファイルパス<br>
		※##user_name##・・・対象ページ最終更新者<br>
		※##publish_start##・・・対象ページ公開開始日<br>
		※##publish_end##・・・対象ページ公開終了日</td>
	</tr>



</table>

</div>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="150" align="left" valign="top" scope="row">件名<span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle"><input id="name"
			name="cms_key_MAIL_SUBJECT_<?=$define?>"
			id="cms_key_MAIL_SUBJECT_<?=$define?>" type="text"
			style="width: 500px" value="<?=htmlspecialchars($subject)?>"></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">本文<span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle"><textarea
			name="cms_key_MAIL_BODY_<?=$define?>" rows="30"
			id="cms_key_MAIL_BODY_<?=$define?>" style="width: 700px;"><?=htmlspecialchars($body)?></textarea>
		</td>
	</tr>
</table>
<br>
<input type="submit" value="設定変更"></form>
</div>
</div>
</body>
</html>