<?php
/*
 *
 */

//--- 設定ファイル読み込み
require ("../.htsetting");
$dir = APPLICATION_ROOT . '/common/';
$setting_vars = $dir . 'setting_mail.inc';
$contents = file_get_contents($setting_vars);
$add_contents = "";

foreach ($_POST as $key => $val) {
	if (strpos($key, "cms_key_") === FALSE) continue;
	$key = str_replace("cms_key_", "", $key);
	//HTMLエスケープ解除
	$val = htmlspecialchars_decode($val);
	//特殊文字エスケープ
	if (ini_get('magic_quotes_gpc') != 1 && strtolower(ini_get('magic_quotes_gpc')) != 'on') {
		$target_str = array(
				"\\", 
				'"', 
				'$'
		);
		$rep_str = array(
				"\\\\", 
				'\"', 
				'\$'
		);
		$val = str_replace($target_str, $rep_str, $val);
	}
	//改行コードを文字列にする
	$target_str = array(
			"\r\n", 
			"\n"
	);
	$val = str_replace($target_str, '\n', $val);
	if (strpos($contents, 'define("' . $key . '"') !== FALSE) {
		$contents = preg_replace('/define\("' . $key . '"(\s*?)?,(\s*?)?".*"\);/i', 'define("' . $key . '","' . str_replace('\\', '\\\\', $val) . '");', $contents);
	}
	else {
		$add_contents = "\t" . 'define("' . $key . '","' . $val . '");';
	}
}
$pos = strrpos($contents, "?>");
$rep_str = ($add_contents != "") ? $add_contents . "\n?>" : $add_contents . "?>";
$contents = substr_replace($contents, $rep_str, $pos);

//ファイルを開く
if (!($fp = fopen($setting_vars, "w"))) {
	user_error("設定ファイルの読み込みに失敗");
}

fwrite($fp, $contents);
fclose($fp);

header("Location: ./index.php?target=" . $_POST['cms_mail']);
exit();
?>
