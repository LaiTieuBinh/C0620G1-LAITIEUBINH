<?php
/*
 * 自動リンク情報エクスポート処理
 */
//見出し文字
$head_str = "自動リンクID,自動リンク名称,RSS出力フラグ,RSSファイル名,デザイン設定,カテゴリコード,抽出条件,抽出方法,表示順,抽出件数,権限\n";

//--- 設定ファイル読み込み
require ("./.htsetting");
global $objCnc;

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_auto_link.inc');
$objAutoLink = new tbl_auto_link($objCnc);

// カラム取得
$column_ary = $objAutoLink->getColumn();

// データ取得
$objAutoLink->select();
if ($objAutoLink->getRowCount() <= 0) {
	DispError("自動リンク情報が一件も登録されていません。", 3, "javascript:history.back()");
	exit();
}

// CSV内容生成
$output_str = $head_str;
while ($objAutoLink->fetch()) {
	foreach ($column_ary as $column) {
		$output_str .= csvWrite($objAutoLink->fld[$column]) . ",";
	}
	$output_str .= "\n";
}

/*---一覧画面へと戻る---*/
header("Content-Disposition: attachment; filename=autolink.csv");
header('Content-type: text/comma-separated-values');

// SHIFT_JISに変換して出力
print UTF8toSJIS($output_str);

?>
