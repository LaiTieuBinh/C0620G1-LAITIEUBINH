<?php
/*
 * サイトトップページ（index.html）の作成
 */
//--- 設定ファイル読み込み
require ("./.htsetting");

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
//print_dp($_POST);


$aryClasses = array(
		0, 
		1, 
		2, 
		3, 
		4
);

if (!$_POST['auto_link'] || !array(
		$_POST['auto_link']
)) {
	user_error('不正なアクセスです。');
}
$aryInsert = array();
$err = array();
foreach ($_POST['auto_link'] as $idx => $ary) {
	$vals = array_values(array_unique($ary));
	if (count($vals) == 1 && $vals[0] == '') continue;
	if ($ary['name'] == '') $err[] = 'nameが入力されていない行があります。【' . ($idx + 1) . '行目】';
	if ($ary['class'] == '') $err[] = 'classが入力されていない行があります。【' . ($idx + 1) . '行目】';
	elseif (!in_array($ary['class'], $aryClasses)) $err[] = '値が正しくないclassの入力があります。【' . ($idx + 1) . '行目】';
	elseif ($ary['class'] == 0) {
		if ($ary['page_id'] == '') $err[] = 'page_idが入力されていない行があります。【' . ($idx + 1) . '行目】';
		elseif (!preg_match('/^\d+$/', $ary['page_id'])) $err[] = 'page_idは半角数値で入力してください。【' . ($idx + 1) . '行目】';
		elseif (!_page_exists($ary['page_id'], $objDac)) $err[] = '入力されたpage_idは登録されていません。【' . ($idx + 1) . '行目】';
	}
	else
		$ary['page_id'] = 'NULL';
	if ($ary['sort_order'] == '') $err[] = 'sort_orderが入力されていない行があります。【' . ($idx + 1) . '行目】';
	elseif (!preg_match('/^\d+$/', $ary['sort_order'])) $err[] = 'sort_orderは半角数値で入力してください。【' . ($idx + 1) . '行目】';
	$aryInsert[] = $ary;
}
if (count($err) > 0) {
	user_error(implode('<br>', $err));
}

// トランザクション開始
$objCnc->begin();

// 全件削除
$sql = "DELETE FROM tbl_auto_link";
if ($objDac->execute($sql) === FALSE) {
	//ロールバック
	$objCnc->rollback();
	user_error('自動リンク情報の削除に失敗しました。');
}

// 登録
foreach ($aryInsert as $idx => $ary) {
	$sql = "INSERT INTO tbl_auto_link VALUES (" . " " . ($idx + 1) . ", '" . $ary['name'] . "'" . ", " . $ary['class'] . ", " . $ary['page_id'] . ", " . $ary['sort_order'] . " )";
	if ($objDac->execute($sql) === FALSE) {
		//ロールバック
		$objCnc->rollback();
		user_error('自動リンク情報の登録に失敗しました。');
	}
}

// コミット
$objCnc->commit();

function _page_exists($pid, $objDac) {
	$sql = "SELECT page_id FROM tbl_publish_page WHERE page_id = " . $pid;
	$objDac->execute($sql);
	return $objDac->fetch();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>自動リンク先の登録</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
</head>

<body id="cms8341-mainbg">
<div id="cms8341-headarea">
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	id="cms8341-header">
	<tr>
		<td align="left" valign="top"><img src="<?=DIR_PATH_LOGO_MENU?>"
			alt="<?=ALT_LOGO_MENU?>" width="330" height="41"></td>
		<td width="110" align="right" valign="top"><img
			src="<?=DIR_PATH_LOGO_CMSMENU?>" alt="<?=ALT_LOGO_CMSMENU?>"
			width="110" height="41"></td>
	</tr>
</table>
</div>
<div align="center" id="cms8341-user">
<div class="cms8341-area-corner">
<div align="center">
<table border="0" cellspacing="0" cellpadding="5">
	<tr>
		<td align="left">
		<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable">
			<tr>
				<th align="center">自動リンク先の登録</th>
			</tr>
			<tr>
				<td align="center">
				<p>自動リンク先を登録しました。</p>
				<p>[<a href="./index.php"> データ初期設定INDEXへ </a></p>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</div>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</body>
</html>
