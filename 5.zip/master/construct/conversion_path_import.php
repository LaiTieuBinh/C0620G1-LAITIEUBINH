<?php
/*
 * 自動リンクページ情報インポート処理
 */

/*===================================================================================
	移行ツール　変換パス情報のインポート(conversion_path_import.php)
	
	指定されたcsvファイルをtbl_conversion_pathに登録する
===================================================================================*/

//--- 設定ファイル読み込み
require ("./.htsetting");
global $objCnc;

/*---------------------------------------------
	定数 
----------------------------------------------*/

//csvファイルupload先
define("CSV_UPLOAD", "./tmp/");
//csvファイル最大行
define("G_CSV_MAX_LINE", 20000);
//項目のチェック
define("THROUGH", 0); // スルー
define("CHECK", 1); // チェック
//need　→　必須, ext→拡張子のチェック, unique →　カラム内の重複チェック, another_unique → 別のカラムとの重複チェック
$column_ary['before'] = array(
		"no" => 0, 
		"need" => CHECK, 
		'ext' => THROUGH, 
		'unique' => CHECK, 
		'another_unique' => CHECK, 
		'name' => "変換前パス"
);
$column_ary['after'] = array(
		"no" => 1, 
		"need" => CHECK, 
		'ext' => CHECK, 
		'unique' => THROUGH, 
		'another_unique' => CHECK, 
		'name' => "変換後パス"
);
//csv項目数
define("G_CSV_ITEM_MAX", count($column_ary));
//登録可能拡張子(カンマ区切りで指定)
define("EXTENSIONS_CONVERSION_PATH", 'html,htm');

/*---------------------------------------------------------------------------------
conversion_path_import.php
---------------------------------------------------------------------------------*/

//---引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError("インポートをするcsvファイルを指定してください。", 2, "javascript:history.back()");
	exit();
}
//---ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError("csvファイルのファイルサイズが0バイトです。", 2, "javascript:history.back()");
	exit();
}

//---アップロード
$frmCsvFnm = CSV_UPLOAD . $frmCsvFnm;
if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $frmCsvFnm) == FALSE) {
	DispError("csvファイルのアップロードに失敗しました。", 2, "javascript:history.back()");
	exit();
}
//(念のため)ファイル存在チェック
if (file_exists($frmCsvFnm) == FALSE) {
	$wk_str = "指定されたファイル【" . $frmCsvFnm . "】が存在しません。";
	DispError($wk_str, 2, "javascript:history.back()");
	exit();
}

// トランザクション開始
$objCnc->begin();

// CSVファイルをUTF-8として読み込む
$CsvFno = csvRead_UTF8($frmCsvFnm);

//一行目は飛ばす
$data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE);

//EOFになるまで読み出し
$err_msg = "";
$line = 1;
$upd_ary = array();
while ($data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
	$line++;
	//各項目のチェック
	if (check_item($data, $column_ary, $line, $err_msg) === FALSE) continue;
	//DB登録用データ
	$upd_ary[] = create_upd_ary($data, $column_ary);
}
//重複のチェック
check_repetition($upd_ary, $column_ary, $err_msg);
//エラーがあった場合
if ($err_msg != "") disp_err($err_msg, $objCnc, $CsvFno, $frmCsvFnm);
//ファイルClose
fclose($CsvFno);
//ファイルを削除
if (unlink($frmCsvFnm) == FALSE) {
	disp_err("csvファイルの削除に失敗しました。", $objCnc, $CsvFno, $frmCsvFnm);
}
// DBへ登録
exec_upd($upd_ary);
// コミット
$objCnc->commit();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>変換パス情報インポート</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
</head>

<body id="cms8341-mainbg">
<div id="cms8341-headarea">
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	id="cms8341-header">
	<tr>
		<td align="left" valign="top"><img src="<?=DIR_PATH_LOGO_MENU?>"
			alt="<?=ALT_LOGO_MENU?>" width="330" height="41"></td>
		<td width="110" align="right" valign="top"><img
			src="<?=DIR_PATH_LOGO_CMSMENU?>" alt="<?=ALT_LOGO_CMSMENU?>"
			width="110" height="41"></td>
	</tr>
</table>
</div>
<div align="center" id="cms8341-user">
<div class="cms8341-area-corner">
<div align="center">
<table border="0" cellspacing="0" cellpadding="5">
	<tr>
		<td align="left">
		<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable">
			<tr>
				<th align="center">変換パス情報のインポート</th>
			</tr>
			<tr>
				<td align="center">
				<p>変換パス情報をインポートしました。</p>
				<p>[<a href="./index.php"> データ初期設定INDEXへ </a>]</p>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</div>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</body>
</html>
<?php
/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/

/**
 * 挿入用の配列を作成する
 * @param $data       １行分のCSV内容
 * @param $column_ary 項目の配列
 * @return 挿入用の配列
 * 
 */
function create_upd_ary($data, $column_ary) {
	$ret = array();
	foreach ($column_ary as $column => $info) {
		//存在チェック
		if (!isset($data[$info["no"]]) || $data[$info["no"]] == "") continue;
		//格納
		$ret[$column] = $data[$info["no"]];
	}
	return $ret;
}
/**
 * 項目のチェックを行う
 * @param $data       １行分のCSV内容
 * @param $column_ary 項目の配列
 * @param $line       読み込み行番号
 * @param $err_msg    エラーメッセージ
 * @return TRUE:FALSE
 * 
 */
function check_item($data, $column_ary, $line, &$err_msg) {
	foreach ($column_ary as $column => $info) {
		if ($info["need"] == THROUGH && $info["need"] == THROUGH) continue;
		//必須チェック
		if ($info["need"] == CHECK) {
			if (!isset($data[$info["no"]]) || $data[$info["no"]] == "") {
				$err_msg .= $info["name"] . "が指定されていないデータが存在します。【" . $line . "行目】<br>";
				continue;
			}
		}
		//拡張子のチェック
		if ($info["ext"] == CHECK) {
			$path_info = pathinfo($data[$info["no"]]);
			if (!isset($path_info['extension'])) {
				$err_msg .= $info['name'] . "は、拡張子まで指定してください。【" . $line . "行目】<br>";
				continue;
			}
			else if (!in_array($path_info['extension'], explode(',', EXTENSIONS_CONVERSION_PATH))) {
				$err_msg .= "拡張子は、" . EXTENSIONS_CONVERSION_PATH . "を指定してください。【" . $line . "行目】<br>";
				continue;
			}
		}
	}
	return ($err_msg == "") ? TRUE : FALSE;
}
/**
 * 配列の重複している要素を取得する
 * @param $ary    配列
 * @return 重複している要素の配列
 * 
 */
function get_not_unique($ary) {
	//リターン値
	$ret = array();
	//値の数をカウント
	$v_cnt_ary = @array_count_values($ary);
	//重複している値をリターン配列に格納
	foreach ($v_cnt_ary as $val => $cnt) {
		if ($cnt == 1) continue;
		$ret[] = $val;
	}
	return $ret;
}
/**
 * 重複している値のチェックを行う
 * @param $upd_ary 		挿入用配列
 * @param $column_ary 	項目の配列
 * @param $err_msg    	エラーメッセージ
 * @return なし
 * 
 */
function check_repetition($upd_ary, $column_ary, &$err_msg) {
	//カラム同士の重複チェック用
	$check_ary = array();
	//重複行格納用配列
	$repetition_ary = array();
	//対象カラム数分ループ
	foreach ($column_ary as $column => $info) {
		//スルー
		if ($info["unique"] == THROUGH && $info["another_unique"] == THROUGH) continue;
		//初期化
		$unique_ary = array();
		//チェック対象配列に格納
		foreach ($upd_ary as $val) {
			if (!isset($val[$column])) continue;
			$unique_ary[] = $val[$column];
		}
		//カラム単位の重複チェック
		if ($info["unique"] == CHECK) $repetition_ary = array_merge($repetition_ary, get_not_unique($unique_ary));
		//カラム内の重複削除
		else $unique_ary = array_unique($unique_ary);
		//格納
		if ($info["another_unique"] == CHECK) $check_ary = array_merge($check_ary, $unique_ary);
	}
	//カラム同士の重複行のチェック
	$repetition_ary = array_merge($repetition_ary, get_not_unique($check_ary));
	//重複行数分ループ
	foreach (array_unique($repetition_ary) as $val) {
		$err_msg .= "重複しているデータが存在します。【" . htmlDisplay($val) . "】<br>";
	}
}

/**
 * 変換情報を更新する
 * @param $upd_ary   挿入用の配列
 * 
 */
function exec_upd($upd_ary) {
	global $objCnc;
	// データアクセスクラス
	require_once (APPLICATION_ROOT . '/common/dbcontrol/b_dac.inc');
	$objDac = new b_dac($objCnc);
	$objDac->setTableName("tbl_conversion_path");
	// 既存データの削除
	if ($objDac->delete() === FALSE) {
		disp_err("変換パス情報のインポートに失敗しました。", $objCnc);
	}
	// DBへ登録
	foreach ($upd_ary as $ary) {
		//SQL作成
		$fields = array();
		$values = array();
		foreach ($ary as $k => $v) {
			$fields[] = "`" . $k . "`";
			$values[] = $objDac->_addslashes($v, "TEXT");
		}
		$sql = "INSERT INTO " . $objDac->table_name . " (" . implode(", ", $fields) . " ) VALUES (" . implode(", ", $values) . " )";
		//実行
		if ($objDac->execute($sql) === TRUE) continue;
		//失敗
		disp_err("変換パス情報のインポートに失敗しました。", $objCnc);
	}
}

/**
 * エラー画面表示
 * 
 */
function disp_err($err_msg, $objCnc, $CsvFno = NULL, $frmCsvFnm = NULL) {
	// ロールバック
	$objCnc->rollback();
	// ファイルClose
	if ($CsvFno !== NULL) fclose($CsvFno);
	// ファイルを削除
	if ($CsvFno !== NULL) unlink($frmCsvFnm);
	// エラーページの表示
	DispError($err_msg, 2, "javascript:history.back()");
	exit();
}

?>
