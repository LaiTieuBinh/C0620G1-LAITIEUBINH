<?php
/*
 *
 */
//--- 設定ファイル読み込み
require ("./.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="Content-Style-Type" content="text/css">
		<meta http-equiv="Content-Script-Type" content="text/javascript">
		<title>データ初期設定INDEX</title>
		<link rel="stylesheet" href="<?php echo(RPW); ?>/admin/style/shared.css" type="text/css">
	</head>
	<body id="cms8341-mainbg">
		<div id="cms8341-headarea">
			<table width="100%" border="0" cellspacing="0" cellpadding="0" id="cms8341-header">
				<tr>
					<td align="left" valign="top"><img src="<?=DIR_PATH_LOGO_MENU?>" alt="<?=ALT_LOGO_MENU?>" width="330" height="41"></td>
					<td width="110" align="right" valign="top"><img src="<?=DIR_PATH_LOGO_CMSMENU?>" alt="<?=ALT_LOGO_CMSMENU?>" width="110" height="41"></td>
				</tr>
			</table>
		</div>
		<div align="center" id="cms8341-user">
			<div class="cms8341-area-corner">
				<div align="center">
					<table border="0" cellspacing="0" cellpadding="5">
						<tr>
							<td align="left">
								<form method="post" action="<?php echo(RPW); ?>/admin/master/construct/category_import.php" enctype="multipart/form-data">
									<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
										<tr>
											<th>分類情報のインポート</th>
										</tr>
										<tr>
											<td>
												<input name="FrmCsvnm" type="file" style="width: 540px"><br>
												<input type="image" src="<?php echo(RPW); ?>/admin/master/images/btn_start.jpg" alt="取り込み開始" width="150" height="20" border="0" style="margin-right: 10px">
											</td>
										</tr>
									</table>
								</form>
								<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
									<tr>
										<th>分類情報のエクスポート</th>
									</tr>
									<tr>
										<td><a href="<?php echo(RPW); ?>/admin/master/construct/category_export.php">category.csv</a></td>
									</tr>
								</table>
								<br>
								<form method="post" action="<?php echo(RPW); ?>/admin/master/construct/autolink_import.php" enctype="multipart/form-data">
									<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
										<tr>
											<th>自動リンクのインポート</th>
										</tr>
										<tr>
											<td>
												<input name="FrmCsvnm" type="file" style="width: 540px"><br>
												<input type="image" src="<?php echo(RPW); ?>/admin/master/images/btn_start.jpg" alt="取り込み開始" width="150" height="20" border="0" style="margin-right: 10px">
											</td>
										</tr>
									</table>
								</form>
								<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
									<tr>
										<th>自動リンクのエクスポート</th>
									</tr>
									<tr>
										<td><a href="<?php echo(RPW); ?>/admin/master/construct/autolink_export.php">autolink.csv</a></td>
									</tr>
								</table>
								<form method="post" action="<?php echo(RPW); ?>/admin/master/construct/conversion_path_import.php" enctype="multipart/form-data">
									<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
										<tr>
											<th>変換パス情報のインポート</th>
										</tr>
										<tr>
											<td>
												<input name="FrmCsvnm" type="file" style="width: 540px"><br>
												<input type="image" src="<?php echo(RPW); ?>/admin/master/images/btn_start.jpg" alt="取り込み開始" width="150" height="20" border="0" style="margin-right: 10px">
											</td>
										</tr>
									</table>
								</form>
								<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
									<tr>
										<th>変換パス情報のエクスポート</th>
									</tr>
									<tr>
										<td><a href="<?php echo(RPW); ?>/admin/master/construct/conversion_path_export.php">conversion_path.csv</a></td>
									</tr>
								</table>
								<br>
								<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
									<tr>
										<th>メール設定</th>
									</tr>
									<tr>
										<td><a href="<?php echo(RPW); ?>/admin/master/construct/mailsetting/index.php">メール設定画面へ</a></td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</div>
			</div>
			<div><img src="<?php echo(RPW); ?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10"></div>
		</div>
	</body>
</html>
