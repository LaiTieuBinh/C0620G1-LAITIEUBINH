<?php
/*
 * カテゴリ管理　カテゴリ情報のエクスポート(export.php)
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/
//見出し文字
$G_SetHead = explode(",", "分類コード1,分類コード2,分類コード3,分類コード4,分類名,表示順");

/*---------------------------------------------------------------------------------
	export.php
---------------------------------------------------------------------------------*/

//--- 設定ファイル読み込み
require ("./.htsetting");
global $objCnc;

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*---CSVファイルの作成---*/
//tbl_categoryの取得
$sql = "SELECT * FROM tbl_category ORDER BY cate_code, level, cate_id";
$objDac->execute($sql);
if ($objDac->getRowCount() <= 0) {
	DispError("分類情報が一件も登録されていません。", 3, "javascript:history.back()");
	exit();
}
//カテゴリ情報の作成
//見出し
$AllExpCavData = array();
while ($objDac->fetch()) {
	$ExpCavData = array();
	//カテゴリコード1
	$ExpCavData[] = substr($objDac->fld['cate_code'], 0, CODE_DIGIT_CATE);
	//カテゴリコード2
	$ExpCavData[] = substr($objDac->fld['cate_code'], CODE_DIGIT_CATE, CODE_DIGIT_CATE);
	//カテゴリコード3
	$ExpCavData[] = substr($objDac->fld['cate_code'], (CODE_DIGIT_CATE * 2), CODE_DIGIT_CATE);
	//カテゴリコード4
	$ExpCavData[] = substr($objDac->fld['cate_code'], (CODE_DIGIT_CATE * 3), CODE_DIGIT_CATE);
	//カテゴリ名
	$ExpCavData[] = $objDac->fld['name'];
	//表示順
	$ExpCavData[] = $objDac->fld['sort_order'];
	$AllExpCavData[] = $ExpCavData;
}

create_Csv("category.csv", $AllExpCavData, $G_SetHead, 0, "", "SJIS-WIN");

?>
