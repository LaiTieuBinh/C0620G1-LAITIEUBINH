<?php
/*
 *
 */
//--- 設定ファイル読み込み
require ("./.htsetting");
global $objCnc;

//csvファイルupload先
define("CSV_UPLOAD", "./tmp/");

//csvファイル最大行
define("G_CSV_MAX_LINE", 20000);

define("THROUGH", 0); // スルー
define("CHECK", 1); // チェック


$column_ary['a_link_id'] = array(
		"no" => 0, 
		"need" => CHECK, 
		'name' => "自動リンクID"
);
$column_ary['name'] = array(
		"no" => 1, 
		"need" => CHECK, 
		'name' => "自動リンク名称"
);
$column_ary['rss_flg'] = array(
		"no" => 2, 
		"need" => CHECK, 
		'name' => "RSS出力フラグ"
);
$column_ary['rss_file'] = array(
		"no" => 3, 
		"need" => THROUGH, 
		'name' => "RSSファイル名"
);
$column_ary['use_group'] = array(
		"no" => 4, 
		"need" => CHECK, 
		'name' => "デザイン設定"
);
$column_ary['cate_code'] = array(
		"no" => 5, 
		"need" => THROUGH, 
		'name' => "カテゴリコード"
);
$column_ary['condition'] = array(
		"no" => 6, 
		"need" => THROUGH, 
		'name' => "抽出方法"
);
$column_ary['link_target'] = array(
		"no" => 7, 
		"need" => CHECK, 
		'name' => "抽出条件"
);
$column_ary['order'] = array(
		"no" => 8, 
		"need" => THROUGH, 
		'name' => "表示順"
);
$column_ary['max_result'] = array(
		"no" => 9, 
		"need" => THROUGH, 
		'name' => "抽出件数"
);
$column_ary['auth'] = array(
		"no" => 10, 
		"need" => CHECK, 
		'name' => "権限"
);

//csv項目数
define("G_CSV_ITEM_MAX", count($column_ary));

//---引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError("インポートをするcsvファイルを指定してください。", 2, "javascript:history.back()");
	exit();
}
//---ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError("csvファイルのファイルサイズが0バイトです。", 2, "javascript:history.back()");
	exit();
}

//---アップロード
$frmCsvFnm = CSV_UPLOAD . $frmCsvFnm;
if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $frmCsvFnm) == FALSE) {
	DispError("csvファイルのアップロードに失敗しました。", 2, "javascript:history.back()");
	exit();
}
//(念のため)ファイル存在チェック
if (file_exists($frmCsvFnm) == FALSE) {
	$wk_str = "指定されたファイル【" . $frmCsvFnm . "】が存在しません。";
	DispError($wk_str, 2, "javascript:history.back()");
	exit();
}

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/b_dac.inc');
$objDac = new b_dac($objCnc);
$objDac->pk = "a_link_id";
$objDac->setTableName("tbl_auto_link");

// トランザクション開始
$objCnc->begin();

// 自動リンク情報の全削除
$objDac->delete();

// CSVファイルをUTF-8として読み込む
$CsvFno = csvRead_UTF8($frmCsvFnm);

//一行目は飛ばす
$data = fgetcsv($CsvFno, G_CSV_MAX_LINE);

//EOFになるまで読み出し
$err_msg = "";
$line = 1;
$ins_ary = array();
while ($data = fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
	$line++;
	//各項目のチェック
	$ret = check_item($data, $column_ary, $line, $err_msg);
	if ($ret == FALSE) continue;
	$ins_ary[] = create_ins_ary($data, $column_ary);
}
if ($err_msg != "") disp_err($err_msg, $objCnc, $CsvFno, $frmCsvFnm);

// DBへ登録
foreach ($ins_ary as $ary) {
	if ($objDac->insert($ary) === TRUE) continue;
	disp_err("自動リンクのインポートに失敗しました。", $objCnc, $CsvFno, $frmCsvFnm);
}

//ファイルClose
fclose($CsvFno);

//ファイルを削除
if (unlink($frmCsvFnm) == FALSE) {
	disp_err("csvファイルの削除に失敗しました。", $objCnc, $CsvFno, $frmCsvFnm);
}

// コミット
$objCnc->commit();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>自動リンク情報インポート</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
</head>

<body id="cms8341-mainbg">
<div id="cms8341-headarea">
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	id="cms8341-header">
	<tr>
		<td align="left" valign="top"><img src="<?=DIR_PATH_LOGO_MENU?>"
			alt="<?=ALT_LOGO_MENU?>" width="330" height="41"></td>
		<td width="110" align="right" valign="top"><img
			src="<?=DIR_PATH_LOGO_CMSMENU?>" alt="<?=ALT_LOGO_CMSMENU?>"
			width="110" height="41"></td>
	</tr>
</table>
</div>
<div align="center" id="cms8341-user">
<div class="cms8341-area-corner">
<div align="center">
<table border="0" cellspacing="0" cellpadding="5">
	<tr>
		<td align="left">
		<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable">
			<tr>
				<th align="center">自動リンク情報のインポート</th>
			</tr>
			<tr>
				<td align="center">
				<p>自動リンク情報をインポートしました。</p>
				<p>[<a href="./index.php"> データ初期設定INDEXへ </a>]&nbsp;&nbsp;&nbsp;[<a
					href="../../page/autolink/index.php"> 自動リンク一覧へ </a>]</p>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</div>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</body>
</html>
<?php
/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/

/**
 * 項目のチェックを行う
 * @param $data       １行分のCSV内容
 * @param $column_ary 項目の配列
 * @param $line       読み込み行番号
 * @param $err_msg    エラーメッセージ
 * @return TRUE:FALSE
 * 
 */
function check_item($data, $column_ary, $line, &$err_msg) {
	foreach ($column_ary as $column => $info) {
		if ($info["need"] == THROUGH) continue;
		if ($data[$info["no"]] == "") {
			$err_msg .= $info["name"] . "が指定されていないデーターが存在します。【" . $line . "行目】";
		}
	}
	return ($err_msg == "") ? TRUE : FALSE;
}

/**
 * 挿入用の配列を作成する
 * @param $data       １行分のCSV内容
 * @param $column_ary 項目の配列
 * @return 挿入用の配列
 * 
 */
function create_ins_ary($data, $column_ary) {
	$ary = array();
	foreach ($column_ary as $column => $info) {
		$ary[$column] = $data[$info["no"]];
	}
	return $ary;
}

/**
 * エラー画面表示
 * 
 */
function disp_err($err_msg, $objCnc, $CsvFno, $frmCsvFnm) {
	// ロールバック
	$objCnc->rollback();
	// ファイルClose
	fclose($CsvFno);
	// ファイルを削除
	unlink($frmCsvFnm);
	// エラーページの表示
	DispError($err_msg, 2, "javascript:history.back()");
	exit();
}

?>
