<?php
/*
 * カテゴリ管理　カテゴリ情報のインポート(category_import.php)
 */
/*===================================================================================
	
	
	指定されたcsvファイルをtbl_categoryに登録する

===================================================================================*/

//--- 設定ファイル読み込み
require ("./.htsetting");

/*---------------------------------------------
	定数 
----------------------------------------------*/
//csvファイルupload先
define("CSV_UPLOAD", "./tmp/");

//csvファイル最大行
define("G_CSV_MAX_LINE", 20000);

//csv項目数
define("G_CSV_ITEM_MAX", 6);

//必須項目チェックフラグ（0:必須チェックなし　1:必須チェックあり)
//カテゴリコード1,カテゴリコード2,カテゴリコード3,カテゴリコード4,カテゴリ名,表示順,
$ChkItemFlg = array(
		1, 
		1, 
		1, 
		1, 
		1, 
		1
);
//項目名
$ChkItemNm = array(
		"分類コード1", 
		"分類コード2", 
		"分類コード3", 
		"分類コード4", 
		"分類名", 
		"表示順"
);

/*---------------------------------------------------------------------------------
	category_import.php
---------------------------------------------------------------------------------*/

//---引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError("インポートをするcsvファイルを指定してください。", 2, "javascript:history.back()");
	exit();
}
//---ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError("csvファイルのファイルサイズが0バイトです。", 2, "javascript:history.back()");
	exit();
}

//---アップロード
$frmCsvFnm = CSV_UPLOAD . $frmCsvFnm;
if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $frmCsvFnm) == FALSE) {
	DispError("csvファイルのアップロードに失敗しました。", 2, "javascript:history.back()");
	exit();
}
//(念のため)ファイル存在チェック
if (file_exists($frmCsvFnm) == FALSE) {
	$wk_str = "指定されたファイル【" . $frmCsvFnm . "】が存在しません。";
	DispError($wk_str, 2, "javascript:history.back()");
	exit();
}

global $objCnc;

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*---csvを読込み、tbl_categoryに追加していく---*/
// トランザクション開始
$objCnc->begin();

//カテゴリ情報の全削除
$sql = "DELETE FROM tbl_category";
$objDac->execute($sql);

//ファイルを開く
if (!($CsvFno = csvRead_UTF8($frmCsvFnm))) {
	//エラーページの表示
	DispError("csvファイルのオープンに失敗しました。", 2, "javascript:history.back()");
	exit();
}
//一行目は飛ばす
$data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE);
//EOFになるまで読み出し
$err_msg = "";
while ($data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
	//配列数のチェック
	$arr_cnt = 0;
	foreach ($data as $value) {
		$arr_cnt = $arr_cnt + 1;
	}
	//項目数が少ない場合は配列に追加する
	if ($arr_cnt < G_CSV_ITEM_MAX) {
		$arr_cnt = G_CSV_ITEM_MAX - $arr_cnt;
		//足りない項目数を配列に追加
		for($idx = 0; $idx < $arr_cnt; $idx++) {
			array_push($data, "");
		}
	}
	//各項目のチェック
	if (FALSE == G_ChkCsvItem($data, $ChkItemFlg, $objDac, $err_msg, $cate_code)) {
		//ファイルClose
		fclose($CsvFno);
		//ファイルを削除
		unlink($frmCsvFnm);
		//ロールバック
		$objCnc->rollback();
		//エラーページの表示
		DispError($err_msg, 2, "javascript:history.back()");
		exit();
	}
	//tbl_categoryに追加
	if (FALSE == G_TblCateAdd($data, $cate_code, $objDac)) {
		//ファイルClose
		fclose($CsvFno);
		//ファイルを削除
		unlink($frmCsvFnm);
		//ロールバック
		$objCnc->rollback();
		//エラーページの表示
		DispError("分類情報の登録に失敗しました。<br>" . $data[0] . "<br>" . $data[1] . "<br>" . $data[2] . "<br>" . $data[3] . "<br>" . $data[4], 2, "javascript:history.back()");
		exit();
	}
}

//ファイルClose
fclose($CsvFno);
//ファイルを削除
if (unlink($frmCsvFnm) == FALSE) {
	//ロールバック
	$objCnc->rollback();
	//エラーページの表示
	DispError("csvファイルの削除に失敗しました。", 2, "javascript:history.back()");
	exit();
}

// コミット
$objCnc->commit();

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>分類情報インポート</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
</head>

<body id="cms8341-mainbg">
<div id="cms8341-headarea">
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	id="cms8341-header">
	<tr>
		<td align="left" valign="top"><img src="<?=DIR_PATH_LOGO_MENU?>"
			alt="<?=ALT_LOGO_MENU?>" width="330" height="41"></td>
		<td width="110" align="right" valign="top"><img
			src="<?=DIR_PATH_LOGO_CMSMENU?>" alt="<?=ALT_LOGO_CMSMENU?>"
			width="110" height="41"></td>
	</tr>
</table>
</div>
<div align="center" id="cms8341-user">
<div class="cms8341-area-corner">
<div align="center">
<table border="0" cellspacing="0" cellpadding="5">
	<tr>
		<td align="left">
		<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable">
			<tr>
				<th align="center">分類情報のインポート</th>
			</tr>
			<tr>
				<td align="center">
				<p>分類情報をインポートしました。</p>
				<p>[<a href="./index.php"> データ初期設定INDEXへ </a>]&nbsp;&nbsp;&nbsp;[<a
					href="../category/index.php"> 分類一覧へ </a>]</p>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</div>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</body>
</html>
<?php
/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	CSV項目のチェック

【引数】	$i_OneData		配列で指定されたcsvデータ（全項目)
		$i_ChkItemFlg	必須チェックフラグ
		$i_ChkItemNm	項目名
		$i_objDac		DB
		$o_ErrMsg		エラーメッセージ
		$o_CateCode		結合されたカテゴリコード
		
【戻値】	True	すべてのチェックが正常に終了
		False	エラーが存在した
		
【備考】
-----------------------------------------------------------------------------*/
function G_ChkCsvItem($i_OneData, $i_ChkItemFlg, $i_objDac, &$o_ErrMsg, &$o_CateCode) {
	
	$cate_cd = array(
			"", 
			"", 
			""
	);
	
	/*---カテゴリコード1($i_OneData[0])～カテゴリコード4($i_OneData[3])チェック---*/
	for($idx = 0; $idx <= 3; $idx++) {
		//必須チェック
		if (($i_ChkItemFlg[$idx] == 1) && (strlen($i_OneData[$idx]) <= 0)) {
			$o_ErrMsg = "分類コード" . ($idx + 1) . "が指定されていないデーターが存在します。";
			return FALSE;
		}
		//桁数チェック
		if (strlen($i_OneData[$idx]) > CODE_DIGIT_CATE) {
			$o_ErrMsg = "分類コード" . ($idx + 1) . "に" . CODE_DIGIT_CATE . "桁を越えて指定されているデーターが存在します。" . "【" . $i_OneData[$idx] . "】";
			return FALSE;
		}
		if (strlen($i_OneData[$idx]) < CODE_DIGIT_CATE) {
			//少ない場合は、0埋め
			$cate_cd[$idx] = str_pad($i_OneData[$idx], CODE_DIGIT_CATE, "0", STR_PAD_LEFT);
		}
		else {
			$cate_cd[$idx] = $i_OneData[$idx];
		}
		if (!preg_match('/^[0-9]+$/', $i_OneData[$idx])) {
			$o_ErrMsg = "半角数値以外の値が指定されている分類コード" . ($idx + 1) . "が存在します。";
			return FALSE;
		}
	}
	
	/*---カテゴリコード---*/
	$o_CateCode = $cate_cd[0] . $cate_cd[1] . $cate_cd[2] . $cate_cd[3]; //3+3+3+3
	if (strlen($o_CateCode) > 0) {
		//tbl_categoryに重複チェック
		$sql = "SELECT cate_id FROM tbl_category WHERE cate_code='" . $o_CateCode . "'";
		$i_objDac->execute($sql);
		if ($i_objDac->getRowCount() > 0) {
			$o_ErrMsg = "すでに存在する分類コードの指定されているデーターが存在します。【" . $cate_cd[0] . "," . $cate_cd[1] . "," . $cate_cd[2] . "," . $cate_cd[3] . "】";
			return FALSE;
		}
	}
	
	/*---カテゴリ名 $i_OneData[4] ---*/
	//必須チェック
	if (($i_ChkItemFlg[4] == 1) && (strlen($i_OneData[4]) <= 0)) {
		$o_ErrMsg = "分類名が指定されていないデーターが存在します。";
		return FALSE;
	}
	// 機種依存文字
	if (FALSE == checkMachineCode($i_OneData[4])) {
		$o_ErrMsg = "機種依存文字が指定されている分類名が存在します。";
		return FALSE;
	}
	
	/*---表示順---*/
	//半角数値チェック
	if (!preg_match('/^[0-9]+$/', $i_OneData[5])) {
		$o_ErrMsg = "半角数値以外の値が指定されている表示順が存在します。";
		return FALSE;
	}
	
	return TRUE;

}

/*-----------------------------------------------------------------------------
	tbl_categoryにCSVデータを追加

【引数】	$i_OneData	配列で指定されたcsvデータ（全項目)
		$i_CateCode	結合されたカテゴリコード
		$i_objDac	DB
		
【戻値】	True	正常に終了
		False	エラー
		
【備考】
-----------------------------------------------------------------------------*/
function G_TblCateAdd($i_OneData, $i_CateCode, $i_objDac) {
	/*---levelの取得---*/
	$level = 0;
	
	//第四カテゴリ
	if ((((int)$i_OneData[0]) > 0) && (((int)$i_OneData[1]) > 0) && (((int)$i_OneData[2]) > 0) && (((int)$i_OneData[3]) > 0)) $level = 4;
	//第三カテゴリ
	elseif ((((int)$i_OneData[0]) > 0) && (((int)$i_OneData[1]) > 0) && (((int)$i_OneData[2]) > 0)) $level = 3;
	//第二カテゴリ
	elseif ((((int)$i_OneData[0]) > 0) && (((int)$i_OneData[1]) > 0)) $level = 2;
	//第一カテゴリ
	elseif ((((int)$i_OneData[0]) > 0)) $level = 1;
	
	//SQL作成
	$sql = "INSERT INTO tbl_category ( level, cate_code, name, sort_order) VALUES (";
	$sql = $sql . $level . ", "; //レベル
	$sql = $sql . $i_objDac->_addslashes($i_CateCode, 'TEXT') . ", "; //カテゴリコード
	$sql = $sql . $i_objDac->_addslashes($i_OneData[4], 'TEXT') . ", "; //名前
	$sql = $sql . $i_objDac->_addslashes($i_OneData[5], 'INT'); //sort_order
	$sql = $sql . ")";
	
	//実行
	return ($i_objDac->execute($sql, "utf-8", "auto"));

}

?>
