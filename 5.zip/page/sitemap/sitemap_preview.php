<?php
require_once ("./.htsetting");
require_once ("./common.inc");

// tbl_sitemap
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap.inc');
$objSitemap = new tbl_sitemap($objCnc);
// tbl_sitemap_handler
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap_handler.inc');
$objSitemapHandler = new tbl_sitemap_handler($objCnc);
// tbl_page
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
// dactools
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
// library
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_library.inc');
$objLibrary = new tbl_library($objCnc);

// サイトマップID取得
if (!isset($_POST['cms_sitemap_id'])) {
	sitemap_error('不正なアクセスです。');
}
$sitemap_id = $_POST['cms_sitemap_id'];

// 登録されているテンプレート一覧
$template_list = get_template_db();

// テンプレートID取得
foreach ($template_list as $tid => $tname) {
	$template_id = (isset($_POST['cms_template_id']) ? $_POST['cms_template_id'] : $tid);
	break;
}

// テンプレートテキスト取得
$tpl = "";
if (($tpl = $objTool->getTemplateContext($template_id)) === FALSE) {
	sitemap_error("プレビューで使用するテンプレート情報の取得に失敗しました。");
}

// レイアウト設定プレビューフラグ
$layout_set_preview = (isset($_POST['cms_layout_set_preview']) && $_POST['cms_layout_set_preview'] == FLAG_ON ? FLAG_ON : FLAG_OFF);

// 編集領域の存在するテンプレートかチェック
$error_msg = '<p>編集領域の指定されていないテンプレートではプレビューできません。</p>';
$edit = getMidString($tpl, '<!-- InstanceBeginEditable name="contents" -->', '<!-- InstanceEndEditable -->');

// サイトマップHTMLの生成
$head_scripts = "";
$toolbar_str = "";
$sitemap_html = "";

// レイアウト設定プレビューの場合
if ($layout_set_preview == FLAG_ON) {
	// 編集領域の存在しないテンプレートではプレビュー不可
	if ($edit === FALSE) {
		sitemap_error("編集領域の指定されていないテンプレートではプレビューできません。");
	}
	// サイトマップ情報を取得
	if ($objSitemap->selectFromID($sitemap_id) == FALSE) {
		sitemap_error("サイトマップ情報の取得に失敗しました。");
	}
	$sitemap_ary = $objSitemap->fld;
	
	// サイトマップトップ非表示フラグ
	$sitemap_top_none = (isset($_POST['cms_layout_none_1']) ? $_POST['cms_layout_none_1'][0] : FLAG_OFF);
	
	// レイアウト情報
	$layout_ary = array();
	
	for($cnt = 1; $cnt <= $sitemap_ary['floor']; $cnt++) {
		// サイトマップトップが非表示の場合
		if ($cnt == 1 && $sitemap_top_none == FLAG_ON) {
			$_POST['cms_layout_direction_' . $cnt] = FLAG_OFF;
			$_POST['cms_layout_tag_' . $cnt] = FLAG_OFF;
			$_POST['cms_layout_none_' . $cnt] = FLAG_ON;
		}
		// サイトマップトップが表示の場合
		// 下位階層の場合
		else {
			if (!isset($_POST['cms_layout_direction_' . $cnt])) {
				sitemap_error("レイアウト情報を取得できませんでした。");
			}
			if (!isset($_POST['cms_layout_tag_' . $cnt])) {
				sitemap_error("レイアウト情報を取得できませんでした。");
			}
			$_POST['cms_layout_none_' . $cnt] = FLAG_OFF;
		}
		// レイアウト情報に格納
		$layout_ary[$cnt] = array(
				"direction" => $_POST['cms_layout_direction_' . $cnt], 
				"tag" => $_POST['cms_layout_tag_' . $cnt], 
				"none" => $_POST['cms_layout_none_' . $cnt]
		);
	}
	
	// サイトマップに表示するページ一覧
	$sitemap_list_ary = array();
	$sitemap_list_ary = $_SESSION['sitemap_admin'];
	
	// サイトマップ
	$sitemap_html = create_sitemap_html($sitemap_list_ary, $layout_ary, $_POST['cms_sitemap_top_id'], 1, $sitemap_ary['language']);
}
// サイトマップ一覧プレビューの場合
else {
	// プレビューフォーム
	$template_slect = mkcombobox(get_template_db(), "cms_template_id", $template_id, 'return cxSitemapPreview();');
	
	// DB情報よりサイトマップHTMLを作成
	$sitemap_html = create_sitemap($sitemap_id, 1);
	
	// ヘッダーにCMS用のスクリプトを記載
	$head_scripts = '';
	$head_scripts .= '<link rel="stylesheet" href="/admin/style/shared.css" type="text/css">' . "\n";
	$head_scripts .= '<link rel="stylesheet" href="/admin/style/accessibility.css" type="text/css">' . "\n";
	$head_scripts .= '<script src="/admin/js/library/prototype.js" type="text/javascript"></script>' . "\n";
	$head_scripts .= '<script src="/admin/js/shared.js" type="text/javascript"></script>' . "\n";
	$head_scripts .= '<script src="/admin/page/sitemap/sitemap_preview.js" type="text/javascript"></script>' . "\n";
	$head_scripts .= '<script type="text/javascript">' . "\n";
	$head_scripts .= '<!--' . "\n";
	$head_scripts .= loadSettingVars() . "\n";
	$head_scripts .= '//-->' . "\n";
	$head_scripts .= '</script>' . "\n";
	
	// 隠し項目
	$form_hidden = array();
	$form_hidden['cms_sitemap_id'] = $sitemap_id;
	$form_hidden['cms_layout_set_preview'] = $layout_set_preview;
	
	// ヘッダー
	$toolbar_str = "";
	$toolbar_str .= '<div id="cms8341-headareaZero" style="margin-bottom: 0px !important">' . "\n";
	$toolbar_str .= '<form class="cms8341-form" id="cms_sitemap_form" name="cms_sitemap_form" method="post" action="#" onSubmit="return false;">' . "\n";
	$toolbar_str .= '<table width="100%" border="0" cellspacing="0" cellpadding="0">' . "\n";
	$toolbar_str .= '<tr>' . "\n";
	$toolbar_str .= '<td align="center" valign="top" bgcolor="#DFDFDF">' . "\n";
	$toolbar_str .= '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader">' . "\n";
	$toolbar_str .= '<tr>' . "\n";
	$toolbar_str .= '<td align="left" valign="middle"><img src="' . RPW . '/admin/page/sitemap/images/title_sitemap_preview.jpg" alt="サイトマッププレビュー" width="200" height="20" style="margin: 4px 10px;"></td>' . "\n";
	$toolbar_str .= '<td width="78" align="right" valign="middle"><a href="javascript:window.close()"><img src="' . RPW . '/admin/images/btn/btn_close.jpg" alt="閉じる" width="58" height="19" border="0" style="margin: 4px 10px;"></a></td>' . "\n";
	$toolbar_str .= '</tr>' . "\n";
	$toolbar_str .= '</table>' . "\n";
	$toolbar_str .= '<div id="cms8341-searcharea" style="text-align: left; padding: 10px 9px 10px 9px;">' . "\n";
	$toolbar_str .= '<table width="98%" border="0" cellpadding="0" cellspacing="0" bgcolor="#F0F0F0" style="border: solid 1px #AAAAAA;">' . "\n";
	$toolbar_str .= '<tr>' . "\n";
	$toolbar_str .= '<td>' . "\n";
	$toolbar_str .= '<table width="100%" border="0" cellpadding="3" cellspacing="0" bgcolor="#F0F0F0" style="font-size: 12px;">' . "\n";
	$toolbar_str .= '<tr>' . "\n";
	$toolbar_str .= '<th width="100" align="left" valign="middle" nowrap scope="row">テンプレート</th>' . "\n";
	$toolbar_str .= '<td align="left" valign="middle">' . $template_slect . '</td>' . "\n";
	$toolbar_str .= '</tr>' . "\n";
	$toolbar_str .= '</table>' . "\n";
	$toolbar_str .= '</td>' . "\n";
	$toolbar_str .= '</tr>' . "\n";
	$toolbar_str .= '</table>' . "\n";
	$toolbar_str .= '</div>' . "\n";
	$toolbar_str .= '</td>' . "\n";
	$toolbar_str .= '</tr>' . "\n";
	$toolbar_str .= '</table>' . "\n";
	$toolbar_str .= '<p>';
	// hidden値
	foreach ($form_hidden as $name => $value) {
		$toolbar_str .= '<input type="hidden" name="' . $name . '" value="' . $value . '" />' . "\n";
	}
	$toolbar_str .= '</p>' . "\n";
	$toolbar_str .= '</form>' . "\n";
	$toolbar_str .= '</div>' . "\n";
}

/* HTML出力 */
$title_html = htmlDisplay("サイトマッププレビュー", 'nonconvert_space');

// 編集領域が存在しない場合はエラーメッセージ
if ($edit === FALSE) {
	$tpl = preg_replace('/(<body[^>]*>).*(<\/body>)/si', '${1}' . $error_msg . '${2}', $tpl);
}
// 編集領域が存在する場合はサイトマップ一覧に変更
else {
	$tpl = str_replace('<!-- InstanceBeginEditable name="contents" -->' . $edit . '<!-- InstanceEndEditable -->', $sitemap_html, $tpl);
}

// テンプレート内のライブラリを書換
// ライブラリ用変数初期化
$lib_tpl = $tpl;
$lib_ary = array();
// ライブラリ領域を検索
while (getLibraryArea($lib_ary, $lib_tpl, 0)) {
	// ライブラリ情報を登録
	if (isset($lib_ary["id"]) && $lib_ary["id"] != "" && $objLibrary->selectFromID($lib_ary["id"]) !== FALSE) {
		// 初期ライブラリを表示
		$tpl = str_replace($lib_ary["match"], $objLibrary->fld['context'], $tpl);
	}
	// 検索用文字列からエリア削除
	$lib_tpl = str_replace($lib_ary["match"], "", $lib_tpl);
}
$tpl = preg_replace('/<title>.*<\/title>/i', '<title>' . htmlDisplay("サイトマッププレビュー", 'nonconvert_space') . '</title>', $tpl);

// オンロードを消去
$tpl = preg_replace('/onload="[^"]*"/i', '', $tpl);
$tpl = preg_replace('/.*\.onload.*/i', '', $tpl);
$tpl = preg_replace('/<script.*<\/script>/i', '', $tpl);
$p = 0;
while (getMidString($tpl, "<script", "</script>", $p) !== FALSE) {
	$hit_str = getMidString($tpl, "<script", "</script>", $p);
	$tpl = str_replace("<script" . $hit_str . "</script>", "", $tpl);
	$p++;
}

// ヘッダー用スクリプトを埋込
$tpl = preg_replace('/<\/head>/i', $head_scripts . '</head>', $tpl);
// プレビューフォームをページ上部にフォームを埋込
$tpl = preg_replace('/(<body[^>]*>)/i', '${1}' . $toolbar_str, $tpl);
// CMSルートを設定
$tpl = setRootPath($tpl);
// プレビューモードを設定
$tpl = setGetParamPath($tpl, "mode=" . MODE_PREVIEW);

?>
<?=

$tpl?>
