// サイトマッププレビュー用Javascript

/**
 * サイトマッププレビュー実行
 * 
 * @return false
 */
function cxSitemapPreview() {
	// フォーム情報設定
	$('cms_sitemap_form').action = "./sitemap_preview.php";
	$('cms_sitemap_form').target = "_self";
	$('cms_sitemap_form').method = "post";
	// フォーム送信
	$('cms_sitemap_form').submit();
	return false;
}
