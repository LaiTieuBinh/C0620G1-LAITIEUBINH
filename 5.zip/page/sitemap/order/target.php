<?php
// キャッシュ制御
header("Cache-Control: public");
header("Pragma: public");
session_cache_limiter('private');

require ("../.htsetting");
require ("../common.inc");

// cnc
global $objCnc;
// tbl_sitemap
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap.inc');
$objSitemap = new tbl_sitemap($objCnc);

// エラーチェック
if (!isset($_POST['cms_sitemap_id']) || $objSitemap->selectFromID($_POST['cms_sitemap_id']) === FALSE) {
	sitemap_error('サイトマップ情報の取得に失敗しました。');
}
// 取得したサイトマップ情報を格納
$sitemap_ary = $objSitemap->fld;

// サイトマップのセッション情報を削除
if (isset($_SESSION['sitemap_admin'])) unset($_SESSION['sitemap_admin']);

/* HTML出力情報 */

// タイトル
$title_html = '表示対象設定';
$title_image = '<img src="../images/bar_sitemap_target.jpg" alt="表示対象設定" width="920" height="30" />';

// ボタン
$button_next = '<a 	href="javascript:" 	onClick="return cxSubmit()"><img src="' . RPW . '/admin/images/btn/btn_submit.jpg" alt="決定" width="102" height="21"  border="0" style="margin-right: 10px" /></a>';
$button_back = '<a href="../index.php"><img src="' . RPW . '/admin/images/btn/btn_cansel.jpg" alt="キャンセル" width="101" height="21" border="0" style="margin-left: 10px" /></a>';

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="../sitemap.js" type="text/javascript"></script>
<script src="./target.js" type="text/javascript"></script>
<script type="text/javascript">
<!--//

<?php
echo loadSettingVars();
?>

// 自動反映エリア（サイトマップ階層）
var max_floor = <?=javaStringEscape($sitemap_ary['floor'])?>;
var ajax_flg = false;

/**
 * 
 */
function cxSubmit() {
	// Ajax処理中は決定できない
	if (ajax_flg != false) {
		return false;
	} 
	// サイトマップトップページの選択をチェック
	var sitemap_top = '';
	if ($('cms_sitemap_form').cms_sitemap_top_id.length) {
		for (var i = 0 ; i < $('cms_sitemap_form').cms_sitemap_top_id.length ; i ++ ) {
			if ($('cms_sitemap_form').cms_sitemap_top_id[i].checked == true ) {
				sitemap_top = $('cms_sitemap_form').cms_sitemap_top_id[i].value;
			}
			
		}
	}
	else {
		if ($('cms_sitemap_form').cms_sitemap_top_id.checked == true ) {
			sitemap_top = $('cms_sitemap_form').cms_sitemap_top_id.value;
		}
	}
	// 未チェック
	if (sitemap_top == '' ) {
		alert("サイトマップトップページが選択されていません。");
		return false;
	}

	// サイトマップ表示順のセッションをクリア
	if (cxSetSitemapSession('sitemap_admin', FLAG_OFF) == false) {
		alert("通信に失敗しました。");
		return false;
	}
	
	// フォーム情報設定
	$('cms_sitemap_form').action = "./disp.php";
	$('cms_sitemap_form').method = "post";
	// フォーム送信
	$('cms_sitemap_form').submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'sitemap';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-sitemap">
<div><?=$title_image?></div>
<div class="cms8341-area-corner">
<form class="cms8341-form" id="cms_sitemap_form" name="cms_sitemap_form"
	method="post" action="#" onSubmit="return false;">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<td valign="top"><span id="cms_sitemap_draw_area">&nbsp;</span></td>
	</tr>
</table>
<p><input type="hidden" name="cms_sitemap_id" id="cms_sitemap_id"
	value="<?=$_POST['cms_sitemap_id']?>" /></p>
<p align="center">
<?=$button_next?><?=$button_back?>
</p>
</form>

<input type="hidden" name="cms_hidden_sitemap_top_id"
	id="cms_hidden_sitemap_top_id"
	value="<?=$sitemap_ary['sitemap_top_id']?>" /></div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!--***処理中プロパティレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0" style="background-image:url(<?=RPW?>/admin/images/layer/titlebar_bg.jpg);height:30px;">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg">メッセージ</div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理中プロパティレイヤー ここまで********************************-->
</body>
</html>
