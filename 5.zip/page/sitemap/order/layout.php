<?php
require ("../.htsetting");
require ("../common.inc");

// cnc
global $objCnc;
// tbl_sitemap
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap.inc');
$objSitemap = new tbl_sitemap($objCnc);
// tbl_sitemap_handler
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap_handler.inc');
$objSitemapHandler = new tbl_sitemap_handler($objCnc);
// tbl_page
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

// エラーチェック
if (!isset($_POST['cms_sitemap_top_id']) || !isset($_POST['cms_sitemap_id'])) {
	sitemap_error('不正アクセスです。');
}

// サイトマップ情報の取得
if (!$objSitemap->selectFromID($_POST['cms_sitemap_id'])) {
	sitemap_error('サイトマップ情報の取得に失敗しました。');
}
$sitemap_id = $_POST['cms_sitemap_id'];
$sitemap_ary = $objSitemap->fld;

// サイトマップのトップページの情報を取得
$getc = 'p.page_id, p.page_title, p.parent_id';
if (!$objPage->selectFromId($_POST['cms_sitemap_top_id'], $getc)) {
	sitemap_error('サイトマップトップページ情報の取得に失敗しました。');
}
$sitemap_top_id = $_POST['cms_sitemap_top_id'];
$sitemap_top_ary = $objPage->fld;

// レイアウト情報を取得
$layout_ary = array();
for($cnt = 1; $cnt <= $sitemap_ary['floor']; $cnt++) {
	$layout_ary[$cnt] = array(
			'direction' => SITEMAP_LAYOUT_VERTICAL, 
			'tag' => SITEMAP_LAYOUT_H2, 
			'none' => FLAG_OFF
	);
	if ($objSitemapHandler->select_layout_from_floor($sitemap_id, $cnt) == FALSE) {
		continue;
	}
	if (!$objSitemapHandler->fetch()) {
		continue;
	}
	$layout_ary[$cnt] = array(
			'direction' => $objSitemapHandler->fld['item3'], 
			'tag' => $objSitemapHandler->fld['item4'], 
			'none' => ($objSitemapHandler->fld['item5'] == FLAG_ON ? FLAG_ON : FLAG_OFF)
	);
}

// サイトマップのセッション情報を削除
if (isset($_SESSION['sitemap_admin'])) unset($_SESSION['sitemap_admin']);

// POST情報をセッションに追加
$no = 0;
foreach ($_POST['cms_sitemap_page_id'] as $floor_num => $info) {
	foreach ($info as $id_type => $page_id) {
		// リンクやコメント情報を格納する値
		$special = '';
		// 種別：ページ
		$page_type = '';
		// 種別：リンク
		if (strpos($id_type, '_link')) {
			$page_type = SITEMAP_PAGE_TYPE_LINK;
			$special = $_POST[$id_type];
		}
		// 種別：コメント
		elseif (strpos($id_type, '_comment')) {
			$page_type = SITEMAP_PAGE_TYPE_COMMENT;
			$special = $_POST[$id_type];
		}
		// ページ
		else {
			$page_type = SITEMAP_PAGE_TYPE_PAGE;
			// ページ情報取得
			if ($objPage->selectFromID($page_id, PUBLISH_TABLE, 'p.page_id,p.parent_id,p.page_title,p.file_path') == FALSE) {
				if (isset($_SESSION['sitemap_admin'])) {
					unset($_SESSION['sitemap_admin']);
				}
				sitemap_error('ページ情報の取得に失敗しました。ページが削除された可能性があります。【' . $page_id . '】');
			}
			$special = $objPage->fld;
		}
		// 親ページID
		$parent_id = @$_POST['cms_sitemap_parent_id'][$floor_num][$id_type];
		// 親ページなしは「SITEMAP_NON_PARENT_STRING」
		$parent = ($parent_id == "" ? SITEMAP_NON_PARENT_STRING : $parent_id);
		// セッションに情報を代入
		$_SESSION['sitemap_admin'][$floor_num][$parent][$id_type] = array(
				// 種別
				'type' => $page_type, 
				// ページID
				'parent_id' => $parent_id, 
				// 順番（仮）
				'order' => ($page_type != SITEMAP_PAGE_TYPE_COMMENT ? ++$no : 0), 
				// ページID
				'page_id' => $id_type, 
				// リンク情報・コメント情報
				'special' => $special, 
				// 表示フラグ
				'checked' => (isset($_POST['check_' . $id_type]) && $_POST['check_' . $id_type] ? FLAG_ON : FLAG_OFF)
		);
	}
}

/* HTML出力情報 */

// タイトル
$title_html = 'レイアウト設定';
$title_image = '<img src="../images/bar_sitemap_layout.jpg" alt="レイアウト設定" width="920" height="30" />';

// ボタン
$button_preview = '<a href="javascript:" onClick="return cxSitemapPreview()"><img src="' . RPW . '/admin/images/btn/btn_preview.jpg" alt="プレビュー" width="100" height="20" border="0" /></a>';
$button_next = '<a href="javascript:" onClick="return cxSubmit()"><img src="' . RPW . '/admin/images/btn/btn_submit.jpg" alt="決定" width="102" height="21"  border="0" style="margin-right: 10px" /></a>';
$button_back = '<a href="javascript:history.back();"><img src="' . RPW . '/admin/images/btn/btn_cansel.jpg" alt="キャンセル" width="101" height="21" border="0" style="margin-left: 10px" /></a>';

// 定数取得
$SITEMAP_LAYOUT_DIRECTION = getDefineArray('SITEMAP_LAYOUT_DIRECTION');
$SITEMAP_LAYOUT_TAGS = getDefineArray('SITEMAP_LAYOUT_TAGS');

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Expires" content="Thu, 01 Dec 1994 16:00:00 GMT">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="../sitemap.js" type="text/javascript"></script>
<script src="./layout.js" type="text/javascript"></script>
<script type="text/javascript">
<!--//
<?php
echo loadSettingVars();
?>
// 階層
var floor = <?=$sitemap_ary['floor']?>;
// レイアウト
var SITEMAP_LAYOUT_VERTICAL = <?=SITEMAP_LAYOUT_VERTICAL?>;
var SITEMAP_LAYOUT_SIDE =<?=SITEMAP_LAYOUT_SIDE?>;
// サイトマップトップページ非表示フラグ
var sitemap_top_none = <?=$layout_ary[1]['none']?>;
//-->
</script>
<link rel="stylesheet" href="../sitemap.css" type="text/css">
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'sitemap';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-sitemap">
<div><?=$title_image?></div>
<div class="cms8341-area-corner">
<form class="cms8341-form" id="cms_sitemap_form" name="cms_sitemap_form"
	method="post" action="#" onSubmit="return false;">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="left" valign="top" width="20%">テンプレート</th>
		<td align="left" valign="top" width="80%"><?=mkcombobox(get_template_db(), "cms_template_id")?>&nbsp;<?=$button_preview?></td>
	</tr>
<?php
// ボックスの指定階層+1個分の入力領域を作成
for($cnt = 1; $cnt <= $sitemap_ary['floor']; $cnt++) {
	// 入力ボックス生成
	$direction = mkradiobutton($SITEMAP_LAYOUT_DIRECTION, "cms_layout_direction_" . $cnt, $layout_ary[$cnt]['direction'], FLAG_OFF, "", "cxCheckLayoutDirection(" . $cnt . ")");
	$tag = mkcombobox($SITEMAP_LAYOUT_TAGS, "cms_layout_tag_" . $cnt, $layout_ary[$cnt]['tag'], "", "120px");
	$tag = preg_replace("/(<select[^>]+)>/i", "$1 onChange=\"cxSelectLayoutTag(" . $cnt . ")\">", $tag);
	// TDの初期スタイル
	$td_style = ($layout_ary[$cnt]['none'] == FLAG_ON ? ' style="bacground-color:#C0C0C0;"' : '');
	?>
<tr>
		<th align="left" valign="top" width="20%">第<?=$cnt?>階層</th>
		<td align="left" valign="top" width="80%" id="cms_layout_td_<?=$cnt?>"
			<?=$td_style?>><?=$direction?>&nbsp;
<span id="cms_layout_tag_<?=$cnt?>_box"><?=$tag?></span>
<?php
	// 第1階層(サイトマップトップ)は非表示を選択可能
	// 但し、下位の階層があった場合のみ
	if (($cnt == 1) && ($sitemap_ary['floor'] != 1)) {
		$none_ary = array(
				FLAG_ON => '非表示'
		);
		$none_chk = array();
		if ($layout_ary[$cnt]['none'] == FLAG_ON) {
			$none_chk[FLAG_ON] = FLAG_ON;
		}
		echo '&nbsp;';
		echo mkcheckbox($none_ary, 'cms_layout_none_' . $cnt, $none_chk, 1, "", 'cxChangeNoneCheckBox(' . $cnt . ')');
	}
	?>
</td>
	</tr>
<?php
}
?>
</table>
<p><input type="hidden" name="cms_sitemap_id" id="cms_sitemap_id"
	value="<?=$sitemap_id?>" /> <input type="hidden"
	name="cms_sitemap_top_id" id="cms_sitemap_top_id"
	value="<?=$sitemap_top_id?>" /> <input type="hidden"
	name="cms_layout_set_preview" id="cms_layout_set_preview"
	value="<?=FLAG_ON?>" /></p>
<p align="center">
<?=$button_next?><?=$button_back?>
</p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
</body>
</html>
