// 表示対象設定画面用Javascript

// ページ読込時に実行するスクリプトを設定
Event.observe(window, 'load', cxCreateSitemapTargetPageInit, false);

/**
 * 子ページの一覧を取得
 * 
 * @param  parent_id サイトマップトップに設定するページID
 * @param  parent_id 取得する階層数
 * @param  parent_id 取得する階層数
 * @return なし
 */
function cxCreateSitemapTargetPageCheck(sitemap_id, parent_id, max_floor, this_floor) {
	// ラジオボタンの値を隠し項目に設定
	$('cms_hidden_sitemap_top_id').value = parent_id;

	// Ajaxでの処理を実行している場合は何もしない
	if (ajax_flg == true) {
		return false;
	}
	// Ajax処理フラグを有効
	ajax_flg = true;

	// ラジオボタンを操作不能に変更
	cxDisableDocumentAllInput();

	// 処理中レイヤーの表示
	$('cms8341-progressmsg').innerHTML = '処理中です．．．';
	cxLayer('cms8341-progress', 1, 500, 500);

	// Ajaxパラメーター
	var params = 'sitemap_id=' + sitemap_id;
	params += '&parent_id=' + parent_id;
	params += '&max_floor=' + max_floor;
	params += '&this_floor=' + this_floor;

	// AjaxでPHPに接続
	var r = new Ajax.Request(
		cms8341admin_path+'/page/sitemap/order/request/create_sitemap_target_page_check.php',
		{
			method: 'post',
			asynchronous: true,
			parameters: params,
			// 通信成功時の処理
			onSuccess: function () {
				// PHP からの戻値
				cxCreateSitemapTargetPageCheckSuccess(r.transport)
			},
			// 通信失敗時の処理
			onFailure: function () {
				// エラー
				alert("処理中にエラーが発生しました。");
				// Ajax処理フラグを解除
				ajax_flg = false;
			}
		}
	);
}

/**
 * 子ページの一覧を取得(Ajax実行結果)
 * 
 * @param  r Ajaxレスポンス
 * @return なし
 */
function cxCreateSitemapTargetPageCheckSuccess(r) {
	// Ajax処理フラグを解除
	ajax_flg = false;

	// ラジオボタンを操作可能に変更
	cxEnableDocumentAllInput();

	// 処理中レイヤーの非表示
	cxLayer('cms8341-progress', 0);
	
	var r_text = r.responseText;
	
	// 取得に失敗しているかチェック
	if (r_text.indexOf("true,",0) !== 0) {
		// エラー
		alert("処理中にエラーが発生しました。");
		document.write(r_text);
		return false;
	}
	r_text = r_text.replace(/^true,/, "");

	// 戻値を取得
	var parent_id = r_text.split(/\n/)[0];
	var replace = new RegExp("^" + parent_id + "\n");
	// HTML
	var html = r_text.replace(replace, "");

	// 現在スタイルの当たっているページからスタイルを除去
	cxResetSitemapSpanStyle();
	// 選択したラジオボタンにスタイルを適用
	if ($('cms_sitemap_line_' + parent_id)) {
		$('cms_sitemap_line_' + parent_id).style.backgroundColor = '#FFFF88';
	}

	// 処理不可
	if (!$('cms_parent_' + parent_id)) {
		return false;
	}
	if (html == "") {
		return false;
	}

	// 取得したHTMLを適用
	$('cms_parent_' + parent_id).innerHTML = html;
	$('cms_parent_' + parent_id).style.display = 'block';
}

/**
 * ドキュメント内のinputを全て使用不可能にする
 * 
 * @param  なし
 * @return なし
 */
function cxDisableDocumentAllInput() {
	// ドキュメント内のinputを全て取得	
	var inputlist = document.getElementsByTagName('input');

	// 全て使用不可能にする
	for ( var i = 0; i < inputlist.length; i++) {
		inputlist[i].disabled = true;
	}
}

/**
 * ドキュメント内のinputを全て使用可能にする
 * 
 * @param  なし
 * @return なし
 */
function cxEnableDocumentAllInput() {
	// ドキュメント内のinputを全て取得	
	var inputlist = document.getElementsByTagName('input');

	// 全て使用可能にする
	for ( var i = 0; i < inputlist.length; i++) {
		inputlist[i].disabled = false;
	}
}

/**
 * ページタイトルのスタイルを全て解除
 * 
 * @param  なし
 * @return なし
 */
function cxResetSitemapSpanStyle() {
	// ドキュメント内のinputを全て取得
	var spanlist = document.getElementsByTagName('span');

	// 取得した結果分ループ
	for ( var i = 0; i < spanlist.length; i++) {
		// IDのないSPANは無視
		if (!spanlist[i].id)
			continue;
		// サイトマップ用のIDが付加されていない場合は無視
		if (!spanlist[i].id.indexOf("cms_sitemap_line_") < 0)
			continue;
		// スタイルを削除
		spanlist[i].removeAttribute("style");
	}
}

/**
 * 表示設定画面初期ページ情報の表示
 * 
 * @param  なし
 * @return なし
 */
function cxCreateSitemapTargetPageInit() {
	// 対象項目がない場合は処理なし
	if (!$('cms_sitemap_id')) {
		return false;
	}
	if (!$('cms_hidden_sitemap_top_id')) {
		return false;
	}
	if (!$('cms_sitemap_draw_area')) {
		return false;
	}

	// Ajax処理フラグを有効
	ajax_flg = true;

	// ラジオボタンを操作不能に変更
	cxDisableDocumentAllInput();

	// 処理中レイヤーの表示
	$('cms8341-progressmsg').innerHTML = 'サイトマップ情報作成中．．．';
	cxLayer('cms8341-progress', 1, 500, 500);

	// Ajaxパラメーター
	var params = 'sitemap_id=' + $('cms_sitemap_id').value;
	params += '&sitemap_top_id=' + $('cms_hidden_sitemap_top_id').value;

	// AjaxでPHPに接続
	var r = new Ajax.Request(
		cms8341admin_path+'/page/sitemap/order/request/create_sitemap_target_page_init.php',
		{
			method: 'post',
			asynchronous: true,
			parameters: params,
			// 通信成功時の処理
			onSuccess: function () {
				// PHP からの戻値
				cxCreateSitemapTargetPageInitSuccess(r.transport)
			},
			// 通信失敗時の処理
			onFailure: function () {
				// エラー
				alert("処理中にエラーが発生しました。");
				// Ajax処理フラグを解除
				ajax_flg = false;
			}
		}
	);
}

/**
 * 表示設定画面初期ページ情報の表示（Ajax実行結果）
 * 
 * @param  なし
 * @return なし
 */
function cxCreateSitemapTargetPageInitSuccess(r) {
	// Ajax処理フラグを解除
	ajax_flg = false;

	// ラジオボタンを操作可能に変更
	cxEnableDocumentAllInput();

	// 処理中レイヤーの非表示
	cxLayer('cms8341-progress', 0);

	var r_text = r.responseText;

	// 取得に失敗しているかチェック
	if (r_text.indexOf("true,",0) !== 0) {
		// エラー
		alert("処理中にエラーが発生しました。");
		return false;
	}
	r_text = r_text.replace(/^true,/, "");

	// 取得したHTMLを出力
	var html = r_text;
	$('cms_sitemap_draw_area').innerHTML = html;
	if ($('cms_sitemap_line_' + $F('cms_hidden_sitemap_top_id'))) {
		$('cms_sitemap_line_' + $F('cms_hidden_sitemap_top_id')).style.backgroundColor = '#FFFF88';
	}
}
