<?php
require ("../.htsetting");
require ("../common.inc");

// cnc
global $objCnc;
// tbl_sitemap
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap.inc');
$objSitemap = new tbl_sitemap($objCnc);
// tbl_sitemap_handler
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap_handler.inc');
$objSitemapHandler = new tbl_sitemap_handler($objCnc);
// tbl_page
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

// セッションに情報がない場合はエラー
if (!isset($_SESSION['sitemap_admin'])) {
	sitemap_error('登録情報が削除されてるか既に登録が完了しています。');
}

// エラーチェック
if (!isset($_POST['cms_sitemap_id']) || $objSitemap->selectFromID($_POST['cms_sitemap_id']) === FALSE) {
	sitemap_error('サイトマップ情報の取得に失敗しました。');
}
// 取得したサイトマップ情報を格納
$sitempa_ary = $objSitemap->fld;

$sitemap_id = $sitempa_ary['sitemap_id'];
$floor = $sitempa_ary['floor'];

// サイトマップのトップページの情報を取得
$getc = 'p.page_id, p.page_title, p.parent_id';
if (!$objPage->selectFromId($_POST['cms_sitemap_top_id'], $getc)) {
	sitemap_error('サイトマップトップページ情報の取得に失敗しました。');
}
$sitemap_top_id = $_POST['cms_sitemap_top_id'];
$sitemap_top_ary = $objPage->fld;

/* DB情報登録 */
$objCnc->begin();

/* サイトマップ情報の登録 */

// 登録情報の作成
$db_ary = array(
		// サイトマップID
		'sitemap_id' => $sitemap_id, 
		// サイトマップトップページID
		'sitemap_top_id' => $sitemap_top_id
);
// DBの更新
if ($objSitemap->update($db_ary) == FALSE) {
	$objCnc->rollback();
	sitemap_error("サイトマップ情報の更新に失敗しました。");
}

/* レイアウト情報の登録 */

// 登録の前に既に登録されている情報を削除
if ($objSitemapHandler->delete_layout($sitemap_id) == FALSE) {
	$objCnc->rollback();
	sitemap_error("サイトマップレイアウト情報の初期化に失敗しました。");
}

// 配列定数の取得
$SITEMAP_LAYOUT_DIRECTION = getDefineArray('SITEMAP_LAYOUT_DIRECTION');
$SITEMAP_LAYOUT_TAGS = getDefineArray('SITEMAP_LAYOUT_TAGS');

// サイトマップトップ非表示フラグ
$sitemap_top_none = (isset($_POST['cms_layout_none_1']) ? $_POST['cms_layout_none_1'][0] : FLAG_OFF);

// 自動反映エリア数分ループ
for($cnt = 0; $cnt < $floor; $cnt++) {
	// 登録する自動反映エリアの階層
	$floor_num = ($cnt + 1);
	
	// サイトマップトップが非表示の場合
	if ($floor_num == 1 && $sitemap_top_none == FLAG_ON) {
		// レイアウトの方向
		$direction = FLAG_OFF;
		// レイアウトのタグ
		$tag = FLAG_OFF;
		// 非表示フラグ
		$none = FLAG_ON;
	}
	// サイトマップトップが表示の場合
	// 下位階層の場合
	else {
		// レイアウトの方向
		if (!isset($_POST['cms_layout_direction_' . ($floor_num)]) || !isset($SITEMAP_LAYOUT_DIRECTION[$_POST['cms_layout_direction_' . ($floor_num)]])) {
			$objCnc->rollback();
			sitemap_error("不正なアクセスです。");
		}
		$direction = $_POST['cms_layout_direction_' . ($floor_num)];
		// レイアウトのタグ
		if (!isset($_POST['cms_layout_tag_' . ($floor_num)]) || !isset($SITEMAP_LAYOUT_TAGS[$_POST['cms_layout_tag_' . ($floor_num)]])) {
			$objCnc->rollback();
			sitemap_error("不正なアクセスです。");
		}
		$tag = $_POST['cms_layout_tag_' . ($floor_num)];
		// 非表示フラグ
		$none = FLAG_OFF;
	}
	
	// 登録情報の作成
	$db_ary = array(
			// レイアウト情報
			'class' => HANDLER_SITEMAP_CLASS_LAYOUT, 
			// サイトマップID
			'item1' => $sitemap_id, 
			// 自動反映エリア階層
			'item2' => $floor_num, 
			// レイアウト方向ID
			'item3' => $direction, 
			// レイアウトタグID
			'item4' => $tag, 
			// 非表示フラグ
			'item5' => $none
	);
	// 登録
	if ($objSitemapHandler->insert_layout($db_ary) == FALSE) {
		$objCnc->rollback();
		sitemap_error("レイアウト情報の登録に失敗しました。");
	}
}

/* サイトマップのページを登録 */

// 登録の前に既に登録されている情報を削除
if (delete_sitemap_display($sitemap_id) == FALSE) {
	$objCnc->rollback();
	sitemap_error("サイトマップ表示設定の削除に失敗しました。");
}

// サイトマップトップページの親ページでサイトマップリストを作成
$sitemap_top_page_ary = get_sitemap_floor($sitemap_id, $sitemap_top_ary['parent_id'], "", "", FLAG_OFF, FLAG_ON);

$before_page_ary = array();
$after_page_ary = array();

$sitemap_top_page_no = 0;

$after_flg = FLAG_OFF;
$cnt = 1;
foreach ($sitemap_top_page_ary as $page_id => $page_ary) {
	// サイトマップトップページID
	if ($page_id == $sitemap_top_id) {
		// 残りは後に移動
		$after_flg = FLAG_ON;
		$sitemap_top_page_no = $cnt;
		// サイトマップトップページは無視
		continue;
	}
	// 後半に追加するページ
	if ($after_flg == FLAG_ON) {
		$after_page_ary[$page_id] = $page_ary;
	}
	// 前半に追加するページ
	else {
		$before_page_ary[$page_id] = $page_ary;
	}
	$cnt++;
}

// ページの表示順設定を初期化
foreach ($_SESSION['sitemap_admin'] as $floor_num => $sess_detail) {
	// 
	foreach ($sess_detail as $parent_id => $page_ary) {
		// 登録処理
		foreach ($page_ary as $page_id => $pinfo) {
			// ページ情報の初期化
			if ($pinfo['type'] == SITEMAP_PAGE_TYPE_PAGE && delete_sitemap_page($page_id) == FALSE) {
				$objCnc->rollback();
				sitemap_error("サイトマップページ情報の削除に失敗しました。");
			}
		}
	}
}

// サイトマップトップページと同階層のページを再登録
$cnt = 1;
foreach ($before_page_ary as $before_page_id => $before_pinfo) {
	// まず削除
	if (delete_sitemap_page($before_pinfo['page_id']) == FALSE) {
		$objCnc->rollback();
		sitemap_error("サイトマップページ情報の削除に失敗しました。");
	}
	// 登録情報
	if (insert_sitemap_page_info($before_pinfo['page_id'], $before_pinfo['parent_id'], $before_pinfo, $cnt++) == FALSE) {
		$objCnc->rollback();
		sitemap_error("サイトマップページ情報の登録に失敗しました。");
	}
}

// セッションの情報を登録
foreach ($_SESSION['sitemap_admin'] as $floor_num => $sess_detail) {
	// 
	foreach ($sess_detail as $parent_id => $page_ary) {
		// 番号初期化
		$no = ($floor_num == 1 ? $sitemap_top_page_no : 1);
		// 登録処理
		foreach ($page_ary as $page_id => $pinfo) {
			// 一階層目の場合は現在登録されている情報を確認
			// ページ情報の登録
			if (insert_sitemap_page_info($page_id, $parent_id, $pinfo, $no++) == FALSE) {
				$objCnc->rollback();
				sitemap_error("サイトマップページ情報の登録に失敗しました。");
			}
			if (insert_sitemap_page_display($sitemap_id, $page_id, $pinfo) == FALSE) {
				$objCnc->rollback();
				sitemap_error("サイトマップ表示順情報の登録に失敗しました。");
			}
		}
		// 第一階層目の場合
		if ($floor_num == 1) {
			// サイトマップトップページと同階層のページを再登録
			foreach ($after_page_ary as $after_page_id => $after_pinfo) {
				// まず削除
				if (delete_sitemap_page($after_pinfo['page_id']) == FALSE) {
					$objCnc->rollback();
					sitemap_error("サイトマップページ情報の削除に失敗しました。");
				}
				// 登録情報
				if (insert_sitemap_page_info($after_pinfo['page_id'], $after_pinfo['parent_id'], $after_pinfo, $no++) == FALSE) {
					$objCnc->rollback();
					sitemap_error("サイトマップページ情報の登録に失敗しました。");
				}
			}
		}
	}
}

// 
$objCnc->commit();

// セッション情報を削除
unset($_SESSION['sitemap_admin']);

/* インデックスページへジャンプ */
header("Location: " . HTTP_ROOT . RPW . '/admin/page/sitemap/index.php');
exit();

?>