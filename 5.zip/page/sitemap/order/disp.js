// 表示設定画面用Javascript

// ページ読込時に実行するスクリプトを設定
Event.observe(window,'load', cxCreateSitemapDispList, false);

// 画像ロード
cxPreImages(
		cms8341admin_path+'/page/sitemap/images/btn_add_link.jpg',
		cms8341admin_path+'/page/sitemap/images/btn_del_link.jpg',
		cms8341admin_path+'/page/sitemap/images/btn_add_comment_on.jpg',
		cms8341admin_path+'/page/sitemap/images/btn_add_comment_off.jpg',
		cms8341admin_path+'/page/sitemap/images/btn_del_comment.jpg',
		cms8341admin_path+'/page/sitemap/images/icon_file.jpg'
);


// ドラッグ＆ドロップ
Sortable.destroy = function(element) {
    element = $(element);
	var s = Sortable.sortables[element.id];
    if (s) {
      Draggables.removeObserver(s.element);
      s.droppables.each(function(d){ Droppables.remove(d) });
      s.draggables.invoke('destroy');
      delete Sortable.sortables[s.element.id];
    }
}
var dragdrop_op = {
	// 対象タグ
	tag:    'div'
};

/**
 * 決定処理
 * 
 * @return false
 */
function cxSubmit() {
	// Ajax処理中は処理無効
	if (ajax_flg == true) {
		return false;
	}
	// フォーム情報設定
	$('cms_sitemap_form').action = "./layout.php";
	$('cms_sitemap_form').method = "post";
	// フォーム送信
	$('cms_sitemap_form').submit();
	return false;
}

/**
 * 表示設定初期表示画面の生成
 * 
 * @param  なし
 * @return なし
 */
function cxCreateSitemapDispList() {
	// Ajax処理中は処理無効
	if (ajax_flg == true) {
		return false;
	}
	ajax_flg = true;
	
	// 処理中レイヤーの表示
	$('cms8341-progressmsg').innerHTML = 'サイトマップ情報構築中．．．';
	cxLayer('cms8341-progress',1,500,500);

	// Ajaxパラメーター
	var params = 'sitemap_id='+$("cms_sitemap_id").value;
	params += '&sitemap_top_id='+$("cms_sitemap_top_id").value;

	// AjaxでPHPに接続
	var r = new Ajax.Request(
		cms8341admin_path+'/page/sitemap/order/request/create_sitemap_disp_list.php',
		{
			method: 'post',
			asynchronous: true,
			parameters: params,
			// 通信成功時の処理
			onSuccess: function () {
				// PHP からの戻値
				cxCreateSitemapDispListSuccess(r.transport)
			},
			// 通信失敗時の処理
			onFailure: function () {
				// エラー
				alert("処理中にエラーが発生しました。");
				// Ajax処理フラグを解除
				ajax_flg = false;
			}
		}
	);
}

var set_exec;
var set_script;

/**
 * 表示設定初期表示画面の生成（Ajax実行結果）
 * 
 * @param  r Ajaxで取得した結果の戻値
 * @return なし
 */
function cxCreateSitemapDispListSuccess(r) {

	var r_text = r.responseText;
	
	// 取得に失敗しているかチェック
	if (r_text.indexOf("true,",0) !== 0) {
		// 処理中レイヤーの非表示
		cxLayer('cms8341-progress',0 );
		// エラー
		alert("処理中にエラーが発生しました。");
		// Ajax処理フラグを解除
		ajax_flg = false;
		
		return false;
	}
	r_text = r_text.replace(/^true,/, "");
	
	// HTML
	var html = r_text;

	// HTML適用
	$("cms_sitemap_top").innerHTML = html;

	// スクリプト実行のためレイヤーの文言を変更
	$('cms8341-progressmsg').innerHTML = '表示設定情報構築中．．．';
	cxLayer('cms8341-progress',1,500,500);

	// 取得した情報をドラッグ＆ドロップできるようにスクリプトを取得
	var m = html.match(/<!-- SCRIPT([\s\S.]*)?SCRIPT -->/i);
	// スクリプトを1行ずつ実行するため改行で分解
	set_script = RegExp.$1.split(/\r?\n/);

	// スクリプト一覧の先頭にスクリプトを追加
	set_script.unshift('set_div_width($(\'cms_sitemap_top\'));');

	// スクリプト実行予約
	interval_exec = setTimeout("cxExecuteDragdropTrue()", 1);
}

/**
 * テキスト配列のスクリプトを実行
 * 
 * @param  なし
 * @return なし
 */
function cxExecuteDragdropTrue() {
	// 実行するスクリプトが存在する場合
	if (set_script.length > 0) {
		// レイヤーを中心に移動
		cxLayer('cms8341-progress',1,500,500);
		// スクリプト実行
		eval(set_script[0]);
		// 実行したスクリプトを配列から削除
		set_script.splice(0, 1);
		// スクリプト実行予約
		clearTimeout(interval_exec);
		interval_exec = setTimeout("cxExecuteDragdropTrue()", 1);
	}
	// 処理終了
	else {
		clearTimeout(interval_exec);
		// 処理中レイヤーの非表示
		cxLayer('cms8341-progress',0);
		// Ajax処理フラグを解除
		ajax_flg = false;
	}
}

/**
 * DIVの横幅を調整
 * 
 * @param  ele 子要素挿入領域のエレメント
 * @return なし
 */
function set_div_width(ele){
	var target = document.getElementsByClassName("cms8341-sitemaplist", ele);
	target.each( function(val){
		val.style.width = document.getElementsByClassName("cms8341-sitemaplist-inline",val)[0].getBoundingClientRect().width;
	});
}

/**
 * 表示設定のチェックボックスをクリックした時の処理
 * 
 * @param  eid チェックボックスのエレメントID
 * @return なし
 */
function cxOnClickSitemapPage(eid) {
	// Ajax処理中は処理無効
	if (ajax_flg == true) {
		return false;
	}
	// 対象のチェックの状態を取得
	var checked = ($(eid).checked ? 'checked' : '' );
	// 親ページ配列
	var parent_ary = new Array($(eid).value);
	// ページ内のインプットボックス全てを取得
	var inputlist = document.getElementsByTagName('input');
	// 対象のチェックボックスを再生成
	$(eid).outerHTML = createSitemapCheckBox(eid, $(eid).value, $(eid).getAttribute('_parent_id'), $(eid).checked, 'enabled');
	// 子ページのチェックボックスを同期
	for (var i = 0 ; i < inputlist.length ; i ++) {
		// チェックボックス以外は無視
		if (! inputlist[i].type || inputlist[i].type != 'checkbox') {
			continue;
		}
		// 表示順変更用のチェックボックス以外は無視
		if (! inputlist[i].getAttribute('_parent_id') || ! in_array(inputlist[i].getAttribute('_parent_id'), parent_ary)) {
			continue;
		}
		// 親ページ一覧配列に追加
		parent_ary.push(inputlist[i].value);
		// チェックボックスの再生成
		inputlist[i].checked = checked;
		inputlist[i].outerHTML = createSitemapCheckBox(inputlist[i].id, inputlist[i].value, inputlist[i].getAttribute('_parent_id'), inputlist[i].checked);
	}
	return ;
}

/**
 * 表示設定のチェックボックスを再生成
 * 
 * @param  nm INPUTタグの「name」属性
 * @param  vl INPUTタグの「value」属性
 * @param  pt INPUTタグの「_parent_id」属性
 * @param  ck INPUTタグの「checked」属性
 * @param  ed INPUTタグの「disabled」属性
 * @return    再生成したチェックボックスHTML
 */
function createSitemapCheckBox(nm, vl, pt, ck, ed) {
	// 属性： id
	var ei = 'id="'+nm+'"';
	// 属性： name
	var en = 'name="'+nm+'"';
	// 属性： value
	var ev = 'value="'+vl+'"';
	// 属性： checked
	var ec = (ck == true ? 'checked="checked"' : (ed == 'enabled' ? '' : 'disabled="disabled"'));
	// 属性： onClick
	var eo = '';
	if (nm.indexOf("_link",0) == -1 && nm.indexOf("_comment",0) == -1) {
		eo = 'onClick="return cxOnClickSitemapPage(\''+nm+'\')"';
	}
	// 属性： _parent_id
	var ep = '_parent_id="'+pt+'"';
	// 戻値： 作成したタグ
	return '<input type="checkbox" '+ei+' '+en+' '+ev+' '+ec+' '+eo+' '+ep+' />';
}

/**
 * リンク設定
 * 
 * @param  page_id   ページID
 * @param  parent_id 親ページID
 * @param  now_floor 現在の階層
 * @param  upd       更新モード
 * @return なし
 */
function cxLinkSet(page_id, parent_id, now_floor, upd) {
	// Ajax処理中は処理無効
	if (ajax_flg == true) {
		return false;
	}
	// 処理モード
	if (upd != undefined && upd == FLAG_ON && $(page_id)) {
		upd = FLAG_ON;
	}
	else {
		upd = FLAG_OFF;
	}
	// リンク初期値
	var link_params = "";
	// 修正の場合
	if (upd == FLAG_ON) {
		// 修正のための引数追加
		link_params = $(page_id).value.replace("#","＃")
		link_params = encodeURIComponent(link_params).replace(/&/g, "%26");
	}
	// リンク設定の戻値を格納するためのオブジェクト
	var retObj = new Object();
	// サイトマップモードの設定
	if (cxSetSitemapSession('cms_sitemap_linkset', FLAG_ON) == false) {
		alert("通信に失敗しました。");
		return false;
	}
	// ダイアログの表示
	cxIframeLayer(
		cms8341admin_path + "/page/sitemap/order/link/link.php?value="+link_params+"&acc_flg="+acc_flg,
		458,
		459,
		COVER_SETTING.COLOR,
		'',
		function (retObj) {
			// サイトマップモードの解除
			cxSetSitemapSession('cms_sitemap_linkset', FLAG_OFF);

			// オブジェクトなし
			if(retObj== undefined) return;

			// オブジェクトの値を変更する
			tmpAry = retObj['ret'].split(SITEMAP_LINK_DELIMITER);
			if(tmpAry[1] != undefined){
				tmpAry[1] = tmpAry[1].replace("＃","#");
			}

			// リンク文字列
			var link_str = tmpAry[1];
			if (tmpAry[3]) {
				link_str += cxCreateLinkFileStrings(tmpAry);
			}

			//ファイルリンクの情報文字列
			link_str += cxCreateOtherWindowStrings(tmpAry, acc_flg);
			//
			var e_pid = page_id+'_link';
			var e_chk = 'check_'+e_pid+'_';
			var e_spn = 'span_'+e_pid+'_';
			var e_hdn = e_pid+'_';
			// 親タグエレメント
			var parent_chk = $('check_'+parent_id);
			var parent_ele = (now_floor == 1 ? $('cms_sitemap_top') : $('cms_sitemap_'+parent_id));

			var checked  = true;
			var disabled = 'enabled';

			if (now_floor > 1) {
				checked  = parent_chk.checked;
				disabled = (parent_chk.disabled == true || checked == false ? 'disabled' : 'enabled');
			}

			// リンク追加の場合の処理
			if (upd != FLAG_ON) {
				// inputタグを全て取得
				var inputlist = document.getElementsByTagName('input');

				// 最大値+1を作成するリンクのIDとする
				var max_id = 0;
				for (var i = 0 ; i < inputlist.length ; i ++ ) {
					// マッチ
					if (inputlist[i].id && inputlist[i].id.indexOf(e_chk ) == 0 ) {
						if (max_id < Number(inputlist[i].id.replace(e_chk, "" ) ) )
							max_id = Number(inputlist[i].id.replace(e_chk, "" ) );
					}
				}
				// 取得した最大値+1
				max_id ++;
				// エレメントIDにリンクID追加
				e_chk = e_chk+max_id;
				e_spn = e_spn+max_id;
				e_hdn = e_hdn+max_id;
			}
			// リンク修正の場合の処理
			else {
				e_chk = 'check_'+page_id;
				e_spn = 'span_'+page_id;
				e_hdn = page_id;
			}

			// 内容作成
			var html = LINK_HTML_FMT;
			html = html.replace(/<!--%RPW%-->/g, RPW);
			html = html.replace(/<!--%checkbox%-->/g, createSitemapCheckBox(e_chk, e_hdn, parent_id, checked, disabled));
			html = html.replace(/<!--%link_text%-->/g, htmlEscape(cxEscapeHtmlChars(link_str)));
			html = html.replace(/<!--%link_value%-->/g, htmlEscape(cxEscapeHtmlChars(retObj['ret'])));
			html = html.replace(/<!--%page_id%-->/g, e_hdn);
			html = html.replace(/<!--%parent_id%-->/g, parent_id);
			html = html.replace(/<!--%now_floor%-->/g, now_floor);

			// リンク追加の場合のリンク挿入
			if (upd != FLAG_ON) {
				// DIVタグ
				var div = document.createElement("div");
				// 属性追加
				div.id        =  e_spn;
				div.align     = 'left';
				div.className = 'cms8341-sitemaplist';
				if (now_floor > 1) {
					div.style.marginLeft = '50px';
				}
				// SPANタグ
				var span = document.createElement("span");
				span.id = 'cms_sitemap_'+e_hdn;
				span.innerHTML = html;

				div.appendChild(span);

				// リンク挿入位置のエレメント
				var after_ele = false;

				var nodes = parent_ele.childNodes;
				for (var i = 0 ; i < nodes.length ; i ++ ) {
					// 対象エレメントの確認
					if (! nodes[i].className) {
						continue;
					}
					if (nodes[i].className != 'cms8341-sitemaplist' ) {
						continue;
					}
					after_ele = nodes[i];
					break;
				}
				// リンク追加
				if (after_ele) {
					parent_ele.insertBefore(div, nodes[i]);
				}
				else {
					parent_ele.appendChild(div);
				}
			}
			// リンク修正の場合のリンク挿入
			else {
				$('cms_sitemap_'+e_hdn).innerHTML = html;
			}

			// 追加したエレメントを移動可能状態にする
			Sortable.create(parent_ele, dragdrop_op);
		}
	);
}

/**
 * ファイルリンクの情報文字列を作成
 * 
 * @param  tmpAry リンク設定で取得した戻値を分解した配列
 * @return 作成したリンク情報文字列
 */
function cxCreateLinkFileStrings(tmpAry) {
	//配列を作成
	var ADD_FILE_DETAIL_EXP_ARY = getAddFileDetailExp();

	// 変数の宣言
	var file_ext_str = "";
	var file_size    = "";
	var file_class   = "";

	// ファイルサイズ
	if(tmpAry[4]) file_size = tmpAry[4];
	// ファイル種別の指定
	if(ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]) {
		
		if(acc_flg == SITEMAP_LANGUAGE_JP) {
			file_ext_str = '（' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['JP'];
		}
		else {
			file_ext_str = '(' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['EN'];
		}
		
		// クラスの指定
		if(ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['CLASS'] != "") file_class = ' class="' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['CLASS'] + '"'
		// ファイルサイズの指定
		if(file_size) file_ext_str += (acc_flg == SITEMAP_LANGUAGE_JP ? "：" : ":") + numEdit(Math.ceil(file_size / 1024)) + "KB";
		file_ext_str += (acc_flg == SITEMAP_LANGUAGE_JP ? "）" : ")");
	}
	
	return file_ext_str;
}

/**
 * リンク削除
 * 
 * @param  delete_ele 削除対象エレメント
 * @param  parent_ele 削除対象の親エレメント
 * @return なし
 */
function cxLinkDelete(delete_ele, parent_ele) {
	// Ajax処理中は処理無効
	if (ajax_flg == true) {
		return false;
	}
	if (! confirm("選択したリンクを削除しますか？")) {
		return ;
	}
	if (!$(parent_ele)) {
		parent_ele = 'cms_sitemap_top';
	}
	$(parent_ele).removeChild($(delete_ele));
}

/**
 * コメント設定
 * 
 * @param  page_id   ページID
 * @param  parent_id 親ページID
 * @param  now_floor 現在の階層
 * @param  upd       更新モード
 * @return なし
 */
function cxCommentSet(page_id, parent_id, now_floor, upd ) {
	// Ajax処理中は処理無効
	if (ajax_flg == true) {
		return false;
	}
	// コメント初期値
	var comment_params = "";
	// 修正の場合
	if (upd != undefined && upd == FLAG_ON && $(page_id+'_comment')) {
		comment_params = encodeURIComponent($(page_id+'_comment').value).replace(/&/g, "%26");
	}
	
	var retObj = new Object();
	cxIframeLayer(
		cms8341admin_path + "/page/sitemap/order/comment/comment.php?comment="+comment_params,
		638,
		460,
		COVER_SETTING.COLOR,
		'',
		function (retObj) {
			if(retObj== undefined) return;

			// 親タグエレメント
			var parent_ele = $('check_'+page_id);

			// 内容作成
			var html = COMMENT_HTML_FMT;

			var m = html.match(/<!-- COMMENT START -->([\s\S.]*)?<!-- COMMENT END -->/i);

			if (! m) {
				alert("コメントの追加に失敗しました。");
				return false;
			}

			var checked  = parent_ele.checked;
			var disabled = (parent_ele.disabled == true || checked == false ? 'disabled' : 'enabled');

			html = m[1];

			html = html.replace(/<!--%RPW%-->/g, RPW);
			html = html.replace(/<!--%checkbox%-->/g, createSitemapCheckBox('check_'+page_id+'_comment', page_id+'_comment', page_id, checked, disabled));
			html = html.replace(/<!--%page_id%-->/g, page_id);
			html = html.replace(/<!--%parent_id%-->/g, parent_id);
			html = html.replace(/<!--%commnet%-->/g, htmlEscape(cxEscapeHtmlChars(retObj['ret'])));
			html = html.replace(/<!--%comment_detail%-->/g, cxEscapeHtmlChars(retObj['ret']));
			html = html.replace(/<!--%now_floor%-->/g, Number(now_floor));
			html = html.replace(/<!--%display%-->/g, "block");

			// 追加したエレメントをコメント領域に挿入
			$('cms_comment_'+page_id).innerHTML = html;
			$('cms_comment_'+page_id).style.display = 'block';

			// コメント追加ボタンを非アクティブ
			$('cms_add_comment_on_'+page_id).style.display = 'none';
			$('cms_add_comment_off_'+page_id).style.display = 'inline';
		}
	);
}

/**
 * コメント削除
 * 
 * @param  page_id ページID
 * @return なし
 */
function cxCommentDelete(page_id) {
	// Ajax処理中は処理無効
	if (ajax_flg == true) {
		return false;
	}
	if (! confirm("選択したコメントを削除しますか？" ) ) {
		return ;
	}
	// 対象エレメントが不正
	if (! $('cms_comment_'+page_id)) return;
	
	// HTML削除
	$('cms_comment_'+page_id).innerHTML = "";
	$('cms_comment_'+page_id).style.display = 'none';
	
	// 対象ページのコメント追加ボタンをアクティブにする
	$('cms_add_comment_on_'+page_id).style.display = 'inline';
	$('cms_add_comment_off_'+page_id).style.display = 'none';
	
	return;
}

/**
 * マウスオーバー時のイベント
 * 
 * @param  my 対象エレメント
 * @return なし
 */
function cxSitemapMouseOver(my) {
	my.style.backgroundColor = '#ffffaa';
}
/**
 * マウスアウト時のイベント
 * 
 * @param  my 対象エレメント
 * @return なし
 */
function cxSitemapMouseOut(my) {
	if (my.style.removeProperty) {
		my.style.removeProperty('background-color');
	} 
	else {
		my.style.removeAttribute('backgroundColor');
	}
}

/**
 * ファイルリンクの情報文字列を作成
 * 
 * @param  tmpAry リンク設定で取得した戻値を分解した配列
 * @param  acc_flg 言語判定用フラグ
 * @return 作成したリンク情報文字列
 */
function cxCreateOtherWindowStrings(tmpAry, acc_flg) {
	// 変数の宣言
	var other_window_str = '';
	
	// target属性値が指定されている場合
	if (tmpAry[2] && tmpAry[2] == '_blank') {
		// 日本語テンプレートの場合
		if (acc_flg == SITEMAP_LANGUAGE_JP) {
			other_window_str += OTHER_WINDOW_STR_JP;
		}
		// 外国語テンプレートの場合
		else if (acc_flg == SITEMAP_LANGUAGE_EN) {
			other_window_str += OTHER_WINDOW_STR_EN;
		}
	}
	
	return other_window_str;
}