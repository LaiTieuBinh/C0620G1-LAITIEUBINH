<?php
// キャッシュ制御
header("Cache-Control: public");
header("Pragma: public");
session_cache_limiter('private');

require ("../.htsetting");
require ("../common.inc");

// DB
global $objCnc;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap.inc');
$objSitemap = new tbl_sitemap($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

// エラーチェック
if (!isset($_POST['cms_sitemap_top_id']) || !isset($_POST['cms_sitemap_id'])) {
	sitemap_error('不正アクセスです。');
}

// サイトマップ情報の取得
if (!$objSitemap->selectFromID($_POST['cms_sitemap_id'])) {
	sitemap_error('サイトマップ情報の取得に失敗しました。');
}
$sitemap_id = $_POST['cms_sitemap_id'];
$sitempa_ary = $objSitemap->fld;

// サイトマップのトップページの情報を取得
$getc = 'p.page_id, p.page_title, p.parent_id';
if (!$objPage->selectFromId($_POST['cms_sitemap_top_id'], $getc)) {
	sitemap_error('サイトマップトップページ情報の取得に失敗しました。');
}
$sitemap_top_id = $_POST['cms_sitemap_top_id'];
$sitemap_top_ary = $objPage->fld;
// 


$link_html_fmt = file_get_contents(APPLICATION_ROOT . "/common/templates/sitemap_disp_link.txt");
$comment_html_fmt = file_get_contents(APPLICATION_ROOT . "/common/templates/sitemap_disp_comment.txt");

/* HTML出力情報 */

// タイトル
$title_html = '表示設定';
$title_image = '<img src="../images/bar_sitemap_disp.jpg" alt="表示設定" width="920" height="30" />';

// ボタン
$button_next = '<a href="javascript:" 	onClick="return cxSubmit()"><img src="' . RPW . '/admin/images/btn/btn_submit.jpg" alt="決定" width="102" height="21"  border="0" style="margin-right: 10px" /></a>';
$button_back = '<a href="javascript:history.back();"><img src="' . RPW . '/admin/images/btn/btn_cansel.jpg" alt="キャンセル" width="101" height="21" border="0" style="margin-left: 10px" /></a>';

$space_img = '<img src="' . RPW . '/admin/images/spacer.gif" alt="" width="60" height="20" border="0">';

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<link rel="stylesheet" href="../sitemap.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="../sitemap.js" type="text/javascript"></script>
<script src="./disp.js" type="text/javascript"></script>

<script type="text/javascript">
<!--//
<?php
echo loadSettingVars();
?>
var LINK_HTML_FMT = '<?=preg_replace("/\r?\n/", "\\n", javaStringEscape($link_html_fmt))?>';
var COMMENT_HTML_FMT = '<?=preg_replace("/\r?\n/", "\\n", javaStringEscape($comment_html_fmt))?>';
var space_image = '<?=preg_replace("/\r?\n/", "\\n", javaStringEscape($space_img))?>';
var SITEMAP_LANGUAGE_JP = <?=SITEMAP_LANGUAGE_JP?>;
var SITEMAP_LANGUAGE_EN = <?=SITEMAP_LANGUAGE_EN?>;
var SITEMAP_NON_PARENT_STRING = '<?=javaStringEscape(SITEMAP_NON_PARENT_STRING)?>';
var SITEMAP_LINK_DELIMITER = '<?=javaStringEscape(SITEMAP_LINK_DELIMITER)?>';
var acc_flg = <?=$sitempa_ary['language']?>;
var ajax_flg = false;
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'sitemap';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-sitemap">
<div><?=$title_image?></div>
<div class="cms8341-area-corner">

<form class="cms8341-form" id="cms_sitemap_form" name="cms_sitemap_form"
	method="post" action="#" onSubmit="return false;">

<p style="color:#990000;font-size:12px;margin-top:20px;">※ドラッグ＆ドロップで項目の順序を入れ替えることができます。</p>

<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<td valign="top">
		<div id="cms_sitemap_top"><!-- ここにサイトマップの情報が表示されます。 --></div>
		</td>
	</tr>
</table>

<p><input type="hidden" name="cms_sitemap_id" id="cms_sitemap_id"
	value="<?=$sitemap_id?>" /> <input type="hidden"
	name="cms_sitemap_top_id" id="cms_sitemap_top_id"
	value="<?=$sitemap_top_id?>" /></p>

<p align="center">
<?=$button_next?><?=$button_back?>
</p>

</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>

<!--***処理中プロパティレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0" style="background-image:url(<?=RPW?>/admin/images/layer/titlebar_bg.jpg);height:30px;">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg">メッセージ</div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理中プロパティレイヤー ここまで********************************-->

</body>
</html>