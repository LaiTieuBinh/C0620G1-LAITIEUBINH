<?php
/*
 * ダウンロード結果ダイアログの表示
 */
/* 設定ファイル */

require ("../../.htsetting");

/* エラー画面設定 */
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$dacTools = new dac_tools($objCnc);

/* HTML出力情報 */
$comment = (isset($_GET['comment']) ? $_GET['comment'] : "");

// タイトル
$title_html = 'コメント設定';
$title_image = '<img src="" alt="表示設定" width="920" height="30" />';

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex, nofollow" />
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=htmlDisplay($title_html)?></title>
<base target="_self">
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
function cxSubmit() {
	// 入力内容の前後の空白を除去
	var comment = trim($('cms_comment').value);
	// 未入力
	if (comment == "") {
		alert("コメントが入力されていません。");
		$('cms_comment').focus();
		return false;
	}
	// 入力チェック
	var info = new Array();
	info = fckCheck('コメント',comment, info );
	// 
	if(info) {
		// エラーの場合
		if(info.length > 0){
			// 確認のダイアログを表示
			var msg = info.join('\n') + '\nよろしいですか？';
			if(!confirm(msg)){
				$('cms_comment').focus();
				return false;
			}
		}
	}
	// 戻値
	var retObj = new Object();
	// 戻値をセット
	retObj['ret'] = comment;
	cxIframeLayerCallback(retObj);
}

Event.observe(window,'load', function(){$('cms_comment').focus();} );

//-->
</script>
</head>
<body bgcolor="#FFFFFF">
<div id="cms8341-headareaZero" style="margin-bottom: 0px !important">
<table width="630" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="630" height="400" align="center" valign="top"
			bgcolor="#DFDFDF" style="border: solid 1px #343434;"><!--  ヘッダー -->
		<table width="630" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/fcklink/title_linkset.jpg"
					alt="<?=htmlDisplay($title_html)?>" width="200" height="20"
					style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a
					href="javascript:void(0)"
					onClick="cxIframeLayerCallback();return false;"><img
					src="<?=RPW?>/admin/images/fcklink/btn_close.jpg" alt="閉じる"
					width="58" height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<!--  コンテンツ -->
		<div
			style="width: 610px; height: 355px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #343434">
		<div align="center">
		<div
			style="width: 570px; height: 265px; padding: 8px; text-align: left">

		<table border="0" cellspacing="0" align="center" width="570px">
			<tr>
				<th width="30%" align="left" valign="top"
					style="font-size: 12px; font-weight: bold; padding: 5px; vertical-align: top; border: solid 1px #999999;"
					bgcolor="#eeeeee" nowrap>コメント</th>
				<td width="70%"
					style="border-top: solid 1px #999999; border-right: solid 1px #999999; border-bottom: solid 1px #999999;"><textarea
					style="width: 320px; height: 240px;" name="cms_comment"
					id="cms_comment"><?=htmlspecialchars($comment)?></textarea></td>
			</tr>
		</table>

		</div>

		<div style="margin: 15px 0px;"><a href="javascript:void(0)"
			onClick="return cxSubmit();"><img
			src="<?=RPW?>/admin/images/fcklink/btn_complete.jpg" alt="完了"
			width="100" height="20" border="0"></a></div>

		</div>
		</div>

<?php
print($dacTools->setAccessibility());
?>

</td>
	</tr>
</table>

</div>

</body>
</html>
