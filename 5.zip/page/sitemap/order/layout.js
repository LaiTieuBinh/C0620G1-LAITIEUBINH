// レイアウト設定画面用javascript

// ページ読込時に実行するスクリプトを設定
Event.observe(window,'load', function() {cxChangeNoneCheckBox(1);});


// Ajax処理フラグ
var ajax_flg = false;

/**
 * 決定処理
 * 
 * @return false
 */
function cxSubmit() {
	// Ajax処理中は処理無効
	if (ajax_flg == true) {
		return false;
	}
	// エラーチェック
	if (cxSitemapErrorCheck() == false) {
		return false;
	}
	// フォーム情報設定
	$('cms_sitemap_form').action = "./submit.php";
	$('cms_sitemap_form').target = "_self";
	$('cms_sitemap_form').method = "post";
	// フォーム送信
	$('cms_sitemap_form').submit();
	return false;
}

/**
 * プレビュー処理
 * 
 * @return false
 */
function cxSitemapPreview() {
	// Ajax処理中は処理無効
	if (ajax_flg == true) {
		return false;
	}
	// エラーチェック
	if (cxSitemapErrorCheck() == false) {
		return false;
	}
	// フォーム情報設定
	$('cms_sitemap_form').action = "../sitemap_preview.php";
	$('cms_sitemap_form').target = "_blank";
	$('cms_sitemap_form').method = "post";
	// フォーム送信
	$('cms_sitemap_form').submit();
	return false;
}

/**
 * エラーチェック
 * 
 * @return true（エラーなし）false（エラー）
 */
function cxSitemapErrorCheck() {
	// エラーチェック
	for (var i = 1 ; i <= floor ; i ++) {
		if ($('cms_layout_direction_'+i+'_1').checked == false && $('cms_layout_direction_'+i+'_2').checked == false) {
			alert("第"+i+"階層のレイアウトが選択されていません。");
			return false;
		}
	}
	return true;
}

/**
 * 縦・横レイアウトの選択を制御
 * 
 * @param  now_floor 選択したレイアウト階層
 * @return なし
 */
function cxCheckLayoutDirection(now_floor) {
	// 対象エレメント
	var ele = 'cms_layout_direction_'+now_floor;

	// 「横」が選択されている場合
	if ($(ele+'_'+SITEMAP_LAYOUT_SIDE).checked == true) {
		// 下位階層のラジオの選択を無効・縦に強制
		for (var n = (now_floor+1) ; n <= floor ; n ++) {
			$('cms_layout_direction_'+n+'_'+SITEMAP_LAYOUT_VERTICAL).checked = true;
			$('cms_layout_direction_'+n+'_'+SITEMAP_LAYOUT_SIDE).checked = false;
			$('cms_layout_direction_'+n+'_'+SITEMAP_LAYOUT_SIDE).disabled = true;
		}
	}
	// 「縦」が選択されている場合
	else {
		// 下位階層のラジオの選択を有効
		for (var n = (now_floor+1) ; n <= floor ; n ++) {
			if ($('cms_layout_direction_'+n+'_'+SITEMAP_LAYOUT_SIDE).checked == true) {
				break;
			}
			$('cms_layout_direction_'+n+'_'+SITEMAP_LAYOUT_SIDE).disabled = false;
		}
	}
}

/**
 * タグの選択を制御
 * 
 * @param  now_floor 選択したタグの階層
 * @return なし
 */
function cxSelectLayoutTag(now_floor) {
	// 制御
	cxCreateSelectOption(now_floor);
	// フォーカスを移動
	window.focus();
}

/**
 * タグ選択の制御スクリプト
 * 
 * @param  now_floor 選択したタグの階層
 * @return false
 */
function cxCreateSelectOption(now_floor) {
	// 設定階層をオーバーしている場合
	if (now_floor > floor) {
		// Ajax処理フラグを解除
		ajax_flg = false;
		// 処理中断
		return false;
	}
	// サイトマップトップが非表示の場合
	if (sitemap_top_none == FLAG_ON && now_floor == 1) {
		// 2階層目がスタート
		now_floor = 2;
	}

	// Ajax処理フラグを有効
	ajax_flg = true;

	// 指定階層のタグ設定を取得
	var idx = $('cms_layout_tag_'+(Number(now_floor))).options.selectedIndex;
	var now_value = $('cms_layout_tag_'+(Number(now_floor))).options[idx].value;

	// 指定階層の親階層のタグ設定を取得
	var parent_value = "";
	if (now_floor > 1) {
		var pidx = $('cms_layout_tag_'+(Number(now_floor)-1)).options.selectedIndex;
		parent_value = $('cms_layout_tag_'+(Number(now_floor)-1)).options[pidx].value;
	}

	// Ajaxパラメーター
	var params = 'now_floor='+now_floor;
	params += '&now_value='+now_value;
	params += '&parent_value='+parent_value;
	params += '&sietmap_top_none='+sitemap_top_none;

	// AjaxでPHPに接続
	var r = new Ajax.Request(
		cms8341admin_path+'/page/sitemap/order/request/create_layout_select.php',
		{
			method: 'post',
			asynchronous: true,
			parameters: params,
			// 通信成功時の処理
			onSuccess: function () {
				// PHP からの戻値
				var html = r.transport.responseText;
				// 取得処理に成功
				if (html.indexOf("true,",0) === 0) {
					// trueを削除
					html = html.replace(/^true,/, "");
					// HTMLに反映
					$('cms_layout_tag_'+(Number(now_floor))+'_box').innerHTML = html;
					// 下位階層の選択も制御
					cxCreateSelectOption(Number(now_floor)+1);
				}
				// 取得処理に失敗
				else {
					// エラー
					alert("予期せぬエラーが発生しました。");
					// Ajax処理フラグを解除
					ajax_flg = false;
				}
			},
			// 通信失敗時の処理
			onFailure: function () {
				// エラー
				alert("予期せぬエラーが発生しました。");
				// Ajax処理フラグを解除
				ajax_flg = false;
			}
		}
	);

	return false;
}

function cxChangeNoneCheckBox(now_floor) {
	
	// 第1階層だけの場合、以下を処理
	// 第1階層だけの場合、そもそもチェックボックスを生成していないので、
	// オブジェクトがNULLとなる
	if(!$('cms_layout_none_'+now_floor+'_'+FLAG_ON)){
		return false;	
	}
	
	// チェック状態
	var checked = $('cms_layout_none_'+now_floor+'_'+FLAG_ON).checked;

	// Ajax処理中は処理無効
	if (ajax_flg == true) {
		$('cms_layout_none_'+now_floor+'_'+FLAG_ON).checked = (checked == true ? false : true);
		return false;
	}

	// 対象エレメント
	var target = $('cms_layout_td_'+now_floor);
	
	// 非表示の場合
	if (checked == true) {
		// サイトマップトップ非表示フラグを有効
		sitemap_top_none = FLAG_ON;
		// レイアウト選択不可
		$('cms_layout_direction_'+now_floor+'_'+SITEMAP_LAYOUT_VERTICAL).checked = true;
		$('cms_layout_direction_'+now_floor+'_'+SITEMAP_LAYOUT_VERTICAL).disabled = true;
		$('cms_layout_direction_'+now_floor+'_'+SITEMAP_LAYOUT_SIDE).checked = false;
		$('cms_layout_direction_'+now_floor+'_'+SITEMAP_LAYOUT_SIDE).disabled = true;
		$('cms_layout_tag_'+now_floor).disabled = true;
	}
	// 表示の場合
	else {
		// サイトマップトップ非表示フラグを無効
		sitemap_top_none = FLAG_OFF;
		// レイアウト選択可
		$('cms_layout_direction_'+now_floor+'_'+SITEMAP_LAYOUT_VERTICAL).disabled = false;
		$('cms_layout_direction_'+now_floor+'_'+SITEMAP_LAYOUT_SIDE).disabled = false;
		$('cms_layout_tag_'+now_floor).disabled = false;
	}
	// レイアウトの選択の制御
	cxCheckLayoutDirection(now_floor);
	cxSelectLayoutTag(now_floor);
}
