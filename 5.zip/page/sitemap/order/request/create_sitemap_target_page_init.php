<?php
// 設定ファイル読み込み
require_once ("../../.htsetting");
require_once ("../../common.inc");

// エラーチェック
if (!isset($_POST['sitemap_id'])) {
	echo "false,";
	exit();
}
if (!isset($_POST['sitemap_top_id'])) {
	echo "false,";
	exit();
}

// 表示対象設定画面初期化用HTMLの生成
$ret = create_sitemap_target_page_init($_POST['sitemap_id'], $_POST['sitemap_top_id']);

echo "true," . $ret;
exit();
?>
