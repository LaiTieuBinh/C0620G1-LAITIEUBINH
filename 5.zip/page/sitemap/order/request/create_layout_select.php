<?php
require_once ("../../.htsetting");
require_once ("../../common.inc");

// エラーチェック
if (!isset($_POST['now_floor']) || !isset($_POST['now_value']) || !isset($_POST['parent_value'])) {
	echo "false,";
	exit();
}

// 引数取得
$now_floor = $_POST['now_floor'];
$now_value = $_POST['now_value'];
$sitemap_top_none = (isset($_POST['sietmap_top_none']) ? $_POST['sietmap_top_none'] : FLAG_OFF);

// トップ階層の指定
$start_floor = ($sitemap_top_none == FLAG_ON ? 2 : 1);

// 選択リスト
$SITEMAP_LAYOUT_TAGS = getDefineArray('SITEMAP_LAYOUT_TAGS');
$parent_key = $_POST['parent_value'];
$option = $SITEMAP_LAYOUT_TAGS;
// 上位階層の設定に伴い選択リストを制御
if ($now_floor > $start_floor) {
	foreach ($SITEMAP_LAYOUT_TAGS as $key => $val) {
		// H2の下位階層はH3のみ
		if ($parent_key == SITEMAP_LAYOUT_H2) {
			if ($key == SITEMAP_LAYOUT_H3) {
				continue;
			}
		}
		// H3の下位階層はH4のみ
		elseif ($parent_key == SITEMAP_LAYOUT_H3) {
			if ($key == SITEMAP_LAYOUT_H4) {
				continue;
			}
		}
		// H4の下位階層はH5のみ
		elseif ($parent_key == SITEMAP_LAYOUT_H4) {
			if ($key == SITEMAP_LAYOUT_H5) {
				continue;
			}
		}
		// H5の下位階層はH6のみ
		elseif ($parent_key == SITEMAP_LAYOUT_H5) {
			if ($key == SITEMAP_LAYOUT_H6) {
				continue;
			}
		}
		// ULは削除できない
		if ($key == SITEMAP_LAYOUT_UL) {
			continue;
		}
		// 選択リストから削除
		unset($option[$key]);
	
	}
}

// 選択リストを作成
$html = mkcombobox($option, "cms_layout_tag_" . $now_floor, $now_value, "", "120px");
$html = preg_replace("/(<select[^>]+)>/i", "$1 onChange=\"cxSelectLayoutTag(" . $now_floor . ")\">", $html);

// 戻値
echo 'true,' . $html;
exit();
?>
