<?php
// 設定ファイル読み込み
require_once ("../../.htsetting");
require_once ("../../common.inc");

// エラーチェック
if (!isset($_POST['sitemap_id'])) {
	echo "false,";
	exit();
}
if (!isset($_POST['parent_id'])) {
	echo "false,";
	exit();
}
if (!isset($_POST['max_floor'])) {
	echo "false,";
	exit();
}
if (!isset($_POST['this_floor'])) {
	echo "false,";
	exit();
}

// 表示対象設定画面でチェックしたページからのサイトマップ範囲HTMLの生成
$ret = create_sitemap_target_page_check($_POST['sitemap_id'], $_POST['parent_id'], '', 0, $_POST['max_floor'], $_POST['this_floor']);

echo "true," . $ret;
exit();
?>
