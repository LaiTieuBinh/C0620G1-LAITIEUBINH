<?php
// 設定ファイル読み込み
require_once ("../../.htsetting");
require_once ("../../common.inc");

// 追加・削除するセッション名称が存在しない場合はエラー
if (!isset($_POST['sess_name'])) {
	echo "false";
	exit();
}
// セッション名
$sess_name = $_POST['sess_name'];
// セッション登録フラグ
// FLAG_ON  : 登録
// FLAG_OFF : 削除
$sess_mode = (isset($_POST['sess_mode']) ? $_POST['sess_mode'] : FLAG_OFF);

if ($sess_mode != FLAG_ON) {
	if (isset($_SESSION[$sess_name])) {
		unset($_SESSION[$sess_name]);
	}
}
else {
	$_SESSION[$sess_name] = FLAG_ON;
}

echo "true";
exit();
?>
