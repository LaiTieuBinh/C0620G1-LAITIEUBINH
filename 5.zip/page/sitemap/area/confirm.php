<?php
require ("../.htsetting");
require ("../common.inc");

// cnc
global $objCnc;
// tbl_sitemap
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap.inc');
$objSitemap = new tbl_sitemap($objCnc);

// 定数
$SITEMAP_FLOOR_ARY = getDefineArray("SITEMAP_FLOOR_ARY");
$SITEMAP_ADD_PAGE_ARY = getDefineArray("SITEMAP_ADD_PAGE_ARY");
$SITEMAP_AUTO_ADD_PAGE_ARY = getDefineArray("SITEMAP_AUTO_ADD_PAGE_ARY");
$SITEMAP_LANGUAGE_ARY = getDefineArray("SITEMAP_LANGUAGE_ARY");

// POST値取得
$post = $_POST;

// エラーチェック
sitemap_area_error_check($post);

// 処理モード
$mode = $post['cms_mode'];

switch ($mode) {
	// 削除登録の場合
	case SITEMAP_MODE_DEL :
		// サイトマップ情報を取得
		if ($objSitemap->selectFromID($post['cms_sitemap_id']) === FALSE) {
			sitemap_error("サイトマップエリア情報の取得に失敗しました。");
		}
		$post['cms_name'] = $objSitemap->fld['name'];
		$post['cms_floor'] = $objSitemap->fld['floor'];
		$post['cms_add_page'] = $objSitemap->fld['add_page'];
		$post['cms_auto_add_page'] = $objSitemap->fld['auto_add_page'];
		$post['cms_language'] = $objSitemap->fld['language'];
		$post['cms_sitemap_source'] = $objSitemap->fld['sitemap_source'];
		break;
	// 新規・更新登録の場合
	default :
		$post['cms_sitemap_source'] = '';
		break;
}

// サイトマップ配列
$sitemap_ary = array(
		// サイトマップID
		'sitemap_id' => trim($post['cms_sitemap_id']), 
		// サイトマップ名
		'name' => trim($post['cms_name']), 
		// 自動反映エリア
		'floor' => trim($post['cms_floor']), 
		// ページ追加設定
		'add_page' => trim($post['cms_add_page']), 
		// 自動ページ追加設定
		'auto_add_page' => trim($post['cms_auto_add_page']), 
		// 言語設定
		'language' => trim($post['cms_language']), 
		// サイトマップソースコード
		'sitemap_source' => trim($post['cms_sitemap_source'])
);

/* HTML出力情報 */

// タイトル
$title_html = 'サイトマップエリア設定';
$title_image = '<img src="../images/bar_area_form.jpg" alt="サイトマップエリア設定" width="920" height="30" />';

$name_input = htmlDisplay($sitemap_ary['name']);
$floor_input = htmlDisplay(@$SITEMAP_FLOOR_ARY[$sitemap_ary['floor']]);
$add_page_input = '<p style="margin-bottom:8px;">' . htmlDisplay(@$SITEMAP_ADD_PAGE_ARY[$sitemap_ary['add_page']]) . '</p>';
$add_page_input .= '<p style="margin:0px;">' . htmlDisplay(@$SITEMAP_AUTO_ADD_PAGE_ARY[$sitemap_ary['auto_add_page']]) . '</p>';
$language_input = htmlDisplay(@$SITEMAP_LANGUAGE_ARY[$sitemap_ary['language']]);

// フォーム内容
$input_html = array(
		// サイトマップ名
		'1' => array(
				'need' => ($mode == SITEMAP_MODE_DEL ? FLAG_OFF : FLAG_ON), 
				'label' => htmlDisplay(SITEMAP_AREA_STR_NAME), 
				'input' => $name_input
		), 
		// 自動反映エリア
		'2' => array(
				'need' => ($mode == SITEMAP_MODE_DEL ? FLAG_OFF : FLAG_ON), 
				'label' => htmlDisplay(SITEMAP_AREA_STR_FLOOR), 
				'input' => $floor_input
		), 
		// ページ追加設定
		'3' => array(
				'need' => ($mode == SITEMAP_MODE_DEL ? FLAG_OFF : FLAG_ON), 
				'label' => htmlDisplay(SITEMAP_AREA_STR_ADD_PAGE), 
				'input' => $add_page_input
		), 
		// 言語設定
		'4' => array(
				'need' => ($mode == SITEMAP_MODE_DEL ? FLAG_OFF : FLAG_ON), 
				'label' => htmlDisplay(SITEMAP_AREA_STR_LANGUAGE), 
				'input' => $language_input
		)
);

// 隠し項目
$input_hidden = '';
foreach ($sitemap_ary as $key => $val) {
	$input_hidden .= '<input type="hidden" name="cms_' . $key . '" id="cms_' . $key . '" value="' . htmlspecialchars($val) . '" />' . "\n";
}
$input_hidden .= '<input type="hidden" name="cms_mode" id="cms_mode" value="' . htmlspecialchars($mode) . '" />' . "\n";

// 表示タグ
$source_html = htmlDisplay(create_sitemap_source_str($sitemap_ary['sitemap_source']));

// ボタン
if ($mode == SITEMAP_MODE_UPD) {
	$button_next = '<a 	href="javascript:" 	onClick="return cxSubmit()"><img src="' . RPW . '/admin/images/btn/btn_fix.jpg" alt="修正" width="150" height="20" border="0" style="margin-right: 10px"></a>';
}
elseif ($mode == SITEMAP_MODE_DEL) {
	$button_next = '<a 	href="javascript:" 	onClick="return cxSubmit()"><img src="' . RPW . '/admin/images/btn/btn_del.jpg" alt="削除" width="150" height="20" border="0" style="margin-right: 10px"></a>';
}
else {
	$button_next = '<a 	href="javascript:" 	onClick="return cxSubmit()"><img src="' . RPW . '/admin/images/btn/btn_add.jpg" alt="追加" width="150" height="20" border="0" style="margin-right: 10px"></a>';
}
$button_back = '<a href="javascript:history.back();"><img src="' . RPW . '/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150" height="20" border="0" style="margin-left: 10px"></a>';

// ページ上部コメント
$comment_html = ($mode == SITEMAP_MODE_DEL ? '<p>この情報を削除してもよろしいですか？</p>' : "");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--//
/**
 * フォーム送信
 */
function cxSubmit() {
	// フォーム情報セット
	$('cms_sitemap_form').action = 'submit.php';
	$('cms_sitemap_form').method = 'post';
	// フォーム送信
	$('cms_sitemap_form').submit();
	return false;
}
//-->
</script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'sitemap';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-sitemap">
<div><?=$title_image?></div>
<div class="cms8341-area-corner">
<?=$comment_html?>
<form class="cms8341-form" id="cms_sitemap_form" name="cms_sitemap_form"
	method="post" action="submit.php" onSubmit="return false;">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
<?php
foreach ($input_html as $input) {
	?>
<tr>
		<th width="200"><?=$input['label']?><?=($input['need'] == FLAG_ON) ? '<span class="cms_require">（必須）</span>' : ''?></th>
		<td><?=$input['input']?></td>
	</tr>
<?php
}
?>
</table>
<p align="center">
<?=$button_next?><?=$button_back?>
</p>
<!--  隠し項目 -->
<p><?=$input_hidden?></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
</body>
</html>
