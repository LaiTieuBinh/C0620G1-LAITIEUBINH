<?php
require ("./.htsetting");
require ("./common.inc");

// DB
global $objCnc;
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap.inc');
$objSitemap = new tbl_sitemap($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap_handler.inc');
$objSitemapHandler = new tbl_sitemap_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

/* HTML出力情報 */

// タイトル
$title_html = 'サイトマップ一覧';
$title_image = '<img src="./images/bar_sitemap_index.jpg" alt="サイトマップ一覧" width="920" height="30" />';

// 空白画像
$space_img = '<img src="' . RPW . '/admin/images/spacer.gif" alt="" width="60" height="20" border="0">';

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--//
var SITEMAP_MODE_INS = '<?=javaStringEscape(SITEMAP_MODE_INS)?>';
var SITEMAP_MODE_UPD = '<?=javaStringEscape(SITEMAP_MODE_UPD)?>';
var SITEMAP_MODE_DEL = '<?=javaStringEscape(SITEMAP_MODE_DEL)?>';

/**
 * 修正
 */
function cxRevisionSitemap(sitemap_id ) {
	// フォーム項目指定
	$('cms_mode').value = SITEMAP_MODE_UPD;
	$('cms_sitemap_id').value = sitemap_id;
	// フォーム情報設定
	$('cms_sitemap_form').action = "./area/form.php";
	$('cms_sitemap_form').target = "_self";
	$('cms_sitemap_form').method = "post";
	// フォーム送信
	$('cms_sitemap_form').submit();
	return false;
}
/**
 * 削除
 */
function cxDeleteSitemap(sitemap_id ) {
	// フォーム項目指定
	$('cms_mode').value = SITEMAP_MODE_DEL;
	$('cms_sitemap_id').value = sitemap_id;
	// フォーム情報設定
	$('cms_sitemap_form').action = "./area/confirm.php";
	$('cms_sitemap_form').target = "_self";
	$('cms_sitemap_form').method = "post";
	$('cms_sitemap_form').submit();
	return false;
}
/**
 * 表示設定
 */
function cxTargetOrder(sitemap_id ) {
	// フォーム項目指定
	$('cms_mode').value = '';
	$('cms_sitemap_id').value = sitemap_id;
	// フォーム情報設定
	$('cms_sitemap_form').action = "./order/target.php";
	$('cms_sitemap_form').target = "_self";
	$('cms_sitemap_form').method = "post";
	$('cms_sitemap_form').submit();
	return false;
}
/**
 * プレビュー
 */
function cxSitemapPreview(sitemap_id ) {
	// フォーム項目指定
	$('cms_mode').value = '';
	$('cms_sitemap_id').value = sitemap_id;
	// フォーム情報設定
	$('cms_sitemap_form').action = "./sitemap_preview.php";
	$('cms_sitemap_form').target = "_blank";
	$('cms_sitemap_form').method = "post";
	$('cms_sitemap_form').submit();
	return false;
}

//-->
</script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'sitemap';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-sitemap">
<div><?=$title_image?></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
<?php
// サイトマップ一覧を取得
$objSitemap->select();
if ($objSitemap->getRowCount() > 0) {
	while ($objSitemap->fetch()) {
		$sfld = $objSitemap->fld;
		// サイトマップトップページを検索
		$where = $objPage->_addslashesC('page_id', $sfld['sitemap_top_id'], '=', 'INT');
		$where .= " AND " . create_common_public_sql();
		// ページ出力設定されているページのみ
		if (ENABLE_OPTION_OUTPUT) {
			$where .= " AND " . $objPage->_addslashesC('output_html_flg', FLAG_ON);
		}
		$objPage->select($where);
		// サイトマッププレビューを表示するかのフラグ
		if ($objPage->getRowCount() > 0) {
			$preview = '<a href="javascript:" onClick="cxSitemapPreview(' . $sfld['sitemap_id'] . ');">' . htmlDisplay($sfld['name']) . '</a>';
		}
		else {
			$preview = htmlDisplay($sfld['name']);
		}
		?>
<tr>
		<td>
		<table width="100%" border="0" cellpadding="5" cellspacing="0"
			style="border: none;">
			<tr>
				<td width="50%" align="left" valign="middle" style="border: none"><strong><?=$preview?></strong></td>
				<td width="50%" align="right" valign="middle" style="border: none">
				<a href="javascript:"
					onClick="return cxTargetOrder(<?=$sfld['sitemap_id']?> );"><img
					src="./images/btn_disp_set.jpg" alt="表示設定" width="120" height="20"
					hspace="0" border="0" /></a> <a href="javascript:"
					onClick="return cxRevisionSitemap(<?=$sfld['sitemap_id']?> );"><img
					src="./images/btn_mini_fix.jpg" alt="修正" width="60" height="20"
					hspace="10" border="0" /></a>
<?php
		if (check_use_sitemap_page($sfld['sitemap_id'], $sfld['sitemap_source'])) {
			echo $space_img;
		}
		else {
			?>
<a href="javascript:"
					onClick="return cxDeleteSitemap(<?=$sfld['sitemap_id']?> );"><img
					src="./images/btn_mini_del.jpg" alt="削除" width="60" height="20"
					border="0" /></a>
<?php
		}
		?>
</td>
			</tr>
		</table>
		<table class="cms8341-dataTable" width="100%">
			<tr>
				<td style="background-color: #F0F0F0; width: 180px;"><?=htmlDisplay(SITEMAP_AREA_STR_FLOOR)?></td>
				<td style="width: 200px;"><?=@$SITEMAP_FLOOR_ARY[$sfld['floor']]?></td>
				<td style="background-color: #F0F0F0; width: 180px;"><?=htmlDisplay(SITEMAP_AREA_STR_ADD_PAGE)?></td>
				<td style="width: 200px;"><?=@$SITEMAP_ADD_PAGE_ARY[$sfld['add_page']]?></td>
			</tr>
			<tr>
				<td style="background-color: #F0F0F0; width: 180px;"><?=htmlDisplay(SITEMAP_AREA_STR_SOURCE)?></td>
				<td colspan="3"><?=htmlDisplay(create_sitemap_source_str($sfld['sitemap_source']))?></td>
			</tr>
		</table>
		</td>
	</tr>
<?php
	}
}
else {
	print '<tr><td align="center" valign="top">現在、サイトマップは登録されていません。</td></tr>';
}
?>
</table>
<form class="cms8341-form" id="cms_sitemap_form" name="cms_sitemap_form"
	method="post" action="#" onSubmit="return false;">
<p><input type="hidden" name="cms_mode" id="cms_mode" value="" /> <input
	type="hidden" name="cms_sitemap_id" id="cms_sitemap_id" value="" /></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
</body>
</html>
