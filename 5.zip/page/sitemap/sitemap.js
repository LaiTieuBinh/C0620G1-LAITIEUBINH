// サイトマップ管理画面共通Javascript

/**
 * PHPの$_SESSIONに指定した名前の$_SESSIONを追加
 * 
 * @param  sess_name 追加するセッション名
 * @param  sess_mode FLAG_ONで追加、FLAG_OFFで削除
 * @return true（正常）｜false（エラー）
 */
function cxSetSitemapSession(sess_name, sess_mode) {
	// セッション名の指定が無効な場合
	if (sess_name == undefined || !sess_name) {
		// 処理中断
		return false;
	}
	// モードの指定が無効な場合
	if (sess_mode == undefined || sess_mode != FLAG_ON) {
		// モードをセッション削除に強制
		sess_mode = FLAG_OFF;
	}

	// Ajaxパラメーター
	var params = 'sess_name=' + sess_name;
	params += '&sess_mode=' + sess_mode;

	// AjaxでPHPに接続
	// 同期通信
	var r = new Ajax.Request(
			cms8341admin_path + '/page/sitemap/order/request/session.php', {
				method : 'post',
				asynchronous : false,
				parameters : params
			});
	// true以外の戻値はエラー
	if (r.transport.responseText != "true") {
		return false;
	}
	// 正常終了
	return true;
}
