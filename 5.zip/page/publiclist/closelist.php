<?php
/*
 * 公開リスト
 */
require ("../.htsetting");

$login = $objLogin->login;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
$objTool2 = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
require ("./include/publiclistFunc.inc");
$objPubliclist = new publiclistFunc($objCnc);
if ($login['class'] == USER_CLASS_WEBMASTER) {
	$set_target = '';
}
else if ($login['class'] == USER_CLASS_WRITER) {
	$set_target = $login['user_id'];
}
else {
	$set_target = $login['dept_code'];
}

//===========================================================
//	非公開リスト処理
//===========================================================
// 検索条件
$search = array(
	// ページID検索
	'page_id' => '',
	'page_title' => '', 
	'search_keywords' => '', 
	'is_tag_search' => FLAG_OFF, 
	'url' => '', 
	'publish_start' => '', 
	'publish_end' => '', 
	'pdsy' => '', 
	'pdsm' => '', 
	'pdsd' => '', 
	'pdey' => '', 
	'pdem' => '', 
	'pded' => '', 
	'target' => $set_target, 
	'target1' => '', 
	'target2' => '', 
	'target3' => '', 
	'expired' => '', 
	'cate_code' => array(
		'cms_cate1' => '', 
		'cms_cate2' => '', 
		'cms_cate3' => '', 
		'cms_cate4' => ''
	), 
	'p' => 1, 
	'template_kind' => '', 
	'template_id' => '', 
	'disp_order_item' => 'publish_start', 
	'disp_order' => 1, 
	'disp_num' => "10"
);
$disp_mode = "";
$template_name = "";
$template_id = "";
$disp_last_condition = "";

//編集画面から戻ってきた場合はSESSIONから値を取得
if (isset($_GET['ref']) && isset($_SESSION['close_search']) && $_GET['ref'] == 'edit') {
	$search = $_SESSION['close_search'];
}

//同一ページ以外から来た場合、SESSIONを削除する
if (!isset($_SERVER['HTTP_REFERER']) || preg_replace('/\?.*$/i', '', $_SERVER['HTTP_REFERER']) != HTTP_ROOT . $_SERVER['PHP_SELF']) {
	unset($_SESSION['close_search']);
}

if (isset($_GET['ini']) && $_GET['ini'] == 1) {
	if (isset($_SESSION['close_search'])) unset($_SESSION['close_search']);
}
elseif (isset($_SESSION['close_search'])) {
	$search = $_SESSION['close_search'];
}
if (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'search') {
	$disp_mode = $_POST['cms_dispMode'];
	$search = array();
	// ページID検索
	if (!empty($_POST['cms_search_page_id'])) {
		$search['page_id'] = explode(' ', preg_replace('/\s+/', ' ', $_POST['cms_search_page_id']));
	}	
	$search['page_title'] = str_replace('　', ' ', $_POST['cms_search_page_title']);
	$search['page_title'] = trim($search['page_title']);
	$search['search_keywords'] = str_replace('　', ' ', $_POST['cms_search_keywords']);
	$search['search_keywords'] = trim($search['search_keywords']);
	$search['is_tag_search'] = $_POST['cms_is_tag_search'];
	$search['url'] = $_POST['cms_url'];
	$search['pdsy'] = $_POST['cms_pdsy'];
	$search['pdsm'] = $_POST['cms_pdsm'];
	$search['pdsd'] = $_POST['cms_pdsd'];
	$search['pdey'] = $_POST['cms_pdey'];
	$search['pdem'] = $_POST['cms_pdem'];
	$search['pded'] = $_POST['cms_pded'];
	if (($search['pdsy'] != '') && ($search['pdsm'] != '') && ($search['pdsd'] != '')) $search['publish_start'] = $search['pdsy'] . '-' . $search['pdsm'] . '-' . $search['pdsd'];
	if (($search['pdey'] != '') && ($search['pdem'] != '') && ($search['pded'] != '')) $search['publish_end'] = $search['pdey'] . '-' . $search['pdem'] . '-' . $search['pded'] . ' 23:59:59';
	//**2006/09/28
	//$search['class'] = $_POST['cms_class'];
	$search['target1'] = (isset($_POST['cms_target_1']) ? $_POST['cms_target_1'] : "");
	$search['target2'] = (isset($_POST['cms_target_2']) ? $_POST['cms_target_2'] : "");
	$search['target3'] = (isset($_POST['cms_target_3']) ? $_POST['cms_target_3'] : "");
	//**2006/09/28
	$search['expired'] = (isset($_POST['cms_expired'])) ? $_POST['cms_expired'] : '';
	// -- カテゴリ
	$search['cate_code']["cms_cate1"] = (isset($_POST['cms_cate1'])) ? $_POST['cms_cate1'] : "";
	$search['cate_code']["cms_cate2"] = (isset($_POST['cms_cate2'])) ? $_POST['cms_cate2'] : "";
	$search['cate_code']["cms_cate3"] = (isset($_POST['cms_cate3'])) ? $_POST['cms_cate3'] : "";
	$search['cate_code']["cms_cate4"] = (isset($_POST['cms_cate4'])) ? $_POST['cms_cate4'] : "";
	$search['p'] = 1;
	//テンプレート
	$search['template_kind'] = (isset($_POST['cms_template_kind']) ? $_POST['cms_template_kind'] : "");
	$search['template_id'] = (isset($_POST['cms_template_ids']) ? $_POST['cms_template_ids'] : "");
	// 自分／所属作成ページ
	$search['target'] = (isset($_POST["cms_target1"]) ? $_POST["cms_target1"] : "");
	//表示順
	$search['disp_order_item'] = (isset($_POST['cms_disp_order_item']) ? $_POST['cms_disp_order_item'] : "");
	//ソート
	$search['disp_order'] = (isset($_POST['cms_disp_order']) ? $_POST['cms_disp_order'] : "");
	
	//表示リミット
	$search['disp_num'] = (isset($_POST['disp_num']) ? $_POST['disp_num'] : 10);
	
	$_SESSION['close_search'] = $search;
	$_SESSION['last_search_condition']['closelist'] = $search;
	//
}
elseif (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'pageset') {
	$search['p'] = $_POST['cms_p'];
	$_SESSION['close_search'] = $search;
	//
}
elseif (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'change_num') {
	$objPubliclist->margePost($_POST, $search);
	$search['p'] = 1;
	$_SESSION['close_search'] = $search;
}
elseif (isset($_GET['ref']) && $_GET['ref'] == 'edit') {
	$_SESSION['close_search'] = $search;
	$disp_mode = 'search';
}
else if (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'last_condition') {
	$search = $_SESSION['last_search_condition']['closelist'];
	$_SESSION['close_search'] = $search;
	$disp_mode = 'search';
}
//前回の検索ボタン
if (isset($_SESSION['last_search_condition']['closelist'])) {
	$disp_last_condition = '<span style="margin:15px;" class="cms8341-verticalMiddle"><a href="javascript:" onclick="return cxLastSearch()"><img src="' . RPW . '/admin/images/btn/btn_search_condition.jpg" alt="前回の条件で検索" width="150" height="20" border="0"></a></span>' . "\n";
}
//


//対象項目生成
// ページID検索
$search_page_id = (!empty($search['page_id'])) ? implode(' ', $search['page_id']) : '';
$dept_code = array();
$disabled = array();
$dept_code['cms_target_1'] = (isset($search['target1']) ? $search['target1'] : "");
$dept_code['cms_target_2'] = (isset($search['target2']) ? $search['target2'] : "");
$dept_code['cms_target_3'] = (isset($search['target3']) ? $search['target3'] : "");
// 公開責任者
if ($login['class'] == USER_CLASS_WEBMASTER && $login['isOpenUser']) {
	$cms_target_radio = '';
}
// 作成者・ウェブマスター
elseif ($login['class'] == USER_CLASS_WRITER || $login['class'] == USER_CLASS_WEBMASTER) {
	if ($search["target"] != '') {
		$t1 = " checked";
		$t2 = "";
	}
	else {
		$t1 = "";
		$t2 = " checked";
	}
	$cms_target_radio = '<p><input type="radio" id="cms_target1" name="cms_target1" value="' . $login['user_id'] . '"' . $t1 . ' onclick="javascript:cxInitialize();">' . '&nbsp;' . '<label for="cms_target1">自分が作成したページ</label>　' . '<input type="radio" id="cms_target2" name="cms_target1" value=""' . $t2 . ' onclick="javascript:cxInitialize();">' . '&nbsp;' . '<label for="cms_target2">全てのページ</label></p>';
}
// 承認者
else {
	if ($search["target"] != '') {
		$t1 = " checked";
		$t2 = "";
	}
	else {
		$t1 = "";
		$t2 = " checked";
	}
	$cms_target_radio = '<p><input type="radio" id="cms_target1" name="cms_target1" value="' . $login['dept_code'] . '"' . $t1 . ' onclick="javascript:cxInitialize();">' . '&nbsp;' . '<label for="cms_target1">所属で作成したページ</label>　' . '<input type="radio" id="cms_target2" name="cms_target1" value=""' . $t2 . ' onclick="javascript:cxInitialize();">' . '&nbsp;' . '<label for="cms_target2">全てのページ</label></p>';
}
$cms_target = $cms_target_radio . create_department_list("cms_target_", $dept_code, "120");

//有効期限
$var = array(
	0 => "指定なし", 
	1 => "一ヶ月前", 
	2 => "一週間前", 
	3 => "期限切れ"
);
$name = "cms_expired";
$cms_expired = mkradiobutton($var, $name, $search["expired"], 4);

$cms_category = create_category_list("cms_cate", $search['cate_code'], '120');

$TEMPLATE_KIND = getDefineArray("TEMPLATE_KIND");
$cms_template_kind = mkcheckbox($TEMPLATE_KIND, "cms_template_kind", $search["template_kind"], 0);
// テンプレート（最新バージョン）情報を取得
// ウェブマスターの場合は全テンプレート
if (isset($search['template_id'])) {
	$template_id = $search['template_id'];
}
//全テンプレート取得
$sql = "SELECT t.* FROM tbl_template AS t" . " WHERE t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND t.disp_flg = '" . FLAG_ON . "'" . " AND " . $objTool2->_addslashesC("t.template_kind", TEMPLATE_KIND_NONE, "<>") . " ORDER BY t.sort_order,t.template_id";
// 作成者の場合は所属に権限があるテンプレート
$objTool2->execute($sql);
$publish_all_temp_list = array();
$template_ary = array();
while ($objTool2->fetch()) {
	$publish_all_temp_list[] = $objTool2->fld;
	
	$template_ary = explode(",", $template_id);
	$temp_ary = array(
		""
	);
	$template_ary = array_diff($template_ary, $temp_ary);
	
	if (in_array($objTool2->fld['template_id'], $template_ary)) {
		$template_name = $template_name . '<span id="template_id_' . $objTool2->fld['template_id'] . '">' . '&nbsp;<a href="javascript:" onClick="return cxTemplateUnSet(template_id_' . $objTool2->fld['template_id'] . ',\'' . $objTool2->fld['template_id'] . '\')">' . '<img src="' . RPW . '/admin/images/icon/result_error.gif" alt="削除" width="12" height="12" border="0">' . '</a>' . htmlDisplay($objTool2->fld['name']) . '</span>';
	}
}
// ウェブマスターは全テンプレート
if ($login['class'] == USER_CLASS_WEBMASTER) {
	$publish_temp_list = $publish_all_temp_list;
}
else {
	//権限があるテンプレート
	$sql = "SELECT t.* FROM tbl_template AS t" . " LEFT JOIN tbl_handler AS h ON (h.item2 = t.template_id)" . " WHERE h.class = " . HANDLER_CLASS_TEMPLATE . " AND h.item1 = '" . $objLogin->get('dept_code') . "'" . " AND t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND " . $objTool2->_addslashesC("t.template_kind", TEMPLATE_KIND_NONE, "<>") . " AND t.disp_flg = '" . FLAG_ON . "'" . " ORDER BY t.sort_order,t.template_id";
	$objTool2->execute($sql);
	$publish_temp_list = array();
	while ($objTool2->fetch()) {
		$publish_temp_list[] = $objTool2->fld;
	}
}

$DISP_ORDER_ITEM = getDefineArray("DISP_ORDER_ITEM");
$disp_order_ary = array(
	"0" => "昇順", 
	"1" => "降順"
);

// タグ内検索
$var = array(
	FLAG_OFF => "HTMLのタグを対象としない", 
	FLAG_ON => "HTMLのタグを対象とする"
);
$name = "cms_is_tag_search";
$cms_is_tag_search = mkradiobutton($var, $name, $search["is_tag_search"], 2);

//表示順項目
$order_item = '<select id="cms_disp_order_item" name="cms_disp_order_item">' . "\n";
foreach ((array) $DISP_ORDER_ITEM as $name => $column) {
	$selected = ($column == $search['disp_order_item']) ? ' selected' : '';
	$order_item .= '<option value="' . $column . '"' . $selected . '>' . htmlDisplay($name) . '</option>' . "\n";
}
$order_item .= '</select>&nbsp;&nbsp;';

//ソート
$disp_order_str = mkradiobutton($disp_order_ary, "cms_disp_order", $search['disp_order'], 2);

// 非公開情報の取得
$objPage->selectClose($search);

// 公開リスト/非公開リスト 初期表示切替設定
$list_mode = 'block';

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>公開・非公開リスト</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/publiclist.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/publiclist.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
Event.observe(window,'load',function(){
//処理
	if (!$('cms_template_id_name')) return false;
	
	if ($('cms_target2') && $('cms_target2').checked) {
		$('cms_template_id_name').value = "cms_target2";
	} else {
		$('cms_template_id_name').value = "cms_target1";
	}
	cxDeptCombChange();
});
//var id_name = "cms_target1";
function cxInitialize() {
	if (!$('cms_template_id_name')) return false;
	
	if ($('cms_target1') && $('cms_target1').checked) {
		if ($('cms_template_id_name').value != "cms_target1") {
			if ($('cms_template_id')) {
				$('cms_template_id').options.selectedIndex = -1;
			}
			if ($('cms_all_template_id')) {
				$('cms_all_template_id').options.selectedIndex = -1;
			}
			if ($('cms_template_ids')) {
				$('cms_template_ids').value = "";
			}
			if ($('cms-template-selected')) {
				$('cms-template-selected').innerHTML = "";
			}
		}
		$('cms_template_id_name').value = "cms_target1";
	} else {
		$('cms_template_id_name').value = "cms_target2";
	}
	cxDeptCombChange();
}
function cxDeptCombChange(){
	var disabled = ($('cms_target1') && $('cms_target1').checked) ? true : false;
	if($('cms_target_1')) $('cms_target_1').disabled = disabled;
	if($('cms_target_2')) $('cms_target_2').disabled = disabled;
	if($('cms_target_3')) $('cms_target_3').disabled = disabled;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'publiclist';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
$headerMode = 'closelist';
?>
<form name="cms_fPubList" id="cms_fPubList" class="cms8341-form"
	method="post" action=""><input type="hidden" name="cms_preview_color"
	id="cms_preview_color" value="" disabled> <input type="hidden" name="cms_dispMode"
	id="cms_dispMode" value=""> <input type="hidden" name="cms_page_id"
	id="cms_page_id" value=""></form>
<div align="center" id="cms8341-contents">
<div align="center" id="cms8341-publiclist">
<div
	style="width: 920px; text-align: left; background: url(images/tab_bg.jpg) bottom repeat-x;">
<table border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="220"><a
			href="<?=RPW?>/admin/page/publiclist/publiclist.php"><img
			src="images/tab_publiclist.jpg" alt="公開ページリスト" width="220"
			height="25" border="0"></a></td>
		<td width="4"><img src="images/tab_bg.jpg" alt="" width="4"
			height="25"></td>
		<td width="220"><a href="<?=RPW?>/admin/page/publiclist/closelist.php"><img
			src="images/tab_closelist.jpg" alt="非公開ページリスト" width="220"
			height="25" border="0"></a></td>
<?php
if (isDisasterEditFlgLoginUser($login)) {
	?>
		<td width="4"><img src="images/tab_bg.jpg" alt="" width="4"
			height="25"></td>
		<td width="220"><a
			href="<?=RPW?>/admin/page/publiclist/disasterlist.php"><img
			src="images/tab_disasterlist.jpg" alt="大規模災害ページリスト" width="220"
			height="25" border="0"></a></td>
<?php
}
?>
	</tr>
</table>
</div>
<!-- 非公開リスト -->
<div style="display:<?=$list_mode?>" id="cms8341_closelistarea">
<form name="cms_fSearch" id="cms_fSearch" class="cms8341-form"
	method="post" action="closelist.php"><input type="hidden"
	name="cms_dispMode" value=""> <input type="hidden" name="cms_p"
	value=""> <input type="hidden" name="cms_template_ids"
	id="cms_template_ids" value="<?=$template_id?>"> <input type="hidden"
	name="cms_template_id_name" id="cms_template_id_name" value="">
<div
	style="width: 918px; border: solid 1px #CCCCCC; border-top: none; background-color: #C6C4FD;"><img
	src="<?=RPW?>/admin/images/spacer.gif" width="1" height="8" alt=""></div>
<div class="cms8341-area-corner">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle"
			style="background-image: url(images/bar_topbg.jpg); height: 31px;"><img
			src="images/bar_search.jpg" alt="検索" width="200" height="20"
			style="margin-left: 10px;"></td>
	</tr>
</table>
<div id="cms8341-search" style="display:<?=(($disp_mode != "search") ? "none" : "block")?>">
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<td>
		<table width="100%" border="0" cellpadding="10" cellspacing="0"
			bgcolor="#F0F0F0">
			<!-- ページID検索 -->
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページID</th>
				<td align="left" valign="middle"><input type="text"
					id="cms_search_page_id" name="cms_search_page_id"
					value="<?=htmlspecialchars($search_page_id)?>"
					style="width: 250px; ime-mode: disabled;">
					<br><small>※複数指定する場合はスペース区切りで指定してください。</small></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページタイトル</th>
				<td align="left" valign="middle"><input type="text"
					id="cms_search_page_title" name="cms_search_page_title"
					value="<?=htmlspecialchars($search['page_title'])?>"
					style="width: 500px;"></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">キーワード</th>
				<td align="left" valign="middle"><?=$cms_is_tag_search?><input
					type="text" id="cms_search_keywords" name="cms_search_keywords"
					value="<?=htmlspecialchars($search['search_keywords'])?>"
					style="width: 500px;"> <small>※大文字と小文字は区別されません。</small></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">URL</th>
				<td align="left" valign="middle" nowrap><input type="text"
					id="cms_url" name="cms_url"
					value="<?=htmlspecialchars($search['url'])?>" style="width: 500px;"><br>
				<small>※<?=HTTP_REAL_ROOT?>/以下のパスを入力してください。部分一致します。</small></td>
			</tr>
			<tr>
				<th width="170" align="left" valign="top" scope="row">テンプレート種類</th>
				<td align="left" valign="top"><?=$cms_template_kind?></td>
			</tr>
			<tr>
				<th width="170" align="left" valign="top" scope="row">テンプレート</th>
				<td align="left" valign="top"><a href="javascript:"
					onClick="return cxTemplateSet()"><img
					src="<?=RPW?>/admin/images/btn/btn_add_mini.jpg" alt="追加"
					width="102" height="21" border="0"></a> <span
					id="cms-template-selected" class="cms8341-templatearea"><?=$template_name?></span>
				</td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">公開開始日</th>
				<td align="left" valign="middle"><input type="text" maxlength="4"
					id="cms_pdsy" name="cms_pdsy"
					value="<?=htmlspecialchars($search['pdsy'])?>"
					style="width: 50px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="cms_pdsm" name="cms_pdsm"
					value="<?=htmlspecialchars($search['pdsm'])?>"
					style="width: 30px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="cms_pdsd" name="cms_pdsd"
					value="<?=htmlspecialchars($search['pdsd'])?>"
					style="width: 30px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxPublicCalendarOpen('cms_pd','start')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a> から <input
					type="text" maxlength="4" id="cms_pdey" name="cms_pdey"
					value="<?=htmlspecialchars($search['pdey'])?>"
					style="width: 50px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="cms_pdem" name="cms_pdem"
					value="<?=htmlspecialchars($search['pdem'])?>"
					style="width: 30px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="cms_pded" name="cms_pded"
					value="<?=htmlspecialchars($search['pded'])?>"
					style="width: 30px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxPublicCalendarOpen('cms_pd','end')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">分類</th>
				<td align="left" valign="middle"><?=$cms_category?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">対象</th>
				<td align="left" valign="middle"><?=$cms_target?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">有効期限</th>
				<td align="left" valign="middle"><?=$cms_expired?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">表示順</th>
				<td align="left" valign="middle"><?=$order_item?><?=$disp_order_str?></td>
			</tr>
		</table>
		</td>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="121" align="center" valign="middle"><a href="javascript:"
			onClick="return cxSearch()"><img
			src="<?=RPW?>/admin/images/btn/btn_search.jpg" alt="検索する" width="101"
			height="21" border="0"></a></td>
	</tr>
</table>
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right" valign="middle"
			style="background-image: url(images/bar_bottombg.jpg); height: 32px;">
		<?php
		if ($disp_mode != "search") {
			?>
		<a href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			src="<?=RPW?>/admin/images/btn/btn_open_mini.jpg" alt="開く" width="80"
			height="15" border="0" style="margin-right: 10px;"
			id="cms-searchSwitch"></a>
		<?php
		}
		else {
			?>
		<a href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			src="<?=RPW?>/admin/images/btn/btn_close_mini.jpg" alt="閉じる"
			width="80" height="15" border="0" style="margin-right: 10px;"
			id="cms-searchSwitch"></a>
		<?php
		}
		?>
		</td>
	</tr>
</table>
</div>
<?php
if ($objPage->getRowCount() == 0) {
	?>
<?php

	if ($disp_last_condition != "") {
		?>
<div style="margin-bottom: 10px; padding: 1px" align="right"><?=$disp_last_condition?></div>
<?php
	}
	?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-workspace">
	<tr>
		<th align="center" valign="middle" scope="col"
			style="font-weight: normal">&nbsp;</th>
	</tr>
	<tr>
		<td align="center" valign="middle">該当するページはありません。</td>
	</tr>
</table>
<?php
}
else {
	?>
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	style="margin-bottom: 10px; padding: 1px">
	<tr valign="top">
		<td colspan="3" align="right">
			<?=$disp_last_condition?>
			<?=mkcombobox($MAXROW_LIST, "disp_num", $search['disp_num'], "cxDispNum(this.value)")?>
		</td>
	</tr>
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objPage->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objPage->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objPage->getNextLink()?></td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-workspace">
	<tr>
		<th align="center" valign="middle" scope="col"
			style="font-weight: normal">タイトル</th>
		<!--<th align="center" valign="middle" scope="col" style="font-weight:normal">チェックツール</th>-->
	</tr>
<?php
	$menu_no = 0;
	while ($objPage->fetch()) {
		$menu_no++;
		$fld = $objPage->fld;
		
		$pubdate = '公開期間：' . dtFormat($fld['publish_start'], 'Y年m月d日H時') . 'から' . get_publish_end_date($fld['publish_end']) . 'まで';
		
		$disp_page_id = '（' . $fld['page_id'] . '）';
		?>
<tr>
		<td align="left" valign="top">
		<p><strong><a href="javascript:"
			onClick="return cxContentsMenu2(event, 'cms_menu_<?=$menu_no?>','<?=$fld['page_id']?>','cms_fPubList','<?=$headerMode?>')"
			onContextMenu="cxContentsMenu2(event, 'cms_menu_<?=$menu_no?>','<?=$fld['page_id']?>','cms_fPubList','<?=$headerMode?>');return false;"><?=htmlDisplay($fld['page_title'])?></a></strong><?=htmlDisplay($disp_page_id)?></p>
		<p><small><?=$pubdate?></small></p>
		<div id="cms_menu_<?=$menu_no?>" class="cms8341-layer"></div>
		</td>
<?php
	}
	?>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="5"
	style="margin-top: 10px;">
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objPage->getBackLink("cxPageSet")?></td>
		<td width="40%" align="center" valign="middle"><?=$objPage->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objPage->getNextLink("cxPageSet")?></td>
	</tr>
</table>
<?php
}
?>
</div>
<!-- ** テンプレート設定レイヤー　ここから ************************************* -->
<div id="cms8341-template-select" class="cms8341-layer">
<table width="800" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="800" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="800" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/template_select/title_template_select.jpg"
					alt="テンプレートの選択" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxTemplateClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 760px; height: 385px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<table width="740" border="0" cellpadding="0" cellspacing="0"
			class="cms8341-noneBorder">
			<tr>
				<td align="left" valign="top">
				<div id="cms_template_list">テンプレートリスト <select name="cms_template_id"
					id="cms_template_id" size="12" style="width: 250px;"
					onChange="cxSelectTemplate()">
<?php
// テンプレート選択フォームの生成＋表示
$def_src = "javascript:''";
foreach ((array) $publish_temp_list as $template_info) {
	$src = DIR_PATH_TEMPLATE . $template_info['temp_txt'];
	print '<option value="' . $template_info['template_id'] . '" id="' . $src . '" _kind="' . $template_info['template_kind'] . '" _kanko_type="' . $template_info['kanko_type'] . '">' . htmlDisplay($template_info['name']) . '</option>' . "\n";
}
?>
</select> <select name="cms_all_template_id" id="cms_all_template_id"
					size="12" style="width: 250px;" onChange="cxSelectTemplate()">
<?php
// テンプレート選択フォームの生成＋表示
$def_src = "javascript:''";
foreach ((array) $publish_all_temp_list as $template_info) {
	$src = DIR_PATH_TEMPLATE . $template_info['temp_txt'];
	print '<option value="' . $template_info['template_id'] . '" id="' . $src . '" _kind="' . $template_info['template_kind'] . '" _kanko_type="' . $template_info['kanko_type'] . '">' . htmlDisplay($template_info['name']) . '</option>' . "\n";
}
?>
</select></div>
				</td>
				<td width="475" align="left" valign="middle">
				<div id="cms_thumb_cover" style="position: absolute; width: 475px; height: 365px; filter: Alpha(opacity = 0)"></div>
				<iframe src="<?=$def_src?>" name="cms_thumb" id="cms_thumb"
					width="470" height="360" frameborder="0" scrolling="no"
					style="border: solid 1px #666"></iframe></td>
			</tr>
		</table>
		</div>
		</div>
		<p style="margin: 10px 0px;"><a href="javascript:"
			onClick="return cxTemplateSubmit()"><img
			src="<?=RPW?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
			height="21" border="0"></a></p>
		</td>
	</tr>
</table>
</div>
<!-- ** テンプレート設定レイヤー　ここまで ************************************* --></form>
</div>
<!-- 非公開リスト -->
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>

<!--***ページプロパティレイヤー ここから********************************-->
<div id="cms8341-property" class="cms8341-layer">
<table width="600" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="600" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="600" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/pageproperty/title_pageproperty.jpg"
					alt="ページプロパティ" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxPagePropertyClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 560px; height: 470px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center" id="cms8341-propertybody"><!-- ****** ページプロパティ表示領域 ここから ********* -->
		ここに各ページのページプロパティが代入されます。 <!-- ****** ページプロパティ表示領域 ここまで ********* --></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***ページプロパティレイヤー ここまで********************************-->
<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCalendarClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px">
		<div id="cms8341-calbody"
			style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
<!--***エラーメッセージレイヤー ここから********************************-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxCloseError()"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー ここまで********************************-->
<div style="margin-bottom: 10px">&nbsp;</div>
</body>
</html>
