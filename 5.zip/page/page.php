<?php
/*
 *
 */
/** require **/
require ("./.htsetting");
$login = $objLogin->login;

// 作業中ページ有りワークスペースへ
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage->selectWorkspace($login['user_id']);
if ($objPage->getRowCount() > 0) {
	if ($login['class'] == USER_CLASS_WEBMASTER) header("Location: " . HTTP_ROOT . RPW . "/admin/page/workspace/workspace_wm.php");
	else if ($login['isRegain'] == TRUE) header("Location: " . HTTP_ROOT . RPW . "/admin/page/workflow/workflow.php");
	else header("Location: " . HTTP_ROOT . RPW . "/admin/page/workspace/workspace.php");
	exit();
}

// 承認依頼コンテンツ有り⇒ワークフローへ
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_contents_group.inc');
$objCGrp = new tbl_contents_group($objCnc);
$objCGrp->selectApproveRequest($login);
if ($objCGrp->getRowCount() > 0) {
	header("Location: " . HTTP_ROOT . RPW . "/admin/page/workflow/workflow.php");
	exit();
}

// サイトビューへ
header("Location: " . HTTP_ROOT . RPW . "/admin/page/siteview/siteview.php");
exit();
?>