/*
 *
 */
function check(ctrl_name) {
	//init
	var p = new Object();
	p.maxRows = 6;			//最大行数
	p.rowCols = 36;			//1行あたりの最大文字数
	p.maxCols = 216;		//最大文字数
	//
	obj = document.getElementById('editor');
	//
	var res = getResult(obj,p);
	//
	var status;
	//resObj = document.getElementById('result');
	if(res.rowCount>p.maxRows || res.colCount>p.maxCols) {
		//resObj.innerHTML = '結果：NG';
		status = false;
	} else {
		//resObj.innerHTML = '結果：OK';
		status = true;
	}
	//resObj.innerHTML += '　行数：' + res.rowCount + "　文字数：" + res.colCount;

	//* XHTML化対応
	var li = $('editor').getElementsByTagName('LI');
	for(var i=0;i<li.length;i++) {
		if(!li[i].outerHTML.match(/<\/LI>$/gi)) {
			li[i].outerHTML = li[i].outerHTML + '</LI>';
		}
	}
	var xhtml = $('editor').innerHTML;
	//タグ、属性を全て小文字に変換
	xhtml = xhtml.replace(/<[^>]*>/gi,function($0){ return $0.toLowerCase(); });
	//属性値対応（"で囲む）
	xhtml = xhtml.replace(/=([^"])([^"\s>]*)/gi,'="$1$2"');
	//空要素対応
	xhtml = xhtml.replace(/<(BASE|META|LINK|HR|BR|PARAM|IMG|AREA|INPUT)([^>]*)>/gi,'<$1$2/>');
	
	$(ctrl_name).value = xhtml;
	
	return status;
}
//
function getResult(obj,par) {
	//
	var res = new Object();
	//行数の取得
	//**エディタ内のブロック要素はP,LIのみと仮定
	var pObj,liObj;
	var r_cnt = 0;
	pObj = obj.getElementsByTagName('p');
	liObj = obj.getElementsByTagName('li');
	for(var i=0;i<pObj.length;i++) {
		r_cnt = r_cnt + this.getRowCount(pObj[i],par.rowCols);
	}
	for(var i=0;i<liObj.length;i++) {
		r_cnt = r_cnt + this.getRowCount(liObj[i],par.rowCols);
	}
	res.rowCount = r_cnt;
	
	//文字数の取得（リストのインデント分を考慮しない絶対値）
	res.colCount = getColCount(obj);
	
	return res;
}
//
function getRowCount(obj,par) {
	var cnt = 0;
	var tag = obj.tagName;
	par = (tag=='P')? par : par - 1;	//リストは1文字分インデントがある
	var txt = obj.innerText;
	var row = txt.split('\n');
	//1行あたりのオーバーフローによる行数加算分の取得
	for(var i=0;i<row.length;i++) {	
		var col = row[i].length;
		if(col>par) {
			cnt = cnt + Math.floor((col-1)/par);
		}
	}
	//改行コードにおける行数を加算
	cnt = cnt + row.length - 1;	
	//1ブロック=1行として行数を加算
	cnt++;
	return cnt;
}
//
function getColCount(obj) {
	var val = obj.innerText;
	txt = val.split('\n');
	return val.length - (txt.length - 1) * 2;
}