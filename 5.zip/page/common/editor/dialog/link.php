<?php
/*
 * リンクの設定を行う
 */
//設定ファイル読み込み
require_once ("../.htsetting");

//エラー画面設定 別ウィンドウ用
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$dacTools = new dac_tools($objCnc);
if (isset($_SESSION['use_template_id'])) {
	if ($dacTools->selectTemplate($_SESSION['use_template_id']) === FALSE) user_error("テンプレート情報の取得に失敗しました。", E_USER_ERROR);
	$acc_flg = $dacTools->fld['acc_flg'];
}
else
	$acc_flg = ACCESSIBILITY_JP_FLG;
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex, nofollow" />
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>リンク設定</title>
<base target="_self">
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
			<!--
				<?php
				echo loadSettingVars();
				?>
				var acc_flg = <?=$acc_flg?>;
			//-->
		</script>
<script
	src="<?=RPW?>/ckeditor/gd_files/js/dialog_common.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/page/common/editor/dialog/js/link.js"
	type="text/javascript"></script>
</head>
<body bgcolor="#FFFFFF">
<div id="cms8341-headareaZero" style="margin-bottom: 0px !important">
<table width="450" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="450" height="400" align="center" valign="top"
			bgcolor="#DFDFDF" style="border: solid 1px #343434;">
		<table width="450" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/fcklink/title_linkset.jpg" alt="リンク設定"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a
					href="javascript:void(0)"
					onClick="cxIframeLayerCallback();return false;"><img
					src="<?=RPW?>/admin/images/fcklink/btn_close.jpg" alt="閉じる"
					width="58" height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 430px; height: 355px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #343434">
		<div align="center">
		<div
			style="width: 390px; height: 265px; padding: 8px; text-align: left">
		<table border="0" cellspacing="0" align="center" width="390px">
			<tr>
				<th width="30%" align="left" valign="top"
					style="font-size: 12px; font-weight: bold; padding: 5px; vertical-align: top; border: solid 1px #999999;"
					bgcolor="#eeeeee" nowrap>リンクタイプ<br />
				</th>
				<td width="70%"
					style="border-top: solid 1px #999999; border-right: solid 1px #999999; border-bottom: solid 1px #999999;">
				<input type="radio" name="chkLinkType" id="chkLinkType_InUrl"
					value="inurl" onclick="SetLinkType(this.value);" checked><label
					for="chkLinkType_InUrl"><span style="font-size: 12px;">サイト内ページ</span></label><br />
				<input type="radio" name="chkLinkType" id="chkLinkType_Url"
					value="url" onclick="SetLinkType(this.value);"><label
					for="chkLinkType_Url"><span style="font-size: 12px;">外部ページ</span></label><br />
				<input type="radio" name="chkLinkType" id="chkLinkType_Email"
					value="email" onclick="SetLinkType(this.value);"><label
					for="chkLinkType_Email"><span style="font-size: 12px;">メール</span></label><br />
				<input type="radio" name="chkLinkType" id="chkLinkType_File"
					value="file" onclick="SetLinkType(this.value);"><label
					for="chkLinkType_File"><span style="font-size: 12px;">ファイル</span></label><br />
				</td>
			</tr>
			<tr>
				<th align="left" valign="top"
					style="font-size: 12px; font-weight: bold; padding: 5px; vertical-align: top; border-left: solid 1px #999999; border-right: solid 1px #999999; border-bottom: solid 1px #999999;"
					bgcolor="#eeeeee" nowrap>
				<div id="divLinkTypeInUrl_name">リンクURL</div>
				<div id="divLinkTypeUrl_name">リンクURL</div>
				<div id="divLinkTypeEMail_name">メールアドレス</div>
				<div id="divLinkTypeFile_name">ファイルパス</div>
				</th>
				<td
					style="border-right: solid 1px #999999; border-bottom: solid 1px #999999;">
				<div id="divLinkTypeInUrl">
				<table width="100%" border="0">
					<tr>
						<td width="100%"><input id="txtInUrl"
							style="ime-mode: disabled; WIDTH: 100%" type="text" /></td>
					</tr>
					<tr>
						<td>
						<div id="mode_set_normal_InUrl">
																	<?php
																	if (FCK_LINK_OTHER_WINDOW) {
																		?>
																	<input type="checkbox" id="setBlank_InUrl"><label
							for="setBlank_InUrl"><span style="font-size: 12px;">別ウィンドウで開く</span></label>
																	<?php
																	}
																	?>
																</div>
						<div id="mode_set_mobile_InUrl" style="display: none">アクセスキー： <input
							type="text" id="setAccessKey_InUrl" maxlength="1" size="4"
							style="ime-mode: disabled" onkeypress="IsDigit(event)" /></div>
						</td>
					</tr>
				</table>
				</div>
				<div id="divLinkTypeUrl">
				<table width="100%" border="0">
					<tr>
						<td width="10%"><select id="cmbLinkProtocol">
							<option value="http://" selected="selected">http://</option>
							<option value="https://">https://</option>
							<option value="">&lt;その他&gt;</option>
						</select></td>
						<td><input id="txtUrl" style="ime-mode: disabled; WIDTH: 100%"
							type="text" onkeyup="OnUrlChange();" onchange="OnUrlChange();" />
						</td>
					</tr>
					<tr>
						<td colspan="2">
						<div id="mode_set_normal_Url">
																	<?php
																	if (FCK_LINK_OTHER_WINDOW) {
																		?>
																	<input type="checkbox" id="setBlank_Url"><label
							for="setBlank_Url"><span style="font-size: 12px;">別ウィンドウで開く</span></label>
																	<?php
																	}
																	?>
																</div>
						<div id="mode_set_mobile_Url" style="display: none">アクセスキー： <input
							type="text" id="setAccessKey_Url" maxlength="1" size="4"
							style="ime-mode: disabled" onkeypress="IsDigit(event)" /></div>
						</td>
					</tr>
				</table>
				</div>
				<div id="divLinkTypeEMail">
				<table width="100%" border="0">
					<tr>
						<td width="100%"><input id="txtEMailAddress"
							style="ime-mode: disabled; WIDTH: 100%" type="text" /><br />
						</td>
					</tr>
					<tr>
						<td></td>
					</tr>
				</table>
				</div>
				<div id="divLinkTypeFile">
				<table width="100%" border="0">
					<tr>
						<td width="100%"><input id="txtFile"
							style="ime-mode: disabled; WIDTH: 100%" type="text" /><br />
						</td>
					</tr>
					<tr>
						<td>
						<div id="mode_set_normal_File">
																	<?php
																	if (FCK_LINK_OTHER_WINDOW) {
																		?>
																	<input type="checkbox" id="setBlank_File"><label
							for="setBlank_File"><span style="font-size: 12px;">別ウィンドウで開く</span></label>
																	<?php
																	}
																	?>
																</div>
						<div id="mode_set_mobile_File" style="display: none">アクセスキー： <input
							type="text" id="setAccessKey_File" maxlength="1" size="4"
							style="ime-mode: disabled" onkeypress="IsDigit(event)" /></div>
						</td>
					</tr>
				</table>
				</div>
				<div id="divLinkTypeAnchor" style="DISPLAY: none" align="center">
				<div id="divSelAnchor" style="DISPLAY: none">
				<table border="0" width="100%">
					<tr>
						<td><span fckLang="DlgLnkAnchorByName">By Anchor Name</span><br />
						<select id="cmbAnchorName" style="WIDTH: 100%">
							<option value="" selected="selected"></option>
						</select></td>
					</tr>
				</table>
				</div>
				<div id="divNoAnchor" style="DISPLAY: none"><span
					fckLang="DlgLnkNoAnchors">&lt;No anchors available in the
				document&gt;</span></div>
				</div>
				<div id="divLinkTypeTel" style="DISPLAY: none"><input
					id="txtTelNumber" style="WIDTH: 100%; ime-mode: disabled;"
					type="text" onkeypress="IsDigit(event)" /><br />
				ハイフンやカッコなしの「番号のみ」入力してください。<br />
				</div>
				</td>
			</tr>
			<tr style="border: solid 1px #999999;">
				<th align="left" valign="top"
					style="font-size: 12px; font-weight: bold; padding: 5px; vertical-align: top; border-left: solid 1px #999999; border-right: solid 1px #999999; border-bottom: solid 1px #999999;"
					bgcolor="#eeeeee" nowrap>リンク先詳細<br />
				</th>
				<td
					style="border-right: solid 1px #999999; border-bottom: solid 1px #999999;">
				<table border="0" width="100%"
					style="margin-top: 5px; margin-bottom: 10px;">
					<tr>
						<td>
						<div id="divSiteLink"><a id="aSiteLink" href="javascript:void(0)"
							onclick="showModal(1);"><img
							src="<?=RPW?>/admin/images/fcklink/btn_pagelink_on.jpg"
							width="180" height="20" alt="サイト内リンク設定" border="0"></a></div>
						</td>
					</tr>
					<tr>
						<td>
						<div id="divFileLink"><a id="aFileLink" href="javascript:void(0)"
							onclick="showModal(2);"><img
							src="<?=RPW?>/admin/images/fcklink/btn_filelink_on.jpg"
							width="180" height="20" alt="ファイルリンク設定" border="0"></a></div>
						</td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</div>
		<div style="margin: 15px 0px;"><a href="javascript:void(0)"
			onClick="window.Ok(); return false;"><img
			src="<?=RPW?>/admin/images/fcklink/btn_complete.jpg" alt="完了"
			width="100" height="20" border="0"></a></div>
		</div>
<?php
print($dacTools->setAccessibility());
?>
		</div>
		</td>
	</tr>
</table>
</div>
</body>
</html>
