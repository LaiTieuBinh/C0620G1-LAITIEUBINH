/*
 * リンク設定用javascript
 */
 
window.dialogArguments = window.frameElement.args;

//正規表現の作成
var oRegex = new Object();
//ロード時のプロトコル解析用正規表現
oRegex.UriProtocol = new RegExp('');
oRegex.UriProtocol.compile('^((((http|https):)?\/\/)|mailto:|tel:)','gi');
//入力時のプロトコル解析用正規表現
oRegex.UrlOnChangeProtocol = new RegExp('');
oRegex.UrlOnChangeProtocol.compile('^(http|https)://(?=.)','gi');
//その他のプロトコル解析用正規表現
oRegex.UrlOnChangeTestOther = new RegExp('');
oRegex.UrlOnChangeTestOther.compile('^((javascript:)|[#/\.]|((ftp|news)://))','gi');
//ターゲット解析用正規表現
oRegex.ReserveTarget = new RegExp('');
oRegex.ReserveTarget.compile('^_(blank|self|top|parent)$','i');

//定義済テキストの削除用
var delRepText = '';
//配列を作成
var ADD_FILE_DETAIL_EXP_ARY = getAddFileDetailExp();
for(i in ADD_FILE_DETAIL_EXP_ARY){
	//定義用テキスト削除用の正規表現作成
	if(acc_flg == 0) delRepText += (delRepText != '' ? '|' : '') + ADD_FILE_DETAIL_EXP_ARY[i]['JP'];		//日本語
	else if(acc_flg == 1) delRepText += (delRepText != '' ? '|' : '') + ADD_FILE_DETAIL_EXP_ARY[i]['EN'];	//外国語
}

//ファイルサイズ（単位：KB）
var FSize;
//ファイル拡張子
var FExp;

//リンク情報の作成
if(window.dialogArguments.href){
	var oLink = document.createElement('A');
	if(window.dialogArguments.href) oLink.href = window.dialogArguments.href;
	if(window.dialogArguments.text) oLink.innerHTML = cxEscapeHtmlChars(window.dialogArguments.text);
	if(window.dialogArguments.target) oLink.target = window.dialogArguments.target;
}

//-------------------------------------------------
//	ロード時に実行される
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
window.onload = function(){
	//リンクに設定されている値の取得
	LoadSelection();
	//リンクタイプの切り替え
	SetLinkType(Get_Sel_Item());
}

//-------------------------------------------------
//	現在設定されている値を取得する
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
var sType = "";
var sHRef = "";
var sTxt = "";
function LoadSelection(){
	//事前にテキストを取得
	if(window.dialogArguments.text){
		sTxt = cxEscapeHtmlChars(window.dialogArguments.text);
	}
	//リンクが無ければ、returnする
	if(!oLink) return;

	//初期値設定
	sType = GetE('chkLinkType_InUrl').value;
	//設定されているリンク先を取得
	sHRef = oLink.getAttribute('_fcksavedurl');
	if(!sHRef || sHRef.length == 0) sHRef = oLink.getAttribute('href',2) + '';
	//ローカルサーバのパスならば、その部分を取り除く
	sHRef = sHRef.replace(HTTP_ROOT,'');
	//リンクタイトルの取得
	sTxt = cxUnEscapeHtmlChars(oLink.innerHTML);

	//プロトコルを取得
	oRegex.UriProtocol.lastIndex = 0;
	var sProtocol = oRegex.UriProtocol.exec(sHRef);
	//プロトコルにより処理を分ける
	if(sProtocol){
		sProtocol = sProtocol[0].toLowerCase();
		//URLよりプロトコル部分を取り除く
		var sUrl = sHRef.replace(oRegex.UriProtocol,'');
		//mailto: E-Mail
		if(sProtocol == 'mailto:'){
			sType = GetE('chkLinkType_Email').value;
			var oEMailInfo = ParseEMailUrl(sUrl);
			GetE('txtEMailAddress').value = oEMailInfo.Address;
		}
		//http:// 外部リンク
		else if(sProtocol == 'http://' || sProtocol == 'https://'){
			sType = GetE('chkLinkType_Url').value;
			GetE('txtUrl').value = sUrl;
			GetE('cmbLinkProtocol').value = sProtocol;
		}
		//その他
		else{
			sType = GetE('chkLinkType_Url').value;
			GetE('txtUrl').value = sProtocol + sUrl;
			GetE('cmbLinkProtocol').value = '';
		}
		afterLoadSelection();
	}
	//その他
	else{
		//内部パスを消す
		if(sHRef.startsWith(RPW)) sHRef = sHRef.remove(0,RPW.length);
		cxAjaxCommand('cxFCKGetFileInfo','file_path=' + sHRef,AjaxSuccess);
	}
}

//-------------------------------------------------
//	通信成功処理
//	【引数】
//		r	: カンマ区切りの文字列(ファイルパス,拡張子,サイズ)
//	【戻値】
//		なし
//-------------------------------------------------
function AjaxSuccess(r){
	if(r.responseText != ""){
		fileinfo = r.responseText.split(",");
		//ファイル
		FExp = fileinfo[1];
		FSize = fileinfo[2];
		sType = GetE('chkLinkType_File').value;
		GetE('txtFile').value = fileinfo[0];
	}
	afterLoadSelection();
}

//-------------------------------------------------
//	通信失敗処理
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
function cxFailure(){
	afterLoadSelection();
}

//-------------------------------------------------
//	ロード後処理
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
function afterLoadSelection(){
	//どの条件にも当てはまらない場合
	if(sType == GetE('chkLinkType_InUrl').value){
		//サイト内リンク
		if(sHRef.match(/^\/[\-\_\.!~\*\'\(\)a-zA-Z0-9;\/\?:\@&=+\$,%#]+$/)){
			GetE('txtInUrl').value = sHRef;
		}
		//外部リンク(その他)
		else{
			sType = GetE('chkLinkType_Url').value;
			GetE('txtUrl').value = sHRef;
			GetE('cmbLinkProtocol').value = '';
		}
	}
	//リンクに設定されているtarget属性を取得する
	var sTarget = oLink.target;
	if(sTarget && sTarget.length > 0){
		if(oRegex.ReserveTarget.test(sTarget)) sTarget = sTarget.toLowerCase();
	}
	//target属性に_blankが指定されていた場合、対応するチェックボックスにチェックをつける
	if(sTarget == "_blank"){
		if(sType == GetE('chkLinkType_InUrl').value && GetE('setBlank_InUrl')) GetE('setBlank_InUrl').checked = true;
		else if(sType == GetE('chkLinkType_Url').value && GetE('setBlank_Url')) GetE('setBlank_Url').checked = true;
		else if(sType == GetE('chkLinkType_File').value && GetE('setBlank_File')) GetE('setBlank_File').checked = true;
	}

	//リンクタイプによりチェックボックスの切り替え
	if(sType == GetE('chkLinkType_InUrl').value) GetE('chkLinkType_InUrl').checked = true;
	else if(sType == GetE('chkLinkType_Url').value) GetE('chkLinkType_Url').checked = true;
	else if(sType == GetE('chkLinkType_Email').value) GetE('chkLinkType_Email').checked = true;
	else if(sType == GetE('chkLinkType_File').value) GetE('chkLinkType_File').checked = true;

	//リンクタイプの切り替え(Ajaxが非同期のため、予備)
	SetLinkType(Get_Sel_Item());
}

//-------------------------------------------------
//	リンクタイプの切り替え
//	【引数】
//		linkType	: 現在選択されているリンクタイプ
//	【戻値】
//		なし
//-------------------------------------------------
function SetLinkType(linkType){
	//内部リンク
	ShowE('divLinkTypeInUrl_name',(linkType == GetE('chkLinkType_InUrl').value));
	ShowE('divLinkTypeInUrl',(linkType == GetE('chkLinkType_InUrl').value));
	//外部リンク
	ShowE('divLinkTypeUrl_name',(linkType == GetE('chkLinkType_Url').value));
	ShowE('divLinkTypeUrl',(linkType == GetE('chkLinkType_Url').value));
	//E-Mail
	ShowE('divLinkTypeEMail_name',(linkType == GetE('chkLinkType_Email').value));
	ShowE('divLinkTypeEMail',(linkType == GetE('chkLinkType_Email').value));
	//ファイル
	ShowE('divLinkTypeFile_name',(linkType == GetE('chkLinkType_File').value));
	ShowE('divLinkTypeFile',(linkType == GetE('chkLinkType_File').value));

	//ページ内リンク以外なら、ボタンを無効にする
	if(linkType != GetE('chkLinkType_InUrl').value) GetE('divSiteLink').innerHTML = '<img src="' + RPW + '/admin/images/fcklink/btn_pagelink_off.jpg" width="180" height="20" alt="" border="0">';
	//ページ内リンクなら有効にする
	else GetE('divSiteLink').innerHTML = '<a id="aSiteLink" href="javascript:void(0)" onclick="showModal(1);"><img src="' + RPW + '/admin/images/fcklink/btn_pagelink_on.jpg" width="180" height="20" alt="サイト内リンク設定" border="0"></a>';
	//ファイル以外なら、ボタンを無効にする
	if(linkType != GetE('chkLinkType_File').value) GetE('divFileLink').innerHTML = '<img src="' + RPW + '/admin/images/fcklink/btn_filelink_off.jpg" width="180" height="20" alt="" border="0">';
	//ファイルなら有効にする
	else GetE('divFileLink').innerHTML = '<a id="aFileLink" href="javascript:void(0)" onclick="showModal(2);"><img src="' + RPW + '/admin/images/fcklink/btn_filelink_on.jpg" width="180" height="20" alt="ファイルリンク設定" border="0"></a>';
}

//-------------------------------------------------
//	URLを入力した際に動的にプロトコルをチェックする
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
function OnUrlChange(){
	var sUrl = GetE('txtUrl').value;
	var sProtocol = oRegex.UrlOnChangeProtocol.exec(sUrl);

	if(sProtocol){
		sUrl = sUrl.substr(sProtocol[0].length);
		GetE('txtUrl').value = sUrl;
		GetE('cmbLinkProtocol').value = sProtocol[0].toLowerCase();
	}
	else if(oRegex.UrlOnChangeTestOther.test(sUrl)) GetE('cmbLinkProtocol').value = '';
}

//-------------------------------------------------
//	決定ボタンが押された際の処理
//	【引数】
//		なし
//	【戻値】
//		true	: 成功時
//		false	: 失敗時
//-------------------------------------------------
function Ok(){
	var sUri,sInnerHtml;

	var selected_item = Get_Sel_Item();
	//サイト内リンクフォーマットチェック用正規表現
	var osUriRegEx = new RegExp("^(s?https?:\/)?\/[-_.!~*'()a-zA-Z0-9;\/?:\@&=+\$,%#]+$");
	switch (selected_item){
		//内部リンク
		case GetE('chkLinkType_InUrl').value:
			
			// リンクテキストチェック
			var link_text = "";
			var info = new Array();
			if(window.dialogArguments.text){
				link_text = cxEscapeHtmlChars(window.dialogArguments.text);
				info = accItemCheck('リンクタイトル',link_text,info,'link');
				if(info.length > 0){
					alert("リンクテキストに推奨されない文字が指定されています。");
				}
				
				// 「　(文字参照全角スペース)」を「 (半角スペース)」に変換
				link_text = link_text.replace(/　/g, " ");
				// 「 (半角スペース)」を削除
				link_text = link_text.replace(/ /g, "");
				if (link_text.length < 1) {
					alert("リンクテキストに画面に表示されない文言のみ指定されています。");
				}
			}
			
			//URLの取得
			sUri = trim(GetE('txtInUrl').value);
			//ローカルサーバのパスならば、その部分を取り除く
			sUri = sUri.replace(HTTP_ROOT,'')
			if(sUri.startsWith(RPW)) sUri = sUri.remove(0,RPW.length);
			//必須チェック
			if(sUri.length == 0){
				alert("リンクURLを入力してください。");
				GetE('txtInUrl').focus();
				return false;
			}
			//URLフォーマットチェック
			var asUriPath = osUriRegEx.exec(sUri);
			if(asUriPath == null){
				alert("リンクURLに不正な値が入力されています。");
				GetE('txtInUrl').focus();
				return false;
			}
			//プロトコルを取得
			oRegex.UriProtocol.lastIndex = 0;
			var sProtocol = oRegex.UriProtocol.exec(sUri);
			//プロトコルが存在しない場合
			if(sProtocol == null){
				//内部パスを足す
				sUri = RPW + sUri;
			}
			FExp = null;
			FSize = null;
			break;
		//外部リンク
		case GetE('chkLinkType_Url').value:
			
			// リンクテキストチェック
			var link_text = "";
			var info = new Array();
			if(window.dialogArguments.text){
				link_text = cxEscapeHtmlChars(window.dialogArguments.text);
				info = accItemCheck('リンクタイトル',link_text,info,'link');
				if(info.length > 0){
					alert("リンクテキストに推奨されない文字が指定されています。");
				}
				
				// 「　(文字参照全角スペース)」を「 (半角スペース)」に変換
				link_text = link_text.replace(/　/g, " ");
				// 「 (半角スペース)」を削除
				link_text = link_text.replace(/ /g, "");
				if (link_text.length < 1) {
					alert("リンクテキストに画面に表示されない文言のみ指定されています。");
				}
			}
			
			//URLの取得
			sUri = trim(GetE('txtUrl').value);
			//必須チェック
			if(sUri.length == 0){
				alert("リンクURLを入力してください。");
				GetE('txtUrl').focus();
				return false;
			}
			//プロトコルを取得
			oRegex.UriProtocol.lastIndex = 0;
			var sProtocol = oRegex.UriProtocol.exec(sUri);
			//プロトコルが存在しない場合
			if(sProtocol == null){
				//プロトコルを足す
				sUri = GetE('cmbLinkProtocol').value + sUri;
			}
			//URLフォーマットチェック
			if(GetE('cmbLinkProtocol').value != ""){
				osUriRegEx = URLRegEx;
				var asUriPath = osUriRegEx.exec(sUri);
				if(asUriPath == null){
					alert("リンクURLに不正な値が入力されています。");
					GetE('txtUrl').focus();
					return false;
				}
			}
			//ローカルサーバのパスならば、その部分を取り除く
			sUri = sUri.replace(HTTP_ROOT,'')
			if(sUri.startsWith(RPW)) sUri = sUri.remove(0,RPW.length);
			//プロトコルを取得
			oRegex.UriProtocol.lastIndex = 0;
			sProtocol = oRegex.UriProtocol.exec(sUri);
			//プロトコルが存在しない場合
			if(sProtocol == null){
				//内部パスを足す
				sUri = RPW + sUri;
			}
			FExp = null;
			FSize = null;
			break;
		//E-Mail
		case GetE('chkLinkType_Email').value:
			
			// リンクテキストチェック
			var link_text = "";
			var info = new Array();
			if(window.dialogArguments.text){
				link_text = cxEscapeHtmlChars(window.dialogArguments.text);
				info = accItemCheck('リンクタイトル',link_text,info,'link');
				if(info.length > 0){
					alert("リンクテキストに推奨されない文字が指定されています。");
				}
				
				// 「　(文字参照全角スペース)」を「 (半角スペース)」に変換
				link_text = link_text.replace(/　/g, " ");
				// 「 (半角スペース)」を削除
				link_text = link_text.replace(/ /g, "");
				if (link_text.length < 1) {
					alert("リンクテキストに画面に表示されない文言のみ指定されています。");
				}
			}
			
			//メールアドレスの取得
			sUri = trim(GetE('txtEMailAddress').value);
			//必須チェック
			if(sUri.length == 0){
				alert("メールアドレスを入力してください。");
				GetE('txtEMailAddress').focus();
				return false;
			}
			//メールアドレスフォーマットチェック
			var asUriPath = EMailRegEx.exec(sUri);
			if(asUriPath == null){
				alert("メールアドレスに不正な値が入力されています。");
				GetE('txtEMailAddress').focus();
				return false;
			}
			//プロトコルを取得
			oRegex.UriProtocol.lastIndex = 0;
			var sProtocol = oRegex.UriProtocol.exec(sUri);
			//プロトコルが存在しない場合
			if(sProtocol == null){
				//設定値の作成
				sUri = CreateEMailUri(sUri,"","");
			}
			FExp = null;
			FSize = null;
			break;
		//ファイル
		case GetE('chkLinkType_File').value:
			
			// リンクテキストチェック
			var link_text = "";
			var info = new Array();
			if(window.dialogArguments.text){
				link_text = cxEscapeHtmlChars(window.dialogArguments.text);
				info = accItemCheck('リンクタイトル',link_text,info,'link');
				if(info.length > 0){
					alert("リンクテキストに推奨されない文字が指定されています。");
				}
				
				// 「　(文字参照全角スペース)」を「 (半角スペース)」に変換
				link_text = link_text.replace(/　/g, " ");
				// 「 (半角スペース)」を削除
				link_text = link_text.replace(/ /g, "");
				if (link_text.length < 1) {
					alert("リンクテキストに画面に表示されない文言のみ指定されています。");
				}
			}
			
			//ファイルパスの取得
			sUri = trim(GetE('txtFile').value);
			//ローカルサーバのパスならば、その部分を取り除く
			sUri = sUri.replace(HTTP_ROOT,'')
			if(sUri.startsWith(RPW)) sUri = sUri.remove(0,RPW.length);
			//必須チェック
			if(sUri.length == 0){
				alert("ファイルパスを入力してください。");
				GetE('txtFile').focus();
				return false;
			}
			//ファイル拡張子のチェック
			var File_Exte = DENIED_EXTENSIONS_FILE.split(",");
			for(var i = 0;i < File_Exte.length;i++){
				var ExteRegEx = new RegExp("(\\." + File_Exte[i] + ")$");
				var asFileExte = ExteRegEx.exec(sUri);
				if(asFileExte != null){
					alert("設定できないファイル拡張子が入力されています。");
					GetE('txtFile').focus();
					return false;
				}
			}
			//プロトコルを取得
			oRegex.UriProtocol.lastIndex = 0;
			var sProtocol = oRegex.UriProtocol.exec(sUri);
			//プロトコルが存在しない場合
			if(sProtocol == null){
				//内部パスを足す
				sUri = RPW + sUri;
			}
			break;
	}

	//オブジェクトの作成
	var retObj = new Object();
	retObj["ret"] = sUri + KANKO_LINK_DELIMITER + sTxt;
	//属性設定
	if(selected_item == GetE('chkLinkType_InUrl').value && GetE('setBlank_InUrl') && GetE('setBlank_InUrl').checked) retObj["ret"] += KANKO_LINK_DELIMITER + "_blank";
	else if(selected_item == GetE('chkLinkType_Url').value && GetE('setBlank_Url') && GetE('setBlank_Url').checked) retObj["ret"] += KANKO_LINK_DELIMITER + "_blank";
	else if(selected_item == GetE('chkLinkType_File').value && GetE('setBlank_File') && GetE('setBlank_File').checked) retObj["ret"] += KANKO_LINK_DELIMITER + "_blank";
	else retObj["ret"] += KANKO_LINK_DELIMITER + "_self";
	//ファイル情報
	if(selected_item == GetE('chkLinkType_File').value){
		if(FExp) retObj["ret"] += KANKO_LINK_DELIMITER + FExp;
		if(FSize) retObj["ret"] += KANKO_LINK_DELIMITER + FSize;
	}
	cxIframeLayerCallback(retObj);
	//正常終了
	return true;
}

//-------------------------------------------------
//	モーダルダイアログを表示する
//	【引数】
//		open_dlg	: オープンするダイアログのID
//					: 1 サイト内にリンク
//					: 2 ファイルにリンク
//	【戻値】
//		なし
//-------------------------------------------------
function showModal(open_dlg){
	var newDlg;
	var Open_URL;
	var Open_Title;
	var Open_Width;
	var Open_Height;
	//サイト内リンク
	if(open_dlg == 1){
		Open_URL = RPW + "/ckeditor/plugins/gd_link/fck_link/fck_sitelink.php" + ((GetE('txtInUrl').value != "") ? ("?url=" + GetE('txtInUrl').value) : (""));
		Open_Title = "サイト内にリンク";
		Open_Width = 800;
		Open_Height = 600;
		Open_resize = 0;
	}
	//ファイルリンク
	else if(open_dlg == 2){
		Open_URL = RPW + "/ckeditor/plugins/gd_link/fck_link/fck_filelink.php" + ((GetE('txtFile').value != "") ? ("?url=" + encodeURL(GetE('txtFile').value)) : (""));
		Open_Title = "ファイルにリンク";
		Open_Width = 630;
		Open_Height = 680;
		Open_resize = 0;
	}
	//ダイアログ表示
	cxIframeLayer(
		Open_URL,
		Open_Width,
		Open_Height,
		COVER_SETTING.COLOR,
		'',
		function (newURL) {
			//戻り値がundefined以外ならvalueにセット
			if(newURL != undefined){
				$sel_item = Get_Sel_Item();
				if($sel_item == GetE('chkLinkType_InUrl').value){
					GetE('txtInUrl').value = newURL["url"] + (newURL["anchor"] ? ("#" + newURL["anchor"]) : "");
				}
				else if($sel_item == GetE('chkLinkType_File').value){
					GetE('txtFile').value = newURL["url"];
					FExp = newURL["exp"];
					FSize = newURL["size"];
				}
			}
		}
	);
}

//-------------------------------------------------
//	現在選択されているリンクタイプを取得する
//	【引数】
//		なし
//	【戻値】
//		現在選択されているリンクタイプのvalue名
//-------------------------------------------------
function Get_Sel_Item(){
	var ret;
	if(GetE('chkLinkType_Url').checked) ret = GetE('chkLinkType_Url').value;
	else if(GetE('chkLinkType_Email').checked) ret = GetE('chkLinkType_Email').value;
	else if(GetE('chkLinkType_File').checked) ret = GetE('chkLinkType_File').value;
	else ret = GetE('chkLinkType_InUrl').value;
	return ret;
}

//-------------------------------------------------
//	E-Mailを含んだURLを分割する
//	【引数】
//		emailUrl	: E-Mailを含んだURL
//	【戻値】
//		分割したEMailオブジェクト
//-------------------------------------------------
function ParseEMailUrl(emailUrl){
	//Initializes the EMailInfo object.
	var oEMailInfo = new Object();
	oEMailInfo.Address	= '';
	oEMailInfo.Subject	= '';
	oEMailInfo.Body		= '';

	var oParts = emailUrl.match(/^([^\?]+)\??(.+)?/);
	if(oParts){
		//Set the e-mail address.
		oEMailInfo.Address = oParts[1];
		//Look for the optional e-mail parameters.
		if(oParts[2]){
			var oMatch = oParts[2].match(/(^|&)subject=([^&]+)/i);
			if(oMatch) oEMailInfo.Subject = unescape(oMatch[2]);
			oMatch = oParts[2].match(/(^|&)body=([^&]+)/i);
			if(oMatch) oEMailInfo.Body = unescape(oMatch[2]);
		}
	}
	return oEMailInfo;
}

//-------------------------------------------------
//	E-Mailを含んだURLを作成する
//	【引数】
//		address	: メールアドレス
//		subject	: 題名
//		body	: 本文
//	【戻値】
//		E-Mailを含んだURL
//-------------------------------------------------
function CreateEMailUri(address,subject,body){
	var sBaseUri = 'mailto:' + address;
	var sParams = '';

	if(subject.length > 0) sParams = '?subject=' + escape(subject);

	if(body.length > 0){
		sParams += (sParams.length == 0 ? '?' : '&');
		sParams += 'body=' + escape(body);
	}
	return sBaseUri + sParams;
}

//-------------------------------------------------
//	文字列をURLエンコードする(UTF-8)
//	【引数】
//		str	: エンコードしたい文字列
//	【戻値】
//		エンコードした文字列
//-------------------------------------------------
function encodeURL(str){
	var character = '';
	var unicode = '';
	var string = '';
	var i = 0;
	for(i = 0;i < str.length;i++){
		character = str.charAt(i);
		unicode = str.charCodeAt(i);
		if(character == ' ') string += '+';
		else{
			if(unicode == 0x2a || unicode == 0x2d || unicode == 0x2e || unicode == 0x5f || ((unicode >= 0x30) && (unicode <= 0x39)) || ((unicode >= 0x41) && (unicode <= 0x5a)) || ((unicode >= 0x61) && (unicode <= 0x7a))){
				string = string + character;
			}
			else{
				if((unicode >= 0x0) && (unicode <= 0x7f)){
					character = '0' + unicode.toString(16);
					string += '%' + character.substr(character.length - 2);
				}
				else if(unicode > 0x1fffff){
					string += '%' + (oxf0 + ((unicode & 0x1c0000) >> 18)).toString(16);
					string += '%' + (0x80 + ((unicode & 0x3f000) >> 12)).toString(16);
					string += '%' + (0x80 + ((unicode & 0xfc0) >> 6)).toString(16);
					string += '%' + (0x80 + (unicode & 0x3f)).toString(16);
				}
				else if(unicode > 0x7ff){
					string += '%' + (0xe0 + ((unicode & 0xf000) >> 12)).toString(16);
					string += '%' + (0x80 + ((unicode & 0xfc0) >> 6)).toString(16);
					string += '%' + (0x80 + (unicode & 0x3f)).toString(16);
				}
				else{
					string += '%' + (0xc0 + ((unicode & 0x7c0) >> 6)).toString(16);
					string += '%' + (0x80 + (unicode & 0x3f)).toString(16);
				}
			}
		}
	}
	return string;
}
