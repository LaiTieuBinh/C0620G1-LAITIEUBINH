/*
 *
 */
// インライン要素
var INLINE_NODES           = new Array("STRONG", "EM", "A" );

// 見出しを設定できない要素(子要素内に含まれている場合もダメ)
var NOT_SET_H_TAG_NODE     = new Array("TABLE","DIV");
// 枠を設定できない要素(子要素内に含まれている場合もダメ)
var NOT_SET_FRAME_NODE     = new Array("DIV","H2","H3","H4","H5","H6");
// テーブルを設定できない要素
var NOT_SET_TABLE_TAG_NODE = new Array("H2","H3","H4","H5","H6");

// 貼り付け(Ctrl+V)時に許可できないタグ
var NOT_PASTE_TAG          = new Array("IMG");

function Editor(objId,toolId,objName) {
	this.obj   = $(objId);
	this.tool  = $(toolId);
	this.sys   = objName;
	//
	this.caret = null;
	this.type  = null;
	this.elem  = null;
	this.p_elem = null;
	this.doflg = true;
	this.saveHTML;
	// テーブル関連
	this.tableObj = null;
	this.tbodyObj = null;
	this.trObj    = null;
	this.thtdObj  = null;
}
Editor.prototype.getCapture = function() {
	// IE11対応
	if(document.getSelection().type == "None") return;
	this.caret = document.getSelection();
	this.caret.text = this.caret.toString();
	this.type  = document.getSelection().type;
	this.elem  = event.srcElement;
	this.p_elem = this.elem.parentNode;
	window.status = "選択タイプ：" + this.type + "　選択中のタグ名：" + this.elem.tagName + "　選択中のテキスト：" + this.caret.text + "　親のタグ名：" + this.p_elem.tagName;
};
Editor.prototype.getKeyDownCapture = function() {
	var keycode = event.keyCode;
	var ctrlkey = event.ctrlKey;
	//if(ctrlkey && keycode==86) {
	//	return this.textPaste();
	//}
	this.getCapture();
};
Editor.prototype.getDblCapture = function() {
	this.elem  = event.srcElement;
	switch(this.elem.tagName) {
		case "A":
			var editor = this;
			this.exec('link', function() {
				editor.getCapture();
			});
			return;
			break;
		default:
			break;
	}
	this.getCapture();
};
Editor.prototype.getDragCapture = function() {
	return false;
}

Editor.prototype.closeContextMenu = function(oId) {
	edit_closet_flg = false;
	var o = ($(oId))? $(oId):false;
	if(o) document.body.removeChild(o);
};
Editor.prototype.createContextMenu = function(mx,my,tar_elem) {
	
	this.elem = tar_elem;
	
	var ui = "";
	var o = document.createElement('DIV');
		o.id = 'contextmenu';
		o.style.left = mx + 'px';
		o.style.top = my + 'px';
		o.style.display = 'block';
		o.className= "cms8341-layer";
	tagName = tar_elem.tagName;
	if(tagName == "P"){
		if(this.MoveToAncestorNode('TABLE') != null){
			if(this.MoveToAncestorNode('TD') != null ) {
				tagName = "TD";
				this.elem = this.MoveToAncestorNode('TD');
			}
			if(this.MoveToAncestorNode('TH') != null ) {
				tagName = "TH";
				this.elem = this.MoveToAncestorNode('TH');
			}
		}
	}
	
	switch(tagName) {
		case 'TD':
		case 'TH':
			this.tableObj = this.MoveToAncestorNode('TABLE');
			this.tbodyObj = this.MoveToAncestorNode('TBODY');
			this.trObj    = this.MoveToAncestorNode('TR');
			this.thtdObj  = this.elem;
			
			if(this.tableObj == null) break;
			if(this.tableObj.className == "outline_txt"){
				ui = this.createContextMenuString("OUTLINE_"+tagName,84);
			} else {
				ui = this.createContextMenuString(tagName,204);
			}
			break;
		case 'TABLE':
			this.tableObj = this.elem;
			
			if(this.tableObj == null) break;
			if(this.tableObj.className == "outline_txt") break;
			ui = this.createContextMenuString(tagName,104);
			break;
		case 'P':
			var divObj = this.MoveToAncestorNode('DIV');
			if(divObj.className != "outline_txt") break;
			ui = this.createContextMenuString(tagName,64);
			break;
		case 'DIV':
			if(tar_elem.className != "atention" && tar_elem.className != "intro" ) break;
			ui = this.createContextMenuString(tagName,64);
			break;
		case 'SPAN':
			var divObj = this.MoveToAncestorNode('DIV');
			if(divObj.className != "outline_txt") break;
			ui = this.createContextMenuString(tagName,64);
			break;
	}
    o.innerHTML = ui;
	return o;
};

Editor.prototype.createContextMenuString = function(tagName, height) {
	var ui  = '<table width="166" border="0" cellpadding="0" cellspacing="0" class="cms8341-noneBorder">';
	    ui += '   <tr>';
	    ui += '      <td width="158" align="left" valign="top" bgcolor="#DFDFDF" style="border:solid 1px #343434 !important;">';
	    ui += '         <table width="158" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader">';
	    ui += '            <tr>';
	    ui += '               <td align="right" valign="middle">';
	    ui += '                  <a href="javascript:"onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')" onkeyup="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/btn/btn_close.jpg" border="0" width="58" heignt="19"></a>';
	    ui += '               </td>';
	    ui += '            </tr>';
	    ui += '         </table>';
	    switch(tagName){
			case 'OUTLINE_TD':
			case 'OUTLINE_TH':
			    ui += '<div><a href="javascript:'+this.sys+'.exec(\'ins_table_tr\')" onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/contentsmenu/tr_add00.jpg" alt="列の追加" border="0" onMouseOver="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/tr_add01.jpg\')" onMouseOut="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/tr_add00.jpg\')" width="158" heignt="20"></a></div>';
			    ui += '<div><a href="javascript:'+this.sys+'.exec(\'del_table_tr\')" onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/contentsmenu/tr_del00.jpg" alt="列の削除" border="0" onMouseOver="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/tr_del01.jpg\')" onMouseOut="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/tr_del00.jpg\')" width="158" heignt="20"></a></div>';
				break;
			case 'TD':
			case 'TH':
			    ui += '<div><a href="javascript:'+this.sys+'.exec(\'ins_table_th\')" onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/contentsmenu/h_add00.jpg" alt="見出し追加" border="0" onMouseOver="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/h_add01.jpg\')" onMouseOut="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/h_add00.jpg\')" width="158" heignt="20"></a></div>';
			    ui += '<div><a href="javascript:'+this.sys+'.exec(\'del_table_th\')" onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/contentsmenu/h_del00.jpg" alt="見出し削除" border="0" onMouseOver="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/h_del01.jpg\')" onMouseOut="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/h_del00.jpg\')" width="158" heignt="20"></a></div>';
			    ui += '<div><a href="javascript:'+this.sys+'.exec(\'ins_table_tr\')" onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/contentsmenu/tr_add00.jpg" alt="列の追加" border="0" onMouseOver="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/tr_add01.jpg\')" onMouseOut="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/tr_add00.jpg\')" width="158" heignt="20"></a></div>';
			    ui += '<div><a href="javascript:'+this.sys+'.exec(\'del_table_tr\')" onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/contentsmenu/tr_del00.jpg" alt="列の削除" border="0" onMouseOver="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/tr_del01.jpg\')" onMouseOut="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/tr_del00.jpg\')" width="158" heignt="20"></a></div>';
			    ui += '<div><a href="javascript:'+this.sys+'.exec(\'ins_table_td\')" onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/contentsmenu/td_add00.jpg" alt="行の追加" border="0" onMouseOver="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/td_add01.jpg\')" onMouseOut="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/td_add00.jpg\')" width="158" heignt="20"></a></div>';
			    ui += '<div><a href="javascript:'+this.sys+'.exec(\'del_table_td\')" onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/contentsmenu/td_del00.jpg" alt="行の削除" border="0" onMouseOver="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/td_del01.jpg\')" onMouseOut="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/td_del00.jpg\')" width="158" heignt="20"></a></div>';
			    ui += '<div><a href="javascript:'+this.sys+'.exec(\'inc_table_border\')" onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/contentsmenu/table_inc00.jpg" alt="枠を太くする" border="0" onMouseOver="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/table_inc01.jpg\')" onMouseOut="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/table_inc00.jpg\')" width="158" heignt="20"></a></div>';
			    ui += '<div><a href="javascript:'+this.sys+'.exec(\'dec_table_border\')" onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/contentsmenu/table_dec00.jpg" alt="枠を細くする" border="0" onMouseOver="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/table_dec01.jpg\')" onMouseOut="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/table_dec00.jpg\')" width="158" heignt="20"></a></div>';
			    break;
			case 'TABLE':
			    ui += '<div><a href="javascript:'+this.sys+'.exec(\'inc_table_border\')" onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/contentsmenu/table_inc00.jpg" alt="枠を太くする" border="0" onMouseOver="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/table_inc01.jpg\')" onMouseOut="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/table_inc00.jpg\')" width="158" heignt="20"></a></div>';
			    ui += '<div><a href="javascript:'+this.sys+'.exec(\'dec_table_border\')" onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/contentsmenu/table_dec00.jpg" alt="枠を細くする" border="0" onMouseOver="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/table_dec01.jpg\')" onMouseOut="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/table_dec00.jpg\')" width="158" heignt="20"></a></div>';
			    break;
			case 'DIV':
			    ui += '<div><a href="javascript:'+this.sys+'.exec(\'del_div\')" onclick="return '+this.sys+'.closeContextMenu(\'contextmenu\')"><img src="'+RPW+'/admin/images/contentsmenu/del_div00.jpg" alt="枠を解除する" border="0" onMouseOver="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/del_div01.jpg\')" onMouseOut="cxImageChange(this,\''+RPW+'/admin/images/contentsmenu/del_div00.jpg\')" width="158" heignt="20"></a></div>';
			    break;
	    }
	    ui += '      </td>';
	    ui += '      <td width="7" height="'+height+'" align="left" valign="top"><img src="'+RPW+'/admin/images/contentsmenu/shadow_right.jpg" alt="" width="5" height="'+height+'"></td>';
	    ui += '   </tr>';
	    ui += '   <tr>';
	    ui += '      <td height="23" align="left" valign="top" class="cms8341-shadowBottomBg"><img src="'+RPW+'/admin/images/contentsmenu/shadow_bottom.jpg" alt="" width="160"></td>';
	    ui += '      <td height="18" align="left" valign="top"><img src="'+RPW+'/admin/images/contentsmenu/shadow_corner.jpg" alt="" width="5" height="7"></td>';
	    ui += '   </tr>';
	    ui += '</table>';
	return ui;
};
Editor.prototype.getRClickCapture = function() {
	this.closeContextMenu('contextmenu');
	var tObj = event.srcElement;
	var mx = document.body.scrollLeft+event.clientX;
	//var my = document.body.scrollTop+event.clientY;
	//alert(document.documentElement.clientHeight+":"+event.clientY+":"+document.body.scrollTop);
	if (typeof document.documentElement.style.msInterpolationMode != "undefined") {
		var my = event.clientY+document.documentElement.scrollTop;
	} else {
		var my = document.documentElement.clientHeight+event.clientY+document.body.scrollTop;
	}
	var o = this.createContextMenu(mx,my,tObj);
	document.body.appendChild(o);	
	this.elem = tObj;
	return false;
};
Editor.prototype.preview = function() {
	var s = this.obj.contentEditable;
	if(s=="true") {
		this.obj.contentEditable = "false";
		this.obj.style.borderStyle = "dotted";
		this.tool.style.backgroundColor = "#ccc";
		this.doflg = false;
	} else {
		this.obj.contentEditable = "true";
		this.obj.style.borderStyle = "solid";
		this.tool.style.backgroundColor = "";
		this.doflg = true;
	}
};
Editor.prototype.confirm = function() {
	alert(this.obj.innerHTML);
};
Editor.prototype.saveEditor = function() {
	this.saveHTML = this.obj.innerHTML;
};
Editor.prototype.restoreEditor = function() {
	this.obj.innerHTML = this.saveHTML;
};
Editor.prototype.textPaste = function() {
	//
	if(!this.caret) {
		alert('ペーストする位置を指定してください。');
		return false;
	}
	// 選択が不明
	if (this.caret.text == undefined ) {
		alert("選択している位置にはペーストできません");
		return false;
	}
	// クリップボードのデータをテキストとして取得
//	var html = clipboardData.getData('text');
	//if(!html) return;
	// データの整形
//	html = html.replace(/\n/gi,'<br>');

	var A=document.getElementById('___HiddenDiv');
	if (!A){
		var A=document.createElement('DIV');
		A.id='___HiddenDiv';
		A.style.visibility='hidden';
		A.style.overflow='hidden';
		A.style.position='absolute';
		A.style.width=1;
		A.style.height=1;
		document.body.appendChild(A);
	};
	A.innerHTML='';
	// IE11対応
	var ua = window.navigator.userAgent;
	var msie = ua.indexOf("MSIE ");
	// If Internet Explorer, return version number
	if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
		var C=document.body.createTextRange();
		C.moveToElementText(A);
		C.execCommand('Paste');
	}
	else if (window.getSelection) { 
		var C=document.createRange();
		C.selectNode(A);
		window.getSelection().addRange(C);
	//	C.moveToElementText(A);
		document.execCommand('Paste');
	}

	var html =A.innerHTML;
	A.innerHTML='';
	
	// 禁止 タグが含まれている場合、エラー
	var reg;
	for ( var i = 0 ; i < NOT_PASTE_TAG.length ; i ++ ) {
		reg = new RegExp("<(\s+)?"+NOT_PASTE_TAG[ i ], "i");
		
		if ( html.match( reg ) ) {
			alert('【'+NOT_PASTE_TAG[ i ]+'】タグを含んだ内容をペーストすることはできません。');
			return false;
		}
	}
	
	// リスト化するタグに特殊属性「_gdlist」を付加
	html = html.replace(/style=('|")[^']*mso-list[^'"]*level(\d+)[^'"]*('|")/gi,
											function($0,$1,$2) {
												if($2) {
													return '_gdlist="'+$2+'"';
												} else {
													return '';
												}
											}
											);
	////一太郎対応/////////////////////////////////////////////////////////////////////////////////////////
	//**一太郎改ページコードの削除/////////////////////////////////////////////////////////////////////////
	html = html.replace(//gi,'');
	//**一太郎HRタグCOLOR属性の削除////////////////////////////////////////////////////////////////////////
	html = html.replace( /<(hr[^>]*) color="?[^\s]*"?([^>]*>)/gi, '<$1$2' ) ;
	
	//アンカーだけのタグの置換え
	html = html.replace(/<a\s(id|name)=\"?[^\"]*\"?>([\s\S]*?)<\/a>/gi,'$2');

	html = html.replace(/<o:p>\s*<\/o:p>/g, '') ;
	html = html.replace(/<o:p>.*?<\/o:p>/g, '&nbsp;') ;
	// <rt>..</rt>, <rp>..</rp>を削除（まず閉じタグの後ろに改行を入れる）
	html = html.replace(/<\/(rt|rp)>/gi, '<\/$1>\n');
	html = html.replace(/(<rt>.*<\/rt>|<rp>.*<\/rp>)\n/gi, '');
	//colgroupタグ,colタグ,rubyタグ,rbタグ,コロンが入るタグの削除
	html = html.replace(/<\/?(colgroup|col|ruby|rb|\??\w+:)[^>]*>/gi, '');
	
	html = html.replace(/<span.*?>/gi, '');
	html = html.replace(/<\/span>/gi, '');
	
	// Remove mso-xxx styles.
	html = html.replace( /\s*mso-[^:]+:[^;"]+;?/gi, '' ) ;

	// Remove margin styles.
	html = html.replace( /\s*margin: 0cm 0cm 0pt\s*;/gi, '' ) ;
	html = html.replace( /\s*margin: 0cm 0cm 0pt\s*"/gi, '"' ) ;

	html = html.replace( /\s*text-indent: 0cm\s*;/gi, '' ) ;
	html = html.replace( /\s*text-indent: 0cm\s*"/gi, '"' ) ;

	html = html.replace( /\s*text-align: [^\s;]+;?"/gi, '"' ) ;

	html = html.replace( /\s*page-break-before: [^\s;]+;?"/gi, '"' ) ;

	html = html.replace( /\s*font-variant: [^\s;]+;?"/gi, '"' ) ;

	html = html.replace( /\s*tab-stops:[^;"]*;?/gi, "" ) ;
	html = html.replace( /\s*tab-stops:[^"]*/gi, "" ) ;

	// Remove FONT face attributes.
	html = html.replace( /(<font[^>]*)\s*face=("[^"]*"|[^ >]*)/gi, '$1' ) ;

	html = html.replace( /\s*font-family:[^;"]*;?/gi, '' ) ;	

	// Remove FONT face attributes.
	html = html.replace( /(<font[^>]*)\s*face=("[^"]*"|[^ >]*)/gi, '$1' ) ;

	html = html.replace( /\s*font-family:[^;"]*;?/gi, '' ) ;

	// Remove Class attributes
	html = html.replace(/class="?msonormal"?/gi,'');
	html = html.replace(/class="?xl[0-9]+"?/gi,'');

	// Remove styles.
	html = html.replace( /<(\w[^>]*) style="([^\"]*)"([^>]*)/gi, '<$1$3' ) ;
	
	html = html.replace( /<span\s*[^>]*>\s*&nbsp;\s*<\/span>/gi, '&nbsp;' ) ;
	html = html.replace( /<span\s*[^>]*><\/span>/gi, '' ) ;

	// Remove id attributes
	html = html.replace( /<(\w[^>]*) id=([^ |>]*)([^>]*)/gi, '<$1$3' ) ;
	// Remove accesskey attributes(for mobile)
	html = html.replace( /<(\w[^>]*) accesskey=([^ |>]*)([^>]*)/gi, '<$1$3' ) ;

	// remove lang attributes
	html = html.replace( /<(\w[^>]*) lang=([^ |>]*)([^>]*)/gi, '<$1$3' ) ;
	
	html = html.replace( /<span\s*[^>]*>(.*?)<\/span>/gi, '$1' ) ;
	html = html.replace( /<span\s*[^>]*>(.*?)<\/span>/gi, '$1' ) ;
	html = html.replace( /<span\s*[^>]*>(.*?)<\/span>/gi, '$1' ) ;
	
	//html = html.replace( /<font\s*>(.*?)<\/font>/gi, '$1' ) ;
	html = html.replace( /<font[^>]*>(.*?)<\/font>/gi, '$1' ) ;

	// Remove XML elements and declarations
	html = html.replace(/<\\?\?xml[^>]*>/gi, '') ;
	
	// Remove Tags with XML namespace declarations: <o:p><\/o:p>
	html = html.replace(/<\/?\w+:[^>]*>/gi, '') ;
	
	//テーブルの置換
	html = html.replace( /(<(table)[^>]*) height=[^ >]+/gi, '$1');
	html = html.replace( /(<(table)[^>]*) border=[^ >]+/gi, '$1 border=1');
	html = html.replace( /(<(table)[^>]*) rules=[^ >]+/gi, '$1');
	html = html.replace( /(<(table)[^>]*) frame=[^ >]+/gi, '$1');
	html = html.replace( /(<(tr)[^>]*) width=[^ >]+/gi, '$1');
	html = html.replace( /(<(tr)[^>]*) height=[^ >]+/gi, '$1');
	
	//コロンが入る属性の削除
	html = html.replace(/(<\w+[^>]*)(\s+\w+:\w+)(=("[^"]*"|[^ >]*))?/gi, '$1');
	
	html = html.replace( /<h\d>\s*<\/h\d>/gi, '' ) ;

	html = html.replace(/<\/?frameset[^>]*>/gi,'');
	html = html.replace(/<\/?frame[^>]*>/gi,'');
	html = html.replace(/<\/?noframes[^>]*>/gi,'');
	html = html.replace(/<\/?iframe[^>]*>/gi,'');
	
	html = html.replace( /<(u|i|strike|s|b)>&nbsp;<\/\1>/g, '&nbsp;' ) ;
	
	html = html.replace(/<\/?font[^>]*>/gi,'');
	
	html = html.replace(/<\/?u>/gi,'');
	
	html = html.replace(/<i(\s[^>]*)?>/gi,'<em$1>');
	html = html.replace(/<\/i>/gi,'</em>');
	html = html.replace(/<b(\s[^>]*)?>/gi,'<strong$1>');
	html = html.replace(/<\/b>/gi,'</strong>');
	
	html = html.replace(/<strike([^>]*>)/gi,'<del$1');
	html = html.replace(/<\/strike>/gi,'</del>');
	html = html.replace(/<s([^trong|>]*>)/gi,'<del$1');
	html = html.replace(/<\/s>/gi,'</del>');
	
	html = html.replace( /<(em|strong|del)>&nbsp;<\/\1>/g, '&nbsp;' ) ;

	// Remove empty tags (three times, just to be sure).
	html = html.replace( /<([^td>]+)(\s+[^>]*>|>)\s*<\/\1>/gi, '' ) ;
	html = html.replace( /<([^td>]+)(\s+[^>]*>|>)\s*<\/\1>/gi, '' ) ;
	html = html.replace( /<([^td>]+)(\s+[^>]*>|>)\s*<\/\1>/gi, '' ) ;
	// IE11対応
	if (!this.caret.pasteHTML) {
		return true;
	}
	this.caret.pasteHTML(html);

	// Wordの箇条書き対応
	while(getListFirstNode()) {
		var A = getListFirstNode();
		if(!A) break;
		var B = getListNodes(A);
		createList(B);
	}
	
	// クリップボードへ値を戻す
//	clipboardData.setData('Text',html);
	
//	this.caret.pasteHTML(html); 
//	$('editor').innerHTML += html;
	return false;
	//
};
// ドラッグ&ドロップ操作／ドロップ
Editor.prototype.textDrop = function() {
	// ドロップ操作を禁止
	return false;
};
Editor.prototype.MoveToAncestorNode=function(A){
	var B;
	// IE11対応
	var T = document.getSelection().type;
	if(!this.elem) return;
	if(A==this.elem.tagName) {
		B = this.elem;
	}else if (T=="Control"){
		var C=document.getSelection();
		for (i=0;i<C.length;i++){
			if (C(i).parentNode){
				B=C(i).parentNode;
				break;
			}
		}
	}else if(T=="Text"){
		var C=document.getSelection();
			B=C.parentElement();
	} else {
		B = this.elem;
	}
	while (B&&B.nodeName!=A) B=B.parentNode;
	return B;
};
// IE11対応
var saveSelection = function() {
	sel = document.getSelection();
	// fix lost selection on mouseover toolbar
	if (sel.getRangeAt && sel.rangeCount) {
		return sel.getRangeAt(0);
	} else {
		return false;
	}
};
// IE11対応
var restoreSelection = function(range) {
	if (range) {
		sel = document.getSelection();
		sel.removeAllRanges();
		sel.addRange(range);
	}
}
var select_caret_range;
Editor.prototype.exec = function(command, callback) {
	// 
	if(!this.doflg) return;
	// 
	this.document = window.document;
	// 変数
	edit_closet_flg = false;
	var caretText   = "";
	// IE11対応
	this.caret      = document.getSelection();
	select_caret_range = saveSelection() || select_caret_range;
	// 
	if(!this.caret){
		alert('挿入位置、もしくは選択範囲を指定してください。');
		return;
	}
	// IE11対応
	this.caret.text = this.caret.toString();
	if(this.caret.text != '')  caretText = this.caret.toString();
	caretText = String(caretText).replace(/^\s+|\s+$/g, "");
	
	//
	switch(command) {
		case "bold":
		case "italic":
			if(caretText!='') document.execCommand(command);
			break;
		case "InsertUnorderedList":
		case "InsertOrderedList":
			document.execCommand(command);
			break;
		case "link":
			
			//定義済テキストの削除用
			var delRepText = '';
			//配列を作成
			var ADD_FILE_DETAIL_EXP_ARY = getAddFileDetailExp();
			for(i in ADD_FILE_DETAIL_EXP_ARY){
				//定義用テキスト削除用の正規表現作成
				if(acc_flg == 0) delRepText += (delRepText != '' ? '|' : '') + ADD_FILE_DETAIL_EXP_ARY[i]['JP'];		//日本語
				else if(acc_flg == 1) delRepText += (delRepText != '' ? '|' : '') + ADD_FILE_DETAIL_EXP_ARY[i]['EN'];	//外国語
			}
			//変数の宣言
			file_size = "";
			file_ext_str = "";
			file_class = "";
			var arg = new Object();

			//選択しているものが文字列以外の場合はエラー
			if(this.caret.type == 'Control'){
				alert('リンクを挿入することが出来ません。' + "\n" + '選択範囲を指定し直してください。');
				return;
			}
			//親ノードにあるAタグを取得
			var tObj = this.MoveToAncestorNode('A');
			if(caretText == "" && (!tObj || (tObj && tObj.innerHTML == ""))){
				alert('挿入位置、もしくは選択範囲を指定してください。');
				return;
			}
			//すでにリンクが存在する場合
			if(tObj && tObj.tagName=="A") {
				arg["href"]   = tObj.getAttribute("href");
				arg["text"]   = tObj.innerHTML;
				arg["target"] = tObj.getAttribute("target");
				// 別ウィンドウで開くリンク文字列の削除
				// 日本語テンプレートの場合
				if (acc_flg == 0) {
					arg['text'] = arg['text'].replace(new RegExp(reg_replace(OTHER_WINDOW_STR_JP) + '$', 'ig'), '');
				}
				// 外国語テンプレートの場合
				else if (acc_flg == 1) {
					arg['text'] = arg['text'].replace(new RegExp(reg_replace(OTHER_WINDOW_STR_EN) + '$', 'ig'), '');
				}
				//外部リンク文字列の削除
				if(OUT_SITE_FLG == true){
					if(acc_flg == 0) arg["text"] = arg["text"].replace(new RegExp(reg_replace(OUT_SITE_STR_JP) + '$','ig'),'');		//日本語
					else if(acc_flg == 1) arg["text"] = arg["text"].replace(new RegExp(reg_replace(OUT_SITE_STR_EN) + '$','ig'),'');	//外国語
				}
				setLink(arg, function(val) {
					if(val){
						//元のリンクに外部サイト以外のリンクが指定されており、現在外部リンク以外のリンクが指定されている場合
						if(!(tObj.getAttribute("href").match(/^(https?:)?\/\//ig) && val["href"].match(/^(https?:)?\/\//ig))){
							//定義済みテキストの削除
							val["text"] = val["text"].replace(new RegExp('(（|\\\()(' + delRepText + ')((：|:)[0-9,]+KB)?(）|\\\))$','gi'),'');
							//ファイルサイズ
							if(tmpAry[4]) file_size = tmpAry[4];
							//ファイル種別の指定
							if(ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]){
								if(acc_flg == 0) file_ext_str = '（' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['JP'];
								else if(acc_flg == 1) file_ext_str = '(' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['EN'];
								//クラスの指定
								if(ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['CLASS'] != "") file_class = ' class="' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['CLASS'] + '"'
								//ファイルサイズの指定
								if(file_size) file_ext_str += (acc_flg == 0 ? "：" : ":") + numEdit(Math.ceil(file_size / 1024)) + "KB";
								file_ext_str += (acc_flg == 0 ? "）" : ")");
							}
						}
						//外部リンクの場合
						if(OUT_SITE_FLG == true && val["href"].match(/^(https?:)?\/\//ig)){
							//サイト内定義リストのチェック
							var out_site_domain_ary = OUT_SITE_DOMAIN.split(',');
							var out_site_flg = true;
							for(var i = 0;i < out_site_domain_ary.length;i++){
								if(val["href"].match(new RegExp('^' + out_site_domain_ary[i],'ig'))){
									out_site_flg = false;
									break;
								}
							}
							//サイト内定義リストに無かった場合
							if(out_site_flg){
								if(acc_flg == 0) file_ext_str += OUT_SITE_STR_JP;			//日本語
								else if(acc_flg == 1) file_ext_str += OUT_SITE_STR_EN;			//外国語
							}
						}
						tObj.href = val['href'];
						tObj.innerHTML = val['text'] + file_ext_str;
						tObj.target = val['target'];
						// target属性値に「_blank」（別ウィンドウ）設定が指定されている場合
						if (val['target'] == '_blank') {
							if (acc_flg == 0) {
								tObj.innerHTML += OTHER_WINDOW_STR_JP;
							}
							else if (acc_flg == 1) {
								tObj.innerHTML += OTHER_WINDOW_STR_EN;
							}
						}
					}
					if (callback) {
						callback();
					}
				});
			}
			//まだリンクが存在しない場合
			else{
				this.saveEditor();
				arg["text"] = caretText;
				// 別ウィンドウで開くリンク文字列の削除
				// 日本語テンプレートの場合
				if (acc_flg == 0) {
					arg['text'] = arg['text'].replace(new RegExp(reg_replace(OTHER_WINDOW_STR_JP) + '$', 'ig'), '');
				}
				// 外国語テンプレートの場合
				else if (acc_flg == 1) {
					arg['text'] = arg['text'].replace(new RegExp(reg_replace(OTHER_WINDOW_STR_EN) + '$', 'ig'), '');
				}
				//外部リンク文字列の削除
				if(OUT_SITE_FLG == true){
					if(acc_flg == 0) arg["text"] = arg["text"].replace(new RegExp(reg_replace(OUT_SITE_STR_JP) + '$','ig'),'');		//日本語
					else if(acc_flg == 1) arg["text"] = arg["text"].replace(new RegExp(reg_replace(OUT_SITE_STR_EN) + '$','ig'),'');	//外国語
				}
				arg["text"] = arg["text"].replace(new RegExp('(（|\\\()(' + delRepText + ')((：|:)[0-9,]+KB)?(）|\\\))$','gi'),'');
				var editor = this;
				setLink(arg, function(val) {
					if(val){
						//ファイルサイズ
						if(tmpAry[4]) file_size = tmpAry[4];
						//ファイル種別の指定
						if(ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]){
							if(acc_flg == 0) file_ext_str = '（' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['JP'];
							else if(acc_flg == 1) file_ext_str = '(' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['EN'];
							//クラスの指定
							if(ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['CLASS'] != "") file_class = ' class="' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['CLASS'] + '"'
							//ファイルサイズの指定
							if(file_size) file_ext_str += (acc_flg == 0 ? "：" : ":") + numEdit(Math.ceil(file_size / 1024)) + "KB";
							file_ext_str += (acc_flg == 0 ? "）" : ")");
						}
						//外部リンクの場合
						if(OUT_SITE_FLG == true && val["href"].match(/^(https?:)?\/\//ig)){
							//サイト内定義リストのチェック
							var out_site_domain_ary = OUT_SITE_DOMAIN.split(',');
							var out_site_flg = true;
							for(var i = 0;i < out_site_domain_ary.length;i++){
								if(val["href"].match(new RegExp('^' + out_site_domain_ary[i],'ig'))){
									out_site_flg = false;
									break;
								}
							}
							//サイト内定義リストに無かった場合
							if(out_site_flg){
								if(acc_flg == 0) file_ext_str += OUT_SITE_STR_JP;			//日本語
								else if(acc_flg == 1) file_ext_str += OUT_SITE_STR_EN;			//外国語
							}
						}
						// IE11 restore selection
						if (select_caret_range) {
							restoreSelection(select_caret_range);
						}
						editor.document.execCommand("unlink");
						editor.document.execCommand("createlink",false,'#custom_editor_dummy_link');
						var anchor_ary = editor.obj.getElementsByTagName('A');
						for(i = 0;i < anchor_ary.length;i++){
							if(anchor_ary[i].getAttribute('href') == '#custom_editor_dummy_link'){
								anchor_ary[i].href = val['href'];
								anchor_ary[i].innerHTML = val['text'] + file_ext_str;
								if(val['target'] != "" && val['target'] != '_self') anchor_ary[i].target = val['target'];
								// target属性値に「_blank」（別ウィンドウ）設定が指定されている場合
								if (val['target'] == '_blank') {
									if (acc_flg == 0) {
										anchor_ary[i].innerHTML += OTHER_WINDOW_STR_JP;
									}
									else if (acc_flg == 1) {
										anchor_ary[i].innerHTML += OTHER_WINDOW_STR_EN;
									}
								}
							}
						}
	/*
						var anchor = document.createElement('A');
						anchor.id = getRand(20);
						anchor.href = val['href'];
						anchor.innerHTML = val['text'] + file_ext_str;
						if(val['target'] != "" && val['target'] != '_self') anchor.target = val['target'];
						if(editor.caret) editor.caret.pasteHTML(anchor.outerHTML);
						var anchor_ary = editor.obj.getElementsByTagName('A');
						for(i = 0;i < anchor_ary.length;i++){
							if(anchor_ary[i].id == anchor.id){
								anchor_ary[i].href = val['href'];
								anchor_ary[i].removeAttribute('id');
								break;
							}
						}
	*/
						//選択しているオブジェクトのタイプがコントロール以外の場合
						// if(document.getSelection().type != 'Control'){
						//	editor.caret.move("character",-1);
						//	editor.caret.select();
						// }
					}
					if (callback) {
						callback();
					}
				});
			}
			break;
		case "unlink":
			var aObj = this.MoveToAncestorNode('A');
			if(aObj && aObj.tagName=="A") {
				var txt = aObj.innerHTML;
				aObj.outerHTML = txt;
			}
			break;
		case "p":
			// 枠を設定する文字の指定がない
			if(this.caret.text == "") {
				alert("見出しを解除する文字が選択されていません");
				break;
			}
			// 選択が不明
			if (this.caret.text == undefined ) {
				alert("選択範囲が正しくないため、見出しを解除することはできません");
				break;
			}
			try {
				document.execCommand("formatblock", false, '<'+command+'>');
			} catch(e) {
				 alert("現在の選択位置の見出しを解除することはできません");
			}
			break;
		case "h2":
		case "h3":
		case "h4":
		case "h5":
		case "h6":
			// class( subheading ) を定義するタグ
			var classTagAry  = new Array("H2","H3","H4","H5","H6");
			// 見出しを設定できない要素
			var nonSetTagAry = NOT_SET_H_TAG_NODE;
			// 枠を設定する文字の指定がない
			if(this.caret.text == "") {
				alert("見出しを設定する文字が選択されていません");
				break;
			}
			// 選択が不明
			if (this.caret.text == undefined ) {
				alert("選択範囲が正しくないため、見出しを設定することはできません");
				break;
			}
			// 見出しを設定できない領域を選択している場合
			if (! cxCheckMustUpstairsTag( this.elem, this.p_elem ) ) {
				alert("現在の選択位置には見出しを設定することはできません");
				break;
			}
			// 選択しているHTMLテキスト内に設定できないタグが含まれているかチェック
			if (! cxCheckCaretNonUseTag( this.caret, nonSetTagAry ) ) {
				alert("選択範囲に見出しを設定できないタグを含んでいるため、見出しを設定することはできません");
				break;
			}
			try {
				document.execCommand("formatblock", false, '<'+command+'>');
			} catch(e) {
				 alert("現在の選択位置には見出しを設定することはできません");
			}
			// クラスを追加
			var chElement = this.elem.childNodes;
			for ( var i = 0 ; i < chElement.length ; i ++ ) {
				if ( in_array( chElement[i].tagName, classTagAry ) ) {
					chElement[i].className = "subheading";
				}
			}
			// 
			break;
		case "intro":
		case "atention":
			if (! this.elem || ! this.p_elem ) {
				alert("枠を設定する位置を指定してください");
				break;
			}
			// 枠を設定できない要素
			var nonSetTagAry = NOT_SET_FRAME_NODE;
			// 最上階層のみ
			if ( ! cxCheckMustUpstairsTag( this.elem, this.p_elem ) ) {
				alert("現在の選択位置には枠を設定することはできません");
				break;
			}
			var html = '<div class="'+command+'_txt"><p>&nbsp;</p></div>';
			
			try {
				if ( this.elem.tagName ==  'DIV' && this.elem.className == 'editor' ) {
					this.elem.innerHTML += html;
				} else {
					this.elem.outerHTML += html;
				}
			} catch(e) {
				 alert("現在の選択位置には枠を設定することはできません");
			}
			// 
			break;
		// 枠解除
		case "del_div":
			if (! this.elem || ! this.p_elem ) {
				alert("枠を解除する位置を指定してください");
				break;
			}
			// 自身が【 DIV 】であれば自身、違う場合は親タグ
			var divElem = ( this.elem.tagName == 'DIV' ? this.elem : this.p_elem );
			// DIVになるまで確認
			while ( divElem.tagName != 'DIV' ) { divElem = divElem.parentNode; }
			// DIVのクラスがカスタムエディタの場合は解除できない
			if (divElem.className == "" || divElem.className == "editor" ) {
				 alert("枠が選択されていません");
				 break;
			}
			// 枠の解除
			try {
				divElem.outerHTML = divElem.innerHTML;
			} catch(e) {
				 alert("枠を解除できません");
			}
			break;
			
		// *****************テーブル関係***************** //
		// 要項
		case "outline":
			if (! this.elem || ! this.p_elem ) {
				alert("要項を設定する位置を指定してください");
				break;
			}
			// 最上階層のみ
			if ( ! cxCheckMustUpstairsTag( this.elem, this.p_elem ) ) {
				 alert("現在の選択位置には要項を作成できません");
				 return false;
			}
			var html = '<table width="80%" border=1 class="outline_txt"><tr><th width="200" align="left" valign="top">&nbsp;</th><td valign="top">&nbsp;</td></tr><!-- outline end --></table>';
			
			try {
				this.elem.innerHTML += html;
			} catch(e) {
				 alert("現在の選択位置には要項を作成できません");
			}
			break;
		
		// テーブル作成
		case "table":
			if (! this.elem || ! this.p_elem ) {
				alert("テーブルを設定する位置を指定してください");
				break;
			}
			if( in_array(this.elem.tagName, NOT_SET_TABLE_TAG_NODE ) ) {
				 alert("現在の選択位置にはテーブルを作成できません");
				 return false;
			}
			var html = '<table border=1><tr><td><p>&nbsp;</p></td><td><p>&nbsp;</p></td></tr><tr><td><p>&nbsp;</p></td><td><p>&nbsp;</p></td></tr></table>';
			try {
				this.elem.innerHTML += html;
			} catch(e) {
				alert("現在の選択位置にはテーブルを作成できません");
				return false;
			}
			break;
	/* テーブル：見出し追加 */
		case "ins_table_th":
			// THタグ
			var new_elem = document.createElement("th");
			new_elem.innerHTML = this.thtdObj.innerHTML;
			// タグの置換
			this.trObj.replaceChild(new_elem, this.thtdObj );
			// 
			break;
	/* テーブル：見出し解除 */
		case "del_table_th":
			// TDタグ
			var new_elem = document.createElement("td");
			new_elem.innerHTML = this.thtdObj.innerHTML;
			// タグの置換
			this.trObj.replaceChild(new_elem, this.thtdObj );
			// 
			break;
	/* テーブル：列の追加 */
		case "ins_table_td":
			var td_pos     = 0;
			var p_tbodyObj = this.tbodyObj;
			var p_trObj    = this.trObj;
			var check_elem = this.thtdObj;
			while(1){
				check_elem = check_elem.previousSibling;
				if(check_elem == null) break;
				td_pos += 1;
			}
			var trObjNodes = p_tbodyObj.childNodes;
			for(i=0; i<trObjNodes.length; i++){
				var new_td_elem = document.createElement("TD");
				new_td_elem.innerHTML = "&nbsp;";
				trObjNodes(i).insertBefore(new_td_elem, trObjNodes(i).childNodes.item(td_pos).nextSibling);
			}
			break;
	/* テーブル：列の削除 */
		case "del_table_td":
			var td_pos     = 0;
			var p_tbodyObj = this.tbodyObj;
			var p_trObj    = this.trObj;
			var check_elem = this.thtdObj;
			while(1){
				check_elem = check_elem.previousSibling;
				if(check_elem == null) break;
				td_pos += 1;
			}
			var trObjNodes = p_tbodyObj.childNodes;
			for(i=0; i<trObjNodes.length; i++){
				trObjNodes(i).removeChild(trObjNodes(i).childNodes.item(td_pos));
			}
			if ( this.trObj.childNodes.length <= 0 ) {
				this.tableObj.parentNode.removeChild(this.tableObj);
			}
			
			break;
	/* テーブル：行の追加 */
		case "ins_table_tr":
			// 
			var td_num     = 0;
			var p_tableObj = this.tableObj;
			var p_tbodyObj = this.tbodyObj;
			var p_trObj    = this.trObj;
			// 
			var new_tr_elem = document.createElement("TR"); 
			var trObjNodes = p_tbodyObj.childNodes;
			
			for(i=0; i<trObjNodes.length; i++){
				if(td_num < trObjNodes(i).childNodes.length){
					td_num = trObjNodes(i).childNodes.length;
				}
			}
			for(i=0; i<td_num; i++){
				if(i == 0 && p_tableObj.className == "outline_txt"){
					//<th width="200" align="left" valign="top">
					var new_td_elem = document.createElement("th"); 
					new_td_elem.setAttribute("width","200");
					new_td_elem.setAttribute("align","left");
					new_td_elem.setAttribute("valign","top");
				} else {
					var new_td_elem = document.createElement("td"); 
				}
				new_td_elem.innerHTML = "&nbsp;";
				new_tr_elem.insertBefore(new_td_elem);
			}
			
			p_tbodyObj.insertBefore(new_tr_elem, p_trObj.nextSibling);
			break;
	/* テーブル：行の削除 */
		case "del_table_tr":
			// 
			this.tbodyObj.removeChild(this.trObj);
			
			if ( this.tbodyObj.childNodes.length <= 0 ) {
				this.tableObj.parentNode.removeChild(this.tableObj);
			}
			
			break;
	/* テーブル：枠を太くする */
		case "inc_table_border":
			// 
			var target_elem = this.tableObj;
			var border      = Number(target_elem.getAttribute("border"));
			// 
			target_elem.setAttribute("border",border+1);
			break;
	/* テーブル：枠を細くする */
		case "dec_table_border":
			// 
			var target_elem = this.tableObj;
			var border      = Number(target_elem.getAttribute("border"));
			// 
			if(border == 0) break;
			// 
			target_elem.setAttribute("border",border-1);
			break;
		default:
			alert('定義されていないコマンドが呼ばれました。');
			break;
	}
	
	//if(this.type=='Text') this.caret.select();
};
//
var tempUrl = 'javascript:void(0)';
function selectDummyANode() {
	document.execCommand('unlink');
	document.execCommand('createLink',false,tempUrl);
	var tempLinks = document.links;
	for(var i=0;i<tempLinks.length;i++) {
		if(tempLinks[i]==tempUrl) {
			return tempLinks[i];
		}
	}
}
//
function setLink(arg, callback) {
	arg['windowObj'] = this;
	cxIframeLayer(
		cms8341admin_path + "/page/common/editor/dialog/link.php",
		458,
		459,
		COVER_SETTING.COLOR,
		'',
		function (obj) {
			if(!obj) return false;
			var val = {"href" : "","text" : arg["text"],"target" : ""};
			if(obj['ret']){
				tmpAry = obj['ret'].split(KANKO_LINK_DELIMITER);
				tmpAry[1] = tmpAry[1].replace("＃","#");
				val['href'] = tmpAry[0];
				// val['text'] = tmpAry[1];
				val['target'] = tmpAry[2];
			}
			
			if (callback) {
				callback(val);
			}
		},
		false,
		false,
		arg
	);
}

function getRand(n,b){
	var val = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789' + (b || '');
	var ret = '';

	val = val.split('');
	for(var i = 0;i < n;i++){
		ret += val[Math.floor(Math.random() * val.length)];
	}
	return ret;
};

// Wordの箇条書き対応
//** リスト化対象ノードの最初のノードを返す
function getListFirstNode() {
	var A = document.getElementsByTagName('P');
	for(var i=0;i<A.length;i++) {
		if(A[i]._gdlist && A[i]._gdlist!="") {
			return A[i];
		}
	}
	return false;
}

//** リスト化するノードを返す
function getListNodes(obj) {
	var A = new Array();
	A.push(obj);
	while(obj) {
		obj = obj.nextSibling;
		if(!obj) break;
		if(obj.tagName=='P' && obj._gdlist) {
			A.push(obj);
		} else {
			break;
		}
	}
	return A;
}

//** リストノードの作成と挿入
function createList(obj) {
	var UL = document.createElement('ul');
	var A  = obj[0].parentNode;
	A.insertBefore(UL,obj[0]);
	var B = new Object();
	var C;
	B[obj[0]._gdlist] = UL;
	for(var i=0;i<obj.length;i++) {
		var LI = document.createElement('li');
		LI.innerHTML = requireText(obj[i].innerHTML);
		if(B[obj[i]._gdlist]) {
			B[obj[i]._gdlist].appendChild(LI);
		} else {
			B[obj[i]._gdlist] = C;
			var ul = document.createElement('ul');
			ul.appendChild(LI);
			C.appendChild(ul);
		}
		C = LI;
		obj[i].outerHTML = "";
	}
}

//** 不要テキスト・スペースの削除
function requireText(text) {
	var A = text.replace(/^(l|O|2|n|u|¨|u|・|○|●|□|■|◇|◆|△|▲|▽|▼|☆|★|◎)(&nbsp;|\s)+/gi,'');
	    A = A.replace(/^([①-⑳])(&nbsp;|\s)+/gi,
												function($0,$1,$2){
														var R = "";
														switch($1) {
																case "①":
																	R = 1;
																	break;
																case "②":
																	R = 2;
																	break;
																case "③":
																	R = 3;
																	break;
																case "④":
																	R = 4;
																	break;
																case "⑤":
																	R = 5;
																	break;
																case "⑥":
																	R = 6;
																	break;
																case "⑦":
																	R = 7;
																	break;
																case "⑧":
																	R = 8;
																	break;
																case "⑨":
																	R = 9;
																	break;
																case "⑩":
																	R = 10;
																	break;
																case "⑪":
																	R = 11;
																	break;
																case "⑫":
																	R = 12;
																	break;
																case "⑬":
																	R = 13;
																	break;
																case "⑭":
																	R = 14;
																	break;
																case "⑮":
																	R = 15;
																	break;
																case "⑯":
																	R = 16;
																	break;
																case "⑰":
																	R = 17;
																	break;
																case "⑱":
																	R = 18;
																	break;
																case "⑲":
																	R = 19;
																	break;
																case "⑳":
																	R = 20;
																	break;
														}
														return R;
												 });
	A = A.replace(/(\d+)(.|．)?(&nbsp;|\s)+/gi,
								function($0,$1,$2,$3) {
									var R = "";
									if($1) R += $1;
									if($2) R += $2;
									return R;
								}
			);
	return A;
}

//画像変更処理
function cxImageChange(t,p) {
	t.src = p;
}

// カーソルが選択している位置がカスタムエディタ内の最上位であるかチェック

function cxCheckMustUpstairsTag( myE, prE ) {
	
	//【DIV】タグの class が【editor】であれば最上位階層であるとする
	
	if ( myE.tagName == "DIV" ) {
		if ( myE.className && myE.className != "editor" ) return false;
	}
	else {
		// カスタマイズエディタで指定できるインラン要素
		var inlineElement = INLINE_NODES;
		// インライン要素でなくなるまで親タグをチェック
		while ( in_array(prE.tagName, inlineElement ) ) {
			prE = prE.parentNode;
		}
		// 
		if (prE.tagName != "DIV" ) return false;
		if (prE.className != "editor" ) return false;
	}
	// 
	return true;
}

// 選択範囲に使用できないタグが含まれているかチェック

function cxCheckCaretNonUseTag( caret, nonSetTagAry ) {
	
	if ( nonSetTagAry == undefined || ! nonSetTagAry ) return true;
	
	if (caret.htmlText != undefined && caret.htmlText != "" ) {
		var regPtn;
		var regErr = false;
		for (var i = 0 ; i < nonSetTagAry.length ; i ++ ) {
			
			regPtn = new RegExp("<(\s+)?"+nonSetTagAry[ i ]+"([^>]+)?>", "i" );
			
			if ( caret.htmlText.match(regPtn ) ) {
				regErr = true;
				break;
			}
		}
		if (regErr ) return false;
	}
	return true;
}