<?php
/*
 * アクセシビリティ変換（別ウィンドウ）
 */
require ("../.htsetting");
// ** global 宣言 ---------------------------
global $objCnc;

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

// エラー出力を別ウィンドウ用に設定
gd_errorhandler_ini_set("template_user_error", "template_user_error_win");
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");

$post = $_POST;

$template_id = '';
$objPage->setTableName(PUBLISH_TABLE);
$objPage->selectFromID($post['cms_page_id']);
$template_id = $objPage->fld['template_id'];

// 2008/10/8追加　アクセシビリティ設定取得
$objDac->setTableName("tbl_template");
$where = $objDac->_addslashesC('template_id', $template_id);
$objDac->select($where);
$acc_flg = '';
while ($objDac->fetch()) {
	$acc_flg = $objDac->fld['acc_flg'];
}

// アクセシビリティチェッククラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/acc_check2.inc');
$objAChk = new acc_check($objCnc, $acc_flg);

// 公開リスト、閲覧モードのときはcms_dispMode=1
// ワークスペース、ワークフローからのときはcms_dispMode=2
// 編集モードのときはcms_dispMode=3


// プレビュー情報をセットする
include (APPLICATION_ROOT . "/common/inc/set_preview.inc");
// テンプレートに差し替えるための情報を配列$aryValuesに格納


/****************/

$sess_acc = $post;
$sess_acc['cms_context'] = $aryValues['cx_context'];
// 編集モード⇒アクセシビリティ変換あり
if ($post['cms_dispMode'] == 3) {
	// JS,CSS
	$head_scripts = '<link rel="stylesheet" href="/admin/style/shared.css" type="text/css">' . "\n";
	$head_scripts .= '<link rel="stylesheet" href="/admin/style/accessibility.css" type="text/css">' . "\n";
	$head_scripts .= '<script src="/admin/js/library/prototype.js" type="text/javascript"></script>' . "\n";
	$head_scripts .= '<script src="/admin/js/shared.js" type="text/javascript"></script>' . "\n";
	$head_scripts .= '<script src="/admin/js/accessibirity.js" type="text/javascript"></script>' . "\n";
	$head_scripts .= '<script type="text/javascript">' . "\n";
	$head_scripts .= '<!--' . "\n";
	$head_scripts .= loadSettingVars() . "\n";
	$head_scripts .= '//-->' . "\n";
	$head_scripts .= '</script>' . "\n";
	
	// FCKeditor領域のチェック、表示情報のセット
	$aryValues['cx_context'] = $objAChk->checkContext($aryValues['cx_context']);
	// FCKeditor領域の変換用HTML
	$sess_acc['rep_context'] = $objAChk->strReplaceHTML;
	// FCKeditor領域のプレビューモードのパラメータを削除
	$sess_acc['rep_context'] = str_replace("?mode=" . MODE_PREVIEW, "", $sess_acc['rep_context']);
	
	// 問い合わせ先メモ領域のチェック、表示情報のセット
	$pv_fld['inquiry_memo'] = ($pv_fld['inquiry_memo'] == '') ? '' : htmlspecialchars($pv_fld['inquiry_memo']);
	$pv_fld['inquiry_memo'] = $objAChk->checkContext($pv_fld['inquiry_memo']);
	// 問い合わせ先メモ領域の変換用HTML
	if (isset($post['cms_inquiry_prop_memo'])) $sess_acc['rep_inquiry_memo'] = $post['cms_inquiry_prop_memo'];
	
	// アクセシビリティ変換のための情報をセッションに格納
	$_SESSION['acc'] = $sess_acc;
	
        	// アクセシビリティチェック必須化
	// アクセシビリティチェック実行済とする。
	$_SESSION['accessibility_check_flg']['accessibility_flg'] = FLAG_ON;
}
// 閲覧モード、リスト⇒アクセシビリティ変換なし
else {
	// JS,CSS
	$head_scripts = '<link rel="stylesheet" href="/admin/style/shared.css" type="text/css">' . "\n";
	$head_scripts .= '<link rel="stylesheet" href="/admin/style/accessibility.css" type="text/css">' . "\n";
	$head_scripts .= '<script src="/admin/js/library/prototype.js" type="text/javascript"></script>' . "\n";
	$head_scripts .= '<script src="/admin/js/shared.js" type="text/javascript"></script>' . "\n";
	$head_scripts .= '<script src="/admin/js/accessibirity.js" type="text/javascript"></script>' . "\n";
	$head_scripts .= '<script type="text/javascript">' . "\n";
	$head_scripts .= '<!--' . "\n";
	$head_scripts .= loadSettingVars() . "\n";
	$head_scripts .= '//-->' . "\n";
	$head_scripts .= '</script>' . "\n";
	
	// FCKeditor領域のチェック、表示情報のセット
	$aryValues['cx_context'] = $objAChk->checkContext($aryValues['cx_context'], 0);
	
	// 問い合わせ先メモ領域のチェック、表示情報のセット
	$pv_fld['inquiry_memo'] = ($pv_fld['inquiry_memo'] == '') ? '' : $pv_fld['inquiry_memo'];
}
/****************/

// 問い合わせのメモにhtmlDisplay()をつけない
$inq_flg = 0;
// イベントを無効化する
$event_flg = 1;

// プレビューを生成する
include (APPLICATION_ROOT . "/common/inc/set_preview_htmlStr.inc");
// $htmlStrに文字列で格納


// ONLOADを消去
$htmlStr = preg_replace('/onload="[^"]*"/i', '', $htmlStr);
$htmlStr = preg_replace('/.*\.onload.*/i', '', $htmlStr);
$htmlStr = preg_replace('/<script.*<\/script>/i', '', $htmlStr);
$p = 0;
while (getMidString($htmlStr, "<script", "</script>", $p) !== FALSE) {
	$hitStr = getMidString($htmlStr, "<script", "</script>", $p);
	$htmlStr = str_replace("<script" . $hitStr . "</script>", "", $htmlStr);
	$p++;
}

// JS,CSSの読み込みを挿入
$htmlStr = preg_replace('/<\/head>/i', $head_scripts . '</head>', $htmlStr);

// リンク無効化
$htmlStr = preg_replace('/<(a|area)( [^>]*)? href="[^"]*"/i', '<${1}${2} href="#"', $htmlStr);
$htmlStr = preg_replace('/<(a|area)( [^>]*)? target="[^"]*"/i', '<${1}${2} ', $htmlStr);

//ヘッダーメッセージ
$tool_replace = 0;
$message = '<img src="' . RPW . '/admin/images/icon/result_normal.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px">' . 'アクセシビリティエラーはありません。';
if (($objAChk->rep_cnt > 0) || ($objAChk->err_cnt > 0)) {
	if ($post['cms_dispMode'] == 3) {
		$tool_replace = 1;
		$message = '<p style="color:#FF0000;font-weight:bold;margin-bottom:5px">' . "\n";
		$message .= '<img src="' . RPW . '/admin/images/icon/result_error.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px">' . "\n";
		$message .= '対象ページに推奨されない文字などが含まれています。</p>' . "\n";
		$message .= '<p style="margin-top:0">「アクセシビリティ変換」ボタンをクリックすると次の内容で編集ページに変換が実行されます。</p>' . "\n";
		
		$message .= '<table>' . "\n";
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= '（背景色）赤' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>推奨されない文字「(1)半角カナを全角カナへ」、「(2)全角英数字を半角英数字へ」全て変換します。</p>' . "\n";
		$message .= '<p>推奨されない文字「(3)2つ以上連続する半角スペース」を削除します。</p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= '（背景色）薄い赤' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>日時の表記や機種依存文字などの推奨されない表記や文字に対して、</p>' . "\n";
		$message .= '<p>チェックされた箇所を推奨される代替文字へ自動変換します。</p>' . "\n";
		$message .= '<p>&nbsp;<input type="button" value="全てのチェックを外す" onClick="return cxReleaseAll();">' . "\n";
		$message .= '&nbsp;<input type="button" value="全てチェックする" onClick="return cxCheckAll();"></p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= '（背景色）黄' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>自動変換等は行わないアクセシビリティ違反を表す場合に表示されます。</p>' . "\n";
		$message .= '<p>警告内容をご確認ください。</p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= '黄枠' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>画像代替テキストやテーブル構造に対して何らかのアクセシビリティ違反が見つかった場合、</p>' . "\n";
		$message .= '<p>対象の画像やテーブルが黄枠で囲まれます。</p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= '緑枠' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>画像代替テキストやテーブル構造情報等を表示する場合、</p>' . "\n";
		$message .= '<p>対象の画像やテーブルが緑枠で囲まれます。</p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= 'エラー情報表示' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>何らかのアクセシビリティ違反が見つかった場合、その箇所にマウスカーソルを</p>' . "\n";
		$message .= '<p>合わせるとチェック結果の詳細情報がポップアップ表示されます。</p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= '音声読み上げ順表示' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>レイアウトテーブル下部に表示されている「音声読み上げ順」ボタンをクリックすると、</p>' . "\n";
		$message .= '<p>対象のテーブルに音声読み上げ順が追記された情報が別ウィンドウで表示されます。</p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '</table>' . "\n";
	}
	else {
		$message = '<p style="color:#FF0000;font-weight:bold">' . "\n";
		$message .= '<img src="' . RPW . '/admin/images/icon/result_error.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px">' . "\n";
		$message .= '対象ページに推奨されない文字などが含まれています。</p>' . "\n";
		
		$message .= '<table>' . "\n";
		
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= '（背景色）赤' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>アクセシブルではない「(1)半角カナを全角カナへ」、「(2)全角英数字を半角英数字へ」、「(3)2つ以上連続する半角スペースを削除」です。</p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= '（背景色）薄い赤' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>日時の表記や機種依存文字など推奨されない表記や文字です。</p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= '（背景色）黄' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>自動変換等は行わないアクセシビリティ違反に該当する文言です。</p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= '黄枠' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>画像代替テキストやテーブル構造等に何らかのアクセシビリティ違反が存在します。</p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= '緑枠' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>画像代替テキストやテーブル構造情報等を表示します。</p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= 'エラー情報表示' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>何らかのアクセシビリティ違反が見つかった場合、その箇所にマウスカーソルを</p>' . "\n";
		$message .= '<p>合わせるとチェック結果の詳細情報がポップアップ表示されます。</p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '<tr>' . "\n";
		$message .= '<th align="left" valign="top" width="150px">' . "\n";
		$message .= '音声読み上げ順表示' . "\n";
		$message .= '</th>' . "\n";
		$message .= '<td>' . "\n";
		$message .= '<p>レイアウトテーブル下部に表示されている「音声読み上げ順」ボタンをクリックすると、</p>' . "\n";
		$message .= '<p>対象のテーブルに音声読み上げ順が追記された情報が別ウィンドウで表示されます。</p>' . "\n";
		$message .= '</td>' . "\n";
		$message .= '</tr>' . "\n";
		
		$message .= '</table>' . "\n";
	}
}

// ツールバーを挿入＆表示領域HTML＋CSS
$params = array(
		'replace' => $tool_replace, 
		'msg' => $message
);
$toolbarStr = "\n" . get_include_contents(APPLICATION_ROOT . "/common/inc/toolbar_acc.inc", $params);
$htmlStr = preg_replace('/(<body[^>]*>)/i', '${1}' . $toolbarStr, $htmlStr);

// フォームを挿入
if ($post['cms_dispMode'] == 3) {
	$form_start = '<form name="cms_fAcc" class="cms8341-form" method="post" action="' . RPW . $post['cms_p_file_path'] . '" target="">' . "\n";
	$form_start .= '<input type="hidden" name="cms_dispMode" value="edit">' . "\n";
	$form_start .= '<input type="hidden" name="cms_accFlg" value="1">' . "\n";
	$form_end = '</form>';
	$htmlStr = preg_replace('/(<body[^>]*>)/i', '${1}' . "\n" . $form_start, $htmlStr);
	$htmlStr = preg_replace('/(<\/body>)/i', $form_end . "\n" . '${1}', $htmlStr);
}

// エラーポップアップ表示用「hidden」値追加
if (isset($objAChk->pop_up_err_hidden) && $objAChk->pop_up_err_hidden != "") {
	$form_start = '<form id="cms_pop_up_err" name="cms_pop_up_err" class="cms8341-form" method="post" action="" target="">' . "\n";
	$form_start .= $objAChk->pop_up_err_hidden;
	$form_end = '</form>';
	$htmlStr = preg_replace('/(<\/body>)/i', $form_start . "\n" . '${1}', $htmlStr);
	$htmlStr = preg_replace('/(<\/body>)/i', $form_end . "\n" . '${1}', $htmlStr);
	
	// 「onMouseover」埋め込み
	$htmlStr = preg_replace("/ _cms_popup_err=\"([0-9]+)\"/i", " onMouseover=\"cxPopUpOpen('" . '${1}' . "')\"", $htmlStr);
}

// 音声読み上げ順表示用「hidden」値追加
if (isset($objAChk->voice_reading_hidden) && $objAChk->voice_reading_hidden != "") {
	$form_start = '<form id="cms_voice_reading" name="cms_voice_reading" class="cms8341-form" method="post" action="" target="">' . "\n";
	$form_start .= $objAChk->voice_reading_hidden;
	
	// JS,CSSの読み込みを挿入
	// HTML文字列の先頭から「</head>」までの文字列を取得
	$head_scripts = substr($htmlStr, 0, strpos($htmlStr, '</head>') + strlen('</head>'));
	
	// 置換用のコメント<!--%xxx%-->を削除
	$head_scripts = preg_replace('/<!--%[^%]+%-->/', '', $head_scripts);
	// 不要な改行を整える
	$head_scripts = preg_replace('/(\r?\n)+/', '\1', $head_scripts);
	
	// 全てルートからのパスにする
	$head_scripts = setRootPath($head_scripts);
	
	$form_start .= '<input type="hidden" name="cms_style_hidden" id="cms_style_hidden" value="' . htmlspecialchars($head_scripts) . '">' . "\r\n";
	
	$form_end = '</form>';
	$htmlStr = preg_replace('/(<\/body>)/i', $form_start . "\n" . '${1}', $htmlStr);
	$htmlStr = preg_replace('/(<\/body>)/i', $form_end . "\n" . '${1}', $htmlStr);
	
	// 音声読み上げ順表示対応
	// 「onMouseover」埋め込み
	$htmlStr = preg_replace("/ _cms_voice_reading_js=\"([^\"]+)\"/i", " onClick=\"cxVoiceReading('" . '${1}' . "')\" onMouseover=\"cxBorderOn('" . '${1}' . "')\"  onMouseout=\"cxBorderOff('" . '${1}' . "')\"", $htmlStr);
}

// 置換用のコメント<!--%xxx%-->を削除
$htmlStr = preg_replace('/<!--%[^%]+%-->/', '', $htmlStr);
// 不要な改行を整える
$htmlStr = preg_replace('/(\r?\n)+/', '\1', $htmlStr);

// 全てルートからのパスにする
$htmlStr = setRootPath($htmlStr);

print $htmlStr;
?>