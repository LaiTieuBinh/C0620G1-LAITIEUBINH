<?php
/*
 * HTMLのクリーンアップ処理
 */
require ("../.htsetting");

$sess_cup = $_POST;

// HTMLソースのクリーンアップ処理
if (isset($sess_cup['cms_context'])) $sess_cup['cms_context'] = htmlCleanUp(del_escapes($sess_cup['cms_context']));

$_SESSION['cup'] = $sess_cup;

// 編集画面に戻る
header("Location: " . HTTP_ROOT . RPW . $sess_cup['cms_p_file_path'] . "?edit=1&cup=1");
?>