<?php
/*
 * プレビュー
 */
require ("../.htsetting");
// 別ウィンドウ用
gd_errorhandler_ini_set("template_user_error", "template_user_error_win");
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");

$post = $_POST;
include (APPLICATION_ROOT . "/common/inc/set_preview.inc");
include (APPLICATION_ROOT . "/common/inc/set_preview_htmlStr.inc");

// コントラストチェックにて基準となる値を取得
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
$contrast_standard = 1;
$objHandler->_select(HANDLER_CLASS_CONTRASTCHECK_STANDARD);
if ($objHandler->fetch()) {
	$contrast_standard = $objHandler->fld['item1'];
}

// ONLOADを消去
$htmlStr = preg_replace('/onload="[^"]*"/i', '', $htmlStr);
$htmlStr = preg_replace('/.*\.onload.*/i', '', $htmlStr);
$htmlStr = preg_replace('/<script.*<\/script>/i', '', $htmlStr);
$p = 0;
while (getMidString($htmlStr, "<script", "</script>", $p) !== FALSE) {
	$hitStr = getMidString($htmlStr, "<script", "</script>", $p);
	$htmlStr = str_replace("<script" . $hitStr . "</script>", "", $htmlStr);
	$p++;
}

// リンク無効化
$htmlStr = preg_replace('/<(a|area)( [^>]*)? href="[^"]*"/i', '<${1}${2} href="#"', $htmlStr);
$htmlStr = preg_replace('/<(a|area)( [^>]*)? target="[^"]*"/i', '<${1}${2} ', $htmlStr);

$htmlStr = setRootPath($htmlStr);

// alt="#" を alt="" に置換
$htmlStr = preg_replace('/<(img|area|input)( [^>]*)? alt="[#＃\s　]*"/i', '<${1}${2} alt=""', $htmlStr);

//コントラストチェック用CSS
$contrast_css = '<link rel="stylesheet" href="' . RPW . '/admin/style/shared.css" type="text/css">' . "\n";
$htmlStr = preg_replace('/<\/head>/i', $contrast_css . '</head>', $htmlStr);
//コントラストチェック用ヘッダー
$contrast_head = '<div id="cms8341-headareaZero" style="margin-bottom:0px !important">' . "\n";
$contrast_head .= '<table width="100%" border="0" cellspacing="0" cellpadding="0">' . "\n";
$contrast_head .= '<tr>' . "\n";
$contrast_head .= '<td align="center" valign="top" bgcolor="#DFDFDF">' . "\n";
$contrast_head .= '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader">' . "\n";
$contrast_head .= '<tr>' . "\n";
$contrast_head .= '<td align="left" valign="middle">' . "\n";
$contrast_head .= '<img src="' . RPW . '/admin/images/contrast/title_contrastcheck.jpg" alt="コントラストチェック結果" width="300" height="20" style="margin:4px 10px;">' . "\n";
$contrast_head .= '</td>' . "\n";
$contrast_head .= '<td width="78" align="right" valign="middle">' . "\n";
$contrast_head .= '<a href="javascript:window.close()">' . "\n";
$contrast_head .= '<img src="' . RPW . '/admin/images/btn/btn_close.jpg" alt="閉じる" width="58" height="19" border="0" style="margin:4px 10px;">' . "\n";
$contrast_head .= '</a>' . "\n";
$contrast_head .= '</td>' . "\n";
$contrast_head .= '</tr>' . "\n";
$contrast_head .= '</table>' . "\n";
$contrast_head .= '</td>' . "\n";
$contrast_head .= '</tr>' . "\n";
$contrast_head .= '</table>' . "\n";
$contrast_head .= '<div id="cms8341-headmessage">　</div>' . "\n";
$contrast_head .= '</div>' . "\n";
$contrast_head .= '<div id="cms8341-contrasttarget">' . "\n";

$htmlStr = preg_replace('/(<body[^>]*>)/i', '${1}' . $contrast_head, $htmlStr);
//コントラストしチェック用JavaScript
$contrast_js = '</div>' . "\n";
$contrast_js .= '<script type="text/javascript" src="' . RPW . '/admin/js/shared.js"></script>' . "\n";
$contrast_js .= '<script type="text/javascript" src="' . RPW . '/admin/js/contrast.js"></script>' . "\n";
$contrast_js .= '<script type="text/javascript">' . "\n";
// コントラストチェックを行う基準を仕込む
$contrast_js .= 'var contrast_standard = ' . $contrast_standard . "\n";
$contrast_js .= 'var contrast = new Contrast("cms8341-contrasttarget");' . "\n";
$contrast_js .= '</script>' . "\n";
$htmlStr = preg_replace('/(<\/body>)/i', $contrast_js . "\n" . '${1}', $htmlStr);

print $htmlStr;
?>