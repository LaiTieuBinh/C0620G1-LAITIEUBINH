/*
 *
 */
var cms8341_OpenDataClass;
var OpenDataSet = Class.create();
OpenDataSet.prototype = {
	// Constructor
	initialize:function() {
		// 各項目オブジェクトの識別用ID
		this.Id = 0;
		// オープンデータファイル可変登録エリア内のdiv要素を取得
		var items  = $('cms8341_OpenDataItems').getElementsByTagName('div');
		for(var i=0 ; i<items.length ; i++) {
			if( Number(this.Id) < Number(items[i].getAttribute('_param')) ) {
				// 現在登録されているファイル数に応じて、IDの値を更新
				this.Id = items[i].getAttribute('_param');
			}
		}
		//必須項目時のラベル
		this.NesLabel = '（必須）';
		//返信メール送信時のラベル
//		this.Reply_MailLabel = '（入力されたメールアドレスに自動返信メールをお送りします。）';
		// 描画HTMLフォーマット({XX}にユーザー入力値を置換して編集画面に返すHTML)
		this.fmtHtml = '';
		this.fmtHtml += '<table width="100%" border="1" cellspacing="0" cellpadding="5" class="opendata_table" style="margin-bottom:10px">';
		this.fmtHtml += '<tr>';
		this.fmtHtml += '<td align="left" valign="middle">';
		this.fmtHtml += '<table width="100%" border="0" cellspacing="0" cellpadding="3" class="cms8341_OpenDataCtrlTable">';
		this.fmtHtml += '<tr>';
		this.fmtHtml += '<th width="30%" align="left" valign="top" id="cms8341_Label_{ID}"><span id="cms8341_ItemLabel_{ID}">{LINK_TEXT}&nbsp;(&nbsp;{OPENDATA_FILEPATH}&nbsp;){OTHER_WINDOW}</span>';
		this.fmtHtml += '</tr>';
		this.fmtHtml += '</table>';
		this.fmtHtml += '</td>';
		this.fmtHtml += '<td width="150" align="center" valign="middle">';
		this.fmtHtml += '<img _param="{ID}" alt="修正する" onclick="OpenDataItemEdit(this)" src="'+RPW+'/admin/images/opendata/item_fix.gif" width="60" height="20" style="cursor:pointer">';
		this.fmtHtml += '&nbsp;';
		this.fmtHtml += '<img _param="{ID}" alt="削除する" onclick="OpenDataItemDel(this)" src="'+RPW+'/admin/images/opendata/item_del.gif" width="60" height="20" style="cursor:pointer">';
		this.fmtHtml += '</td>';
		this.fmtHtml += '</tr>';
		this.fmtHtml += '</table>';
		this.fmtHtml += '<input type="hidden" id="disp_sort_{ID}" name="disp_sort[]" value="{ID}">';
		this.fmtHtml += '<input type="hidden" id="file_path_{ID}" name="file_path_{ID}" value="{OPENDATA_FILEPATH}">';
		this.fmtHtml += '<input type="hidden" id="link_target_{ID}" name="link_target_{ID}" value="{LINK_TARGET}">';
		this.fmtHtml += '<input type="hidden" id="link_text_{ID}" name="link_text_{ID}" value="{LINK_TEXT}">';
		this.fmtHtml += '<input type="hidden" id="opendata_category_{ID}" name="opendata_category_{ID}" value="{OPENDATA_CATE}">';
		this.fmtHtml += '<input type="hidden" id="od_data_type_{ID}" name="od_data_type_{ID}" value="{OD_DATA_TYPE}">';
		this.fmtHtml += '<input type="hidden" id="opendata_keywords_{ID}" name="opendata_keywords_{ID}" value="{OPENDATA_KEYWORDS}">';
		this.fmtHtml += '<input type="hidden" id="opendata_license_{ID}" name="opendata_license_{ID}" value="{OPENDATA_LICENSE}">';
		this.fmtHtml += '<input type="hidden" id="pssd_{ID}" name="pssd_{ID}" value="{PSSD}">';
		this.fmtHtml += '<input type="hidden" id="pssm_{ID}" name="pssm_{ID}" value="{PSSM}">';
		this.fmtHtml += '<input type="hidden" id="pssy_{ID}" name="pssy_{ID}" value="{PSSY}">';
		this.fmtHtml += '<input type="hidden" id="ptsd_{ID}" name="ptsd_{ID}" value="{PTSD}">';
		this.fmtHtml += '<input type="hidden" id="ptsm_{ID}" name="ptsm_{ID}" value="{PTSM}">';
		this.fmtHtml += '<input type="hidden" id="ptsy_{ID}" name="ptsy_{ID}" value="{PTSY}">';
		this.fmtHtml += '<input type="hidden" id="summary_{ID}" name="summary_{ID}" value="{OPENDATA_SUMMARY}">';
		this.fmtHtml += '<input type="hidden" id="file_extention_{ID}" name="file_extention_{ID}" value="{FILE_EXTENSION}">';
		this.fmtHtml += '<input type="hidden" id="file_size_{ID}" name="file_size_{ID}" value="{FILE_SIZE}">';
		
		//イベントリスナー登録(追加ボタンを押下された際に実行される処理をイベント登録)
		Event.observe($('cms8341_AddOpendataFiles'), 'click', this.controllAdd.bind(this));
	},
	//改行処理（改行コード→BR）
	encodeBR:function(txt) {
		return txt.replace(/\x0D\x0A|\x0D|\x0A/g,'<br>');
	},
	//改行コードの代替エスケープ
	escapeBR:function(txt) {
		return txt.replace(/\x0D\x0A|\x0D|\x0A/g,'[br]');
	},
	//代替エスケープのデコード
	descapeBR:function(txt) {
		return txt.replace(/\[br\]/g,'\n');
	},
	//HTMLエスケープ処理
	htmlEscape:function(str,flg) {
		var ret = str;
		//\マークをエスケープ
		ret = ret.replace(/\\/g,'\\\\');
		//シングルクォーテーションをエスケープ
		ret = ret.replace(/\'/g,'&#39;');
		while(ret.match("&#39;")){
			ret = ret.replace("&#39;","\\'");
		}
		//他のエスケープ処理
		if(flg == true){
			ret = ret.replace(/\&/g,'&amp;');
			ret = ret.replace(/</g,'&lt;');
			ret = ret.replace(/>/g,'&gt;');
			ret = ret.replace(/\"/g,'&quot;');
		}
		return ret;
	},
		
	/*--------------------------
	 * オープンデータファイルの可変登録エリアに出力するHTMLを作成する
	 *---------------------------*/
	createItemBlock:function(obj) {
		// 置換する文字列をセットする
		if (obj["id"] != undefined) {
			// 編集時は対象のIDをセット
			var id = obj["id"];
		}
		else {
			var id = this.Id;
		}
		var link_text = obj["link_text"];
		var file_path = obj["file_path"];
		var summary = obj["summary"];
		var link_target = obj["link_target"];
		var opendata_cate = obj["opendata_category"];
		var od_data_type = obj["od_data_type"];
		var opendata_keywords = obj["opendata_keywords"];
		var opendata_license = obj["opendata_license"];
		var pssd = obj["pssd"];
		var pssm = obj["pssm"];
		var pssy = obj["pssy"];
		var ptsd = obj["ptsd"];
		var ptsm = obj["ptsm"];
		var ptsy = obj["ptsy"];
		var file_extention = obj["file_extention"];
		var file_sized = obj["file_size"];

		// target属性値に「_blank」（別ウィンドウ）設定が指定されている場合
		var other_window_str = '';
		if (link_target && link_target == '_blank') {
			// 日本語テンプレートの場合
			if (acc_flg == 0) {
				other_window_str += OTHER_WINDOW_STR_JP;
			}
			// 外国語テンプレートの場合
			else if (acc_flg == 1) {
				other_window_str += OTHER_WINDOW_STR_EN;
			}
		}
		
		// フォーマット内の置換文字を置換
		var retHtml = this.fmtHtml;
		retHtml = retHtml.replace(/{ID}/g,id);
		retHtml = retHtml.replace(/{LINK_TEXT}/g,link_text);
		retHtml = retHtml.replace(/{OPENDATA_FILEPATH}/g,file_path);
		retHtml = retHtml.replace(/{OPENDATA_SUMMARY}/g,summary);
		retHtml = retHtml.replace(/{LINK_TARGET}/g,link_target);
		retHtml = retHtml.replace(/{LINK_TEXT}/g,link_text);
		retHtml = retHtml.replace(/{OPENDATA_CATE}/g,opendata_cate);
		retHtml = retHtml.replace(/{OD_DATA_TYPE}/g,od_data_type);
		retHtml = retHtml.replace(/{OPENDATA_KEYWORDS}/g,opendata_keywords);
		retHtml = retHtml.replace(/{OPENDATA_LICENSE}/g,opendata_license);
		retHtml = retHtml.replace(/{PSSD}/g,pssd);
		retHtml = retHtml.replace(/{PSSM}/g,pssm);
		retHtml = retHtml.replace(/{PSSY}/g,pssy);
		retHtml = retHtml.replace(/{PTSD}/g,ptsd);
		retHtml = retHtml.replace(/{PTSM}/g,ptsm);
		retHtml = retHtml.replace(/{PTSY}/g,ptsy);
		retHtml = retHtml.replace(/{FILE_EXTENSION}/g,file_extention);
		retHtml = retHtml.replace(/{FILE_SIZE}/g,file_sized);
		retHtml = retHtml.replace(/{OTHER_WINDOW}/g,other_window_str);
		
		return retHtml;
	},
	
	//モーダル画面の表示
	showModal:function(arg, callback) {
		arg['windowObject'] = window;
		// 必要なパラメータを指定してリンク設定ダイアログを表示
		//return cxShowModalDialog(cms8341admin_path+"/page/common/opendata/opendata_link.php?id="+arg["id"]+"&page_id="+$('cms_page_id').value+"&dir_path="+$('cms_dir_path').value+"&from_type="+$('cms_from_type').value+"&img="+arg["img"]+"&img_width="+arg['img_width']+"&img_height="+arg['img_height'],arg,"status:false;dialogWidth:460px;dialogHeight:580px;help:no;status:no");
		//return cxShowModalDialog(cms8341admin_path+"/page/common/opendata/opendata_link.php?id="+arg["id"]+"&page_id="+$('cms_page_id').value+"&dir_path="+$('cms_dir_path').value, arg, "status:false;dialogWidth:460px;dialogHeight:580px;help:no;status:no");
		var Open_URL = cms8341admin_path+"/page/common/opendata/opendata_link.php?id="+arg["id"]+"&page_id="+$('cms_page_id').value+"&dir_path="+$('cms_dir_path').value;
		cxIframeLayer(
			Open_URL,
			460,
			580,
			COVER_SETTING.COLOR,
			'',
			callback,
			false,
			false,
			arg
		);
	
	},
	
	//コントロール追加
	controllAdd:function(e) {
		var arg = new Object();
		// 現在の要素数を取得
		var items  = $('cms8341_OpenDataItems').getElementsByTagName('div');
		// 可変登録の最大数を超えている場合はエラーとする
		if (items.length >= OPENDATA_VARIABLE_FILE_MAX_COUNT) {
			alert('このエリアに対するオープンデータファイルの登録上限数に達しています。');
			return false;
		}
		this.Id++;
		arg["id"] = this.Id;
		arg["img"] = '';
		var callback = function(retObj){
			if (retObj !== false && retObj != undefined) {
				// リターンされたオブジェクトを元に、出力するHTMLを生成
				var html = cms8341_OpenDataClass.createItemBlock(retObj);
				// divエレメントを作成
				var div = document.createElement('div');
				// 追加するオープンデータ項目のIDを作成
				div.id = "cms8341_OpenDataCtrl_"+this.Id;
				div.setAttribute('_param', this.Id);
				// 追加オープンデータ用に作成したdivに作成したHTMLを埋め込む
				div.innerHTML = html;
				// 生成したオープンデータ項目を対象のエリアに追加
				$('cms8341_OpenDataItems').appendChild(div);
				// ドラッグアンドドロップによる表示順変更を可能とする
				Sortable.create('cms8341_OpenDataItems',{tag:'div'});
			}
			else {
				// 追加ボタン押下後、閉じるが実行された場合などにはIDをデクリメントしておく
				this.Id--;
			}
		}
		this.showModal(arg, callback.bind(this));
	}
}

//-------------------------------------------------
// オープンデータファイル情報の編集
// 
// param : obj
// return: なし
//-------------------------------------------------
function OpenDataItemEdit(obj) {
	// 修正が指定された項目のIDを取得
	var id = obj.getAttribute('_param');
	// 修正対象の項目のhidden値を元に、モーダルウィンドウに渡すパラメータをセットする
	var datObj = new Object();
	datObj["id"] = id;
	datObj["link_text"] = $F('link_text_' + id);
	datObj["file_path"] = $F('file_path_' + id);
	datObj["file_size"] = $F('file_size_' + id);
	datObj["file_extention"] = $F('file_extention_' + id);
	datObj["summary"] = $F('summary_' + id);
	datObj["link_target"] = $F('link_target_' + id);
	datObj["opendata_category"] = $F('opendata_category_' + id);
	datObj["od_data_type"] = $F('od_data_type_' + id);
	datObj["opendata_keywords"] = $F('opendata_keywords_' + id);
	datObj["opendata_license"] = $F('opendata_license_' + id);
	datObj["pssd"] = $F('pssd_' + id);
	datObj["pssm"] = $F('pssm_' + id);
	datObj["pssy"] = $F('pssy_' + id);
	datObj["ptsd"] = $F('ptsd_' + id);
	datObj["ptsm"] = $F('ptsm_' + id);
	datObj["ptsy"] = $F('ptsy_' + id);
	// モーダルウィンドウを開く
	var callback = function(retObj){
		if (retObj !== false && retObj != undefined) {
			// 返り値を元にオープンデータの内容を更新
			var retHtml = cms8341_OpenDataClass.createItemBlock(retObj);
			$("cms8341_OpenDataCtrl_"+id).innerHTML = retHtml;
		}
	}
	cms8341_OpenDataClass.showModal(datObj, callback);
}

//-------------------------------------------------
// オープンデータファイルの削除
// 
// param : obj
// return: なし
//-------------------------------------------------
function OpenDataItemDel(obj) {
	var id = obj.getAttribute('_param');
	var r = confirm('オープンデータファイルを削除しますがよろしいですか？');
	if (r) {
		// 指定されたオープンデータファイルの情報を削除する
		Element.remove($('cms8341_OpenDataCtrl_'+id));
	}
}

