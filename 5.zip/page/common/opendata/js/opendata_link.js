/*
 * リンク設定用javascript
 */

window.dialogArguments = window.frameElement.args;

//正規表現の作成
var oRegex = new Object();
//ロード時のプロトコル解析用正規表現
oRegex.UriProtocol = new RegExp('');
oRegex.UriProtocol.compile('^((((http|https):)?\/\/)|mailto:|tel:)','gi');
//入力時のプロトコル解析用正規表現
oRegex.UrlOnChangeProtocol = new RegExp('');
oRegex.UrlOnChangeProtocol.compile('^(http|https)://(?=.)','gi');
//その他のプロトコル解析用正規表現
oRegex.UrlOnChangeTestOther = new RegExp('');
oRegex.UrlOnChangeTestOther.compile('^((javascript:)|[#/\.]|((ftp|news)://))','gi');
//ターゲット解析用正規表現
oRegex.ReserveTarget = new RegExp('');
oRegex.ReserveTarget.compile('^_(blank|self|top|parent)$','i');

//定義済テキストの削除用
var delRepText = '';
//配列を作成
var ADD_FILE_DETAIL_EXP_ARY = getAddFileDetailExp();
for(i in ADD_FILE_DETAIL_EXP_ARY){
	//定義用テキスト削除用の正規表現作成
	if(acc_flg == 0) delRepText += (delRepText != '' ? '|' : '') + ADD_FILE_DETAIL_EXP_ARY[i]['JP'];		//日本語
	else if(acc_flg == 1) delRepText += (delRepText != '' ? '|' : '') + ADD_FILE_DETAIL_EXP_ARY[i]['EN'];	//外国語
}

// ファイルサイズ（単位：KB）
var FSize;
// ファイル拡張子
var FExp;

//選択されているリンクオブジェクトの取得
if(GET['href'] && GET['href'] != ""){
	var oLink = document.createElement('A');
	oLink.href = GET['href'];
	oLink.innerHTML = cxEscapeHtmlChars(GET['text']);
	oLink.target = GET['target'];
}

//-------------------------------------------------
//	ロード時に実行される
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
window.onload = function(){
	//リンクに設定されている値の取得
	LoadSelection();
	//リンクタイプの切り替え
	SetLinkType(Get_Sel_Item());
}

//-------------------------------------------------
//	現在設定されている値を取得する
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
var sType = "";
var sHRef = "";
var sTxt = "";
var target_id = "";
function LoadSelection(){
	// モーダルダイアログのパラメータ取得処理
	var argObj = window.dialogArguments;
	// パラメータを元に各項目に値をセットする(オープンデータ項目の修正時の既存設定内容の反映)
	if (argObj !== undefined) {
		// ID
		if(argObj['id'] !== undefined){
			target_id = argObj['id'];
		}
		// リンクテキスト
		if(argObj['link_text'] !== undefined){
			$('txtFile_txt').value = argObj['link_text'];
		}
		// ファイルパス
		if(argObj['file_path'] !== undefined){
			$('txtFile').value = argObj['file_path'];
		}
		// ファイルサイズ
		if(argObj['file_size'] !== undefined){
			FSize = argObj['file_size'];
		}
		// ファイル拡張子
		if(argObj['file_extention'] !== undefined){
			FExp = argObj['file_extention'];
		}
		// 別ウィンドウで開く
		if(argObj['link_target'] !== undefined && argObj['link_target'] == '_blank'){
			$('setBlank_File').checked = true;
		}
		// 概要
		if(argObj['summary'] !== undefined){
			$('opendata_summary').value = argObj['summary'];
		}
		// ライセンス
		if(argObj['opendata_license'] !== undefined){
			// 選択項目を取得し、パラメータと一致した選択項目のselectedを有効にする
			pulldown_option = document.getElementById("opendata_license").getElementsByTagName('option');
			for(i=0 ; i < pulldown_option.length ; i++){
				if (pulldown_option[i].value == argObj['opendata_license']) {
					pulldown_option[i].selected = true;
				}
			}
		}
		// データ時点
		if(argObj['ptsy'] !== undefined && argObj['ptsm'] !== undefined && argObj['ptsd'] !== undefined){
			$('ptsy').value = argObj['ptsy'];
			$('ptsm').value = argObj['ptsm'];
			$('ptsd').value = argObj['ptsd'];
		}
		// 掲載日
		if(argObj['pssy'] !== undefined && argObj['pssm'] !== undefined && argObj['pssd'] !== undefined){
			$('pssy').value = argObj['pssy'];
			$('pssm').value = argObj['pssm'];
			$('pssd').value = argObj['pssd'];
		}
		// カテゴリ
		if(argObj['opendata_category'] !== undefined){
			// 選択項目を取得し、パラメータと一致したチェックボックスにチェックを入れる
			check_param = argObj['opendata_category'].split(',');
			check_option = document.getElementsByName("opendata_category[]");
			for (var j = 0; j < check_param.length; j++) {
				for (var i = 0; i < check_option.length; i++) {
					if (check_option[i].value == check_param[j]) {
						check_option[i].checked = true;
					}
				}
			}
		}
		// データタイプ
		if(argObj['od_data_type'] !== undefined){
			// 選択項目を取得し、パラメータと一致した選択項目のselectedを有効にする
			pulldown_option = document.getElementById("od_data_type").getElementsByTagName('option');
			for(i=0 ; i < pulldown_option.length ; i++){
				if (pulldown_option[i].value == argObj['od_data_type']) {
					pulldown_option[i].selected = true;
				}
			}
		}
		// キーワード検索タグ
		if(argObj['opendata_keywords'] !== undefined){
			$('opendata_keywords').value = argObj['opendata_keywords'];
		}
	}
	
	// リンクが無ければ、returnする
	if(!oLink) {
		return;
	}
	// 初期値設定(オープンデータ登録処理では初期値としてfileをセット)
	sType = GetE('chkLinkType_File').value;
	// 設定されているリンク先を取得
	sHRef = oLink.getAttribute('_fcksavedurl');
	if(!sHRef || sHRef.length == 0) {
		sHRef = oLink.getAttribute('href',2) + '';
	}
	// ローカルサーバのパスならば、その部分を取り除く
	sHRef = sHRef.replace(HTTP_ROOT,'');
	// リンクタイトルの取得
	sTxt = cxUnEscapeHtmlChars(oLink.innerHTML);
	// プロトコルを取得
	oRegex.UriProtocol.lastIndex = 0;
	var sProtocol = oRegex.UriProtocol.exec(sHRef);
	// プロトコルにより処理を分ける
	if (sProtocol) {
		// オープンデータの場合はファイル固定なのでここに入ることはあり得ない
		alert("オープンデータファイル以外のタイプが選択されています。");
		GetE('txtInUrl_txt').focus();
		return false;
	}
	// その他
	else {
		// 内部パスを消す
		if (sHRef.startsWith(RPW)) {
			sHRef = sHRef.remove(0,RPW.length);
		}
		// ファイル情報を取得する
		cxAjaxCommand('cxFCKGetFileInfo','file_path=' + sHRef,AjaxSuccess);
	}
}

//-------------------------------------------------
//	通信成功処理
//	【引数】
//		r	: カンマ区切りの文字列(ファイルパス,拡張子,サイズ)
//	【戻値】
//		なし
//-------------------------------------------------
function AjaxSuccess(r){
	if(r.responseText != ""){
		fileinfo = r.responseText.split(",");
		//ファイル
		FExp = fileinfo[1];
		FSize = fileinfo[2];
		sType = GetE('chkLinkType_File').value;
		GetE('txtFile').value = fileinfo[0];
		GetE('txtFile_txt').value = sTxt;
	}
	afterLoadSelection();
}

//-------------------------------------------------
//	通信失敗処理
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
function cxFailure(){
	afterLoadSelection();
}

//-------------------------------------------------
//	ロード後処理
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
function afterLoadSelection(){
	// リンクに設定されているtarget属性を取得する
	var sTarget = oLink.target;
	if(sTarget && sTarget.length > 0){
		if(oRegex.ReserveTarget.test(sTarget)) {
			sTarget = sTarget.toLowerCase();
		}
	}
	// target属性に_blankが指定されていた場合、対応するチェックボックスにチェックをつける
	if(sTarget == "_blank"){
		if(sType == GetE('chkLinkType_File').value && GetE('setBlank_File')) {
			GetE('setBlank_File').checked = true;
		}
	}
	// リンクタイプによりチェックボックスの切り替え
	if(sType == GetE('chkLinkType_File').value) {
		GetE('chkLinkType_File').checked = true;
	}
	// リンクタイプの切り替え(Ajaxが非同期のため、予備)
	SetLinkType(Get_Sel_Item());
}

//-------------------------------------------------
//	リンクタイプの切り替え
//	【引数】
//		linkType	: 現在選択されているリンクタイプ
//	【戻値】
//		なし
//-------------------------------------------------
function SetLinkType(linkType){
	//ファイル
	ShowE('divLinkTypeFile_txt_name',(linkType == GetE('chkLinkType_File').value));
	ShowE('divLinkTypeFile_txt',(linkType == GetE('chkLinkType_File').value));
	ShowE('divLinkTypeFile_name',(linkType == GetE('chkLinkType_File').value));
	ShowE('divLinkTypeFile',(linkType == GetE('chkLinkType_File').value));
	// ファイル以外なら、ボタンを無効にする
	if (linkType != GetE('chkLinkType_File').value) {
		GetE('divFileLink').innerHTML = '<a id="aFileLink" class="cke_dialog_ui_button cke_dialog_ui_button_inactive" >ファイルリンク設定</a>';
	}
	else {
		// ファイルなら有効にする
		GetE('divFileLink').innerHTML = '<a id="aFileLink" class="cke_dialog_ui_button" href="javascript:void(0)" onclick="showModal(2);">ファイルリンク設定</a>';
	}
}

//-------------------------------------------------
//	完了ボタンが押された際の処理
//	【引数】
//		なし
//	【戻値】
//		true	: 成功時
//		false	: 失敗時
//-------------------------------------------------
function Ok(){
	var sUri;
	
	// 選択されているタイプを取得する
	var selected_item = Get_Sel_Item();
	// オープンデータの場合はファイル以外はあり得ないので、異なる値がとれば場合はエラーとする
	if (selected_item != GetE('chkLinkType_File').value) {
		alert("オープンデータ以外のタイプが指定されています。");
		return false;
	}
	
	// サイト内リンクフォーマットチェック用正規表現
	var osUriRegEx = new RegExp("^(s?https?:\/)?\/[-_.!~*'()a-zA-Z0-9;\/?:\@&=+\$,%#]+$");
	
	// リンクタイトル
	var sUri_txt = trim(GetE('txtFile_txt').value);
	// 必須チェック
	if(sUri_txt.length == 0){
		alert("リンクタイトルが入力されていません。");
		GetE('txtFile_txt').focus();
		return false;
	}
	// 機種依存文字チェック
	var info = new Array();
	info = fckCheck('リンクタイトル',sUri_txt,info);
	info = accItemCheck('リンクタイトル',sUri_txt,info,'file');
	// スペースのみの指定の場合は確認
	var tmp_sUri_txt = sUri_txt;
	// 「　(文字参照全角スペース)」を「 (半角スペース)」に変換
	tmp_sUri_txt = tmp_sUri_txt.replace(/　/g, " ");
	// 「 (半角スペース)」を削除
	tmp_sUri_txt = tmp_sUri_txt.replace(/ /g, "");
	if (tmp_sUri_txt.length < 1) {
		info.push("リンクタイトルに画面に表示されない文言のみ指定されています。");
	}
	if (!info) {
		return false;
	}
	if(info.length > 0){
		var msg = info.join('\n') + '\nよろしいですか？';
		if(!confirm(msg)){
			$('txtFile_txt').focus();
			return false;
		}
	}
	// ファイルパスの取得
	sUri = trim(GetE('txtFile').value);
	// ローカルサーバのパスならば、その部分を取り除く
	sUri = sUri.replace(HTTP_ROOT,'')
	if(sUri.startsWith(RPW)) sUri = sUri.remove(0,RPW.length);
	// 必須チェック
	if(sUri.length == 0){
		alert("ファイルパスを入力してください。");
		GetE('txtFile').focus();
		return false;
	}
	// ファイル拡張子のチェック
	var File_Exte = DENIED_EXTENSIONS_FILE.split(",");
	for(var i = 0 ; i < File_Exte.length ; i++) {
		var ExteRegEx = new RegExp("(\\." + File_Exte[i] + ")$");
		var asFileExte = ExteRegEx.exec(sUri);
		if(asFileExte != null){
			alert("設定できないファイル拡張子が入力されています。");
			GetE('txtFile').focus();
			return false;
		}
	}
	// プロトコルを取得
	oRegex.UriProtocol.lastIndex = 0;
	var sProtocol = oRegex.UriProtocol.exec(sUri);
	// 読み元に返すファイルパスを退避
	var ret_file_path = sUri;
	// プロトコルが存在しない場合
	if (sProtocol == null) {
		// 内部パスを足す
		sUri = RPW + sUri;
	}
	
	// オープンデータ概要
	var summary_txt = trim(GetE('opendata_summary').value);
	// 必須チェック
	if(summary_txt.length == 0){
		alert("概要を入力してください。");
		GetE('opendata_summary').focus();
		return false;
	}
	// 機種依存文字チェック
	info = new Array();
	info = fckCheck('概要',summary_txt,info);
	info = accItemCheck('概要',summary_txt,info,'file');
	if (!info) {
		alert("[概要]入力値チェックエラー");
		return false;
	}
	if(info.length > 0){
		var msg = info.join('\n') + '\nよろしいですか？';
		if(!confirm(msg)){
			$('txtFile_txt').focus();
			return false;
		}
	}
	// ライセンス必須チェック
	var license_txt = trim(GetE('opendata_license').value);
	if(license_txt.length == 0){
		alert("ライセンスを選択してください。");
		GetE('opendata_license').focus();
		return false;
	}
	// データ時点入力日付チェック
	if (!($F('ptsy') == "" && $F('ptsm') == "" && $F('ptsd') == "")) {
		var date_check_result = cxDateCheckNew("pt", "ymd", 2, "データ時点");
		if (!disp_date_error(date_check_result, "ptsy")) {
			return false;
		}
	} else {
		alert("データ時点を入力してください。");
		GetE('ptsy').focus();
		return false;
	}
	// 掲載日
	if (!($F('pssy') == "" && $F('pssm') == "" && $F('pssd') == "")) {
		var date_check_result = cxDateCheckNew("ps", "ymd", 2, "掲載日");
		if (!disp_date_error(date_check_result, "pssy")) {
			return false;
		}
	} else {
		alert("掲載日を入力してください。");
		GetE('pssy').focus();
		return false;
	}
	// カテゴリ必須チェック
	var category_check_box_ele = document.getElementsByName('opendata_category[]');
	var category_check_box_flg = false;
	for (var i=0; i<category_check_box_ele.length; i++) {
		if(category_check_box_ele.item(i).checked) {
			category_check_box_flg = true;
		}
	}
	if (!category_check_box_flg) {
		alert("カテゴリを選択してください。");
		return false;
	}
	// データタイプ必須チェック
	var od_data_type_txt = trim(GetE('od_data_type').value);
	if(od_data_type_txt.length == 0){
		alert("データタイプを選択してください。");
		GetE('od_data_type').focus();
		return false;
	}
	// キーワード検索タグ
	var keyword_search_txt = trim(GetE('opendata_keywords').value);
	// 機種依存文字チェック
	info = new Array();
	info = fckCheck('キーワード検索タグ',keyword_search_txt,info);
	info = accItemCheck('キーワード検索タグ',keyword_search_txt,info,'file');
	if (!info) {
		alert("[キーワード検索タグ]入力値チェックエラー");
		return false;
	}
	if(info.length > 0){
		var msg = info.join('\n') + '\nよろしいですか？';
		if(!confirm(msg)){
			$('txtFile_txt').focus();
			return false;
		}
	}
	
	// --------------------
	// 表示元に返すオブジェクトの作成
	// --------------------
	var retObj = new Object();
	
	// 対象のIDを返す
	retObj["id"] = target_id;
	
	retObj["ret"] = sUri + KANKO_LINK_DELIMITER + sUri_txt;
	
	// 別ウィンドウで開くが指定されている場合は、[_blank]をセットする
	var target_str = '';
	if(selected_item == GetE('chkLinkType_File').value && GetE('setBlank_File') && GetE('setBlank_File').checked) {
		target_str = "_blank";
		retObj["ret"] += KANKO_LINK_DELIMITER + target_str;
	}
	else {
		target_str = '_self';
	}
	//ファイル情報
	if(selected_item == GetE('chkLinkType_File').value){
		if (FExp) {
			retObj["ret"] += KANKO_LINK_DELIMITER + FExp;
		}
		if (FSize) {
			retObj["ret"] += KANKO_LINK_DELIMITER + FSize;
		}
	}
	// リンクテキスト
	retObj["link_text"] = sUri_txt;
	// ファイルパス
	retObj["file_path"] = ret_file_path;
	// 概要
	retObj["summary"] = summary_txt;
	// オープンデータライセンス
	retObj["opendata_license"] = GetE('opendata_license').value;
	// データ時点
	retObj["ptsy"] = GetE('ptsy').value;
	retObj["ptsm"] = GetE('ptsm').value;
	retObj["ptsd"] = GetE('ptsd').value;
	// 掲載日
	retObj["pssy"] = GetE('pssy').value;
	retObj["pssm"] = GetE('pssm').value;
	retObj["pssd"] = GetE('pssd').value;
	// オープンデータカテゴリ
	var category_check_box_ele = document.getElementsByName('opendata_category[]');
	var category_check_box_val = '';
	for (var i=0; i<category_check_box_ele.length; i++) {
		if (category_check_box_ele.item(i).checked) {
			//category_check_box_val += category_check_box_ele.item(i).value + KANKO_LINK_DELIMITER;
			category_check_box_val += category_check_box_ele.item(i).value + ',';
		}
	}
	category_check_box_val = category_check_box_val.substr(0, category_check_box_val.length-1);
	retObj["opendata_category"] = category_check_box_val;
	// オープンデータデータタイプ
	retObj["od_data_type"] = GetE('od_data_type').value;
	// キーワード検索タグ
	retObj["opendata_keywords"] = keyword_search_txt;
	// ファイル拡張子
	retObj["file_extention"] = FExp;
	// ファイルサイズ
	retObj["file_size"] = FSize;
	// ターゲット
	retObj["link_target"] = target_str;
	
	cxIframeLayerCallback(retObj);
	//正常終了
	return true;
}

//-------------------------------------------------
//	モーダルダイアログを表示する
//	【引数】
//		open_dlg	: オープンするダイアログのID
//					: 1 サイト内にリンク
//					: 2 ファイルにリンク
//	【戻値】
//		なし
//-------------------------------------------------
function showModal(open_dlg){
	var newDlg;
	var Open_URL;
	var Open_Title;
	var Open_Width;
	var Open_Height;
	
	// オープンデータの場合は2以外を受け取ることは考慮しない
	if (open_dlg != 2) {
		alert("ファイルリンクダイアログ表示パラメータが不正です。");
		return false;
	}
	
	//ファイルリンク
	if(open_dlg == 2){
		Open_URL = RPW + "/ckeditor/plugins/gd_link/fck_link/fck_filelink.php" + ((GetE('txtFile').value != "") ? ("?url=" + encodeURL(GetE('txtFile').value)) : (""));
		Open_Title = "ファイルにリンク";
		Open_Width = 630;
		Open_Height = 680;
		Open_resize = 0;
	}
	//ダイアログ表示
	cxIframeLayer(
		Open_URL,
		Open_Width,
		Open_Height,
		COVER_SETTING.COLOR,
		'',
		function (newURL) {
			if(newURL != undefined){
				$sel_item = Get_Sel_Item();
				if ($sel_item == GetE('chkLinkType_File').value) {
					GetE('txtFile').value = newURL["url"];
					FExp = newURL["exp"];
					FSize = newURL["size"];
				}
			}
		}
	);

}

//-------------------------------------------------
//	現在選択されているリンクタイプを取得する
//	【引数】
//		なし
//	【戻値】
//		現在選択されているリンクタイプのvalue名
//-------------------------------------------------
function Get_Sel_Item(){
	var ret = false;
	// オープンデータはタイプファイル固定
	if (GetE('chkLinkType_File').checked) {
		ret = GetE('chkLinkType_File').value;
	}
	return ret;
}

//-------------------------------------------------
//	文字列をURLエンコードする(UTF-8)
//	【引数】
//		str	: エンコードしたい文字列
//	【戻値】
//		エンコードした文字列
//-------------------------------------------------
function encodeURL(str){
	var character = '';
	var unicode = '';
	var string = '';
	var i = 0;
	for(i = 0;i < str.length;i++){
		character = str.charAt(i);
		unicode = str.charCodeAt(i);
		if(character == ' ') string += '+';
		else{
			if(unicode == 0x2a || unicode == 0x2d || unicode == 0x2e || unicode == 0x5f || ((unicode >= 0x30) && (unicode <= 0x39)) || ((unicode >= 0x41) && (unicode <= 0x5a)) || ((unicode >= 0x61) && (unicode <= 0x7a))){
				string = string + character;
			}
			else{
				if((unicode >= 0x0) && (unicode <= 0x7f)){
					character = '0' + unicode.toString(16);
					string += '%' + character.substr(character.length - 2);
				}
				else if(unicode > 0x1fffff){
					string += '%' + (oxf0 + ((unicode & 0x1c0000) >> 18)).toString(16);
					string += '%' + (0x80 + ((unicode & 0x3f000) >> 12)).toString(16);
					string += '%' + (0x80 + ((unicode & 0xfc0) >> 6)).toString(16);
					string += '%' + (0x80 + (unicode & 0x3f)).toString(16);
				}
				else if(unicode > 0x7ff){
					string += '%' + (0xe0 + ((unicode & 0xf000) >> 12)).toString(16);
					string += '%' + (0x80 + ((unicode & 0xfc0) >> 6)).toString(16);
					string += '%' + (0x80 + (unicode & 0x3f)).toString(16);
				}
				else{
					string += '%' + (0xc0 + ((unicode & 0x7c0) >> 6)).toString(16);
					string += '%' + (0x80 + (unicode & 0x3f)).toString(16);
				}
			}
		}
	}
	return string;
}
