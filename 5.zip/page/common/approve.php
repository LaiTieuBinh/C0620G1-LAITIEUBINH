<?php
/*
 * 修正/承認/否認
 */
require ("../.htsetting");

// cms_dispModeおよびcms_group_idが渡されなければエラー
if (!isset($_POST['cms_dispMode']) || !isset($_POST['cms_group_id'])) {
	user_error("It isn't setted cms_dispMode or cms_group_id in _post.", E_USER_ERROR);
}
// cms_dispMode='approve'	承認者による承認
// cms_dispMode='denail'	承認者による否認
// cms_dispMode='revise'	作成者による否認コンテンツグループの修正


require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_contents_group.inc');
$objCGrp = new tbl_contents_group($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_approve_handler.inc');
$objAppHandler = new tbl_approve_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/login.inc');
$objLogin = new login();

// 移行作業用：否認時ファイル添付機能
if (IKOU_MODE == TRUE && $_POST['cms_dispMode'] == 'denail') {
	$save_file_name = '';
	// （php.ini）post_max_size をオーバーすると$_POSTの値が飛んでこない
	if (count($_FILES) == 0) {
		DispError("取り込みファイルのファイルサイズが大きすぎる可能性があります。", 2, "javascript:history.back()", MENU_KIND_PAGE);
	}
	// 取り込みファイルが指定されている場合のみチェック処理
	if (isset($_FILES['denial_file']) && $_FILES['denial_file']['name'] != '') {
		// （php.ini）upload_max_filesize をオーバーすると$_FILES['FrmZipnm']['size']はゼロになる
		// ファイルサイズがゼロならエラー
		if ($_FILES['denial_file']['size'] <= 0) {
			DispError("取り込みファイルの指定が正しくないか、取り込みファイルのファイルサイズが大きすぎる可能性があります。", 2, "javascript:history.back()", MENU_KIND_PAGE);
			exit();
		}
		// アップロード
		$date = date("mdHis");
		$save_file_name = basename($_FILES['denial_file']['name']);
		// 指定されたファイルのファイル名をチェック
		if (!preg_match('/^[-0-9a-zA-Z_.]+$/', $save_file_name)) {
			// 「半角英数字」,「-」,「_」,「.」以外が使用されたファイル名は認めない
			DispError("添付するファイル名には半角英数字、ハイフン「-」、アンダーバー「_」のみ使用可能です。", 2, "javascript:history.back()", MENU_KIND_PAGE);
			exit();
		}
		
		// 拡張子チェック
		$sExtension = strtolower(substr($save_file_name, (strrpos($save_file_name, '.') + 1)));
		// 添付ファイルに許可されている拡張子のファイルのみを受け付ける
		$ADD_FILE_DETAIL_EXP = getDefineArray('ADD_FILE_DETAIL_EXP');
		if (!array_key_exists($sExtension, $ADD_FILE_DETAIL_EXP)) {
			// 許可された拡張子のリストに存在しない拡張子だった場合には、エラーとする
			DispError("アップロードが許可されていない拡張子のファイルが指定されています。", 2, "javascript:history.back()", MENU_KIND_PAGE);
			exit();
		}
		// 保存するファイルパスを作成
		$save_file_path = DOCUMENT_ROOT . ATTACHED_FILE_SAVE_PATH . '/' . $date . '_' . $save_file_name;
		// 既に同名のファイルが存在するかチェック、存在する場合は保存するファイル名の時間の後ろに「_new」を付与したファイル名とする
		if (file_exists($save_file_path) == TRUE) {
			// このファイル名でさらにかぶることまでは考慮しない
			$save_file_name = $date . '_new_' . $save_file_name;
		}
		else {
			$save_file_name = $date . '_' . $save_file_name;
		}
		// 保存するファイルパスを確定
		$save_file_path = DOCUMENT_ROOT . ATTACHED_FILE_SAVE_PATH . '/' . $save_file_name;
		// フォルダが無ければ作成
		if (!mkNewDirectory($save_file_path)) {
			DispError("添付ファイル保存用ディレクトリの生成に失敗しました。", 2, "javascript:history.back()", MENU_KIND_PAGE);
			exit();
		};
		// 添付ファイル格納先へ保存
		if (move_uploaded_file($_FILES['denial_file']['tmp_name'], $save_file_path) == FALSE) {
			DispError("添付ファイルのアップロードに失敗しました。", 2, "javascript:history.back()", MENU_KIND_PAGE);
			exit();
		}
		// 念のためファイル存在チェック
		if (file_exists($save_file_path) == FALSE) {
			$wk_str = "添付ファイルのアップロードに失敗しました。【" . $save_file_path . "】";
			DispError($wk_str, 2, "javascript:history.back()", MENU_KIND_PAGE);
			exit();
		}
	}
}

$objCnc->begin();

// グループに属するページ情報を取得
$objPage->selectFromGroupID($_POST['cms_group_id']);
$aryID = array();
$aryPage = array();
while ($objPage->fetch()) {
	$aryID[] = $objPage->fld['page_id'];
	$ary = array();
	$ary['page_id'] = $objPage->fld['page_id'];
	$ary['page_title'] = $objPage->fld['page_title'];
	$ary['file_path'] = $objPage->fld['file_path'];
	if ($objPage->fld['work_class'] == WORK_CLASS_NEW) $ary['work_class'] = '（新規）';
	elseif ($objPage->fld['work_class'] == WORK_CLASS_PUBLISH) $ary['work_class'] = '（更新）';
	elseif ($objPage->fld['work_class'] == WORK_CLASS_DELETE && $objPage->fld['close_flg'] == FLAG_OFF) $ary['work_class'] = '（削除依頼）';
	elseif ($objPage->fld['work_class'] == WORK_CLASS_DELETE && $objPage->fld['close_flg'] == FLAG_ON) $ary['work_class'] = '（非公開依頼）';
	else $ary['work_class'] = '';
	$ary['template_kind_temp'] = $objPage->fld['template_kind'];
	
	$aryPage[] = $ary;
}
// ページIDのカンマ区切り文字列
$listID = implode(',', $aryID);

// 否認されたコンテンツグループの修正
if ($_POST['cms_dispMode'] == 'revise') {
	// コンテンツグループの削除
	if ($objCGrp->deleteFromID($_POST['cms_group_id']) === FALSE) {
		$objCnc->rollback();
		user_error("承認依頼グループの削除に失敗しました。");
	}
	// 公開情報を更新（status=完了）
	$sql = "UPDATE tbl_publish_page" . " SET status = 202" . " WHERE page_id IN (" . $listID . ")";
	if ($objPage->execute($sql) === FALSE) {
		$objCnc->rollback();
		user_error("公開ページ情報の更新に失敗しました。");
	}
	// 編集情報を更新（status=完了）
	$sql = "UPDATE tbl_work_page SET" . " status = 202" . ", group_id = NULL" . ", publish_start = NULL" . ", publish_end = NULL" . " WHERE page_id IN (" . $listID . ")";
	if ($objPage->execute($sql) === FALSE) {
		$objCnc->rollback();
		user_error("編集ページ情報の更新に失敗しました。");
	}
	
// 承認/否認
}
else {
	// コンテンツグループ情報を取得
	if ($objCGrp->selectFromID($_POST['cms_group_id']) === FALSE) {
		$objCnc->rollback();
		user_error("この承認依頼は既に変更され作業者に取り戻しまたは公開されています。");
	}
	$cgrp_fld = $objCGrp->fld;
	$order = getOrder($cgrp_fld['status']);
	
	// 不正なステータス
	if ($order == "") {
		$objCnc->rollback();
		user_error("この承認依頼は既に変更され作業者に取り戻しまたは公開されています。");
	}
	
	$now_appr = 4;
	$isFind = ($objLogin->get('isRegain') == TRUE || $objLogin->get('class') == USER_CLASS_WEBMASTER) ? true : false;
	for($i = $order; $i < 4; $i++) {
		// 代理承認の場合はウェブマスター権限
		if ($objLogin->get('isRegain') == TRUE) break;
		$approver = $cgrp_fld['approve' . $i];
		if (strstr($approver, "appr") === FALSE) {
			if ($approver == $objLogin->get('dept_code')) {
				$now_appr = $i;
				$isFind = true;
				break;
			}
		}
		else {
			$approver = str_replace("appr", "", $approver);
			if ($objLogin->get('class') - 1 == $approver) {
				$now_appr = $i;
				$isFind = true;
				break;
			}
		}
	}
	if (!$isFind) {
		user_error("この承認依頼は既に承認されています。");
	}
	// 承認ステータス
	if ($now_appr == 1) {
		$status = 302;
		$approver = $cgrp_fld['approve2'];
	}
	elseif ($now_appr == 2) {
		$status = 303;
		$approver = $cgrp_fld['approve3'];
	}
	elseif ($now_appr == 3) {
		$status = 304;
		$approver = $cgrp_fld['approve4'];
	}
	elseif ($now_appr == 4) {
		$status = 401;
		$approver = '';
	}
	if ($approver == '') {
		if ($cgrp_fld['approve4'] != "") {
			if ($status == 302 || $status == 303) {
				$status = 304;
			}
			else {
				$status = 401;
			}
			$approver = $cgrp_fld['approve4'];
		}
		else {
			$status = 401;
		}
	}
	
	// 否認ステータス
	if ($_POST['cms_dispMode'] == 'denail') {
		$status = 305;
	}
	// 否認の場合、否認理由を格納
	$note2 = ($_POST['cms_dispMode'] == 'denail') ? replaceTextarea($_POST['cms_note2']) : '';
	
	// コンテンツグループ情報の削除：公開待ち
	if ($status == 401) {
		$ary1 = array();
		$ary1['group_id'] = $_POST['cms_group_id'];
		$ary1['status'] = $status;
		$ary1['note2'] = $note2;
		$ary1['approver_id'] = $objLogin->get('user_id');
		$ary1['approve_datetime'] = 'NOW';
		// 公開期間の変更
		if (isset($_POST['cms_publish_start'])) {
			$ary1['publish_start'] = $_POST['cms_publish_start'];
		}
		if (isset($_POST['cms_publish_end'])) {
			$ary1['publish_end'] = $_POST['cms_publish_end'];
		}
		// （UPDATE tbl_contents_group）
		if ($objCGrp->update($ary1) === FALSE) {
			user_error("承認依頼情報の更新に失敗しました。");
		}
		

		// 公開情報, 編集情報を更新を更新
		$ary2 = array();
		$ary2['page_id'] = $listID;
		$ary2['status'] = $status;
		// （UPDATE tbl_publish_page）
		if ($objPage->update($ary2, PUBLISH_TABLE) === FALSE) {
			user_error("公開ページ情報の更新に失敗しました。");
		}
		// 公開期間の変更
		if (isset($_POST['cms_publish_start'])) {
			$ary2['publish_start'] = $_POST['cms_publish_start'];
		}
		if (isset($_POST['cms_publish_end'])) {
			$ary2['publish_end'] = $_POST['cms_publish_end'];
		}
		// （UPDATE tbl_pwork_page）
		if ($objPage->update($ary2, WORK_TABLE) === FALSE) {
			user_error("編集ページ情報の更新に失敗しました。");
		}
		
	// コンテンツグループ情報の更新：承認待ち
	}
	else {
		$ary1 = array();
		$ary1['group_id'] = $_POST['cms_group_id'];
		$ary1['status'] = $status;
		$ary1['note2'] = $note2;
		
		// 移行作業用：否認時ファイル添付機能
		// 移行モードで、否認時の添付ファイル指定がある場合は更新
		if ($status == 305 && IKOU_MODE == TRUE && $save_file_name != '') {
			$ary1['attached_file'] = $save_file_name;
		}
		
		$ary1['approver_id'] = $objLogin->get('user_id');
		$ary1['approve_datetime'] = 'NOW';
		// 否認以外は公開期間の変更を行う
		if ($status != 305) {
			// 公開期間の変更
			if (isset($_POST['cms_publish_start'])) {
				$ary1['publish_start'] = $_POST['cms_publish_start'];
			}
			if (isset($_POST['cms_publish_end'])) {
				$ary1['publish_end'] = $_POST['cms_publish_end'];
			}
		}
		// （UPDATE tbl_contents_group）
		if ($objCGrp->update($ary1) === FALSE) {
			user_error("承認依頼情報の更新に失敗しました。");
		}
		

		// 公開情報, 編集情報を更新を更新
		$ary2 = array();
		$ary2['page_id'] = $listID;
		$ary2['status'] = $status;
		// （UPDATE tbl_publish_page）
		if ($objPage->update($ary2, PUBLISH_TABLE) === FALSE) {
			user_error("公開ページ情報の更新に失敗しました。");
		}
		// 公開期間の変更
		if (isset($_POST['cms_publish_start'])) {
			$ary2['publish_start'] = $_POST['cms_publish_start'];
		}
		if (isset($_POST['cms_publish_end'])) {
			$ary2['publish_end'] = $_POST['cms_publish_end'];
		}
		// （UPDATE tbl_work_page）
		if ($objPage->update($ary2, WORK_TABLE) === FALSE) {
			user_error("編集ページ情報の更新に失敗しました。");
		}
		
		// 否認の場合はひも付けテーブルに保存する
		if ($status == 305 && isset($_POST['cms_denial_page']) && $_POST['cms_denial_page'] != "") {
			$denial_page_ary = explode(',', $_POST['cms_denial_page']);
			$ary_denial['class'] = HANDLER_APPROVE_CLASS_DENAIL_MSG;
			$ary_denial['item2'] = $note2;
			$ary_denial['item3'] = $objLogin->get('user_id');
			$ary_denial['item4'] = date('Y-m-d H:i:s');
			
			// 移行作業用：否認時ファイル添付機能
			// 移行モードの時のみ添付ファイル情報もひも付けテーブルに保存
			if (IKOU_MODE == TRUE && $save_file_name != '') {
				$ary_denial_file['class'] = HANDLER_APPROVE_CLASS_DENIAL_FILE;
				$ary_denial_file['item2'] = $save_file_name;
				$ary_denial_file['item3'] = $ary_denial['item3'];
				$ary_denial_file['item4'] = $ary_denial['item4'];
			}
			
			foreach ($denial_page_ary as $denial_page_id) {
				if ($objAppHandler->delete_denial_msg($denial_page_id) === FALSE) {
					user_error("否認理由の削除に失敗しました。");
				}
				$ary_denial['item1'] = $denial_page_id;
				if ($objAppHandler->insert($ary_denial) === FALSE) {
					user_error("否認理由の登録に失敗しました。");
				}
				
				// 移行作業用：否認時ファイル添付機能
				if (IKOU_MODE == TRUE) {
					// 移行モードの時、対象ページの前回否認時の添付ファイル情報があれば削除
					// (添付ファイル未指定で否認を行った際、1つ前の添付ファイル情報のDLリンクが出てしまう為削除のみここで行う)
					if ($objAppHandler->delete_denial_file($denial_page_id) === FALSE) {
						user_error("否認理由の削除に失敗しました。");
					}
					
					// 否認履歴情報管理テーブルに否認時の情報を保存
					// ※移行作業用処理(insertしてデータを蓄積するのみ。削除は手動で行う必要有)
					require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_ikou_denial_log.inc');
					$obj_denial_log = new tbl_ikou_denial_log($objCnc);
					$denial_log_ary = array();
					$denial_log_ary['page_id'] = $denial_page_id;
					$denial_log_ary['group_id'] = $ary1['group_id'];
					$denial_log_ary['group_name'] = $cgrp_fld['group_name'];
					$denial_log_ary['approve_req_comment'] = $cgrp_fld['note1'];
					$denial_log_ary['denial_reason'] = $ary1['note2'];
					if ($save_file_name != '') {
						// 移行モード時、添付ファイル情報が指定されている場合はハンドラに情報を登録
						$ary_denial_file['item1'] = $denial_page_id;
						if ($objAppHandler->insert($ary_denial_file) === FALSE) {
							user_error("否認理由の登録に失敗しました。");
						}
						
						// 添付ファイル未指定時は否認履歴情報の添付ファイル情報は更新しない。
						$denial_log_ary['attached_file'] = $ary_denial_file['item2'];
					}
					$denial_log_ary['user_id'] = $cgrp_fld['user_id'];
					$denial_log_ary['request_datetime'] = $cgrp_fld['request_datetime'];
					$denial_log_ary['approver_id'] = $ary1['approver_id'];
					$denial_log_ary['approve_datetime'] = 'NOW';
					$denial_log_ary['status'] = $ary1['status'];
					
					// （insert tbl_ikou_denial_log）
					if ($obj_denial_log->insert($denial_log_ary) === FALSE) {
						user_error("否認履歴情報の登録に失敗しました。");
					}
				}
				
			}
		
		}
	}
	
	//--- CMS-8341 Version2 --------------------------------------------------------------------------------------------//
	// ログ登録(承認・否認)
	if($_POST['cms_dispMode'] == 'denail') {
		$log_flg = WRITE_INFO_LOG_DENAIL;
		$log_status = LOG_STATUS_DENAIL;
	}
	else {
		$log_flg = WRITE_INFO_LOG_APPR;
		$log_status = LOG_STATUS_APPR;
	}
	if($log_flg) {
		$objPage->setTableName(PUBLISH_TABLE);
		$objPage->select($objPage->_addslashesC('page_id', $listID, 'IN'));
		while($objPage->fetch()){
			if (set_log_data($log_status, $objPage->fld) === FALSE) {
				$objCnc->rollback();
				user_error("ログ情報の登録に失敗しました。");
			}
		}
	}
	//--- CMS-8341 Version2 --------------------------------------------------------------------------------------------//
	

	// メール送信
	while (1) {
		if (count($aryPage) == 0) break;
		// ページ作成者情報を取得
		$sql = "SELECT user_id,name,dept_name,email,dept_code FROM tbl_user WHERE user_id = " . $cgrp_fld['user_id'];
		if ($objDac->execute($sql) == FALSE) break;
		if (!$objDac->fetch()) break;
		$user_fld = $objDac->fld;
		// 最初の承認者情報を取得するための条件
		$deptInfo = getDeptCode($user_fld['dept_code']);
		$where = '';
		if ($approver == 'appr1') $where = "dept_code = '" . gd_addslashes($deptInfo['dept3_code']) . "'";
		elseif ($approver == 'appr2') $where = "dept_code = '" . gd_addslashes($deptInfo['dept2_code']) . "'";
		elseif ($approver == 'appr3') $where = "dept_code = '" . gd_addslashes($deptInfo['dept1_code']) . "'";
		elseif ($status != 304) $where = "dept_code = '" . gd_addslashes($approver) . "'";
		elseif ($approver == WEB_MASTER_CODE) $where = "class = " . USER_CLASS_WEBMASTER;
		else $where = "user_id = " . $approver;
		if ($where == '') break;
		// （否認）
		if ($_POST['cms_dispMode'] == 'denail') {
			$danail_dt = date('Y年n月j日H時i分');
			// TO:ページ作成者
			if (MAIL_FLG_DENAIL1) {
				// ---メール本文作成用配列
				$mail_fld = array();
				$mail_fld['url'] = HTTP_REAL_ROOT;
				$mail_fld['cms_url'] = HTTP_ROOT . RPW;
				$mail_fld['dept_name'] = $user_fld['dept_name'];
				$mail_fld['user_name'] = $user_fld['name'];
				$mail_fld['request_dept_name'] = $user_fld['dept_name'];
				$mail_fld['request_user_name'] = $user_fld['name'];
				$mail_fld['group_name'] = $cgrp_fld['group_name'];
				$mail_fld['publish_start'] = $cgrp_fld['publish_start'];
				$mail_fld['publish_end'] = $cgrp_fld['publish_end'];
				$mail_fld['login_dept_name'] = $objLogin->get('dept_name');
				$mail_fld['login_user_name'] = $objLogin->get('name');
				$mail_fld['now_date'] = date('Y-m-d H:i:s');
				$mail_fld['approve_note'] = $cgrp_fld['note1'];
				$mail_fld['denail_note'] = $note2;
				$mail_fld['request_page_group'] = $aryPage;
				$head = get_mail_str($mail_fld, MAIL_SUBJECT_DENAIL1);
				$body = get_mail_str($mail_fld, MAIL_BODY_DENAIL1);
				send_mail($user_fld['email'], MAIL_ADDR_FROM, $head, $body);
			}
			// TO:否認した承認者（組織）
			if (MAIL_FLG_DENAIL2) {
				if ($cgrp_fld['status'] == 304 && $cgrp_fld['approve4'] == $objLogin->get('user_id') && $objLogin->get('isOpenUser')) {
					$sql = "SELECT user_id,name,dept_name,email FROM tbl_user WHERE user_id = " . $objLogin->get('user_id');
				}
				else {
					$sql = "SELECT user_id,name,dept_name,email FROM tbl_user WHERE dept_code = '" . $objLogin->get('dept_code') . "' AND class <> '" . USER_CLASS_WRITER . "'";
				}
				if ($objDac->execute($sql) == FALSE) break;
				while ($objDac->fetch()) {
					// ---メール本文作成用配列
					$mail_fld = array();
					$mail_fld['url'] = HTTP_REAL_ROOT;
					$mail_fld['cms_url'] = HTTP_ROOT . RPW;
					$mail_fld['dept_name'] = $objDac->fld['dept_name'];
					$mail_fld['user_name'] = $objDac->fld['name'];
					$mail_fld['request_dept_name'] = $user_fld['dept_name'];
					$mail_fld['request_user_name'] = $user_fld['name'];
					$mail_fld['group_name'] = $cgrp_fld['group_name'];
					$mail_fld['publish_start'] = $cgrp_fld['publish_start'];
					$mail_fld['publish_end'] = $cgrp_fld['publish_end'];
					$mail_fld['login_dept_name'] = $objLogin->get('dept_name');
					$mail_fld['login_user_name'] = $objLogin->get('name');
					$mail_fld['now_date'] = date('Y-m-d H:i:s');
					$mail_fld['approve_note'] = $cgrp_fld['note1'];
					$mail_fld['denail_note'] = $note2;
					$mail_fld['request_page_group'] = $aryPage;
					$head = get_mail_str($mail_fld, MAIL_SUBJECT_DENAIL2);
					$body = get_mail_str($mail_fld, MAIL_BODY_DENAIL2);
					send_mail($objDac->fld['email'], MAIL_ADDR_FROM, $head, $body);					
				}
			}
			
		// （承認）TO:次の承認者
		}
		elseif ($status != 401 && $approver != '' && MAIL_FLG_APPROVE) {
			if (substr($where, 0, 5) == 'class') {
				$sql = "SELECT user_id,name,dept_name,email,dept_code" . " FROM tbl_user AS u LEFT JOIN tbl_handler AS h ON (h.class = " . HANDLER_CLASS_OEPN_FLG . " AND h.item1 = u.user_id)" . " WHERE u.class = " . USER_CLASS_WEBMASTER . " AND h.item1 IS NULL";
			}
			else {
				$sql = "SELECT user_id,name,dept_name,email,dept_code FROM tbl_user WHERE class <> '" . USER_CLASS_WRITER . "' AND " . $where;
			}
			if ($objDac->execute($sql) == FALSE) break;
			while ($objDac->fetch()) {
				if (substr($where, 0, 9) == 'dept_code') {
					$dept_name = $objDac->fld['dept_name'] . " 承認者";
				}
				elseif (substr($where, 0, 7) == 'user_id') {
					$dept_name = $objDac->fld['dept_name'] . " " . $objDac->fld['name'] . "様";
				}
				else {
					$dept_name = 'ウェブマスター';
				}
				// ---メール本文作成用配列
				$mail_fld = array();
				$mail_fld['url'] = HTTP_REAL_ROOT;
				$mail_fld['cms_url'] = HTTP_ROOT . RPW;
				$mail_fld['now_date'] = date('Y-m-d H:i:s');
				$mail_fld['approve_name'] = $dept_name;
				$mail_fld['dept_name'] = $objDac->fld['dept_name'];
				$mail_fld['user_name'] = $objDac->fld['name'];
				$mail_fld['request_dept_name'] = $user_fld['dept_name'];
				$mail_fld['request_user_name'] = $user_fld['name'];
				$mail_fld['group_name'] = $cgrp_fld['group_name'];
				$mail_fld['publish_start'] = $cgrp_fld['publish_start'];
				$mail_fld['publish_end'] = $cgrp_fld['publish_end'];
				$mail_fld['login_dept_name'] = $objLogin->get('dept_name');
				$mail_fld['login_user_name'] = $objLogin->get('name');
				$mail_fld['now_date'] = date('Y-m-d H:i:s');
				$mail_fld['approve_note'] = $cgrp_fld['note1'];
				$mail_fld['request_page_group'] = $aryPage;
				$head = get_mail_str($mail_fld, MAIL_SUBJECT_APPROVE);
				$body = get_mail_str($mail_fld, MAIL_BODY_APPROVE);
				send_mail($objDac->fld['email'], MAIL_ADDR_FROM, $head, $body);
			}
		}
		break;
	}
	// スキップ承認した場合は承認依頼者であった人にスキップした旨のメールを出す
	if (isset($_POST['cms_isSkip']) && $_POST['cms_isSkip'] == FLAG_ON && MAIL_FLG_SKIP) {
		$exec = "";
		$status_name = '';
		if ($_POST['cms_dispMode'] == 'denail') {
			$exec = "により否認になりました。";
			$status_name = '否認';
		}
		else {
			$exec = "の承認により" . getStatusName($status) . "になりました。";
			$status_name = getStatusName($status);
		}
		$order = getOrder($cgrp_fld['status']);
		$approver = $cgrp_fld['approve' . $order];
		
		// 承認者情報を取得するための条件
		$where = "user_id = '" . gd_addslashes($cgrp_fld['user_id']) . "'";
		$objDac->setTableName("tbl_user");
		$objDac->select($where);
		$objDac->fetch();
		$deptInfo = getDeptCode($objDac->fld['dept_code']);
		if ($approver == 'appr1') $where = "class='" . USER_CLASS_APPROVER1 . "' AND dept_code = '" . gd_addslashes($deptInfo['dept3_code']) . "'";
		elseif ($approver == 'appr2') $where = "class='" . USER_CLASS_APPROVER2 . "' AND dept_code = '" . gd_addslashes($deptInfo['dept2_code']) . "'";
		elseif ($approver == 'appr3') $where = "class='" . USER_CLASS_APPROVER3 . "' AND dept_code = '" . gd_addslashes($deptInfo['dept1_code']) . "'";
		elseif ($status != 304) $where = "class != '" . USER_CLASS_WRITER . "' AND dept_code = '" . gd_addslashes($approver) . "'";
		elseif ($approver == WEB_MASTER_CODE) $where = "class = " . USER_CLASS_WEBMASTER;
		// ページ承認者情報を取得
		$sql = "SELECT login_id,user_id,name,dept_name,email,dept_code FROM tbl_user WHERE " . $where;
		if ($objDac->execute($sql)) {
			while ($objDac->fetch()) {
				// ---メール本文作成用配列
				$mFld = $objDac->fld;
				$mail_fld = array();
				$mail_fld['url'] = HTTP_REAL_ROOT;
				$mail_fld['cms_url'] = HTTP_ROOT . RPW;
				$mail_fld['now_date'] = date('Y-m-d H:i:s');
				$mail_fld['dept_name'] = $mFld['dept_name'];
				$mail_fld['user_name'] = $mFld['name'];
				$mail_fld['skip_status'] = $status_name;
				$mail_fld['group_name'] = $cgrp_fld['group_name'];
				$mail_fld['login_dept_name'] = $objLogin->get('dept_name');
				$mail_fld['login_user_name'] = $objLogin->get('name');
				$mail_fld['request_dept_name'] = $user_fld['dept_name'];
				$mail_fld['request_user_name'] = $user_fld['name'];
				$mail_fld['request_page_group'] = $aryPage;
				$head = get_mail_str($mail_fld, MAIL_SUBJECT_SKIP);
				$body = get_mail_str($mail_fld, MAIL_BODY_SKIP);
				send_mail($mFld['email'], MAIL_ADDR_FROM, $head, $body);
			}
		}
	}

}

$objCnc->commit();

$open_status = '';
if (isset($status)) {
	if ($status == 401) $open_status = '?open=w';
	elseif (301 <= $status && $status <= 304) $open_status = '?open=p';
}

// ワークフローへ移動
header("Location: " . HTTP_ROOT . RPW . "/admin/page/workflow/workflow.php" . $open_status);
?>