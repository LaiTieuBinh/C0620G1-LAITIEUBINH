<?php
/*
 *
 */
/** リンクチェック **/
require ("../.htsetting");

// 別ウィンドウ用
gd_errorhandler_ini_set("template_user_error", "template_user_error_win");
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$objLinks = new tbl_links($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_links.inc');
$objFCKLinks = new tbl_fck_links($objCnc);

// 対象のファイルパスが渡されなければエラー
if (!isset($_POST['cms_file_path']) || $_POST['cms_file_path'] == "") {
	user_error("パラメーターエラー", E_USER_ERROR);
}
$file_path = $_POST['cms_file_path'];

$page_id_ary = array();
//公開ページリンク情報取得
$objLinks->useLinkFileCheck($file_path, PUBLISH_TABLE);
while ($objLinks->fetch()) {
	$page_id_ary[] = $objLinks->fld['page_id'];
}

//編集ページリンク情報取得
$objLinks->useLinkFileCheck($file_path, WORK_TABLE);
while ($objLinks->fetch()) {
	$page_id_ary[] = $objLinks->fld['page_id'];
}

//公開ページイメージ情報取得
$objImages->useImageCheck($file_path, PUBLISH_TABLE);
while ($objImages->fetch()) {
	$page_id_ary[] = $objImages->fld['page_id'];
}

//編集ページイメージ情報取得
$objImages->useImageCheck($file_path, WORK_TABLE);
while ($objImages->fetch()) {
	$page_id_ary[] = $objImages->fld['page_id'];
}

//取得したページIDの重複削除
$page_id_ary = array_unique($page_id_ary);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>使用ページチェック結果</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/linkcheck.css"
	type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/treelist.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
</head>

<body>
<form name="cms_fTreeList" id="cms_fTreeList" class="cms8341-form"
	method="post" action=""><input type="hidden" name="cms_dispMode"
	id="cms_dispMode" value=""> <input type="hidden" name="cms_page_id"
	id="cms_page_id" value=""></form>
<div id="cms8341-linkcheck">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/usefile/title_usefile_check.jpg"
					alt="使用ページチェック結果" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="cxIframeLayerCallback()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div id="cms8341-checklistarea">
		<div align="center">
		<table width="430" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left" valign="top">
				<p>【<?=htmlDisplay($file_path)?>】</p>
				<p><img src="<?=RPW?>/admin/images/usefile/bar_usefile.jpg"
					alt="使用ページリスト" width="430" height="20"></p>

<?php
if (count($page_id_ary) > 0) {
	foreach ((array) $page_id_ary as $page_id) {
		if(!$objPage->selectFromID($page_id,WORK_TABLE)){
			if(!$objPage->selectFromID($page_id)){
				user_error("ページ情報取得失敗【ページID=" . $page_id . "】", E_USER_ERROR);
			}
		}

		$fld = $objPage->fld;
		
		//アイコン情報を取得
		$ret_ary = get_status_icon($fld);
		
		print '<p class="cms8341-normal"><img src="' . RPW . '/admin/images/treelist/' . $ret_ary['wc_img'] . '" alt="' . $ret_ary['wc_alt'] . '" width="59" height="16" class="icon">';
		if ($fld['work_class'] == 3 || $fld['status'] == 402) {
			print '<a href="javascript:" onClick="return cxPreview(\'cms_fTreeList\',' . $fld['page_id'] . ',\'1\')">' . htmlDisplay($fld['page_title']) . '</a>&nbsp;（' . $fld['file_path'] . '）</p>' . "\n";
		}
		else {
			print '<a href="javascript:" onClick="return cxPreview(\'cms_fTreeList\',' . $fld['page_id'] . ',\'2\')">' . htmlDisplay($fld['page_title']) . '</a>&nbsp;（' . $fld['file_path'] . '）</p>' . "\n";
		}
	}
}
else {
	print '<p class="cms8341-normal">依存ファイルを使用しているページはありません。</p>';
}

echo ('</td>' . "\n");
echo ('</tr>' . "\n");
echo ('</table>' . "\n");
echo ('</div>' . "\n");
echo ('</div></td>' . "\n");
echo ('</tr>' . "\n");
echo ('</table>' . "\n");
echo ('</div>' . "\n");
echo ('</body>' . "\n");
echo ('</html>' . "\n");
?>