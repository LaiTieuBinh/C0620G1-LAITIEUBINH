<?php
/*
 * 新規ページ作成処理
 */
require ("../.htsetting");

// 親ページIDが渡されなければエラー(空白が渡されることはある)
if (!isset($_POST['cms_parent_id'])) {
	user_error("It isn't setted cms_parent_id in _post.", E_USER_ERROR);
}
// テンプレート種類が渡されなければエラー
if (!isset($_POST['cms_template_kind'])) {
	user_error("It isn't setted cms_template_kind in _post.", E_USER_ERROR);
}
$tpl_kind = $_POST['cms_template_kind'];

// ファイル名を小文字に変換
$_POST['cms_filename'] = strtolower($_POST['cms_filename']);

$filename = DOCUMENT_ROOT . RPW . $_POST['cms_dir_path'] . $_POST['cms_filename'];
if (@file_exists($filename)) {
	user_error($filename . ' は既に存在します。');
}

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInquiry = new tbl_inquiry($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete.inc');
$objEnq = new tbl_enquete($objCnc);
$objEnq2 = new tbl_enquete($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete_detail.inc');
$objEnqDtl = new tbl_enquete_detail($objCnc);
$objEnqDtl2 = new tbl_enquete_detail($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFaq = new tbl_faq($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output_handler.inc');
$objOpHndl = new tbl_output_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_library.inc');
$objLibrary = new tbl_library($objCnc);
// イベントカレンダー複数日
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_event.inc');
$obj_event = new tbl_event($objCnc);

//携帯ページ自動掲載用ファイルパス
$mobile_filename = DOCUMENT_ROOT . RPW . DIR_PATH_MOBILE . $_POST['cms_dir_path'] . $_POST['cms_filename'];
if ($objTool->selectTemplate($_POST['cms_template_id'])) {
	if ($objTool->fld['mobile_temp_txt'] != "") {
		if (@file_exists($mobile_filename)) {
			user_error($mobile_filename . ' は既に存在します。');
		}
	}
}

// 保存先の権限チェック（ウェブマスターでなければ、権限のあるディレクトリ以外に保存できない）
if (($objLogin->get('class') != USER_CLASS_WEBMASTER) && !$objHandler->IsEditableDir($objLogin->get('dept_code'), $_POST['cms_dir_path'])) {
	user_error('保存先のフォルダはページの編集権限がありません。');
}

// カテゴリコード
$cate_code = $_POST['cms_cate1']; // 第一カテゴリ（必須）しか選択されていなければ$_POST['cms_cate1']がカテゴリコードになる
if (isset($_POST['cms_cate2']) && $_POST['cms_cate2']) $cate_code = $_POST['cms_cate2']; // 第二カテゴリが選択されていれば$_POST['cms_cate2']がカテゴリコードになる
if (isset($_POST['cms_cate3']) && $_POST['cms_cate3']) $cate_code = $_POST['cms_cate3']; // 第三カテゴリが選択されていれば$_POST['cms_cate3']がカテゴリコードになる
if (isset($_POST['cms_cate4']) && $_POST['cms_cate4']) $cate_code = $_POST['cms_cate4']; // 第四カテゴリが選択されていれば$_POST['cms_cate4']がカテゴリコードになる


$parent_fld = NULL;
//親ページなしフラグが無く、親ページIDに空白以外が渡された場合
if (!(isset($_POST['cms_parent_id_none']) && $_POST['cms_parent_id_none'] != "") && isset($_POST['cms_parent_id']) && $_POST['cms_parent_id'] != "") {
	// 親ページ情報（tbl_publish_pageから）の取得配列$parent_fldに格納
	if ($objPage->selectFromID($_POST['cms_parent_id'], 1) === FALSE) {
		if ($objPage->selectFromPath(SITE_TOP_PAGE) === FALSE) {
			user_error("Can't find parent page data.<br>cms_parent_id[" . $_POST['cms_parent_id'] . "]", E_USER_ERROR);
		}
		$_POST['cms_parent_id'] = $objPage->fld['page_id'];
	}
	$parent_fld = $objPage->fld;
}

// テンプレート読み込み
if ($objTool->selectTemplate($_POST['cms_template_id']) === FALSE) {
	user_error("Can't find template data.<br>dac_tools selectTemplate(" . $_POST['cms_template_id'] . ")", E_USER_ERROR);
}
$template_path = DOCUMENT_ROOT . DIR_PATH_TEMPLATE . $objTool->fld['temp_txt'];
if (!file_exists($template_path)) {
	user_error("The template file doesn't exist.<br>temp_txt[" . $objTool->fld['temp_txt'] . "]", E_USER_ERROR);
}
// テンプレートのバージョン（最新バージョン）
$template_ver = $objTool->fld['template_ver'];
// 観光種類
$kanko_type = $objTool->fld['kanko_type'];
$kanko_xml = $objTool->fld['kanko_xml'];
$template_id = $objTool->fld['template_id'];
// 使用できないライブラリ一覧
$nonuse_library_id = $objTool->fld['nonuse_library_id'];
$nonuse_library_id_Ary = explode(",", $nonuse_library_id);

$fp = fopen($template_path, "r");
$htmlStr = fread($fp, filesize($template_path));
fclose($fp);
//複製なら、元ページの情報を取得
$copyTbl = WORK_TABLE;
if ($_POST['cms_dispMode'] == "copy" || $_POST['cms_dispMode'] == "disaster") {
	$copyTbl = WORK_TABLE;
	//ワークテーブルの情報を取得
	$objPage->selectFromID($_POST['cms_copy_page_id'], WORK_TABLE);
	//ワークテーブルに情報が存在しない
	if ($objPage->getRowCount() == 0) {
		$copyTbl = PUBLISH_TABLE;
		//公開テーブルの情報を取得
		$objPage->selectFromID($_POST['cms_copy_page_id'], PUBLISH_TABLE);
		//公開テーブルに情報が存在しない
		if ($objPage->getRowCount() == 0) {
			user_error(($_POST['cms_dispMode'] == "copy" ? "複製元" : "緊急情報元") . "のページが見つかりません。");
		}
	}
	$context = $objPage->fld['context'];
}
else {
	$context = getMidString($htmlStr, '<!-- InstanceBeginEditable name="contents" -->', '<!-- InstanceEndEditable -->');
}
if (!isset($context) || $context === FALSE) $context = '';
// 編集領域へ自動挿入
$context = str_replace("<!-- page_title area -->", $_POST['cms_page_title'], $context);
// イベントカレンダー複数日
if (EVENT_CAL_MULTI_FLAG) {
	$open_date = array();
	$open_start_count = count($_POST['cms_pdsy']);
	for($i = 0; $i < $open_start_count; $i++) {
		// 開始時間が設定されていない場合
		if (intval($_POST['cms_pdsh'][$i]) == 0 && intval($_POST['cms_pdsi'][$i]) == 0) {
			$open_start_time = '';
		}
		else {
			$open_start_time = $_POST['cms_pdsh'][$i] . '時' . $_POST['cms_pdsi'][$i] . '分';
		}
		
		// 終了時間が設定されている場合
		if (intval($_POST['cms_pdeh'][$i]) == 0 && intval($_POST['cms_pdei'][$i]) == 0) {
			$open_end_time = '';
		}
		else {
			$open_end_time = $_POST['cms_pdeh'][$i] . '時' . $_POST['cms_pdei'][$i] . '分';
		}
		
		// 日時を配列に格納
		if (empty($_POST['cms_pdey'][$i])) {
			$open_date[] = '<li>' . $_POST['cms_pdsy'][$i] . '年' . $_POST['cms_pdsm'][$i] . '月' . $_POST['cms_pdsd'][$i] . '日&nbsp;' . $open_start_time . '</li>';
		}
		else {
			$open_date[] = '<li>' . $_POST['cms_pdsy'][$i] . '年' . $_POST['cms_pdsm'][$i] . '月' . $_POST['cms_pdsd'][$i] . '日&nbsp;' . $open_start_time . '～' . $_POST['cms_pdey'][$i] . '年' . $_POST['cms_pdem'][$i] . '月' . $_POST['cms_pded'][$i] . '日&nbsp;' . $open_end_time . '</li>';
		}
	}
	$context = str_replace("<!-- open_date area -->", '<ul>' . implode('', $open_date) . '</ul>', $context);
}
// イベントカレンダー単一日
else {
	$open_start = $_POST['cms_pdsy'] . '年' . $_POST['cms_pdsm'] . '月' . $_POST['cms_pdsd'] . "日";
	$open_end = $_POST['cms_pdey'] . '年' . $_POST['cms_pdem'] . '月' . $_POST['cms_pded'] . "日";
	$context = str_replace("<!-- open_start area -->", $open_start, $context);
	$context = str_replace("<!-- open_end area -->", $open_end, $context);
}

// ぱんくずパス
if (!($tpl_kind == TEMPLATE_KIND_FIXED && $kanko_type == KANKO_TYPE_EVENT) && $_POST['cms_dispMode'] != "faq") {
	$ancestor_path = ($parent_fld['ancestor_path'] != '') ? $parent_fld['ancestor_path'] . ',' : '';
	$ancestor_path .= $parent_fld['file_path'];
	$parent_id = $parent_fld['page_id'];
}
else {
	$objPage->selectFromPath(SITE_TOP_PAGE);
	$ancestor_path = SITE_TOP_PAGE;
	$parent_id = $objPage->fld['page_id'];
}

// 新しいページIDの取得
$PID = $objPage->getSeqNextval();
$inquiry_id = "";
$inquiry_flg = FLAG_OFF;
if ((isset($_POST['cms_inquiry_cnt']) && $_POST['cms_inquiry_cnt'] > 0) || $_POST['cms_inquiry_memo'] != "") {
	$inquiry_id = $objInquiry->getSeqNextval();
	$inquiry_flg = FLAG_ON;
}

// 登録情報のセット
$ary1 = array();
$ary1['page_id'] = $PID;
$ary1['cate_code'] = $cate_code;
$ary1['template_id'] = $_POST['cms_template_id'];
$ary1['template_ver'] = $template_ver;
$ary1['parent_id'] = $parent_id;
$ary1['ancestor_path'] = $ancestor_path;
$ary1['user_id'] = $objLogin->get('user_id');
$ary1['dir_path'] = $_POST['cms_dir_path'];
$ary1['filename'] = $_POST['cms_filename'];
$ary1['file_path'] = $_POST['cms_dir_path'] . $_POST['cms_filename'];
$ary1['page_title'] = $_POST['cms_page_title'];
$ary1['header'] = $_POST['cms_page_title'];
$ary1['context'] = $context;
$ary1['keywords'] = str_replace("、", ",", $_POST['cms_keywords']);
$ary1['description'] = $_POST['cms_description'];
$ary1['summary'] = $_POST['cms_summary'];
$ary1['index_title'] = $_POST['cms_index_title'];
$ary1['contents_top_flg'] = (isset($_POST['cms_contents_top_flg'])) ? $_POST['cms_contents_top_flg'] : 0;
$ary1['status'] = STATUS_RESERVE;
$ary1['template_kind'] = $_POST['cms_template_kind'];
if ((isset($_POST['cms_faq_id']))) {
	$ary1['faq_id'] = $_POST['cms_faq_id'];
}
$ary1['menu_generation_order'] = $objPage->getNextMenuGenerationOrder($parent_id);

// イベント
if ($tpl_kind == TEMPLATE_KIND_FIXED && $kanko_type == KANKO_TYPE_EVENT) {
	// 開催日を設定
	// イベントカレンダー複数日
	if (EVENT_CAL_MULTI_FLAG) {
		$ch_open_date_ary = array();
		
		// 開催日の要素数を取得
		$open_start_count = count($_POST['cms_pdsy']);
		
		// 要素ごとに開催日を変数に格納
		for($i = 0; $i < $open_start_count; $i++) {
			// 開始日が空の場合はスキップ
			if (empty($_POST['cms_pdsy'][$i]) && empty($_POST['cms_pdsm'][$i]) && empty($_POST['cms_pdsd'][$i])) {
				continue;
			}
			
			// 開始時間
			if (intval($_POST['cms_pdsh'][$i]) == 0 && intval($_POST['cms_pdsi'][$i]) == 0) {
				$pdsh = '00';
				$pdsi = '00';
			}
			else {
				//0埋め
				$pdsh = sprintf("%02d", $_POST['cms_pdsh'][$i]);
				$pdsi = sprintf("%02d", $_POST['cms_pdsi'][$i]);
			}
			
			// 終了時間
			if (intval($_POST['cms_pdeh'][$i] == 0) && intval($_POST['cms_pdei'][$i]) == 0) {
				$pdeh = '00';
				$pdei = '00';
			}
			else {
				// 0埋め
				$pdeh = sprintf("%02d", $_POST['cms_pdeh'][$i]);
				$pdei = sprintf("%02d", $_POST['cms_pdei'][$i]);
			}
			
			// 日時を配列に格納
			$open_start = $_POST['cms_pdsy'][$i] . '-' . $_POST['cms_pdsm'][$i] . '-' . $_POST['cms_pdsd'][$i] . ' ' . $pdsh . ':' . $pdsi . ':00';
			if (strlen($_POST['cms_pdey'][$i] . $_POST['cms_pdem'][$i] . $_POST['cms_pded'][$i]) > 0) {
				$open_end = $_POST['cms_pdey'][$i] . '-' . $_POST['cms_pdem'][$i] . '-' . $_POST['cms_pded'][$i] . ' ' . $pdeh . ':' . $pdei . ':00';
			}
			else {
				$open_end = '';
			}
			
			// 集約チェック用開催期間配列に情報を格
			$ch_open_date_ary[] = array(
				// 「datetime」型から日付形式に変更
				'open_start' => str_replace('-', '/', $open_start),
				'open_end' => str_replace('-', '/', $open_end)
			);
		}
		// 開催期間の集約
		$merge_open_date_ary = cxMergeOpenDate($ch_open_date_ary, 'simple');
		foreach ((array) $merge_open_date_ary as $merge_open_date) {
			// 日付形式から「datetime」型に変更
			$ary1['open_start'][] = str_replace('/', '-', $merge_open_date['open_start']);
			$ary1['open_end'][] = str_replace('/', '-', $merge_open_date['open_end']);
		}
	}
	// イベントカレンダー単一日
	else {
		$ary1['open_start'] = $_POST['cms_pdsy'] . '-' . $_POST['cms_pdsm'] . '-' . $_POST['cms_pdsd'] . ' 00:00:00';
		if (strlen($_POST['cms_pdey'] . $_POST['cms_pdem'] . $_POST['cms_pded']) > 0) {
			$ary1['open_end'] = $_POST['cms_pdey'] . '-' . $_POST['cms_pdem'] . '-' . $_POST['cms_pded'] . ' 00:00:00';
		}
	}
}
// アンケート
if ($tpl_kind == TEMPLATE_KIND_ENQUETE) {
	// アンケート種別を設定
	$ary1['enquete_kind'] = $_POST['cms_enquete_kind'];
	$ary1['enquete_status'] = 100;
	if ($_POST['cms_enquete_kind'] == ENQ_KIND_MAIL && isset($_POST['cms_enq_email'])) {
		$ary1['enquete_email'] = $_POST['cms_enq_email'];
	}
}

$ary1['inquiry_memo'] = $_POST['cms_inquiry_memo'];
$ary1['inquiry_id'] = $inquiry_id;
$ary1['inquiry_flg'] = $inquiry_flg;
// ウェブマスターの新規作成のときは有効期限を登録する
if ($objLogin->get('class') == USER_CLASS_WEBMASTER) {
	$Y = date('Y');
	$n = date('n');
	$j = date('j');
	$H = date('H');
	$ary1['publish_start'] = $Y . '-' . $n . '-' . $j . ' ' . $H . ':00:00';
	
	$Y = date('Y', strtotime("+" . PUBLISH_END_MONTH . " month"));
	$n = date('n', strtotime("+" . PUBLISH_END_MONTH . " month"));
	$j = date('j', strtotime("+" . PUBLISH_END_MONTH . " month"));
	$ary1['publish_end'] = $Y . '-' . $n . '-' . $j . ' ' . $H . ':00:00';
}

$auto_op_fld_ary = array();
// 外部連携機能がONの場合
if (ENABLE_OPTION_OUTPUT) {
	// 外部出力データID取得
	$op_id_ary = getOutputTemplateFromTemplateId($ary1['template_id']);
	// 外部出力IDの中から自動出力形式の情報を取得
	$auto_op_fld_ary = getAutoOutputFromOutputId($op_id_ary, 2);
}
if (count($auto_op_fld_ary) > 0) {
	if (isset($_POST['cms_output_html_flg']) || $_POST['cms_dispMode'] == "disaster") {
		$ary1['output_html_flg'] = FLAG_ON;
	}
	else {
		$ary1['output_html_flg'] = FLAG_OFF;
	}
}
else {
	$ary1['output_html_flg'] = FLAG_ON;
}

$objCnc->begin();

// 公開情報の登録（INSERT INTO tbl_publish_page）
if ($objPage->insert($ary1, PUBLISH_TABLE) === FALSE) {
	user_error("ページの新規作成に失敗しました。", E_USER_ERROR);
}

// イベントカレンダー複数日
if (EVENT_CAL_MULTI_FLAG) {
	// イベントの登録（INSERT INTO tbl_work_event）
	if ($tpl_kind == TEMPLATE_KIND_FIXED && $kanko_type == KANKO_TYPE_EVENT) {
		if ($obj_event->insert($ary1, WORK_TABLE) === FALSE) {
			user_error('開催期間の登録に失敗しました。', E_USER_ERROR);
		}
	}
}

// オープンデータ
// noを初期化
$opendata_no = 0;
// ページをオープンデータとして登録
if (isset($_POST['opendata_id'])) {
	if (setOpenData($PID, $_POST, $opendata_no) == FALSE) {
		user_error('オープンデータ情報の登録に失敗しました。', E_USER_ERROR);
	}	
}

// 問い合わせの登録 (INSERT INTO tbl_publish_inquiry)
// 新しい問い合わせIDの取得
$no = 1;
for($i = 1; $i < $_POST['cms_inquiry_cnt'] + 1; $i++) {
	if (!isset($_POST['cms_inquiry_dept1_' . $i])) continue;
	$dept_code = "";
	$inq_ary = array();
	$inq_ary['inquiry_id'] = $inquiry_id;
	$inq_ary['inquiry_no'] = $no;
	if ($_POST['cms_inquiry_dept3_' . $i]) {
		$dept_code = $_POST['cms_inquiry_dept3_' . $i];
	}
	else if ($_POST['cms_inquiry_dept2_' . $i]) {
		$dept_code = $_POST['cms_inquiry_dept2_' . $i];
	}
	else if ($_POST['cms_inquiry_dept1_' . $i]) {
		$dept_code = $_POST['cms_inquiry_dept1_' . $i];
	}
	$inq_ary['dept_code'] = $dept_code;
	$inq_ary['name'] = $_POST['cms_inquiry_charge_' . $i];
	$inq_ary['anex_number'] = $_POST['cms_inquiry_anExtensionNumber_' . $i];
	$inq_ary['drxt_number'] = $_POST['cms_inquiry_directNumber_' . $i];
	$inq_ary['fax'] = $_POST['cms_inquiry_fax_' . $i];
	$inq_ary['email'] = $_POST['cms_inquiry_email_' . $i];
	if ($inq_ary['dept_code'] == "" && $inq_ary['name'] == "" && $inq_ary['anex_number'] == "" && $inq_ary['drxt_number'] == "" && $inq_ary['fax'] == "") {
		continue;
	}
	if ($objInquiry->insert($inq_ary, WORK_TABLE) === FALSE) {
		user_error("ページの新規作成に失敗しました。", E_USER_ERROR);
	}
	
	$no++;
}

if ($objInquiry->insertWorkFromPublish($inquiry_id) === FALSE) {
	user_error("ページの新規作成に失敗しました。", E_USER_ERROR);
}

// 編集情報の登録（INSERT INTO tbl_work_page SELECT FROM tbl_work_page）
$objPage->insertWorkFromPublish($PID, $objLogin->login);

// 自動リンク依頼の登録
if (entryAutolink($_POST['cms_a_link_id'], $PID) === FALSE) {
	user_error('自動リンク依頼の登録に失敗しました。', E_USER_ERROR);
}

if ($tpl_kind == TEMPLATE_KIND_ENQUETE && ($_POST['cms_dispMode'] == "copy" || $_POST['cms_dispMode'] == "disaster")) {
	//コピー元のページ情報を取得
	$objPage->selectFromID($_POST['cms_copy_page_id'], PUBLISH_TABLE);
	if ($objPage->fld['work_class'] == WORK_CLASS_NEW || $objPage->fld['work_class'] == WORK_CLASS_PUBLISH && $objPage->fld['status'] < STATUS_PUBLISH) {
		//編集テーブルの情報を取得
		$tbl = WORK_TABLE;
	}
	else {
		//公開テーブルの情報を取得
		$tbl = PUBLISH_TABLE;
	}
	$objEnq->selectFromPID($_POST['cms_copy_page_id'], $tbl);
	if ($objEnq->getRowCount() != 0) {
		while ($objEnq->fetch()) {
			$efld = $objEnq->fld;
			$old_enquete_id = $efld['enquete_id'];
			$enquete_id = $objEnq2->getSeqNextval();
			$efld['enquete_id'] = $enquete_id;
			$efld['page_id'] = $PID;
			if ($objEnq2->insert($efld, PUBLISH_TABLE) === FALSE) {
				user_error("ページの新規作成に失敗しました。", E_USER_ERROR);
			}
			// WORKテーブルにもPUBLISHと同じデータをINSERTする
			if ($objEnq2->insert($efld, WORK_TABLE) === FALSE) {
				user_error("ページの新規作成に失敗しました。", E_USER_ERROR);
			}
			
			$objEnqDtl->selectFromEID($old_enquete_id, $tbl);
			while ($objEnqDtl->fetch()) {
				$dfld = $objEnqDtl->fld;
				$dfld['enquete_id'] = $enquete_id;
				if ($objEnqDtl2->insert($dfld, PUBLISH_TABLE) === FALSE) {
					user_error("ページの新規作成に失敗しました。", E_USER_ERROR);
				}
				// WORKテーブルにもPUBLISHと同じデータをINSERTする
				if ($objEnqDtl2->insert($dfld, WORK_TABLE) === FALSE) {
					user_error("ページの新規作成に失敗しました。", E_USER_ERROR);
				}
			}
		}
	}
}
elseif ($tpl_kind == TEMPLATE_KIND_ENQUETE && $_POST['cms_enquete_kind'] == ENQ_KIND_MAIL) {
	$con_cnt = 0;
	foreach ($ENQ_DEF_CONTROL_ARY as $control) {
		$con_cnt = $con_cnt + 1;
		$enq_ary = array();
		$enquete_id = $objEnq->getSeqNextval();
		$enq_ary['enquete_id'] = $enquete_id;
		$enq_ary['page_id'] = $PID;
		$enq_ary['name'] = $control['name'];
		$enq_ary['sort_order'] = $con_cnt;
		$enq_ary['require_flg'] = $control['require_flg'];
		$enq_ary['comment'] = $control['comment'];
		$enq_ary['control_kind'] = $control['control_kind'];
		$enq_ary['desc_mail_flg'] = $control['desc_mail_flg'];
		if ($objEnq2->insert($enq_ary, PUBLISH_TABLE) === FALSE) {
			user_error("ページの新規作成に失敗しました。", E_USER_ERROR);
		}
		if ($objEnq2->insert($enq_ary, WORK_TABLE) === FALSE) {
			user_error("ページの新規作成に失敗しました。", E_USER_ERROR);
		}
		$objEnqDtl->add_where("enquete_id", $enquete_id);
		$objEnqDtl->delete("", PUBLISH_TABLE);
		$objEnqDtl->add_where("enquete_id", $enquete_id);
		$objEnqDtl->delete("", WORK_TABLE);
		$detail_cnt = 0;
		foreach ($control['detail'] as $item) {
			$detail_cnt = $detail_cnt + 1;
			$enq_dtl_ary = array();
			$enq_dtl_ary['enquete_id'] = $enquete_id;
			$enq_dtl_ary['enquete_no'] = $detail_cnt;
			$enq_dtl_ary['setting_info1'] = $item['setting_info1'];
			$enq_dtl_ary['setting_info2'] = $item['setting_info2'];
			$enq_dtl_ary['setting_info3'] = $item['setting_info3'];
			$enq_dtl_ary['setting_info4'] = $item['setting_info4'];
			$enq_dtl_ary['setting_info5'] = $item['setting_info5'];
			if ($objEnqDtl->insert($enq_dtl_ary, PUBLISH_TABLE) === FALSE) {
				user_error("ページの新規作成に失敗しました。", E_USER_ERROR);
			}
			if ($objEnqDtl->insert($enq_dtl_ary, WORK_TABLE) === FALSE) {
				user_error("ページの新規作成に失敗しました。", E_USER_ERROR);
			}
		}
	}
}

// 観光情報
$fixed_chk = array();
$fixed_chk["template_kind"] = $_POST['cms_template_kind'];
$fixed_chk["template_id"] = $_POST['cms_template_id'];
$fixed_chk["template_ver"] = $template_ver;
$fixed_chk["kanko_xml"] = $kanko_xml;
if (isFixed($fixed_chk)) {
	if (!isset($link_no)) $link_no = 0;
	if (!isset($img_no)) $img_no = 0;
	// オープンデータ
	// 定型typeオープンデータ
	if (!isset($opendata_no)) {
		$opendata_no = 0;
	}
	$no = setData($PID, $_POST, $link_no, $img_no, $opendata_no);
	setDefData($PID, $_POST['cms_template_id'], $no);
	//複製の場合
	if ($_POST['cms_dispMode'] == "copy" || $_POST['cms_dispMode'] == "disaster") {
		require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
		$objKanko = new tbl_kanko($objCnc);
		$objKanko->copy($_POST['cms_copy_page_id'], $PID, "page");
		//複製元FlashVideoフォルダから、複製先のFlashVideoフォルダにデータをコピーする
		if (!copyFlashVideoFolderFromPageId($_POST['cms_copy_page_id'], $PID)) {
			user_error("ページの複製に失敗しました。", E_USER_ERROR);
		}
	}
	// 外部出力先登録
	if (isset($_POST['cms_output']) && count($_POST['cms_output']) > 0 && $_POST['cms_dispMode'] != "disaster") {
		foreach ($_POST['cms_output'] as $output_id) {
			$insAry = array();
			$insAry['class'] = HANDLER_OUTPUT_CLASS_WORK_PAGE;
			$insAry['output_id'] = $output_id;
			$insAry['page_id'] = $PID;
			if ($objOpHndl->insertPage($insAry) === FALSE) {
				user_error("外部出力先の登録に失敗しました。", E_USER_ERROR);
			}
		}
	}
}

// オープンデータ
// オープンデータ機能 ページの複製対応
//複製の場合
if ($_POST['cms_dispMode'] == "copy" || $_POST['cms_dispMode'] == "disaster") {
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_open_data.inc');
	$obj_open_data = new tbl_open_data($objCnc);
	// コピー元のページに設定されているオープンデータ関連の情報をコピー
	$obj_open_data->copy($_POST['cms_copy_page_id'], $PID);
}

// ライブラリ
$libHtmlStr = $htmlStr;
$libAry = array();
// ライブラリ領域を検索
while (getLibraryArea($libAry, $libHtmlStr, 0)) {
	
	$libInsertFlg = FLAG_OFF;
	
	// 複写 の場合は複写元に同一エリア名のライブラリの指定を確認
	if (($_POST['cms_dispMode'] == "copy" || $_POST['cms_dispMode'] == "disaster") && $objLibrary->selectFromPageArea($_POST['cms_copy_page_id'], $libAry["area"], $copyTbl) !== FALSE) {
		$libInsertFlg = FLAG_ON;
		$libAry["id"] = $objLibrary->fld['library_id'];
	
	}
	// 新規作成 or 複写元に同一ライブラリエリアがない場合はデフォルトライブラリの指定を確認
	elseif (isset($libAry["id"]) && $libAry["id"] != "" && $objLibrary->selectFromID($libAry["id"]) !== FALSE) {
		$libInsertFlg = FLAG_ON;
	}
	// 使用できないライブラリの場合は設定しない
	if (in_array($libAry["id"], $nonuse_library_id_Ary)) $libInsertFlg = FLAG_OFF;
	
	// DBに登録する場合
	if ($libInsertFlg == FLAG_ON) {
		// 登録情報の作成
		$db_ary = array();
		$db_ary['page_id'] = $PID;
		$db_ary['area'] = $libAry["area"];
		$db_ary['library_id'] = $libAry["id"];
		$db_ary['library_ver'] = $objLibrary->fld['library_ver'];
		// DBに登録
		if ($objHandler->insertLibrary($db_ary, WORK_TABLE) === FALSE) user_error('ライブラリ設定の登録に失敗しました。', E_USER_ERROR);
	}
	// 登録したエリア情報を対象から除外
	$libHtmlStr = str_replace($libAry["match"], "", $libHtmlStr);
}

// 回答ページより作成を行った場合はFAQテーブルの更新
if ($_POST['cms_dispMode'] == 'faq') {
	// faq_id のセット
	$aryFAQ['faq_id'] = $ary1['faq_id'];
	// 作業区分の取得
	$aryFAQ['create_cls'] = getCreateClassFAQ($PID, $aryFAQ['faq_id']);
	// 作業区分が「新規作成から」以外
	if ($aryFAQ['create_cls'] != FAQ_CREATE_CLASS_NEW_PAGE) {
		// FAQテーブルの更新
		$aryFAQ['create_cls'] = FAQ_CREATE_CLASS_INQUIURY;
		if ($objFaq->update($aryFAQ) === FALSE) {
			user_error("ページの新規作成に失敗しました。", E_USER_ERROR);
		}
		// 観光テーブルにFAQ情報を登録
		if (ConvertFAQtoKanko($PID, $aryFAQ['faq_id'], $_POST['cms_template_id']) === FALSE) {
			user_error("ページの新規作成に失敗しました。", E_USER_ERROR);
		}
	}
}

// 緊急情報ページの場合の登録処理
if ($_POST['cms_dispMode'] == "disaster") {
	$error_msg = "";
	if (!isCreateDisasterPage($_POST['cms_copy_page_id'], $error_msg)) {
		user_error($error_msg, E_USER_ERROR);
	}
	// 緊急情報　登録
	if (!entryDisasterPage($_POST['cms_copy_page_id'], $PID)) {
		user_error("緊急情報ページ情報の登録に失敗しました。", E_USER_ERROR);
	}
}

// ログ登録(ページ新規作成)
if (WRITE_INFO_LOG_NEWPAGE) {
	if (set_log_data(LOG_STATUS_NEWPAGE, $PID, WORK_TABLE) === FALSE) {
		user_error('ログ情報の登録に失敗しました。', E_USER_ERROR);
	}
}

mkNewPage($PID, $_POST['cms_dir_path'] . $_POST['cms_filename']);

if ($objTool->selectTemplate($_POST['cms_template_id'])) {
	if ($objTool->fld['mobile_temp_txt'] != "") {
		mkNewDirectory($mobile_filename);
		// 生成HTMLの内容
		$template_path = APPLICATION_ROOT . '/common/templates/mobile_dummypage.txt';
		$fp = fopen($template_path, "r");
		$htmlStr = fread($fp, filesize($template_path));
		fclose($fp);
		// 携帯自動掲載用ダミーHTML生成
		$fp = fopen($mobile_filename, "w");
		$r = fwrite($fp, $htmlStr);
		fclose($fp);
		chmod($mobile_filename, 0777);
	}
}

$objCnc->commit();

// 作成したページ（編集モード）に移動
header("Location: " . HTTP_ROOT . RPW . $ary1['file_path'] . "?edit=1");
?>