<?php
/*
 * スペルチェック
 */
require ("../.htsetting");

// エラー出力を別ウィンドウ用に設定
gd_errorhandler_ini_set("template_user_error", "template_user_error_win");
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");

// スペルチェックチェッククラス
$pspell_config = pspell_config_create("en");
$pspell_link = pspell_new("en");
require_once (APPLICATION_ROOT . '/common/dbcontrol/spell_check.inc');
$objSChk = new spell_check($objCnc, $pspell_link);

$post = $_POST;
// 公開リスト、閲覧モードのときはcms_dispMode=1
// ワークスペース、ワークフローからのときはcms_dispMode=2
// 編集モードのときはcms_dispMode=3


// プレビュー情報をセットする
include (APPLICATION_ROOT . "/common/inc/set_preview.inc");
// テンプレートに差し替えるための情報を配列$aryValuesに格納


/****************/

$sess_apell = $post;
$sess_apell['cms_context'] = $aryValues['cx_context'];
// 編集モード⇒スペルチェック変換あり
if ($post['cms_dispMode'] == 3) {
	// JS,CSS
	$head_scripts = '<link rel="stylesheet" href="/admin/style/shared.css" type="text/css">' . "\n" . '<link rel="stylesheet" href="/admin/style/accessibility.css" type="text/css">' . "\n" . '<script src="/admin/js/library/prototype.js" type="text/javascript"></script>' . "\n" . '<script src="/admin/js/shared.js" type="text/javascript"></script>' . "\n" . '<script src="/admin/js/spellcheck.js" type="text/javascript"></script>';
	
	// FCKeditor領域のチェック、表示情報のセット
	$aryValues['cx_context'] = $objSChk->checkContext($aryValues['cx_context'], 1);
	// FCKeditor領域の変換用HTML
	$sess_apell['rep_context'] = $objSChk->strReplaceHTML;
	// FCKeditor領域のプレビューモードのパラメータを削除
	$sess_apell['rep_context'] = str_replace("?mode=" . MODE_PREVIEW, "", $sess_apell['rep_context']);
	
	// 問い合わせ先メモ領域のチェック、表示情報のセット
	$pv_fld['inquiry_memo'] = ($pv_fld['inquiry_memo'] == '') ? '' : htmlspecialchars($pv_fld['inquiry_memo']);
	$pv_fld['inquiry_memo'] = $objSChk->checkContext($pv_fld['inquiry_memo'], 1);
	// 問い合わせ先メモ領域の変換用HTML
	//		$sess_apell['rep_inquiry_memo'] = $objSChk->strReplaceHTML;
	if (isset($post['cms_inquiry_prop_memo'])) $sess_apell['rep_inquiry_memo'] = $post['cms_inquiry_prop_memo'];
	
	// スペルチェック変換のための情報をセッションに格納
	$_SESSION['spell'] = $sess_apell;
	
// 閲覧モード、リスト⇒スペルチェック変換なし
}
else {
	// JS,CSS
	$head_scripts = '<link rel="stylesheet" href="/admin/style/shared.css" type="text/css">' . "\n" . '<link rel="stylesheet" href="/admin/style/accessibility.css" type="text/css">' . "\n" . '<script src="/admin/js/library/prototype.js" type="text/javascript"></script>' . "\n" . '<script src="/admin/js/shared.js" type="text/javascript"></script>' . "\n" . '<script src="/admin/js/spellcheck.js" type="text/javascript"></script>';
	
	// FCKeditor領域のチェック、表示情報のセット
	$aryValues['cx_context'] = $objSChk->checkContext($aryValues['cx_context'], 0);
	
	// 問い合わせ先メモ領域のチェック、表示情報のセット
	$pv_fld['inquiry_memo'] = ($pv_fld['inquiry_memo'] == '') ? '' : $pv_fld['inquiry_memo'];
}
/****************/

// 問い合わせのメモにhtmlDisplay()をつけない
$inq_flg = 0;
// イベントを無効化する
$event_flg = 1;

// プレビューを生成する
include (APPLICATION_ROOT . "/common/inc/set_preview_htmlStr.inc");
// $htmlStrに文字列で格納


// ONLOADを消去
$htmlStr = preg_replace('/onload="[^"]*"/i', '', $htmlStr);
$htmlStr = preg_replace('/.*\.onload.*/i', '', $htmlStr);
$htmlStr = preg_replace('/<script.*<\/script>/i', '', $htmlStr);
$p = 0;
while (getMidString($htmlStr, "<script", "</script>", $p) !== FALSE) {
	$hitStr = getMidString($htmlStr, "<script", "</script>", $p);
	$htmlStr = str_replace("<script" . $hitStr . "</script>", "", $htmlStr);
	$p++;
}

// JS,CSSの読み込みを挿入
$htmlStr = preg_replace('/<\/head>/i', $head_scripts . '</head>', $htmlStr);

// リンク無効化
$htmlStr = preg_replace('/<(a|area)( [^>]*)? href="[^"]*"/i', '<${1}${2} href="#"', $htmlStr);
$htmlStr = preg_replace('/<(a|area)( [^>]*)? target="[^"]*"/i', '<${1}${2} ', $htmlStr);

//ヘッダーメッセージ
$tool_replace = 0;
$message = '<img src="' . RPW . '/admin/images/icon/result_normal.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px">' . 'スペルミスはありません。';

if ($objSChk->check_cnt > 0) {
	if ($post['cms_dispMode'] == 3) {
		$tool_replace = 1;
		$message = '<p style="color:#FF0000;font-weight:bold;margin-bottom:5px;">' . '<img src="' . RPW . '/admin/images/icon/result_error.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px">' . '対象ページに' . $objSChk->check_cnt . '件のスペルミスが含まれています。</p>' . "\n" . '<p>候補リストの中から適切なスペルを選択し、「スペル変換」ボタンをクリックすると編集ページに変換が実行されます。</p>' . "\n";
	}
	else {
		$message = '<span style="color:#FF0000;font-weight:bold">' . '<img src="' . RPW . '/admin/images/icon/result_error.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px">' . '対象ページに' . $objSChk->check_cnt . '件のスペルミスが含まれています。</span>' . "\n";
	}
}

// ツールバーを挿入＆表示領域HTML＋CSS
$params = array(
		'replace' => $tool_replace, 
		'msg' => $message
);
$toolbarStr = "\n" . get_include_contents(APPLICATION_ROOT . "/common/inc/toolbar_spell.inc", $params);
$htmlStr = preg_replace('/(<body[^>]*>)/i', '${1}' . $toolbarStr, $htmlStr);

// フォームを挿入
if ($post['cms_dispMode'] == 3) {
	$form_start = '<form name="cms_fSpell" class="cms8341-form" method="post" action="' . RPW . $post['cms_p_file_path'] . '" target="">' . "\n" . '<input type="hidden" name="cms_dispMode" value="edit">' . "\n" . '<input type="hidden" name="cms_spellFlg" value="1">';
	$form_end = '</form>';
	$htmlStr = preg_replace('/(<body[^>]*>)/i', '${1}' . "\n" . $form_start, $htmlStr);
	$htmlStr = preg_replace('/(<\/body>)/i', $form_end . "\n" . '${1}', $htmlStr);
}

// 不要な改行を整える
$htmlStr = preg_replace('/(\r?\n)+/', '\1', $htmlStr);

// 全てルートからのパスにする
$htmlStr = setRootPath($htmlStr);

print $htmlStr;
?>