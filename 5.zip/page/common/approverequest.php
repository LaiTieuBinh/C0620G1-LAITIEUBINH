<?php
/*
 * 承認依頼
 */
require ("../.htsetting");

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_contents_group.inc');
$objCGrp = new tbl_contents_group($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage2 = new tbl_page($objCnc);

// cms_approve_id, cms_page_id が渡されなければエラー
if (!isset($_POST['cms_approve_id']) || !isset($_POST['cms_page_id'])) {
	user_error("It isn't setted cms_approve_id or cms_page_id in _post.", E_USER_ERROR);
}

// 承認フロー情報を取得
$sql = "SELECT * FROM tbl_approve WHERE " . $objDac->_addslashesC('approve_id', $_POST['cms_approve_id'], '=', 'INT');
if ($objDac->execute($sql) === FALSE || !$objDac->fetch()) {
	user_error("Can't find approve data.<br>cms_approve_id[" . $_POST['cms_approve_id'] . "]", E_USER_ERROR);
}

// ステータスを決定
if ($objDac->fld['approve1'] != '') {
	$status = 301;
	$approver = $objDac->fld['approve1'];
}
elseif ($objDac->fld['approve2'] != '') {
	$status = 302;
	$approver = $objDac->fld['approve2'];
}
elseif ($objDac->fld['approve3'] != '') {
	$status = 303;
	$approver = $objDac->fld['approve3'];
}
elseif ($objDac->fld['approve4'] != '') {
	$status = 304;
	$approver = $objDac->fld['approve4'];
}
else {
	$status = 401;
	$approver = '';
}

$group_id = '';
$publish_start = $_POST['cms_pdsy'] . '-' . $_POST['cms_pdsm'] . '-' . $_POST['cms_pdsd'] . ' ' . $_POST['cms_pdsh'] . ':00:00';
$publish_end = $_POST['cms_pdey'] . '-' . $_POST['cms_pdem'] . '-' . $_POST['cms_pded'] . ' ' . $_POST['cms_pdeh'] . ':00:00';

// トランザクション開始
$objCnc->begin();

// コンテンツグループの登録（承認なしの場合は飛ばす）
if ($status != 401) {
	$ary1 = array();
	// 新しいコンテンツグループIDを取得
	$group_id = $objCGrp->getSeqNextval();
	$ary1['group_id'] = $group_id;
	$ary1['group_name'] = trim($_POST['cms_group_name']);
	$ary1['note1'] = trim($_POST['cms_note1']);
	$ary1['user_id'] = $objLogin->get('user_id');
	$ary1['approve_id'] = $_POST['cms_approve_id'];
	$ary1['publish_start'] = $publish_start;
	$ary1['publish_end'] = $publish_end;
	$ary1['request_datetime'] = 'NOW';
	$ary1['status'] = $status;
	// （INDERT INTO tbl_contents_group）
	if ($objCGrp->insert($ary1) === FALSE) {
		$objCnc->rollback();
		user_error("承認依頼情報の登録に失敗しました。");
	}
}
// 公開情報を更新（UPDATE tbl_publish_page）
$ary2 = array();
$ary2['page_id'] = implode(',', $_POST['cms_page_id']);
$ary2['status'] = $status;
if ($objPage->update($ary2, PUBLISH_TABLE) === FALSE) {
	$objCnc->rollback();
	user_error("公開ページ情報の更新に失敗しました。");
}
// 編集情報を更新（UPDATE tbl_work_page）
$ary2['group_id'] = $group_id;
$ary2['publish_start'] = $publish_start;
$ary2['publish_end'] = $publish_end;
if ($objPage->update($ary2, WORK_TABLE) === FALSE) {
	$objCnc->rollback();
	user_error("編集ページ情報の更新に失敗しました。");
}

//--- CMS-8341 Version2 --------------------------------------------------------------------------------------------//
// ログ登録(承認依頼(新規・更新・削除・非公開))
if (WRITE_INFO_LOG_REQ) {
	foreach ($_POST['cms_page_id'] as $page_id) {
		$objPage->selectFromID($page_id, WORK_TABLE);
		switch ($objPage->fld['work_class']) {
			case WORK_CLASS_NEW :
				$log_status = LOG_STATUS_REQ_INS;
				break;
			case WORK_CLASS_PUBLISH :
				$log_status = LOG_STATUS_REQ_UPD;
				break;
			case WORK_CLASS_DELETE :
				if ($objPage->fld['close_flg'] == FLAG_ON) {
					$log_status = LOG_STATUS_REQ_CLS;
				}
				else {
					$log_status = LOG_STATUS_REQ_DEL;
				}
				break;
			default :
				user_error("ページ情報の取得に失敗しました。");
		}
		if (set_log_data($log_status, $objPage->fld, WORK_TABLE) === FALSE) {
			user_error("ログ情報の登録に失敗しました。");
		}
	}
}
//--- CMS-8341 Version2 --------------------------------------------------------------------------------------------//


// メール送信（承認依頼）
if ($status != 401 && $approver != '') {
	while (1) {
		// グループのページ情報を取得
		$sql = "SELECT page_id,page_title,file_path,work_class,template_kind,close_flg FROM tbl_work_page" . " WHERE group_id = " . $group_id . " ORDER BY work_class, update_datetime";
		if ($objDac->execute($sql) == FALSE) break;
		$aryPage = array();
		while ($objDac->fetch()) {
			if ($objDac->fld['work_class'] == WORK_CLASS_NEW) $objDac->fld['work_class'] = '（新規）';
			elseif ($objDac->fld['work_class'] == WORK_CLASS_PUBLISH) $objDac->fld['work_class'] = '（更新）';
			elseif ($objDac->fld['work_class'] == WORK_CLASS_DELETE && $objDac->fld['close_flg'] == FLAG_OFF) $objDac->fld['work_class'] = '（削除依頼）';
			elseif ($objDac->fld['work_class'] == WORK_CLASS_DELETE && $objDac->fld['close_flg'] == FLAG_ON) $objDac->fld['work_class'] = '（非公開依頼）';
			else $objDac->fld['work_class'] = '';
			$aryPage[] = $objDac->fld;
			$template_kind = $objDac->fld['template_kind'];
		}
		if (count($aryPage) == 0) break;
		// 最初の承認者情報を取得するための条件
		$deptInfo = getDeptCode($objLogin->get('dept_code'));
		$where = '';
		if ($approver == 'appr1') $where = "dept_code = '" . gd_addslashes($deptInfo['dept3_code']) . "'";
		elseif ($approver == 'appr2') $where = "dept_code = '" . gd_addslashes($deptInfo['dept2_code']) . "'";
		elseif ($approver == 'appr3') $where = "dept_code = '" . gd_addslashes($deptInfo['dept1_code']) . "'";
		elseif ($status != 304) $where = "dept_code = '" . gd_addslashes($approver) . "'";
		elseif ($approver == WEB_MASTER_CODE) $where = "class = " . USER_CLASS_WEBMASTER;
		else $where = "user_id = " . $approver;
		if ($where == '') break;
		// TO:最初の承認者
		if (MAIL_FLG_REQUEST1) {
			if (substr($where, 0, 5) == 'class') {
				$sql = "SELECT user_id,name,dept_name,email,dept_code" . " FROM tbl_user AS u LEFT JOIN tbl_handler AS h ON (h.class = " . HANDLER_CLASS_OEPN_FLG . " AND h.item1 = u.user_id)" . " WHERE u.class = " . USER_CLASS_WEBMASTER . " AND h.item1 IS NULL";
			}
			else {
				$sql = "SELECT user_id,name,dept_name,email,dept_code FROM tbl_user WHERE class <> '" . USER_CLASS_WRITER . "' AND " . $where;
			}
			if ($objDac->execute($sql) == FALSE) break;
			while ($objDac->fetch()) {
				if (substr($where, 0, 9) == 'dept_code') {
					$dept_name = $objDac->fld['dept_name'] . " 承認者";
				}
				elseif (substr($where, 0, 7) == 'user_id') {
					$dept_name = $objDac->fld['dept_name'] . " " . $objDac->fld['name'] . "様";
				}
				else {
					$dept_name = 'ウェブマスター';
				}
				// ---メール本文作成用配列
				$mail_fld = array();
				$mail_fld['url'] = HTTP_REAL_ROOT;
				$mail_fld['cms_url'] = HTTP_ROOT . RPW;
				$mail_fld['approve_name'] = $dept_name;
				$mail_fld['dept_name'] = $objDac->fld['dept_name'];
				$mail_fld['user_name'] = $objDac->fld['name'];
				$mail_fld['request_dept_name'] = $objLogin->get('dept_name');
				$mail_fld['request_user_name'] = $objLogin->get('name');
				$mail_fld['group_name'] = trim($_POST['cms_group_name']);
				$mail_fld['publish_start'] = $publish_start;
				$mail_fld['publish_end'] = $publish_end;
				$mail_fld['login_dept_name'] = $objLogin->get('dept_name');
				$mail_fld['login_user_name'] = $objLogin->get('name');
				$mail_fld['now_date'] = date('Y-m-d H:i:s');
				$mail_fld['approve_note'] = trim($_POST['cms_note1']);
				$mail_fld['request_page_group'] = $aryPage;
				$head = get_mail_str($mail_fld, MAIL_SUBJECT_REQUEST1);
				$body = get_mail_str($mail_fld, MAIL_BODY_REQUEST1);
				send_mail($objDac->fld['email'], MAIL_ADDR_FROM, $head, $body);
			}
		}
		// TO:ページ作成者
		if (MAIL_FLG_REQUEST2) {
			if (substr($where, 0, 9) == 'dept_code') {
				$where = preg_replace('/and class.*$/i', '', $where);
				$sql = "SELECT dept_name FROM tbl_department WHERE " . $where;
				if ($objDac->execute($sql) == FALSE) break;
				if (!$objDac->fetch()) break;
				$dept_name = $objDac->fld['dept_name'] . " 承認者";
			}
			elseif (substr($where, 0, 7) == 'user_id') {
				$sql = "SELECT name, dept_name FROM tbl_user WHERE " . $where;
				if ($objDac->execute($sql) == FALSE) break;
				if (!$objDac->fetch()) break;
				$dept_name = $objDac->fld['dept_name'] . " " . $objDac->fld['name'] . "様";
			}
			else {
				$dept_name = 'ウェブマスター';
			}
			// ---メール本文作成用配列
			$mail_fld = array();
			$mail_fld['url'] = HTTP_REAL_ROOT;
			$mail_fld['cms_url'] = HTTP_ROOT . RPW;
			$mail_fld['approve_name'] = $dept_name;
			$mail_fld['dept_name'] = $objLogin->get('dept_name');
			$mail_fld['user_name'] = $objLogin->get('name');
			$mail_fld['request_dept_name'] = $objLogin->get('dept_name');
			$mail_fld['request_user_name'] = $objLogin->get('name');
			$mail_fld['group_name'] = trim($_POST['cms_group_name']);
			$mail_fld['publish_start'] = $publish_start;
			$mail_fld['publish_end'] = $publish_end;
			$mail_fld['login_dept_name'] = $objLogin->get('dept_name');
			$mail_fld['login_user_name'] = $objLogin->get('name');
			$mail_fld['now_date'] = date('Y-m-d H:i:s');
			$mail_fld['approve_note'] = trim($_POST['cms_note1']);
			$mail_fld['request_page_group'] = $aryPage;
			$head = get_mail_str($mail_fld, MAIL_SUBJECT_REQUEST2);
			$body = get_mail_str($mail_fld, MAIL_BODY_REQUEST2);
			send_mail($objLogin->get('email'), MAIL_ADDR_FROM, $head, $body);
		
		}
		break;
	}
}
$objCnc->commit();
// ワークスペースに移動
header("Location: " . HTTP_ROOT . RPW . "/admin/page/workspace/workspace.php");
?>