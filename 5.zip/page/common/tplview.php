<?php
/*
 *
 */
/** require **/
require ("../.htsetting");

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_library.inc');
$objLibrary = new tbl_library($objCnc);

//
function tplError($msg) {
	$err = "<html>\n" . "<head>\n" . "<title>テンプレートプレビューエラー</title>\n" . "</head>\n" . "<body>\n" . "<script>\n" . "alert('" . $msg . "')\n" . "window.close();\n" . "</script>\n" . "</body>\n" . "</html>\n";
	print $err;
	exit();
}
//
$path = (isset($_GET["path"])) ? $_GET["path"] : FALSE;
if (!$path || strlen($path) == 0) {
	$msg = "テンプレートファイルへのパスが取得できませんでした。";
	tplError($msg);
}
else {
	$path = DOCUMENT_ROOT . $path;
	$fp = fopen($path, "r");
	if (!$fp) {
		$msg = "テンプレートファイルが開けませんでした。";
		tplError($msg);
	}
	$tpl = fread($fp, filesize($path));
	
	// ダウンロード指定の場合は変換なし
	if (!isset($_GET['dl']) || $_GET['dl'] != FLAG_ON) {
		
		// ライブラリ用変数初期化
		$libHtmlStr = $tpl;
		$libAry = array();
		
		// ライブラリ領域を検索
		while (getLibraryArea($libAry, $libHtmlStr, 0)) {
			// ライブラリ情報を登録
			if (isset($libAry["id"]) && $libAry["id"] != "" && $objLibrary->selectFromID($libAry["id"]) !== FALSE) {
				// 初期ライブラリを表示
				$tpl = str_replace($libAry["match"], $objLibrary->fld['context'], $tpl);
			}
			// 検索用文字列からエリア削除
			$libHtmlStr = str_replace($libAry["match"], "", $libHtmlStr);
		}
		
		// レスポンシブ対応されたテンプレートのテンプレート選択領域対応
		// サムネイル表示の場合
		if (isset($_GET['thum']) && $_GET['thum'] == FLAG_ON) {
			// 削除対象要素を取得
			$TPL_PREV_THUM_DEL_ELM = getDefineArray('TPL_PREV_THUM_DEL_ELM');
			// 削除対象要素の数だけループ処理
			foreach ($TPL_PREV_THUM_DEL_ELM as $del_elm) {
				// 削除対象が存在しない場合は、処理しない
				if (stripos($tpl, $del_elm) !== FALSE) {
					// 削除対象が含まれる行そのものを削除
					$tpl = preg_replace("/^.*" . $del_elm . ".*$/m", '', $tpl);
				}
			}
		}
	}
	
	print $tpl;
	fclose($fp);
}
?>