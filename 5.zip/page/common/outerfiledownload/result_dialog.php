<?php
/*
 * ダウンロード結果ダイアログの表示
 */
/* 設定ファイル */

require ("../../.htsetting");

/* エラー画面設定 */
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

/* ページID */

$pid = (isset($_GET['cms_page_id']) ? $_GET['cms_page_id'] : "");

if ($pid == "") {
	user_error("不正なアクセスです。", E_USER_ERROR);
}

/* フォーマット */

$fmt = '<tr>' . "\n" . '<td align="center" valign="top" scope="row">{result}</td>' . "\n" . '<td align="left" valign="top" scope="row">{url}{location}</td>' . "\n" . '<td align="left" valign="top" scope="row">{file_path}</td>' . "\n" . '</tr>' . "\n";

// ダイアログのタイトル
$dialog_title = "ダウンロード結果";

// 自身のページパス


require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

$dir_path = "";

// 編集情報取得
if ($objPage->selectFromID($pid, WORK_TABLE, 'file_path') === FALSE) {
	// 公開情報取得
	if ($objPage->selectFromID($pid, PUBLISH_TABLE, 'file_path') === FALSE) {
		// 失敗
		user_error('ページ情報の取得に失敗しました。【' . $pid . '】', E_USER_ERROR);
	}
}
// 成功
$dir_path = cms_dirname($objPage->fld['file_path']);

// ダウンロード成功数
$success_count = 0;

// ダウンロード結果数
$documents_count = 0;
$images_count = 0;

if (isset($_SESSION['outer_fd_dialog']['documents']) && is_array($_SESSION['outer_fd_dialog']['documents'])) $documents_count = count($_SESSION['outer_fd_dialog']['documents']);
if (isset($_SESSION['outer_fd_dialog']['images']) && is_array($_SESSION['outer_fd_dialog']['images'])) $images_count = count($_SESSION['outer_fd_dialog']['images']);

// 結果HTMLの作成
$resultHTML = "";

if (isset($_SESSION['outer_fd_dialog'])) {
	// ファイル → 画像
	foreach ($_SESSION['outer_fd_dialog'] as $mode => $ary) {
		// HTML作成
		foreach ($ary as $result) {
			
			// エラーフラグ
			$error_flg = (isset($result['error']) && $result['error'] == FLAG_ON ? FLAG_ON : FLAG_OFF);
			
			// フォーマット
			$addHTML = $fmt;
			
			// 結果フラグ
			$flg = ($error_flg == FLAG_ON ? "×" : "○");
			$addHTML = str_replace("{result}", $flg, $addHTML);
			// ダウンロードURL
			$addHTML = str_replace("{url}", htmlDisplay($result['url']), $addHTML);
			// ロケーション
			$location = ($result['location'] != "" ? '<br />' . htmlDisplay($result['location']) : htmlDisplay(""));
			$addHTML = str_replace("{location}", $location, $addHTML);
			
			// ファイルパス
			if ($error_flg != FLAG_ON) {
				// エラーでない場合
				

				// ファイルパス
				$file_path = ($mode == 'documents' ? FCK_FILELINK_FORDER : FCK_IMAGES_FORDER) . "/" . $result['file_name'];
				// リネーム
				$rename = ($result['rename'] == FLAG_ON ? "（リネーム）" : "");
				
				$addHTML = str_replace("{file_path}", htmlDisplay($file_path . $rename), $addHTML);
				
				$success_count++;
			}
			else {
				// エラー
				

				// エラーメッセージ
				if (!isset($result['out_error']) || $result['out_error'] == FLAG_ON) {
					$addHTML = str_replace("{file_path}", '<span class="cms_require">' . htmlDisplay($result['error_msg']) . '</span>', $addHTML);
				}
				else {
					$addHTML = str_replace("{file_path}", htmlDisplay($result['error_msg']), $addHTML);
				}
			}
			
			// 結果HTMLに追加
			$resultHTML .= $addHTML;
		}
	}
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Expires" content="Thu, 01 Dec 1994 16:00:00 GMT">
<title><?=htmlDisplay($dialog_title)?></title>
<base target="_self" />
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
// 親ウィンドウへの戻り値
var retObj = new Object();
    retObj['success_count'] = <?=$success_count?>;
window.returnValue = retObj;
//「はい」クリック
function cxDeleteYes( ) { cxIframeLayerCallback(window.returnValue); }
//-->
</script>
</head>
<body bgcolor="#DFDFDF">
<div id="cms8341-headareaZero" style="margin-bottom: 0px !important">
<div id="cms8341-searcharea"
	style="height: 100%; overflow: auto; margin: 10px 7px; padding: 10px 10px; background-color: #DFDFDF; padding: 0px; text-align: left; border: solid 1px #343434;">
<table width="100%" border="0" cellspacing="0" cellpadding="5"
	bgcolor="#FFFFFF" align="left" style="border-collapse: collapse;">
	<tr>
		<td align="center" style="padding: 10px;"><!-- タイトル -->
		<table width="99%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable"
			style="border-collapse: collapse; margin-bottom: 20px;">
			<tr>
				<th align="left" valign="top" scope="row"><?=htmlDisplay($dialog_title)?></th>
			</tr>
		</table>
		<!-- 保存先 ディレクトリ -->
		<table width="99%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable"
			style="border-collapse: collapse; margin-bottom: 10px;">
			<tr>
				<th align="left" valign="top" scope="row">保存先ディレクトリ</th>
				<td align="left" valign="top" scope="row"><?=HTTP_ROOT?><?=RPW?><?=$dir_path?></td>
			</tr>
		</table>
		<div
			style="width: 95%; height: 260px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: center; vertical-align: middle; border: solid 1px #999999">
		<!-- 結果一覧 -->
		<table width="95%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable" style="border-collapse: collapse;">
<?php
// ダウンロード結果に表示するファイルが存在する場合
if ($documents_count > 0 || $images_count > 0) {
	?>
<tr>
				<th width="10%" align="center" valign="top" scope="row">結果</th>
				<th width="45%" align="center" valign="top" scope="row">ダウンロードファイル</th>
				<th width="45%" align="center" valign="top" scope="row">ファイル名</th>
			</tr>
<?=$resultHTML?>
	<?php
	// 表示するファイルが存在しない場合
}
else {
	?>
<tr>
				<td width="100%" align="center" valign="top" scope="row">ダウンロードするファイルが見つかりませんでした。











				
				
				
				</th>
			</tr>
<?php
}
?>
</table>
		</div>
		<!-- 閉じるボタン -->
		<p style="margin-top: 10px;"><span><a href="javascript:"
			onClick="cxDeleteYes();"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></span></p>

		</td>
	</tr>
</table>
</div>

</body>
</html>