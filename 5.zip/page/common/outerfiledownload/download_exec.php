<?php
/*
 *
 */
/* 設定ファイル */

require ("../../.htsetting");

/* 引数取得・初期化 */

// POST
$post = $_POST;
// ページID
$pid = (isset($post['cms_page_id']) ? $post['cms_page_id'] : "");
// 編集領域HTML
$context = $post['cms_context'];

// 保存先パス
$dir_path = "";
// ダウンロードリスト
$download_list = array(
		'documents' => array(), 
		'images' => array()
);
// セッション
$_SESSION['outer_fd'] = $post;
$_SESSION['outer_fd_dialog'] = array(
		'documents' => array(), 
		'images' => array()
);
// その他のページ情報
$template_kind = $post['cms_template_kind'];

/* 保存先ディレクトリパス取得 */
if (!_ofd_get_dirpath($pid, $objCnc, $dir_path)) {
	// 失敗
	exit();
}

/* ダウンロードするファイルの一覧を取得 */
$download_list = _ofd_get_download_list($context);

/* ダウンロード(documents) */
if (count($download_list['documents']) > 0) _ofd_download_files($download_list['documents'], $dir_path, $_SESSION['outer_fd_dialog']['documents'], $template_kind, 'documents');

/* ダウンロード(images) */
if (count($download_list['images']) > 0) _ofd_download_files($download_list['images'], $dir_path, $_SESSION['outer_fd_dialog']['images'], $template_kind, 'images');

/* ファイル内 関数 */

// -- 保存先ディレクトリパス取得
function _ofd_get_dirpath($pid, &$objCnc, &$dir_path) {
	// 保存先パス
	$dir_path = "";
	
	// DB
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
	$objPage = new tbl_page($objCnc);
	
	// 編集情報取得
	if ($objPage->selectFromID($pid, WORK_TABLE, 'file_path') === FALSE) {
		// 公開情報取得
		if ($objPage->selectFromID($pid, PUBLISH_TABLE, 'file_path') === FALSE) {
			// 失敗
			return FALSE;
		}
	}
	// 成功
	$dir_path = cms_dirname($objPage->fld['file_path']);
	return TRUE;
}

// -- ダウンロードするファイルの一覧を取得
function _ofd_get_download_list($context) {
	// 一覧格納配列
	$download_list = array(
			'documents' => array(), 
			'images' => array()
	);
	
	// ドメイン（一覧）
	$domain_ary = explode(",", IKOU_OUTER_FILE_DOWNLOAD_DOMAIN);
	// ドメイン（取得条件用）
	$domain_target = "";
	if (IKOU_OUTER_FILE_DOWNLOAD_DOMAIN == "") {
		// 許可ドメイン指定なし（全て許可）の場合
		$domain_target = "https?:\/\/";
	}
	else {
		// 許可ドメイン指定ありの場合
		foreach ($domain_ary as $domain)
			$domain_target .= (strlen($domain_target) > 0 ? "|" : "") . reg_replace($domain);
		$domain_target = "(" . $domain_target . ")";
	}
	
	// リンクタグから取得（指定ドメインで始まるリンクパス）
	$p = 0;
	$ret = array();
	while (preg_match('/<(a|area)( [^>]*)? href="(' . $domain_target . '[^"]*)"[^>]*>/i', $context, $ret, PREG_OFFSET_CAPTURE, $p)) {
		$download_list['documents'][] = $ret[3][0];
		$p = $ret[0][1] + strlen($ret[0][0]);
	}
	// イメージタグから取得（指定ドメインで始まるイメージパス）
	$p = 0;
	$ret = array();
	while (preg_match('/<(img|area|input)( [^>]*)? src="(' . $domain_target . '[^"]*)"[^>]*>/i', $context, $ret, PREG_OFFSET_CAPTURE, $p)) {
		$download_list['images'][] = $ret[3][0];
		$p = $ret[0][1] + strlen($ret[0][0]);
	}
	
	return $download_list;
}

// -- ダウンロード


// $mode = 'documents' ファイル || 'images' イメージ


function _ofd_download_files($file_list, $dir_path, &$ret_ary, $template_kind, $mode = 'documents') {
	// ダウンロード完了ファイルパス格納配列
	$end_files = array();
	
	// 保存先ディレクトリ
	$dir_path = $dir_path . ($mode == 'documents' ? FCK_FILELINK_FORDER : FCK_IMAGES_FORDER);
	$dir_path = preg_replace("/\/+/", "/", $dir_path);
	
	// 許可しないContent-Type
	$IKOU_OUTER_FILE_DOWNLOAD_CONTENT_TYPE = explode(",", IKOU_OUTER_FILE_DOWNLOAD_CONTENT_TYPE);
	
	// 
	foreach ($file_list as $url) {
		// i-city
		if (strstr($url, IKOU_I_CITY_URL) !== FALSE && preg_match("/" . reg_replace(IKOU_I_CITY_URL) . "\/([^\/\?]+)/", $url, $matches)) {
			// ファイルパス
			$file_url = $url;
			// ファイル名
			$file_name = $matches[1];
			// モード変更
			$dl_mode = IKOU_OFD_MODE_I_CITY;
		}
		// 通常
		else {
			// ファイルパス
			$file_url = $url;
			$file_url = preg_replace('/#.*$/i', '', $file_url); // アンカーリンク削除
			$file_url = preg_replace('/\?.*$/i', '', $file_url); // GET パラメータ削除
			// ファイル名
			$file_name = basename($file_url);
			// モード変更
			$dl_mode = IKOU_OFD_MODE_NOMAL;
		}
		
		// ロケーション情報
		$location = "";
		// リネーム
		$rename = FLAG_OFF;
		
		// 同一ファイルを取得済みの場合は無視
		if (in_array($file_url, $end_files)) continue;
		
		// 終了済みファイルとする
		$end_files[] = $file_url;
		
		// エラー関連
		$error = FLAG_OFF;
		$error_msg = "";
		
		// エラー出力
		$out_error = FLAG_ON;
		
		//BASIC認証の設定
		$url = convert_basic_url($url);
		//プロキシサーバーの設定がある場合
		if (PROXY_SERVER_HOST != "") {
			//プロキシサーバーを設定する
			$default_opts = array(
					'http' => array(
							'proxy' => 'tcp://' . PROXY_SERVER_HOST . ":" . PROXY_SERVER_PORT,
							'request_fulluri' => TRUE,
					)
			);
			stream_context_get_default($default_opts);
		}
		// HTTPヘッダー取得
		$header_ary = @get_headers($url);
		if (!$header_ary) {
			// 戻り値を追加
			$ret_ary[] = array(
					'url' => $file_url, 
					'dir_path' => $dir_path, 
					'file_name' => $file_name, 
					'rename' => $rename, 
					'location' => $location, 
					'error' => FLAG_ON, 
					'error_msg' => 'HTTPヘッダー情報の取得に失敗しました。'
			);
			continue;
		}
		$ext = getExtension($file_name);
		
		// ステータス確認
		$status = "";
		
		foreach ($header_ary as $header_line) {
			// 半角スペースで区切る
			$line_ary = preg_split("/\s+/", $header_line);
			// ステータス
			if (strpos(strtolower($line_ary[0]), "http") === 0) {
				$status = $line_ary[1];
				// Not Found 
				if ($status == "404") {
					$error = FLAG_ON;
					$error_msg = "ファイルが見つかりませんでした。";
					break;
				}
				// その他400系エラーと500系エラー
				elseif (strpos($status, "4") === 0) {
					$error = FLAG_ON;
					$error_msg = "ファイルのダウンロードに失敗しました。";
					break;
				}
			}
			// ロケーション
			elseif (strpos(strtolower($line_ary[0]), "content-location") === 0 || strpos(strtolower($line_ary[0]), "location") === 0) {
				// ダウンロード先ファイル情報変更
				// 画面上での表示はなし
				/* $location .= '⇒ '.$line_ary[1]."\n"; */
				$file_name = basename($line_ary[1]);
				$file_name = preg_replace('/#.*$/i', '', $file_name); // アンカーリンク削除
				$file_name = preg_replace('/\?.*$/i', '', $file_name); // GET パラメータ削除
				// ドメインチェック
				if (!_ofd_location_url_check($line_ary[1])) {
					$error = FLAG_ON;
					$error_msg = "許可されていないドメインに移動しています。";
					$status = "";
					break;
				}
			}
			// ダウンロード不許可タイプのチェック
			elseif (strpos(strtolower($line_ary[0]), "content-type") === 0 && in_array(preg_replace("/;.*$/", "", strtolower($line_ary[1])), $IKOU_OUTER_FILE_DOWNLOAD_CONTENT_TYPE)) {
				// 例外としてGETパラメータがあり拡張子が登録可能なものはエラーとしない
				// ※i-cityのURLのみ
				if ($dl_mode == IKOU_OFD_MODE_I_CITY && preg_match('/\?.*$/', $file_url) && !in_array($ext, explode(",", DENIED_EXTENSIONS_FILE))) {
					break;
				}
				$error = FLAG_ON;
				$error_msg = "HTMLファイルはダウンロードできません。";
				$status = "";
				$out_error = FLAG_OFF;
				break;
			}
		}
		// エラー以外の場合はステータスを確認
		if ($error != FLAG_ON && strpos($status, "2") !== 0) {
			// エラー
			$error = FLAG_ON;
			$error_msg = "ファイルのダウンロードに失敗しました。";
		}
		// エラー
		if ($error == FLAG_ON) {
			$ret_ary[] = array(
					'url' => $file_url, 
					'dir_path' => $dir_path, 
					'file_name' => $file_name, 
					'rename' => $rename, 
					'location' => $location, 
					'error' => FLAG_ON, 
					'error_msg' => $error_msg, 
					'out_error' => $out_error
			);
			continue;
		}
		
		// ファイル名の英数字を半角英数に置換
		$file_name = mb_convert_kana($file_name, 'rn', 'UTF-8');
		$file_name = strtolower($file_name);
		
		// 
		if (!_ofd_download_check($file_url, $file_name, $template_kind, $mode, $error_msg)) {
			// エラー
			$ret_ary[] = array(
					'url' => $file_url, 
					'dir_path' => $dir_path, 
					'file_name' => $file_name, 
					'rename' => $rename, 
					'location' => $location, 
					'error' => FLAG_ON, 
					'error_msg' => $error_msg
			);
			continue;
		}
		
		// ファイルダウンロード
		$before_name = $file_name;
		if (!_ofd_http_download($file_url, $dir_path, $mode, $template_kind, $file_name, $error_msg)) $error = FLAG_ON;
		
		// リネーム情報
		if ($before_name != $file_name) $rename = FLAG_ON;
		
		// 
		$ret_ary[] = array(
				'url' => $file_url, 
				'dir_path' => $dir_path, 
				'file_name' => $file_name, 
				'rename' => $rename, 
				'location' => $location, 
				'error' => $error, 
				'error_msg' => $error_msg
		);
	}
}
// チェック
function _ofd_download_check($file_url, $file_name, $template_kind, $mode = 'documents', &$error_msg) {
	
	// GETなどのパラメーターを消去
	$file_url = preg_replace('/#.*$/i', '', $file_url); // アンカーリンク削除
	$file_url = preg_replace('/\?.*$/i', '', $file_url); // GET パラメータ削除
	$file_name = preg_replace('/#.*$/i', '', $file_name); // アンカーリンク削除
	$file_name = preg_replace('/\?.*$/i', '', $file_name); // GET パラメータ削除
	

	// 拡張子
	$url_extension = substr($file_url, (strrpos($file_url, '.') + 1));
	$url_extension = strtolower($url_extension);
	$name_extension = substr($file_name, (strrpos($file_name, '.') + 1));
	$name_extension = strtolower($name_extension);
	
	// エラーチェック
	$DENIED_EXTENSIONS_FILE = explode(",", DENIED_EXTENSIONS_FILE);
	$ALLOWED_EXTENSIONS_IMAGE_MOBILE = explode(",", ALLOWED_EXTENSIONS_IMAGE_MOBILE);
	$ALLOWED_EXTENSIONS_IMAGE = explode(",", ALLOWED_EXTENSIONS_IMAGE);
	// + 拡張子
	if ($mode == 'documents') {
		// ファイルの場合
		if (in_array($url_extension, $DENIED_EXTENSIONS_FILE) || in_array($name_extension, $DENIED_EXTENSIONS_FILE)) {
			$error_msg = "ダウンロードできない拡張子のファイルです。";
			return FALSE;
		}
	}
	elseif ($template_kind == TEMPLATE_KIND_MOBILE) {
		// イメージ(携帯)の場合
		if (!in_array($url_extension, $ALLOWED_EXTENSIONS_IMAGE_MOBILE) || !in_array($name_extension, $ALLOWED_EXTENSIONS_IMAGE_MOBILE)) {
			$error_msg = "ダウンロードできない拡張子の画像です。";
			return FALSE;
		}
	}
	else {
		// イメージの場合
		if (!in_array($url_extension, $ALLOWED_EXTENSIONS_IMAGE) || !in_array($name_extension, $ALLOWED_EXTENSIONS_IMAGE)) {
			$error_msg = "ダウンロードできない拡張子の画像です。";
			return FALSE;
		}
	}
	// + マルチバイト文字列
	if (strlen($file_name) != mb_strlen($file_name)) {
		$error_msg = "ファイル名にマルチバイト文字が使用されています。";
		return FALSE;
	}
	
	return TRUE;
}
// ダウンロード
function _ofd_http_download($file_url, $dir_path, $mode = 'documents', $template_kind, &$file_name, &$error_msg) {
	// エラー文章
	$error_msg = "";
	// ダウンロードファイル取得
	$file_url = convert_basic_url($file_url);
	$file_contents = @file_get_contents(html_entity_decode($file_url));
	// 失敗
	if (!$file_contents) {
		$error_msg = "ファイルのダウンロードに失敗しました。";
		return FALSE;
	}
	
	// 拡張子
	$extension = substr($file_name, (strrpos($file_name, '.') + 1));
	$extension = strtolower($extension);
	
	// ファイル名から拡張子除去
	$file_name = preg_replace("/" . reg_replace($extension) . "$/", "", $file_name);
	// CMSで使用できない記号等の文字列を削除
	$file_name = preg_replace("/[^\w\-_~]/i", "", $file_name);
	// 拡張子を付加
	$file_name .= "." . $extension;
	
	// ディレクトリパス修正
	$dir_path .= "/";
	$dir_path = preg_replace("/\/+/", "/", DOCUMENT_ROOT . RPW . $dir_path);
	// ディレクトリ作成
	mkNewDirectory($dir_path . "dummy.txt");
	
	// 元ファイル名
	$original_name = $file_name;
	
	// 同一ファイル名チェック
	$cnt = 0;
	while (@file_exists($dir_path . $file_name) || $file_name == "." . $extension) {
		// カウントアップ
		$cnt++;
		// 拡張子・最後のアンダーバー（複数）を除外したファイル名
		$file_name = preg_replace("/\." . reg_replace($extension) . "$/", "", $original_name);
		$file_name = preg_replace("/" . IMAGE_UPLOAD . "*$/", "", $file_name);
		// ファイル名の生成
		$file_name .= IMAGE_UPLOAD . $cnt . "." . $extension;
	}
	// ファイル作成
	$fp = fopen($dir_path . $file_name, 'a');
	if (!$fp) {
		$error_msg = "ファイルの作成に失敗しました。";
		return FALSE;
	}
	// 権限変更
	@chmod($dir_path . $file_name, 0777);
	
	if (!fwrite($fp, $file_contents)) {
		fclose($fp);
		$error_msg = "ファイルの書き込みに失敗しました。";
		return FALSE;
	}
	fclose($fp);
	
	// ファイルサイズ（容量）チェック
	if (is_none_check_dir($dir_path) === FALSE) {
		if (@filesize($dir_path . $file_name) > ($mode == 'documents' ? FCK_UPLOAD_MAX_FILE : FCK_UPLOAD_MAX_IMAGE) * 1024) {
			@unlink($dir_path . $file_name);
			$error_msg = "ファイルサイズが大き過ぎます。";
			return FALSE;
		}
		//画像
		if ($mode == 'images') {
			//携帯
			if ($template_kind == TEMPLATE_KIND_MOBILE) {
				$up_w = FCK_MOBILE_UPLOAD_IMAGE_W;
				$up_h = FCK_MOBILE_UPLOAD_IMAGE_H;
				//通常
			}
			else {
				$up_w = FCK_UPLOAD_IMAGE_W;
				$up_h = FCK_UPLOAD_IMAGE_H;
			}
			//画像リサイズ
			if (mkThumbnail($dir_path . $file_name, $up_w, $up_h) === FALSE) {
				@unlink($dir_path . $file_name);
				$error_msg = "画像のリサイズに失敗しました。";
				return FALSE;
			}
		}
	}
	
	// 不要ファイル削除用
	$file_path = preg_replace("/^" . reg_replace(DOCUMENT_ROOT . RPW) . "/", "", $dir_path) . $file_name;
	if (!isset($_SESSION['depend']['uplist']) || !in_array($file_path, $_SESSION['depend']['uplist'])) $_SESSION['depend']['uplist'][] = $file_path;
	
	return TRUE;
}

// -- ドメインのチェック(ロケーション用)
function _ofd_location_url_check($url) {
	// 許可ドメイン指定なし（全て許可）の場合は無条件で「OK」
	if (IKOU_OUTER_FILE_DOWNLOAD_DOMAIN == "") return TRUE;
	// 絶対パス、相対パス指定の場合は無条件で「OK」
	if (preg_match("/^(\/|\.)/", $url)) return TRUE;
	
	// ドメイン（一覧）
	$domain_ary = explode(",", IKOU_OUTER_FILE_DOWNLOAD_DOMAIN);
	
	// 指定されたドメインから始まっている場合は「OK」
	foreach ($domain_ary as $domain) {
		if (preg_match("/^" . reg_replace($domain) . "/", $url)) return TRUE;
	}
	// 一致しない
	return FALSE;
}

/**
 * BASIC認証用のURLに変換する
 * @param $url URL
 * @return BASIC認証用のURL
 * 
 */
function convert_basic_url($url) {
	$IKOU_BASIC_AUTH_ARY = getDefineArray("IKOU_BASIC_AUTH_ARY");
	foreach ($IKOU_BASIC_AUTH_ARY as $IKOU_BASIC_AUTH) {
		if ($IKOU_BASIC_AUTH['domain'] == "") continue;
		if (strpos($url, $IKOU_BASIC_AUTH['domain']) !== 0) continue;
		$url = str_replace("://", "://" . $IKOU_BASIC_AUTH["id"] . ":" . $IKOU_BASIC_AUTH["pw"] . "@", $url);
	}
	
	return $url;
}

?>
true