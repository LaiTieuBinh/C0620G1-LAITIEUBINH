<?php
/*
 *
 */
/* 設定ファイル */

require ("../../.htsetting");

/* 引数取得・初期化 */

// POST
$post = $_POST;
// 編集領域HTML
$context = $post['cms_context'];

// セッション
$_SESSION['outer_fd'] = $post;

/* 編集領域HTMLの修正 */

$_SESSION['outer_fd']['cms_context'] = _ofd_replace_context($context, $_SESSION['outer_fd_dialog']['documents'], $_SESSION['outer_fd_dialog']['images']);

// Session の削除
unset($_SESSION['outer_fd_dialog']);

/* 編集画面へ遷移 */

_ofd_location_page($post['cms_p_file_path']);

/* ファイル内 関数 */

// -- 編集領域のリンクを修正
function _ofd_replace_context($context, $documents_list, $images_list) {
	// リンクパス修正
	foreach ($documents_list as $detail) {
		// エラーは無視
		if (isset($detail['error']) && $detail['error'] == FLAG_ON) continue;
		// パス
		$file_path = $detail['dir_path'] . "/" . $detail['file_name'];
		$file_path = preg_replace("/\/+/", "/", $file_path);
		// 修正
		$context = preg_replace('/(<(a|area)( [^>]*)? href=")' . reg_replace($detail['url']) . '/i', "$1" . $file_path, $context);
	}
	// イメージパス修正
	foreach ($images_list as $detail) {
		// エラーは無視
		if (isset($detail['error']) && $detail['error'] == FLAG_ON) continue;
		// パス
		$file_path = $detail['dir_path'] . "/" . $detail['file_name'];
		$file_path = preg_replace("/\/+/", "/", $file_path);
		// 修正
		$context = preg_replace('/(<(img|area|input)( [^>]*)? src=")' . reg_replace($detail['url']) . '/i', "$1" . $file_path, $context);
	}
	return $context;
}

// -- 編集画面へ遷移
function _ofd_location_page($file_path) {
	
	header("Location: " . HTTP_ROOT . RPW . $file_path . "?edit=1&outer_fd=1");
	exit();
}

?>