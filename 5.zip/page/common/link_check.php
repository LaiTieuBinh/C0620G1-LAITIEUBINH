<?php
/*
 * リンクチェック
 */
require ("../.htsetting");

// 別ウィンドウ用
gd_errorhandler_ini_set("template_user_error", "template_user_error_win");
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");

// 対象のページIDが渡されなければエラー
if (!isset($_POST['cms_page_id']) || $_POST['cms_page_id'] == '') {
	user_error("It isn't setted cms_page_id in _post.", E_USER_ERROR);
}

// リンク一括チェックの引数取得
$batchMode = FLAG_OFF;
if (isset($_POST['check_mode']) && $_POST['check_mode'] == 'batch') {
	$batchMode = FLAG_ON;
}

//print_dp($_POST);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$objLinks = new tbl_links($objCnc);

// オープンデータ
// オープンデータファイルリンクチェック
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_open_data.inc');
$objOpendata = new tbl_open_data($objCnc);


// 公開情報の取得
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$fields = "file_path, dir_path, page_title";
if ($objPage->selectFromID($_POST['cms_page_id'], 1, $fields) === FALSE) {
	user_error("dac execute error. <br>tbl_page->selectFromID(" . $_POST['cms_page_id'] . ", 1, " . $fields . ");", E_USER_ERROR);
}
$page_fld = $objPage->fld;

// リンク一括チェック レスポンス用
$batch_title = $page_fld['page_title'];
$batch_path = $page_fld['file_path'];

//テンプレート情報
$template_ary = array();
if (isset($_POST['cms_template_id'])) $template_ary['template_id'] = $_POST['cms_template_id'];
if (isset($_POST['cms_template_ver'])) $template_ary['template_ver'] = $_POST['cms_template_ver'];
if (isset($_POST['cms_template_kind'])) $template_ary['template_kind'] = $_POST['cms_template_kind'];
?>
<?php

// リンク一括チェックでないならHTML出力 >>>>
if ($batchMode != FLAG_ON) {
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>リンクチェック結果</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/linkcheck.css"
	type="text/css">
</head>

<body>
<div id="cms8341-linkcheck">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/linkcheck/title_linkcheck.jpg"
					alt="リンクチェック結果" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return window.close()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div id="cms8341-checklistarea">
		<div align="center">
		<table width="430" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left" valign="top">
				<p><img src="<?=RPW?>/admin/images/linkcheck/bar_tolink.jpg"
					alt="リンクしているページ" width="430" height="20"></p>
<?php
	// リンク一括チェックでないならHTML出力 <<<
}
?>
<?php

// リンクしているページ


// リンク一括チェック時 出力文字列
$batchStr = "1";
$cnt = 0;

// オープンデータ
// オープンデータファイルリンクチェック用配列
$opendata_chk_ary = array();

// 編集モード（FCKeditor領域をチェックする）
if (isset($_POST['cms_context'])) {
	$mobile_flg = FALSE;
	if (isset($_POST['cms_template_kind'])) {
		if ($_POST['cms_template_kind'] == TEMPLATE_KIND_MOBILE) $mobile_flg = TRUE;
	}
	// HTTPルートを削除
	$context = delHttpRoot($_POST['cms_context']);
	// パスから作業用ルートを削除
	$context = delRootPath($context);
	// 自動生成領域はチェックしない
	$context = repMidStr(AUTOLINK_BEGIN, AUTOLINK_END, '', $context);
	//$cnt = 0;
	$p = 0;
	// <a href="">の値を見ていく
	while (preg_match('/<(a|area)( [^>]*)? href="([^"]*)"[^>]*>/i', $context, $ret, PREG_OFFSET_CAPTURE, $p)) {
		$str = $ret[0][0];
		$href = $ret[3][0];
		$msg = '';
		$err = 'normal';
		$title = '';
		$p1 = $ret[0][1] + strlen($ret[0][0]);
		$p = $p1;
		// 閉じタグがある
		if (($p2 = @strpos($context, '</a>', $p1)) !== FALSE || strpos(strtolower($str), '<area ') !== FALSE) {
			if (preg_match('/(mailto|javascript):/i', $href)) continue; // mailto,javascriptを含むものは対象外
			if ($mobile_flg == TRUE && preg_match('/^tel:/i', $href)) continue; // 携帯用ページの時、tel:から始まるものは対象外
			if (preg_match('/^#.+/', $href)) continue; // ページ内アンカーは対象外
			// 外部リンク：httpから始まっている
			if (preg_match('/^(https?:)?\/\//i', $href)) {
				$path = $href;
				$err = 'error';
				$res = get_http_header($path); // httpヘッダを取得
				if (strpos(strtolower($str), '<area ') !== FALSE) {
					preg_match('/<(area)( [^>]*)? (title|alt)="([^"]*)"[^>]*>/i', $str, $ret2, PREG_OFFSET_CAPTURE, 0);
					if (isset($ret2[4][0])) {
						$title = htmlDisplay('[' . $ret2[4][0] . ']');
					}
					else {
						$title = "[タイトル指定なし]";
					}
				}
				else {
					$title = htmlDisplay('[' . substr($context, $p1, $p2 - $p1) . ']');
				}
				// Status-Codeの一文字目が1か2のときはリンク切れ
				$temp_ary = array(
						1, 
						2
				);
				if (in_array(substr($res['Status-Code'], 0, 1), $temp_ary)) $err = 'normal';
				// 内部リンク
			}
			else {
				$href = preg_replace('/#.*$/i', '', $href); // アンカー部分は削除
				$href = preg_replace('/\?.*$/i', '', $href); // GETパラメータ部分は削除
				// パスが/で終わっていたらindex.htmlとする
				if (substr($href, -1, 1) == '/') $href = $href . 'index.html';
				// 絶対パスを取得する
				$path = getAbsolutePath($href, $page_fld['dir_path']);
				$file_exte = substr(strrchr($path, '.'), 1);
				// 拡張子が取れなければリンク切れ
				if ($file_exte == '') $err = 'error';
				// HTMLファイルの場合
				elseif ($file_exte == 'html') {
					// 公開ページ情報に登録されてなければリンク切れ
					if ($objPage->selectFromPath($path, 1, "work_class, page_title, close_flg, output_html_flg") === FALSE) $err = 'error';
					// パスのHTMLファイルが存在しなければリンク切れ
					elseif (!file_exists(DOCUMENT_ROOT . RPW . $path)) $err = 'error';
					// 新規作成中のページ
					elseif ($objPage->fld['work_class'] == WORK_CLASS_NEW) $msg = '&nbsp;<font color="#009900">（新規作成中）</font>';
					// 削除処理中のページ
					elseif ($objPage->fld['work_class'] == WORK_CLASS_DELETE) $msg = '&nbsp;<font color="#D50000">（非公開または削除処理中）</font>';
					// 非公開処理中のページ
					else if ($objPage->fld['close_flg'] == FLAG_ON) {
						$err = 'error';
						$msg = '&nbsp;<font color="#D50000">（非公開）</font>';
					}
					// ページ出力設定がされていないページ
					elseif (isset($objPage->fld['output_html_flg']) && $objPage->fld['output_html_flg'] == FLAG_OFF) $err = 'error';
					if ($err == 'normal') {
						$title = htmlDisplay($objPage->fld['page_title']) . '&nbsp;&nbsp;';
					}
					else {
						$title = htmlDisplay($path) . '&nbsp;&nbsp;';
					}
					
				// HTMLファイル以外の場合
				}
				else {
					// ファイルが存在しなければリンク切れ
					if (!file_exists(DOCUMENT_ROOT . RPW . $path)) $err = 'error';
					$title = htmlDisplay($path) . '&nbsp;&nbsp;';
					// オープンデータ
					// オープンデータファイルリンクチェック用配列に格納
					if ($err != 'error') {
						if (preg_match('/openDataFile/', $str)) {
							$opendata_fld = array();
							$opendata_fld['outer_flg'] = 0;
							$opendata_fld['path'] = $path;
							$opendata_fld['text'] = substr($context, $p1, $p2 - $p1); 
							$opendata_fld['file_exte'] = '';
							$opendata_chk_ary[] = $opendata_fld;
						}
					}
				}
				if (strpos(strtolower($str), '<area ') !== FALSE) {
					preg_match('/<(area)( [^>]*)? (title|alt)="([^"]*)"[^>]*>/i', $str, $ret2, PREG_OFFSET_CAPTURE, 0);
					if (isset($ret2[4][0])) {
						$title .= htmlDisplay('[' . $ret2[4][0] . ']');
					}
					else {
						$title .= "[タイトル指定なし]";
					}
				}
				else {
					$title .= htmlDisplay('[' . substr($context, $p1, $p2 - $p1) . ']');
				}
			}
			// $title内のパス（画像リンクなど）は絶対パスにする
			$title = setAbsolutePath($title, $page_fld['dir_path'], RPW);
			
			if ($batchMode != FLAG_ON) {
				// リンク一括チェックでないならHTML出力
				print '<p class="cms8341-' . $err . '"><img src="' . RPW . '/admin/images/icon/link_' . $err . '.jpg" alt="" width="12" height="12">' . $title . $msg . '</p>' . "\n";
			}
			else {
				// リンク一括チェック
				if ($err == 'error') {
					// エラー文字指定
					$batchStr = "0";
					// エラーチェック終了
					break;
				}
			}
			$cnt++;
		}
	}
	// 添付資料のリンクチェック
	if (isset($_POST['files']) && is_array($_POST['files'])) {
		foreach ($_POST['files'] as $files) {
			$err = 'normal';
			if ($files[3]) continue;
			if (!file_exists(DOCUMENT_ROOT . RPW . $files[2])) $err = 'error';
			$title = htmlDisplay($files[2]) . '&nbsp;&nbsp;[' . htmlDisplay($files[0] . $files[1]) . ']';
			// リンク一括チェックでないならHTML出力
			if ($batchMode != FLAG_ON) {
				print '<p class="cms8341-' . $err . '"><img src="' . RPW . '/admin/images/icon/link_' . $err . '.jpg" alt="" width="12" height="12">' . $title . '</p>' . "\n";
			}
			$cnt++;
		}
	}
}
	
$lnksAry = array();
if (isFixed($template_ary)) {
	$itemAry = createKankoDataFromPost($_POST);
	foreach ($itemAry as $item) {
		if ($item['kind'] != "page") continue;
		$temp_ary = array(
				"link", 
				"mail", 
				"file",
				// オープンデータ
				"opendata"
		);
		if (!in_array($item['type'], $temp_ary)) continue;
		if ($item['context'] == KANKO_LINK_DELIMITER) continue;
		$fld = array();
		list($path, $text) = explode(KANKO_LINK_DELIMITER, $item['context']);
		$path = preg_replace('/#.*$/i', '', $path); // アンカー部分は削除
		$path = preg_replace('/\?.*$/i', '', $path); // GETパラメータ部分は削除
		$sExtension = substr($path, (strrpos($path, '.') + 1));
		$sExtension = strtolower($sExtension);
		$fld['file_exte'] = $sExtension;
		$fld["outer_flg"] = (preg_match('/^(https?:)?\/\//i', $path)) ? 1 : 0;
		// 内部
		if ($fld["outer_flg"] == 0) {
			$path = str_replace(RPW, "", $path);
			if ($fld['file_exte'] == "html") {
				$objPage->selectFromPath($path);
				$fld["linkpage_id"] = "";
				if (isset($objPage->fld)) {
					$fld = array_merge($fld, $objPage->fld);
					$fld["linkpage_id"] = $fld['page_id'];
				}
			}
		}
		$fld["path"] = $path;
		$fld["text"] = $text;
		$lnksAry[] = $fld;
		// オープンデータ
		// オープンデータファイルリンクチェック用配列に格納
		if ($item['type'] == "opendata") {
			$opendata_chk_ary[] = $fld;
		}
	}
}

// オープンデータ
// オープンデータファイル情報可変領域チェック
if (isset($_POST['disp_sort']) && count($_POST['disp_sort']) > 0) {
	$disp_sort_ary = $_POST['disp_sort'];
	$opendata_fld = array();
	foreach($disp_sort_ary as $id_index) {
		$opendata_fld['outer_flg'] = 0;
		if (isset($_POST['file_path_' . $id_index])) {
			$opendata_fld['path'] = $_POST['file_path_' . $id_index];
		}
		if (isset($_POST['link_text_' . $id_index])) {
			$opendata_fld['text'] = $_POST['link_text_' . $id_index];
		}
		if (isset($_POST['file_extention_' . $id_index])) {
			$opendata_fld['file_exte'] = $_POST['file_extention_' . $id_index];
		}
		$lnksAry[] = $opendata_fld;
		// オープンデータファイルリンクチェック用配列に格納
		$opendata_chk_ary[] = $opendata_fld;
	}
}

// 編集画面以外から実行された場合DBの情報に対してリンクチェックを行う
if (!isset($_POST['page_edit_flg']) || $_POST['page_edit_flg'] != FLAG_ON) {
	// 閲覧モードのときは編集ページのリンク情報を取得
	if ($_POST['cms_dispMode'] == 'edit') {
		$objLinks->selectLinks($_POST['cms_page_id'], 2);
		while ($objLinks->fetch()) {
			$lnksAry[] = $objLinks->fld;
		}
		// オープンデータ
		$objOpendata->selectFromPID($_POST['cms_page_id'], '', '', '', 2);
		$opendata_fld = array();
		
		while ($objOpendata->fetch()) {
			$opendata_fld['outer_flg'] = 0;
			$opendata_fld['path'] = $objOpendata->fld['opendata_file_path'];
			$opendata_fld['text'] = $objOpendata->fld['opendata_title'];
			$opendata_fld['file_exte'] = $objOpendata->fld['file_extention'];
			// オープンデータファイルリンクチェック用配列に格納
			$opendata_chk_ary[] = $opendata_fld;
		}
		
		// リストからのときは公開ページのリンク情報を取得
	}
	else {
		$objLinks->selectLinks($_POST['cms_page_id'], 1);
		while ($objLinks->fetch()) {
			$lnksAry[] = $objLinks->fld;
		}
		// オープンデータ
		$objOpendata->selectFromPID($_POST['cms_page_id'], '', '', '', 1);
		$opendata_fld = array();

		while ($objOpendata->fetch()) {
			$opendata_fld['outer_flg'] = 0;
			$opendata_fld['path'] = $objOpendata->fld['opendata_file_path'];
			$opendata_fld['text'] = $objOpendata->fld['opendata_title'];
			$opendata_fld['file_exte'] = $objOpendata->fld['file_extention'];
			// オープンデータファイルリンクチェック用配列に格納
			$opendata_chk_ary[] = $opendata_fld;
		}
	}
}

//		if ($objLinks->getRowCount() == 0) {
if ((count($lnksAry) + $cnt) == 0) {
	if ($batchMode != FLAG_ON) {
		print '<p class="cms8341-normal">リンクしているページはありません。</p>' . "\n";
	}
}
else {
	// DBに登録されたリンク情報を見ていく
	foreach ($lnksAry as $fld) {
		$msg = '';
		$err = 'normal';
		$title = '';
		// 外部リンク：outer_flg==1
		if ($fld['outer_flg'] == 1) {
			$err = 'error';
			$res = get_http_header($fld['path']); // httpヘッダを取得
			$title = htmlDisplay('[' . $fld['text'] . ']');
			// Status-Codeの一文字目が1か2のときはリンク切れ
			$temp_ary = array(
					1, 
					2
			);
			if (in_array(substr($res['Status-Code'], 0, 1), $temp_ary)) $err = 'normal';
			
		// 内部リンク
		}
		else {
			//メールだったら無視する
			if (preg_match("/^mailto:/i", $fld['path'])) continue;
			// 拡張子が取れなければリンク切れ
			if ($fld['file_exte'] == '') $err = 'error';
			// HTMLファイルの場合
			elseif ($fld['file_exte'] == 'html') {
				// 公開ページ情報に登録されてなければリンク切れ：あればlink_page_idとして取得される
				if ($fld['linkpage_id'] == '') $err = 'error';
				// パスのHTMLファイルが存在しなければリンク切れ
				elseif (!file_exists(DOCUMENT_ROOT . RPW . $fld['path'])) $err = 'error';
				// 新規作成中のページ
				elseif ($fld['work_class'] == WORK_CLASS_NEW) $msg = '&nbsp;<font color="#009900">（新規作成中）</font>';
				// 削除処理中のページ／非公開処理中のページ
				elseif ($fld['work_class'] == WORK_CLASS_DELETE) $msg = '&nbsp;<font color="#D50000">（非公開または削除処理中）</font>';
				// 非公開処理中のページ
				else if ($fld['close_flg'] == FLAG_ON) {
					$err = 'error';
					$msg = '&nbsp;<font color="#D50000">（非公開）</font>';
				}
				// ページ出力設定がされていないページ
				elseif (isset($fld['output_html_flg']) && $fld['output_html_flg'] == FLAG_OFF) $err = 'error';
				if ($err == 'normal') $title = htmlDisplay($fld['page_title']) . '&nbsp;&nbsp;';
				
			// HTMLファイル以外の場合
			}
			else {
				// ファイルが存在しなければリンク切れ
				if (!file_exists(DOCUMENT_ROOT . RPW . $fld['path'])) $err = 'error';
				$title = htmlDisplay($fld['path']) . '&nbsp;&nbsp;';
			}
			$title .= htmlDisplay('[' . $fld['text'] . ']');
		}
		// $title内のパス（画像リンクなど）は絶対パスにする
		$title = setAbsolutePath($title, $page_fld['dir_path'], RPW);
		
		if ($batchMode != FLAG_ON) {
			// リンク一括チェックでないならHTML出力
			print '<p class="cms8341-' . $err . '"><img src="' . RPW . '/admin/images/icon/link_' . $err . '.jpg" alt="" width="12" height="12">' . $title . $msg . '</p>' . "\n";
		}
		else {
			// リンク一括チェック
			if ($err == 'error') {
				// エラー文字指定
				$batchStr = "0";
				// エラーチェック終了
				break;
			}
		}
	}
}
// リンク一括チェックでないならHTML出力 >>>>
if ($batchMode != FLAG_ON) {
	echo ('</td>');
	echo ('</tr>');
	echo ('<tr>');
	echo ('<td align="left" valign="top"><p><img src="' . RPW . '/admin/images/linkcheck/bar_fromlink.jpg" alt="リンクされているページ" width="430" height="20"></p>');
	// リンク一括チェックでないならHTML出力 <<<<
	

	// リンクされているページ
	$linked_count = 0;
	$objDac = new dac($objCnc);
	
	//tbl_publish_linksからリンクを張っているものを抽出sql
	$aryPage_p = array();
	$aryIds_p = array();
	$sql = "SELECT p.page_id, p.page_title, p.work_class, p.status, p.close_flg" . " FROM tbl_publish_links AS l INNER JOIN tbl_publish_page AS p ON (p.page_id = l.page_id)" . " WHERE l.path = '" . gd_addslashes($page_fld['file_path']) . "'" . " GROUP BY p.page_id";
	$objDac->execute($sql);
	while ($objDac->fetch()) {
		$aryPage_p[] = $objDac->fld;
		$aryIds_p[] = $objDac->fld['page_id'];
	}
	
	//tbl_work_linksからリンクを張っているものを抽出するsql
	$aryPage_w = array();
	$aryIds_w = array();
	$sql = "SELECT p.page_id, p.page_title, p.work_class, p.status, p.close_flg" . " FROM tbl_work_links AS l INNER JOIN tbl_publish_page AS p ON (p.page_id = l.page_id)" . " WHERE l.path = '" . gd_addslashes($page_fld['file_path']) . "'" . " GROUP BY p.page_id";
	$objDac->execute($sql);
	while ($objDac->fetch()) {
		$aryPage_w[] = $objDac->fld;
		$aryIds_w[] = $objDac->fld['page_id'];
	}
	
	//以下では、現在公開中のものからも、編集中のものからもリンクを張っているもの、または公開中のものからしかリンクを張っていないものを抽出する
	foreach ($aryPage_p as $page) {
		$msg = '';
		if ($page['status'] != 402) {
			// ワーククラスが3なら削除処理中を表示する
			if ($page['work_class'] == 3) {
				$msg = '&nbsp;<font color="#D50000">（削除処理中）</font>';
				// $aryIds_wにpage_idがなければ、このリンクは編集完了後にリンクが切れる
			}
			elseif (!in_array($page['page_id'], $aryIds_w)) {
				$msg = '&nbsp;<font color="#D50000">（編集中）リンクが切られます</font>';
			}
		}
		if ($page['status'] == 402 && $page['close_flg'] == FLAG_ON) {
			$msg = '&nbsp;<font color="#D50000">（非公開）</font>';
		}
		print '<p class="cms8341-normal"><img src="' . RPW . '/admin/images/icon/icon_normal.jpg" alt="" width="10" height="10">' . htmlDisplay($page['page_title']) . $msg . '</p>' . "\n";
		$linked_count++;
	}
	
	//以下では、編集中のファイルからのみリンクを張られているものを抽出する
	foreach ($aryPage_w as $page) {
		$msg = '';
		// $aryIds_pにpage_idがなければ、このリンクは編集完了後に張られることになる
		if (in_array($page['page_id'], $aryIds_p) || $page['status'] == 402) continue;
		if ($page['work_class'] == 3) { //ワーククラスが3なら削除処理中
			$msg = '&nbsp;<font color="#D50000">（削除処理中）</font>';
		}
		elseif ($page['work_class'] == 2) { //ワーククラスが2なら編集中
			$msg = '&nbsp;<font color="#D50000">（編集中）リンクされます</font>';
		}
		elseif ($page['work_class'] == 1) { //ワーククラスが1なら新規作成中
			$msg = '&nbsp;<font color="#D50000">（新規作成中）リンクされます</font>';
		}
		print '<p class="cms8341-normal"><img src="' . RPW . '/admin/images/icon/icon_normal.jpg" alt="" width="10" height="10">' . htmlDisplay($page['page_title']) . $msg . '</p>' . "\n";
		$linked_count++;
	}
	
	if ($linked_count == 0) {
		print '<p class="cms8341-normal">リンクされているページはありません。</p>' . "\n";
	}
	
	if(ENABLE_OPEN_DATA_FLG){
		// オープンデータ
		// オープンデータファイルリンクチェック
		echo ('</td>');
		echo ('</tr>');
		echo ('<tr>');
		echo ('<td align="left" valign="top"><p><img src="' . RPW . '/admin/images/linkcheck/bar_opendata_tolink.jpg" alt="オープンデータファイルにリンクしているページ" width="430" height="20"></p>');

		// オープンデータファイルにリンクしているページのチェック
		$opendata_link_count = 0;
		$objDac = new dac($objCnc);

		// テンプレート情報から言語判定
		if (!empty($template_ary['template_id'])) {
			$objDac->setTableName("tbl_template");
			$where = $objDac->_addslashesC('template_id', $template_ary['template_id']);
			$where .= ' AND ' . $objDac->_addslashesC('template_ver', $template_ary['template_ver']);
			$objDac->select($where);
			$acc_flg = '';
			while ($objDac->fetch()) {
				$acc_flg = $objDac->fld['acc_flg'];
			}
		} else {
			$acc_flg = ACCESSIBILITY_JP_FLG;
		}
		
		// tbl_publish_open_dataからリンクされているものを抽出するsql
		$aryPage_p = array();
		$aryIds_p = array();	
		$sql = "SELECT p.page_id, p.dir_path, p.file_path, p.work_class, p.status, c.opendata_title, o.opendata_file_path, o.file_extention, o.file_bytes";
		$sql .= " FROM tbl_publish_open_data AS o INNER JOIN tbl_publish_page AS p ON (o.page_id = p.page_id)";
		$sql .= " LEFT JOIN (SELECT opendata_title, opendata_file_path, file_extention, file_bytes FROM tbl_publish_open_data WHERE page_id = " . $_POST['cms_page_id'] . " AND opendata_type <> 1) AS c on o.opendata_file_path = c.opendata_file_path"; 
		$sql .= " WHERE o.page_id <> " . $_POST['cms_page_id'] . " AND o.opendata_type <> 1";
		if (count($opendata_chk_ary) > 0) {
			$sql .= " AND (";
			foreach ($opendata_chk_ary as $cnt => $file_path) { 
				if ($cnt == 0) {
					$sql .= "o.opendata_file_path = '" . $file_path['path'] . "'";
				} else {
					$sql .= " OR o.opendata_file_path = '" . $file_path['path'] . "'";
				}
			}
			$sql .= ")";
		}
		$sql .= " ORDER BY o.opendata_file_path, p.page_id";

		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$aryPage_p[] = $objDac->fld;
			$aryIds_p[] = $objDac->fld['page_id'];
		}

		//tbl_work_open_dataからリンクされているものを抽出するsql
		$aryPage_w = array();
		$aryIds_w = array();
		$sql = "SELECT p.page_id, p.dir_path, p.file_path, p.work_class, p.status, c.opendata_title, o.opendata_file_path, o.file_extention, o.file_bytes";
		$sql .= " FROM tbl_work_open_data AS o INNER JOIN tbl_publish_page AS p ON (o.page_id = p.page_id)";
		$sql .= " LEFT JOIN (SELECT opendata_title, opendata_file_path, file_extention, file_bytes FROM tbl_work_open_data WHERE page_id = " . $_POST['cms_page_id'] . " AND opendata_type <> 1) AS c on o.opendata_file_path = c.opendata_file_path"; 
		$sql .= " WHERE o.page_id <> " . $_POST['cms_page_id'] . " AND o.opendata_type <> 1";
		if (count($opendata_chk_ary) > 0) {
			$sql .= " AND (";
			foreach ($opendata_chk_ary as $cnt => $file_path) { 
				if ($cnt == 0) {
					$sql .= "o.opendata_file_path = '" . $file_path['path'] . "'";
				} else {
					$sql .= " OR o.opendata_file_path = '" . $file_path['path'] . "'";
				}
			}
			$sql .= ")";
		}
		$sql .= " ORDER BY o.opendata_file_path, p.page_id";
		
		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$aryPage_w[] = $objDac->fld;
			$aryIds_w[] = $objDac->fld['page_id'];
		}

		foreach ($opendata_chk_ary as $id => $data) {
			$last_title = '';
			//以下では、現在公開中のものからも、編集中のものからもリンクを張っているもの、または公開中のものからしかリンクを張っていないものを抽出する
			foreach ($aryPage_p as $page) {
				if ($page['opendata_file_path'] == $data['path']) {
					$msg = '';
					if ($page['status'] != 402) {
						// ワーククラスが3なら削除処理中を表示する
						if ($page['work_class'] == 3) {
							$msg = '&nbsp;<font color="#D50000">（削除処理中）</font>';
							// $aryIds_wにpage_idがなければ、このリンクは編集完了後にリンクが切れる
						}
						elseif (!in_array($page['page_id'], $aryIds_w)) {
							$msg = '&nbsp;<font color="#D50000">（編集中）リンクが切られます</font>';
						}
					}
					
					$title = $data['text'];
					$detail = '';
					// ファイル拡張子がある場合は詳細情報を作成
					if ($data['file_exte'] != '') {
						$detail = createFileDetailStr($acc_flg, $data['file_exte'], $page['file_bytes']);
					}
					$disp_title = htmlDisplay('[' . $title . $detail . $data['path'] . ']') . '&nbsp;&nbsp;';
					// 前回と同じファイルタイトルでなければ出力
					if ($last_title != $title) {
						print '<p class="cms8341-normal"><img src="' . RPW . '/admin/images/icon/link_normal.jpg" alt="" width="12" height="12">' . $disp_title . '</p>' . "\n";
					}
					
					$path = htmlDisplay(setAbsolutePath($page['file_path'], $page['dir_path'], RPW));
					print '<p class="cms8341-normal">' . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $path . $msg . '</p>' . "\n";
					$opendata_link_count++;
					$last_title = $title;
				}
			}
			
			//以下では、編集中のファイルからのみリンクを張られているものを抽出する
			foreach ($aryPage_w as $page) {
				if ($page['opendata_file_path'] == $data['path']) {
					$msg = '';
					// $aryIds_pにpage_idがなければ、このリンクは編集完了後に張られることになる
					if (in_array($page['page_id'], $aryIds_p) || $page['status'] == 402) continue;
					if ($page['work_class'] == 3) { //ワーククラスが3なら削除処理中
						$msg = '&nbsp;<font color="#D50000">（削除処理中）</font>';
					}
					elseif ($page['work_class'] == 2) { //ワーククラスが2なら編集中
						$msg = '&nbsp;<font color="#D50000">（編集中）リンクされます</font>';
					}
					elseif ($page['work_class'] == 1) { //ワーククラスが1なら新規作成中
						$msg = '&nbsp;<font color="#D50000">（新規作成中）リンクされます</font>';
					}
					
					$title = $data['text'];
					$detail = '';
					// ファイル拡張子がある場合は詳細情報を作成
					if ($data['file_exte'] != '') {
						$detail = createFileDetailStr($acc_flg, $data['file_exte'], $page['file_bytes']);
					}
					$disp_title = htmlDisplay('[' . $title . $detail . $data['path'] . ']') . '&nbsp;&nbsp;';
					// 前回と同じファイルタイトルでなければ出力
					if ($last_title != $title) {
						print '<p class="cms8341-normal"><img src="' . RPW . '/admin/images/icon/link_normal.jpg" alt="" width="12" height="12">' . $disp_title . '</p>' . "\n";
					}
					
					$path = htmlDisplay(setAbsolutePath($page['file_path'], $page['dir_path'], RPW));
					print '<p class="cms8341-normal">' . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $path . $msg . '</p>' . "\n";
					$opendata_link_count++;
					$last_title = $title;
				}
			}
		}
		
		if ($opendata_link_count == 0) {
			print '<p class="cms8341-normal">オープンデータファイルにリンクしているページはありません。</p>' . "\n";
		}
	}
	
	
	// リンク一括チェックでないならHTML出力 >>>>
	echo ('</td>');
	echo ('</tr>');
	echo ('</table>');
	echo ('</div>');
	echo ('</div></td>');
	echo ('</tr>');
	echo ('</table>');
	echo ('</div>');
	echo ('</body>');
	echo ('</html>');
	// リンク一括チェックでないならHTML出力 <<<<
}
else {
	// リンク一括チェックならレスポンス文字列出力
	print($batchStr . "," . $_POST['cms_page_id'] . "," . $batch_path . "," . $batch_title);
}
?>