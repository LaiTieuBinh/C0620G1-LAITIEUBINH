<?php
// オープンデータ
/*
 * 指定されたファイルのダウンロードを実行する。
 */

// 設定ファイル読み込み
require ("../.htsetting");

// GETパラメータを取得
if (!isset($_GET["dl_file_path"])) {
	user_error('ダウンロードファイルのパスが指定されていません。');
}

// ダウンロード対象ファイルのパス
$target_file_path = $_GET["dl_file_path"];

// ダウンロードするファイルのパスを生成する
$download_file_path = DOCUMENT_ROOT . $target_file_path;

// ファイルを読み込む
if (($dl_file = @file_get_contents($download_file_path)) === FALSE) {
	user_error('ダウンロードファイルの読み込みに失敗しました。【' . $download_file_path . '】');
	exit();
}
// ファイルサイズを取得
$file_size = @filesize($download_file_path);

// ヘッダ出力
header("Content-Type: application/octet-stream");
header("Content-Disposition: attachment; filename=" . basename($download_file_path));
header('Content-Length: ' . $file_size);
echo $dl_file;

exit();
?>
