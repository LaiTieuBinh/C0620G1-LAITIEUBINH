<?php
/*
 * javascriptよりAjaxで呼ばれ、ファイルの存在チェックを行う
 */
//引数の取得
$file_path = (isset($_POST['file_path']) && $_POST['file_path'] != "" ? $_POST['file_path'] : "");

//引数のチェック
if($file_path == "") print(0);

//チェックを行う
if(@file_exists($file_path)) print(1);
else print(0);
exit();
?>
