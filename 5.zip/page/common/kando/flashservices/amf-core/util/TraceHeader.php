<?php
/**
 * TraceHeader is a simple holder class for NetDebug::trace headers
 * 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @copyright (c) 2003 amfphp.org
 * @package flashservices
 * @author Justin Watkins
 * @version $Id: TraceHeader.php 24 2009-12-03 07:43:01Z kawarazaki $
 * @subpackage debug
 */
 
class TraceHeader {
	function TraceHeader($traceStack) {
		$this->EventType = "trace";
		$this->Time = time();
		$this->Source = "Server";
		$this->Date = array(date("D M j G:i:s T O Y"));
		$this->messages = $traceStack;
	} 
} 

?>