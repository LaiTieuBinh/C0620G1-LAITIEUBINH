<?php
class Remote{  // サービス名。ファイル名と同じ名前にする。
	// コンストラクタ。これも同じ名前にする。
	function Remote(){

		$this->methodTable = array(

			// 公開するメソッドの情報
			"DataSendFlash" => array(
				"description" => "text test",
				"access"	 => "remote",
				"arguments"	 => array("arg1")
			)
		);
	}
	//////////////////////////////////////
	// サービスのメソッド
	//データ取得用配列
	//DataSendFlash()：Flashより直接コール
	function DataSendFlash( $pageid , $templateFlg , $captionFlg , $captionPos_Flg , $printFlg , $video56k , $video300k , $video500k , $videoTime , $synchronizeAry , $filenameAry=array('0'=>'slide.swf','56'=>'video56.flv','300'=>'','500'=>'')){
		//外部ファイルの読み込み
		require_once(".htsetting");

		//変数の宣言
		$return_ary = array(
			'status' => FLAG_ON,
			'err_msg' => '',
		);
		$err_msg = "";

		//XML作成処理
		if(!createFlashKandoXml($pageid,$templateFlg,$captionFlg,$captionPos_Flg,$printFlg,$video56k,$video300k,$video500k,$videoTime,$synchronizeAry,$filenameAry,$err_msg)){
			$return_ary['status'] = FLAG_OFF;
			$return_ary['err_msg'] = $err_msg;
		}

		return $return_ary;
	}
}
?>

