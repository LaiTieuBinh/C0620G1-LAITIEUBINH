<?php
/*
 * フラッシュ動画のアップロード完了処理
 */
//外部ファイル読み込み
require_once ("./.htsetting");

//変数の宣言
$bitrate = ""; //ビットレート
$page_id = ""; //ページID


//引数の取得
$bitrate = (isset($_GET['bitrate']) ? $_GET['bitrate'] : "");
$page_id = (isset($_GET['page_id']) ? $_GET['page_id'] : "");

//引数をチェック
if ($bitrate == "" || $page_id == "") {
	//エラー
	print('不正なパラメータです。');
	exit();
}

//SESSIONのデータをセット
$SESS = (isset($_SESSION['FLASH_VIDEO_' . $page_id . '_' . $bitrate]) ? $_SESSION['FLASH_VIDEO_' . $page_id . '_' . $bitrate] : "");

//通常終了した場合
if (isset($SESS['cmp_flg']) && $SESS['cmp_flg'] && isset($SESS['file_name']) && $SESS['file_name'] != "") {
	print('file_name=' . $SESS['file_name'] . '&err=&');
} //エラーがあった場合
else if (isset($SESS['err']) && $SESS['err'] != "") {
	print('file_name=' . (isset($SESS['file_name']) && $SESS['file_name'] != "" ? $SESS['file_name'] : "") . '&err=' . $SESS['err'] . '&');
} //その他の場合
else {
	print("file_name=&err=アップロードを完了することができませんでした。");
}
unset($_SESSION['FLASH_VIDEO_' . $page_id . '_' . $bitrate]);

exit();
?>