<?php
/*
 * フラッシュ動画のアップロード処理
 */
//外部ファイル読み込み
require_once ("./.htsetting");

//変数の宣言
$bitrate = ""; //ビットレート
$page_id = ""; //ページID
$err_msg = ""; //エラーメッセージ


//引数の取得
$bitrate = (isset($_GET['bitrate']) ? $_GET['bitrate'] : "");
$page_id = (isset($_GET['page_id']) ? $_GET['page_id'] : "");

//引数をチェック
if (!isset($_FILES) || $_FILES == "" || $bitrate == "" || $page_id == "") {
	//エラー
	$_SESSION['FLASH_VIDEO_' . $page_id . '_' . $bitrate]['cmp_flg'] = false;
	$_SESSION['FLASH_VIDEO_' . $page_id . '_' . $bitrate]['file_name'] = "";
	$_SESSION['FLASH_VIDEO_' . $page_id . '_' . $bitrate]['err'] = '不正なパラメータです。';
	exit();
}

//ファイル数分ループ
foreach ($_FILES as $Up_File) {
	$extension = substr($Up_File['name'], strrpos($Up_File['name'], '.') + 1);
	//ファイルパスの作成
	$file_path = DOCUMENT_ROOT . DIR_PATH_FLASH_VIDEO . $page_id;
	//ファイル名の作成
	$file_name = (in_array(strtoupper($extension), $VIDEO_EXT) ? VIDEO_EXT_HEADER . $bitrate : SLIDE_EXT_HEADER) . '.' . $extension;
	//ファイル名のチェック
	$cnt = 1;
	while (@file_exists($file_path . '/' . $file_name)) {
		$file_name = (in_array(strtoupper($extension), $VIDEO_EXT) ? VIDEO_EXT_HEADER . $bitrate : SLIDE_EXT_HEADER) . '_' . $cnt . '.' . $extension;
		$cnt++;
	}
	
	//ファイルの移動処理
	//フォルダが存在しなければ、フォルダを作成
	if (!@is_dir($file_path)) {
		if (!mkNewDirectory($file_path . '/' . $file_name)) $err_msg = "ファイルのアップロードに失敗しました。";
	}
	
	//ファイルの移動
	if (@move_uploaded_file($Up_File["tmp_name"], ($file_path . '/' . $file_name))) chmod($file_path . '/' . $file_name, 0777);
	else $err_msg = "ファイルのアップロードに失敗しました。";
	
	//SESSIONにデータをセット
	$_SESSION['FLASH_VIDEO_' . $page_id . '_' . $bitrate]['cmp_flg'] = ($err_msg == "" ? true : false);
	$_SESSION['FLASH_VIDEO_' . $page_id . '_' . $bitrate]['file_name'] = $file_name;
	$_SESSION['FLASH_VIDEO_' . $page_id . '_' . $bitrate]['err'] = $err_msg;
}

exit();
?>