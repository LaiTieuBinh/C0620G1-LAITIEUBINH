<?php
/*
 * 今回の作業でアップロードし、使用されないファイルをチェック(Ajaxで呼び出す)(編集完了時に削除する一覧)
 */
/** require **/
require ("../../.htsetting");

// 
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
// 
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$objLinks = new tbl_links($objCnc);
// 
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete.inc');
$objEnq = new tbl_enquete($objCnc);

//
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
$objKanko = new tbl_kanko($objCnc);

// ページIDを取得できなければ何もしない
if (!isset($_GET['pid'])) {
	print "-1,不正なアクセスです。";
	exit();
}
$pid = $_GET['pid'];
if (isset($_SESSION['depend']['dellist'])) unset($_SESSION['depend']['dellist']);
$_SESSION['depend']['dellist'] = array();

// 削除対象となるファイルがあるかチェック
if (isset($_SESSION['depend']['uplist']) && count($_SESSION['depend']['uplist']) > 0) {
	
	// CMSで使用されるステータス
	$CMS_PAGE_STATUS_ARRAY = array(
			STATUS_NEW, 
			STATUS_SAVE, 
			STATUS_COMP, 
			STATUS_APPROVE_1, 
			STATUS_APPROVE_2, 
			STATUS_APPROVE_3, 
			STATUS_APPROVE_LAST, 
			STATUS_DENIAL, 
			STATUS_PUBLISH_WAIT, 
			STATUS_PUBLISH
	);
	
	$retLinks = array();
	$retImages = array();
	$enqImages = array();
	$fixedItems = array();
	// オープンデータ
	// オープンデータファイル可変登録
	$variable_opendata_files_ary = array();
	
	// 一時保存・編集完了の場合 --------------------------------------------------------------- //
	if (isset($_POST['current_dir'])) {
		if (isset($_POST['context'])) {
			// HTTPルートを削除する
			$chkContext = delHttpRoot($_POST['context']);
			// パスから作業用ルートを削除
			$chkContext = delRootPath($chkContext);
			// 絶対パスにする
			$chkContext = setAbsolutePath($chkContext, $_POST['current_dir'], '', FALSE);
			// リンク情報、画像情報取得用コンテキスト：自動生成領域は除外する
			$chkContext = repMidStr(AUTOLINK_BEGIN, AUTOLINK_END, '', $chkContext);
			
			// 編集領域のリンク情報配列
			$p = 0;
			$no2 = 0;
			while (1) {
				$r = dac_insertLink($chkContext, $objLinks, $pid, $no2, $p, FLAG_ON);
				if ($r == -9) break;
				if (is_array($r)) {
					if (isset($r['file_exte']) && $r['file_exte'] == "html") continue;
					if (isset($r['outer_flg']) && $r['outer_flg'] == 1) continue;
					$retLinks[] = $r['path'];
				}
			}
			
			// 編集領域の画像情報配列
			$p = 0;
			$no2 = 0;
			while (1) {
				$r = dac_insertImage($chkContext, $objImages, $pid, $no2, $p, FLAG_ON);
				if ($r == -9) break;
				if (is_array($r)) $retImages[] = $r['src'];
			}
		}
		
		// アンケート画像
		if (isset($_POST['enquete_images'])) {
			$_POST['enquete_images'] = str_replace(HTTP_ROOT . RPW, "", $_POST['enquete_images']);
			$enqImages = explode(",", $_POST['enquete_images']);
		}
		
		// 定型情報取得
		if (isset($_POST['fixed_items'])) {
			$fixedFiles = explode(",", $_POST['fixed_items']);
			foreach ((array) $fixedFiles as $item) {
				$item = preg_replace("/^(" . reg_replace(HTTP_ROOT) . ")?" . reg_replace(RPW) . "/i", "", $item);
				if (strpos($item, "/") === 0) array_push($fixedItems, $item);
			}
		}
		// オープンデータ
		// オープンデータファイルの可変登録エリアに登録されたファイル情報を取得
		if (isset($_POST['variable_opendata_files'])) {
			$opendata_files_ary = explode(",", $_POST['variable_opendata_files']);
			foreach ((array) $opendata_files_ary as $file_path) {
				$file_path = preg_replace("/^(" . reg_replace(HTTP_ROOT) . ")?" . reg_replace(RPW) . "/i", "", $file_path);
				if (strpos($item, "/") === 0) {
					// ファイルパスを削除非対象として配列に格納
					array_push($variable_opendata_files_ary, $file_path);
				}
			}
		}
	} // 閉じるの場合 --------------------------------------------------------------------------- //
	else {
		// 編集開始時にセットする SESSION 情報を参照
		if (isset($_SESSION['cms_edit_back_status'])) {
			// 公開情報を取得
			if ($objPage->selectFromID($pid, PUBLISH_TABLE) !== FALSE) $pTbl = PUBLISH_TABLE;
			// 編集情報を取得
			if (in_array($_SESSION['cms_edit_back_status'], $CMS_PAGE_STATUS_ARRAY) && $_SESSION['cms_edit_back_status'] != STATUS_PUBLISH) {
				if ($objPage->selectFromID($pid, WORK_TABLE) !== FALSE) $pTbl = WORK_TABLE;
			}
		}
		// 取得できない場合は何もしない
		if (!isset($pTbl)) {
			print "-1,ページ情報の取得に失敗しました。";
			exit();
		}
		
		// 自身のページのリンク情報取得
		$objLinks->selectFromPageID($pid, $pTbl);
		while ($objLinks->fetch()) {
			if ($objLinks->fld['outer_flg'] == 1) continue;
			$retLinks[] = $objLinks->fld['path'];
		}
		
		// 自身のページの画像情報取得
		$objImages->selectFromPageID($pid, $pTbl);
		while ($objImages->fetch()) {
			$retImages[] = $objImages->fld['src'];
		}
		
		// 自身のページのアンケート情報取得
		$objEnq->selectFromPID($pid, $pTbl);
		while ($objEnq->fetch()) {
			if ($objEnq->fld['img_src'] != "") $enqImages[] = $objEnq->fld['img_src'];
		}
		
		// 定型情報取得
		$objKanko->selectFromPID($pid, "", "", $pTbl);
		$temp_ary = array(
				"file", 
				"link", 
				"image", 
				"customarea",
				// オープンデータ
				"opendata"
		);
		while ($objKanko->fetch()) {
			if (!in_array($objKanko->fld['type'], $temp_ary)) continue;
			if ($objKanko->fld['type'] == "customarea") {
				$p = 0;
				$no2 = 0;
				while (1) {
					$r = dac_insertLink($objKanko->fld['context'], $objLinks, $pid, $no2, $p, FLAG_ON);
					if ($r == -9) break;
					if (is_array($r)) {
						if (isset($r['file_exte']) && $r['file_exte'] == "html") continue;
						if (isset($r['outer_flg']) && $r['outer_flg'] == 1) continue;
						$fixedItems[] = preg_replace("/^(" . reg_replace(HTTP_ROOT) . ")?" . reg_replace(RPW) . "/i", "", $r['path']);
					}
				}
			}
			else {
				$item = explode(KANKO_LINK_DELIMITER, $objKanko->fld['context']);
				$item[0] = preg_replace("/^(" . reg_replace(HTTP_ROOT) . ")?" . reg_replace(RPW) . "/i", "", $item[0]);
				if (strpos($item[0], "/") === 0) $fixedItems[] = $item[0];
			}
		}
	}
	
	// 画像・ファイルパスにGET(?～)が付加されている場合は消す
	$gp = '/(\?|#).*$/i';
	foreach ($retLinks as $k => $v)
		$retLinks[$k] = preg_replace($gp, "", $v);
	foreach ($retImages as $k => $v)
		$retImages[$k] = preg_replace($gp, "", $v);
	foreach ($enqImages as $k => $v)
		$enqImages[$k] = preg_replace($gp, "", $v);
	foreach ($fixedItems as $k => $v)
		$fixedItems[$k] = preg_replace($gp, "", $v);
	// オープンデータ
	// オープンデータ可変登録
	foreach ($variable_opendata_files_ary as $k => $v) {
		$variable_opendata_files_ary[$k] = preg_replace($gp, "", $v);
	}
	
	foreach ($_SESSION['depend']['uplist'] as $key => $file_path) {
		
		// 存在チェック
		if (!@is_file(DOCUMENT_ROOT . RPW . $file_path)) {
			// 存在しなければ、削除対象ではないのでリストから削除
			unset($_SESSION['depend']['uplist'][$key]);
			continue;
		}
		
		// 全てのページの公開情報で使用されていないかチェック -------------------------------- //
		$objLinks->setTableName(PUBLISH_TABLE);
		$objImages->setTableName(PUBLISH_TABLE);
		
		// リンクテーブルの公開情報より検索
		$where = $objLinks->_addslashesC('path', $file_path, 'LIKE', 'TEXT') . // ファイルパス
" AND " . $objLinks->_addslashesC('outer_flg', 0, '=', 'INT'); // 外部参照以外
		$objLinks->select($where);
		// 使われている場合
		if ($objLinks->getRowCount() > 0) continue;
		
		// イメージテーブルの公開情報より検索
		$where = $objImages->_addslashesC('src', $file_path, 'LIKE', 'TEXT'); // ファイルパス
		$objImages->select($where);
		// 使われている場合
		if ($objImages->getRowCount() > 0) continue;
		
		// 自身のページ以外の編集情報で使用されていないかチェック ----------------------------- //
		$objLinks->setTableName(WORK_TABLE);
		$objImages->setTableName(WORK_TABLE);
		
		// リンクテーブルの編集情報より検索
		$where = $objLinks->_addslashesC('path', $file_path, 'LIKE', 'TEXT') . // ファイルパス
" AND " . $objLinks->_addslashesC('outer_flg', 0, '=', 'INT') . // 外部参照以外
" AND " . $objLinks->_addslashesC('page_id', $pid, '<>', 'INT'); // ページID
		$objLinks->select($where);
		// 使われている場合
		if ($objLinks->getRowCount() > 0) continue;
		
		// イメージテーブルの編集情報より検索
		$where = $objImages->_addslashesC('src', $file_path, 'LIKE', 'TEXT') . // ファイルパス
" AND " . $objImages->_addslashesC('page_id', $pid, '<>', 'INT'); // ページID
		$objImages->select($where);
		// 使われている場合
		if ($objImages->getRowCount() > 0) continue;
		
		// 自身のページの編集情報、もしくは現在の編集領域の情報で使用されていないかチェック --- //
		

		// リンク情報
		if (in_array($file_path, $retLinks)) continue;
		
		// 画像情報
		if (in_array($file_path, $retImages)) continue;
		
		// アンケートの画像で使用されていないか検索 ------------------------------------------- //
		
		$objEnq->add_where('img_src', $file_path, 'LIKE');
		$objEnq->add_where('page_id', $pid, '<>', 'INT');
		$objEnq->setTableName(PUBLISH_TABLE);
		$objEnq->select();
		// 使用されている場合
		if ($objEnq->getRowCount() > 0) continue;
		
		$objEnq->add_where('img_src', $file_path, 'LIKE');
		$objEnq->add_where('page_id', $pid, '<>', 'INT');
		$objEnq->setTableName(WORK_TABLE);
		$objEnq->select();
		// 使用されている場合
		if ($objEnq->getRowCount() > 0) continue;
		
		// 自身のページのアンケート情報
		if (in_array($file_path, $enqImages)) continue;
		
		// 他のページの定型情報で使用されていないかチェック ----------------------------------- //
		

		// 公開情報で使用されている場合(自身のページ含む)
		if ($objKanko->checkUseFiles($file_path, PUBLISH_TABLE)) continue;
		
		// 編集情報
		if ($objKanko->checkUseFiles($file_path, WORK_TABLE, "", $pid)) continue;
		
		// 自身の編集情報
		if (in_array($file_path, $fixedItems)) continue;
		
		// オープンデータ
		// オープンデータ可変登録(オープンデータファイルはリンクテーブルにも登録される為、自ページの編集情報の確認処理のみ追加する)
		// 自ページの編集情報
		if (in_array($file_path, $variable_opendata_files_ary)) {
			// 編集情報として存在したファイルの場合は削除対象としない
			continue;
		}
		
		// 削除が可能なのでリストに追加
		$_SESSION['depend']['dellist'][] = $file_path;
	}
}
// 重複パスを削除
$_SESSION['depend']['dellist'] = array_unique($_SESSION['depend']['dellist']);

// 削除できるファイルがある場合は true
if (count($_SESSION['depend']['dellist']) > 0) {
	print "0,true";
} // 削除できるファイルがない場合は false
else {
	print "0,false";
}

?>