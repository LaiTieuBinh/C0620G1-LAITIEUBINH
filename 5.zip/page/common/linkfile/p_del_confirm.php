<?php
/*
 * 使用されなくなるファイルのチェック(Ajaxで呼び出す)(公開時に削除する一覧)
 */
/** require **/
require ("../../.htsetting");

// 
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
// 
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$objLinks = new tbl_links($objCnc);
// 
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
//
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
//
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete.inc');
$objEnq = new tbl_enquete($objCnc);
//
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
$objKanko = new tbl_kanko($objCnc);

// ページIDを取得できなければ何もしない
if (!isset($_GET['pid'])) {
	print "-1,不正なアクセスです。";
	exit();
}
$pid = $_GET['pid'];
if (isset($_SESSION['pub_depend']['dellist'])) unset($_SESSION['pub_depend']['dellist']);
$_SESSION['pub_depend']['dellist'] = array();

$cntRelFiles = array();

// 自身のページのディレクトリを取得できなければ何もしない
if (!isset($_POST['current_dir'])) {
	print "-1,必要情報の取得に失敗しました。(current_dir)";
	exit();
}

// 画像・ファイルパスにGET(?～)が付加されている場合は消す
$gp = '/(\?|#).*$/i';

// 編集領域で使用している画像・ファイル情報を取得 -------------------------------------------- //


if (isset($_POST['context'])) {
	// HTTPルートを削除する
	$chkContext = delHttpRoot($_POST['context']);
	// パスから作業用ルートを削除
	$chkContext = delRootPath($chkContext);
	// 絶対パスにする
	$chkContext = setAbsolutePath($chkContext, $_POST['current_dir'], '', FALSE);
	// リンク情報、画像情報取得用コンテキスト：自動生成領域は除外する
	$chkContext = repMidStr(AUTOLINK_BEGIN, AUTOLINK_END, '', $chkContext);
	
	// 編集領域のリンク情報配列
	$p = 0;
	$no2 = 0;
	while (1) {
		$r = dac_insertLink($chkContext, $objLinks, $pid, $no2, $p, FLAG_ON);
		if ($r == -9) break;
		if (is_array($r)) {
			if (isset($r['file_exte']) && $r['file_exte'] == "html") continue;
			if (isset($r['outer_flg']) && $r['outer_flg'] == 1) continue;
			$cntRelFiles[] = preg_replace($gp, "", $r['path']);
		}
	}
	
	// 編集領域の画像情報配列
	$p = 0;
	$no2 = 0;
	while (1) {
		$r = dac_insertImage($chkContext, $objImages, $pid, $no2, $p, FLAG_ON);
		if ($r == -9) break;
		if (is_array($r)) $cntRelFiles[] = preg_replace($gp, "", $r['src']);
	}
}

// 自身のページのアンケート画像（新規作成時）
if (isset($_POST['enquete_images'])) {
	$enqImages = explode(",", $_POST['enquete_images']);
	foreach ((array) $enqImages as $img_src) {
		$img_src = preg_replace("/^(" . reg_replace(HTTP_ROOT) . ")?" . reg_replace(RPW) . "/i", "", $img_src);
		array_push($cntRelFiles, preg_replace($gp, "", $img_src));
	}
}
// 自身のページの定型情報
if (isset($_POST['fixed_items'])) {
	$fixedFiles = explode(",", $_POST['fixed_items']);
	foreach ((array) $fixedFiles as $item) {
		$item = preg_replace("/^(" . reg_replace(HTTP_ROOT) . ")?" . reg_replace(RPW) . "/i", "", $item);
		if (strpos($item, "/") === 0) array_push($cntRelFiles, preg_replace($gp, "", $item));
	}
}

// オープンデータ
// オープンデータファイルの可変登録エリアに登録されたファイル情報を取得
if (isset($_POST['variable_opendata_files'])) {
	$opendata_files_ary = explode(",", $_POST['variable_opendata_files']);
	foreach ((array) $opendata_files_ary as $file_path) {
		$file_path = preg_replace("/^(" . reg_replace(HTTP_ROOT) . ")?" . reg_replace(RPW) . "/i", "", $file_path);
		if (strpos($file_path, "/") === 0) {
			array_push($cntRelFiles, preg_replace($gp, "", $file_path));
		}
	}
}

// ページパス変更に伴う関連ファイルの移動を考慮


// 考慮する関連ファイルのパターン
$pattern = "/(" . reg_replace(FCK_IMAGES_FORDER) . '|' . reg_replace(FCK_FILELINK_FORDER) . ')$/';
$current_dir = preg_replace("/\/$/", "", $_POST['current_dir']);

// パスが変更になる場合は、移動したものとして判定するため修正
foreach ($cntRelFiles as $key => $path) {
	//
	$m = array();
	// 規定のフォルダに保存されているなら修正
	if (preg_match($pattern, cms_dirname($path), $m)) {
		
		if (cms_dirname($path) == $current_dir . $m[1]) continue;
		
		$cnt = 0;
		do {
			// 移動先フォルダの規定のディレクトリ
			$rep_path = str_replace(cms_dirname($path), $current_dir . $m[1], $path);
			// 同一ファイル名が存在する場合はリネーム
			$rep_path = preg_replace("/(" . IMAGE_UPLOAD . "[0-9]+)?(\.[^\.]*)$/", ($cnt == 0 ? "" : IMAGE_UPLOAD . $cnt) . "$2", $rep_path);
			$cnt++;
		} while (@is_file(DOCUMENT_ROOT . RPW . $rep_path));
		
		$cntRelFiles[$key] = $rep_path;
	}
}

// 前回の編集情報を取得 ---------------------------------------------------------------------- //


$pTbl = WORK_TABLE;
$checkAry = array();

if ($objPage->selectFromID($pid, WORK_TABLE) === FALSE) {
	// 取得に失敗した場合は公開情報を取得
	if ($objPage->selectFromID($pid, PUBLISH_TABLE) === FALSE) {
		// 完全に取得に失敗した場合はエラー
		print "-1,ページ情報の取得に失敗しました。";
		exit();
	}
	$pTbl = PUBLISH_TABLE;
}

$work_class = $objPage->fld['work_class'];

// リンク情報を取得
$objLinks->selectRelated($pid, $pTbl);

while ($objLinks->fetch()) {
	$checkAry[] = $objLinks->fld['path'];
}

// 画像情報を取得
$objImages->selectFromPageID($pid, $pTbl);

while ($objImages->fetch()) {
	$checkAry[] = $objImages->fld['src'];
}

// アンケート情報取得
$objEnq->selectFromPID($pid, $pTbl);
while ($objEnq->fetch()) {
	if ($objEnq->fld['img_src'] != "") $checkAry[] = $objEnq->fld['img_src'];
}

// 定型情報取得
$objKanko->selectFromPID($pid, "", "", $pTbl);
while ($objKanko->fetch()) {
	$temp_ary = array(
			"file", 
			"link", 
			"image", 
			"customarea",
			// オープンデータ
			"opendata"
	);
	if (!in_array($objKanko->fld['type'], $temp_ary)) continue;
	if ($objKanko->fld['type'] == "customarea") {
		$p = 0;
		$no2 = 0;
		while (1) {
			$r = dac_insertLink($objKanko->fld['context'], $objLinks, $pid, $no2, $p, FLAG_ON);
			if ($r == -9) break;
			if (is_array($r)) {
				if (isset($r['file_exte']) && $r['file_exte'] == "html") continue;
				if (isset($r['outer_flg']) && $r['outer_flg'] == 1) continue;
				$checkAry[] = preg_replace("/^(" . reg_replace(HTTP_ROOT) . ")?" . reg_replace(RPW) . "/i", "", $r['path']);
			}
		}
	}
	else {
		$item = explode(KANKO_LINK_DELIMITER, $objKanko->fld['context']);
		$item[0] = preg_replace("/^(" . reg_replace(HTTP_ROOT) . ")?" . reg_replace(RPW) . "/i", "", $item[0]);
		if (strpos($item[0], "/") === 0) $checkAry[] = $item[0];
	}
}

foreach ($checkAry as $key => $file_path) {
	
	$file_path = preg_replace($gp, "", $file_path);
	
	// ファイルが既に存在しない
	if (!@is_file(DOCUMENT_ROOT . RPW . $file_path)) continue;
	
	// 規定のディレクトリの保存されていない画像・ファイルは対象外
	if (!preg_match("/(" . reg_replace(FCK_IMAGES_FORDER) . '|' . reg_replace(FCK_FILELINK_FORDER) . ')$/', cms_dirname($file_path))) continue;
	
	// 自身のページ以外の公開情報で使用されていないかチェック -------------------------------- //
	$objLinks->setTableName(PUBLISH_TABLE);
	$objImages->setTableName(PUBLISH_TABLE);
	
	// リンクテーブルの公開情報より検索
	$where = $objLinks->_addslashesC('path', $file_path, 'LIKE', 'TEXT'); // ファイルパス
	$where .= " AND " . $objLinks->_addslashesC('outer_flg', 0, '=', 'INT'); // 外部参照以外
	$where .= " AND " . $objLinks->_addslashesC('page_id', $pid, '<>', 'INT'); // ページID
	$objLinks->select($where);
	// 使われている場合
	if ($objLinks->getRowCount() > 0) continue;
	
	// イメージテーブルの公開集情報より検索
	$where = $objImages->_addslashesC('src', $file_path, 'LIKE', 'TEXT'); // ファイルパス
	$where .= " AND " . $objImages->_addslashesC('page_id', $pid, '<>', 'INT'); // ページID
	$objImages->select($where);
	// 使われている場合
	if ($objImages->getRowCount() > 0) continue;
	
	// 自身のページ以外の編集情報で使用されていないかチェック -------------------------------- //
	$objLinks->setTableName(WORK_TABLE);
	$objImages->setTableName(WORK_TABLE);
	
	// リンクテーブルの編集情報より検索
	$where = $objLinks->_addslashesC('path', $file_path, 'LIKE', 'TEXT'); // ファイルパス
	$where .= " AND " . $objLinks->_addslashesC('outer_flg', 0, '=', 'INT'); // 外部参照以外
	$where .= " AND " . $objLinks->_addslashesC('page_id', $pid, '<>', 'INT'); // ページID
	$objLinks->select($where);
	// 使われている場合
	if ($objLinks->getRowCount() > 0) continue;
	
	// イメージテーブルの編集情報より検索
	$where = $objImages->_addslashesC('src', $file_path, 'LIKE', 'TEXT'); // ファイルパス
	$where .= " AND " . $objImages->_addslashesC('page_id', $pid, '<>', 'INT'); // ページID
	$objImages->select($where);
	// 使われている場合
	if ($objImages->getRowCount() > 0) continue;
	
	// 削除予定リストに既に登録されていないかチェック ---------------------------------------- //
	if ($objHandler->selectPublishDeleteFile($pid, $file_path) !== FALSE) continue;
	
	// 自身のページの、現在の編集領域で使用されていないかチェック ---------------------------- //
	

	if (in_array($file_path, $cntRelFiles)) continue;
	
	// 他ページのアンケート領域で使用されていないかチェック ---------------------------------- //
	$objEnq->add_where('img_src', $file_path, 'LIKE');
	if ($work_class == WORK_CLASS_NEW) {
		$objEnq->add_where('page_id', $pid, '<>', 'INT');
	}
	$objEnq->setTableName(PUBLISH_TABLE);
	$objEnq->select();
	// 使用されている場合
	if ($objEnq->getRowCount() > 0) continue;
	$objEnq->add_where('img_src', $file_path, 'LIKE');
	if ($work_class == WORK_CLASS_NEW) {
		$objEnq->add_where('page_id', $pid, '<>', 'INT');
	}
	$objEnq->setTableName(WORK_TABLE);
	$objEnq->select();
	// 使用されている場合
	if ($objEnq->getRowCount() > 0) continue;
	
	// 他のページの定型情報で使用されていないかチェック -------------------------------------- //
	

	// 公開情報で使用されている場合
	if ($objKanko->checkUseFiles($file_path, PUBLISH_TABLE, "", $pid)) continue;
	
	// 編集情報
	if ($objKanko->checkUseFiles($file_path, WORK_TABLE, "", $pid)) continue;
	
	// 削除が可能なのでリストに追加
	$_SESSION['pub_depend']['dellist'][] = $file_path;
}
// 重複パスを削除
$_SESSION['pub_depend']['dellist'] = array_unique($_SESSION['pub_depend']['dellist']);

// 削除できるファイルがある場合は true
if (count($_SESSION['pub_depend']['dellist']) > 0) {
	print "0,true";
} // 削除できるファイルがない場合は false
else {
	print "0,false";
}

?>