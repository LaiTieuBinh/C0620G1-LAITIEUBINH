<?php
/*
 * 使用されなくなる画像があった場合に表示されるダイアログ(作業の取り消し時に削除する一覧)
 */
/** require **/
require ("../../.htsetting");

$listTemplate = '<table width="95%" border="0" cellpadding="2" cellspacing="2" class="cms8341-dataTable" style="border-collapse:collapse;border:solid 1px #CCCCCC;margin-bottom: 5px;" >' . '<tr>' . '<td>' . '{list}' . '</td>' . '</tr>' . '</table>';

// 削除対象ファイルリストHTML
$listHTML = "";
foreach ($_SESSION['depend']['dellist'] as $file) {
	$listHTML .= str_replace("{list}", htmlspecialchars($file), $listTemplate);
}

// タイトル
$titleHTML = "ファイルを削除します";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Expires" content="Thu, 01 Dec 1994 16:00:00 GMT">
<title><?=$titleHTML?></title>
<base target="_self" />
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

// 親ウィンドウへの戻り値
retObj = new Object();
window.returnValue = false;

// 「はい」クリック
function cxDeleteYes( ) {
	retObj["delete"]   = FLAG_ON;
	cxIframeLayerCallback(retObj);
}
// 「いいえ」クリック
function cxDeleteNo( ) {
	retObj["delete"]   = FLAG_OFF;
	cxIframeLayerCallback(retObj);
}

//-->
</script>
</head>
<body bgcolor="#DFDFDF">
<?php /* ヘッダー */?>
<div id="cms8341-headareaZero" style="margin-bottom: 0px !important">
<?php /* メイン */?>
<div id="cms8341-searcharea"
	style="width: 97%; height: 100%; overflow: auto; margin: 10px 7px; background-color: #DFDFDF; padding: 0px; text-align: left; border: solid 1px #343434;">
<table width="100%" border="0" cellspacing="0" cellpadding="5"
	bgcolor="#FFFFFF" align="left" style="border-collapse: collapse;">
	<tr>
		<td align="center" style="padding: 10px;">
		<p align="left" style="margin-top: 10px;">どのページからも参照されなくなるファイルがあります。<br>
		削除してもよろしいですか。</p>
		<div
			style="width: 95%; height: 185px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: center; vertical-align: middle; border: solid 1px #999999">
		<table width="95%" border="0" cellpadding="0" cellspacing="0"
			style="border-collapse: collapse;">
			<tr>
				<td align="left" valign="middle">
		<?=$listHTML?>
		</td>
			</tr>
		</table>
		</div>
		<p style="margin-top: 10px;"><span><a href="javascript:"
			onClick="cxDeleteYes();"><img
			src="<?=RPW?>/admin/images/btn/btn_yes.jpg" alt="はい" width="100"
			height="20" border="0"></a></span> <span style="margin-left: 20px;"><a
			href="javascript:" onClick="cxDeleteNo();"><img
			src="<?=RPW?>/admin/images/btn/btn_no.jpg" alt="いいえ" width="100"
			height="20" border="0"></a></span></p>
		</td>
	</tr>
</table>
</div>

</body>
</html>