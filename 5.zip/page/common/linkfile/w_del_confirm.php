<?php
/*
 * 使用されなくなるファイルのチェック(Ajaxで呼び出す)(作業の取り消し時に削除する一覧)
 */
/** require **/
require ("../../.htsetting");

// 
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
// 
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$objLinks = new tbl_links($objCnc);
// 
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
//
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
//
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete.inc');
$objEnq = new tbl_enquete($objCnc);
//
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
$objKanko = new tbl_kanko($objCnc);

// ページIDを取得できなければ何もしない
if (!isset($_POST['pid'])) {
	print "-1,不正なアクセスです。";
	exit();
}
$pid = $_POST['pid'];
if (isset($_SESSION['depend']['dellist'])) unset($_SESSION['depend']['dellist']);
$_SESSION['depend']['dellist'] = array();

// 画像・ファイルパスにGET(?～)が付加されている場合は消す
$gp = '/(\?|#).*$/i';

//編集情報を取得 ---------------------------------------------------------------------- //
$checkAry = array();
if ($objPage->selectFromID($pid, WORK_TABLE) === FALSE) {
	print "-1,ページ情報の取得に失敗しました。";
	exit();
}
$work_class = $objPage->fld['work_class'];

// リンク情報を取得
$objLinks->selectRelated($pid, WORK_TABLE);

while ($objLinks->fetch()) {
	$checkAry[] = $objLinks->fld['path'];
}

// 画像情報を取得
$objImages->selectFromPageID($pid, WORK_TABLE);

while ($objImages->fetch()) {
	$checkAry[] = $objImages->fld['src'];
}

// アンケート情報取得
$objEnq->selectFromPID($pid, WORK_TABLE);
while ($objEnq->fetch()) {
	if ($objEnq->fld['img_src'] != "") $checkAry[] = $objEnq->fld['img_src'];
}

// 定型情報取得
$objKanko->selectFromPID($pid, "", "", WORK_TABLE);
$temp_ary = array(
		"file", 
		"link", 
		"image", 
		"customarea",
		// オープンデータ
		"opendata"
);
while ($objKanko->fetch()) {
	if (!in_array($objKanko->fld['type'], $temp_ary)) continue;
	if ($objKanko->fld['type'] == "customarea") {
		$p = 0;
		$no2 = 0;
		while (1) {
			$r = dac_insertLink($objKanko->fld['context'], $objLinks, $pid, $no2, $p, FLAG_ON);
			if ($r == -9) break;
			if (is_array($r)) {
				if (isset($r['file_exte']) && $r['file_exte'] == "html") continue;
				if (isset($r['outer_flg']) && $r['outer_flg'] == 1) continue;
				$checkAry[] = preg_replace("/^(" . reg_replace(HTTP_ROOT) . ")?" . reg_replace(RPW) . "/i", "", $r['path']);
			}
		}
	}
	else {
		$item = explode(KANKO_LINK_DELIMITER, $objKanko->fld['context']);
		$item[0] = preg_replace("/^(" . reg_replace(HTTP_ROOT) . ")?" . reg_replace(RPW) . "/i", "", $item[0]);
		if (strpos($item[0], "/") === 0) $checkAry[] = $item[0];
	}
}

foreach ($checkAry as $key => $file_path) {
	
	$file_path = preg_replace($gp, "", $file_path);
	
	// ファイルが既に存在しない
	if (!@is_file(DOCUMENT_ROOT . RPW . $file_path)) continue;
	
	// 規定のディレクトリの保存されていない画像・ファイルは対象外
	if (!preg_match("/(" . reg_replace(FCK_IMAGES_FORDER) . '|' . reg_replace(FCK_FILELINK_FORDER) . ')$/', cms_dirname($file_path))) continue;
	
	// 公開情報で使用されていないかチェック -------------------------------- //
	$objLinks->setTableName(PUBLISH_TABLE);
	$objImages->setTableName(PUBLISH_TABLE);
	
	// リンクテーブルの公開情報より検索
	$where = $objLinks->_addslashesC('path', $file_path, 'LIKE', 'TEXT') . // ファイルパス
" AND " . $objLinks->_addslashesC('outer_flg', 0, '=', 'INT'); // 外部参照以外
	if ($work_class == WORK_CLASS_NEW) {
		$where .= " AND " . $objLinks->_addslashesC('page_id', $pid, '<>', 'INT'); // ページID
	}
	$objLinks->select($where);
	// 使われている場合
	if ($objLinks->getRowCount() > 0) continue;
	
	// イメージテーブルの公開集情報より検索
	$where = $objImages->_addslashesC('src', $file_path, 'LIKE', 'TEXT'); // ファイルパス
	if ($work_class == WORK_CLASS_NEW) {
		$where .= " AND " . $objImages->_addslashesC('page_id', $pid, '<>', 'INT'); // ページID
	}
	$objImages->select($where);
	// 使われている場合
	if ($objImages->getRowCount() > 0) continue;
	
	// 編集情報で使用されていないかチェック -------------------------------- //
	$objLinks->setTableName(WORK_TABLE);
	$objImages->setTableName(WORK_TABLE);
	
	// リンクテーブルの編集情報より検索
	$where = $objLinks->_addslashesC('path', $file_path, 'LIKE', 'TEXT') . // ファイルパス
" AND " . $objLinks->_addslashesC('outer_flg', 0, '=', 'INT') . // 外部参照以外
" AND " . $objLinks->_addslashesC('page_id', $pid, '<>', 'INT'); // ページID
	$objLinks->select($where);
	// 使われている場合
	if ($objLinks->getRowCount() > 0) continue;
	
	// イメージテーブルの編集情報より検索
	$where = $objImages->_addslashesC('src', $file_path, 'LIKE', 'TEXT') . // ファイルパス
" AND " . $objImages->_addslashesC('page_id', $pid, '<>', 'INT'); // ページID
	$objImages->select($where);
	// 使われている場合
	if ($objImages->getRowCount() > 0) continue;
	
	// 他ページのアンケート領域で使用されていないかチェック ---------------------------------- //
	$objEnq->add_where('img_src', $file_path, 'LIKE');
	if ($work_class == WORK_CLASS_NEW) {
		$objEnq->add_where('page_id', $pid, '<>', 'INT');
	}
	$objEnq->setTableName(PUBLISH_TABLE);
	$objEnq->select();
	// 使用されている場合
	if ($objEnq->getRowCount() > 0) continue;
	// 編集情報
	$objEnq->add_where('img_src', $file_path, 'LIKE');
	if ($work_class == WORK_CLASS_NEW) {
		$objEnq->add_where('page_id', $pid, '<>', 'INT');
	}
	$objEnq->setTableName(WORK_TABLE);
	$objEnq->select();
	// 使用されている場合
	if ($objEnq->getRowCount() > 0) continue;
	
	// 他のページの定型情報で使用されていないかチェック -------------------------------------- //
	

	if ($work_class == WORK_CLASS_NEW) {
		// 公開情報で使用されている場合
		if ($objKanko->checkUseFiles($file_path, PUBLISH_TABLE, "", $pid)) continue;
	}
	else {
		// 公開情報で使用されている場合
		if ($objKanko->checkUseFiles($file_path, PUBLISH_TABLE, "")) continue;
	}
	// 編集情報
	if ($objKanko->checkUseFiles($file_path, WORK_TABLE, "", $pid)) continue;
	
	// 削除が可能なのでリストに追加
	$_SESSION['depend']['dellist'][] = $file_path;
}
// 重複パスを削除
$_SESSION['depend']['dellist'] = array_unique($_SESSION['depend']['dellist']);

// 削除できるファイルがある場合は true
if (count($_SESSION['depend']['dellist']) > 0) {
	print "0,true";
} // 削除できるファイルがない場合は false
else {
	print "0,false";
}

?>