<?php
/**
 * 画像のリスト表示を行なう
 */
// -- 共通設定ファイル -- //
require ("./.htsetting");

// -- エラー画面設定 -- //
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

// -- インクルード -- //
global $objCnc;
global $objLogin;
require_once (APPLICATION_ROOT . "/common/dbcontrol/commands.inc");
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/page_control.inc');
$objP = new page_control();

// ページ内定数
define("FCK_IMAGE_CATE_NOW", 0); // 分類条件用(現在の場所)
define("FCK_IMAGE_CATE_SHARED", 1); // 分類条件用(共通画像)
$MAXROW_LIST = getDefineArray("MAXROW_LIST"); //1ページに表示される最大表示件数配列


// CMSで使用するPOSTのプレフィックス
define("CMS_POST", "cms_fck_image_");

// リスト表示時の画像の縦横幅
define("FCK_IMAGE_LIST_WIDTH", "64");
define("FCK_IMAGE_LIST_HEIGHT", "64");

//変数の宣言
$page = 0; //ページ番号
$maxRow = 0; //1ページに表示される最大表示件数


// 検索条件配列
$search = array(
		"category" => FCK_IMAGE_CATE_NOW, 
		"keyword" => "", 
		"path" => "", 
		"update_datetime" => FLAG_OFF,  //検索条件ではなく、画像の表示・非表示フラグだが、他のものと取り扱いが同じためここに記載
		"thumbnail_flg" => FLAG_OFF
);

// POST値取得
foreach ($_POST as $k => $v) {
	if (substr($k, 0, strlen(CMS_POST)) != CMS_POST) continue;
	$k = str_replace(CMS_POST, "", $k);
	$search[$k] = $v;
}
$page = (isset($_POST['cms_page']) && is_numeric($_POST['cms_page']) ? floor($_POST['cms_page']) : 1);
$maxRow = (isset($_POST['maxrow']) && is_numeric($_POST['maxrow']) ? floor($_POST['maxrow']) : key($MAXROW_LIST));

// SESSION取得
$search['path'] = "";
// SESSIONを取得できる場合
if (isset($_SESSION['cms_page_id'])) {
	// 作業テーブルよりパス取得
	if ($objPage->selectFromID($_SESSION['cms_page_id'], WORK_TABLE, "file_path") !== FALSE) {
		$search['path'] = cms_dirname($objPage->fld['file_path']);
	} // 公開テーブルよりパス取得
	else if ($objPage->selectFromID($_SESSION['cms_page_id'], PUBLISH_TABLE, "dir_path") !== FALSE) {
		$search['path'] = ($objPage->fld['dir_path'] == "/" ? "" : $objPage->fld['dir_path']);
	} //ページ情報を取得できない場合、エラー
	else
		user_error("ページ情報の取得に失敗しました。", E_USER_ERROR);
}
else
	user_error("ページIDの取得に失敗しました。", E_USER_ERROR);
	
// -- 検索条件作成 -- //
$where = "";

// 分類
$search_path = "";
switch ($search['category']) {
	// 現在の場所
	case FCK_IMAGE_CATE_NOW :
		//現在の場所のパス
		$search_path = $search['path'] . FCK_IMAGES_FORDER;
		$search_path = str_replace('//', '/', $search_path);
		break;
	// 共通画像
	case FCK_IMAGE_CATE_SHARED :
		$search_path = FCK_IMAGES_FORDER_SHARED;
		$search_path = str_replace('//', '/', $search_path);
		break;
}
$where .= " AND " . $objFCKImages->_addslashesC("path", $search_path . "/%", "LIKE");

// キーワード --
// 文字列が存在すれば検索条件セット
if (strlen($search['keyword']) > 0) {
	$keyword = explode(" ", str_replace("　", " ", $search['keyword']));
	foreach ($keyword as $k => $v) {
		if (strlen($v) > 0) {
			$v = javaStringEscape($v);
			$where .= ' AND (' . $objFCKImages->_addslashesC("name", "%" . $v . "%", "LIKE");
			$where .= ' OR ' . $objFCKImages->_addslashesC("path", "%" . $v . "%", "LIKE") . ")";
		}
	}
}

// 条件文に付加されている最初の AND を除去
$where = preg_replace("/^( AND )+/i", "", $where);

//一時検索
$objFCKImages->select($objFCKImages->_addslashesC("path", $search_path . "/%", "LIKE"), "*");
//検索結果全件抽出
$flds = array();
while ($objFCKImages->fetch()) {
	if (!@file_exists(DOCUMENT_ROOT . RPW . $objFCKImages->fld['path'])) {
		$objFCKImages_tmp = new tbl_fck_images($objCnc);
		//トランザクション処理
		$objCnc->begin();
		//削除処理
		if ($objFCKImages_tmp->deleteFromImageID($objFCKImages->fld['id']) === FALSE) {
			//エラー
			$objCnc->rollback();
			user_error("データの更新処理に失敗しました。", E_USER_ERROR);
		}
		//コミット
		$objCnc->commit();
		$objFCKImages_tmp = null;
	}
	else
		$flds[] = $objFCKImages->fld;
}

//フォルダ内の全てのファイルを読み込む
$real_file_path = array();
$dirList = array(
		DOCUMENT_ROOT . RPW . $search_path
);
//取り込み可能拡張子の取得
$exp_ary = explode(",", ALLOWED_EXTENSIONS_IMAGE);
foreach ((array) $exp_ary as $key => $val) {
	$exp_ary[$key] = "." . $val;
}
//フォルダの一覧を取得
$dirList = cxGetDirList(DOCUMENT_ROOT . RPW . $search_path, $dirList);
//フォルダ数分ループ
foreach ((array) $dirList as $dir) {
	$dir = str_replace(DOCUMENT_ROOT . RPW, "", $dir);
	//フォルダ内にあるファイル一覧を取得
	$fileList = array();
	$fileList = cxGetFileList(DOCUMENT_ROOT . RPW . $dir, $fileList, implode(",", $exp_ary));
	//ファイル数分ループ
	foreach ((array) $fileList as $file) {
		//一覧に表示するためファイル名を保持
		$real_file_path[] = $dir . '/' . substr($file, (strrpos($file, '/') + 1));
	}
}

//DBに情報の無いファイルの情報を登録する
//実ファイル分ループ
foreach ((array) $real_file_path as $num => $file) {
	$no_db_file_path_flg = true; //DB登録済み判定フラグ
	//DBに登録されている数分ループ
	foreach ((array) $flds as $fld) {
		//DBにパスがある場合
		if ($file == $fld['path']) {
			$no_db_file_path_flg = false;
			break;
		}
	}
	//DBに登録されていない場合
	if ($no_db_file_path_flg) {
		//トランザクション処理
		$objCnc->begin();
		//登録処理
		$temp_ary = array(
				'name' => $file, 
				'path' => $file
		);
		if ($objFCKImages->insert($temp_ary) === FALSE) {
			//エラー
			$objCnc->rollback();
			user_error("データの一覧登録処理に失敗しました。", E_USER_ERROR);
		}
		//コミット
		$objCnc->commit();
	}
}

//更新日
if ($search['update_datetime'] == FLAG_ON) $order = "update_datetime ASC";
else $order = "update_datetime DESC";

//ページ管理
$row_cnt = $objFCKImages->getCount($where, $objFCKImages->table_name);
$objP->limit = $maxRow;
$objP->set($page, $row_cnt);
//検索
$objFCKImages->select($where, "*", $order, $objP->getOffset(), $objP->getLimit());
//検索結果全件抽出
$drawHTML = "";
while ($objFCKImages->fetch()) {
	$fld = $objFCKImages->fld;
	// 実ファイルが存在していない場合は表示しない
	if (!@file_exists(DOCUMENT_ROOT . RPW . $fld['path'])) continue;
	
	// 画像サイズの取得
	$size = @getimagesize(DOCUMENT_ROOT . RPW . $fld['path']);
	$witdh = $size[0];
	$height = $size[1];
	// サイズ判定処理
	$isResizeWitdh = ($witdh > FCK_IMAGE_LIST_WIDTH) ? true : false;
	$isResizeHeight = ($height > FCK_IMAGE_LIST_HEIGHT) ? true : false;
	// 縦横ともに指定サイズを超えていた場合
	if ($isResizeWitdh && $isResizeHeight) {
		// 横のサイズの方が大きい場合、縦を横に合わせる
		if ($witdh > $height) {
			$witdhDisp = FCK_IMAGE_LIST_WIDTH;
			$heightDisp = $height / ($witdh / FCK_IMAGE_LIST_WIDTH);
			// 縦のサイズの方が大きい場合、横を縦にあわせる
		}
		else {
			$witdhDisp = $witdh / ($height / FCK_IMAGE_LIST_HEIGHT);
			$heightDisp = FCK_IMAGE_LIST_HEIGHT;
		}
		// 縦のサイズが指定のサイズを超えていた場合、横を縦にあわせる
	}
	else if (!$isResizeWitdh && $isResizeHeight) {
		$witdhDisp = $witdh / ($height / FCK_IMAGE_LIST_HEIGHT);
		$heightDisp = FCK_IMAGE_LIST_HEIGHT;
		// 横のサイズが指定のサイズを超えていた場合、縦を横に合わせる
	}
	else if ($isResizeWitdh && !$isResizeHeight) {
		$witdhDisp = FCK_IMAGE_LIST_WIDTH;
		$heightDisp = $height / ($witdh / FCK_IMAGE_LIST_WIDTH);
		// 縦横どちらも指定サイズを超えていない場合
	}
	else if (!$isResizeWitdh && !$isResizeHeight) {
		$witdhDisp = $witdh;
		$heightDisp = $height;
	}
	
	//削除可能かチェックする
	$chk_tbl = array(
			'tbl_work_images', 
			'tbl_publish_images'
	);
	$Delete_Flg = true;
	foreach ($chk_tbl as $tbl) {
		$sql = "SELECT page_id FROM " . $tbl . " WHERE (" . $objImages->_addslashesC('src', $fld['path'], 'LIKE', 'TEXT') . ")";
		$objImages->execute($sql);
		if ($objImages->getRowCount() > 0) $Delete_Flg = false;
	}
	
	// HTML 作成
	$drawHTML .= '<tr id="cms_image_tr_' . $fld['id'] . '">';
	$drawHTML .= '<td style="margin:0px;padding:5px;background-color:#DFDFDF;border:none;">';
	$drawHTML .= '<table border="0" cellspacing="0px" cellpadding="0" margin="0" padding="0" style="margin:0px;padding:0px;border-collapse:collapse;">';
	$drawHTML .= '<tr style="margin:0px;padding:0px;">';
	//POSTする値
	$drawHTML .= '<input type="hidden" name="cms_url_' . $fld['id'] . '" id="cms_url_' . $fld['id'] . '" value="' . htmlDisplay($fld['path']) . '">';
	$drawHTML .= '<input type="hidden" name="cms_width_' . $fld['id'] . '" id="cms_width_' . $fld['id'] . '" value="' . $witdh . '">';
	$drawHTML .= '<input type="hidden" name="cms_height_' . $fld['id'] . '" id="cms_height_' . $fld['id'] . '" value="' . $height . '">';
	$drawHTML .= '<input type="hidden" name="cms_alt_' . $fld['id'] . '" id="cms_alt_' . $fld['id'] . '" value="' . htmlDisplay($fld['name']) . '">';
	//サムネイルフラグがONの場合
	if ($search['thumbnail_flg'] == FLAG_ON) {
		//左
		$drawHTML .= '<td width="20%" align="center" style="margin:0px;padding:0px;border:solid 1px #999999;background-color:#FFFFFF;">';
		//サムネイル画像
		$drawHTML .= '<img src="' . RPW . $fld['path'] . '?rnd=' . rand() . '" width="' . $witdhDisp . '" height="' . $heightDisp . '" alt="' . htmlDisplay($fld['name']) . '" border="0">';
		$drawHTML .= '</td>';
	}
	//中
	$drawHTML .= '<td width="' . ($search['thumbnail_flg'] == FLAG_ON ? "70%" : "90%") . '" height="80px" align="left" style="margin:0px;padding:0px;border:solid 1px #999999;">';
	$drawHTML .= '<table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" style="margin:0px;padding:0px;border-collapse:collapse;">';
	//ファイル情報
	$drawHTML .= '<tr style="margin:0px;padding:0px;">';
	$drawHTML .= '<td style="margin:0px;padding:0px;padding-left:3px;background-color:#FFFFFF;">';
	$drawHTML .= '<div id="cms_image_name_' . $fld['id'] . '" style="font-weight:bold;font-size:15px;">' . htmlDisplay($fld['name']) . '</div>';
	$drawHTML .= htmlDisplay($fld['path']) . '<br>';
	$drawHTML .= '<div id="cms_image_update_datetime_' . $fld['id'] . '">更新日：' . dtFormat($fld['update_datetime'], "Y年m月d日 H時i分s秒") . '</div>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
	//操作ボタン
	$drawHTML .= '<tr>';
	$drawHTML .= '<td align="left" valign="middle" style="margin:0px;padding:0px;padding-top:3px;background-color:#EAEAEA;">';
	$drawHTML .= '&nbsp;';
	//編集
	if ($search['category'] == FCK_IMAGE_CATE_NOW || $objLogin->get('class') == USER_CLASS_WEBMASTER) {
		$drawHTML .= '<a href="javascript:void(0)" onclick="cxEdit(' . $fld['id'] . '); return false;"><img src="' . RPW . '/admin/images/fckimage/btn_imageedit_on.jpg" width="80" height="20" alt="編集" border="0"></a>';
	}
	else
		$drawHTML .= '<img src="' . RPW . '/admin/images/fckimage/btn_imageedit_off.jpg" width="80" height="20" alt="編集" border="0">';
	$drawHTML .= '&nbsp;';
	$drawHTML .= '&nbsp;';
	//削除
	if ($Delete_Flg && ($search['category'] == FCK_IMAGE_CATE_NOW || $objLogin->get('class') == USER_CLASS_WEBMASTER)) {
		$drawHTML .= '<a href="javascript:void(0)" onclick="cxDeleteImage(' . $fld['id'] . ',\'' . javaStringEscape(htmlDisplay($fld['name'])) . '\'); return false;"><img src="' . RPW . '/admin/images/fckimage/btn_delete_on.jpg" width="80" height="20" alt="削除" border="0"></a>';
	} //削除_OFF
	else
		$drawHTML .= '<img src="' . RPW . '/admin/images/fckimage/btn_delete_off.jpg" width="80" height="20" alt="削除" border="0">';
	$drawHTML .= '&nbsp;';
	$drawHTML .= '&nbsp;';
	//プロパティ
	$drawHTML .= '<a href="javascript:void(0)" onclick="cxShowProperty(' . $fld['id'] . '); return false;"><img src="' . RPW . '/admin/images/fckimage/btn_property.jpg" width="80" height="20" alt="プロパティ" border="0"></a>';
	$drawHTML .= '&nbsp;';
	$drawHTML .= '&nbsp;';
	//プレビュー
	$drawHTML .= '<a href="' . RPW . $fld['path'] . '" target="_blank"><img src="' . RPW . '/admin/images/fckimage/btn_preview.jpg" width="80" height="20" alt="プレビュー" border="0"></a>';
	$drawHTML .= '&nbsp;';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
	$drawHTML .= '</table>';
	$drawHTML .= '</td>';
	//右
	$drawHTML .= '<td width="10%" align="center" valign="middle" style="border:none;background-color:#DFDFDF;">';
	$drawHTML .= '&nbsp;';
	$drawHTML .= '&nbsp;';
	//画像挿入ボタンの表示
	$drawHTML .= '<a href="javascript:void(0)" onclick="cxReturn(' . $fld['id'] . '); return false;"><img src="' . RPW . '/admin/images/fckimage/btn_image_set.jpg" width="80" height="20" alt="画像挿入" border="0"></a>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
	$drawHTML .= '</table>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
	$drawHTML .= '<tr style="background-color:#DFDFDF;">';
	$drawHTML .= '<td style="border:none;padding-left:5px;padding-right:5px;">';
	$drawHTML .= '<hr>';
	$drawHTML .= '</td>';
	$drawHTML .= '</tr>';
}

// -- HTML 出力 -- //


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ファイルにリンク</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/ckeditor/plugins/gd_image/pages/js/com_func.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/page/common/enq/js/image_list.js"
	type="text/javascript"></script>
<script type="text/javascript">
<!--
	<?php
	//上書きがあった場合、編集画面に表示されている画像を差し替える
	if (isset($_SESSION["updata_file"]) && count($_SESSION["updata_file"]) > 0) {
		$script = 'window.dialogArguments = window.frameElement.args; var targetArea = window.dialogArguments.document.body;' . "\n";
		$script .= 'var img_ary = targetArea.getElementsByTagName(\'img\');' . "\n";
		$script .= 'var updata_ary = [' . "\n";
		foreach ((array) $_SESSION["updata_file"] as $val) {
			$script .= '"' . $val . '",' . "\n";
		}
		$script = substr($script, 0, strrpos($script, ",")) . "\n";
		$script .= ']' . "\n";
		$script .= 'var img = new Array();' . "\n";
		//項目作成部分の画像差し替え
		$script .= 'for(var i = 0;i < updata_ary.length;i++){' . "\n";
		$script .= 'for(var j = 0;j < img_ary.length;j++){' . "\n";
		$script .= 'if(updata_ary[i] == img_ary[j].src.substring(img_ary[j].src.indexOf(baseUrl),(img_ary[j].src.indexOf(\'?\') > 0 ? img_ary[j].src.indexOf(\'?\') : img_ary[j].src.length))){' . "\n";
		$rnd = rand();
		$script .= 'cxPreImages(updata_ary[i] + "?rnd=' . $rnd . '");' . "\n";
		$script .= 'img[j] = new Image();' . "\n";
		$script .= 'img[j].src = updata_ary[i] + "?rnd=' . $rnd . '";' . "\n";
		$script .= 'img[j].onload = function(){img_load(img,img_ary);}' . "\n";
		$script .= '}' . "\n";
		$script .= '}' . "\n";
		$script .= '}' . "\n";
		//編集ページの画像差し替え
		$script .= 'var img_ary2 = window.dialogArguments.window.dialogArguments.windowObject.document.body.getElementsByTagName(\'img\');' . "\n";
		$script .= 'for(var i = 0;i < updata_ary.length;i++){' . "\n";
		$script .= 'for(var j = 0;j < img_ary2.length;j++){' . "\n";
		$script .= 'if(updata_ary[i] == img_ary2[j].src.substring(img_ary2[j].src.indexOf(baseUrl),(img_ary2[j].src.indexOf(\'?\') > 0 ? img_ary2[j].src.indexOf(\'?\') : img_ary2[j].src.length))){' . "\n";
		$rnd = rand();
		$script .= 'cxPreImages(updata_ary[i] + "?rnd=' . $rnd . '");' . "\n";
		$script .= 'img_ary2[j].src = updata_ary[i] + "?rnd=' . $rnd . '"' . "\n";
		$script .= '}' . "\n";
		$script .= '}' . "\n";
		$script .= '}' . "\n";
		//FCKeditor内の画像差し替え
		$script .= 'img_ary2 = window.dialogArguments.window.dialogArguments.windowObject.document.getElementById(\'cms_context___Frame\').contentWindow.document.getElementsByTagName(\'iframe\')[0].contentWindow.document.body.getElementsByTagName(\'img\');' . "\n";
		$script .= 'for(var i = 0;i < updata_ary.length;i++){' . "\n";
		$script .= 'for(var j = 0;j < img_ary2.length;j++){' . "\n";
		$script .= 'if(updata_ary[i] == img_ary2[j].src.substring(img_ary2[j].src.indexOf(baseUrl),(img_ary2[j].src.indexOf(\'?\') > 0 ? img_ary2[j].src.indexOf(\'?\') : img_ary2[j].src.length))){' . "\n";
		$rnd = rand();
		$script .= 'cxPreImages(updata_ary[i] + "?rnd=' . $rnd . '");' . "\n";
		$script .= 'img_ary2[j].src = updata_ary[i] + "?rnd=' . $rnd . '"' . "\n";
		$script .= '}' . "\n";
		$script .= '}' . "\n";
		$script .= '}' . "\n";
		//画像onLoad関数
		$script .= 'function img_load(org_img_obj,img_obj){' . "\n";
		$script .= 'var image_width_size = window.dialogArguments.image_prev_width;' . "\n";
		$script .= 'for(var i = 0;i < img_obj.length;i++){' . "\n";
		$script .= 'if(org_img_obj[i]){' . "\n";
		$script .= 'img_obj[i].src = org_img_obj[i].src;' . "\n";
		$script .= 'img_obj[i].width = (image_width_size > org_img_obj[i].width ? org_img_obj[i].width : image_width_size);' . "\n";
		$script .= 'img_obj[i].height = (image_width_size > org_img_obj[i].width ? org_img_obj[i].height : Math.round((image_width_size * org_img_obj[i].height) / org_img_obj[i].width));' . "\n";
		$script .= '}' . "\n";
		$script .= '}' . "\n";
		$script .= '}' . "\n";
		print($script);
		unset($_SESSION["updata_file"]);
	}
	?>
	<?php
	echo loadSettingVars();
	?>
//-->
</script>
<base target="_self" />
</head>
<body bgcolor="#FFFFFF">
<div id="cms8341-headareaZero" style="margin-bottom: 0px !important">
<table width="100%" height="554px" border="0" cellspacing="0"
	cellpadding="0" style="border-collapse: collapse;">
	<tr>
		<td width="100%" height="100%" align="center" valign="top"
			bgcolor="#DFDFDF"
			style="margin-bottom: 0px; border: solid 1px #343434;">
		<table width="100%" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/fckimage/title_imageset.jpg" alt="画像設定"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a
					href="javascript:cxIframeLayerCallback();" id="header_close"><img
					src="<?=RPW?>/admin/images/fckimage/btn_close.jpg" alt="閉じる"
					width="58" height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div id="cms8341-searcharea"
		style="width: 97%; overflow: auto; margin: 10px 0px; background-color: #DFDFDF; padding: 0px; text-align: left; border: solid 1px #343434;">
		<div id="cms8341-tab">
		<table border="0" cellspacing="0" cellpadding="0"
			style="border-collapse: collapse;">
			<tr>
				<td><a href="<?=RPW?>/admin/page/common/enq/image.php?mode=upload"><img
					src="<?=RPW?>/admin/images/fckimage/tab_pc_off.jpg" alt="PCから選んで登録"
					width="150" height="21" border="0"></a></td>
				<td><img src="<?=RPW?>/admin/images/fckimage/tab_server_on.jpg"
					alt="登録済ファイルから選択" width="150" height="21" border="0"></td>
			</tr>
		</table>
		</div>
		<table width="100%" height="493" cellspacing="0" cellpadding="0"
			style="background-color: #FFFFFF; border-top: solid 1px #999999;">
			<tr>
				<td bgcolor="FFFFFF" valign="top">
				<table width="100%" border="0" cellspacing="0" cellpadding="5"
					bgcolor="#FFFFFF" align="left" style="border-collapse: collapse;">
					<tr>
						<td align="center" style="padding: 10px;">
						<form name="cms_fck_image_list" id="cms_fck_image_list"
							action="<?=RPW?>/admin/page/common/enq/image_list.php"
							method="post">
						<div
							style="border-collapse: collapse; padding: 2px 2px 10px 2px; align: center"><img
							src="<?=RPW?>/admin/images/fckimage/bar_search.jpg" width="570"
							height="20" alt="画像ファイル検索"></div>
						<table border="0" cellspacing="0" cellpadding="0" width="98%"
							bgcolor="#F0F0F0"
							style="border-collapse: collapse; border: solid 1px #CCCCCC;">
							<tr>
								<td>
								<table border="0" cellspacing="0" cellpadding="0" align="left"
									width="100%"
									style="margin: 0px; padding: 2px; padding-left: 5px;">
									<tr>
										<th width="30%" align="left" valign="middle" scope="row"><label
											for="cms_fck_image_category">ファイル分類</label></th>
										<td width="70%" align="left"><select
											name="cms_fck_image_category" id="cms_fck_image_category"
											style="width: 275px;">
											<option value="<?=FCK_IMAGE_CATE_NOW?>"
												<?=(($search['category'] == FCK_IMAGE_CATE_NOW) ? 'selected' : '');?>>現在の場所</option>
											<option value="<?=FCK_IMAGE_CATE_SHARED?>"
												<?=(($search['category'] == FCK_IMAGE_CATE_SHARED) ? 'selected' : '');?>>共通画像</option>
										</select></td>
									</tr>
									<tr>
										<th width="30%" align="left" valign="middle"><label
											for="cms_fck_image_category"><label
											for="cms_fck_image_keyword">キーワード</label></th>
										<td width="70%" align="left"><input type="text"
											name="cms_fck_image_keyword" id="cms_fck_image_keyword"
											value="<?=htmlspecialchars($search['keyword'])?>"
											style="width: 270px;"></td>
									</tr>
									<tr>
										<th width="30%" align="left" valign="middle"><label
											for="cms_fck_image_update">表示順</label></th>
										<td width="70%" align="left">更新日の&nbsp; <input id="upd_asc"
											type="radio" name="cms_fck_image_update_datetime" value="0"
											<?=($search['update_datetime'] == FLAG_OFF) ? "checked" : "";?>>
										<label for="upd_asc">降順</label> <input id="upd_dsc"
											type="radio" name="cms_fck_image_update_datetime" value="1"
											<?=($search['update_datetime'] == FLAG_ON) ? "checked" : "";?>>
										<label for="upd_dsc">昇順</label></td>
									</tr>
									<tr>
										<th width="30%" align="left" valign="middle"><label
											for="cms_fck_image_thumbnail">サムネイル</label></th>
										<td width="70%" align="left">
											<?php
											$temp_ary = array(
													'非表示', 
													'表示'
											);
											print(mkradiobutton($temp_ary, "cms_fck_image_thumbnail_flg", $search['thumbnail_flg'], 0));
											?>
										</td>
									</tr>
								</table>
								</td>
								<td align="center" valign="middle" rowspan="4"><img
									src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt=""
									width="26" height="28"></td>
								<td width="121" align="center" valign="middle" rowspan="4"><a
									href="javascript:void(0)" onClick="return cxSearch()"
									tabindex="1"><img
									src="<?=RPW?>/admin/images/fckimage/btn_search.jpg" width="101"
									height="21" alt="検索" border="0"></a></td>
							</tr>
						</table>
						<input type="hidden" name="maxrow" id="search_maxrow"
							value="<?=$maxRow?>"></form>
						<div
							style="border-collapse: collapse; padding: 2px 2px 5px 2px; align: center"><img
							src="<?=RPW?>/admin/images/fckimage/bar_filelist.jpg" width="570"
							height="20" alt="画像ファイルリスト"></div>
						<table width="90%" border="0" cellspacing="0" cellpadding="0"
							style="margin-top: 0px; margin-bottom: 0px; padding: 1px">
							<tr valign="top">
								<td align="right">
																<?=mkcombobox($MAXROW_LIST, "dispNum", $maxRow, "cxDispNum(this.value)")?>
															</td>
							</tr>
						</table>
						<table width="100%" border="0" cellspacing="0" cellpadding="0"
							align="center">
							<tr>
								<td>
								<div
									style="width: 97%; height: 265px; overflow-y: scroll; overflow-x: hidden;"
									nowrap scope="row">
								<table width="97%" border="0" cellspacing="0" cellpadding="0"
									class="cms8341-dataTable"
									style="border-collapse: collapse; border: solid 1px #999999;">
																		<?=$drawHTML?>
																	</table>
								</div>
								</td>
							</tr>
						</table>
						</td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</div>
		<div class="cms8341-area-corner-page-count"
			style="width: 97%; margin-bottom: 12px; text-align: center;"><span
			style="float: left; width: 20%;"><?=$objP->getBackLink();?></span> <span
			style="float: right; width: 20%;"><?=$objP->getNextLink();?></span>
		<span style="width: 60%;"><?=$objP->getViewCount();?></span></div>
		</td>
	</tr>
</table>
</div>
<form name="cms_fck_image_select" id="cms_fck_image_select"
	action="<?=RPW?>/admin/page/common/enq/image.php" method="post"><input
	type="hidden" name="url" id="url" value=""> <input type="hidden"
	name="width" id="width" value=""> <input type="hidden" name="height"
	id="height" value=""> <input type="hidden" name="alt" id="alt" value="">
</form>
<form name="cms_page_post" id="cms_page_post" method="post" action=""><input
	type="hidden" name="cms_page" value=""> <input type="hidden"
	name="maxrow" id="maxrow" value=""> <input type="hidden"
	name="cms_fck_image_category" id="cms_fck_image_category"
	value="<?=$search['category']?>"> <input type="hidden"
	name="cms_fck_image_keyword" id="cms_fck_image_keyword"
	value="<?=$search['keyword']?>"> <input type="hidden"
	name="cms_fck_image_update_datetime" id="cms_fck_image_update_datetime"
	value="<?=$search['update_datetime']?>"> <input type="hidden"
	name="cms_fck_image_thumbnail_flg" id="cms_fck_image_thumbnail_flg"
	value="<?=$search['thumbnail_flg']?>"></form>
</body>
</html>