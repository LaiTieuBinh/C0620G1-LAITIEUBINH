/*
 *
 */
window.dialogArguments = window.frameElement.args;
var enq;
Event.observe(window,'load',function(){
	var id = window.dialogArguments['id'];
	if(!id) {
		alert('システムエラー：項目識別用IDが取得できませんでした');
		cxIframeLayerCallback();
	}
	enq = new EnqueteSet();
});

var EnqueteSet = Class.create();
var prm = "";
EnqueteSet.prototype = {
	//Constructor
	initialize:function() {
		//パラメータ初期設定
		this.result        = new Object();				//最終設定データ格納オブジェクト
		this.selectedType  = 'input';							//選択済みコントロール種類{input,textarea,radio,checkbox,select}
		this.selectedData;												//選択済みオプションオブジェクト
		this.selectedColor = '#FFFFCC';						//選択済みオプションオブジェクト背景色
		this.defaultColor  = '';									//通常オプションオブジェクト背景色
		this.handle = 1;													//処理フラグ　1=追加 2=編集
		this.checkLabel    = '（チェック済み）';	//チェック済みにした場合のラベルテキスト
		this.checkLabelBr  = '（改行あり）';	//改行ありにした場合のラベルテキスト
		
		//イベントリスナー登録
		Event.observe($('controll_a'), 'click', this.controllSet.bind(this));
		Event.observe($('controll_b'), 'click', this.controllSet.bind(this));
		Event.observe($('controll_c'), 'click', this.controllSet.bind(this));
		Event.observe($('controll_d'), 'click', this.controllSet.bind(this));
		Event.observe($('controll_e'), 'click', this.controllSet.bind(this));
		if($F('from_type')==1){
			Event.observe($('controll_f'), 'click', this.controllSet.bind(this));
		}
		Event.observe($('radio_add'), 'click', this.optionSet.bind(this));
		Event.observe($('radio_edit'), 'click', this.optionEdit.bind(this));
		Event.observe($('radio_del'), 'click', this.optionDel.bind(this));
		Event.observe($('radio_up'), 'click', this.optionUp.bind(this));
		Event.observe($('radio_down'), 'click', this.optionDown.bind(this));
		Event.observe($('checkbox_add'), 'click', this.optionSet.bind(this));
		Event.observe($('checkbox_edit'), 'click', this.optionEdit.bind(this));
		Event.observe($('checkbox_del'), 'click', this.optionDel.bind(this));
		Event.observe($('checkbox_up'), 'click', this.optionUp.bind(this));
		Event.observe($('checkbox_down'), 'click', this.optionDown.bind(this));
		Event.observe($('select_add'), 'click', this.optionSet.bind(this));
		Event.observe($('select_edit'), 'click', this.optionEdit.bind(this));
		Event.observe($('select_del'), 'click', this.optionDel.bind(this));
		Event.observe($('select_up'), 'click', this.optionUp.bind(this));
		Event.observe($('select_down'), 'click', this.optionDown.bind(this));
		Event.observe($('submit'), 'click', this.enqSubmit.bind(this));
		Event.observe($('cansel'), 'click', this.windowClose);
		Event.observe($('header_close'), 'click', this.windowClose);

		//データ受信処理
		var resObj = window.dialogArguments;
		if(resObj['name']) {
			$('name').value = resObj['name'];
			$('nes').checked = (resObj['nes']==1)? true : false;
			if ($('desc_mail')) {
				$('desc_mail').checked = (resObj['desc_mail']==1)? true : false;
			}
			$('memo').value = resObj['memo'];
			if($F('from_type')==0){
				if(resObj['img_alt'] != ""){
					$('cms_image').alt = resObj['img_alt'];
					$('cms_image_hidden').value += KANKO_LINK_DELIMITER + resObj['img_alt'];
				}
			}
			//画面描画
			var type = resObj['ctrl'];
			switch(type) {
				case "input_mail":
					$('controll_f').checked = true;
					if(ENQ_RETURN_MAIL_SEND_FLG == 1){
						$('input_detail_text').innerHTML = "<strong>メールアドレスの設定</strong>"
							+'&nbsp;<input type="checkbox" name="reply_mail_flg" id="reply_mail_flg" value="1">'
							+'<label for="reply_mail_flg">返信メールを送る</label>';
					}
					else{
						$('input_detail_text').innerHTML = "<strong>メールアドレスの設定</strong>";
						$('input_reply_mail_text').innerHTML = '&nbsp;<input type="checkbox" name="reply_mail_flg" id="reply_mail_flg" value="1">';
						$('reply_mail_flg').style.display = 'none';
					}
					break;
				case "input":
					$('controll_a').checked = true;
					$('input_detail_text').innerHTML = "<strong>テキスト（1行）の設定</strong>";
					$('input_reply_mail_text').innerHTML = '&nbsp;<input type="checkbox" name="reply_mail_flg" id="reply_mail_flg" value="1">';
					$('reply_mail_flg').style.display = 'none';
					break;
				case "textarea":
					$('controll_b').checked = true;
					break;
				case "radio":
					$('controll_c').checked = true;
					break;
				case "checkbox":
					$('controll_d').checked = true;
					break;
				case "select":
					$('controll_e').checked = true;
					break;
				default:
					if($F('from_type')==0) $('controll_a').checked = true;
					break;
			}
			var offElem = this.getTypeElements(this.selectedType);
			var onElem = this.getTypeElements(type);
			for(var i=0;i<offElem.length;i++) Element.hide(offElem[i]);
			for(var j=0;j<onElem.length;j++) Element.block(onElem[j]);
			if($(type+'_edit')) {
				$(type+'_edit').disabled = true;
				$(type+'_edit').style.pointerEvents = "none";
			}
			if($(type+'_del')) {
				$(type+'_del').disabled = true;
				$(type+'_del').style.pointerEvents = "none";
			}
			if($(type+'_up')) {
				$(type+'_up').disabled = true;
				$(type+'_up').style.pointerEvents = "none";
			}
			if($(type+'_down')) {
				$(type+'_down').disabled = true;
				$(type+'_down').style.pointerEvents = "none";
			}
			//共有パラメータ保存
			this.selectedType = type;
			//詳細情報設定
			var item = resObj['item'];
			if(type=='input_mail' || type=='input' || type=="textarea") {
				var type_temp = type;
				if(type=='input_mail') {
					type_temp = 'input';
					$('reply_mail_flg').checked = (item[0][3] == 1 ? true : false);
				}
				$(type_temp+'_set1').value = item[0][0];
				$(type_temp+'_set2').value = item[0][1];
				$(type_temp+'_set3').value = item[0][2];
			} else {
				for(var i=0;i<item.length;i++) {
					this.optionSetting(type,item[i][1],item[i][2],item[i][3]);
				}
			}
		}
		if(($F('from_type')==0) && !resObj['ctrl']) $('controll_a').checked = true;
	},
	//コントロール選択処理
	controllSet:function(e) {
		//オプションオブジェクトのリセット処理
		this.dataReset();
		//コントロール種別の取得
		var obj = e.srcElement || e.currentTarget;
		if(!obj || !obj.value) return;
		var type = obj.value;
		//画面描画
		var offElem = this.getTypeElements(this.selectedType);
		var onElem = this.getTypeElements(type);
		for(var i=0;i<offElem.length;i++) Element.hide(offElem[i]);
		for(var j=0;j<onElem.length;j++){
			Element.block(onElem[j]);
		}
		if(type == "input_mail"){
			var checked = (($('reply_mail_flg') != undefined) && $('reply_mail_flg').checked ? 'checked' : '');
			$('input_detail_text').innerHTML = "<strong>メールアドレスの設定</strong>";
			if(ENQ_RETURN_MAIL_SEND_FLG == 1){
				$('input_reply_mail_text').innerHTML = '&nbsp;<input type="checkbox" name="reply_mail_flg" id="reply_mail_flg" value="1"'+checked+'>'
					+'<label for="reply_mail_flg">返信メールを送る</label>';
			}
			else{
				$('input_reply_mail_text').innerHTML = '&nbsp;<input type="checkbox" name="reply_mail_flg" id="reply_mail_flg" value="1"'+checked+'>';
				$('reply_mail_flg').style.display = 'none';
			}
		} else if(type == "input"){
			var checked = (($('reply_mail_flg') != undefined) && $('reply_mail_flg').checked ? 'checked' : '');
			$('input_detail_text').innerHTML = "<strong>テキスト（1行）の設定</strong>";
			$('input_reply_mail_text').innerHTML = '&nbsp;<input type="checkbox" name="reply_mail_flg" id="reply_mail_flg" value="1"'+checked+'>';
			$('reply_mail_flg').style.display = 'none';
		}
		if($(type+'_edit')) {
			$(type+'_edit').disabled = true;
			$(type+'_edit').style.pointerEvents = "none";
			$(type+'_edit').style.cursor = '';
			$(type+'_edit').src = cms8341admin_path + '/images/set_enquete/btn_edit_off.jpg';
		}
		if($(type+'_del')) {
			$(type+'_del').disabled = true;
			$(type+'_del').style.pointerEvents = "none";
			$(type+'_del').style.cursor = '';
			$(type+'_del').src = cms8341admin_path + '/images/set_enquete/btn_del_off.jpg';
		}
		if($(type+'_up')) {
			$(type+'_up').disabled = true;
			$(type+'_up').style.pointerEvents = "none";
			$(type+'_up').style.cursor = '';
			$(type+'_up').src = cms8341admin_path + '/images/set_enquete/btn_up_off.jpg';
		}
		if($(type+'_down')) {
			$(type+'_down').disabled = true;
			$(type+'_down').style.pointerEvents = "none";
			$(type+'_down').style.cursor = '';
			$(type+'_down').src = cms8341admin_path + '/images/set_enquete/btn_down_off.jpg';
		}
		//共有パラメータ保存
		this.selectedType = type;
	},
	//コントロール種別ごとのオブジェクト取得処理:Array
	getTypeElements:function(A) {
		var retObj = {
			'input_mail':[$('sample_input'),$('input_detail')],
			'input':[$('sample_input'),$('input_detail')],
			'textarea':[$('sample_textarea'),$('textarea_detail')],
			'radio':[$('sample_radio'),$('radio_detail')],
			'checkbox':[$('sample_checkbox'),$('checkbox_detail')],
			'select':[$('sample_select'),$('select_detail')]
		};
		return retObj[A] || new Array();
	},
	//選択肢の設定処理
	optionSet:function() {
		switch(this.handle) {
			case 1:
				this.optionAdd();
				break;
			case 2:
				this.optionFix();
				break;
			default:
				alert('HANDLEに不正な値（'+this.handle+'）が設定されています。');
				break;
		}
	},
	//選択肢の画面描画処理
	optionSetting:function(A,B,C,D) {
		var listObj = $(A+'_result');
		var setObj = document.createElement('P');
		setObj.innerHTML = '<input type="radio" name="__uiselected">&nbsp;' + this.htmlEscape(B,true);
		if(C==1) {
			if(A!='checkbox') {
				//チェック済み重複チェック
				var dup_check = this.duplicateCheck($(A+'_result'));
				if(dup_check) {
					setObj.innerHTML += this.checkLabel;
				} else {
					C = 0;
				}
			} else {
				setObj.innerHTML += this.checkLabel;
			}
			setObj.checked = C;
		}
		if(D==1) {
			setObj.innerHTML += this.checkLabelBr;
			setObj.checkedBr = D
		}
		listObj.appendChild(setObj);
		//フォームリセット
		$(A+'_set1').value = '';
		$(A+'_set2').checked = false;
		if(A=='checkbox' || A=='radio') {
			$(A+'_set3').checked = false;
		}
		//イベントリスナー登録
		Event.observe(setObj,'click',this.dataClick.bind(this));
		//アニメーション定義
		// Sortable.create(A+'_result',{tag:'p',containment:'dummy',constraint:'false',onChange:this.sortChange.bind(this)});
	},
	//選択肢の新規追加処理
	optionAdd:function() {
		var type = this.selectedType;
		//オプションオブジェクトのリセット処理
		if(this.selectedData) this.dataReset();
		//入力・設定値の取得
		var set1 = $(type+'_set1').value;
		if(!set1) {
			alert('回答項目が入力されていません。');
			return;
		} else {
			var e = new Array();
			e = fckCheck('回答項目', set1, e);
			if(e.length!=0) {
				var msg = e.join('\n') + '\nよろしいですか？';
				if (!confirm(msg)) {
					$(type+'_set1').focus();
					return false;
				}
			}
		}
		var set2 = ($(type+'_set2').checked)? 1:0;
		if(type=='checkbox' || type=='radio') {
			var set3 = ($(type+'_set3').checked)? 1:0;
		}else{
			var set3 = 0;
		}
		//画面描画
		this.optionSetting(type, set1, set2, set3);
	},
	//選択肢の編集開始処理
	optionEdit:function() {
		var type = this.selectedType;
		if(!this.selectedData){
			alert('編集する項目が選択されていません');
			return;
		}
		//ハンドル変数に編集コードを設定
		this.handle = 2;
		//インターフェース設定
		var obj = this.selectedData.parentNode;
		var label = obj.innerText;
		    label = label.replace(this.checkLabel,'');
		    label = label.replace(this.checkLabelBr,'');
		    label = label.replace(/^\s/,'');
		var check = obj.checked;
		$(type+'_set1').value = label;
		if(check) {
			$(type+'_set2').checked = true;
		} else {
			$(type+'_set2').checked = false;
		}
		if(type=='checkbox' || type=='radio') {
			var checkBr = obj.checkedBr;
			if(checkBr) {
				$(type+'_set3').checked = true;
			} else {
				$(type+'_set3').checked = false;
			}
		}
		$(type+'_add').alt = '反映する';
		$(type+'_add').src = cms8341admin_path + '/images/set_enquete/btn_fixed.jpg';
		//オプションデータ編集用UIをOFF
		this.optionUICtrl(this.selectedType,'off');
	},
	//選択肢の編集処理
	optionFix:function() {
		var type = this.selectedType;
		if(!this.selectedData){
			alert('編集する項目が選択されていません');
			return;
		}
		//ハンドル変数に初期値（追加コード）を設定
		this.handle = 1;
		//編集処理
		//入力・設定値の取得
		var set1 = $(type+'_set1').value;
		if(!set1) {
			alert('回答項目が入力されていません。');
			return;
		} else {
			var e = new Array();
			e = fckCheck('回答項目', set1, e);
			if(e.length!=0) {
				var msg = e.join('\n') + '\nよろしいですか？';
				if (!confirm(msg)) {
					$(type+'_set1').focus();
					this.optionEdit();
					return false;
				}
			}
		}
		var set2 = ($(type+'_set2').checked)? 1:0;
		//チェック済みの場合のチェック済み重複チェック
		if(set2==1) {
			if(type!='checkbox') {
				var dup_check = this.duplicateCheck($(type+'_result'));
				if(!dup_check) set2 = 0;
			} else {
				var dup_check = true;
			}
		}
		if(type=='checkbox' || type=='radio') {
			var set3 = ($(type+'_set3').checked)? 1:0;
		}else{
			var set3 = 0;
		}
		//オプションオブジェクトのリセット処理
		var setObj = this.selectedData.parentNode;
		this.dataReset();
		//画面描画
		setObj.innerHTML = '<input type="radio" name="__uiselected">&nbsp;' + this.htmlEscape(set1,true);
		if(dup_check) setObj.innerHTML += this.checkLabel;
		setObj.checked = set2;
		if(set3) setObj.innerHTML += this.checkLabelBr;
		setObj.checkedBr = set3;
		
		//アニメーション定義
		// Sortable.create(type+'_result',{tag:'p',containment:'dummy',constraint:'false',onChange:this.sortChange.bind(this)});
		//インターフェース設定
		$(type+'_set1').value = '';
		$(type+'_set2').checked = false;
		if(type=='checkbox' || type=='radio') {
			$(type+'_set3').checked = false;
		}
		$(type+'_add').alt = '追加する';
		$(type+'_add').src = cms8341admin_path + '/images/set_enquete/btn_add.jpg';
	},
	//選択肢の削除
	optionDel:function() {
		if(!this.selectedData){
			alert('削除する項目が選択されていません');
			return;
		}
		var obj = this.selectedData.parentNode;
		var r = confirm('回答項目、'+obj.innerText+"を削除しますがよろしいですか？");
		if(r) {
			 Element.remove(this.selectedData.parentNode);
			this.optionUICtrl(this.selectedType,'off');
		}
	},
	//選択肢の表示順変更（上へ）処理
	optionUp:function() {
		var type = this.selectedType;
		if(!this.selectedData){
			alert('表示順を変更する項目が選択されていません');
			return;
		}
		var list = $(type+'_result');
		var obj = this.selectedData.parentNode;
		var obj2 = obj.previousSibling;
		if(!obj2 || this.selectedData == list.firstChild) return;
		list.removeChild(obj);
		list.insertBefore(obj, obj2);
		this.selectedData.checked = true;
		this.selectedData.focus();
		//アニメーションを中止
//		Sortable.destroy(type+'_result');
	},
	//選択肢の表示順変更（下へ）処理
	optionDown:function() {
		var type = this.selectedType;
		if(!this.selectedData){
			alert('表示順を変更する項目が選択されていません');
			return;
		}
		var list = $(type+'_result');
		var obj = this.selectedData.parentNode;
		var obj2 = obj.nextSibling;
		if(!obj2 || this.selectedData == list.lastChild) return;
		var obj3 = obj2.nextSibling;
		if(!obj3 || obj2 == list.lastChild){
			list.removeChild(obj);
			list.appendChild(obj);
		}else{
			list.removeChild(obj);
			list.insertBefore(obj, obj3);
		}

		this.selectedData.checked = true;
		this.selectedData.focus();
		//アニメーションを中止
//		Sortable.destroy(type+'_result');
	},
	//アニメーション領域更新イベント処理
	sortChange:function() {
		if(!this.selectedData) return;
		this.selectedData.checked = true;
	},
	//オプションオブジェクトのクリックイベント処理
	dataClick:function(e) {
		var obj = e.srcElement || e.currentTarget;
		if(!obj) return;
		if (obj.tagName == "P") {
			obj = obj.children[0];
		}
		//選択済みオブジェクトのクリア
		this.dataReset();
		//クリックしたオブジェクトの設定
		obj.checked = true;
		obj.parentNode.style.backgroundColor = this.selectedColor;
		this.selectedData = obj;
		//コントロール種類がRADIO,CHECKBOX,SELECTの場合、編集、削除ボタンを有効化
		this.optionUICtrl(this.selectedType,'on');
	},
	//選択済みオブジェクトのクリア
	dataReset:function() {
		if(!this.selectedData) return;
		if(!this.selectedData.parentNode) {
			alert('システムエラー：選択済みオブジェクトが見つかりません。');
			return;
		}
		this.selectedData.checked = false;
		this.selectedData.parentNode.style.backgroundColor = this.defaultColor;
		this.selectedData = null;
		//コントロール種類がRADIO,CHECKBOX,SELECTの場合、編集、削除ボタンを無効化
		this.optionUICtrl(this.selectedType,'off');
	},
	//チェック済み重複チェック＋ラベルリセット
	duplicateCheck:function(A) {
		var obj = A.getElementsByTagName('P');
		for(var i=0;i<obj.length;i++) {
			if(obj[i].checked==1) {
				if(this.selectedData && this.selectedData.parentNode==obj[i]) continue;
				var flg = confirm('既にチェック済みとしている回答項目があります。\n現在の設定項目をチェック済みとしますか？');
				if(flg) {
					obj[i].innerHTML = obj[i].innerHTML.replace(this.checkLabel,'');
					obj[i].checked = 0;
				}
				return flg;
			}
		}
		return true;
	},
	//オプションデータ編集用UI制御
	optionUICtrl:function(type,sw) {
		/*
		if(sw=='on') {
			if($(type+'_edit')) $(type+'_edit').disabled = false;
			if($(type+'_del')) $(type+'_del').disabled = false;
		} else {
			if($(type+'_edit')) $(type+'_edit').disabled = true;
		if($(type+'_del')) $(type+'_del').disabled = true;
		}
		*/
		if(sw!='on' && sw!='off') return;
		if(sw=='on') {
			if($(type+'_edit')) {
				$(type+'_edit').disabled = false;
				$(type+'_edit').style.pointerEvents = "auto";
				$(type+'_edit').style.cursor = 'pointer';
				$(type+'_edit').src = cms8341admin_path + '/images/set_enquete/btn_edit_'+sw+'.jpg';
			}
			if($(type+'_del')) {
				$(type+'_del').disabled = false;
				$(type+'_del').style.pointerEvents = "auto";
				$(type+'_del').style.cursor = 'pointer';
				$(type+'_del').src = cms8341admin_path + '/images/set_enquete/btn_del_'+sw+'.jpg';
			}
			if($(type+'_up')) {
				$(type+'_up').disabled = false;
				$(type+'_up').style.pointerEvents = "auto";
				$(type+'_up').style.cursor = 'pointer';
				$(type+'_up').src = cms8341admin_path + '/images/set_enquete/btn_up_'+sw+'.jpg';
			}
			if($(type+'_down')) {
				$(type+'_down').disabled = false;
				$(type+'_down').style.pointerEvents = "auto";
				$(type+'_down').style.cursor = 'pointer';
				$(type+'_down').src = cms8341admin_path + '/images/set_enquete/btn_down_'+sw+'.jpg';
			}
		} else {
			if($(type+'_edit')) {
				$(type+'_edit').disabled = true;
				$(type+'_edit').style.pointerEvents = "none";
				$(type+'_edit').style.cursor = '';
				$(type+'_edit').src = cms8341admin_path + '/images/set_enquete/btn_edit_'+sw+'.jpg';
			}
			if($(type+'_del')) {
				$(type+'_del').disabled = true;
				$(type+'_del').style.pointerEvents = "none";
				$(type+'_del').style.cursor = '';
				$(type+'_del').src = cms8341admin_path + '/images/set_enquete/btn_del_'+sw+'.jpg';
			}
			if($(type+'_up')) {
				$(type+'_up').disabled = true;
				$(type+'_up').style.pointerEvents = "none";
				$(type+'_up').style.cursor = '';
				$(type+'_up').src = cms8341admin_path + '/images/set_enquete/btn_up_'+sw+'.jpg';
			}
			if($(type+'_down')) {
				$(type+'_down').disabled = true;
				$(type+'_down').style.pointerEvents = "none";
				$(type+'_down').style.cursor = '';
				$(type+'_down').src = cms8341admin_path + '/images/set_enquete/btn_down_'+sw+'.jpg';
			}
		}
	},
	//入力チェック処理
	enqCheck:function() {
		var e = new Array();
		//*項目名
		if($F('name')=='') {
			alert('項目名が入力されていません。');
			$('name').focus();
			return false;
		} else {
			e = fckCheck('項目名', $F('name'), e);
		}
		//*注意事項
		if($F('memo')!='') {
			e = fckCheck('注意事項', $F('memo'), e);
		}
		//*回答項目
		if(this.selectedType!='input_mail' && this.selectedType!='input' && this.selectedType!='textarea') {
			var r = $(this.selectedType+'_result').getElementsByTagName('P');
			if(r.length==0) {
				alert('回答項目が設定されていません。');
				$(this.selectedType+'_set1').focus();
				return false;
			}
		}else{
			$type = this.selectedType;
			if(this.selectedType=='input_mail') $type = 'input';
			if($F($type+"_set3")!='') {
				e = fckCheck('初期値', $F($type+"_set3"), e);
			}
		}
		//*アクセシビリティチェック結果
		if(e.length!=0) {
				var msg = e.join('\n') + '\nよろしいですか？';
				if (!confirm(msg)) {
					return false;
				}
			}
		return true;
	},
	//各項目のコントロール詳細情報を取得
	getItemInfo:function(type) {
		var ret = new Array();
		var imput_mail_flg = false;
		switch(type) {
			case "input_mail":
				type = "input";
				imput_mail_flg = true;
			case "input":
			case "textarea":
				var A = new Array();
				A.push(this.htmlEscape($F(type+"_set1"),true));	//input:横幅				textarea:横幅
				A.push(this.htmlEscape($F(type+"_set2"),true));	//input:最大文字数	textarea:縦幅
				A.push(this.htmlEscape($F(type+"_set3"),true));	//input:初期値			textarea:初期値
				if (imput_mail_flg) {
					A.push((($F('reply_mail_flg') == 1 ? 1 : 0)));	//input:返信メール
				}
				ret.push(A);
				break;
			case "radio":
			case "checkbox":
			case "select":
				var A;
				var obj = $(type+'_result').getElementsByTagName('P');
				for(var i=0;i<obj.length;i++) {
					A = new Array();
					A.push(i);																						//表示順（0スタート）
					var text = obj[i].innerText;
					text = text.replace(this.checkLabel,'');
					text = text.replace(this.checkLabelBr,'');
					A.push(this.htmlEscape(text,true));	//回答項目名称
					A.push(obj[i].checked);																//初期チェックフラグ
					A.push(obj[i].checkedBr);																//改行フラグ
					ret.push(A);
				}
				break;
			default:
				alert("システムエラー：コントロール詳細情報の取得中に不正なコントロール識別子が指定されました。（" + type + "）");
				return false;
				break;
		}
		return ret;
	},
	//HTMLエスケープ処理
	htmlEscape:function(str,flg) {
		var ret = str;
		if(flg == true){
			ret = ret.replace(/\&/g,'&amp;');
			ret = ret.replace(/</g,'&lt;');
			ret = ret.replace(/>/g,'&gt;');
			ret = ret.replace(/\"/g,'&quot;');
		}
		return ret;
	},
	//最終決定処理
	enqSubmit:function() {
		var chk = this.enqCheck();
		if(!chk) return false;
		submit_end();
	},
	//ウィンドウを閉じる
	windowClose:function(){
		if(!window.returnValue) window.returnValue = false;
		cxIframeLayerCallback();
	}
}

/**
 * submit完了処理
 * 
 */
function submit_end(){
	var retObj = new Object();
	retObj["id"]   = window.dialogArguments["id"];
	retObj["name"] = enq.htmlEscape($F('name'),true);
	retObj["nes"]  = ($('nes').checked==true)? 1 : 0;
	retObj["desc_mail"]  = ($('desc_mail') && $('desc_mail').checked==true)? 1 : 0;
	retObj["memo"] = enq.htmlEscape($F('memo'),true);
	retObj["ctrl"] = enq.selectedType;
	retObj["item"] = enq.getItemInfo(enq.selectedType);
	retObj["img"] = '';
	retObj["img_alt"] = '';

	if($F('from_type') == 0){
		if(document.enq_form.cms_image_hidden.value != ""){
			retObj["img"] = document.enq_form.cms_image.src;
			retObj["img_alt"] = document.enq_form.cms_image.alt;
		}
	}
	cxIframeLayerCallback(retObj);
}

function IsDigit(e){
	e = e || event ;
	var iCode = ( e.keyCode || e.charCode ) ;
	event.returnValue =
		(
			( iCode >= 48 && iCode <= 57 )		// Numbers
			|| (iCode >= 37 && iCode <= 40)		// Arrows
			|| iCode == 8						// Backspace
			|| iCode == 46						// Delete
		) ;
	return event.returnValue ;
}

//通信失敗処理
function cxFailure() {
//	$('cms8341-errormsg').innerHTML = '<p align="center">情報取得中に通信エラーが発生しました</p>';
//	cxLayer('cms8341-error',1,500,375);
}
//	ファイルパスの拡張子部分を取得
function getExtention(path){
	var arr;
	var ext;
	
	ext = "";
	arr = path.split(".");
	if(arr.length == 0) return ext;
	ext = arr[arr.length-1];
	return ext;
}
//	ファイル存在チェック結果
function cxRefferFileUploadCheckOK(r){
	var xmlDoc = r.responseXML.documentElement;
	if (!xmlDoc || xmlDoc.nodeName != 'Paths') {
		return;
	}

	var UpPath = xmlDoc.childNodes.item(0);
	var CompPath = xmlDoc.childNodes.item(0);

	if (CompPath.attributes.getNamedItem('value').value != '') {
		return;
	} else {
		prm = 'file_path='+UpPath.attributes.getNamedItem('value').value;
		cxAjaxCommand('cxRefferFileUploadCheck', prm, cxRefferFileUploadCheckOK);
	}
}
