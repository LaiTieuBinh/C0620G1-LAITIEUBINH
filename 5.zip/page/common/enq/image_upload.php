<?php
/*
 * 画像のアップロードを行う
 */
//設定ファイル読み込み
require_once ("./.htsetting");

//エラー画面設定 別ウィンドウ用
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

//DBアクセス用ファイルの読み込み
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);

//変数の初期化
unset($_SESSION["err_msg"]);
$_SESSION['err_msg'] = "";
unset($_SESSION['post']);
unset($_SESSION["updata_file"]);
$_SESSION["updata_file"] = array();
//フォルダパス
$base_path = "";
$real_base_path = DOCUMENT_ROOT . RPW;
//ファイルパス
$file_path = "";
$real_file_path = "";

//フォルダパスの取得
//SESSIONを取得できる場合
if (isset($_SESSION['cms_page_id']) && $_SESSION['cms_page_id'] != "") {
	//パス取得
	if ($objPage->selectFromID($_SESSION['cms_page_id'], WORK_TABLE, "file_path") !== FALSE) {
	}
	else if ($objPage->selectFromID($_SESSION['cms_page_id'], PUBLISH_TABLE, "file_path") !== FALSE) {
	}
	else
		user_error('ページ情報を取得できませんでした。', E_USER_ERROR);
	$base_path = cms_dirname($objPage->fld['file_path']);
	$real_base_path .= $base_path;
}
else
	user_error('ログイン情報を取得できませんでした。現在の開いている全てのブラウザを閉じて再度実行してください。', E_USER_ERROR);
	
//アップロードファイル数分ループ
$i = 0;
foreach ($_FILES as $file_key => $Up_File) {
	//ファイルID
	$i = substr($file_key, -1);
	//ファイル名
	$file_name = "";
	//エラーメッセージ
	$err_msg = "";
	//一時使用ファイルパス
	$base_path_tmp = "";
	$real_base_path_tmp = "";
	
	//ファイルが無ければスキップ
	if ($Up_File['name'] == "") continue;
	
	//フォルダ名追加
	$base_path_tmp = $base_path . FCK_IMAGES_FORDER;
	$real_base_path_tmp = $real_base_path . FCK_IMAGES_FORDER;
	
	//ファイルパスの設定
	//リネームが存在した場合、リネームされたファイル名を使用する
	if (isset($_POST['cms_rename_file_path_' . $i]) && $_POST['cms_rename_file_path_' . $i] != "") $file_name = strtolower(basename($_POST['cms_rename_file_path_' . $i]));
	else $file_name = strtolower($Up_File['name']);
	$file_path = $base_path_tmp . "/" . $file_name;
	$real_file_path = DOCUMENT_ROOT . RPW . $file_path;
	
	//エラー処理を行うため、whileを使用
	while (true) {
		//同名ファイルの確認
		$temp_ary = array(
				$i => RPW . $file_path
		);
		if (@file_exists($real_file_path)) $_SESSION["updata_file"] = array_merge($_SESSION["updata_file"], $temp_ary);
		//ファイルチェック
		if (!is_uploaded_file($Up_File["tmp_name"])) $err_msg = "不正なファイルが選択されています。";
		//ファイルエラーチェック
		if ($Up_File["error"] != UPLOAD_ERR_OK) $err_msg = "ファイルのアップロードに失敗しました。";
		//拡張子チェック
		$File_Exte = explode(",", DENIED_EXTENSIONS_FILE);
		foreach ($File_Exte as $exte) {
			if (preg_match('/(\.' . $exte . ')$/i', $file_name)) $err_msg = "指定されたファイルはアップロードすることが出来ません。";
		}
		//携帯用の拡張子及びサイズの取得
		if (isset($_SESSION['use_template_kind']) && $_SESSION['use_template_kind'] == TEMPLATE_KIND_MOBILE) {
			$File_Exte = explode(",", ALLOWED_EXTENSIONS_IMAGE_MOBILE);
			$Image_Max_Size_Width = FCK_MOBILE_UPLOAD_IMAGE_W;
			$Image_Max_Size_Height = FCK_MOBILE_UPLOAD_IMAGE_H;
		} //通常用の拡張子及びサイズの取得
		else {
			$File_Exte = explode(",", ALLOWED_EXTENSIONS_IMAGE);
			$Image_Max_Size_Width = FCK_UPLOAD_IMAGE_W;
			$Image_Max_Size_Height = FCK_UPLOAD_IMAGE_H;
		}
		//全て小文字に変換
		foreach ($File_Exte as $k => $val) {
			$File_Exte[$k] = strtolower($val);
		}
		//画像の情報取得
		$image_info = @getimagesize($Up_File["tmp_name"]);
		if (!isset($image_info) || isset($image_info) && $image_info == null) {
			$err_msg = "指定されたファイルはアップロードすることが出来ません。";
			break;
		}
		//拡張子によっての処理
		switch ($image_info[2]) {
			//GIF
			case IMG_GIF :
				if (!in_array("gif", $File_Exte)) $err_msg = "指定されたファイルはアップロードすることが出来ません。";
				break;
			//PNG
			case 3 :
			case IMG_PNG :
				if (!in_array("png", $File_Exte)) $err_msg = "指定されたファイルはアップロードすることが出来ません。";
				break;
			//JPG
			case IMG_JPG :
			case IMG_JPEG :
				if (!in_array("jpg", $File_Exte) && !in_array("jpeg", $File_Exte)) $err_msg = "指定されたファイルはアップロードすることが出来ません。";
				break;
			//その他
			default :
				$err_msg = "指定されたファイルはアップロードすることが出来ません。";
				break;
		}
		//ファイル名チェック
		//使用不可の記号チェック
		if (preg_match('/[^\w\-_\.~]/i', $file_name)) $err_msg = "アップロードできないファイル名です。ファイル名に使用できるのは半角英数字と - _ . ~ です。";
		//「.」が複数含まれているかチェック
		if (strpos($file_name, '.') != strrpos($file_name, '.')) $err_msg = "ファイル名に「.」が二つ以上ついているファイルはアップロードすることが出来ません。";
		//「.」がファイル名の先頭に含まれているかチェック
		if (strpos($file_name, '.') == 0) $err_msg = "ファイル名にの先頭に「.」がついているファイルはアップロードすることが出来ません。";
		//ファイルサイズチェック
		//0byte以下のファイルチェック
		if ($Up_File["size"] <= 0) $err_msg = "ファイルサイズが0バイトのファイルは取り込めません。";
		//ファイルMAXサイズチェック
		if (is_none_check_dir($real_file_path) === FALSE && $Up_File["size"] > FCK_UPLOAD_MAX_IMAGE * 1024) $err_msg = "画像ファイルの容量が大き過ぎます。";
		//エラーがあれば、抜ける
		if ($err_msg != "") break;
		
		//ファイルの移動処理
		//フォルダが存在しなければ、フォルダを作成
		if (!is_dir($real_base_path_tmp)) {
			if (!@mkdir($real_base_path_tmp, 0777)) $err_msg = "ファイルのアップロードに失敗しました。";
		}
		//エラーがあれば、抜ける
		if ($err_msg != "") break;
		
		//ファイルの移動
		if (@move_uploaded_file($Up_File["tmp_name"], ($real_file_path))) chmod($real_file_path, 0777);
		else $err_msg = "ファイルのアップロードに失敗しました。";
		//ファイルリサイズ
		if (!mkThumbnail($real_file_path, $Image_Max_Size_Width, $Image_Max_Size_Height)) $err_msg = "ファイルのアップロードに失敗しました。";
		//エラーがあれば、抜ける
		if ($err_msg != "") break;
		
		//登録処理
		$Up_File_Info = pathinfo($real_file_path);
		//登録用配列の設定
		$filedtl_ary = array();
		$filedtl_ary["name"] = $_POST['cms_image_name_' . $i]; //画像名称
		$filedtl_ary["path"] = $file_path; //ファイルパス
		//登録処理
		$objCnc->begin();
		//「tbl_fck_images」に同じパスが存在する場合、削除する
		if ($objFCKImages->selectFCKImage($file_path)) {
			if (!$objFCKImages->deleteFromImagePath($file_path)) $err_msg = "データベースの更新に失敗しました。";
		}
		//「tbl_fck_images」にアップロードした画像情報の登録
		if (!$objFCKImages->insert($filedtl_ary)) $err_msg = "データベースへの登録に失敗しました。";
		//「tbl_handler」にアップロードした画像のあるフォルダのアクセス権限を登録
		$dept_code = $objLogin->get('dept_code');
		$dir = cms_dirname($file_path) . "/";
		//組織コードの値がウェブマスター以外の場合、登録処理を行う
		if ($dept_code != WEB_MASTER_CODE) {
			//権限登録
			$temp_ary = array(
					$dir
			);
			if (!insert_handler_directory($dept_code, $temp_ary)) {
				$err_msg = "組織情報の登録に失敗しました。";
			}
		}
		//エラーが無ければ、登録する
		if ($err_msg == "") {
			// アップロードしたファイルリストに追加
			if (!isset($_SESSION['depend']['uplist']) || !in_array($file_path, $_SESSION['depend']['uplist'])) $_SESSION['depend']['uplist'][] = $file_path;
			$objCnc->commit();
		} //エラーがあれば、元に戻す
		else
			$objCnc->rollback();
		break;
	}
	
	//エラーメッセージがあれば、通常表示
	if ($err_msg != "") {
		if (@file_exists($real_file_path)) @unlink($real_file_path);
		$_SESSION['err_msg'] .= "ファイル" . ($i + 1) . " : " . $err_msg . '\n';
		if (!isset($_SESSION['post'])) $_SESSION['post'] = array();
		$_SESSION['post']['cms_image_name_' . $i] = $_POST['cms_image_name_' . $i];
	}
}

if (isset($_SESSION["err_msg"]) && $_SESSION["err_msg"] != "") header("Location: " . HTTP_ROOT . RPW . "/admin/page/common/enq/image.php");
else header("Location: " . HTTP_ROOT . RPW . "/admin/page/common/enq/image_list.php");
?>
