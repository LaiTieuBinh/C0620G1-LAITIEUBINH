<?php
/*
 *
 */
mb_language('Japanese');
mb_internal_encoding('UTF-8');

$ret = $_POST;
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>アンケート設定確認</title>
</head>

<body>
<h1>アンケート設定確認</h1>
<h2>取得データ</h2>
<?php
$item_title = $ret['item_title'];
$item_nes = $ret['item_nes'];
$item_memo = $ret['item_memo'];
$item_ctrl = $ret['item_ctrl'];
$ctrl = $ret['ctrl'];

$item_cnt = count($item_title);

$Html = '';
for($i = 0; $i < $item_cnt; $i++) {
	echo '<table width="80%" border="1" cellspacing="1" cellpadding="3">' . "\n";
	echo '<tr>' . "\n";
	echo '<th width="30%" align="left" valign="top">項目名称</th>' . "\n";
	echo '<td align="left" valign="top">' . htmlspecialchars($item_title[$i]) . '</td>' . "\n";
	echo '</tr>' . "\n";
	echo '<tr>' . "\n";
	echo '<th align="left" valign="top">必須フラグ</th>' . "\n";
	echo '<td align="left" valign="top">' . $item_nes[$i] . '</td>' . "\n";
	echo '</tr>' . "\n";
	echo '<tr>' . "\n";
	echo '<th align="left" valign="top">注意事項</th>' . "\n";
	echo '<td align="left" valign="top">' . nl2br(htmlspecialchars($item_memo[$i])) . '&nbsp;</td>' . "\n";
	echo '</tr>' . "\n";
	;
	echo '<tr>' . "\n";
	echo '<th align="left" valign="top">コントロール種類</th>' . "\n";
	echo '<td align="left" valign="top">' . $item_ctrl[$i] . '</td>' . "\n";
	echo '</tr>' . "\n";
	echo '<tr>' . "\n";
	echo '<th align="left" valign="top">コントロール詳細情報</th>' . "\n";
	echo '<td align="left" valign="top">' . "\n";
	for($j = 0; $j < count($ctrl[$i]); $j++) {
		echo '<ol>' . "\n";
		echo '<li>' . $ctrl[$i][$j][0] . '</li>' . "\n";
		echo '<li>' . htmlspecialchars($ctrl[$i][$j][1]) . '</li>' . "\n";
		echo '<li>' . htmlspecialchars($ctrl[$i][$j][2]) . '</li>' . "\n";
		echo '</ol>' . "\n";
	}
	echo '</td>' . "\n";
	echo '</tr>' . "\n";
	echo '</table><br>' . "\n";
}
?>
<hr>
<p><a href="javascript:history.back()">前のページに戻る</a></p>
</body>
</html>
