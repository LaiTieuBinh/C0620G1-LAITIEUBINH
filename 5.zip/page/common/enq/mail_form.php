<?php
/*
 *
 */
require ("./.htsetting");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>組織から選ぶ</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/master/user/user.css"
	type="text/css">
<style type="text/css">
.cms8341-enqsettingarea {
	width: 732px;
	height: 621px;
	overflow: auto;
	margin: 0px 0px 10px 0px;
	background-color: #FFFFFF;
	padding: 15px 19px 15px 19px;
	text-align: left;
	border: solid 1px #999999;
	font-size: 14px;
}

.cms8341-wrapper {
	width: 710px;
}
</style>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
//
function cxOpenMailUser(){
	Element.show('header_area');
	str = '<p style="margin-bottom:2px;">検索したいユーザー名を入力してください</p>';
	str = str + '<p style="margin-top:2px;"><input type="text" name="user_name" id="user_name" class="cms8341-verticalMiddle"> <img id="cms_search" src="<?=RPW?>/admin/images/set_enquete/btn_addsearch.jpg" width="60" height="20" alt="検索する" onClick="cxUserSearch()" class="cms8341-verticalMiddle" style="cursor:pointer"></p>';
	$('header_area').innerHTML = str;
	$('data_area').innerHTML = "";
	Event.observe($('user_name'),'keypress',cxKeyPress,false);
}
function cxUserSearch(){
	var prm = "name="+$F('user_name');
	$('data_area').innerHTML = "検索中...";
	var a = new Ajax.Updater(
       'data_area',
       cms8341admin_path+'/page/common/enq/mail_user_exec.php',
       {   
          method: 'post',
          postBody: prm,
          onSuccess: function(request) {
          },   
          onFailure: function(request) {   
             alert('失敗しました');   
          }   
       }   
    );   
}

function cxOpenMailDept(){
	$('header_area').innerHTML = "";
	$('data_area').innerHTML = "";
	Element.hide('header_area');
	cxDeptReload("");
}
function cxDeptReload(url){
	var a = new Ajax.Updater(
       'data_area',
       cms8341admin_path+'/page/common/enq/mail_dept_exec.php',
       {   
          method: 'post',
          postBody: url,
          onSuccess: function(request) {
          },   
          onFailure: function(request) {   
             alert('失敗しました');   
          }   
       }   
    );   
}
function cxOpenMailInput(){
	Element.show('header_area');
	str = '<p style="margin-bottom:2px;">メールアドレスを入力してください</p>';
	str = str + '<p style="margin-top:2px;"><input type="text" name="email" id="email" style="ime-mode:disabled" class="cms8341-verticalMiddle"> ';
	str = str + '<img id="cms_email_set" src="<?=RPW?>/admin/images/set_enquete/btn_addset.jpg" width="60" height="20" alt="設定する" onClick="cxInputSubmit()" class="cms8341-verticalMiddle" style="cursor:pointer"></p>';
	$('header_area').innerHTML = str;
	$('data_area').innerHTML = "";
	Event.observe($('email'),'keypress',cxKeyPress,false);
}
function cxInputSubmit(){
	if($F('email') == ""){
		alert("メールアドレスを入力してください。");
		return;
	}
	word = "[!#-9A-~]+@+[a-z0-9]+.+[^.]$";
	var regObj = new RegExp(word,"i");
	if (!$F('email').match(regObj)) {
		alert("メールアドレスとしてふさわしくない値が入力されています。");
		$('email').focus();
		return;
	}
	cxSubmit("直接入力",$F('email'));
}
function cxKeyPress(event){
	var item = Event.element(event);
	if(event.keyCode == 13){
		if(item.id == "email"){
			cxInputSubmit();
		} else if(item.id == "user_name"){
			cxUserSearch();
		}
	}
}

function cxSubmit(name,email){
	var retObj = new Object();
	retObj["name"]   = name;
	retObj["email"] = email;
	cxIframeLayerCallback(retObj);
}
function cxInit() {
	Event.observe($('cms_mail_user'),'click',cxOpenMailUser,false);
	Event.observe($('cms_mail_dept'),'click',cxOpenMailDept,false);
	Event.observe($('cms_mail_input'),'click',cxOpenMailInput,false);
	$('header_area').innerHTML = "";
	$('data_area').innerHTML = "";
	Element.hide('header_area');
	cxDeptReload("");
}
Event.observe(window,'load',cxInit,false);
//-->
</script>
</head>

<body id="cms8341-mainbg">
<table width="792" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="792" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="792" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/set_enquete/title_mailadd.jpg"
					alt="メール送信先の追加" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="#"
					onclick="cxIframeLayerCallback();" id="header_close"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="text-align: left; margin-top: 12px;"><img
			id="cms_mail_dept"
			src="<?=RPW?>/admin/images/set_enquete/select_dept.jpg" width="120"
			height="20" alt="組織から選ぶ"
			style="cursor: pointer; margin-left: 10px; margin-right: 5px;"><img
			id="cms_mail_user"
			src="<?=RPW?>/admin/images/set_enquete/select_user.jpg" width="120"
			height="20" alt="ユーザから選ぶ" style="cursor: pointer; margin-right: 5px;"><img
			id="cms_mail_input"
			src="<?=RPW?>/admin/images/set_enquete/select_free.jpg" width="120"
			height="20" alt="直接入力" style="cursor: pointer; margin-right: 5px;"></div>
		<div class="cms8341-enqsettingarea">
		<div class="cms8341-wrapper">
		<div id="header_area"></div>
		<div id="data_area"></div>
		</div>
		</div>

</body>
</html>