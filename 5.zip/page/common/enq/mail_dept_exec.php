<?php
/*
 * ユーザ管理　一覧画面(index.php)
 */
require ("./.htsetting");

$StrDbg = "";
$GLOBALS["StrDbg"] = "";

/*---------------------------------------------
	定数 
----------------------------------------------*/

//表示＆組織レベル
define("G_DEPT_LEVEL00", 0); //初期画面
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


//エクスプローラー風プラマイ記号イメージPath
define("G_LIST_IMG_P", RPW . "/admin/master/images/dir_plus.jpg"); //プラス
define("G_LIST_IMG_M", RPW . "/admin/master/images/dir_minus.jpg"); //マイナス


//クラスイメージPath
$G_AreClassImg[] = array(
		RPW . "/admin/master/user/images/author.gif", 
		RPW . "/admin/master/user/images/approve01.gif", 
		RPW . "/admin/master/user/images/approve02.gif", 
		RPW . "/admin/master/user/images/approve03.gif"
);
$G_AreClassImg[] = array(
		"ページ作成者", 
		"第1承認者", 
		"第2承認者", 
		"第3承認者"
);

/*---------------------------------------------------------------------------------
	imprt.php
---------------------------------------------------------------------------------*/

/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

/*---引数の取得---*/
$args = ($_SERVER['REQUEST_METHOD'] == 'GET') ? $_GET : $_POST;
//表示レベル
if (isset($_REQUEST["level"]) == TRUE) {
	$PrmLevel = $args['level'];
	if (($PrmLevel != G_DEPT_LEVEL00) & ($PrmLevel != G_DEPT_LEVEL01) & ($PrmLevel != G_DEPT_LEVEL02) & ($PrmLevel != G_DEPT_LEVEL03)) {
		DispError("有効ではないパラメーターが指定されました。", 3, "javascript:history.back()");
		exit();
	}
}
else {
	//未指定の場合は初期画面表示
	$PrmLevel = G_DEPT_LEVEL00;
}
//組織コード
$PrmDeptCode = "";
if (($PrmLevel == G_DEPT_LEVEL01) || ($PrmLevel == G_DEPT_LEVEL02) || ($PrmLevel == G_DEPT_LEVEL03)) {
	if (isset($_REQUEST["dept_code"]) == TRUE) {
		$PrmDeptCode = $args['dept_code'];
	}
	else {
		//未指定の場合は初期画面表示
		$PrmLevel = G_DEPT_LEVEL00;
	}
}

/*--- データアクセスクラス ---*/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*--- ウェブマスタの取得---*/
$sql = "SELECT user_id, dept_code, name, email, item1 FROM tbl_user AS u " . "LEFT JOIN (SELECT item1 FROM tbl_handler WHERE class=" . HANDLER_CLASS_OEPN_FLG . ") AS h ON u.user_id = h.item1 " . "WHERE (dept_code = '" . WEB_MASTER_CODE . "') " . "ORDER BY user_id";
$objDac->execute($sql);
//ウェブマスタデータの作成
$DspWebMst = "";
while ($objDac->fetch()) {
	
	if (strlen($objDac->fld['item1']) <= 0) {
		$DspWebMst = $DspWebMst . 
/*				"<p align=\"left\"><img src=\"" . RPW . "/admin/master/user/images/webmaster.gif\" alt=\"ウェブマスター\" width=\"100\" height=\"20\">　" . 
			"<a href=\"" . "detail.php?user_id=". $objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL00. "&dept_code=" . WEB_MASTER_CODE ."\">" . 
			htmlspecialchars($objDac->fld['name']) . "</a></p>\n";*/
			"<p align=\"left\"><img src=\"" . RPW . "/admin/master/user/images/webmaster.gif\" alt=\"ウェブマスター\" width=\"100\" height=\"20\">　" . "<a href=\"#\" onClick=\"return cxSubmit('" . ArgConvert($objDac->fld['name']) . "','" . $objDac->fld['email'] . "')\" style=\"color:#0000FF\" title=\"" . $objDac->fld['email'] . "\">" . htmlspecialchars($objDac->fld['name']) . "</a></p>\n";
	}
	else {
		$DspWebMst = $DspWebMst . "<p align=\"left\"><img src=\"" . RPW . "/admin/master/user/images/open.gif\" alt=\"公開責任者\" width=\"100\" height=\"20\">　" . //				"<a href=\"" . "detail.php?user_id=". $objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL00. "&dept_code=" . WEB_MASTER_CODE ."\">" . 
"<a href=\"#\" onClick=\"return cxSubmit('" . ArgConvert($objDac->fld['name']) . "','" . $objDac->fld['email'] . "')\" style=\"color:#0000FF\" title=\"" . $objDac->fld['email'] . "\">" . htmlspecialchars($objDac->fld['name']) . "</a></p>\n";
	}
}

/*---一覧の取得---*/
//取得レベルに応じた表示データの作成
$DspLstUser = "";
switch ($PrmLevel) {
	case G_DEPT_LEVEL00 : //初期画面
		G_SetDspList_Level00($objDac, $DspLstUser);
		break;
	case G_DEPT_LEVEL01 : //部
		G_SetDspList_Level01($objDac, $PrmDeptCode, $G_AreClassImg, G_LIST_IMG_P, $DspLstUser);
		break;
	case G_DEPT_LEVEL02 : //課
		//課リストを作成
		G_SetDspList_Level02($objDac, $PrmDeptCode, $G_AreClassImg, G_LIST_IMG_P, $DspLstUser);
		break;
	case G_DEPT_LEVEL03 : //係
		//係リストを作成
		G_SetDspList_Level03($objDac, $PrmDeptCode, $G_AreClassImg, G_LIST_IMG_P, $DspLstUser);
		break;
}

header("Content-Type: text/html; charset=UTF-8");
print $DspWebMst . $DspLstUser;
exit();

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	レベル０、初期画面表示データ作成

【引数】	$i_objDac		取得されたデーターオブジェクト
		$o_DspLstUser	表示する一覧データ
		
【戻値】	True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspList_Level00($i_objDac, &$o_DspLstUser) {
	
	/*---展開されたデータを作成---*/
	$sql = "SELECT tbl_department.sort_order, tbl_department.level, tbl_department.dept_code, tbl_department.dept_name, Count(tbl_user.dept_code) AS dept_cnt, " . "tbl_user.user_id " . "FROM tbl_user RIGHT JOIN tbl_department ON tbl_user.dept_code = tbl_department.dept_code " . "GROUP BY tbl_department.sort_order, tbl_department.level, tbl_department.dept_code, tbl_department.dept_name " . "HAVING (tbl_department.level=" . G_DEPT_LEVEL01 . ") " . "ORDER BY tbl_department.dept_code, tbl_department.level, tbl_department.sort_order, tbl_user.class, tbl_user.user_id";
	
	//取得
	$i_objDac->execute($sql);
	
	//データ作成
	while ($i_objDac->fetch()) {
		$param = "level=" . G_DEPT_LEVEL01 . "&dept_code=" . $i_objDac->fld['dept_code'];
		$o_DspLstUser .= "<p align=\"left\" class=\"dir_first\">" . "<img src=\"" . G_LIST_IMG_P . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
	}

}

/*-----------------------------------------------------------------------------
	レベル１　「部」の展開

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_PrmDeptCode	引数で指定された組織コード
		$i_AreClassImg	画像のイメージパスが格納されているテーブル
		$i_ExpImg		展開部分のプラマイ記号
		$o_DspLstUser	表示する一覧データ
		
【戻値】	True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspList_Level01($i_objDac, $i_PrmDeptCode, $i_AreClassImg, $i_ExpImg, &$o_DspLstUser) {
	
	/*--- 組織コード部の切り出し ---*/
	$dept_01 = substr($i_PrmDeptCode, 0, CODE_DIGIT_DEPT);
	
	/*---対象となる部に所属しているユーザーを取得---*/
	$sql = "SELECT tbl_user.dept_code, tbl_user.class, tbl_user.user_id, tbl_user.name, tbl_user.email, tbl_department.dept_name " . "FROM tbl_user INNER JOIN tbl_department ON tbl_user.dept_code = tbl_department.dept_code " . "WHERE (((tbl_user.dept_code)='" . $i_PrmDeptCode . "')) " . "ORDER BY tbl_user.dept_code, tbl_user.class, tbl_user.user_id";
	//取得
	$i_objDac->execute($sql);
	$down_user_list = "";
	while ($i_objDac->fetch()) {
		$down_user_list .= "<p align=\"left\" class=\"dir_second\">" . "<img src=\"" . $i_AreClassImg[0][($i_objDac->fld['class'] - 1)] . "\" alt=\"" . $i_AreClassImg[1][($i_objDac->fld['class'] - 1)] . "\" width=\"100\" height=\"20\">　" . //		"<a href=\"" . "detail.php?user_id=". $i_objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL01. "&dept_code=" . $i_PrmDeptCode ."\">" . 
"<a href=\"#\" onClick=\"return cxSubmit('" . ArgConvert($i_objDac->fld['name']) . "','" . $i_objDac->fld['email'] . "')\" style=\"color:#0000FF\" title=\"" . $i_objDac->fld['email'] . "\">" . htmlspecialchars($i_objDac->fld['name']) . "</a>" . "（" . htmlspecialchars($i_objDac->fld['dept_name']) . "）" . "</p>\n";
	}
	
	/*---対象となる部の課を取得する---*/
	$sql = "SELECT tbl_department.dept_code, tbl_department.name, tbl_department.dept_name " . "FROM tbl_department " . "WHERE (((tbl_department.level)=" . G_DEPT_LEVEL02 . ") AND ((tbl_department.dept_code) Like '" . $dept_01 . "%')) " . "ORDER BY tbl_department.level, tbl_department.dept_code, tbl_department.sort_order, tbl_department.dept_id";
	//取得
	$i_objDac->execute($sql);
	//データ作成
	$down_list = "";
	while ($i_objDac->fetch()) {
		$exp_img = $i_ExpImg;
		$param = "level=" . G_DEPT_LEVEL02 . "&dept_code=" . $i_objDac->fld['dept_code'];
		$down_list .= "<p align=\"left\" class=\"dir_second\">" . "<img src=\"" . $exp_img . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
	}
	
	/*---リスト全体を作成---*/
	$sql = "SELECT tbl_department.dept_code, tbl_department.name, tbl_department.dept_name " . "FROM tbl_department " . "WHERE (((tbl_department.level)=" . G_DEPT_LEVEL01 . "))" . "ORDER BY tbl_department.level, tbl_department.dept_code, tbl_department.sort_order, tbl_department.dept_id";
	//取得
	$i_objDac->execute($sql);
	//データ作成
	while ($i_objDac->fetch()) {
		if (strcmp($i_PrmDeptCode, $i_objDac->fld['dept_code']) == 0) {
			//展開された部
			$param = "level=" . G_DEPT_LEVEL01;
			$o_DspLstUser .= "<p align=\"left\" class=\"dir_first\">" . "<img src=\"" . G_LIST_IMG_M . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
			//部に所属するユーザーを結合
			$o_DspLstUser .= $down_user_list;
			//部に所属する課を結合
			$o_DspLstUser .= $down_list;
		
		}
		else {
			//展開された部以外のデータ
			$param = "level=" . G_DEPT_LEVEL01 . "&dept_code=" . $i_objDac->fld['dept_code'];
			$o_DspLstUser .= "<p align=\"left\" class=\"dir_first\">" . "<img src=\"" . $i_ExpImg . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
		}
	}

}

/*-----------------------------------------------------------------------------
	レベル２　「課」の展開

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_PrmDeptCode	引数で指定された組織コード
		$i_AreClassImg	画像のイメージパスが格納されているテーブル
		$i_ExpImg		展開部分のプラマイ記号
		$o_DspLstUser	表示する一覧データ
		
【戻値】	True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspList_Level02($i_objDac, $i_PrmDeptCode, $i_AreClassImg, $i_ExpImg, &$o_DspLstUser) {
	
	/*---部コードの切り出し---*/
	$dept_01 = substr($i_PrmDeptCode, 0, CODE_DIGIT_DEPT); //組織コード１の切り出し
	$dept_01_like = $dept_01;
	$dept_01 = str_pad($dept_01, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
	/*---係コードの切り出し---*/
	$dept_02 = substr($i_PrmDeptCode, 0, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT)); //組織コード２の切り出し
	

	/*---対象となる部と課に所属しているユーザーを取得---*/
	$sql = "SELECT tbl_department.level, tbl_user.dept_code, tbl_user.class, tbl_user.user_id, tbl_user.name, tbl_user.email, tbl_department.dept_name " . "FROM tbl_user INNER JOIN tbl_department ON tbl_user.dept_code = tbl_department.dept_code " . "WHERE (((tbl_department.level)=" . G_DEPT_LEVEL01 . " ) AND ((tbl_user.dept_code)='" . $dept_01 . "')) OR " . "(((tbl_department.level)=" . G_DEPT_LEVEL02 . ") AND ((tbl_user.dept_code) Like '" . $dept_02 . "%')) " . "ORDER BY tbl_department.level, tbl_user.dept_code, tbl_user.class, tbl_user.user_id";
	
	//取得
	$i_objDac->execute($sql);
	$dn_user_dept01 = "";
	$dn_user_dept02 = "";
	while ($i_objDac->fetch()) {
		if ($i_objDac->fld['level'] == G_DEPT_LEVEL01) {
			$dn_user_dept01 .= "<p align=\"left\" class=\"dir_second\">" . "<img src=\"" . $i_AreClassImg[0][($i_objDac->fld['class'] - 1)] . "\" alt=\"" . $i_AreClassImg[1][($i_objDac->fld['class'] - 1)] . "\" width=\"100\" height=\"20\">　" . //"<a href=\"" . "detail.php?user_id=". $i_objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL02. "&dept_code=" . $i_PrmDeptCode ."\">" . 
"<a href=\"#\" onClick=\"return cxSubmit('" . ArgConvert($i_objDac->fld['name']) . "','" . $i_objDac->fld['email'] . "')\" style=\"color:#0000FF\" title=\"" . $i_objDac->fld['email'] . "\">" . htmlspecialchars($i_objDac->fld['name']) . "</a>" . "（" . htmlspecialchars($i_objDac->fld['dept_name']) . "）" . "</p>\n";
		}
		else {
			$dn_user_dept02 .= "<p align=\"left\" class=\"dir_third\">" . "<img src=\"" . $i_AreClassImg[0][($i_objDac->fld['class'] - 1)] . "\" alt=\"" . $i_AreClassImg[1][($i_objDac->fld['class'] - 1)] . "\" width=\"100\" height=\"20\">　" . //					"<a href=\"" . "detail.php?user_id=". $i_objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL02 . "&dept_code=" . $i_PrmDeptCode ."\">" . 
"<a href=\"#\" onClick=\"return cxSubmit('" . ArgConvert($i_objDac->fld['name']) . "','" . $i_objDac->fld['email'] . "')\" style=\"color:#0000FF\" title=\"" . $i_objDac->fld['email'] . "\">" . htmlspecialchars($i_objDac->fld['name']) . "</a>" . "（" . htmlspecialchars($i_objDac->fld['dept_name']) . "）" . "</p>\n";
		}
	
	}
	
	/*---対象となる部の課の係を取得する---*/
	$sql = "SELECT tbl_department.dept_code, tbl_department.name, tbl_department.dept_name " . "FROM tbl_department " . "WHERE (((tbl_department.level)=" . G_DEPT_LEVEL03 . ") AND ((tbl_department.dept_code) Like '" . $dept_02 . "%')) " . "ORDER BY tbl_department.level, tbl_department.dept_code, tbl_department.sort_order, tbl_department.dept_id";
	//取得
	$i_objDac->execute($sql);
	//データ作成
	$down_list = "";
	while ($i_objDac->fetch()) {
		$exp_img = $i_ExpImg;
		$param = "level=" . G_DEPT_LEVEL03 . "&dept_code=" . $i_objDac->fld['dept_code'];
		$down_list = $down_list . "<p align=\"left\" class=\"dir_third\">" . "<img src=\"" . $exp_img . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
	}
	
	/*---一覧の作成---*/
	$sql = "SELECT tbl_department.dept_code, tbl_department.name, tbl_department.dept_name, tbl_department.level " . "FROM tbl_department " . "WHERE (((tbl_department.level)=" . G_DEPT_LEVEL01 . ")) OR " . "(((tbl_department.level)=" . G_DEPT_LEVEL02 . ") AND ((tbl_department.dept_code) Like '" . $dept_01_like . "%'))" . "ORDER BY tbl_department.dept_code, tbl_department.level, tbl_department.sort_order, tbl_department.dept_id;";
	//取得
	$i_objDac->execute($sql);
	//データ作成
	while ($i_objDac->fetch()) {
		//部データ
		if (G_DEPT_LEVEL01 == $i_objDac->fld['level']) {
			//選択された部データ展開部
			if (strcmp($dept_01, $i_objDac->fld['dept_code']) == 0) {
				$param = "level=" . G_DEPT_LEVEL01;
				$o_DspLstUser = $o_DspLstUser . "<p align=\"left\" class=\"dir_first\">" . "<img src=\"" . G_LIST_IMG_M . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
				//部に所属するユーザーデータの結合
				$o_DspLstUser .= $dn_user_dept01;
			}
			else {
				$param = "level=" . G_DEPT_LEVEL01 . "&dept_code=" . $i_objDac->fld['dept_code'];
				$o_DspLstUser .= "<p align=\"left\" class=\"dir_first\">" . "<img src=\"" . $i_ExpImg . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
			}
		}
		//課データ
		if (G_DEPT_LEVEL02 == $i_objDac->fld['level']) {
			//展開された係展開部
			if (strcmp($i_PrmDeptCode, $i_objDac->fld['dept_code']) == 0) {
				$param = "level=" . G_DEPT_LEVEL01 . "&dept_code=" . $dept_01;
				$o_DspLstUser .= "<p align=\"left\" class=\"dir_second\">" . "<img src=\"" . G_LIST_IMG_M . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
				//課に所属するユーザーデータの結合
				$o_DspLstUser .= $dn_user_dept02;
				//課に所属する係データの結合
				$o_DspLstUser .= $down_list;
			
			}
			else {
				$param = "level=" . G_DEPT_LEVEL02 . "&dept_code=" . $i_objDac->fld['dept_code'];
				$o_DspLstUser .= "<p align=\"left\" class=\"dir_second\">" . "<img src=\"" . G_LIST_IMG_P . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
			}
		}
	}

}

/*-----------------------------------------------------------------------------
	レベル３　「係」の展開

【引数】	$i_objDac		取得されたデーターオブジェクト
		$i_PrmDeptCode	引数で指定された組織コード
		$i_AreClassImg	画像のイメージパスが格納されているテーブル
		$i_ExpImg		展開部分のプラマイ記号
		$o_DspLstUser	表示する一覧データ
		
【戻値】	True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspList_Level03($i_objDac, $i_PrmDeptCode, $i_AreClassImg, $i_ExpImg, &$o_DspLstUser) {
	
	/*---部コードの切り出し---*/
	$dept_01 = substr($i_PrmDeptCode, 0, CODE_DIGIT_DEPT); //組織コード１の切り出し
	$dept_01_like = $dept_01;
	$dept_01 = str_pad($dept_01, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
	
	/*---係コードの切り出し---*/
	$dept_02 = substr($i_PrmDeptCode, 0, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT)); //組織コード２の切り出し
	$dept_02_like = $dept_02;
	$dept_02 = str_pad($dept_02, (CODE_DIGIT_DEPT + CODE_DIGIT_DEPT + CODE_DIGIT_DEPT), "0", STR_PAD_RIGHT);
	
	/*---対象となる部と課と係所属しているユーザーを取得---*/
	$sql = "SELECT tbl_department.level, tbl_user.dept_code, tbl_user.class, tbl_user.user_id, tbl_user.name, tbl_user.email, tbl_department.dept_name " . "FROM tbl_user INNER JOIN tbl_department ON tbl_user.dept_code = tbl_department.dept_code " . "WHERE " . "(((tbl_user.dept_code) Like '" . $dept_01_like . "%') AND ((tbl_department.level)=" . G_DEPT_LEVEL01 . ")) OR " . "(((tbl_user.dept_code) Like '" . $dept_02_like . "%') AND ((tbl_department.level)=" . G_DEPT_LEVEL02 . ")) OR " . "(((tbl_user.dept_code) = '" . $i_PrmDeptCode . "') AND ((tbl_department.level)=" . G_DEPT_LEVEL03 . ")) " . "ORDER BY tbl_department.level, tbl_user.dept_code, tbl_user.class, tbl_user.user_id";
	
	//取得
	$i_objDac->execute($sql);
	$dn_user_dept01 = "";
	$dn_user_dept02 = "";
	$dn_user_dept03 = "";
	while ($i_objDac->fetch()) {
		switch ($i_objDac->fld['level']) {
			case G_DEPT_LEVEL01 : //部
				$dn_user_dept01 .= "<p align=\"left\" class=\"dir_second\">" . "<img src=\"" . $i_AreClassImg[0][($i_objDac->fld['class'] - 1)] . "\" alt=\"" . $i_AreClassImg[1][($i_objDac->fld['class'] - 1)] . "\" width=\"100\" height=\"20\">　" . //"<a href=\"" . "detail.php?user_id=". $i_objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL03. "&dept_code=" . $i_PrmDeptCode ."\">" . 
"<a href=\"#\" onClick=\"return cxSubmit('" . ArgConvert($i_objDac->fld['name']) . "','" . $i_objDac->fld['email'] . "')\" style=\"color:#0000FF\" title=\"" . $i_objDac->fld['email'] . "\">" . htmlspecialchars($i_objDac->fld['name']) . "</a>" . "（" . htmlspecialchars($i_objDac->fld['dept_name']) . "）" . "</p>\n";
				break;
			case G_DEPT_LEVEL02 : //課
				$dn_user_dept02 .= "<p align=\"left\" class=\"dir_third\">" . "<img src=\"" . $i_AreClassImg[0][($i_objDac->fld['class'] - 1)] . "\" alt=\"" . $i_AreClassImg[1][($i_objDac->fld['class'] - 1)] . "\" width=\"100\" height=\"20\">　" . //					"<a href=\"" . "detail.php?user_id=". $i_objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL03 . "&dept_code=" . $i_PrmDeptCode ."\">" . 
"<a href=\"#\" onClick=\"return cxSubmit('" . ArgConvert($i_objDac->fld['name']) . "','" . $i_objDac->fld['email'] . "')\" style=\"color:#0000FF\" title=\"" . $i_objDac->fld['email'] . "\">" . htmlspecialchars($i_objDac->fld['name']) . "</a>" . "（" . htmlspecialchars($i_objDac->fld['dept_name']) . "）" . "</p>\n";
				break;
			case G_DEPT_LEVEL03 : //係
				$dn_user_dept03 .= "<p align=\"left\" class=\"dir_fourth\">" . "<img src=\"" . $i_AreClassImg[0][($i_objDac->fld['class'] - 1)] . "\" alt=\"" . $i_AreClassImg[1][($i_objDac->fld['class'] - 1)] . "\" width=\"100\" height=\"20\">　" . //					"<a href=\"" . "detail.php?user_id=". $i_objDac->fld['user_id'] . "&level=" . G_DEPT_LEVEL03. "&dept_code=" . $i_PrmDeptCode ."\">" . 
"<a href=\"#\" onClick=\"return cxSubmit('" . ArgConvert($i_objDac->fld['name']) . "','" . $i_objDac->fld['email'] . "')\" style=\"color:#0000FF\" title=\"" . $i_objDac->fld['email'] . "\">" . htmlspecialchars($i_objDac->fld['name']) . "</a>" . "（" . htmlspecialchars($i_objDac->fld['dept_name']) . "）" . "</p>\n";
				break;
		}
	
	}
	
	/*---一覧の作成---*/
	$sql = "SELECT tbl_department.dept_code, tbl_department.level, tbl_department.sort_order, tbl_department.name, tbl_department.dept_name " . "FROM tbl_department " . "WHERE (((tbl_department.level)=" . G_DEPT_LEVEL01 . ")) OR " . "(((tbl_department.dept_code) Like '" . $dept_01_like . "%') AND ((tbl_department.level)=" . G_DEPT_LEVEL02 . ")) OR " . "(((tbl_department.dept_code) Like '" . $dept_02_like . "%') AND ((tbl_department.level)=" . G_DEPT_LEVEL03 . ")) " . "ORDER BY tbl_department.dept_code, tbl_department.level, tbl_department.sort_order, tbl_department.level, tbl_department.sort_order, tbl_department.dept_id";
	//取得
	$i_objDac->execute($sql);
	//データ作成
	while ($i_objDac->fetch()) {
		switch ($i_objDac->fld['level']) {
			case G_DEPT_LEVEL01 : //部
				if (strcmp($dept_01, $i_objDac->fld['dept_code']) == 0) {
					$param = "level=" . G_DEPT_LEVEL01;
					//選択された部データ展開部
					$o_DspLstUser .= "<p align=\"left\" class=\"dir_first\">" . "<img src=\"" . G_LIST_IMG_M . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
					//部に所属するユーザーデータの結合
					$o_DspLstUser .= $dn_user_dept01;
				}
				else {
					$param = "level=" . G_DEPT_LEVEL01 . "&dept_code=" . $i_objDac->fld['dept_code'];
					$o_DspLstUser .= "<p align=\"left\" class=\"dir_first\">" . "<img src=\"" . $i_ExpImg . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
				}
				break;
			case G_DEPT_LEVEL02 : //課
				if (strcmp($dept_02, $i_objDac->fld['dept_code']) == 0) {
					$param = "level=" . G_DEPT_LEVEL01 . "&dept_code=" . $dept_01;
					//選択された課データの展開部
					$o_DspLstUser .= "<p align=\"left\" class=\"dir_second\">" . "<img src=\"" . G_LIST_IMG_M . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
					//課に所属するユーザーデータの結合
					$o_DspLstUser .= $dn_user_dept02;
				
				}
				else {
					$param = "level=" . G_DEPT_LEVEL02 . "&dept_code=" . $i_objDac->fld['dept_code'];
					$o_DspLstUser .= "<p align=\"left\" class=\"dir_second\">" . "<img src=\"" . G_LIST_IMG_P . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
				}
				break;
			case G_DEPT_LEVEL03 : //係
				if (strcmp($i_PrmDeptCode, $i_objDac->fld['dept_code']) == 0) {
					$param = "level=" . G_DEPT_LEVEL02 . "&dept_code=" . $dept_02;
					//選択された係データの展開部
					$o_DspLstUser .= "<p align=\"left\" class=\"dir_third\">" . "<img src=\"" . G_LIST_IMG_M . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
					//係に所属するユーザーデータの結合
					$o_DspLstUser .= $dn_user_dept03;
				}
				else {
					$param = "level=" . G_DEPT_LEVEL03 . "&dept_code=" . $i_objDac->fld['dept_code'];
					$o_DspLstUser .= "<p align=\"left\" class=\"dir_third\">" . "<img src=\"" . $i_ExpImg . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\" onClick=\"return cxDeptReload('" . $param . "')\" style=\"cursor:pointer\">" . htmlspecialchars($i_objDac->fld['dept_name']) . "</p>\n";
				}
		}
	}

}

/**
 * javascript引数用文字列置換(シングルクォートで囲まれた引数用)
 * @param $arg javascriptの引数として追加文字列に置換する
 */
function ArgConvert($arg){

	$ret_str = '';
	$ret_str = str_replace('&#039;', '\\\'', str_replace('\\', '\\\\', htmlspecialchars($arg, ENT_QUOTES)));
	return $ret_str;
}

?>

