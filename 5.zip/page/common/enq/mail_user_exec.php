<?php
/*
 *
 */
/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");

/*---引数の取得---*/
if (!isset($_POST['name'])) {
	user_error("必要なパラメータがありません");
}
$name = $_POST['name'];

$retHtml = '';
/*--- データアクセスクラス ---*/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
$where = $objDac->_addslashesC("name", $name . "%", "LIKE", "TEXT");
$objDac->setTableName("tbl_user");
$objDac->select($where);
if ($objDac->getRowCount() > 0) {
	while ($objDac->fetch()) {
		$retHtml .= "<tr>" . "<td><a href=\"#\" onClick=\"return cxSubmit('" . $objDac->fld['name'] . "','" . $objDac->fld['email'] . "')\" style=\"color:#0000FF\" title=\"" . $objDac->fld['email'] . "\">" . htmlspecialchars($objDac->fld['name']) . "</a></td>" . "</tr>";
	}
}
else {
	$retHtml .= "<tr><td>対象データはありませんでした。</td></tr>";
}
$retHtml = '<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable">' . $retHtml;
$retHtml .= "</table>";

header("Content-Type: text/html; charset=UTF-8");
print $retHtml;
exit();

?>

