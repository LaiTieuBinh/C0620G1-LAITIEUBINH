/*
 *
 */
var cms8341_EnqClass;
var EnqueteSet = Class.create();
EnqueteSet.prototype = {
	//Constructor
	initialize:function() {
		this.Id = 0;										//各項目オブジェクトの識別用ID
		var items  = $('cms8341_EnqueteItems').getElementsByTagName('div');
		for(var i=0;i<items.length;i++) {
			if( Number(this.Id) < Number(items[i].getAttribute('_param')) ) this.Id = items[i].getAttribute('_param');
		}
		this.NesLabel = '（必須）';	//必須項目時のラベル
		this.Reply_MailLabel = '（入力されたメールアドレスに自動返信メールをお送りします。）';	//返信メール送信時のラベル
		//描画HTMLフォーマット
		//アンケートフォームの場合は縦型
		if($('cms_from_type').value == 0 || $('cms_from_type').value == 2){
			this.fmtHtml  = '<table width="100%" border="1" cellspacing="0" cellpadding="5" class="enquete_table" style="margin-bottom:10px">';
			this.fmtHtml += '<tr>';
			this.fmtHtml += '<td align="left" valign="middle">';
			this.fmtHtml += '<table width="100%" border="0" cellspacing="0" cellpadding="3" class="cms8341_EnqCtrlTable">';
			this.fmtHtml += '<tr>';
			this.fmtHtml += '<th width="30%" align="left" valign="top" id="cms8341_Label_{Id}"><span id="cms8341_ItemLabel_{Id}" _nes="{ItemNes}">{ItemName}</span><span class="nes">{NesLabel}</span><br><span id="cms8341_ItemMemo_{Id}"><span class="memo">{MemoLabel}</span></span></th>';
			this.fmtHtml += '</tr>';
			this.fmtHtml += '{ItemImg}';
			this.fmtHtml += '<tr>';
			this.fmtHtml += '<td align="left" valign="top" id="cms8341_Ctrl_{Id}">{ItemCtrl}</td>';
			this.fmtHtml += '</tr>';
			this.fmtHtml += '</table>';
			this.fmtHtml += '</td>';
			this.fmtHtml += '<td width="150" align="center" valign="middle">';
			this.fmtHtml += '<img _param="{Id}" alt="修正する" onclick="EnqItemEdit(this)" src="'+RPW+'/admin/images/set_enquete/item_fix.gif" width="60" height="20" style="cursor:pointer">';
			this.fmtHtml += '&nbsp;';
			this.fmtHtml += '<img _param="{Id}" alt="削除する" onclick="EnqItemDel(this)" src="'+RPW+'/admin/images/set_enquete/item_del.gif" width="60" height="20" style="cursor:pointer">';
			this.fmtHtml += '</td>';
			this.fmtHtml += '</tr>';
			this.fmtHtml += '</table>';
		}else{
			this.fmtHtml  = '<table width="100%" border="1" cellspacing="0" cellpadding="5" class="enquete_table" style="margin-bottom:10px">';
			this.fmtHtml += '<tr>';
			this.fmtHtml += '<td align="left" valign="middle">';
			this.fmtHtml += '<table width="100%" border="0" cellspacing="0" cellpadding="3" class="cms8341_EnqCtrlTable">';
			this.fmtHtml += '<tr>';
			this.fmtHtml += '<th width="30%" align="left" valign="top" id="cms8341_Label_{Id}"><span id="cms8341_ItemLabel_{Id}" _nes="{ItemNes}" _desc_mail="{ItemDescMail}" _reply_mail="{ItemReplyMail}">{ItemName}</span><span class="nes">{NesLabel}</span><br><span id="cms8341_ItemMemo_{Id}"><span class="memo">{MemoLabel}</span></span></th>';
			this.fmtHtml += '<td align="left" valign="top" id="cms8341_Ctrl_{Id}">{ItemCtrl}<br><span class="nes">{Reply_MailLabel}</span></td>';
			this.fmtHtml += '</tr>';
			this.fmtHtml += '</table>';
			this.fmtHtml += '</td>';
			this.fmtHtml += '<td width="150" align="center" valign="middle">';
			this.fmtHtml += '<img _param="{Id}" alt="修正する" onclick="EnqItemEdit(this)" src="'+RPW+'/admin/images/set_enquete/item_fix.gif" width="60" height="20" style="cursor:pointer">';
			this.fmtHtml += '&nbsp;';
			this.fmtHtml += '<img _param="{Id}" alt="削除する" onclick="EnqItemDel(this)" src="'+RPW+'/admin/images/set_enquete/item_del.gif" width="60" height="20" style="cursor:pointer">';
			this.fmtHtml += '</td>';
			this.fmtHtml += '</tr>';
			this.fmtHtml += '</table>';
		}
		//
		//this.fmtHtml = '{ItemName}';
		//イベントリスナー登録
		Event.observe($('cms8341_EmqAddItem'), 'click', this.controllAdd.bind(this));
	},
	//改行処理（改行コード→BR）
	encodeBR:function(txt) {
		return txt.replace(/\x0D\x0A|\x0D|\x0A/g,'<br>');
	},
	//改行コードの代替エスケープ
	escapeBR:function(txt) {
		return txt.replace(/\x0D\x0A|\x0D|\x0A/g,'[br]');
	},
	//代替エスケープのデコード
	descapeBR:function(txt) {
		return txt.replace(/\[br\]/g,'\n');
	},
	//HTMLエスケープ処理
	htmlEscape:function(str,flg) {
		var ret = str;
		//\マークをエスケープ
		ret = ret.replace(/\\/g,'\\\\');
		//シングルクォーテーションをエスケープ
		ret = ret.replace(/\'/g,'&#39;');
		while(ret.match("&#39;")){
			ret = ret.replace("&#39;","\\'");
		}
		//他のエスケープ処理
		if(flg == true){
			ret = ret.replace(/\&/g,'&amp;');
			ret = ret.replace(/</g,'&lt;');
			ret = ret.replace(/>/g,'&gt;');
			ret = ret.replace(/\"/g,'&quot;');
		}
		return ret;
	},
	//画面描画処理
	createItemBlock:function(obj) {
		//Get
		var id   = obj["id"];
		var name = obj["name"];
		var nes  = obj["nes"];
		var desc_mail  = obj["desc_mail"];
		var memo = obj["memo"];
		var img = obj["img"];
		var img_alt = obj["img_alt"];
		var ctrl = obj["ctrl"];
		var item = obj["item"];
		var form = "";
		//表示画面セット
		var v_nes  = (nes==1)? this.NesLabel : "";
		var v_reply_mail  = "";
		var v_memo = this.encodeBR(memo);
		switch(ctrl) {
			case "input_mail":
				form  = '<input name="'+id+'" type="text" size="'+item[0][0]+'" _p_size="'+item[0][0]+'" maxlength="'+item[0][1]+'" _p_maxlength="'+item[0][1]+'" value="'+item[0][2]+'" mail_flg="1" reply_mail_flg="'+item[0][3]+'" onblur="cms8341_EnqClass.itemReset(this,\''+this.htmlEscape(item[0][2],false)+'\');">';
				v_reply_mail  = (item[0][3]==1)? this.Reply_MailLabel : "";
				break;
			case "input":
				form  = '<input name="'+id+'" type="text" size="'+item[0][0]+'" _p_size="'+item[0][0]+'" maxlength="'+item[0][1]+'" _p_maxlength="'+item[0][1]+'" value="'+item[0][2]+'" mail_flg="0" reply_mail_flg="0" onblur="cms8341_EnqClass.itemReset(this,\''+this.htmlEscape(item[0][2],false)+'\');">';
				break;
			case "textarea":
				form = '<textarea name="'+id+'" cols="'+item[0][0]+'" _p_cols="'+item[0][0]+'" rows="'+item[0][1]+'" _p_rows="'+item[0][1]+'" onblur="cms8341_EnqClass.itemReset(this,\''+this.htmlEscape(this.escapeBR(item[0][2]),false)+'\');">'+item[0][2]+'</textarea>';
				break;
			case "radio":
				for(var i=0;i<item.length;i++) {
					if(item[i][3]==1){
						br = 1;
						br_str = '<br>';
					}else{
						br = 0;
						br_str = '&nbsp;';
					}

					if(item[i][2]==1) {
						form += '<input type="radio" name="'+id+'_'+i+'" value="'+item[i][1]+'" checked="checked" _br="'+br+'" onblur="cms8341_EnqClass.itemReset(this,'+item[i][2]+');">';
					} else {
						form += '<input type="radio" name="'+id+'_'+i+'" value="'+item[i][1]+'" _br="'+br+'" onblur="cms8341_EnqClass.itemReset(this,'+item[i][2]+');">';
					}
					form += item[i][1] + br_str;
				}
				break;
			case "checkbox":
				for(var i=0;i<item.length;i++) {
					if(item[i][3]==1){
						br = 1;
						br_str = '<br>';
					}else{
						br = 0;
						br_str = '&nbsp;';
					}

					if(item[i][2]==1) {
						form += '<input type="checkbox" name="'+id+'_'+i+'" value="'+item[i][1]+'" checked="checked" _br="'+br+'" onblur="cms8341_EnqClass.itemReset(this,'+item[i][2]+');">';
					} else {
						form += '<input type="checkbox" name="'+id+'_'+i+'" value="'+item[i][1]+'" _br="'+br+'" onblur="cms8341_EnqClass.itemReset(this,'+item[i][2]+');">';
					}
					form += item[i][1] + br_str;
				}
				break;
			case "select":
				form = '';
				var sID = 0;
				for(var i=0;i<item.length;i++) {
					if(item[i][2]==1) {
						sID = i;
						form += '<option selected="selected" value="'+item[i][1]+'">';
					} else {
						form += '<option value="'+item[i][1]+'">';
					}
					form += item[i][1] + '</option>';
				}
				form += '</select>';
				form = '<select name="'+id+'" onblur="cms8341_EnqClass.itemReset(this,'+sID+');">' + form;
				break;
			default:
				break;
		}
		
		Img = '';
		if(obj["img"] != ''){
			var date = new Date();
			var y = date.getFullYear();
			var m = "0" + (date.getMonth() + 1);
			var d = "0" + date.getDate();
			var h = "0" + date.getHours();
			var mi = "0" + date.getMinutes();
			var s = "0" + date.getSeconds();
			var strDate = y+m+d+h+mi+s;
			Img += '<tr>';
			Img += '<td align="left" valign="top" id="cms8341_Img_'+id+'"><img alt="'+obj["img_alt"]+'" src="'+obj["img"]+'?'+strDate+'" /></td>';
//			Img += '<td align="left" valign="top" id="cms8341_Img_'+id+'"><img alt="'+obj["img_alt"]+'" src="'+obj["img"]+'" /></td>';
			Img += '</tr>';
		}
		
		var retHtml = this.fmtHtml;
		retHtml = retHtml.replace(/{Id}/g,id);
		retHtml = retHtml.replace(/{ItemName}/g,name);
		retHtml = retHtml.replace(/{ItemNes}/g,nes);
		retHtml = retHtml.replace(/{ItemDescMail}/g,desc_mail);
		retHtml = retHtml.replace(/{NesLabel}/g,v_nes);
		retHtml = retHtml.replace(/{ItemMemo}/g,memo);
		retHtml = retHtml.replace(/{MemoLabel}/g,v_memo);
		retHtml = retHtml.replace(/{ItemImg}/g,Img);
		retHtml = retHtml.replace(/{ItemCtrl}/g,form);
		retHtml = retHtml.replace(/{Reply_MailLabel}/g,v_reply_mail);
		//
		return retHtml;
	},
	//モーダル画面の表示
	showModal:function(arg, callback) {
		arg['windowObject'] = window;
		cxIframeLayer(
			cms8341admin_path+"/page/common/enq/controll.php?id="+arg["id"]+"&page_id="+$('cms_page_id').value+"&dir_path="+$('cms_dir_path').value+"&from_type="+$('cms_from_type').value+"&img="+arg["img"]+"&img_width="+arg['img_width']+"&img_height="+arg['img_height'],
			520,
			800,
			COVER_SETTING.COLOR,
			'',
			callback,
			false,
			false,
			arg
		);
	},
	//コントロール追加
	controllAdd:function(e) {
		var arg = new Object();
		this.Id++;
		arg["id"] = this.Id;
		arg["img"] = '';
		var enqueteSet = this;
		this.showModal(arg, function(retObj) {
			if(retObj!==false && retObj != undefined) {
				var html = enqueteSet.createItemBlock(retObj);
				var div = document.createElement('div');
				div.id = "cms8341_EnqCtrl_"+enqueteSet.Id;
				div.setAttribute('_param', enqueteSet.Id);
				div.innerHTML = html;
				$('cms8341_EnqueteItems').appendChild(div);
				Sortable.create('cms8341_EnqueteItems',{tag:'div'});
			} else {
				enqueteSet.Id--;
			}
		});
	},
	//
	itemReset:function(obj,def) {
		var tag = obj.tagName.toLowerCase();
		if(tag=='input') {
			tag = obj.type.toLowerCase();
		}
		switch(tag) {
			case 'text':
				obj.value = def;
				break;
			case 'textarea':
				obj.value = this.descapeBR(def);
				break;
			case 'radio':
			case 'checkbox':
				obj.checked = def;
				break;
			case 'select':
				obj.selectedIndex = def;
				break;
		}
	}
}
//
function EnqItemEdit(obj) {
	var id = obj.getAttribute('_param');
	var ItemLabel = $('cms8341_ItemLabel_'+id);
	var name = ItemLabel.innerText;
	var nes  = ItemLabel.getAttribute('_nes');
	var desc_mail  = ItemLabel.getAttribute('_desc_mail');
	var memo = $('cms8341_ItemMemo_'+id).innerText;
	if(!$('cms8341_Img_'+id)){
		var img = '';
		var img_alt = '';
	}else{
		var ImgTag = $('cms8341_Img_'+id).children[0];
		var img = ImgTag.src;
		var img_alt = ImgTag.alt;
		var img_width = ImgTag.offsetWidth;
		var img_height = ImgTag.offsetHeight;
	}
	var cObj = $('cms8341_Ctrl_'+id).children[0];
	var item = new Array();
	var ctrl = cObj.tagName.toLowerCase();
	var mail = "";
	if(ctrl=='input'){
		ctrl = cObj.type.toLowerCase();
	}
	switch(ctrl) {
		case "text":
			mail = cObj.getAttribute('mail_flg').toLowerCase();
			var info = new Array();
			if(mail == "0"){
				ctrl = 'input';
			}else{
				ctrl = 'input_mail';
			}
			info[0] = cObj.getAttribute('_p_size');
			info[1] = cObj.getAttribute('_p_maxlength');
			info[2] = cObj.value;
			if (ctrl == 'input_mail') {
				info[3] = cObj.getAttribute('reply_mail_flg');
			}
			item.push(info);
			break;
		case "textarea":
			var info = new Array();
			info[0] = cObj.getAttribute('_p_cols');
			info[1] = cObj.getAttribute('_p_rows');
			info[2] = cObj.value;
			item.push(info);
			break;
		case "radio":
		case "checkbox":
			var info = new Array();
			var opt =  $('cms8341_Ctrl_'+id).getElementsByTagName('input');
			for(var i=0;i<opt.length;i++) {
				item[i] = new Array();
				item[i][0] = i;
				item[i][1] = opt[i].value;
				item[i][2] = (opt[i].checked)? 1 : 0;
				item[i][3] = opt[i].getAttribute('_br');
			}
			break;
		case "select":
			var info = new Array();
			var opt = cObj.getElementsByTagName('option');
			for(var i=0;i<opt.length;i++) {
				item[i] = new Array();
				item[i][0] = i;
				item[i][1] = opt[i].value;
				item[i][2] = (opt[i].selected)? 1 : 0;
			}
			break;
	}
	var datObj = new Object();
	datObj["id"] = id;
	datObj["name"] = name;
	datObj["nes"] = nes;
	datObj["desc_mail"] = (desc_mail == 1 ? 1 : 0);
	datObj["memo"] = memo;
	datObj["img"] = img;
	datObj["img_alt"] = img_alt;
	datObj["img_width"] = img_width;
	datObj["img_height"] = img_height;
	datObj["ctrl"] = ctrl;
	datObj["item"] = item;
	cms8341_EnqClass.showModal(datObj, function(retObj) {
		if(retObj!==false && retObj != undefined) {
			var retHtml = cms8341_EnqClass.createItemBlock(retObj);
			$("cms8341_EnqCtrl_"+id).innerHTML = retHtml;
		}
	});
}
//
function EnqItemDel(obj) {
	var id = obj.getAttribute('_param');
	var r = confirm('アンケート項目を削除しますがよろしいですか？');
	if(r) Element.remove($('cms8341_EnqCtrl_'+id));
}
//
function EnqHiddenApply(nam,val) {
	var fObj   = $('cms_fEdit');
	var aObj   = document.createElement('input');
	aObj.type  = 'hidden';
	aObj.name  = nam;
	aObj.value = val;
	fObj.appendChild(aObj);
}
function EnqItemClear() {
	var ih = document.getElementsByTagName('input');
	var de = new Array();
	for(var i=0;i<ih.length;i++) {
		if(ih[i].type!='hidden') continue;
		if(!ih[i].name) continue;
		var r = ih[i].name.match(/item_title\[\d+\]|item_nes\[\d+\]|item_desc_mail\[\d+\]|item_memo\[\d+\]|item_ctrl\[\d+\]|ctrl\[\d+\]\[\d+\]\[[0-9]+\]/);
		if(r) {
			de.push(ih[i]);
		}
	}
	while(de.length>0) {
		Element.remove(de.pop());
	}
}
function EnqItemCreateForm() {
	EnqItemClear();
	var EnqDiv = $('cms8341_EnqueteItems');
	var items  = EnqDiv.getElementsByTagName('div');
	var i_cnt = items.length;
	for(var i=0;i<i_cnt;i++) {
		var id = items[i].getAttribute('_param');
		var name = $('cms8341_ItemLabel_'+id).innerText;
		EnqHiddenApply('item_title['+i+']',name);
		var nes  = $('cms8341_ItemLabel_'+id).getAttribute('_nes');
		EnqHiddenApply('item_nes['+i+']',nes);
		var desc_mail  = $('cms8341_ItemLabel_'+id).getAttribute('_desc_mail');
		EnqHiddenApply('item_desc_mail['+i+']',desc_mail);
		var memo = $('cms8341_ItemMemo_'+id).innerText;
		EnqHiddenApply('item_memo['+i+']',memo);
		if(!$('cms8341_Img_'+id)){
			EnqHiddenApply('img['+i+']',"");
			EnqHiddenApply('img_alt['+i+']',"");
		}else{
			var img_tag = $('cms8341_Img_'+id).children[0];
			var img_ary = img_tag.src.split('?');
			EnqHiddenApply('img['+i+']',img_ary[0]);
			EnqHiddenApply('img_alt['+i+']',img_tag.alt);
		}
		
		var cObj = $('cms8341_Ctrl_'+id).children[0];
		var item = new Array();
		var ctrl = cObj.tagName.toLowerCase();
		if(ctrl=='input') ctrl = cObj.type.toLowerCase();
		switch(ctrl) {
			case "text":
				ctrl = 'input';
				EnqHiddenApply('item_ctrl['+i+']',ctrl);
				EnqHiddenApply('ctrl['+i+'][0][0]',cObj.getAttribute('_p_size'));
				EnqHiddenApply('ctrl['+i+'][0][1]',cObj.getAttribute('_p_maxlength'));
				EnqHiddenApply('ctrl['+i+'][0][2]',cObj.value);
				EnqHiddenApply('ctrl['+i+'][0][3]',cObj.getAttribute('mail_flg'));
				EnqHiddenApply('ctrl['+i+'][0][4]',cObj.getAttribute('reply_mail_flg'));
				break;
			case "textarea":
				EnqHiddenApply('item_ctrl['+i+']',ctrl);
				EnqHiddenApply('ctrl['+i+'][0][0]',cObj.getAttribute('_p_cols'));
				EnqHiddenApply('ctrl['+i+'][0][1]',cObj.getAttribute('_p_rows'));
				EnqHiddenApply('ctrl['+i+'][0][2]',cObj.value);
				break;
			case "radio":
			case "checkbox":
				EnqHiddenApply('item_ctrl['+i+']',ctrl);
				var opt =  $('cms8341_Ctrl_'+id).getElementsByTagName('input');
				for(var j=0;j<opt.length;j++) {
					EnqHiddenApply('ctrl['+i+']['+j+'][0]',j);
					EnqHiddenApply('ctrl['+i+']['+j+'][1]',opt[j].value);
					EnqHiddenApply('ctrl['+i+']['+j+'][2]',(opt[j].checked)? 1 : 0);
					EnqHiddenApply('ctrl['+i+']['+j+'][3]',opt[j].getAttribute('_br'));
				}
				break;
			case "select":
				EnqHiddenApply('item_ctrl['+i+']',ctrl);
				var opt = cObj.getElementsByTagName('option');
				for(var j=0;j<opt.length;j++) {
					EnqHiddenApply('ctrl['+i+']['+j+'][0]',j);
					EnqHiddenApply('ctrl['+i+']['+j+'][1]',opt[j].value);
					EnqHiddenApply('ctrl['+i+']['+j+'][2]',(opt[j].selected)? 1 : 0);
				}
				break;
		}
	}
}
function submitTest() {
	EnqItemCreateForm();
	document.cms_fEdit.action = 'conf.php';
	document.cms_fEdit.target = '';
	document.cms_fEdit.submit();
	return true;
}
