<?php
/*
 *
 */
/*--- 設定ファイル読み込み ---*/
require ("./.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);

//プレビュー画像の横幅を設定
define("IMAGE_PREV_WIDTH", 220);

//アンケートフォームの場合
if ($_GET['from_type'] == ENQ_KIND_CGI) {
	$name_max_input = ENQ_CONTROL_NAME_MAX_INPUT_ENQ;
	$name_comment = ENQ_CONTROL_NAME_COMMENT_ENQ;
}
else {
	$name_max_input = ENQ_CONTROL_NAME_MAX_INPUT_MAIL;
	$name_comment = ENQ_CONTROL_NAME_COMMENT_MAIL;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>アンケート項目設定</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<style type="text/css">
#cms8341-enqsettingarea {
	width: 430px;
	height: 700px;
	overflow: auto;
	margin: 10px 0px;
	background-color: #FFFFFF;
	padding: 9px 19px 0px 19px;
	text-align: left;
	border: solid 1px #999999;
	font-size: 14px;
}

#cms8341-enqsettingarea p {
	margin-top: 0px;
	margin-bottom: 10px;
}

#cms8341-enqsettingarea p.label {
	margin-top: 0px;
	margin-bottom: 10px;
}

#cms8341-enqsettingarea p.ctrl {
	margin-top: 5px;
	margin-bottom: 0px;
}

#cms8341-enqsettingarea table {
	border-collapse: collapse;
	border: solid 1px #666;
	margin-bottom: 15px;
}

#cms8341-enqsettingarea th {
	font-weight: normal;
	border: solid 1px #666;
	background-color: #EFEFEF;
}

#cms8341-enqsettingarea td {
	border: solid 1px #666;
}

#cms8341-enqsettingarea .width270 {
	width: 270px;
}

#cms8341-enqsettingarea .width210 {
	width: 210px;
}

#cms8341-enqsettingarea .width100 {
	width: 100px;
}

#cms8341-enqcntrollarea {
	height: 660px;
	overflow: hidden;
}

.result_container {
	width: 270px;
	height: 80px;
	overflow: scroll;
	border: solid 1px #666;
	position: relative;
}

.resultarea p {
	margin: 1px 0px !important;
	padding: 3px;
	border-bottom: solid 1px #666;
}

.resultarea p input {
	cursor: pointer;
}

.none {
	display: none;
}

input.ime-none {
	ime-mode: disabled
}

/* preload image */
.preload01 {
	background-image: url(<?=RPW?>/admin/images/set_enquete/btn_fixed.jpg)
}

.preload01 {
	background-image:
		url(<?=RPW?>/admin/images/set_enquete/btn_edit_off.jpg)
}

.preload01 {
	background-image: url(<?=RPW?>/admin/images/set_enquete/btn_del_off.jpg)
}

/* Set css for only firefox browser */
@-moz-document url-prefix() {
	#textarea_set3 {
		height: 75px;
	}
	.result_container {
		height: 81px;
	}
	#cms8341-enqsettingarea p {
		margin-top: 13px;
		margin-bottom: 0px;
	}
	#cms8341-enqcntrollarea {
		height: 678px;
	}
	#cms8341-enqsettingarea {
		height: 717px;
	}
	#sample_b {
		height: 66px;
	}
}
</style>
<script type="text/javascript" src="<?=RPW?>/admin/js/common_action.js"></script>
<script type="text/javascript"
	src="<?=RPW?>/admin/js/library/prototype.js"></script>
<script type="text/javascript"
	src="<?=RPW?>/admin/js/library/scriptaculous.js"></script>
<script type="text/javascript" src="<?=RPW?>/admin/js/shared.js"></script>
<script type="text/javascript" src="./enquete_controll.js"></script>
<script type="text/javascript">
	//変数の宣言
	var KANKO_LINK_DELIMITER = '<?=KANKO_LINK_DELIMITER?>';
	var ENQ_RETURN_MAIL_SEND_FLG = '<?=(ENQ_RETURN_MAIL_SEND_FLG == TRUE ? FLAG_ON : FLAG_OFF)?>';
	var image_prev_width = <?=IMAGE_PREV_WIDTH?>
	
	//画像設定
	function imageSelect(id){
		var retObj = new Object();
		value = $F(id + '_hidden').replace("#","＃");
		value = encodeURIComponent(value);
		prm = "value=" + value;
		//ダイアログの表示
		cxIframeLayer(
			cms8341admin_path + "/page/common/enq/image.php?" + prm,
			630,
			660,
			COVER_SETTING.COLOR,
			'',
			function (retObj) {
				//戻り値のチェック
				if(retObj == undefined) return;
				tmpAry = retObj['ret'].split(KANKO_LINK_DELIMITER);
				tmpAry[1] = tmpAry[1].replace("＃","#");
				$(id).src = (baseUrl + htmlEscape(cxEscapeHtmlChars(tmpAry[0]))).replace(/\/+/g,'/') + '?rnd=' + parseInt((Math.random() * 10000) + 1);
				$(id).alt = htmlEscape(cxEscapeHtmlChars(tmpAry[1]))
				$(id).width = (image_prev_width > tmpAry[2] ? tmpAry[2] : image_prev_width);
				$(id).height = (image_prev_width > tmpAry[2] ? tmpAry[3] : Math.round((image_prev_width * tmpAry[3]) / tmpAry[2]));
				$(id + '_hidden').value = tmpAry[0] + KANKO_LINK_DELIMITER + tmpAry[1];	
			}
		);	
	}
	/**
	 * 定型テンプレート用画像の削除を行なう
	 * @param id アイテムID
	 */
	function deleteImage(id){
		$(id).src = cms8341admin_path + '/images/thumbnails/temp1.gif';
		$(id).alt="";
		$(id).width = 0;
		$(id).height = 0;
		$(id + '_hidden').value = "";
	}
</script>
</head>

<body>
<form action="#" name="enq_form" method="post"
	enctype="multipart/form-data">
<table width="505" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="505" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="505" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/set_enquete/title_enqsetting.jpg"
					alt="アンケート項目設定" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="#" onClick="cxIframeLayerCallback()"
					id="header_close"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div id="cms8341-enqsettingarea">
		<div id="cms8341-enqcntrollarea">
		<p class="label"><img
			src="<?=RPW?>/admin/images/set_enquete/label_labeling.jpg"
			width="430" height="20" alt="ラベル設定"></p>
		<table width="430" border="0" cellpadding="5" cellspacing="0">
			<tr>
				<th width="100" align="left" valign="top" nowrap>項目名<span
					class="cms_require">（必須）</span>
				<div class="cms_recommend"><?=$name_comment?></div>
				</th>
				<td align="left" valign="top"><input name="name" type="text"
					id="name" size="50" maxlength="<?=$name_max_input?>"
					class="width270"> <br>
				<input type="checkbox" name="nes" id="nes" value="1"> <label
					for="nes">必須項目にする</label>
				<?php
					if($_GET['from_type'] == ENQ_KIND_MAIL && ENQ_RETURN_MAIL_SEND_FLG == FLAG_ON){
				?>
					<input type="checkbox" name="desc_mail" id="desc_mail" value="1" checked>
					<label for="desc_mail">返信メールに記載</label>
					<br>
				<?php
					}
				?>
				</td>
			</tr>
			<tr>
				<th width="100" align="left" valign="top" nowrap>注意事項
				<div class="cms_recommend"><?=ENQ_CONTROL_MEMO_COMMENT?></div>
				</th>
				<td align="left" valign="top"><textarea name="memo" cols="40"
					rows="3" id="memo" class="width270"></textarea></td>
			</tr>
<?php
if ($_GET['from_type'] == ENQ_KIND_CGI) {
	?>
<tr>
				<th width="100" align="left" valign="top" nowrap>画像</th>
				<td align="left" valign="top">
	<?php
	if ($_GET['img'] != "") {
		$alt = "";
		$link = $_GET['img'];
		$disp_width = ' width="' . (IMAGE_PREV_WIDTH > $_GET['img_width'] ? $_GET['img_width'] : IMAGE_PREV_WIDTH) . '"';
		$disp_height = ' height="' . (IMAGE_PREV_WIDTH > $_GET['img_width'] ? $_GET['img_height'] : round((IMAGE_PREV_WIDTH * $_GET['img_height']) / $_GET['img_width'])) . '"';
	}
	else {
		$alt = "";
		$link = RPW . "/admin/images/thumbnails/temp1.gif";
		$disp_width = ' width="0"';
		$disp_height = ' height="0"';
	}
	?>
	<div
					style="width: 240px; height: 80px; overflow-y: scroll; float: left;">
				<input type="hidden" id="cms_image_hidden"
					value="<?=$_GET['img']?>"> <img id="cms_image" src="<?=$link?>"
					alt="<?=$alt?>" <?=$disp_width?> <?=$disp_height?> /></div>
				<div style="margin-left: 5px; float: right;">
				<p><a href="javascript:void(0)"
					onclick="imageSelect('cms_image');return false;"><img
					src="<?=RPW?>/admin/images/btn/btn_img_setup_on.gif" border="0"
					alt="画像設定" class="cms8341-verticalMiddle"
					style="margin-top: 5px; border: 0px;" /></a></p>
				<p><a href="javascript:void(0)"
					onclick="deleteImage('cms_image');return false;"><img
					src="<?=RPW?>/admin/images/btn/btn_del_mini.gif" border="0"
					alt="削除する" class="cms8341-verticalMiddle"
					style="margin-top: 5px; border: 0px;" /></a></p>
				</div>
				</td>
			</tr>
<?php
}
?>
</table>
		<p class="label"><img
			src="<?=RPW?>/admin/images/set_enquete/label_selectctrl.jpg"
			width="430" height="20" alt="コントロール選択"></p>
		<table width="430" border="0" cellpadding="5" cellspacing="0">
			<tr>
				<td width="170" align="left" valign="top" nowrap><input
					name="controll" type="radio" id="controll_a" value="input" checked>
				<label for="controll_a">テキスト（1行）</label> <br>
				<input name="controll" id="controll_b" type="radio" value="textarea">
				<label for="controll_b">テキスト（複数行）</label> <br>
<?php
if ($_GET['from_type'] == ENQ_KIND_MAIL) {
	?><input name="controll" type="radio" id="controll_f"
					value="input_mail"> <label for="controll_f">メールアドレス</label> <br><?php
}
?>
<input name="controll" id="controll_c" type="radio" value="radio"> <label
					for="controll_c">ラジオボタン</label> <br>
				<input name="controll" id="controll_d" type="radio" value="checkbox">
				<label for="controll_d">チェックボックス</label> <br>
				<input name="controll" id="controll_e" type="radio" value="select">
				<label for="controll_e">選択リスト</label></td>
				<td align="center" valign="middle">
				<p id="sample_input"><input name="sample_a" type="text"
					class="width210" id="sample_a" value="サンプル" size="30"></p>
				<p class="none" id="sample_textarea"><textarea name="sample_b"
					cols="25" rows="4" class="width210" id="sample_b">サンプル
サンプル</textarea></p>
				<p class="none" id="sample_input"><input name="sample_a" type="text"
					class="width210" id="sample_a" value="サンプル" size="30"></p>
				<p class="none" id="sample_textarea"><textarea name="sample_b"
					cols="25" rows="4" class="width210" id="sample_b">サンプル
サンプル</textarea></p>
				<p class="none" id="sample_radio"><input name="sample_c"
					id="sample_c1" type="radio" value="サンプル" checked> <label
					for="sample_c1">サンプル１</label><br>
				<input name="sample_c" id="sample_c2" type="radio" value="サンプル"> <label
					for="sample_c2">サンプル２</label><br>
				<input name="sample_c" id="sample_c3" type="radio" value="サンプル"> <label
					for="sample_c3">サンプル３</label><br>
				<input name="sample_c" id="sample_c4" type="radio" value="サンプル"> <label
					for="sample_c4">サンプル４</label></p>
				<p class="none" id="sample_checkbox"><input name="sample_d"
					type="checkbox" id="sample_d1" value="サンプル" checked> <label
					for="sample_d1">サンプル１</label><br>
				<input name="sample_d" id="sample_d2" type="checkbox" value="サンプル">
				<label for="sample_d2">サンプル２</label><br>
				<input name="sample_d" id="sample_d3" type="checkbox" value="サンプル">
				<label for="sample_d3">サンプル３</label><br>
				<input name="sample_d" id="sample_d4" type="checkbox" value="サンプル">
				<label for="sample_d4">サンプル４</label></p>
				<p class="none" id="sample_select"><select name="sample_e"
					class="width210">
					<option>サンプル１</option>
					<option>サンプル２</option>
					<option>サンプル３</option>
				</select></p>
				</td>
			</tr>
		</table>
		<p class="label"><img
			src="<?=RPW?>/admin/images/set_enquete/label_setctrl.jpg" width="430"
			height="20" alt="コントロール設定"></p>
		<div id="input_detail">
		<p><span id="input_detail_text"><strong>テキスト（1行）の設定</strong></span><span id="input_reply_mail_text"></span></p>
		<table width="430" border="0" cellpadding="5" cellspacing="0">
			<tr>
				<th width="100" align="left" valign="top" nowrap>横幅</th>
				<td align="left" valign="top"><input name="input_set1" type="text"
					class="ime-none width100" id="input_set1" size="10" maxlength="3"
					value="<?=ENQ_CONTROL_INPUT_SET1?>" onkeypress="IsDigit(event)">
				文字分</td>
			</tr>
			<tr>
				<th width="100" align="left" valign="top" nowrap>最大文字数</th>
				<td align="left" valign="top"><input name="input_set2" type="text"
					class="ime-none width100" id="input_set2" size="10" maxlength="3"
					onkeypress="IsDigit(event)"> 文字</td>
			</tr>
			<tr>
				<th width="100" align="left" valign="top" nowrap>初期値
				<div class="cms_recommend"><?=ENQ_CONTROL_INPUT_SET3_COMMENT?></div>
				</th>
				<td align="left" valign="top"><input name="input_set3" type="text"
					id="input_set3" size="50"
					maxlength="<?=ENQ_CONTROL_INPUT_SET3_MAX_INPUT?>" class="width270"></td>
			</tr>
		</table>
		</div>
		<div class="none" id="textarea_detail">
		<p><strong>テキスト（複数行）の設定</strong></p>
		<table width="430" border="0" cellpadding="5" cellspacing="0">
			<tr>
				<th width="100" align="left" valign="top" nowrap>横幅</th>
				<td align="left" valign="top"><input name="textarea_set1"
					type="text" class="ime-none width100" id="textarea_set1" size="10"
					maxlength="3" value="<?=ENQ_CONTROL_INPUT_SET1?>"
					onkeypress="IsDigit(event)"> 文字分</td>
			</tr>
			<tr>
				<th width="100" align="left" valign="top" nowrap>縦幅</th>
				<td align="left" valign="top"><input name="textarea_set2"
					type="text" class="ime-none width100" id="textarea_set2" size="10"
					maxlength="3" onkeypress="IsDigit(event)"> 行分</td>
			</tr>
			<tr>
				<th width="100" align="left" valign="top" nowrap>初期値
				<div class="cms_recommend"><?=ENQ_CONTROL_TEXTAREA_SET3_COMMENT?></div>
				</th>
				<td align="left" valign="top"><textarea name="textarea_set3"
					id="textarea_set3" cols="40" rows="5" class="width270"></textarea></td>
			</tr>
		</table>
		</div>
		<div class="none" id="radio_detail">
		<p><strong>ラジオボタンの設定</strong></p>
		<table width="430" border="0" cellpadding="5" cellspacing="0">
			<tr>
				<th width="100" align="left" valign="top" nowrap>回答項目
				<div class="cms_recommend"><?=ENQ_CONTROL_RADIO_SET1_COMMENT?></div>
				</th>
				<td align="left" valign="top"><input name="radio_set1" type="text"
					id="radio_set1" size="40"
					maxlength="<?=ENQ_CONTROL_RADIO_SET1_MAX_INPUT?>" class="width210">
				<img src="<?=RPW?>/admin/images/set_enquete/btn_add.jpg" width="80"
					height="21" alt="追加する" id="radio_add" style="cursor: pointer"
					align="absmiddle"> <br>
				<input name="radio_set2" id="radio_set2" type="checkbox" value="1">
				<label for="radio_set2">チェック済みにする</label> &nbsp;&nbsp;<input
					name="radio_set3" id="radio_set3" type="checkbox" value="1"> <label
					for="radio_set3">改行を入れる</label></td>
			</tr>
			<tr>
				<th width="100" align="left" valign="top" nowrap>回答リスト</th>
				<td align="left" valign="top">
				<div class="result_container">
				<div class="resultarea" id="radio_result"></div>
				<div id="dummy"></div>
				</div>
				<p class="ctrl"><img
					src="<?=RPW?>/admin/images/set_enquete/btn_edit_on.jpg" width="61"
					height="20" alt="編集する" id="radio_edit" style="cursor: pointer"
					align="absmiddle"> <img
					src="<?=RPW?>/admin/images/set_enquete/btn_del_on.jpg" width="61"
					height="20" alt="削除する" id="radio_del" style="cursor: pointer"
					align="absmiddle"> <img
					src="<?=RPW?>/admin/images/set_enquete/btn_up_on.jpg" width="61"
					height="20" alt="上へ" id="radio_up" style="cursor: pointer"
					align="absmiddle"> <img
					src="<?=RPW?>/admin/images/set_enquete/btn_down_on.jpg" width="61"
					height="20" alt="下へ" id="radio_down" style="cursor: pointer"
					align="absmiddle"></p>
				</td>
			</tr>
		</table>
		</div>
		<div class="none" id="checkbox_detail">
		<p><strong>チェックボックスの設定</strong></p>
		<table width="430" border="0" cellspacing="0" cellpadding="5">
			<tr>
				<th width="100" align="left" valign="top" nowrap>回答項目
				<div class="cms_recommend"><?=ENQ_CONTROL_CHECKBOX_SET1_COMMENT?></div>
				</th>
				<td align="left" valign="top"><input name="checkbox_set1"
					type="text" id="checkbox_set1" size="40"
					maxlength="<?=ENQ_CONTROL_CHECKBOX_SET1_MAX_INPUT?>"
					class="width210"> <img
					src="<?=RPW?>/admin/images/set_enquete/btn_add.jpg" width="80"
					height="21" alt="追加する" id="checkbox_add" style="cursor: pointer"
					align="absmiddle"> <br>
				<input name="checkbox_set2" id="checkbox_set2" type="checkbox"
					value="1"> <label for="checkbox_set2">チェック済みにする</label>
				&nbsp;&nbsp;<input name="checkbox_set3" id="checkbox_set3"
					type="checkbox" value="1"> <label for="checkbox_set3">改行を入れる</label></td>
			</tr>
			<tr>
				<th width="100" align="left" valign="top" nowrap>回答リスト</th>
				<td align="left" valign="top">
				<div class="result_container">
				<div class="resultarea" id="checkbox_result"></div>
				</div>
				<p class="ctrl"><img
					src="<?=RPW?>/admin/images/set_enquete/btn_edit_on.jpg" width="61"
					height="20" alt="編集する" id="checkbox_edit" style="cursor: pointer"
					align="absmiddle"> <img
					src="<?=RPW?>/admin/images/set_enquete/btn_del_on.jpg" width="61"
					height="20" alt="削除する" id="checkbox_del" style="cursor: pointer"
					align="absmiddle"> <img
					src="<?=RPW?>/admin/images/set_enquete/btn_up_on.jpg" width="61"
					height="20" alt="上へ" id="checkbox_up" style="cursor: pointer"
					align="absmiddle"> <img
					src="<?=RPW?>/admin/images/set_enquete/btn_down_on.jpg" width="61"
					height="20" alt="下へ" id="checkbox_down" style="cursor: pointer"
					align="absmiddle"></p>
				</td>
			</tr>
		</table>
		</div>
		<div class="none" id="select_detail">
		<p><strong>選択リストの設定</strong></p>
		<table width="430" border="0" cellspacing="0" cellpadding="5">
			<tr>
				<th width="100" align="left" valign="top" nowrap>回答項目
				<div class="cms_recommend"><?=ENQ_CONTROL_SELECT_SET1_COMMENT?></div>
				</th>
				<td align="left" valign="top"><input name="select_set1" type="text"
					id="select_set1" size="40"
					maxlength="<?=ENQ_CONTROL_SELECT_SET1_MAX_INPUT?>" class="width210">
				<img src="<?=RPW?>/admin/images/set_enquete/btn_add.jpg" width="80"
					height="21" alt="追加する" id="select_add" style="cursor: pointer"
					align="absmiddle"> <br>
				<input name="select_set2" id="select_set2" type="checkbox" value="1">
				<label for="select_set2">チェック済みにする</label></td>
			</tr>
			<tr>
				<th width="100" align="left" valign="top" nowrap>回答リスト</th>
				<td align="left" valign="top">
				<div class="result_container">
				<div class="resultarea" id="select_result"></div>
				</div>
				<p class="ctrl"><img
					src="<?=RPW?>/admin/images/set_enquete/btn_edit_on.jpg" width="61"
					height="20" alt="編集する" id="select_edit" style="cursor: pointer"
					align="absmiddle"> <img
					src="<?=RPW?>/admin/images/set_enquete/btn_del_on.jpg" width="61"
					height="20" alt="削除する" id="select_del" style="cursor: pointer"
					align="absmiddle"> <img
					src="<?=RPW?>/admin/images/set_enquete/btn_up_on.jpg" width="61"
					height="20" alt="上へ" id="select_up" style="cursor: pointer"
					align="absmiddle"> <img
					src="<?=RPW?>/admin/images/set_enquete/btn_down_on.jpg" width="61"
					height="20" alt="下へ" id="select_down" style="cursor: pointer"
					align="absmiddle"></p>
				</td>
			</tr>
		</table>
		</div>
		</div>
		<p align="center"><a href="#" id="submit"><img
			src="<?=RPW?>/admin/images/set_enquete/btn_submit.jpg" width="101"
			height="20" alt="設定" style="border: none; margin-right: 4px"></a> <a
			href="#" id="cansel" onClick="cxIframeLayerCallback()"><img
			src="<?=RPW?>/admin/images/set_enquete/btn_cansel.jpg" width="101"
			height="20" alt="キャンセル" style="border: none; margin-left: 4px"></a></p>
		</div>
		<input type="hidden" name="RPW" id="RPW" value="<?=RPW?>"> <input
			type="hidden" name="id" id="id" value="<?=$_GET['id']?>"> <input
			type="hidden" name="page_id" id="page_id"
			value="<?=$_GET['page_id']?>"> <input type="hidden" name="dir_path"
			id="dir_path" value="<?=$_GET['dir_path']?>"> <input type="hidden"
			name="hidden_img" id="hidden_img" value="<?=$_GET['img']?>"> <input
			type="hidden" name="from_type" id="from_type"
			value="<?=$_GET['from_type']?>">
		</form>
<?php
print $objTool->setAccessibility();
?>






</body>
</html>
