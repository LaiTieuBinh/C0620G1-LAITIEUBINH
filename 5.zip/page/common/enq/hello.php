<?php
/*
 *
 */
mb_language('Japanese');
mb_internal_encoding('UTF-8');

$ret = $_POST;
$msg = "Hello PHP 5.2.3";
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>アンケート設定確認</title>
</head>

<body>
<h1>アンケート設定確認</h1>
<p>取得データ</p>
<p><?=$msg?></p>
</body>
</html>
