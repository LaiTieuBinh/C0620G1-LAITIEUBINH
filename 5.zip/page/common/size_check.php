<?php
/*
 * ページの容量チェックを行なう
 */
//外部ファイル読み込み
require ("../.htsetting");

//POST値のチェック
if (!isset($_POST['param'])) {
	print '-1,-1';
	exit();
}

//POST値の取得
$html = replace_src($_POST['param']);

//本文の容量を取得
$text_size = strlen($html);

//画像ファイルの容量を取得
$img_size = 0;
$pos = 0;
//<img src="">の値を探索
while (preg_match('/<img( [^>]*)? src="([^"]*)"[^>]*>/i', $html, $ret, PREG_OFFSET_CAPTURE, $pos)) {
	//情報の取得
	$str = $ret[0][0];
	$src = $ret[2][0];
	$pos = $ret[0][1] + strlen($str);
	
	//外部の画像は対象外
	if (preg_match('/^(htt(ps?)?:\/\/)([^\/]+)(\/.*$)/i', $src, $match)) {
		//ドメイン名を削除
		// CKエディタ(文字指定の無いアンカーに付与されるクラス名を変更)
		if (preg_match('/class="cke_anchor"/i', $src) || preg_match('/cms8341/i', $src)) $src = $match[4];
		else continue;
	}
	//ファイルが実在する場合は、ファイル容量の取得
	if (@file_exists(DOCUMENT_ROOT . $src)) $img_size += filesize(DOCUMENT_ROOT . $src);
}

//キロバイトに変換
$text_size = ((0 < $text_size) ? ceil($text_size / 1024) : 0);
$img_size = ((0 < $img_size) ? ceil($img_size / 1024) : 0);
$out = $text_size . ',' . $img_size;
header("Content-Type: text/html; charset=UTF-8");
print $out;
exit();
?>