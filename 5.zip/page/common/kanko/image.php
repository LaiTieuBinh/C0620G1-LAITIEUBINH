<?php
/*
 * 画像の設定を行う
 */
//設定ファイル読み込み
require_once ("./.htsetting");

//エラー画面設定 別ウィンドウ用
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

//DBアクセス用ファイルの読み込み
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

if (isset($_SESSION['post']) && $_SESSION['post'] != "") {
	$POST = $_SESSION['post'];
	unset($_SESSION['post']);
}

//変数の初期化
//フォルダパス(絶対パス)
$real_base_path = DOCUMENT_ROOT . RPW;

//フォルダパスの取得
//SESSIONを取得できる場合
if (isset($_SESSION['cms_page_id']) && $_SESSION['cms_page_id'] != "") {
	//パス取得
	if ($objPage->selectFromID($_SESSION['cms_page_id'], WORK_TABLE, "file_path") !== FALSE) {
		$real_base_path .= cms_dirname($objPage->fld['file_path']) . FCK_IMAGES_FORDER;
	}
	else if ($objPage->selectFromID($_SESSION['cms_page_id'], PUBLISH_TABLE, "file_path") !== FALSE) {
		$real_base_path .= cms_dirname($objPage->fld['file_path']) . FCK_IMAGES_FORDER;
	}
	else
		user_error('ページ情報を取得できませんでした。', E_USER_ERROR);
}
else
	user_error('ログイン情報を取得できませんでした。現在の開いている全てのブラウザを閉じて再度実行してください。', E_USER_ERROR);
	
//値の取得
if (isset($_GET['value'])) {
	$value = str_replace("＃", "#", $_GET['value']);
	$values = explode(KANKO_LINK_DELIMITER, $value);
	if (isset($values[0])) $src = htmlDisplay($values[0], "nonspace");
	if (isset($values[1])) $alt = htmlDisplay($values[1], "nonspace");
}
//変数設定、SESSION削除
if (isset($_GET['type']) && $_GET['type'] == 'image') {
	if (isset($_SESSION['kanko_image_size'])) unset($_SESSION['kanko_image_size']);
	if (isset($_SESSION['kanko_image_size_height'])) unset($_SESSION['kanko_image_size_height']);
}
if (isset($_GET['size'][0]) && is_numeric($_GET['size'][0])) $_SESSION['kanko_image_size'] = $_GET['size'][0];
if (isset($_GET['size'][1]) && is_numeric($_GET['size'][1])) $_SESSION['kanko_image_size_height'] = $_GET['size'][1];
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex, nofollow" />
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>画像設定</title>
<base target="_self">
<link rel="stylesheet" href="<?=RPW?>/admin/style/normalize.css" type="text/css">
<link rel="stylesheet" href="<?=RPW?>/ckeditor/gd_files/css/dialog.css" type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script	src="<?=RPW?>/ckeditor/gd_files/js/dialog_common.js" type="text/javascript"></script>
<script src="<?=RPW?>/ckeditor/plugins/gd_image/pages/js/com_func.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/page/common/kanko/js/image.js" 	type="text/javascript"></script>
<script src="<?=RPW?>/admin/page/common/kanko/js/image_upload.js" type="text/javascript"></script>
<script type="text/javascript">
			<!--
				var get_mode = '<?php
				print((isset($_GET["mode"]) && $_GET["mode"] == "upload" ? "upload" : "property"));
				?>';
				var err_msg = '<?php
				print((isset($_SESSION["err_msg"]) ? $_SESSION["err_msg"] : ""));
				?>';
				var template_kind = '<?php
				print((isset($_SESSION["use_template_kind"]) ? $_SESSION["use_template_kind"] : ""));
				?>';
				<?php
				unset($_SESSION["err_msg"]);
				?>
				var POST = new Object();
				POST["url"] = '<?php
				print((isset($_POST["url"]) ? javaStringEscape($_POST["url"]) : ""));
				?>';
				POST["width"] = '<?php
				print((isset($_POST["width"]) ? javaStringEscape($_POST["width"]) : ""));
				?>';
				POST["height"] = '<?php
				print((isset($_POST["height"]) ? javaStringEscape($_POST["height"]) : ""));
				?>';
				POST["alt"] = '<?php
				print((isset($_POST["alt"]) ? javaStringEscape($_POST["alt"]) : ""));
				?>';
				var GET = new Object();
				GET["id"] = '<?php
				print((isset($_GET["id"]) ? javaStringEscape($_GET["id"]) : ""));
				?>';
				GET["src"] = '<?php
				print((isset($src) ? javaStringEscape($src) : ""));
				?>';
				GET["alt"] = '<?php
				print((isset($alt) ? javaStringEscape($alt) : ""));
				?>';
				<?php
				//上書きがあった場合、編集画面に表示されている画像を差し替える
				if (isset($_SESSION["updata_file"]) && count($_SESSION["updata_file"]) > 0) {
					$script = 'window.dialogArguments = window.frameElement.args; var targetArea = window.dialogArguments.document.body;' . "\n";
					$script .= 'var img_ary = targetArea.getElementsByTagName(\'img\');' . "\n";
					$script .= 'var updata_ary = [' . "\n";
					foreach ((array) $_SESSION["updata_file"] as $val) {
						$script .= '"' . $val . '",' . "\n";
					}
					$script = substr($script, 0, strrpos($script, ",")) . "\n";
					$script .= ']' . "\n";
					$script .= 'var img = new Array();' . "\n";
					$script .= 'for(var i = 0;i < updata_ary.length;i++){' . "\n";
					$script .= 'for(var j = 0;j < img_ary.length;j++){' . "\n";
					$script .= 'if(updata_ary[i] == img_ary[j].src.substring(img_ary[j].src.indexOf(baseUrl),(img_ary[j].src.indexOf(\'?\') > 0 ? img_ary[j].src.indexOf(\'?\') : img_ary[j].src.length))){' . "\n";
					$rnd = rand();
					$script .= 'cxPreImages(updata_ary[i] + "?rnd=' . $rnd . '");' . "\n";
					$script .= 'img[j] = new Image();' . "\n";
					$script .= 'img[j].src = updata_ary[i] + "?rnd=' . $rnd . '";' . "\n";
					$script .= 'img[j].onload = function(){img_load(img,img_ary);}' . "\n";
					$script .= '}' . "\n";
					$script .= '}' . "\n";
					$script .= '}' . "\n";
					$script .= 'function img_load(org_img_obj,img_obj){' . "\n";
					//$script .= 'var kanko_image_size = "' . $_SESSION['kanko_image_size'] . '";' . "\n";
					$script .= 'for(var i = 0;i < img_obj.length;i++){' . "\n";
					$script .= 'if(org_img_obj[i]){' . "\n";
					$script .= 'var w_size = (img_obj[i].w_size ? parseInt(img_obj[i].w_size) : org_img_obj[i].width);' . "\n";
					$script .= 'var h_size = (img_obj[i].h_size ? parseInt(img_obj[i].h_size) : org_img_obj[i].height);' . "\n";
					$script .= 'img_obj[i].src = org_img_obj[i].src;' . "\n";
					$script .= 'if(w_size < org_img_obj[i].width || h_size < org_img_obj[i].height){' . "\n";
					$script .= 'var W = w_size / org_img_obj[i].width;' . "\n";
					$script .= 'var H = h_size / org_img_obj[i].height;' . "\n";
					$script .= '(W < H) ? key = W : key= H;' . "\n";
					$script .= 'img_obj[i].width = Math.ceil(org_img_obj[i].width * key);' . "\n";
					$script .= 'img_obj[i].height = Math.ceil(org_img_obj[i].height * key);' . "\n";
					$script .= '}else{' . "\n";
					$script .= 'img_obj[i].width = org_img_obj[i].width;' . "\n";
					$script .= 'img_obj[i].height = org_img_obj[i].height;' . "\n";
					$script .= '}' . "\n";
					//$script .= 'img_obj[i].width = (kanko_image_size > org_img_obj[i].width ? org_img_obj[i].width : kanko_image_size);' . "\n";
					$script .= '}' . "\n";
					$script .= '}' . "\n";
					$script .= '}' . "\n";
					print($script);
					unset($_SESSION["updata_file"]);
				}
				?>
				<?php
				echo loadSettingVars();
				?>
			//-->
		</script>
</head>
<body>
<div class="cke_dialog_title">画像設定<img style="float: right; cursor: pointer;" onclick="cxIframeLayerCallback();return false;" src="<?=RPW?>/ckeditor/skins/moono-lisa/images/close.png" alt="閉じる"></div>
<div id="cms8341-headareaZero" style="margin-bottom: 0px !important">
		<div id="divProperty">
		<div id="cms8341-tab" class="cke_dialog_tabs">
		<table border="0" cellspacing="0" cellpadding="0"
			style="border-collapse: collapse;">
			<tr>
				<td><a style="height: 28px;" class="cke_dialog_tab" href="<?=RPW?>/admin/page/common/kanko/image.php?mode=upload"><span>PCから選んで登録</span></td>
				<td><a style="height: 26px;" class="cke_dialog_tab cke_dialog_tab_selected" ><span> 登録済画像から選択 </span></a></td>
			</tr>
		</table>
		</div>
		<table width="100%" height="520px" cellspacing="0" cellpadding="5" class="cke_dialog_contents"
			style="background-color: #FFFFFF; border-top: solid 1px #999999;">
			<tr>
				<td valign="top">
				<div style="border-collapse: collapse; text-align: left; padding: 15px 2px 10px 2px; align: center">
				<fieldset>
				<legend>画像情報</legend>
				<form name="cms_fck_image_property" id="cms_fck_image_property"
					action="javascript:void(0)" method="post"
					enctype="multipart/form-data"
					onsubmit="cxSubmit_Property(); return false;">
				<table width="100%" border="0" cellspacing="0" align="center">
					<tr>
						<td width="30%" align="center" valign="top"
							style="padding-top: 20px; padding-bottom: 15px;"><img
							id="imgPreview" src="<?=RPW?>/admin/images/spacer.gif" alt=""
							width="0" height="0"></td>
						<td width="70%" align="center" valign="top"
							style="border--bottom: solid 1px #999999; padding-left: 5px; padding-top: 5px; padding-bottom: 5px;">
						<table width="100%" border="0" cellspacing="0" cellpadding="0"
							style="border: none; margin: 0px; padding-top: 2px; padding-bottom: 2px;">
							<tr style="padding-top: 10px;">
								<td
									style="font-size: 15px; font-weight: bold; padding-left: 5px;"><span class="cke_dialog_ui_labeled_label">代替テキスト</span></td>
							</tr>
							<tr>
								<td style="padding-left: 5px;"><input id="txtAlt" class="cke_dialog_ui_input_text" 
									style="WIDTH: 90%" type="text"></td>
							</tr>
							<tr style="padding-bottom: 10px;">
								<td style="padding-left: 1px;"><input id="chkAlt"
									type="checkbox" onClick="setAlt();"><label for="chkAlt"><span
									class="cke_dialog_ui_labeled_label">代替テキストを設定しない</span></label></td>
							</tr>
						</table>
						</td>
					</tr>
				</table>
				</fieldset>
				<div align="center" style="margin: 15px 0px;"><input type="submit"
					name="submit_property" id="submit_property"
					 class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_grey"
					height="20" value="設定" border="0"> &nbsp; &nbsp; &nbsp; <a
					href="<?=RPW?>/admin/page/common/kanko/image_list.php" class="cke_dialog_ui_button">一覧画面へ</a></div>
				</form>
				</div>
				</td>
			</tr>
		</table>
		</div>
		<div id="divUpload" style="DISPLAY: none">
		<div id="cms8341-tab" class="cke_dialog_tabs">
		<table border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
			<tr>
				<td><a style="height: 26px;" href="fck_image.php?mode=upload" class="cke_dialog_tab cke_dialog_tab_selected" >
				<span>PCから選んで登録</span></a></td>
				<td><a style="height: 28px;" class="cke_dialog_tab" href="<?=RPW?>/admin/page/common/kanko/image_list.php">
				<span>登録済画像から選択</span></a></td>
			</tr>
		</table>
		</div>
		<table width="100%" height="500px" cellspacing="0" cellpadding="0" class="cke_dialog_contents" >
			<tr>
				<td valign="top">
				<form name="cms_fck_image_upload" id="cms_fck_image_upload"
					action="<?=RPW?>/admin/page/common/kanko/image_upload.php"
					method="post" enctype="multipart/form-data"
					onsubmit="cxSubmit_Upload('<?=$real_base_path?>'); return false;">
													<?php
													for($i = 0; $i < 5; $i++) {
															print('<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center" class="cms8341-dataTable" style="border-collapse:collapse;margin-top: 10px;">');
															print('<tr>');
															print('<th width="15%" align="left" valign="top" class="cke_dialog_ui_labeled_label">画像名称' . ($i + 1) . '</th>');
															print('<td width="85%" valign="top">');
															print('<input id="cms_image_name_' . $i . '" name="cms_image_name_' . $i . '" style="WIDTH: 98%;" type="text" class="cke_dialog_ui_input_text" maxlength="64" value="' . (isset($POST['cms_image_name_' . $i]) ? htmlDisplay($POST['cms_image_name_' . $i]) : "") . '">');
															print('</td>');
															print('</tr>');
															print('<tr>');
															print('<th width="15%" align="left" valign="top" class="cke_dialog_ui_labeled_label">ファイル' . ($i + 1) . '</th>');
															print('<td width="85%">');
															print('<label width="10%" for="cms_image_path_' . $i . '" class="cke_dialog_ui_button cke_dialog_ui_button_padding" style="margin-left: 1px;">参照</label> <span type="text"id="file-selected_' . $i . '"></span>');
															print('</td>');
															print('<input id="cms_image_path_' . $i . '" style="visibility:hidden; display: none;" name="cms_image_path_' . $i . '" type="file">');
															print('<script> var filetype_' . $i . ' = document.getElementById("cms_image_path_' . $i . '"); filetype_' . $i . '.onchange = function(){ var fileName = ""; fileName = filetype_' . $i . '.value; document.getElementById("file-selected_' . $i . '").innerHTML = fileName.replace(/^.*[\\\/]/, ""); };</script>');
															print('</tr>');																																						
															print('</table>');
															print('<input type="hidden" id="cms_rename_file_path_' . $i . '" name="cms_rename_file_path_' . $i . '">');

													}
													?>
													<br />
				<br />
				<div align="center"><input type="submit" class="cke_dialog_ui_button cke_dialog_ui_button_grey" name="submit_upload"
					id="submit_upload" value="登録" style="padding-right: 30px; padding-left: 30px;"></div>
				</form>
				</td>
			</tr>
		</table>
		</div>
							<?php
							print($objTool->setAccessibility());
							?>
						</div>
		</td>
	</tr>
</table>
</div>
</body>
</html>
