/*
 * 画像設定用javascript
 */

//変数の設定
var oImage_real;
var oImage;
var oImageOriginal;
var bHasImage;
var sPrevUrl;
var bLockRatio = true;
var Random_num = 0;

//-------------------------------------------------
//	キーを押したときの処理
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
window.document.onkeydown = function(e){
	e = e || event || this.parentWindow.event;
	switch(e.keyCode){
		//ENTER
		case 13:
			var oTarget = e.srcElement || e.target;
			if(oTarget.tagName == 'TEXTAREA') return;
			if(oTarget.tagName == 'INPUT' && (oTarget.type == 'text' || oTarget.type == 'file')){
				if(oTarget.form.id == 'cms_fck_image_upload') $('submit_upload').click();
				else if(oTarget.form.id == 'cms_fck_image_property') $('submit_property').click();
			}
			return false;
			break;
		//ESC
		case 27:
			cxIframeLayerCallback();
			return false;
			break;
	}
	return true;
}

//-------------------------------------------------
//	ロード時に実行される
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
window.onload = function(){
	//フォーカスを自身のウィンドウにする
	window.self.focus();
	//GETされたモードがuploadなら、load処理終了
	if(get_mode == "upload"){
		$('divProperty').style.display = "none";
		$('divUpload').style.display = "";
		return;
	}
	//エラーメッセージがあれば、アラート表示して、load処理終了
	if(err_msg){
		$('divProperty').style.display = "none";
		$('divUpload').style.display = "";
		alert(err_msg);
		return;
	}
	//現在選択されている画像の取得
	if(GET["src"] && GET["src"] != ""){
		//キャッシュから画像を読ませないための乱数
		Random_num = parseInt((Math.random() * 10000) + 1);

		oImage_real = document.createElement('IMG');
		oImage_real.src = RPW + GET["src"] + '?rnd=' + Random_num;
		oImage_real.alt = GET["alt"];
	}
	else oImage_real = null;
	//POSTの値を取得
	LoadPost();
	//画面上のイメージを選択している場合
	if(oImage_real){
		//画像が無ければ、画面上のイメージを取得
		if(!oImage) oImage = oImage_real;
		//画面上イメージの選択の有無
		bHasImage = true;
	}
	//画面上のイメージを選択していない場合
	else bHasImage = false;
	//プロパティを表示
	if(oImage){
		$('divProperty').style.display = "";
		$('divUpload').style.display = "none";
	}
	//アップロードを表示
	else{
		$('divProperty').style.display = "none";
		$('divUpload').style.display = "";
		return;
	}
	//リンクに設定されている値の取得
	LoadSelection();
	//プレビュー情報の取得
	LoadPreview();
	//alt入力フォームの表示切り替え
	setAlt();
}

//-------------------------------------------------
//	POSTの値を取得し、イメージオブジェクトを作成する
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
function LoadPost(){
	//POST値が無ければ、returnする
	if(POST["url"] == "") return;
	//イメージオブジェクトの作成
	oImage = document.createElement('IMG');
	//POST値の取得
	oImage.src = POST["url"];
	oImage.width = POST["width"];
	oImage.height = POST["height"];
	oImage.alt = POST["alt"];
	sPrevUrl = POST["url"];
}

//-------------------------------------------------
//	現在設定されている値を取得する
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
function LoadSelection(){
	//イメージオブジェクトが存在しなければ、returnする
	if(!oImage) return;
	//画像パスを取得
	var sUrl = GetAttribute(oImage,'_fcksavedurl','');
	if(sUrl.length == 0) sUrl = GetAttribute(oImage,'src','');
	sPrevUrl = sUrl;

	//イメージにセットされている値の取得
	$('txtAlt').value = GetAttribute(oImage,'alt','');
	if($('txtAlt').value == "") $('chkAlt').checked = true;

	//イメージの縦・横幅を取得
	var iWidth,iHeight;
	var regexSize = /^\s*(\d+)px\s*$/i;
	//イメージの横幅
	if(oImage.style.width){
		var aMatch = oImage.style.width.match(regexSize);
		if(aMatch) iWidth = aMatch[1];
	}
	//イメージの縦幅
	if(oImage.style.height){
		var aMatch = oImage.style.height.match(regexSize);
		if(aMatch) iHeight = aMatch[1];
	}
}

//-------------------------------------------------
//	プレビュー用画像の情報作成
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
var TimerID;
function LoadPreview(){
	//プレビュー画像にURLをセット
	$('imgPreview').src = sPrevUrl + "?" + getRand(5);
	//オリジナル画像のセット
	UpdateOriginal(POST["url"] == "" ? null : true);
	TimerID = setInterval('imgComp_Check()',100);
	//プレビュー表示の値を取得
	iWidth = oImage.offsetWidth;
	iHeight = oImage.offsetHeight;
	//プレビュー画像用サイズの取得
	reduction_rate = Reduction_Rate_Fixation(iWidth,iHeight,130,130);
	//プレビュー画像にサイズをセット
	$('imgPreview').width = Math.round(iWidth * (reduction_rate != 0 ? reduction_rate : 1));
	$('imgPreview').height = Math.round(iHeight * (reduction_rate != 0 ? reduction_rate : 1));
}
function imgComp_Check(){
	if(oImageOriginal.complete == undefined || oImageOriginal.complete){
		clearInterval(TimerID);
		//プレビュー表示の値を取得
		iWidth = oImageOriginal.width;
		iHeight = oImageOriginal.height;
		//プレビュー画像用サイズの取得
		reduction_rate = Reduction_Rate_Fixation(iWidth,iHeight,130,130);
		//プレビュー画像にサイズをセット
		$('imgPreview').width = Math.round(iWidth * (reduction_rate != 0 ? reduction_rate : 1));
		$('imgPreview').height = Math.round(iHeight * (reduction_rate != 0 ? reduction_rate : 1));
	}
}

//-------------------------------------------------
//	オリジナル情報を持った画像オブジェクトの作成
//	【引数】
//		resetSize	: サイズをリセットする場合のフラグ
//	【戻値】
//		なし
//-------------------------------------------------
function UpdateOriginal(resetSize){
	//イメージオブジェクトの作成
	oImageOriginal = null;
	oImageOriginal = document.createElement('IMG');
	//画像のパスを設定
	oImageOriginal.src = $('imgPreview').src;
	//サイズをリセットする
	if(resetSize){
		oImageOriginal.onload = function(){
			this.onload = null;
		}
	}
}

//-------------------------------------------------
//	決定ボタンが押された際の処理
//	【引数】
//		なし
//	【戻値】
//		true	: 成功時
//		false	: 失敗時
//-------------------------------------------------
function cxSubmit_Property(){
	//altのチェック
	if($('chkAlt').checked == false){
		//altの取得
		var alt = trim($('txtAlt').value);
		//必須チェック
		if(alt.length == 0){
			alert('代替テキストを入力してください。');
			$('txtAlt').focus();
			return false;
		}
		//機種依存文字チェック
		var info = new Array();
		info = fckCheck('代替テキスト',$('txtAlt').value,info);
		info = accItemCheck('代替テキスト',$('txtAlt').value,info,'image');
		if(!info) return false;
		if(info.length > 0){
			var msg = info.join('\n') + '\nよろしいですか？';
			if(!confirm(msg)){
				$('txtAlt').focus();
				return false;
			}
		}
	}
	else $('txtAlt').value = "";
	//オブジェクトの作成
	var retObj = new Object();
	retObj["ret"] = oImage.src.replace(HTTP_ROOT + RPW,'').replace('?rnd=' + Random_num,'') + KANKO_LINK_DELIMITER + $F('txtAlt') + KANKO_LINK_DELIMITER + oImage.width + KANKO_LINK_DELIMITER + oImage.height;
	cxIframeLayerCallback(retObj);
	//正常終了
	return true;
}

//-------------------------------------------------
//	altの入力フォームをチェックボックスにより切り替える
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
function setAlt(){
	//チェックが付いていた場合
	if($('chkAlt').checked == true){
		$('txtAlt').disabled = true;
		$('txtAlt').style.backgroundColor = "#C0C0C0";
	}
	//チェックが付いていなかった場合
	else{
		$('txtAlt').disabled = "";
		$('txtAlt').style.backgroundColor = "";
	}
}

//-------------------------------------------------
//	画像の変更倍率を取得する(固定版)
//	【引数】
//		olg_w	: 元の横幅
//		olg_h	: 元の縦幅
//		new_w	: 新しい横幅
//		new_h	: 新しい縦幅
//	【戻値】
//		変更する倍率
//-------------------------------------------------
function Reduction_Rate_Fixation(olg_w,olg_h,new_w,new_h){
	//変更倍率
	var reduction_rate = 0;
	//指定値とのサイズの差を取得
	var w = olg_w - new_w;
	var h = olg_h - new_h;

	//縦・横両方が、指定値と違う場合
	if(w > 0 && h > 0){
		if(w > h) reduction_rate = new_w / olg_w;
		else reduction_rate = new_h / olg_h;
	}
	//縦・横どちらかが、指定値と違う場合
	else if(w > 0 || h > 0){
		//横が違う場合
		if(w > 0) reduction_rate = new_w / olg_w;
		//縦が違う場合
		else if(h > 0) reduction_rate = new_h / olg_h;
		//それ以外の場合
		else reduction_rate = 1;
	}
	//両方同じ場合
	else reduction_rate = 1;
	//値を返す
	return (isNaN(reduction_rate) ? 0 : reduction_rate);
}

//-------------------------------------------------
//	ランダム数字列を取得する
//	【引数】
//		num	: 桁数
//	【戻値】
//		ランダムな数字列
//-------------------------------------------------
function getRand(num){
	var ret = 0;
	for(var i = 0;i < num;i++){
		ret = ret * 10 + (Math.floor(Math.random() * 10));
	}
	return ret;
}
