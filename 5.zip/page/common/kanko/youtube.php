<?php
/*
 * YouTubeの設定を行う
 * $Rev: 25 $
 * $Date: 2009-12-03 16:53:23 +0900 (木, 03 12 2009) $
 * $Author: kawarazaki $
 */

//設定ファイル読み込み
require_once ("./.htsetting");

//エラー画面設定 別ウィンドウ用
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

//定数の読み込み
$YOUTUBE_PATTERN_ARY = getDefineArray('YOUTUBE_PATTERN_ARY');
$YOUTUBE_OPTION_ARY = getDefineArray('YOUTUBE_OPTION_ARY');
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex, nofollow" />
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>YouTube設定</title>
<link rel="stylesheet" href="<?=RPW?>/ckeditor/gd_files/css/dialog.css" type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/ckeditor/gd_files/js/dialog_common.js" type="text/javascript"></script>
<script type="text/javascript">
			<!--
				//オプションの値を作成
				var option_ary = new Array();
				<?php
				foreach ($YOUTUBE_OPTION_ARY as $option_name => $option_value) {
					print('option_ary[\'' . $option_name . '\'] = new Array();' . "\n");
					foreach ($option_value as $name => $key) {
						print('option_ary[\'' . $option_name . '\'][\'' . $name . '\'] = \'' . $key . '\';' . "\n");
					}
				}
				?>

				/**
				 * キーを押したときの処理
				 */
				window.document.onkeydown = function(e){
					e = e || event || this.parentWindow.event;
					switch(e.keyCode){
						//ENTER
						case 13:
							var oTarget = e.srcElement || e.target;
							if(oTarget.tagName == 'TEXTAREA') return;
							if(oTarget.tagName == 'INPUT' && (oTarget.type == 'text' || oTarget.type == 'file')) cxSubmit_Property();
							return false;
							break;
						//ESC
						case 27:
							cxIframeLayerCallback();
							return false;
							break;
					}
					return true;
				}

				/**
				 * ページ表示完了時に呼ばれるイベント
				 */
				window.onload = function(){
					//設定されている値の取得
					LoadSelection();
				}

				/**
				 * 現在設定されている値を取得する
				 */
				function LoadSelection(){
					//引数の取得
					var value = '<?=(isset($_GET['value']) ? $_GET['value'] : '');?>';

					//引数が無い場合
					if(value == '' || value == KANKO_LINK_DELIMITER) return false;

					//値の取得
					var value_ary = value.split(KANKO_LINK_DELIMITER);
					var url = value_ary[0];
					var title = value_ary[1];
					var width = value_ary[2];
					var height = value_ary[3];

					//値の設定
					//タイトル
					if(title != '') $('youtube_title').value = title;
					//URL
					if(url != ''){
						//URLの取得
						var url_tmp = url.substring(0,url.lastIndexOf('?'));
						//設定値の取得
						var get_ary = url.substring(url.lastIndexOf('?')).split('&');
						//GET数分ループ
						for(var i = 0;i < get_ary.length;i++){
							//キーと値を分割
							ary = get_ary[i].split('=');
							//配列にキーが存在する場合
							if(option_ary[ary[0]]){
								//設定が1（TRUE）の場合は設定する
								if(ary[1] == 1) $('youtube_op_' + ary[0]).checked = true;
							}
							//配列にキーが存在しない場合は、URLへ戻す
							else url_tmp += (get_ary[i].match(/^(https?:)?\/\//i) || get_ary[i].substr(0,1).match(/(&|\?)/) ? '' : '&') + get_ary[i];
						}
						//URLを取得
						$('youtube_url').value = url_tmp;
					}
					//横幅
					if(width != '') $('youtube_width').value = width;
					//高さ
					if(height != '') $('youtube_height').value = height;
				}

				/**
				 * 決定ボタンが押された際の処理
				 * @return false
				 */
				function cxSubmit_Property(){
					//値のチェック
					var errMsg = '';
					//タイトル
					if(!$F('youtube_title') || $F('youtube_title') == '') errMsg = 'タイトルが入力されていません。';
					//URL
					else if(!$F('youtube_url') || $F('youtube_url') == '') errMsg = 'URLが入力されていません。';
					else if($F('youtube_url').match(/^(https?)(:\/\/[-_.!~*\'\(\)a-zA-Z0-9;\/?:\@&=+\$,%#]+)$/i) == null) errMsg = 'URLとして認められないURLが指定されています。';
					else if(!in_array($F('youtube_url').match(/^https?:\/\/[^\/]*?(\/|$)/i)[0],("<?=implode(',', $YOUTUBE_PATTERN_ARY);?>").split(','))) errMsg = 'YouTube以外のURLが指定されています。';
					//横幅
					else if($F('youtube_width') != "" && $F('youtube_width') <= 0) errMsg = '横幅に0以下が入力されています。';
					else if($F('youtube_width') != "" && !$F('youtube_width').match(/^[0-9]*$/)) errMsg = '横幅に数字以外が入力されています。';
					//高さ
					else if($F('youtube_height') != "" && $F('youtube_height') <= 0) errMsg = '高さに0以下が入力されています。';
					else if($F('youtube_height') != "" && !$F('youtube_height').match(/^[0-9]*$/)) errMsg = '高さに数字以外が入力されています。';

					//エラーが存在する場合
					if(errMsg != ''){
						alert(errMsg);
						return false;
					}

					//パラメータの作成
					var paramStr = '';
					for(var key in option_ary){
						if(!$('youtube_op_' + key)) continue;
						paramStr += '&' + key + '=' + ($('youtube_op_' + key).checked ? '1' : '0');
					}
					//親画面に値を渡す
					retObj = {
						ret	:	$F('youtube_url') + paramStr + KANKO_LINK_DELIMITER + 
								$F('youtube_title') + KANKO_LINK_DELIMITER + 
								$F('youtube_width') + KANKO_LINK_DELIMITER + 
								$F('youtube_height')
					};

					//クローズ
					cxIframeLayerCallback(retObj);
				}

				<?php
				echo loadSettingVars();
				?>
			//-->
		</script>
</head>
<body>
<div class="cke_dialog_title">YouTube設定<img style="float: right; cursor: pointer;" onclick="cxIframeLayerCallback();return false;" src="<?=RPW?>/ckeditor/skins/moono-lisa/images/close.png" alt="閉じる"></div>
<div id="cms8341-headareaZero" style="margin-bottom: 0px !important">
<table width="100%" height="380px" border="0" cellspacing="0"
	cellpadding="0">
	<tr>
		<td width="100%" height="100%" align="center" valign="top">
		<div id="divProperty" style="height: 97%; background-color: #FFFFFF;">
		<form>
		<table cellspacing="0px"
			style="margin: 10px 20px; text-align: left;"
			class="cms8341-dataTable">
			<tr>
				<th width="15%"
					style="font-size: 12px; padding: 5px; margin: 0px; "><span class="cke_dialog_ui_labeled_label" >タイトル</span></th>
				<td width="85%"
					style="padding: 5px; margin: 0px; "><input
					type="text" class="cke_dialog_ui_input_text" id="youtube_title" name="youtube_title" value=""
					></td>
			</tr>
			<tr>
			<th
					style="font-size: 12px; padding: 5px; margin: 0px; "><span class="cke_dialog_ui_labeled_label" >URL</span></th>
				<td
					style="padding: 5px; margin: 0px; "><input
					type="text" class="cke_dialog_ui_input_text" id="youtube_url" name="youtube_url" value=""
					style="width: 230px; margin-right: 10px;"><a style="margin-top: -2px; "
					href="<?=YOUTUBE_DEFAULT_URL?>" class="cke_dialog_ui_button" target="_blank">YouTubeへ</a></td>
			</tr>
			<tr>
				<th
					style="font-size: 12px; padding: 5px; margin: 0px; "><span class="cke_dialog_ui_labeled_label" >横幅</span></th>
				<td
					style="padding: 5px; margin: 0px;"><input
					type="text" class="cke_dialog_ui_input_text" id="youtube_width" name="youtube_width"
					value="<?=YOUTUBE_WIDTH?>" style="width: 200px;"></td>
			</tr>
			<tr>
				<th
					style="font-size: 12px; padding: 5px; margin: 0px; "><span class="cke_dialog_ui_labeled_label" >高さ</span></th>
				<td
					style="padding: 5px; margin: 0px;"><input
					type="text" class="cke_dialog_ui_input_text" id="youtube_height" name="youtube_height"
					value="<?=YOUTUBE_HEIGHT?>" style="width: 200px;"></td>
			</tr>
			<tr>
				<th
					style="font-size: 12px; padding: 5px; margin: 0px; "><span class="cke_dialog_ui_labeled_label" ></span></th>
				<td >
			<fieldset>
			<legend>オプション</legend>
				<?php
				foreach ($YOUTUBE_OPTION_ARY as $option_name => $option_value) {
					print('<p style="margin:0px;margin-top:5px;"><input type="checkbox" id="youtube_op_' . $option_name . '" name="youtube_op_' . $option_name . '" value="1"' . ($option_value['defult'] == 1 ? ' checked' : '') . '><label for="youtube_op_' . $option_name . '">' . $option_value['name'] . '</label></p>');
				}
				?>
				</fieldset>
				</td>
			</tr>
		</table>
		<p align="center" style="margin-top: 30px;"><span
			style="margin-right: 20px;"><a class="cke_dialog_ui_button cke_dialog_ui_button_grey" href="javascript:void(0)"
			onclick="cxSubmit_Property();return false;">設定する</a></span> <span
			style="margin-left: 20px;"><a href="javascript:void(0)"
			onclick="cxIframeLayerCallback();return false;" class="cke_dialog_ui_button">キャンセル</a></span></p>
		</form>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
</body>
</html>
