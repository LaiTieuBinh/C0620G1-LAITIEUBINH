<?php
/*
 * リンクの設定を行う
 */
//設定ファイル読み込み
require_once("./.htsetting");

//エラー画面設定 別ウィンドウ用
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

require_once(APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$dacTools = new dac_tools($objCnc);
if (!isset($_SESSION['use_template_id']) || $dacTools->selectTemplate($_SESSION['use_template_id']) === FALSE) user_error("テンプレート情報の取得に失敗しました。", E_USER_ERROR);
$acc_flg = $dacTools->fld['acc_flg'];

if (isset($_GET['value'])) {
	$value = str_replace("＃", "#", $_GET['value']);
	// オープンデータ
	// typeを保存
	$fixed_item_type = $_GET['type'];
	switch ($_GET['type']) {
		//リンク
		case "link" :
		//メール
		case "mail" :
			$values = explode(KANKO_LINK_DELIMITER, $value);
			if (isset($values[0])) $href = htmlDisplay($values[0], "nonspace");
			if (isset($values[1])) $text = $values[1];
			if (isset($values[2])) $target = $values[2];
		//ファイル
		case "file" :
			$values = explode(KANKO_LINK_DELIMITER, $value);
			if (isset($values[0])) $href = htmlDisplay($values[0], "nonspace,nonconvert_amp");
			if (isset($values[1])) $text = $values[1];
			if (isset($values[2])) $target = $values[2];
			if (isset($values[3])) $file_ext = $values[3];
			if (isset($values[4])) $file_size = $values[4];
			$filename = $href;
		// オープンデータ
		case "opendata" :
			$values = explode(KANKO_LINK_DELIMITER, $value);
			if (isset($values[0])) $href = htmlDisplay($values[0], "nonspace");
			if (isset($values[1])) $text = $values[1];
			if (isset($values[2])) $target = $values[2];
			if (isset($values[3])) $file_ext = $values[3];
			if (isset($values[4])) $file_size = $values[4];
			if (isset($values[5])) $od_category = $values[5];
			if (isset($values[6])) $od_keywords = $values[6];
			if (isset($values[7])) $od_license = $values[7];
			if (isset($values[8])) $od_pssy = $values[8];
			if (isset($values[9])) $od_pssm = $values[9];
			if (isset($values[10])) $od_pssd = $values[10];
			if (isset($values[11])) $od_ptsy = $values[11];
			if (isset($values[12])) $od_ptsm = $values[12];
			if (isset($values[13])) $od_ptsd = $values[13];
			if (isset($values[14])) {
				// 改行を一時的に置換して保存する(link.js内で復元)
				$od_summary = preg_replace('/\n|\r|\r\n/', '{OD_RETURN}', $values[14] );
			}
			if (isset($values[15])) $od_od_data_type = $values[15];
			$filename = $href;
	}
}

// オープンデータ
// オープンデータカテゴリ
$OPENDATA_CATEGORY = getOpenDataCategory();
// オープンデータライセンス
$OPENDATA_LICENSE = getDefineArray("OPENDATA_LICENSE");
// ライセンスのセレクトボックス作成用に配列を作成
$lisence_ary = array();
foreach ($OPENDATA_LICENSE as $key => $value) {
	$lisence_ary[$key] = $value['name'];
}
// オープンデータデータタイプ
$OD_DATA_TYPE = getDefineArray("OD_DATA_TYPE");

// オープンデータのカテゴリチェックボックスを作成
$mk_category_ary = array();
$open_data_cate = '';
foreach ((array) $OPENDATA_CATEGORY as $category_id => $category_name) {
	$mk_category_ary[$category_id] = $category_name;
}
if (count($mk_category_ary) >= 0) {
	$select_ary = array();
	$open_data_cate .= mkcheckbox($mk_category_ary, 'opendata_category', $select_ary, 1);
}
// オープンデータのライセンスリストを作成
$open_data_license = create_list("opendata_license", $lisence_ary, OPENDATA_DATA_LICENSE_DEFAULT, 200, 0);

// オープンデータのデータタイプリストを作成
$open_data_od_data_type = create_list("od_data_type", $OD_DATA_TYPE, '',200, 0);

/*----------------------------------------------------------
 * プルダウン作成
 * param : $name - 付与するnameの値
 * param : $ary - プルダウン要素を格納した配列
 * param : $select - 初期選択させる要素
 * param : $select - サイズ
 * param : $nasi - 先頭に「指定なし」の表示を行うか
 * return : none
 *----------------------------------------------------------*/
function create_list($name, $ary, $select, $width, $nasi = '0') {
	$liststr = '<select id="' . $name . '" name="' . $name . '" style="width:' . $width . 'px;">' . "\n";
	if ($nasi == 0) {
		$liststr .= '<option value="">指定なし</option>' . "\n";
	}
	foreach ($ary as $key => $listary) {
		$selected = ($key == $select) ? ' selected' : '';
		$liststr .= '<option value="' . $key . '"' . $selected . '>' . htmlDisplay($listary) . '</option>' . "\n";
	}
	$liststr .= '</select>' . "\n";
	return $liststr;
}

// オープンデータデータタイプ
$dialog_style = '';
if($_GET['type'] == 'opendata') {
	$dialog_style = 'overflow-y:scroll; padding:0; height:520px';
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta name="robots" content="noindex, nofollow"/>
	<meta http-equiv="Content-Style-Type" content="text/css">
	<meta http-equiv="Content-Script-Type" content="text/javascript">
	<title>リンク設定</title>
	<base target="_self">
	<link href="<?=RPW?>/admin/style/normalize.css" type="text/css" rel="stylesheet">
	<link href="<?=RPW?>/ckeditor/gd_files/css/grid.css" type="text/css" rel="stylesheet">
	<link href="<?=RPW?>/ckeditor/gd_files/css/dialog.css" type="text/css" rel="stylesheet">
	<script src="<?= RPW ?>/admin/js/library/prototype.js" type="text/javascript"></script>
	<script src="<?= RPW ?>/admin/js/shared.js" type="text/javascript"></script>
	<!-- オープンデータ -->
	<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
	<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
	<script type="text/javascript">
		<!--
			<?php
			echo loadSettingVars();
			?>
			var acc_flg = <?=$acc_flg?>;
			var GET = new Object();
			GET["id"] = '<?php
			print((isset($_GET["id"]) ? javaStringEscape($_GET["id"]) : ""));
			?>';
			GET["href"] = '<?php
			print((isset($href) ? javaStringEscape($href) : ""));
			?>';
			GET["text"] = '<?php
			print((isset($text) ? javaStringEscape($text) : ""));
			?>';
			GET["target"] = '<?php
			print((isset($target) ? javaStringEscape($target) : ""));
			?>';
			<?php
			// オープンデータ
			// 定型typeオープンデータ js参照用にオープンデータ関連の情報を保存 
			if (isset($fixed_item_type) && $fixed_item_type == 'opendata') {
			?>
				GET["type"] = '<?php
				print(javaStringEscape($fixed_item_type));
				?>';
				GET["od_category"] = '<?php
				print((isset($od_category) ? javaStringEscape($od_category) : ''));
				?>';
				GET["od_keywords"] = '<?php
				print((isset($od_keywords) ? javaStringEscape($od_keywords) : ''));
				?>';
				GET["od_license"] = '<?php
				print((isset($od_license) ? javaStringEscape($od_license) : ''));
				?>';
				GET["od_pssy"] = '<?php
				print((isset($od_pssy) ? javaStringEscape($od_pssy) : ''));
				?>';
				GET["od_pssm"] = '<?php
				print((isset($od_pssm) ? javaStringEscape($od_pssm) : ''));
				?>';
				GET["od_pssd"] = '<?php
				print((isset($od_pssd) ? javaStringEscape($od_pssd) : ''));
				?>';
				GET["od_ptsy"] = '<?php
				print((isset($od_ptsy) ? javaStringEscape($od_ptsy) : ''));
				?>';
				GET["od_ptsm"] = '<?php
				print((isset($od_ptsm) ? javaStringEscape($od_ptsm) : ''));
				?>';
				GET["od_ptsd"] = '<?php
				print((isset($od_ptsd) ? javaStringEscape($od_ptsd) : ''));
				?>';
				GET["od_summary"] = "<?php
				print((isset($od_summary) ? javaStringEscape($od_summary) : ''));
				?>";
				GET["od_od_data_type"] = '<?php
				print((isset($od_od_data_type) ? javaStringEscape($od_od_data_type) : ''));
				?>';
			<?php
			}
			?>
			
		//-->
	</script>
	<script
			src="<?= RPW ?>/ckeditor/gd_files/js/dialog_common.js"
			type="text/javascript"></script>
	<script src="<?= RPW ?>/admin/page/common/kanko/js/link.js"
			type="text/javascript"></script>
</head>

<body class="cke_reset_all">
<div class="cke_dialog_title">リンク設定<img style="float: right; cursor: pointer;" onclick="cxIframeLayerCallback();return false;" src="<?=RPW?>/ckeditor/skins/moono-lisa/images/close.png" alt="閉じる"></div>
<div class="dialog_body" style='<?php echo $dialog_style; ?>'>
	<div class="lay360">
		<div class="size8">
			<fieldset>
				<legend><label class="cke_dialog_ui_labeled_label">リンクタイプ</label></legend>
				<?php
				if ($_GET['type'] == 'mail') {
					print('<input type="radio" name="chkLinkType" id="chkLinkType_Email" value="email" onclick="SetLinkType(this.value);" checked><label for="chkLinkType_Email"><span class="cke_dialog_ui_labeled_label" >メール</span></label><br />');
					print('<span style="display:none;"><input type="radio" name="chkLinkType" id="chkLinkType_InUrl" value="inurl" onclick="SetLinkType(this.value);"><label for="chkLinkType_InUrl"><span class="cke_dialog_ui_labeled_label" >サイト内ページ</span></label><br /></span>');
					print('<span style="display:none;"><input type="radio" name="chkLinkType" id="chkLinkType_Url" value="url" onclick="SetLinkType(this.value);"><label for="chkLinkType_Url"><span class="cke_dialog_ui_labeled_label" >外部ページ</span></label><br /></span>');
					print('<span style="display:none;"><input type="radio" name="chkLinkType" id="chkLinkType_File" value="file" onclick="SetLinkType(this.value);"><label for="chkLinkType_File"><span class="cke_dialog_ui_labeled_label" >ファイル</span></label><br /></span>');
					print('<span style="display:none;"><input type="radio" name="chkLinkType" id="chkLinkType_OpData" value="opendata" onclick="SetLinkType(this.value);"><label for="chkLinkType_OpData"><span style="font-size:12px;">ファイル(オープンデータ)</span></label><br /></span>');
				} 
				// オープンデータ
				else if($_GET['type'] == 'opendata') {
					print('<input type="radio" name="chkLinkType" id="chkLinkType_OpData" value="opendata" onclick="SetLinkType(this.value);" checked><label for="chkLinkType_OpData"><span style="font-size:12px;">ファイル(オープンデータ)</span></label><br />');
					print('<span style="display:none;"><input type="radio" name="chkLinkType" id="chkLinkType_Email" value="email" onclick="SetLinkType(this.value);"><label for="chkLinkType_Email"><span style="font-size:12px;">メール</span></label><br /></span>');
					print('<span style="display:none;"><input type="radio" name="chkLinkType" id="chkLinkType_InUrl" value="inurl" onclick="SetLinkType(this.value);"><label for="chkLinkType_InUrl"><span style="font-size:12px;">サイト内ページ</span></label><br /></span>');
					print('<span style="display:none;"><input type="radio" name="chkLinkType" id="chkLinkType_Url" value="url" onclick="SetLinkType(this.value);"><label for="chkLinkType_Url"><span style="font-size:12px;">外部ページ</span></label><br /></span>');
					print('<span style="display:none;"><input type="radio" name="chkLinkType" id="chkLinkType_File" value="file" onclick="SetLinkType(this.value);"><label for="chkLinkType_File"><span style="font-size:12px;">ファイル</span></label><br /></span>');
				}
				else {
					print('<input type="radio" name="chkLinkType" id="chkLinkType_InUrl" value="inurl" onclick="SetLinkType(this.value);" checked><label for="chkLinkType_InUrl"><span style="font-size:12px;">サイト内ページ</span></label><br />');
					print('<input type="radio" name="chkLinkType" id="chkLinkType_Url" value="url" onclick="SetLinkType(this.value);"><label for="chkLinkType_Url"><span style="font-size:12px;">外部ページ</span></label><br />');
					print('<input type="radio" name="chkLinkType" id="chkLinkType_File" value="file" onclick="SetLinkType(this.value);"><label for="chkLinkType_File"><span style="font-size:12px;">ファイル</span></label><br />');
					print('<span style="display:none;"><input type="radio" name="chkLinkType" id="chkLinkType_Email" value="email" onclick="SetLinkType(this.value);"><label for="chkLinkType_Email"><span style="font-size:12px;">メール</span></label><br /></span>');
					print('<span style="display:none;"><input type="radio" name="chkLinkType" id="chkLinkType_OpData" value="opendata" onclick="SetLinkType(this.value);"><label for="chkLinkType_OpData"><span style="font-size:12px;">ファイル(オープンデータ)</span></label><br /></span>');
				}
				?>
			</fieldset>
		</div>
	</div>


	<div class="lay360">
		<div class="size8">
			<div id="divLinkTypeInUrl_txt_name"><span class="cke_dialog_ui_labeled_label">リンクタイトル</span></div>
			<div id="divLinkTypeUrl_txt_name"><span class="cke_dialog_ui_labeled_label">リンクタイトル</span></div>
			<div id="divLinkTypeEMail_txt_name"><span class="cke_dialog_ui_labeled_label">リンクタイトル</span></div>
			<div id="divLinkTypeFile_txt_name"><span class="cke_dialog_ui_labeled_label">リンクタイトル</span></div>
		</div>
	</div>

	<div class="lay360">
		<div class="size8">
			<div id="divLinkTypeInUrl_txt"><input id="txtInUrl_txt" class="cke_dialog_ui_input_text" type="text" /></div>
			<div id="divLinkTypeUrl_txt"><input id="txtUrl_txt" class="cke_dialog_ui_input_text" type="text" /></div>
			<div id="divLinkTypeEMail_txt"><input id="txtEMailAddress_txt" class="cke_dialog_ui_input_text" type="text" /></div>
			<div id="divLinkTypeFile_txt"><input id="txtFile_txt" class="cke_dialog_ui_input_text" type="text" /></div>
		</div>
	</div>

	<div class="lay360">
		<div class="size8">
			<div id="divLinkTypeInUrl_name"><span class="cke_dialog_ui_labeled_label">リンクURL</span></div>
			<div id="divLinkTypeUrl_name"><span class="cke_dialog_ui_labeled_label">リンクURL</span></div>
			<div id="divLinkTypeEMail_name"><span class="cke_dialog_ui_labeled_label">メールアドレス</span></div>
			<div id="divLinkTypeFile_name"><span class="cke_dialog_ui_labeled_label">ファイルパス</span></div>
		</div>
	</div>

	<div id="divLinkTypeInUrl" class="lay360">
		<div class="size8">
			<input id="txtInUrl" class="cke_dialog_ui_input_text" type="text"/>

			<div id="mode_set_normal_InUrl">
				<?php if (FCK_LINK_OTHER_WINDOW) { ?>
					<input type="checkbox" id="setBlank_InUrl"><label for="setBlank_InUrl"><span class="cke_dialog_ui_labeled_label">別ウィンドウで開く</span></label>
					<?php
				}
				?>
			</div>
			<div id="mode_set_mobile_InUrl" style="display: none"><span class="cke_dialog_ui_labeled_label">アクセスキー：</span><input
						type="text" id="setAccessKey_InUrl" class="cke_dialog_ui_input_text" maxlength="1" size="4" style="ime-mode: disabled"
						onkeypress="IsDigit(event)"/></div>
		</div>
	</div>

	<div id="divLinkTypeUrl" class="lay360">
		<div class="size2">
			<select id="cmbLinkProtocol" class="cke_dialog_ui_input_select" style="width: 89px;">
				<option value="http://" selected="selected">http://</option>
				<option value="https://">https://</option>
				<option value="">その他</option>
			</select>
		</div>

		<div class="size6">
			<input id="txtUrl" type="text" class="cke_dialog_ui_input_text" onkeyup="OnUrlChange();" onchange="OnUrlChange();"/>
		</div>
		<div class="size8">	
			<div id="mode_set_normal_Url">
			<?php
			if (FCK_LINK_OTHER_WINDOW) {
				?>
				<input type="checkbox" id="setBlank_Url"><label for="setBlank_Url"><span class="cke_dialog_ui_labeled_label">別ウィンドウで開く</span></label>
				<?php
			}
			?>
	</div>
			<div id="mode_set_mobile_Url" style="display: none"><span  class="cke_dialog_ui_labeled_label">アクセスキー：</span>
				<input type="text" id="setAccessKey_Url" class="cke_dialog_ui_input_text" maxlength="1" size="4" style="ime-mode: disabled" onkeypress="IsDigit(event)" />
			</div>
		</div>
	</div>

	<div id="divLinkTypeEMail" class="lay360">
		<div class="size8">
		<input id="txtEMailAddress" class="cke_dialog_ui_input_text" type="text"/>
	</div>
	</div>

	<div id="divLinkTypeFile" class="lay360">
		<div class="size8">
		<input id="txtFile" class="cke_dialog_ui_input_text" type="text"/>
		<div id="mode_set_normal_File">
			<?php
			if (FCK_LINK_OTHER_WINDOW) {
				?>
				<input type="checkbox" id="setBlank_File"><label for="setBlank_File"><span
							class="cke_dialog_ui_labeled_label">別ウィンドウで開く</span></label>
				<?php
			}
			?>
		</div>
			<div id="mode_set_mobile_File" style="display: none"><span  class="cke_dialog_ui_labeled_label">アクセスキー：</span>
				<input type="text" class="cke_dialog_ui_input_text" id="setAccessKey_File" maxlength="1" size="4" style="ime-mode: disabled" onkeypress="IsDigit(event)" />
			</div>
		</div>
	</div>

	<div class="lay360">
		<fieldset style="width: 315px; margin-left: 10px;">
			<legend><span class="cke_dialog_ui_labeled_label">リンク先詳細</span></legend>
			<div class="pre1 size5 suf1">
				<div style="margin-left: 30px;">
					<div id="divSiteLink"><a id="aSiteLink" class="cke_dialog_ui_button" href="javascript:void(0)"
											 onclick="showModal(1);">サイト内リンク設定</a></div>
					<div id="divFileLink"><a id="aFileLink" class="cke_dialog_ui_button" href="javascript:void(0)"
											 onclick="showModal(2);">ファイルリンク設定</a></div>
				</div>
			</div>
		</fieldset>
	</div>

	<!-- オープンデータ -->
	<div id="divLinkTypeOpData" class="lay360" style="display: none;">
		<fieldset>
		<legend><span class="cke_dialog_ui_labeled_label">オープンデータリンク先詳細</span></legend>
		
		<span class="cke_dialog_ui_labeled_label">概要<span class='cms_require'>（必須）</span></span></span>
		<p><textarea id="opendata_summary" name="cke_dialog_ui_input_textarea" cols="37" rows="5"></textarea></p>
		<span class="cke_dialog_ui_labeled_label">ライセンス<a target='_blank' href='/cms8341/shared/system/opendata/license.html'>（説明）</a><span class='cms_require'>（必須）</span></span></span>
		<p><?=$open_data_license?></p>
		
		<span class="cke_dialog_ui_labeled_label">データ時点<span class='cms_require'>（必須）</span></span></span>
		<p>
			<input type="text" maxlength="4" id="ptsy" name="ptsy" value=""
				style="width: 50px; ime-mode: disabled"> <span class="cke_dialog_ui_labeled_label">年</span> <input type="text"
				maxlength="2" id="ptsm" name="ptsm" value=""
				style="width: 30px; ime-mode: disabled"> <span class="cke_dialog_ui_labeled_label">月</span> <input type="text"
				maxlength="2" id="ptsd" name="ptsd" value=""
				style="width: 30px; ime-mode: disabled"> <span class="cke_dialog_ui_labeled_label">日</span> <a
				href="javascript:"
				onClick="return cxCalendarOpen('pt','start')"><img
				src="/cms8341/admin/images/icon/icon_calendar.jpg"
				alt="カレンダーで設定する" width="14" height="17" border="0"
				align="absmiddle"></a>
		</p>
		
		<span class="cke_dialog_ui_labeled_label">掲載日<span class='cms_require'>（必須）</span></span>
		<p>
			<input type="text" maxlength="4" id="pssy" name="pssy" value=""
				style="width: 50px; ime-mode: disabled"> <span class="cke_dialog_ui_labeled_label">年</span> <input type="text"
				maxlength="2" id="pssm" name="pssm" value=""
				style="width: 30px; ime-mode: disabled"> <span class="cke_dialog_ui_labeled_label">月</span> <input type="text"
				maxlength="2" id="pssd" name="pssd" value=""
				style="width: 30px; ime-mode: disabled"> <span class="cke_dialog_ui_labeled_label">日</span> <a
				href="javascript:"
				onClick="return cxCalendarOpen('ps','start')"><img
				src="/cms8341/admin/images/icon/icon_calendar.jpg"
				alt="カレンダーで設定する" width="14" height="17" border="0"
				align="absmiddle"></a>
		</p>
		
		<span class="cke_dialog_ui_labeled_label">カテゴリ<span class='cms_require'>（必須）</span></span>
		<p><?=$open_data_cate?></p>
		<span class="cke_dialog_ui_labeled_label">データタイプ<a target='_blank' href='/cms8341/shared/system/opendata/datatype.html'>（説明）</a><span class='cms_require'>（必須）</span></span>
		<p><?=$open_data_od_data_type?></p>
		<span class="cke_dialog_ui_labeled_label">キーワード検索タグ</span>
		<input type="text" name="opendata_keywords"
			id="opendata_keywords" style="width: 99%;" value=""><span class="cke_dialog_ui_labeled_label" 
			style="font-size: 11px;">※複数ある場合はコンマ(,)で区切って下さい</span>
		</br>
		</fieldset>
	</div>
	
	<div class="lay360">
		<div class="pre3 size2 suf2">
			<a href="javascript:void(0)" class="cke_dialog_ui_button cke_dialog_ui_button_padding cke_dialog_ui_button_grey"
			onClick="window.Ok(); return false;">完了</a>
		</div>
	</div>
	<?php
	print($dacTools->setAccessibility());
	?>
	<!-- オープンデータ -->
	<!--***カレンダーレイヤー ここから********************************-->
	<div id="cms8341-calendar" class="cms8341-layer">
	<table width="430" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="430" align="center" valign="top" bgcolor="#DFDFDF" style="border: solid 1px #343434;">
			<table width="430" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader">
				<tr>
					<td align="left" valign="middle">
						<img src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー" width="200" height="20" style="margin: 4px 10px;">
					</td>
					<td width="78" align="right" valign="middle">
						<a href="javascript:" onClick="return cxCalendarClose()">
						<img src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58" height="19" border="0" style="margin: 4px 10px;">
						</a>
					</td>
				</tr>
			</table>
			<div style="width: 100%; margin-top: 10px">
				<div id="cms8341-calbody" style="width: 420px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 5px; padding: 5px;">
				</div>
			</div>
			</td>
		</tr>
	</table>
	</div>
	<!--***カレンダーレイヤー ここまで********************************-->
</div>
</body>
</html>
