<?php
/*
 * 削除依頼
 */
require ("../.htsetting");

// ページIDが渡されなければエラー
if (!isset($_POST['cms_page_id'])) {
	user_error("It isn't setted cms_page_id in _post.", E_USER_ERROR);
}
$PID = $_POST['cms_page_id'];

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInq = new tbl_inquiry($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
$objKanko = new tbl_kanko($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output_handler.inc');
$objOpHndl = new tbl_output_handler($objCnc);
// イベントカレンダー複数日
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_event.inc');
$obj_event = new tbl_event($objCnc);
// オープンデータ
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_open_data.inc');
$obj_open_data = new tbl_open_data($objCnc);

// 公開ページ情報の取得
if ($objPage->selectFromID($PID, 1, 'work_class, status, inquiry_id') === FALSE) {
	user_error("dac execute error. <br>tbl_page->selectFromID(" . $PID . ", 1);", E_USER_ERROR);
}
$work_class = $objPage->fld['work_class'];
$bak_status = $objPage->fld['status'];
// 新規作成ページおよび公開待ち状態になっていないページは削除できない
if ($work_class != 2 || $bak_status < 401) {
	user_error("このページは削除できません。");
}

$objCnc->begin();

// work_pageに情報をコピー
$ary = array();
$ary['page_id'] = $PID;
$ary['work_class'] = 3;
// ウェブマスターの場合は公開待ち状態、作成者の場合は完了状態にする
$ary['status'] = ($objLogin->get('class') == USER_CLASS_WEBMASTER) ? 401 : 202;
// 公開済みだったページ
if ($bak_status == 402) {
	$ary['bak_status'] = 402;
	// 公開ページ情報の更新（UPDATE tbl_publish_page）
	if ($objPage->update($ary, 1) === FALSE) {
		$objCnc->rollback();
		user_error("公開ページ情報の更新に失敗しました。");
	}
	// 編集ページ情報の登録（INSERT INT tbl_work_page SELECT FROM tbl_publish_page）
	if ($objPage->insertWorkFromPublish($PID, $objLogin->login) === FALSE) {
		$objCnc->rollback();
		user_error("編集ページ情報の登録に失敗しました。");
	}
	if ($objInq->insertWorkFromPublish($objPage->fld['inquiry_id']) === FALSE) {
		$objCnc->rollback();
		user_error("編集問い合わせ情報の登録に失敗しました。");
	}
	if ($objKanko->insertWorkFromPublish($PID) === FALSE) {
		$objCnc->rollback();
		user_error("編集定型情報の登録に失敗しました。");
	}
	// イベントカレンダー複数日
	if (EVENT_CAL_MULTI_FLAG) {
		// イベント開催期間情報登録
		if ($obj_event->insertWorkFromPublish($PID) === FALSE) {
			user_error('開催期間の登録に失敗しました。');
		}
	}
	// 外部連携データ設定の登録
	if (ENABLE_OPTION_OUTPUT) {
		if ($objOpHndl->insertWorkFromPublish($PID) === FALSE) {
			$objCnc->rollback();
			user_error("外部連携データ設定の登録に失敗しました。");
		}
	}
	// オープンデータ
	if ($obj_open_data->insertWorkFromPublish($PID) === FALSE) {
		return FALSE;
	}
	// 編集ページ情報の更新（UPDATE tbl_work_page）
	unset($ary['bak_status']);
	$ary['close_flg'] = 0;
	if ($objPage->update($ary, 2) === FALSE) {
		$objCnc->rollback();
		user_error("編集ページ情報の更新に失敗しました。");
	}
	// 公開待ちだったページ
}
else {
	// 公開ページ情報の更新（UPDATE tbl_publish_page）
	if ($objPage->update($ary, 1) === FALSE) {
		$objCnc->rollback();
		user_error("公開ページ情報の更新に失敗しました。");
	}
	// 編集ページ情報の更新（UPDATE tbl_work_page）
	$ary['close_flg'] = 0;
	if ($objPage->update($ary, 2) === FALSE) {
		$objCnc->rollback();
		user_error("編集ページ情報の更新に失敗しました。");
	}
}

$objCnc->commit();

// ウェブマスターはワークフローへ移動
if ($objLogin->get('class') == USER_CLASS_WEBMASTER || $objLogin->get('isRegain') == TRUE) {
	header("Location: " . HTTP_ROOT . RPW . "/admin/page/workflow/workflow.php");
	// 作成者はワークスペースへ移動
}
else {
	header("Location: " . HTTP_ROOT . RPW . "/admin/page/workspace/workspace.php");
}
?>