<?php
/*
 * FCKエディタの中にあるリンクにファイルがある場合、ファイルの形式とサイズを追記する
 */
//外部ファイル読み込み
require ("../.htsetting");

//変数の宣言
$post = $_POST;

//ファイルパスの変換処理
if (isset($post['cms_context'])) $post['cms_context'] = FilePathConversion(del_escapes($post['cms_context']));
//ファイル情報の保持
$_SESSION['conv_fp'] = $post;
//編集画面に戻る
header("Location: " . HTTP_ROOT . RPW . $post['cms_p_file_path'] . "?edit=1&conv_fp=1");

/**
 * DBに登録されているファイルパスに変換する。
 * @param $cms_context　FCKeditorの中に記入されている文字列
 * @return 追記後の文字列
 */
function FilePathConversion($cms_context) {
	//DB
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/b_dac.inc');
	$objDac = new b_dac($objCnc, "tbl_conversion_path");
	$ret = array();
	$p = 0;
	while (preg_match('/<(a|area)( [^>]*)? href="([^"]*)"[^>]*>/i', $cms_context, $ret, PREG_OFFSET_CAPTURE, $p)) {
		$str = $ret[0][0];
		$src = $ret[3][0];
		$src = preg_replace('/(#|\?).*/i', '', $src);
		$src = str_replace('%20', ' ', $src);
		$p = $ret[0][1] + strlen($ret[0][0]);
		$objDac->add_where('`before`', str_replace(RPW, '', $src));
		$objDac->select();
		if (!$objDac->fetch()) continue;
		$after_path = $objDac->fld['after'];
		$str = str_replace(str_replace(' ', '%20', $src), $after_path, $str);
		$p = $ret[0][1] + strlen($str);
		$cms_context = str_replace($ret[0][0], $str, $cms_context);
	}
	return $cms_context;
}
?>
