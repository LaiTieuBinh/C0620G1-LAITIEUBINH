<?php
/*
 * 新規ページ作成画面
 */
require ("../.htsetting");

// 親ページID（cms_page_id）が渡されなければエラー(空白が渡されることはある)
if (!isset($_POST['cms_page_id'])) {
	user_error("It isn't setted cms_page_id in _post.", E_USER_ERROR);
}

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_auto_link.inc');
$objAutoLink = new tbl_auto_link($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInquiry = new tbl_inquiry($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFaq = new tbl_faq($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
// イベントカレンダー複数日
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_event.inc');
$obj_event = new tbl_event($objCnc);

// 大規模災害状態
$disaster_flg = (isDisasterFlg() ? FLAG_ON : FLAG_OFF);

$PID = $_POST['cms_page_id'];
$tbl_name = WORK_TABLE;
// 複写の場合は自分のページ情報を取得
if ($_POST['cms_dispMode'] == 'copy' || $_POST['cms_dispMode'] == 'disaster') {
	// 自分の公開情報を取得
	$where = "tbl_work_page.page_id = '" . $PID . "' and tbl_work_page.page_id = tbl_publish_page.page_id";
	$field = "tbl_work_page.*,ancestor_path";
	$objPage->setTableName("tbl_work_page, tbl_publish_page");
	$objPage->select($where, $field);
	// 編集情報にない場合は公開情報から取得する。
	if ($objPage->getRowCount() == 0) {
		$where = "page_id = '" . $PID . "'";
		$objPage->setTableName("tbl_publish_page");
		$objPage->select($where);
		if ($objPage->getRowCount() == 0) {
			user_error("dac execute error. <br>tbl_page->select(" . $PID . ", 1);", E_USER_ERROR);
		}
		$tbl_name = PUBLISH_TABLE;
	}
	$objPage->fetch();
	$pub_fld = $objPage->fld;
	$PID = $pub_fld['parent_id'];
	// 複写時は複写元の保存先ディレクトリを保持
	$copy_dir_path = cms_dirname($pub_fld['file_path']);
	$copy_dir_path .= (substr($copy_dir_path, -1) != "/" ? "/" : "");
}
else {
	// 親ページの公開情報を取得
	if ($objPage->selectFromID($PID, 1) === FALSE) {
		user_error("dac execute error. <br>tbl_page->selectFromID(" . $PID . ", 1);", E_USER_ERROR);
	}
	$pub_fld = $objPage->fld;
}

// 緊急情報　エラーチェック
if ($_POST['cms_dispMode'] == 'disaster') {
	$error_msg = "";
	if (!isCreateDisasterPage($_POST['cms_page_id'], $error_msg)) {
		user_error($error_msg, E_USER_ERROR);
	}
}

$page_title_from = '';
$keywords = '';
$description = '';
$summary = "";
$index_title = '';
$template_name = '';
$template_id = '';
$template_kind = '';
$template_ver = '';
$inquiry_memo = '';
$inquiry_cnt = 1;
$outline = '';
$publish_to = '';
$contents_top_flg_checked = '';
$isChecked = array(
		ENQ_KIND_CGI => "", 
		ENQ_KIND_MAIL => ""
);
$link_str = "";
// イベントカレンダー複数日
if (EVENT_CAL_MULTI_FLAG) {
	$pdsy = $pdsm = $pdsd = $pdsh = $pdsi = $pdey = $pdem = $pded = $pdeh = $pdei = array();
}
// イベントカレンダー単一日
else {
	$pdsy = $pdsm = $pdsd = $pdey = $pdem = $pded = "";
}
$enq_kind = "";
$enq_email = "";
$file_name = "";
$faq_id = "";
$kanko_type = "";
$autoLinks_array = Array(
		"auto_links" => "", 
		"auto_links_title" => ""
);
$a_link_id = "";
$output = "";
$sel_op_ary = array();
$op_tpl_ary = array();
$output_html = OUTPUT_HTML_FLG;

if ($_POST['cms_dispMode'] == 'copy' || $_POST['cms_dispMode'] == 'disaster') {
	// 複写の場合はコピー元から取得
	$page_title = '';
	$page_title_from = $pub_fld['page_title'];
	$index_title = $pub_fld['index_title'];
	$keywords = $pub_fld['keywords'];
	$description = $pub_fld['description'];
	$summary = $pub_fld['summary'];
	
	$a_link_id = createAutolinkAryProperty($autoLinks_array, $pub_fld['page_id'], $pub_fld['index_title'], $tbl_name);
	
	// テンプレート読み込み
	if ($objTool->selectTemplate($pub_fld['template_id']) === FALSE) {
		user_error("Can't find template data.<br>dac_tools selectTemplate(" . $pub_fld['template_id'] . ")", E_USER_ERROR);
	}
	$template_name = "テンプレート：" . $objTool->fld['name'] . "が選択されています。";
	$template_id = $pub_fld['template_id'];
	$template_kind = $pub_fld['template_kind'];
	$template_ver = $pub_fld['template_ver'];
	$cate_code = $pub_fld['cate_code'];
	// 観光種類
	$kanko_type = $objTool->fld['kanko_type'];
	if ($pub_fld['contents_top_flg'] == 1) {
		$contents_top_flg_checked = "checked";
	}
	$inquiry_memo = $pub_fld['inquiry_memo'];
	
	$where = "inquiry_id = " . $pub_fld['inquiry_id'];
	if ($tbl_name == WORK_TABLE) {
		$objInquiry->setTableName("tbl_work_inquiry");
	}
	else {
		$objInquiry->setTableName("tbl_publish_inquiry");
	}
	$objInquiry->select($where, "*", "inquiry_id");
	if ($objInquiry->getRowCount() > 0) {
		$inquiry_cnt = $objInquiry->getRowCount();
	}
	
	if (ENABLE_OPTION_OUTPUT && $template_kind == TEMPLATE_KIND_FIXED) {
		// コピー元ページに設定されている外部連携情報取得
		if ($pub_fld['status'] != STATUS_PUBLISH) {
			$op_ary = getOutputPageFromPageId($pub_fld['page_id'], HANDLER_OUTPUT_CLASS_WORK_PAGE);
		}
		else {
			$op_ary = getOutputPageFromPageId($pub_fld['page_id']);
		}
		foreach ($op_ary as $op_fld)
			$sel_op_ary[] = $op_fld['output_id'];
	}
	if ($template_kind == TEMPLATE_KIND_FIXED && $kanko_type == KANKO_TYPE_EVENT) {
		// イベントカレンダー複数日
		if (EVENT_CAL_MULTI_FLAG) {
			if ($obj_event->selectFromID($pub_fld['page_id'], $tbl_name) === FALSE) {
				user_error("dac execute error. <br>tbl_event->selectFromID(" . $PID . ", " . $tbl_name . ");", E_USER_ERROR);
			}
			$open_date = '';
			$i = 0;
			while ($obj_event->fetch()) {
				$open_start = strtotime($obj_event->fld['open_start']);
				$pdsy[$i] = date('Y', $open_start);
				$pdsm[$i] = date('n', $open_start);
				$pdsd[$i] = date('j', $open_start);
				
				// 0時00分の場合は未入力扱いとする
				if (date("G", $open_start) == '0' && date('i', $open_start) == '00') {
					$pdsh[$i] = '';
					$pdsi[$i] = '';
				}
				else {
					$pdsh[$i] = date('G', $open_start);
					$pdsi[$i] = date('i', $open_start);
				}
				
				if (!empty($obj_event->fld['open_end'])) {
					$open_end = strtotime($obj_event->fld['open_end']);
					$pdey[$i] = date('Y', $open_end);
					$pdem[$i] = date('n', $open_end);
					$pded[$i] = date('j', $open_end);
					
					// 0時00分の場合は未入力扱いとする
					if (date('G', $open_end) == '0' && date('i', $open_end) == '00') {
						$pdeh[$i] = '';
						$pdei[$i] = '';
					}
					else {
						$pdeh[$i] = date('G', $open_end);
						$pdei[$i] = date('i', $open_end);
					}
				}
				else {
					$pdey[$i] = '';
					$pdem[$i] = '';
					$pded[$i] = '';
					$pdeh[$i] = '';
					$pdei[$i] = '';
				}
				++$i;
			}
		}
		// イベントカレンダー単一日
		else {
			$open_start = strtotime($pub_fld['open_start']);
			$pdsy = date("Y", $open_start);
			$pdsm = date("n", $open_start);
			$pdsd = date("j", $open_start);
			if ($pub_fld['open_end'] != "") {
				$open_end = strtotime($pub_fld['open_end']);
				$pdey = date("Y", $open_end);
				$pdem = date("n", $open_end);
				$pded = date("j", $open_end);
			}
		}
	}
	else if ($template_kind == TEMPLATE_KIND_ENQUETE) {
		$enq_kind = $pub_fld["enquete_kind"];
		$isChecked[$enq_kind] = "checked";
		$file_name = substr(basename($pub_fld["file_path"]), 0, strpos(basename($pub_fld["file_path"]), "."));
	}
	$link_str = "";
	$output_html = $pub_fld['output_html_flg'];
}
else if ($_POST['cms_dispMode'] == 'faq') {
	// 自分の公開情報を取得
	$objFaq->selectFromID($_POST['cms_faq_id']);
	$faq_id = $_POST['cms_faq_id'];
	$page_title = '';
	$page_title_from = $objFaq->fld['question_title'];
	$cate_code = $objFaq->fld['cate_code'];
	
	$PID = $pub_fld['parent_id'];
	
	// 新規の場合は親ページから取得
	// 親ページのページタイトルを取得
	// 自分が作業中のページの場合は編集情報から取得
	if ($pub_fld['status'] < 402 && $pub_fld['user_id'] == $objLogin->get('user_id')) {
		if ($objPage->selectFromID($PID, 2, 'page_title, cate_code') === FALSE) {
			user_error("dac execute error. <br>tbl_page->selectFromID(" . $PID . ", 2, 'page_title');", E_USER_ERROR);
		}
		$page_title = $objPage->fld['page_title'];
		// 自分が作業中のページじゃなければ公開情報から取得
	}
	else {
		$page_title = $pub_fld['page_title'];
	}
	
	// 外部連携機能デフォルトチェック有り項目取得
	if (ENABLE_OPTION_OUTPUT) {
		$op_ary = getOutput();
		foreach ($op_ary as $op_fld) {
			if (!isset($op_fld['output_default_check']) || $op_fld['output_default_check'] != FLAG_ON) continue;
			$sel_op_ary[] = $op_fld['output_id'];
		}
	}
}
else {
	// 新規の場合は親ページから取得
	// 親ページのページタイトルを取得
	// 自分が作業中のページの場合は編集情報から取得
	if ($pub_fld['status'] < 402 && $pub_fld['user_id'] == $objLogin->get('user_id')) {
		if ($objPage->selectFromID($PID, 2, 'page_title, cate_code') === FALSE) {
			user_error("dac execute error. <br>tbl_page->selectFromID(" . $PID . ", 2, 'page_title');", E_USER_ERROR);
		}
		$page_title = $objPage->fld['page_title'];
		$cate_code = $objPage->fld['cate_code'];
		// 自分が作業中のページじゃなければ公開情報から取得
	}
	else {
		$page_title = $pub_fld['page_title'];
		$cate_code = $pub_fld['cate_code'];
	}
	
	// 外部連携機能デフォルトチェック有り項目取得
	if (ENABLE_OPTION_OUTPUT) {
		$op_ary = getOutput();
		foreach ($op_ary as $op_fld) {
			if (!isset($op_fld['output_default_check']) || $op_fld['output_default_check'] != FLAG_ON) continue;
			$sel_op_ary[] = $op_fld['output_id'];
		}
	}
}

if ($objCate->isDisasterCategory($cate_code)) {
	$cate_code = '';
}
$cateInfo = getCateCode($cate_code);
// ぱんくずのセット
$pankuzu = $objTool->getPankuzu(FLAG_OFF, $template_kind, $kanko_type, $pub_fld['ancestor_path'], $page_title, $objLogin->get('user_id'), FALSE);
$pankuzu = setRootPath($pankuzu); // ルートからのパスにする


// テンプレート（最新バージョン）情報を取得
// ウェブマスターの場合は全テンプレート
if ($objLogin->get('class') == USER_CLASS_WEBMASTER) {
	$sql = "SELECT t.* FROM tbl_template AS t" . " WHERE t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND t.disp_flg = '" . FLAG_ON . "'" . " ORDER BY t.sort_order,t.template_id";
	// 作成者の場合は所属に権限があるテンプレート
}
else {
	if ($_POST['cms_dispMode'] == 'faq') {
		// FAQ回答より新規作成の場合は定型FAQテンプレートを抽出
		$sql = "SELECT t.* FROM tbl_template AS t" . " LEFT JOIN tbl_handler AS h ON (h.item2 = t.template_id)" . " WHERE h.class = " . HANDLER_CLASS_TEMPLATE . " AND h.item1 = '" . $objLogin->get('dept_code') . "'" . " AND t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND t.disp_flg = '" . FLAG_ON . "'" . " AND t.template_kind = '" . TEMPLATE_KIND_FIXED . "'" . " AND t.kanko_type = '" . KANKO_TYPE_FAQ . "'" . " ORDER BY t.sort_order,t.template_id";
	}
	else {
		$sql = "SELECT t.* FROM tbl_template AS t" . " LEFT JOIN tbl_handler AS h ON (h.item2 = t.template_id)" . " WHERE h.class = " . HANDLER_CLASS_TEMPLATE . " AND h.item1 = '" . $objLogin->get('dept_code') . "'" . " AND t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND t.disp_flg = '" . FLAG_ON . "'" . " ORDER BY t.sort_order,t.template_id";
	}
}
$objTool->execute($sql);

// ファイル保存先設定レイヤーの表示取得
if (isset($_SESSION['reffer'])) unset($_SESSION['reffer']);
$_SESSION['reffer'] = array();
require_once (APPLICATION_ROOT . "/common/dbcontrol/commands.inc");
$where = " class ='" . HANDLER_CLASS_DEF_DIR1 . "'";
$where .= " AND item1 ='" . $objLogin->get('dept_code') . "'";
$objDac->setTableName("tbl_handler");
$objDac->select($where);
$objDac->fetch();
if ($objDac->getRowCount() == 0) {
	$defFolder = "";
}
else {
	$defFolder = $objDac->fld['item2'];
}

// デフォルト保存先フォルダ
$DEFAULT_DIR_FIXED = getDefineArray('DEFAULT_DIR_FIXED');
$def_dir_fixed = array();
$def_dir_fixed_hidden = "";
foreach ((array) $DEFAULT_DIR_FIXED as $_type => $_dir) {
	// ディレクトリ名の前後に「/(スラッシュ)」
	$_dir = (preg_match("/^\//", $_dir)) ? $_dir : "/" . $_dir;
	$_dir .= (preg_match("/\/$/", $_dir)) ? "" : $_dir . "/";
	// 実存ファイルチェック
	if (@is_dir(DOCUMENT_ROOT . RPW . $_dir)) {
		$def_dir_fixed[$_type] = htmlspecialchars($_dir);
		$def_dir_fixed_hidden .= '<input type="hidden" id="cms_def_dir_fixed_' . $_type . '" name="cms_def_dir_fixed_' . $_type . '" value="' . htmlspecialchars($_dir) . '">' . PHP_EOL;
	}
}

// 初期フォルダ変更
foreach ((array) $def_dir_fixed as $_type => $_dir) {
	if ($kanko_type == $_type) {
		$defFolder = $_dir;
	}
}

// 複写の場合、複写元の保存先ディレクトリを初期ディレクトリにする
if ($_POST['cms_dispMode'] == 'copy' || $_POST['cms_dispMode'] == 'disaster') {
	// 複写元の保存先ディレクトリに権限がある場合のみ
	if ($objLogin->get('class') == USER_CLASS_WEBMASTER || $objHandler->IsEditableDir($objLogin->get('dept_code'), $copy_dir_path) !== FALSE) {
		$defFolder = $copy_dir_path;
	}
}

$refferStr = cxRefferMoveDir($objCnc, $defFolder);

//組織プルダウン生成
$combo_dept = createDeptCombo($objLogin->get('dept_code'), 1);

// 自分の組織情報を取得
$sql = "SELECT * FROM tbl_department WHERE dept_code = '" . $objLogin->get('dept_code') . "'";
$objDeptDac = new dac($objCnc);
$objDeptDac->execute($sql);
$objDeptDac->fetch();

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>新規ページの作成</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/newpage.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/newpage.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/reffer.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/kanko.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>

</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'workspace';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-newpage">
<form name="cms_fAddpage" id="cms_fAddpage" class="cms8341-form"
	method="post" action="<?=RPW?>/admin/page/common/addpage.php"><input
	type="hidden" name="cms_parent_id" id="cms_parent_id" value="<?=$PID?>">
<input type="hidden" name="cms_dir_path" id="cms_dir_path" value=""> <input
	type="hidden" name="cms_filename" id="cms_filename" value=""> <input
	type="hidden" name="cms_template_kind" id="cms_template_kind"
	value="<?=$template_kind?>"> <input type="hidden"
	name="cms_template_kanko_type" id="cms_template_kanko_type"
	value="<?=$kanko_type?>"> <input type="hidden" name="cms_inquiry_cnt"
	id="cms_inquiry_cnt" value="<?=$inquiry_cnt?>"> <input type="hidden"
	name="cms_dispMode" id="cms_dispMode"
	value="<?=$_POST['cms_dispMode']?>"> <input type="hidden"
	name="cms_copy_page_id" id="cms_copy_page_id"
	value="<?=$_POST['cms_page_id']?>"> <input type="hidden"
	name="cms_user_class" id="cms_user_class"
	value="<?=$objLogin->get('class')?>"> <input type="hidden"
	name="cms_ssl_flg" id="cms_ssl_flg" value="<?=ENQUETE_SSL_FLG?>"> <input
	type="hidden" name="cms_enq_email" id="cms_enq_email"
	value="<?=$enq_email?>"> <input type="hidden" name="cms_ssl_dir"
	id="cms_ssl_dir" value="<?=ENQUETE_SSL_DIR?>"> <input type="hidden"
	name="cms_faq_id" id="cms_faq_id" value="<?=$faq_id?>"> <input
	type="hidden" name="cms_a_link_id" id="cms_a_link_id"
	value="<?=$a_link_id?>"> <input type="hidden" name="cms_index_title"
	id="cms_index_title" value="<?=$index_title?>"> <input type="hidden"
	name="cms_sel_op" id="cms_sel_op"
	value="<?=implode(",", $sel_op_ary)?>"><input type="hidden"
	name="cms_template_ver" id="cms_template_ver"
	value="<?=$template_ver?>"><input type="hidden" name="cms_output_html"
	id="cms_output_html" value="<?=$output_html?>">

<?=$def_dir_fixed_hidden?>
<div><img src="images/bar_newpage.jpg" alt="新規ページ作成" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<p id="cms8341-pankuzu"><?=$pankuzu?> &gt; </p>
<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="170" align="left" valign="top" scope="row">テンプレート <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top">
		<p id="cms-template-selected"><?=$template_name?></p>
		<p><a href="javascript:" onClick="return cxTemplateSet()"><img
			src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
			height="20" border="0"></a></p>
		</td>
	</tr>
	<tr id="cms_page_title_tr" style="display: none">
		<th width="150" align="left" valign="top" scope="row"><label
			for="cms_page_title">タイトル <span class="cms_require">（必須）</span></label>
		<div class="cms_recommend"></div>
		</th>
		<td><input type="text" maxlength="255" name="cms_page_title"
			id="cms_page_title" style="width: 240px;"
			value="<?=htmlspecialchars($page_title_from)?>"><br>
		<span id="cms_parent_id_none_sp" style="display: none"><input
			type="checkbox" name="cms_parent_id_none" id="cms_parent_id_none"
			value="1"><label for="cms_parent_id_none">親ページなしにする</label></span></td>
	</tr>
	<tr id="cms_enquete_kind_tr" style="display: none">
		<th align="left" valign="top" nowrap scope="row">アンケート種別 <span
			class="cms_require">（必須）</span></th>
		<td>
<?php
foreach ($ENQUETE_KIND as $key => $value) {
	echo '<input type="radio" name="cms_enquete_kind" onClick="cxMailSelect(\'' . $key . '\')" id="cms_enquete_kind_' . $key . '" value="' . $key . '" ' . $isChecked[$key] . '><label for="cms_enquete_kind_' . $key . '">' . $value . '</label>' . "\n";
}
?>
<img id="cms_enquete_mail_add" alt="メール送信先の追加"
			src="<?=RPW?>/admin/images/set_enquete/btn_mailadd.jpg" width="100"
			height="20" style="cursor: pointer; margin-left: 10px; display:none"
			class="cms8341-verticalMiddle">
		<div id="cms_enquete_mail_form" style="display: none">
		<div id="cms_enquete_emai_list">
<?php
if ($pub_fld['enquete_email'] != "") {
	$enquete_emailAry = explode(",", $pub_fld['enquete_email']);
	$enq_mail_str = '<table cellspacing="0" cellpadding="5" border="1" style="margin-top:10px;border-collapse:collapse">';
	foreach ($enquete_emailAry as $enquete_email) {
		$enqDatas = explode(":", $enquete_email);
		$enq_mail_str .= '<tr id="mail_tr_cms_enqmail_' . $enqDatas[0] . '">';
		$enq_mail_str .= '<td><span id="cms_enqname_' . $enqDatas[0] . '">' . $enqDatas[1] . '</span></td>';
		$enq_mail_str .= '<td><span id="cms_enqmail_' . $enqDatas[0] . '">' . $enqDatas[0] . '</span></td>';
		$enq_mail_str .= '<td><img src="' . RPW . '/admin/images/set_enquete/item_del.gif" alt="削除する" onClick="cxEnqMailDel(\'mail_tr_cms_enqmail_' . $enqDatas[0] . '\')" style="cursor:pointer"></td>';
		$enq_mail_str .= '</tr>';
	}
	$enq_mail_str .= '</table>';
	echo $enq_mail_str;
}
?>
</div>
		</div>
		</td>
	</tr>
	<tr id="cms_cate_tr" style="display: none">
		<th align="left" valign="top" nowrap scope="row">分類 <span
			class="cms_require">（必須）</span></th>
		<td><select name="cms_cate1" id="cms_cate1"
			onChange="javascript:cxChangeCate(2, this.value)">
			<option value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
<?php
// 第一カテゴリのプルダウンを生成＋表示
if ($objCate->selectNewPageCate1($disaster_flg) === FALSE) {
	user_error("dac execute error. <br>tbl_category->selectNewPageCate1(" . $disaster_flg . ");", E_USER_ERROR);
}
while ($objCate->fetch()) {
	// 大規模災害状態でない場合
	// 大規模災害用分類の場合
	if ($disaster_flg == FLAG_OFF && $objCate->fld['disaster_flg'] == FLAG_ON) {
		// 選択できない
		continue;
	}
	
	$selected = ($objCate->fld['cate_code'] == $cateInfo['cate1_code']) ? ' selected' : '';
	print '<option id="cms_cate_' . $objCate->fld['cate_code'] . '" value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
}
?>
</select>&nbsp; <select name="cms_cate2" id="cms_cate2"
			onChange="javascript:cxChangeCate(3, this.value)">
			<option value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
<?php
// 第二カテゴリのプルダウンを生成＋表示
if ($cateInfo['level'] >= 1) {
	if ($objCate->selectChildren($cateInfo['cate1_code']) === FALSE) {
		user_error("dac execute error. <br>tbl_category->selectChildren(" . $cateInfo['cate1_code'] . ");", E_USER_ERROR);
	}
	while ($objCate->fetch()) {
		$selected = ($objCate->fld['cate_code'] == $cateInfo['cate2_code']) ? ' selected' : '';
		print '<option id="cms_cate_' . $objCate->fld['cate_code'] . '" value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
	}
}

?>
</select>&nbsp; <select name="cms_cate3" id="cms_cate3"
			onChange="javascript:cxChangeCate(4, this.value)">
			<option value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
<?php
// 第三カテゴリのプルダウンを生成＋表示
if ($cateInfo['level'] >= 2) {
	if ($objCate->selectChildren($cateInfo['cate2_code']) === FALSE) {
		user_error("dac execute error. <br>tbl_category->selectChildren(" . $cateInfo['cate2_code'] . ");", E_USER_ERROR);
	}
	while ($objCate->fetch()) {
		$selected = ($objCate->fld['cate_code'] == $cateInfo['cate3_code']) ? ' selected' : '';
		print '<option id="cms_cate_' . $objCate->fld['cate_code'] . '" value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
	}
}
?>
</select>&nbsp; <select name="cms_cate4" id="cms_cate4"
			onChange="javascript:cxChangeCate(5, this.value)">
			<option value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
<?php
// 第四カテゴリのプルダウンを生成＋表示
if ($cateInfo['level'] >= 3) {
	if ($objCate->selectChildren($cateInfo['cate3_code']) === FALSE) {
		user_error("dac execute error. <br>tbl_category->selectChildren(" . $cateInfo['cate3_code'] . ");", E_USER_ERROR);
	}
	while ($objCate->fetch()) {
		$selected = ($objCate->fld['cate_code'] == $cateInfo['cate4_code']) ? ' selected' : '';
		print '<option value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
	}
}
?>
</select></td>
	</tr>
	<tr id="cms_pd_tr" style="display: none">
<?php
// イベントカレンダー複数日
if (EVENT_CAL_MULTI_FLAG) {
?>
		<th align="left" valign="top" nowrap scope="row">開催期間 <span
			class="cms_require">（開始のみ必須）</span>
		<div class="cms_recommend"><?php echo (EVENT_SET_LIMIT); ?>件まで設定可能</div>
		</th>
		<td>
			<?php
			//開催日の要素数を取得
			$open_start_count = count($pdsy);
			?>
			<div><a href="javascript:" id="add_event_date" name="add_event_date"
			onclick="return cxAddEventDate()"><img
			src="<?php echo (RPW); ?>/admin/images/btn/btn_add_mini_02.jpg"
			alt="追加する" width="60" height="20" border="0" /></a>
				<?php
				if ($open_start_count > 0) {
					echo '<input type="hidden" id="cms_pd_count" name="cms_pd_count" value="' . $open_start_count . '" />&nbsp';
				}
				else {
					echo '<input type="hidden" id="cms_pd_count" name="cms_pd_count" value="1" />&nbsp';
				}
				?>
				<input type="hidden" id="cms_pd_limit" name="cms_pd_limit"
			value="<?php echo (EVENT_SET_LIMIT); ?>" />&nbsp; <a href="javascript:"
			id="cms_pd_calendar" onclick="return cxCalendarOpen('cms_pd','select')"><img
			src="<?php echo (RPW); ?>/admin/images/btn/btn_calendar.jpg"
			border="0" width="150" height="20"></a></div>

		<table border="0">
			<tbody id="calendar_input_area">
					<?php
					$html = '';
					// 開催期間がある場合、各期間を入力欄にセット
					if ($open_start_count > 0) {
						for($i = 0; $i < $open_start_count; $i++) {
							$no = $i + 1;
							
							$html .= '<tr><td id="cms_pd' . $no . '">';
							$html .= '<div style="float:left;">';
							$html .= '<input type="text" maxlength="4" id="cms_pd' . $no . 'sy" name="cms_pdsy[]" value="' . $pdsy[$i] . '" style="width: 36px; ime-mode: disabled">&nbsp;年&nbsp;';
							$html .= '<input type="text" maxlength="2" id="cms_pd' . $no . 'sm" name="cms_pdsm[]" value="' . $pdsm[$i] . '" style="width: 18px; ime-mode: disabled">&nbsp;月&nbsp;';
							$html .= '<input type="text" maxlength="2" id="cms_pd' . $no . 'sd" name="cms_pdsd[]" value="' . $pdsd[$i] . '" style="width: 18px; ime-mode: disabled">&nbsp;日&nbsp;';
							$html .= '<input type="text" maxlength="2" id="cms_pd' . $no . 'sh" name="cms_pdsh[]" value="' . $pdsh[$i] . '" style="width: 18px; ime-mode: disabled">&nbsp;時&nbsp;';
							$html .= '<input type="text" maxlength="2" id="cms_pd' . $no . 'si" name="cms_pdsi[]" value="' . $pdsi[$i] . '" style="width: 18px; ime-mode: disabled">&nbsp;分&nbsp;';
							$html .= 'から&nbsp;';
							$html .= '<input type="text" maxlength="4" id="cms_pd' . $no . 'ey" name="cms_pdey[]" value="' . $pdey[$i] . '" style="width: 36px; ime-mode: disabled">&nbsp;年&nbsp;';
							$html .= '<input type="text" maxlength="2" id="cms_pd' . $no . 'em" name="cms_pdem[]" value="' . $pdem[$i] . '" style="width: 18px; ime-mode: disabled">&nbsp;月&nbsp;';
							$html .= '<input type="text" maxlength="2" id="cms_pd' . $no . 'ed" name="cms_pded[]" value="' . $pded[$i] . '" style="width: 18px; ime-mode: disabled">&nbsp;日&nbsp;';
							$html .= '<input type="text" maxlength="2" id="cms_pd' . $no . 'eh" name="cms_pdeh[]" value="' . $pdeh[$i] . '" style="width: 18px; ime-mode: disabled">&nbsp;時&nbsp;';
							$html .= '<input type="text" maxlength="2" id="cms_pd' . $no . 'ei" name="cms_pdei[]" value="' . $pdei[$i] . '" style="width: 18px; ime-mode: disabled">&nbsp;分&nbsp;';
							$html .= 'まで&nbsp;';
							$html .= '</div>';
							$html .= '<div style="float:left;">';
							if ($no > 1) {
								$html .= '<a href="javascript:" id="del_event_date' . $no . '" name="del_event_date' . $no . '" onclick="return cxDelEventDate(' . $no . ')"><img src="' . RPW . '/admin/images/btn/btn_del_mini.jpg" width="60" height="20" border="0" /></a>';
							}
							$html .= '</div>';
							$html .= '</td></tr>';
						}
					}
					// 開催期間が無い場合
					else {
						$html .= '<tr><td id="cms_pd1">';
						$html .= '<div style="float:left;">';
						$html .= '<input type="text" maxlength="4" id="cms_pd1sy" name="cms_pdsy[]" value="" style="width: 36px; ime-mode: disabled">&nbsp;年&nbsp;';
						$html .= '<input type="text" maxlength="2" id="cms_pd1sm" name="cms_pdsm[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;月&nbsp;';
						$html .= '<input type="text" maxlength="2" id="cms_pd1sd" name="cms_pdsd[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;日&nbsp;';
						$html .= '<input type="text" maxlength="2" id="cms_pd1sh" name="cms_pdsh[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;時&nbsp;';
						$html .= '<input type="text" maxlength="2" id="cms_pd1si" name="cms_pdsi[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;分&nbsp;';
						$html .= 'から&nbsp;';
						$html .= '<input type="text" maxlength="4" id="cms_pd1ey" name="cms_pdey[]" value="" style="width: 36px; ime-mode: disabled">&nbsp;年&nbsp;';
						$html .= '<input type="text" maxlength="2" id="cms_pd1em" name="cms_pdem[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;月&nbsp;';
						$html .= '<input type="text" maxlength="2" id="cms_pd1ed" name="cms_pded[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;日&nbsp;';
						$html .= '<input type="text" maxlength="2" id="cms_pd1eh" name="cms_pdeh[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;時&nbsp;';
						$html .= '<input type="text" maxlength="2" id="cms_pd1ei" name="cms_pdei[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;分&nbsp;';
						$html .= 'まで&nbsp;';
						$html .= '</div>';
						$html .= '</td></tr>';
					}
					echo $html;
					?>
				</tbody>
		</table>
		<small>※終了期間を省略した場合は、開始期間と同じ日付になります。<br />
		※時間を省略した場合は、時間は表示されません。</small></td>
<?php
}
// イベントカレンダー単一日
else {
?>
		<th align="left" valign="top" nowrap scope="row">開催期間 <span
			class="cms_require">（開始のみ必須）</span></th>
		<td><input type="text" maxlength="4" id="cms_pdsy" name="cms_pdsy"
			value="<?=$pdsy?>" style="width: 50px; ime-mode: disabled"> 年 <input
			type="text" maxlength="2" id="cms_pdsm" name="cms_pdsm"
			value="<?=$pdsm?>" style="width: 30px; ime-mode: disabled"> 月 <input
			type="text" maxlength="2" id="cms_pdsd" name="cms_pdsd"
			value="<?=$pdsd?>" style="width: 30px; ime-mode: disabled"> 日 <a
			href="javascript:" onClick="return cxCalendarOpen('cms_pd','start')"><img
			src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
			width="14" height="17" border="0" align="absmiddle"></a> から &nbsp; <input
			type="text" maxlength="4" id="cms_pdey" name="cms_pdey"
			value="<?=$pdey?>" style="width: 50px; ime-mode: disabled"> 年 <input
			type="text" maxlength="2" id="cms_pdem" name="cms_pdem"
			value="<?=$pdem?>" style="width: 30px; ime-mode: disabled"> 月 <input
			type="text" maxlength="2" id="cms_pded" name="cms_pded"
			value="<?=$pded?>" style="width: 30px; ime-mode: disabled"> 日 <a
			href="javascript:" onClick="return cxCalendarOpen('cms_pd','end')"><img
			src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
			width="14" height="17" border="0" align="absmiddle"></a> まで<br>
		<small>※終了期間を省略した場合は、開始期間と同じ日付になります。</small></td>
<?php
}
?>
	</tr>
<?php
// 作成者の場合はコンテンツトップを選択
if ($objLogin->get('class') == USER_CLASS_WRITER) {
	?>
<tr id="cms_contents_top_tr" style="display: none">
		<th align="left" valign="top" nowrap scope="row">コンテンツトップ</th>
		<td><input type="checkbox" name="cms_contents_top_flg"
			id="cms_contents_top_flg" value="1" <?=$contents_top_flg_checked?>><label
			for="cms_contents_top_flg">コンテンツトップページにする</label><br>
		<small>※作成するページが複数ページ構成のトップページとなる場合は、コンテンツトップにチェックを入れてください。</small></td>
	</tr>
<?php
} // 作成者の場合はコンテンツトップを選択（END） 
?>
<tr id="cms_keyword_tr" style="display: none">
		<th align="left" valign="top" nowrap scope="row"><label
			for="cms_keywords">検索エンジン用キーワード</label>
		<div class="cms_recommend">推奨5キーワード以内</div>
		</th>
		<td><input type="text" name="cms_keywords" id="cms_keywords"
			style="width: 500px;" value="<?=htmlspecialchars($keywords)?>">&nbsp;<a
			href="javascript:"
			onClick="return cxGetTemplateKeywords('cms_keywords','cms_template_id','cms_template_ver')"><img
			src="<?=RPW?>/admin/images/btn/btn_get_from_template.jpg"
			alt="テンプレートから取得" border="0" width="120" height="20"
			class="cms8341-verticalMiddle"></a>
		<div style="font-size: 11px;">※複数ある場合はコンマ(,)で区切って下さい</div>
		</td>
	</tr>
	<tr id="cms_description_tr" style="display: none">
		<th align="left" valign="top" nowrap scope="row"><label
			for="cms_description">検索エンジン用説明文</label>
		<div class="cms_recommend">推奨100文字以内</div>
		</th>
		<td align="left" valign="top"><input type="text"
			name="cms_description" id="cms_description" style="width: 500px;"
			value="<?=htmlspecialchars($description)?>"></td>
	</tr>
	<tr id="cms_summry_tr" style="display: none">
		<th align="left" valign="top" nowrap scope="row"><label
			for="cms_summary">要約文</label></th>
		<td align="left" valign="top"><textarea name="cms_summary" rows="3"
			id="cms_summary" style="width: 500px;"><?=htmlspecialchars($summary)?></textarea></td>
	</tr>
	<tr id="cms_inquiry_tr" style="display: none">
		<th align="left" valign="top" nowrap scope="row">問い合わせ先</th>
		<td id="cms_inquiry_td">
<?php
if (($_POST['cms_dispMode'] == 'copy' || $_POST['cms_dispMode'] == 'disaster') && ($objInquiry->getRowCount() > 0 || $inquiry_memo != "")) {
	$loop_cnt = 0;
	$inq_dtl = "";
	while ($objInquiry->fetch()) {
		$loop_cnt++;
		$inq_fld = $objInquiry->fld;
		$str = "";
		$dept_str = createDeptCombo($inq_fld['dept_code'], $inq_fld['inquiry_no'], "cms_inquiry_dept");
		$inq_dtl .= '<div id="cms_inquiry_' . $inq_fld['inquiry_no'] . '">' . "\n";
		if ($loop_cnt == 1) {
			$inq_dtl .= '<div id="cms_inquiry_no_' . $inq_fld['inquiry_no'] . '" style="font-weight:bold">問い合わせ先' . $inq_fld['inquiry_no'] . '  </div>' . "\n";
		}
		else {
			$inq_dtl .= '<div id="cms_inquiry_no_' . $inq_fld['inquiry_no'] . '" style="font-weight:bold">問い合わせ先' . $inq_fld['inquiry_no'] . '  <a href="javascript:" onClick="return cxInquiryDel(' . $inq_fld['inquiry_no'] . ')"><img src="' . RPW . '/admin/images/btn/btn_del_mini.gif" alt="削除する" width="60" height="20" border="0" style="border:0px;"></a></div>' . "\n";
		}
		$inq_dtl .= '<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable" id="cms_inquiry_table">' . "\n";
		$inq_dtl .= '<tr id="cms_inquiry_dept_th_1"><th id="cms_inquiry_dept_th" style="width:160px;">' . INQUIRY_DEPT_NAME . '</th>' . "\n";
		$inq_dtl .= '<td>' . $dept_str . '</td></tr>' . "\n";
		$inq_dtl .= '<tr id="cms_inquiry_charge_tr_' . $inq_fld['inquiry_no'] . '"><th id="cms_inquiry_charge_th">' . INQUIRY_CHARGE_NAME . '<div class="cms_recommend"></div></th>' . "\n";
		$inq_dtl .= '<td><input type="text" name="cms_inquiry_charge_' . $inq_fld['inquiry_no'] . '" id="cms_inquiry_charge_' . $inq_fld['inquiry_no'] . '" value="' . htmlspecialchars($inq_fld['name']) . '" style="width:240px;"><span id="cms_inquiry_charge_info" style="font-size:11px;"><br>※資料の一部を担当する場合、担当者名に続けて（資料○○関係）と追記</span></td></tr>' . "\n";
		$inq_dtl .= '<tr id="cms_inquiry_anExtensionNumber_tr_' . $inq_fld['inquiry_no'] . '"><th id="cms_inquiry_anExtensionNumber_th">' . INQUIRY_EXTENSIONNUMBER_NAME . $str . '</th>' . "\n";
		$inq_dtl .= '<td><input type="text" name="cms_inquiry_anExtensionNumber_' . $inq_fld['inquiry_no'] . '" id="cms_inquiry_anExtensionNumber_' . $inq_fld['inquiry_no'] . '" value="' . $inq_fld['anex_number'] . '" class="cms8341-verticalMiddle"></td></tr>' . "\n";
		$inq_dtl .= '<tr id="cms_inquiry_directNumber_tr_' . $inq_fld['inquiry_no'] . '"><th id="cms_inquiry_directNumber_th">' . INQUIRY_DIRECTNUMBER_NAME . $str . '</th>' . "\n";
		$inq_dtl .= '<td><input type="text" name="cms_inquiry_directNumber_' . $inq_fld['inquiry_no'] . '" id="cms_inquiry_directNumber_' . $inq_fld['inquiry_no'] . '" value="' . $inq_fld['drxt_number'] . '"> (例： 03-3502-0000)&nbsp;<a href="javascript:" onClick="cxGetInquiryDeptInfo(' . $inq_fld['inquiry_no'] . ',\'tel\')"><img src="' . RPW . '/admin/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得" border="0" width="100" height="20" class="cms8341-verticalMiddle"></a></td></tr>' . "\n";
		$inq_dtl .= '<tr id="cms_inquiry_fax_tr_' . $inq_fld['inquiry_no'] . '"><th id="cms_inquiry_fax_th">' . INQUIRY_FAX_NAME . '</th>' . "\n";
		$inq_dtl .= '<td><input type="text" name="cms_inquiry_fax_' . $inq_fld['inquiry_no'] . '" id="cms_inquiry_fax_' . $inq_fld['inquiry_no'] . '" value="' . $inq_fld['fax'] . '"> (例： 03-3502-0000)&nbsp;<a href="javascript:" onClick="cxGetInquiryDeptInfo(' . $inq_fld['inquiry_no'] . ',\'fax\')"><img src="' . RPW . '/admin/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得" border="0" width="100" height="20" class="cms8341-verticalMiddle"></a></td></tr>' . "\n";
		$inq_dtl .= '<tr id="cms_inquiry_email_tr_' . $inq_fld['inquiry_no'] . '"><th id="cms_inquiry_email_th">' . INQUIRY_EMAIL_NAME . '</th>' . "\n";
		$inq_dtl .= '<td><input type="text" name="cms_inquiry_email_' . $inq_fld['inquiry_no'] . '" id="cms_inquiry_email_' . $inq_fld['inquiry_no'] . '" value="' . $inq_fld['email'] . '" style="ime-mode:disabled;">&nbsp;<a href="javascript:" onClick="cxGetInquiryDeptInfo(' . $inq_fld['inquiry_no'] . ',\'email\')"><img src="' . RPW . '/admin/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得" border="0" width="100" height="20" class="cms8341-verticalMiddle"></a></td></tr>' . "\n";
		$inq_dtl .= '</table><br></div>' . "\n";
	}
	if ($objInquiry->getRowCount() <= 0 && $inquiry_memo != "") {
		$str = "";
		$dept_str = createDeptCombo("", 1, "cms_inquiry_dept");
		$inq_dtl .= '<div id="cms_inquiry_1">' . "\n";
		$inq_dtl .= '<div id="cms_inquiry_no_1" style="font-weight:bold">問い合わせ先1</div>' . "\n";
		$inq_dtl .= '<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable" id="cms_inquiry_table">' . "\n";
		$inq_dtl .= '<tr id="cms_inquiry_dept_tr_1"><th id="cms_inquiry_dept_th" style="width:160px;">' . INQUIRY_DEPT_NAME . '</th>' . "\n";
		$inq_dtl .= '<td>' . $dept_str . '</td></tr>' . "\n";
		$inq_dtl .= '<tr id="cms_inquiry_charge_tr_1"><th id="cms_inquiry_charge_th">' . INQUIRY_CHARGE_NAME . '<div class="cms_recommend"></div></th>' . "\n";
		$inq_dtl .= '<td><input type="text" name="cms_inquiry_charge_1" id="cms_inquiry_charge_1" value="" style="width:240px;"><span id="cms_inquiry_charge_info" style="font-size:11px;"><br>※資料の一部を担当する場合、担当者名に続けて（資料○○関係）と追記</span></td></tr>' . "\n";
		$inq_dtl .= '<tr id="cms_inquiry_anExtensionNumber_tr_1"><th id="cms_inquiry_anExtensionNumber_th">' . INQUIRY_EXTENSIONNUMBER_NAME . $str . '</th>' . "\n";
		$inq_dtl .= '<td><input type="text" name="cms_inquiry_anExtensionNumber_1" id="cms_inquiry_anExtensionNumber_1" value="" class="cms8341-verticalMiddle"></td></tr>' . "\n";
		$inq_dtl .= '<tr id="cms_inquiry_directNumber_tr_1"><th id="cms_inquiry_directNumber_th">' . INQUIRY_DIRECTNUMBER_NAME . $str . '</th>' . "\n";
		$inq_dtl .= '<td><input type="text" name="cms_inquiry_directNumber_1" id="cms_inquiry_directNumber_1" value=""> (例： 03-3502-0000)&nbsp;<a href="javascript:" onClick="cxGetInquiryDeptInfo(\'1\',\'tel\')"><img src="' . RPW . '/admin/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得" border="0" width="100" height="20" class="cms8341-verticalMiddle"></a></td></tr>' . "\n";
		$inq_dtl .= '<tr id="cms_inquiry_fax_tr_1"><th id="cms_inquiry_fax_th">' . INQUIRY_FAX_NAME . '</th>' . "\n";
		$inq_dtl .= '<td><input type="text" name="cms_inquiry_fax_1" id="cms_inquiry_fax_1" value=""> (例： 03-3502-0000)&nbsp;<a href="javascript:" onClick="cxGetInquiryDeptInfo(\'1\',\'fax\')"><img src="' . RPW . '/admin/images/btn/btn_get_deptinfo.jpg" border="0" width="100" height="20" class="cms8341-verticalMiddle"></a></td></tr>' . "\n";
		$inq_dtl .= '<tr id="cms_inquiry_email_tr_1"><th id="cms_inquiry_email_th">' . INQUIRY_EMAIL_NAME . '</th>' . "\n";
		$inq_dtl .= '<td><input type="text" name="cms_inquiry_email_1" id="cms_inquiry_email_1" value="" style="ime-mode:disabled;">&nbsp;<a href="javascript:" onClick="cxGetInquiryDeptInfo(\'1\',\'email\')"><img src="' . RPW . '/admin/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得" border="0" width="100" height="20" class="cms8341-verticalMiddle"></a></td></tr>' . "\n";
		$inq_dtl .= '</table><br></div>' . "\n";
	}
	echo $inq_dtl;
	?>
<?php
}
else {
	?>

<div id="cms_inquiry_1">
		<div style="font-weight: bold" id="cms_inquiry_no_1">問い合わせ先1</div>
		<table width="100%" border="0" cellpadding="7" cellspacing="0"
			class="cms8341-dataTable" id="cms_inquiry_table">
			<tr id="cms_inquiry_dept_th_1">
				<th id="cms_inquiry_dept_th" style="width: 160px;"><?=INQUIRY_DEPT_NAME?></th>
				<td>
<?=$combo_dept?>	
	</td>
			</tr>
			<tr id="cms_inquiry_charge_tr_1">
				<th id="cms_inquiry_charge_th"><?=INQUIRY_CHARGE_NAME?><div
					class="cms_recommend"></div>
				</th>
				<td><input type="text" name="cms_inquiry_charge_1"
					id="cms_inquiry_charge_1" value="" style="width: 240px;"><span
					id="cms_inquiry_charge_info" style="font-size: 11px;"></span></td>
			</tr>
			<tr id="cms_inquiry_anExtensionNumber_tr_1">
				<th id="cms_inquiry_anExtensionNumber_th"><?=INQUIRY_EXTENSIONNUMBER_NAME?></th>
				<td><input type="text" name="cms_inquiry_anExtensionNumber_1"
					id="cms_inquiry_anExtensionNumber_1" value=""
					class="cms8341-verticalMiddle"></td>
			</tr>
			<tr id="cms_inquiry_directNumber_tr_1">
				<th id="cms_inquiry_directNumber_th"><?=INQUIRY_DIRECTNUMBER_NAME?></th>
				<td><input type="text" name="cms_inquiry_directNumber_1"
					id="cms_inquiry_directNumber_1"
					value="<?=($objLogin->get('class') == USER_CLASS_WEBMASTER) ? '' : $objDeptDac->fld['tel']?>">
				(例： 03-3502-0000)&nbsp;<a href="javascript:"
					onClick="cxGetInquiryDeptInfo('1','tel')"><img
					src="<?=RPW?>/admin/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得"
					border="0" width="100" height="20" class="cms8341-verticalMiddle"></a>
				</td>
			</tr>
			<tr id="cms_inquiry_fax_tr_1">
				<th id="cms_inquiry_fax_th"><?=INQUIRY_FAX_NAME?></th>
				<td><input type="text" name="cms_inquiry_fax_1"
					id="cms_inquiry_fax_1"
					value="<?=($objLogin->get('class') == USER_CLASS_WEBMASTER) ? '' : $objDeptDac->fld['fax']?>">
				(例： 03-3502-0000)&nbsp;<a href="javascript:"
					onClick="cxGetInquiryDeptInfo('1','fax')"><img
					src="<?=RPW?>/admin/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得"
					border="0" width="100" height="20" class="cms8341-verticalMiddle"></a>
				</td>
			</tr>
			<tr id="cms_inquiry_email_tr_1">
				<th id="cms_inquiry_email_th"><?=INQUIRY_EMAIL_NAME?></th>
				<td><input type="text" name="cms_inquiry_email_1"
					id="cms_inquiry_email_1"
					value="<?=($objLogin->get('class') == USER_CLASS_WEBMASTER) ? '' : $objDeptDac->fld['email']?>"
					style="ime-mode: disabled;">&nbsp;<a href="javascript:"
					onClick="cxGetInquiryDeptInfo('1','email')"><img
					src="<?=RPW?>/admin/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得"
					border="0" width="100" height="20" class="cms8341-verticalMiddle"></a>
				</td>
			</tr>
		</table>
		<br>
		</div>
<?php
}
?>
<div id="cms_inquiry_add">
		<p>追加問い合わせ先&nbsp;<a href="javascript:" onClick="return cxAddInquiry()"><img
			src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
			height="20" border="0" class="cms8341-verticalMiddle"></a></p>
		</div>
		<table width="100%" border="0" cellpadding="7" cellspacing="0"
			class="cms8341-dataTable" id="cms_inquiry_memo_table">
			<tr>
				<th id="cms_inquiry_dept_th" style="width: 160px;"><?=INQUIRY_FREE_NAME?><div
					class="cms_recommend">推奨5行以内100文字程度</div>
				</th>
				<td><textarea name="cms_inquiry_memo" id="cms_inquiry_memo" rows="5"
					style="width: 400px;"><?=$inquiry_memo?></textarea>
				<div id="cms-autoLinks_info" style="font-size: 11px;">※問い合わせ項目に当てはまらない場合に記入してください。</div>
				</td>
			</tr>
		</table>
		</td>
	</tr>
<?php
if (ENABLE_OPTION_OUTPUT && $_POST['cms_dispMode'] != 'disaster') {
	?>
<tr id="cms_output_tr" style="display: none">
		<th align="left" valign="top" nowrap scope="row">外部出力先</th>
		<td align="left" valign="top"><span id="cms-outputs"></span>
	
	</tr>
<?php
}
?>
<tr id="cms_autoLinks_tr" style="display: none">
		<th align="left" valign="top" nowrap scope="row">自動リンク先</th>
		<td align="left" valign="top">
		<ul id="cms-auto-links"><?=$autoLinks_array["auto_links"]?></ul>
		<span id="cms-link-title"><?=$autoLinks_array["auto_links_title"]?></span>
		<p><a href="javascript:" onClick="return cxAutoLinksSet()"><img
			src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
			height="20" border="0" class="cms8341-verticalMiddle"></a></p>
		</td>
	</tr>
	<tr id="cms_reffer_tr" style="display: none">
		<th align="left" valign="top" scope="row">ファイル保存先 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top">
		<p id="cms_file_path"></p>
		<p><a href="javascript:" onClick="return cxRefferSet()"><img
			src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
			height="20" border="0"></a></p>
		</td>
	</tr>
	<tr id="cms_ssl_reffer_tr" style="display: none">
		<th align="left" valign="top" scope="row">ファイル保存先 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><input type="text" maxlength="255"
			name="cms_file_name" id="cms_file_name"
			style="width: 240px; ime-mode: disabled;" value="<?=$file_name?>">.html
		<div style="font-size: 11px;">※ファイル名のみを入力してください</div>
		</td>
	</tr>
</table>
<br>
<?php if(ENABLE_OPEN_DATA_FLG) { ?>
<!-- オープンデータ -->
<div id="cms_opendata_area"></div>
<?php } ?>
<br>
<div id="cms_kanko_area"></div>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center" id="cms_submit" style="display: none"><a
	href="javascript:"
	onClick="return cxSubmit('<?=$objLogin->get('class')?>')"><img
	src="<?=RPW?>/admin/images/btn/btn_submit_large.jpg" alt="作成"
	width="150" height="20" border="0" style="margin-right: 10px;"></a><a
	href="javascript:" onClick="return cxPageCancel()"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px;"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
<!-- ** テンプレート設定レイヤー　ここから ************************************* -->
<div id="cms8341-template-select" class="cms8341-layer">
<table width="800" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="800" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="800" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/template_select/title_template_select.jpg"
					alt="テンプレートの選択" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxTemplateClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 760px; height: 385px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<table width="740" border="0" cellpadding="0" cellspacing="0"
			class="cms8341-noneBorder">
			<tr>
				<td align="left" valign="top">
				<div id="cms_template_list"><label for="cms_template_id">テンプレートリスト</label>
				<select name="cms_template_id" id="cms_template_id" size="12"
					style="width: 250px;" onChange="cxSelectTemplate()">
<?php
// テンプレート選択フォームの生成＋表示
$def_src = "javascript:''";
while ($objTool->fetch()) {
	if ($objTool->fld['template_id'] == TEMPLATE_ID_NONE) continue;
	$src = DIR_PATH_TEMPLATE . $objTool->fld['temp_txt'];
	if ($template_id != "" && $template_id == $objTool->fld['template_id']) {
		print '<option value="' . $objTool->fld['template_id'] . '" id="' . $src . '" _kind="' . $objTool->fld['template_kind'] . '" _kanko_type="' . $objTool->fld['kanko_type'] . '" _ver="' . $objTool->fld['template_ver'] . '" selected>' . htmlDisplay($objTool->fld['name']) . '</option>' . "\n";
	}
	else {
		print '<option value="' . $objTool->fld['template_id'] . '" id="' . $src . '" _kind="' . $objTool->fld['template_kind'] . '" _kanko_type="' . $objTool->fld['kanko_type'] . '" _ver="' . $objTool->fld['template_ver'] . '">' . htmlDisplay($objTool->fld['name']) . '</option>' . "\n";
	}
}
?>
</select></div>
				</td>
				<td width="475" align="left" valign="middle">
				<div id="cms_thumb_cover" style="position: absolute; width: 475px; height: 365px; filter: Alpha(opacity = 0)"></div>
				<iframe src="<?=$def_src?>" name="cms_thumb" id="cms_thumb"
					width="470" height="360" frameborder="0" scrolling="no"
					style="border: solid 1px #666"></iframe></td>
			</tr>
		</table>
		</div>
		</div>
		<p style="margin: 10px 0px;"><a href="javascript:"
			onClick="return cxTemplateSubmit()"><img
			src="<?=RPW?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
			height="21" border="0"></a></p>
		</td>
	</tr>
</table>
</div>
<!-- ** テンプレート設定レイヤー　ここまで ************************************* --></form>
</div>
</div>
<!-- cms8341-contents -->
<!--***ファイル保存先設定レイヤー　ここから***********-->
<div id="cms8341-reffer" class="cms8341-layer">
<?=$refferStr?>
</div>
<!--***ファイル保存先設定レイヤー　ここまで***********-->
<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCalendarClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%;">
		<div id="cms8341-calbody"
			style="width: 480px; height: 450px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
<!--***エラーメッセージレイヤー　　ここから***********-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxLayer('cms8341-error',0);"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー　　ここまで***********-->
<?php
echo $objTool->setAccessibility();
?>
</body>
</html>
