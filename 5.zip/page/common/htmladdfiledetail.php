<?php
/*
 * FCKエディタの中にあるリンクにファイルがある場合、ファイルの形式とサイズを追記する
 */
//外部ファイル読み込み
require ("../.htsetting");

//変数の宣言
$post = $_POST;

//ファイル形式とサイズの追記処理
if (isset($post['cms_context'])) $post['cms_context'] = htmlAddFileDetail(del_escapes($post['cms_context']));
//ファイル情報の保持
$_SESSION['add_fd'] = $post;
//編集画面に戻る
header("Location: " . HTTP_ROOT . RPW . $post['cms_p_file_path'] . "?edit=1&add_fd=1");

/**
 * ファイル形式とサイズの追記処理
 * ファイルの形式とサイズを追記する。
 * @param $cms_context　FCKeditorの中に記入されている文字列
 * @return 追記後の文字列
 */
function htmlAddFileDetail($cms_context) {
	global $_POST;
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
	$dacTools = new dac_tools($objCnc);
	if ($dacTools->selectTemplate($_POST['cms_template_id']) === FALSE) user_error("テンプレート情報の取得に失敗しました。", E_USER_ERROR);
	$acc_flg = $dacTools->fld['acc_flg'];
	//検索開始文字用オフセット
	$offset = 0;
	//ファイル情報配列の作成
	$ADD_FILE_DETAIL_EXP_ARY = getDefineArray("ADD_FILE_DETAIL_EXP");
	
	//外部リンク表記が画像の場合の対応
	$out_site_str_jp = preg_replace('/(src=")https?:\/\/' . SERVER_NAME . '/', '$1', str_replace('\\"', '"', OUT_SITE_STR_JP));
	$out_site_str_en = preg_replace('/(src=")https?:\/\/' . SERVER_NAME . '/', '$1', str_replace('\\"', '"', OUT_SITE_STR_EN));
	
	//外部リンク表記配列セット
	$ADD_FILE_EXT_LINK_STR = array(
			'JP' => $out_site_str_jp,
			'EN' => $out_site_str_en
	);
	$ADD_FILE_EXT_LINK_URL = array(
			'http://',
			'https://'
	);
	$ADD_FILE_NOT_EXT_LINK_URL = explode(",", OUT_SITE_DOMAIN);
	
	//外部リンク表記が画像の場合の対応
	$del_img = array();
	foreach ($ADD_FILE_EXT_LINK_STR as $key => $value) {
		if (preg_match('/<img[^>]+src=\"([^\"]+)\"/', $value, $matches)) {
			$del_img[] = $matches[1];
		}
	}
	
	//ファイル終了まで繰り返す(aタグを取得)
	while (preg_match('/<a([^>]*?)href="([^"]*?)"([^>]*?)>([\S\s]*?)<\/a>/i', $cms_context, $matches, PREG_OFFSET_CAPTURE, $offset)) {
		//クラス置換対象の配列取得
		$link_class_array = array(
				$matches[1],
				$matches[3]
		);
		//リンク対象の配列取得
		$link_href_array = $matches[2];
		//リンクテキストの配列取得
		$link_text_array = $matches[4];
		//リンクテキストの文字数取得
		$link_text_cnt = strlen($matches[0][0]);
		//ファイル名取得
		$filename = ($link_href_array[0] != "" ? basename($link_href_array[0]) : '');
		//拡張子を取得
		preg_match('/.*\.(.*)$/i', $filename, $exp_match);
		$exp = (isset($exp_match[1]) ? strtolower($exp_match[1]) : "");
		//外部リンクフラグ
		$external_link = FLAG_OFF;
		if (OUT_SITE_FLG) {
			//外部リンクとして認識する指定ならフラグオン
			foreach ((array) $ADD_FILE_EXT_LINK_URL as $_url) {
				if (preg_match("/^" . reg_replace($_url) . "/i", $link_href_array[0])) {
					$external_link = FLAG_ON;
					break;
				}
			}
			foreach ((array) $ADD_FILE_NOT_EXT_LINK_URL as $_url) {
				if (preg_match("/^" . reg_replace($_url) . "/i", $link_href_array[0])) {
					$external_link = FLAG_OFF;
					break;
				}
			}
		}
		
		//拡張子があり、追記するものに指定されている場合
		$tag_a = $matches[0][0];
		//外部リンクの場合
		if ($exp != "" && array_key_exists($exp, $ADD_FILE_DETAIL_EXP_ARY) || $external_link == FLAG_ON) {
			//文字列を一旦削除
			$delRepText = strtoupper($exp);
			foreach ($ADD_FILE_DETAIL_EXP_ARY as $val) {
				if ($acc_flg == ACCESSIBILITY_JP_FLG) $delRepText .= '|' . $val['JP'];
				else if ($acc_flg == ACCESSIBILITY_NOT_JP_FLG) $delRepText .= '|' . $val['EN'];
			}
			$str = $link_text_array[0];
			// 別ウィンドウで開く表記削除
			// 日本語テンプレートの場合
			if ($acc_flg == ACCESSIBILITY_JP_FLG) {
				$str = preg_replace('/' . reg_replace(OTHER_WINDOW_STR_JP) . '$/i', '', $str);
			}
			// 外国語テンプレートの場合
			else if ($acc_flg == ACCESSIBILITY_NOT_JP_FLG) {
				$str = preg_replace('/' . reg_replace(OTHER_WINDOW_STR_EN) . '$/i', '', $str);
			}
			// 外部リンク表記が画像の場合の対応
			$str = preg_replace('/(src=")https?:\/\/' . SERVER_NAME . '/', '$1', $str);
			foreach ($del_img as $img) {
				$str = preg_replace('/<img[^>]+src="' . reg_replace($img) . '"[^>]+>/', '', $str);
			}
			// 外部リンク表記削除
			if (OUT_SITE_FLG) {
				if ($acc_flg == ACCESSIBILITY_JP_FLG) $str = preg_replace('/' . reg_replace($ADD_FILE_EXT_LINK_STR['JP']) . '$/i', "", $str);
				else if ($acc_flg == ACCESSIBILITY_NOT_JP_FLG) $str = preg_replace('/' . reg_replace($ADD_FILE_EXT_LINK_STR['EN']) . '$/i', "", $str);
			}
			// 添付ファイル表記の削除
			$str = preg_replace('/(（|\\()(' . $delRepText . ')((：|:)[0-9,]+KB)?(）|\\))$/i', "", $str);
			
			//パスを整理(サーバのルートパスを削除する)
			$link_href_array[0] = str_replace(HTTP_ROOT, "", $link_href_array[0]);
			$link_href_array[0] = str_replace(RPW, "", $link_href_array[0]);
			
			//ファイルサイズの初期化
			$filesize = 0;
			//「/」から始まっているパスは、内部パスとみなす
			if (substr($link_href_array[0], 0, 1) == "/") {
				//ファイルサイズの取得
				$link_href_array[0] = RPW . $link_href_array[0];
				$filesize = @filesize(DOCUMENT_ROOT . $link_href_array[0]);
				$filesize = ceil($filesize / 1024);
			}
			
			//拡張子の判定 & 追加用文字列の作成
			$class = "";
			//ファイル種別の指定
			if (isset($ADD_FILE_DETAIL_EXP_ARY[$exp]) && $external_link != FLAG_ON && $filesize != 0) {
				if ($acc_flg == ACCESSIBILITY_JP_FLG) $str .= "（" . $ADD_FILE_DETAIL_EXP_ARY[$exp]['JP']; //日本語
				else if ($acc_flg == ACCESSIBILITY_NOT_JP_FLG) $str .= "(" . $ADD_FILE_DETAIL_EXP_ARY[$exp]['EN']; //外国語
				//クラスの指定
				if ($ADD_FILE_DETAIL_EXP_ARY[$exp]['CLASS'] != "") $class = ' class="' . $ADD_FILE_DETAIL_EXP_ARY[$exp]['CLASS'] . '"';
				//ファイルサイズの指定
				$str .= ($acc_flg == ACCESSIBILITY_JP_FLG ? "：" : ":") . numEdit($filesize) . "KB";
				$str .= ($acc_flg == ACCESSIBILITY_JP_FLG ? "）" : ")");
			}
			// 外部ページの場合は表記を挿入
			if (OUT_SITE_FLG && $external_link == FLAG_ON) {
				if ($acc_flg == ACCESSIBILITY_JP_FLG) $str .= $ADD_FILE_EXT_LINK_STR['JP'];
				elseif ($acc_flg == ACCESSIBILITY_NOT_JP_FLG) $str .= $ADD_FILE_EXT_LINK_STR['EN'];
			}
			
			//クラスの指定を一旦削除する
			$etc_str = "";
			foreach ($link_class_array as $link_class) {
				$link_class[0] = preg_replace('/class="[^"]*?"/i', "", $link_class[0]);
				$etc_str .= $link_class[0];
			}
			//クラスの指定
			$etc_str .= $class;
			//aタグを作成
			$tag_a = '<a' . preg_replace("/\s+/", " ", " " . $etc_str . " ") . 'href="' . $link_href_array[0] . '">' . $str . '</a>';
			//追加
			$cms_context = substr($cms_context, 0, $matches[0][1]) . $tag_a . substr($cms_context, $matches[0][1] + strlen($matches[0][0]));
			//リンクテキストの文字数変更
			$link_text_cnt = strlen($tag_a);
		}
		// target属性値に「_blank」（別ウィンドウ）設定が指定されている場合
		if (strpos($matches[0][0], 'target="_blank"') !== FALSE) {
			// 日本語テンプレートの場合
			if ($acc_flg == ACCESSIBILITY_JP_FLG) {
				$rep_tag_a = str_replace('</a>', OTHER_WINDOW_STR_JP . '</a>', $tag_a);
				$cms_context = str_replace($tag_a, $rep_tag_a, $cms_context);
			}
			// 外国語テンプレートの場合
			else if ($acc_flg == ACCESSIBILITY_NOT_JP_FLG) {
				$rep_tag_a = str_replace('</a>', OTHER_WINDOW_STR_EN . '</a>', $tag_a);
				$cms_context = str_replace($tag_a, $rep_tag_a, $cms_context);
			}
			$link_text_cnt = strlen($rep_tag_a);
		}
		//検索開始文字列を進める
		$offset = $matches[0][1] + $link_text_cnt;
	}
	return $cms_context;
}
?>
