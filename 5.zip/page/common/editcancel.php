<?php
/*
 * 作業の取り消し
 */
require ("../.htsetting");

// ウェブマスターの作成ページを公開中止にしたとき$_GET['pubchancel_id']が渡される
if (isset($_GET['pubchancel_id'])) {
	$PID = $_GET['pubchancel_id'];
	// ワークスペースから作業の取り消しをしたとき$_POST['cms_page_id']が渡される
}
elseif (isset($_POST['cms_page_id'])) {
	$PID = $_POST['cms_page_id'];
	// $_GET['pubchancel_id']も$_POST['cms_page_id']も渡されなければエラー
}
else {
	user_error("It isn't setted cms_page_id in _post.", E_USER_ERROR);
}

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage2 = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$objLinks = new tbl_links($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
$objKanko = new tbl_kanko($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_map.inc');
$objMap = new tbl_map($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInquiry = new tbl_inquiry($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete.inc');
$objEnq = new tbl_enquete($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete_detail.inc');
$objEnqDtl = new tbl_enquete_detail($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output_handler.inc');
$objOpHndl = new tbl_output_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_approve_handler.inc');
$objAppHandler = new tbl_approve_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap_handler.inc');
$objSitemapHandler = new tbl_sitemap_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_disaster_handler.inc');
$obj_dis_handle = new tbl_disaster_handler($objCnc);
// イベントカレンダー複数日
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_event.inc');
$obj_event = new tbl_event($objCnc);
// オープンデータ
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_open_data.inc');
$obj_open_data = new tbl_open_data($objCnc);

// 公開ページ情報を取得
if ($objPage->selectFromID($PID, PUBLISH_TABLE, "work_class, file_path, bak_status,template_kind,page_id,inquiry_id,parent_id,template_id") === FALSE) {
	user_error("dac execute error. <br>tbl_page->selectFromID(" . $PID . ", 1);", E_USER_ERROR);
}
$fld = $objPage->fld;
$p_file_path = $fld['file_path'];

// 編集ページ情報を取得
if ($objPage->selectFromID($PID, WORK_TABLE, "page_id, page_title, file_path") === FALSE) {
	user_error("dac execute error. <br>tbl_page->selectFromID(" . $PID . ", 2);", E_USER_ERROR);
}
$w_fld = $objPage->fld;

// トランザクション開始
$objCnc->begin();

// 作業情報の削除
if (!$objPage->deleteFromPageID($PID, WORK_TABLE)) { // （DELETE FROM tbl_work_page）
	user_error('編集ページ情報の削除に失敗しました。');
}
if (!$objLinks->deleteFromPageID($PID, WORK_TABLE)) { // （DELETE FROM tbl_work_links）
	user_error('編集リンク情報の削除に失敗しました。');
}
if (!$objImages->deleteFromPageID($PID, WORK_TABLE)) { // （DELETE FROM tbl_work_images）
	user_error('編集画像情報の削除に失敗しました。');
}
if (!$objHandler->deleteLibrary($PID, WORK_TABLE)) { // （DELETE FROM tbl_handler WHERE class = HANDLER_CLASS_LIBRARY_P2）
	user_error('編集ライブラリ設定の削除に失敗しました。');
}
if (!$objHandler->deleteAutoLink($PID, WORK_TABLE)) { // （DELETE FROM tbl_handler WHERE class = HANDLER_CLASS_INDEX_CHK2）
	user_error('編集自動リンク設定の削除に失敗しました。');
}
if (!$objHandler->deleteAutoLinkPage($PID, WORK_TABLE)) {
	user_error('編集自動リンク設定の削除に失敗しました。');
}
if (!$objHandler->deletePublishDeleteFile($PID)) { // （DELETE FROM tbl_handler WHERE class = HANDLER_CLASS_PUBLISH_DELETE_FILE）
	user_error('削除ファイル情報の削除に失敗しました。');
}
if (!$objKanko->deleteFromID($PID, "", WORK_TABLE)) { // （DELETE FROM tbl_kanko WHERE page_id）
	user_error('編集観光情報の削除に失敗しました。');
}
if (ENABLE_OPTION_GOOGLEMAP) {
	if (!$objMap->deleteFromPID($PID, WORK_TABLE)) { // （DELETE FROM tbl_work_map WHERE page_id）
		user_error('編集地図情報の削除に失敗しました。');
	}
}
if (!$objInquiry->deleteFromID($fld['inquiry_id'], WORK_TABLE)) {
	user_error('問い合わせ情報の削除に失敗しました。');
}
if ($fld['template_kind'] == TEMPLATE_KIND_ENQUETE) {
	$objEnq->selectFromPID($PID, WORK_TABLE);
	if ($objEnq->fetch()) {
		$enq_fld = $objEnq->fld;
		$enquete_id = $enq_fld['enquete_id'];
		$objEnq->add_where("page_id", $PID);
		if ($objEnq->delete("", WORK_TABLE) === FALSE) {
			user_error('編集アンケート情報の削除に失敗しました。');
		}
		$objEnqDtl->add_where("enquete_id", $enquete_id);
		if ($objEnqDtl->delete("", WORK_TABLE) === FALSE) {
			user_error('編集アンケート詳細情報の削除に失敗しました。');
		}
	}
}

// 否認理由のひも付け削除
if (!$objAppHandler->delete_denial_msg($PID)) {
	user_error('前回の否認理由の削除に失敗しました。');
}
if (ENABLE_OPTION_OUTPUT) {
	if (!$objOpHndl->deletePage($PID, HANDLER_OUTPUT_CLASS_WORK_PAGE)) {
		user_error('外部連携データ出力設定の削除に失敗しました。');
	}
}

// サイトマップ情報の削除
if (!$objSitemapHandler->delete_entry_page($PID, WORK_TABLE)) {
	$objCnc->rollback();
	user_error('編集サイトマップ設定の削除に失敗しました。');
}

// 大規模災害用分類ページ情報の削除
if (!$obj_dis_handle->deleteDisasterListTop($PID, WORK_TABLE)) {
	$objCnc->rollback();
	user_error('編集大規模災害用分類ページ情報の削除に失敗しました。');
}

// イベントカレンダー複数日
if (EVENT_CAL_MULTI_FLAG) {
	// 開催日の削除
	if (!$obj_event->delete($PID, WORK_TABLE)) {
		$objCnc->rollback();
		user_error('開催期間の削除に失敗しました。');
	}
}

// オープンデータ
if (!$obj_open_data->deleteFromID($PID, '', '', '', WORK_TABLE)) {
	$objCnc->rollback();
	user_error('オープンデータ編集情報の削除に失敗しました。');
}

// 新規ページの場合：公開情報の削除、htmlファイルの削除
if ($fld['work_class'] == 1) {
	
	if (publishRegFAQ($PID, "del") === FALSE) {
		$objCnc->rollback();
		user_error('FAQ情報の更新に失敗しました。');
	}
	
	// 緊急情報　紐付け情報削除
	if (!deleteDisasterPage($PID)) {
		$objCnc->rollback();
		user_error('緊急情報ページ情報の削除に失敗しました。');
	}
	
	// 大規模災害用分類一覧ページ作成情報の削除
	if (!deleteDisasterListPage($fld['page_id'])) {
		user_error('大規模災害用分類一覧ページ作成情報の削除に失敗しました。');
	}
	
	// 大規模災害用分類ページ情報の削除
	if (!$obj_dis_handle->deleteDisasterListTop($PID, PUBLISH_TABLE)) {
		$objCnc->rollback();
		user_error('大規模災害用分類ページ情報の削除に失敗しました。');
	}
	
	if (!$objPage->deleteFromPageID($PID, PUBLISH_TABLE)) { // （DELETE FROM tbl_publish_page）
		$objCnc->rollback();
		user_error('公開ページ情報の削除に失敗しました。');
	}
	$sql = "UPDATE tbl_category SET faqpage_id = NULL" . " WHERE faqpage_id IS NOT NULL AND faqpage_id = " . $PID;
	if (!$objDac->execute($sql)) {
		$objCnc->rollback();
		user_error('FAQ一覧ページ設定の削除に失敗しました。');
	}
	
	//FLASH動画
	if (isset($_POST['cms_template_id'])) $kanko_type = $objTool->selectTemplateKankoType($_POST['cms_template_id']);
	else if (isset($fld['template_id'])) $kanko_type = $objTool->selectTemplateKankoType($fld['template_id']);
	else $kanko_type = "";
	if ($kanko_type != "" && $kanko_type == KANKO_TYPE_FLASH_VIDEO) {
		//一時フォルダが存在したら、削除する
		if (!removeDir(DOCUMENT_ROOT . DIR_PATH_FLASH_VIDEO . $PID)) {
			$objCnc->rollback();
			user_error('フォルダの削除に失敗しました。【' . DOCUMENT_ROOT . DIR_PATH_FLASH_VIDEO . $PID . '】');
		}
		//FlashVideoフォルダが存在したら、削除する
		if (!removeDir(DOCUMENT_ROOT . RPW . FLASH_VIDEO_DIR . '/' . $PID)) {
			$objCnc->rollback();
			user_error('フォルダの削除に失敗しました。【' . DOCUMENT_ROOT . RPW . FLASH_VIDEO_DIR . '/' . $PID . '】');
		}
	}
	
	//定型情報があるページかチェック
	if (!isset($fld) && isset($_POST['cms_template_id'])) {
		$fld = array(
				'template_id' => $_POST['cms_template_id']
		);
	}
	//定型情報があるページの場合
	if (isFixed($fld)) {
		//CMS内のサムネイル画像を削除
		if (deleteThumbnail_CMS($PID) === FALSE) {
			$objCnc->rollback();
			user_error('サムネイル画像の削除に失敗しました。【' . $PID . '】');
		}
	}
	
	// 公開対象ページ情報配列
	$public_page_ary = array();
	// メニュー生成順配列
	$menu_generation_order_ary = array();
	
	// 削除されるページ情報
	$delete_pid  = $fld['page_id'];
	$delete_path = $fld['file_path'];
	// 正規表現用
	$reg_path    = reg_replace($delete_path);
	
	// パンくず修正対象ページ取得用SQL
	$where = $objPage->_addslashesC('ancestor_path', '%' . $delete_path . '%', 'LIKE', 'TEXT');
	$field = "*";
	$order = "menu_generation_order";
	
	// パンくず修正対象ページ取得
	$objPage->setTableName(PUBLISH_TABLE);
	$objPage->select($where, $field, $order);
	
	// 取得ページ数分を処理
	while ($objPage->fetch()) {
		// 作業の取り消しページはスキップ
		if ($objPage->fld['page_id'] == $delete_pid) {
			continue;
		}
		
		// パンくずの修正
		$ancestor_path = $objPage->fld['ancestor_path'];
		$ancestor_path = preg_replace('/^' . $reg_path . '(,)*/', '', $ancestor_path);
		$ancestor_path = preg_replace('/,' . $reg_path . '/', '', $ancestor_path);
		$ancestor_path = preg_replace("/^(,)*/", '', $ancestor_path);
		$ancestor_path = preg_replace("/(,)*$/", '', $ancestor_path);
		
		// 親ページに変更がない場合はスキップ
		if ($objPage->fld['ancestor_path'] == $ancestor_path) {
			continue;
		}
		
		// パンくず変更後の親ページパスを取得
		$ancestor_path_ary = (array)explode(',', $ancestor_path);
		$parent_path = end($ancestor_path_ary);
		// パンくず変更後の親ページIDを取得
		if ($parent_path != "" && !$objPage2->selectFromPath($parent_path, PUBLISH_TABLE, 'page_id')) {
			$objCnc->rollback();
			user_error('親ページ情報の取得に失敗しました。【' . $objPage->fld['page_id'] . '】');
		}
		
		// DB更新用配列
		$ary = array(
				'page_id' => $objPage->fld['page_id'], 
				'parent_id' => ($parent_path != "" ? $objPage2->fld['page_id'] : ''), 
		);
		
		// 親ページなし
		// メニュー生成順配列が作成されていない
		if ($ary['parent_id'] == "" || !isset($menu_generation_order_ary[$ary['parent_id']])) {
			// メニュー生成順を取得
			if (($ary['menu_generation_order'] = $objPage2->getNextMenuGenerationOrder($ary['parent_id'])) === FALSE) {
				$objCnc->rollback();
				user_error('メニュー生成表示順の取得に失敗しました。【' . $objPage->fld['page_id'] . '】');
			}
		}
		// 親ページあり
		// メニュー生成順配列が作成されている
		else {
			// メニュー生成順配列情報を使用して修正
			$menu_generation_order_rep = reg_replace($menu_generation_order_ary[$ary['parent_id']]['old']);
			$ary['menu_generation_order'] = preg_replace("/^" . $menu_generation_order_rep . "/", $menu_generation_order_ary[$ary['parent_id']]['new'], $objPage->fld['menu_generation_order']);
		}
		
		// メニュー生成順配列の作成
		$menu_generation_order_ary[$objPage->fld['page_id']] = array(
				// 変更前
				'old' => $objPage->fld['menu_generation_order'], 
				// 変更後
				'new' => $ary['menu_generation_order']
		);
		
		// 編集ページ情報の更新
		if (!$objPage2->update($ary, WORK_TABLE)) {
			$objCnc->rollback();
			user_error('編集ページ情報の更新に失敗しました。【' . $objPage->fld['page_id'] . '】');
		}
		
		// 公開ページ情報の更新
		$ary['ancestor_path'] = $ancestor_path;
		if (!$objPage2->update($ary, PUBLISH_TABLE)) {
			$objCnc->rollback();
			user_error('公開ページ情報の更新に失敗しました。【' . $objPage->fld['page_id'] . '】');
		}
		$sql = "UPDATE tbl_work_page SET parent_id=" . $objPage2->_addslashes($fld['parent_id'], 'INT') . " WHERE parent_id='" . $delete_pid . "'";
		if (!$objPage2->execute($sql)) {
			$objCnc->rollback();
			user_error('編集ページ情報の更新に失敗しました。【' . $delete_pid . '】');
		}
		// 新規以外で非公開でない場合
		if ($objPage->fld['work_class'] != WORK_CLASS_NEW && $objPage->fld['close_flg'] == FLAG_OFF) {
			// 公開対象ページに追加
			$public_page_ary[$objPage->fld['page_id']] = $objPage->fld['file_path'];
		}
	}
	
	// 公開対象ページが存在する場合
	if (count($public_page_ary) > 0) {
		// 公開対象ページ情報から重複を削除
		$public_page_ary = array_unique($public_page_ary);
		
		// FTP接続を開始する
		$ftpCnc = connectFTP("cms");
		
		// 公開対象ページの公開
		foreach ($public_page_ary as $pid => $path) {
			// ページ出力設定されていないページは公開しない
			if (is_output_html($pid) === FALSE) {
				continue;
			}
			
			// 接続が切れていたら再接続を行う
			if (isset($ftpCnc) && $ftpCnc != '') {
				if (($pwd = @ftp_pwd($ftpCnc)) === FALSE) {
					$ftpCnc = connectFTP("cms");
				}
			}
			else {
				$ftpCnc = connectFTP("cms");
			}
			
			// ページ公開
			$public_error = '';
			if (create_html($pid, $path, $objCnc, $ftpCnc, $public_error, FALSE) === FALSE) {
				$objCnc->rollback();
				user_error($public_error);
			}
		}
		
		// FTP接続を終了する
		if (FTP_UPLOAD_FLG) {
			cx_ftp_close($ftpCnc);
		}
	}
	
	// htmlファイルの削除
	@unlink(DOCUMENT_ROOT . RPW . $fld['file_path']);
	// 自動掲載用携帯テンプレートが登録されているテンプレートを使用したページだった場合htmlファイルを削除
	if ($objTool->selectTemplate($fld['template_id'])) {
		if ($objTool->fld['mobile_temp_txt'] != "") {
			@unlink(DOCUMENT_ROOT . RPW . DIR_PATH_MOBILE . $fld['file_path']);
		}
	}
	
// 更新ページ、削除ページの場合：公開情報のステータス更新
}
else {
	$ary1 = array();
	$ary1['page_id'] = $PID;
	$ary1['status'] = $fld['bak_status'];
	$ary1['bak_status'] = '';
	$ary1['work_class'] = WORK_CLASS_PUBLISH;
	$ary1['user_lock'] = '';
	if (!$objPage->update($ary1, PUBLISH_TABLE)) { // （UPDATE tbl_publish_page）
		user_error('公開ページ情報のステータス更新に失敗しました。');
	}
}

$w_file_path = $w_fld['file_path'];
// 保存先の変更をしようとしていたとき、キープしていたHTMLファイルを削除する
if ($w_file_path != $p_file_path) {
	@unlink(DOCUMENT_ROOT . RPW . $w_file_path);
	// 自動掲載用携帯ページファイル削除
	if ($objTool->selectTemplate($fld['template_id'])) {
		if ($objTool->fld['mobile_temp_txt'] != "") {
			@unlink(DOCUMENT_ROOT . RPW . DIR_PATH_MOBILE . $w_file_path);
		}
	}
}

// 作業中にアップロードした未使用ファイルの削除
if (isset($_POST['cms_unuse_delete']) && $_POST['cms_unuse_delete'] == FLAG_ON && isset($_SESSION['depend']['dellist'])) {
	
	// 削除(はい)を選択した場合のみ
	

	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
	$objFCKImages = new tbl_fck_images($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_links.inc');
	$objFCKLinks = new tbl_fck_links($objCnc);
	
	// エラー文章代入用
	$error_msg = "";
	// ファイル削除
	if (!filesDelete($objLinks, $objImages, $objFCKLinks, $objFCKImages, $objEnq, $objKanko, $_SESSION['depend']['dellist'], $error_msg)) {
		user_error($error_msg, E_USER_ERROR);
	}
}
// セッション情報削除
if (isset($_SESSION['depend'])) unset($_SESSION['depend']);

// ログ登録(作業の取り消し・閉じるボタン押下)
$log_flg = false;
// 閉じるボタン押下
if (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'edit_close') {
	$log_flg = WRITE_INFO_LOG_PAGEEDIT_CLOSE;
	$log_status = LOG_STATUS_PAGEEDIT_CLOSE;
}
// 作業の取り消し押下
else if (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'edit_cancel') {
	$log_flg = WRITE_INFO_LOG_PAGEEDIT_CANCEL;
	$log_status = LOG_STATUS_PAGEEDIT_CANCEL;
}
if ($log_flg) {
	if (set_log_data($log_status, $w_fld) === FALSE) {
		user_error('ログ情報の登録に失敗しました。', E_USER_ERROR);
	}
}

// コミット
$objCnc->commit();

// セッションに戻り先がセットされているときはそこに移動
if (isset($_SESSION['back_path'])) {
	header("Location: " . HTTP_ROOT . $_SESSION['back_path']);
	// ワークスペースに移動
}
elseif ($objLogin->get('class') == USER_CLASS_WEBMASTER) {
	header("Location: " . HTTP_ROOT . RPW . "/admin/page/workspace/workspace_wm.php");
}
elseif ($objLogin->get('class') == USER_CLASS_WRITER) {
	header("Location: " . HTTP_ROOT . RPW . "/admin/page/workspace/workspace.php");
}
else {
	header("Location: " . HTTP_ROOT . RPW . "/admin/page/workflow/workflow.php");
}
?>