<?php
/*
 * プレビュー
 */
require ("../.htsetting");
// 別ウィンドウ用
gd_errorhandler_ini_set("template_user_error", "template_user_error_win");
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");

$post = $_POST;

// プレビューモード取得:「sp」がついていたらスマートフォンプレビュー
if (isset($post['cms_dispMode']) && strstr($post['cms_dispMode'], 'sp')) {
	preg_match("/[0-9]+/", $post['cms_dispMode'], $match);
	$post['cms_dispMode'] = $match[0];
	$is_sp_flg = FLAG_ON;
}
else {
	$is_sp_flg = FLAG_OFF;
}

// 色覚プレビュー
if (isset($post['cms_preview_color'])) {
	$preview_color_code = (int)$post['cms_preview_color'];
}

include (APPLICATION_ROOT . "/common/inc/set_preview.inc");
include (APPLICATION_ROOT . "/common/inc/set_preview_htmlStr.inc");

if ($is_sp_flg == FLAG_ON) {
	$htmlStr = replaceSpCss($htmlStr);
}
if (isset($preview_color_code)) {
	$htmlStr = addPreviewColorJs($htmlStr, $preview_color_code);
}

// ツールバーの取得
$params['is_sp_flg'] = $is_sp_flg;
$toolbarStr = get_include_contents(APPLICATION_ROOT . "/common/inc/toolbar_preview.inc", $params);
// BODYタグにツールバーを埋め込み
$htmlStr = preg_replace('/(<body[^>]*>)/i', '${1}' . $toolbarStr . "\n", $htmlStr);

$htmlStr = setRootPath($htmlStr);

// alt="#" を alt="" に置換
$htmlStr = preg_replace('/<(img|area|input)( [^>]*)? alt="[#＃\s　]*"/i', '<${1}${2} alt=""', $htmlStr);
// Hide toolbar when print
$htmlStr = preg_replace('/<\/head>/i', '<style type="text/css">@media print{#preview-title{display: none;}}</style>' . "\n" . '</head>', $htmlStr);
// convert link image external info source base 64
if (isset($preview_color_code)) {
	$htmlStr = replaceExternalImage($htmlStr);
}
print $htmlStr;
?>