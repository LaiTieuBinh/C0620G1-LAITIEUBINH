<?php
/*
 * 公開中止
 */
require ("../.htsetting");

if (!isset($_POST['cms_page_id'])) {
	user_error("It isn't setted cms_page_id in _post.", E_USER_ERROR);
}
$PID = $_POST['cms_page_id'];

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_contents_group.inc');
$objCGrp = new tbl_contents_group($objCnc);

// ページ情報を取得
if ($objPage->selectFromID($PID, 2) === FALSE) {
	user_error("このページはすでに公開済みか公開中止が行われました。");
}
// ページが公開待ちで無い場合
if ($objPage->fld['status'] != STATUS_PUBLISH_WAIT) {
	user_error("このページは、現在公開待ちではありません。");
}
$work_class = $objPage->fld['work_class'];
$template_id = $objPage->fld['template_id'];
$group_id = $objPage->fld['group_id'];
// テンプレート情報を取得
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
if ($objTool->selectTemplate($template_id) === FALSE) {
	user_error("dac execute error. <br>tbl_tools->selectTemplate(" . $template_id . ");", E_USER_ERROR);
}
$approve_id = $objTool->fld['approve_id'];

$objCnc->begin();

// 公開情報を更新
$ary1 = array();
$ary1['page_id'] = $PID;
$ary1['status'] = ($work_class == 3) ? 202 : 201;
if ($objPage->update($ary1, PUBLISH_TABLE) === FALSE) {
	$objCnc->rollback();
	user_error("公開ページ情報の更新に失敗しました。");
}
// 編集情報を更新
$ary1['approve_id'] = $approve_id;
$ary1['group_id'] = '';
if ($objPage->fld['user_class'] != USER_CLASS_WEBMASTER) {
	$ary1['publish_start'] = '';
	$ary1['publish_end'] = '';
}
else {
	$ary1['publish_start'] = date("Y-m-d");
	$ary1['publish_end'] = date("Y-m-d", strtotime("+3 year"));
}
if ($objPage->update($ary1, WORK_TABLE) === FALSE) {
	$objCnc->rollback();
	user_error("編集ページ情報の更新に失敗しました。");
}
// 承認依頼グループを削除
if ($objCGrp->deleteFromID($group_id) === FALSE) {
	$objCnc->rollback();
	user_error("承認依頼情報の削除に失敗しました。");
}
// ログ登録(公開中止)
if(WRITE_INFO_LOG_PUB_CANCEL){
	if(set_log_data(LOG_STATUS_PUB_CANCEL, $PID, WORK_TABLE) === FALSE){
		$objCnc->rollback();
		user_error("ログ情報の登録に失敗しました。");
	}
}

$objCnc->commit();

if ($objLogin->get('class') == USER_CLASS_WRITER && $objLogin->get('isRegain') === FALSE) {
	header("Location: " . HTTP_ROOT . RPW . "/admin/page/workspace/workspace.php");
}
else {
	header("Location: " . HTTP_ROOT . RPW . "/admin/page/workflow/workflow.php");
}
?>