<?php
/*
 *
 */
require ("./.htsetting");
/*
$files[*][0]	-->>	リンクタイトル
$files[*]			-->>	アップロードファイル	*$_FILES['files'][1]
$files[*][1]	-->>	（ファイル形式：ファイルサイズKB）
$files[*][2]	-->>	リンクパス
$files[*][3]	-->>	削除フラグ（1:削除対象）
$files[*][4]	-->>	0:新規　1:更新
*/
//定義パラメータ
//生成HTMLフォーマット
$retHtml = '{LI_START}' . '{LINK}' . '<input type="hidden" name="files[{ID}][0]" value="{TEXT}">' . '<input type="hidden" name="files[{ID}][1]" value="{EXTSIZE}">' . '<input type="hidden" name="files[{ID}][2]" value="{PATH}">' . '<input type="hidden" name="files[{ID}][3]" value="{DEL}">' . '{LI_END}';

//CHECK
if (!isset($_POST['files'])) {
	user_error('指定ファイルのファイルサイズが大きすぎる可能性があります。');
}

//GET
$data = $_POST['files'];
$upfile = (isset($_FILES['files'])) ? $_FILES['files'] : FALSE;
$dir_path = DOCUMENT_ROOT . RPW . $_POST['path']; //アップロードディレクトリパス
$lnk_path = $_POST['path']; //リンク用ディレクトリパス（公開パス）
$html_file = $_POST['html']; //設定対象HTMLファイル名
//
$html = ''; //戻り値生成
$cnt = 0; //作業用カウント
$e_cnt = 0; //枝番取得用カウント
$d_cnt = 0; //削除判別用カウント
//
for($i = 0; $i < count($data); $i++) {
	$flg = $data[$i][4];
	$text = ($data[$i][0]) ? htmlDisplay($data[$i][0]) : '';
	$text = preg_replace('/\'/', '\\\'', $text);
	//
	if ($text == '' && $flg == 0) {
		continue; //リンクテキストが空、新規の場合は無視
	}
	//ファイルアップロード
	if (isset($upfile['name'][$i]) && $upfile['name'][$i] != '') {
		//拡張子取得
		if (preg_match('/\.([^\.]*)$/i', $upfile['name'][$i], $matches)) {
			$ext = $matches[1];
		}
		//ファイルサイズ取得（単位：KB）
		if ($upfile['size'][$i] <= 0) {
			user_error('指定ファイルのファイルサイズが大きすぎる可能性があります。');
		}
		$size = round($upfile['size'][$i] / 1024);
		//拡張子＋ファイルサイズラベル生成
		$extsize = createEXTSIZE($ext, $size);
		//添付資料ディレクトリ取得
		$tmpdir = setExtDir($ext);
		//リンクパス
		//*枝番用文字コード
		$tmp_code = $e_cnt + 1;
		$eda = ($tmp_code < 10) ? '0' . $tmp_code : $tmp_code;
		$filename = $html_file . "-" . $eda . "." . $ext;
		$path = $lnk_path . $tmpdir . $filename;
		//*ディレクトリの作成
		$up_dir_path = $dir_path . $tmpdir; //アップロードディレクトリ
		if (!@file_exists($up_dir_path)) {
			if (!@mkdir($up_dir_path, 0777)) {
				user_error('フォルダの作成に失敗しました。');
			}
		}
		//アップロード
		$tmp_file = $upfile['tmp_name'][$i];
		$upd_file = $up_dir_path . $filename;
		if (!move_uploaded_file($tmp_file, $upd_file)) {
			user_error('ファイルのアップロードに失敗しました。');
		}
		;
		if (!chmod($upd_file, 0777)) {
			user_error('パーミッションの変更に失敗しました。');
		}
	}
	else {
		//ファイルアップロードしない場合は、元の設定値を取得
		$extsize = $data[$i][1];
		$path = $data[$i][2];
	}
	//
	$del = (isset($data[$i][3]) && $data[$i][3] == 1) ? 1 : 0;
	if ($text != '') {
		$atag = '<a href="#">' . $text . $extsize . '</a>';
		$li_start = '<li>';
		$li_end = '</li>';
	}
	else {
		$atag = '';
		$li_start = '';
		$li_end = '';
	}
	if ($del == 1) {
		$li_start = '<li style="display:none">';
		$li_end = '</li>';
		$d_cnt++;
	}
	//
	if ($flg == 1 && $text == '' && $extsize == '' && $del == 0) {
		$e_cnt++;
		continue;
	}
	//
	$html .= $retHtml;
	$html = preg_replace('/{ID}/', $cnt, $html);
	$html = preg_replace('/{LI_START}/', $li_start, $html);
	$html = preg_replace('/{LI_END}/', $li_end, $html);
	$html = preg_replace('/{LINK}/', $atag, $html);
	$html = preg_replace('/{TEXT}/', $text, $html);
	$html = preg_replace('/{EXTSIZE}/', $extsize, $html);
	$html = preg_replace('/{PATH}/', $path, $html);
	$html = preg_replace('/{DEL}/', $del, $html);
	//
	$cnt++;
	$e_cnt++;
}
if ($cnt == $d_cnt) {
	$html .= '現在、添付資料は設定されていません。';
}

//// function /////////////////////////////////////////////////////////////
//** リンクテキストに付加する（ファイル形式：ファイルサイズKB）を生成
function createEXTSIZE($ext, $size) {
	switch ($ext) {
		case 'doc' :
		case 'docx' :
			$ext_kind = 'ワード';
			break;
		case 'xls' :
		case 'xlsx' :
			$ext_kind = 'エクセル';
			break;
		case 'txt' :
			$ext_kind = 'テキスト';
			break;
		case 'jtd' :
			$ext_kind = '一太郎';
			break;
		default :
			$ext_kind = strtoupper($ext);
			break;
	}
	$size = number_format($size);
	return '（' . $ext_kind . '：' . $size . 'KB）';
}

//** 拡張子別ディレクトリパス設定
function setExtDir($ext) {
	switch ($ext) {
		case 'pdf' :
			$tmpdir = 'pdf/';
			break;
		case 'jpg' :
		case 'gif' :
		case 'jpeg' :
		case 'png' :
			$tmpdir = 'img/';
			break;
		default :
			$tmpdir = 'other/';
			break;
	}
	return $tmpdir;
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>添付資料設定単体連携テスト</title>
<script type="text/javascript">
<!--
	var html = '<?=$html?>';
	var obj = window.opener.document.getElementById('tempfileslist');
	obj.innerHTML = html;
	window.close();
//-->
</script>
</head>

<body>
<h1>添付資料設定単体連携テスト</h1>
<ul>
	<?=$html?>
</ul>
</body>
</html>
