<?php
/*
 *
 */
require ("./.htsetting");
$path = $_GET['path'];
$html = $_GET['html'];
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>添付資料設定</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<style type="text/css">
#cms8341-listarea {
	margin: 10px 10px;
	background-color: #FFFFFF;
	padding: 0px;
	text-align: left;
	border: solid 1px #999999;
	font-size: 14px;
}

body {
	background-color: #DFDFDF;
}

form {
	margin: 0px;
}

table.data {
	border: solid 1px #666;
	font-size: 90%;
	margin-bottom: 2px;
}

td.data {
	border-left: solid 1px #666;
}
</style>
<script type="text/javascript">
<!--
//枝番コードより項目順を取得（ゼロ番スタート）
function getEdaCode(path) {
	var tmp_f = path.split('/');
	var fn = tmp_f.pop();
	var flg = fn.replace(/^\d{6}(_\d+)?-(\d{2})\.[^.]*/i, function($0,$1,$2) {
																											return $2;
																										 });
	return flg - 1;
}

//削除フラグによるグレーアウト制御
function grayOut(obj) {
	var param = obj._param;
	var flg = obj.checked;
	var div = document.getElementById(param);
	if(flg) {
		//document.getElementById('text'+param).disabled = true;
		document.getElementById('text'+param).style.imeMode = 'disabled';
		document.getElementById('text'+param).style.color = '#ACA899';
		document.getElementById('file'+param).disabled = true;
		div.style.backgroundColor = '#CCCCCC';
	} else {
		//document.getElementById('text'+param).disabled = false;
		document.getElementById('text'+param).style.imeMode = '';
		document.getElementById('text'+param).style.color = '';
		document.getElementById('file'+param).disabled = false;
		div.style.backgroundColor = '';
	}
}

function lock(id) {
	if(!document.getElementById('del'+id)) return true;
	var d = document.getElementById('del'+id).checked;
	return (d)? false : true;
}

//添付資料項目フォームの追加
function itemAdd() {
	var obj = document.getElementById('list');
	var num = obj.childNodes.length;
	createItemHtml(num,false,0);
}

//画面描画用HTML生成
function createItemHtml(id,ary,flg) {
	var fmt;
	var root_path = '<?=RPW?>';
	fmt  = '<table width="100%" cellspacing="0" cellpadding="3" border="0" class="data">';
	fmt += '<tr>';
	fmt += '<td align="left" valign="middle">';
	fmt += '<table cellspacing="0" cellpadding="3" border="0">';
	fmt += '<tr>';
	fmt += '<td align="left" valign="middle">添付資料タイトル</td>';
	fmt += '<td align="left" valign="middle">';
	fmt += '<input type="text" name="files[{ID}][0]" size="40" value="{TEXT}" id="text{ID}" onkeydown="return lock({ID})">';
	fmt += '</td>';
	fmt += '</tr>';
	fmt += '<tr>';
	fmt += '<td align="left" valign="middle">添付資料ファイル</td>';
	fmt += '<td align="left" valign="middle">';
	fmt += '<input type="file" name="files[{ID}]" size="40" id="file{ID}">';
	fmt += '</td>';
	fmt += '</tr>';
	fmt += '{CNF_AREA}';
	fmt += '</table>';
	fmt += '</td>';
	fmt += '<td align="center" valign="middle" width="100" class="data">';
	fmt += '{DEL_AREA}';
	fmt += '</td>';
	fmt += '</tr>';
	fmt += '</table>';
	fmt += '<input type="hidden" name="files[{ID}][1]" value="{EXTSIZE}" id="ext{ID}">';
	fmt += '<input type="hidden" name="files[{ID}][2]" value="{PATH}" id="path{ID}">';
	fmt += '<input type="hidden" name="files[{ID}][4]" value="'+flg+'" id="flg{ID}">';	//0:新規　1:既存
	var del = '<input type="checkbox" name="files[{ID}][3]" value="1" _param={ID} onclick="grayOut(this)" {DEL} id="del{ID}"><label for="del{ID}">削除</label>';
	var cnf = '<tr><td>&nbsp;</td><td align="left"><a href="'+root_path+'{PATH}" target="_blank">'+root_path+'{PATH}</a></td></tr>';
	
	if(!ary) ary = new Array();
	
	var div = document.createElement('div');
	div.id = id;
	var html = fmt;
	html = html.replace(/{ID}/g,id);
//2007.09.25 T.Ohishi Fix
	var title = (ary['text'])? ary['text'].replace(/"/g,'&quot;') : '';
	html = (ary['text'])? html.replace(/{TEXT}/g,title) : html.replace(/{TEXT}/g,'');
	//html = (ary['text'])? html.replace(/{TEXT}/g,ary['text']) : html.replace(/{TEXT}/g,'');
//2007.09.25 T.Ohishi Fix
	html = (ary['extsize'])? html.replace(/{EXTSIZE}/g,ary['extsize']) : html.replace(/{EXTSIZE}/g,'');
	html = (ary['path'])? html.replace(/{PATH}/g,ary['path']) : html.replace(/{PATH}/g,'');
	if(ary['del']==1) {
		del = del.replace(/{DEL}/g,' checked="checked"');
		del = del.replace(/{ID}/g,id);
		html = html.replace(/{DEL_AREA}/,del);
		html = html.replace(/{STYLE}/,'background-color:#CCCCCC');
	} else if(ary['del']==0) {
		del = del.replace(/{DEL}/g,'');
		del = del.replace(/{ID}/g,id);
		html = html.replace(/{DEL_AREA}/,del);
		html = html.replace(/{STYLE}/,'');
	} else {
		del = false;
		html = html.replace(/{DEL_AREA}/,'&nbsp;');
		html = html.replace(/{STYLE}/,'');
	}
	if(ary['path']) {
		cnf = cnf.replace(/{PATH}/g,ary['path']);
		html = html.replace(/{CNF_AREA}/,cnf);
	} else {
		html = html.replace(/{CNF_AREA}/,'');
	}
	div.innerHTML = html;
	var obj = document.getElementById('list');
	list.appendChild(div);
	if(ary['del']==1) {
		document.getElementById('text'+id).style.imeMode = 'disabled';
		document.getElementById('text'+id).style.color = '#ACA899';
		document.getElementById('file'+id).disabled = true;
		div.style.backgroundColor = '#CCCCCC';
	}
}

//拡張子チェック
function extCheck(str) {
	return str.match(/[^\.]*\.(php(\d)?|phtml|pwml|inc|asp|aspx|ascx|jsp|cfm|cfc|pl|bat|exe|com|dll|vbs|js|reg|cgi|html|htm)$/g);
}
//機種依存文字チェック
function machineCheck(str) {
	var obj = document.getElementById('cms_accessibility_check_2_w');
	if(!obj) return false;
	//var pattern = '[№℡ⅠⅰⅡⅱⅢⅲⅣⅳⅤⅴⅥⅵⅦⅶⅧⅷⅨⅸⅩⅹⅪⅺⅫⅻ①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳㈱㈲㈹㍻㍼㍽㍾㎎㎏㎜㎝㎞㎡㎥]';
	var pattern = '['+obj.innerHTML+']';
	return str.match(pattern);
}
//半角カナチェック
function kanaCheck(str) {
	var obj = document.getElementById('cms_accessibility_check_9_w');
	if(!obj) return false;
	//var pattern = '[｡｢｣､･ｦｧｨｩｪｫｬｭｮｯｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ￥]';
	var pattern = '['+obj.innerHTML+']';
	return str.match(pattern);
}
//英数字チェック
function charaCheck(str) {
	var obj = document.getElementById('cms_accessibility_check_8_w');
	if(!obj) return false;
	//var pattern = '[０１２３４５６７８９ＡａＢｂＣｃＤｄＥｅＦｆＧｇＨｈＩｉＪｊＫｋＬｌＭｍＮｎＯｏＰｐＱｑＲｒＳｓＴｔＵｕＶｖＷｗＸｘＹｙＺｚ]';
	var pattern = '['+obj.innerHTML+']';
	return str.match(pattern);
}

//サブミットチェック
function check() {
	var obj = document.getElementById('list');
	var num = obj.childNodes.length;
	var m_err = 0;	//機種依存文字エラーカウント
	var k_err = 0;	//半角カナ文字エラーカウント
	var c_err = 0;	//全角英数字エラーカウント
	for(var i=0;i<num;i++) {
		var text = document.getElementById('text'+i).value;
		var file = document.getElementById('file'+i).value;
		var path = document.getElementById('path'+i).value;
		//妥当性チェック（両方空か両方指定済み）
		if(!path) {
			if(text && !file) {
				alert('リンクテキストが指定されているが、リンクファイルが指定されていない項目があります。');
				document.getElementById('file'+i).focus();
				return false;
			}
			if(!text && file) {
				alert('リンクファイルが指定されているが、リンクテキストが指定されていない項目があります。');
				document.getElementById('text'+i).focus();
				return false;
			}
		} else {
			if(!text) {
				alert('リンクテキストが指定されていない項目があります。');
				document.getElementById('text'+i).focus();
				return false;
			}
		}
		//拡張子
		if(extCheck(file)) {
			alert('リンクファイルに指定されている形式のファイルはアップロードすることはできません。');
			return false;
		}
		//機種依存文字
		if(machineCheck(text)) {
			m_err++;
		}
		//半角カナ
		if(kanaCheck(text)) {
			k_err++;
		}
		//全角英数字
		if(charaCheck(text)) {
			c_err++;
		}
	}
	var err_msg = '';
	if(m_err>0) {
		err_msg += '文字化けの原因となる機種依存が含まれています。';
	}
	if(k_err>0) {
		if(err_msg!='') err_msg += '\n';
		err_msg += '文字化けの原因となる半角カナ文字が含まれています。';
	}
	if(c_err>0) {
		if(err_msg!='') err_msg += '\n';
		err_msg += '全角英数字が含まれています。';
	}
	if(err_msg!='') {
		err_msg += '\nよろしいですか？';
		var r = confirm(err_msg);
		if(!r) return false;
	}
	return true;
}

window.onload = function() {
	var datAry = new Array();
	var obj = window.opener.document.getElementById('tempfileslist');
	var li = obj.getElementsByTagName('li');
	var datCnt = li.length;
	if(datCnt>0) {
		for(var i=0;i<datCnt;i++) {
			var item = li[i].getElementsByTagName('input');
			var data = new Array();
			for(var j=0;j<item.length;j++) {
				var __name = item[j].name;
				if(__name.match(/files\[\d+\]\[0\]/)) data['text'] = item[j].value;
				if(__name.match(/files\[\d+\]\[1\]/)) data['extsize'] = item[j].value;
				if(__name.match(/files\[\d+\]\[2\]/)) {
					data['path'] = item[j].value;
					var num = getEdaCode(item[j].value);
				}
				if(__name.match(/files\[\d+\]\[3\]/)) data['del'] = item[j].value;
			}
			datAry[num] = data;
		}
		
		for(var k=0;k<datAry.length;k++) {
			createItemHtml(k,datAry[k],1);
		}
	} else {
		createItemHtml(0,false,0);
	}
}
//-->
</script>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="100%" align="center" valign="top">
		<table width="100%" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/page/common/tmpfile/images/title_tmpfile.jpg"
					alt="添付ファイル設定" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return window.close()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>

		<form action="upload.php" method="post" enctype="multipart/form-data"
			onsubmit="return check()">

		<div id="cms8341-listarea">
		<div align="center">
		<table width="609" border="0" cellspacing="0" cellpadding="10">
			<tr>
				<td align="left" valign="top">
				<div id="list"></div>
				<p align="right"><a href="#"><img src="images/btn_add.jpg"
					width="100" height="20" alt="添付資料追加" border="0" onclick="itemAdd()"
					id="addbtn"></a></p>
				<p align="center"><input type="image" src="images/btn_submit.jpg"
					alt="設定"></p>
				</td>
			</tr>
		</table>
		</div>
		</div>
		<input type="hidden" name="path" value="<?=$path?>"> <input
			type="hidden" name="html" value="<?=$html?>"></form>
		<!-- アクセシビリティチェック文字列 START -->
<?php
echo $objTool->setAccessibility();
?>
<!-- アクセシビリティチェック文字列 END -->

</body>
</html>
