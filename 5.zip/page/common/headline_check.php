<?php
/*
 *
 */
/** プレビュー **/
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

// 別ウィンドウ用
gd_errorhandler_ini_set("template_user_error", "template_user_error_win");
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");

$post = $_POST;
include (APPLICATION_ROOT . "/common/inc/set_preview.inc");
include (APPLICATION_ROOT . "/common/inc/set_preview_htmlStr.inc");

$htmlStr = setRootPath($htmlStr);

// IFRAMEタグを消去
$htmlStr = preg_replace('/<iframe(\s[^>]*>|>)(?:.|\n)*?<\/iframe>/i','', $htmlStr);

// alt="#" を alt="" に置換
$htmlStr = preg_replace('/<(img|area|input)( [^>]*)? alt="[#＃\s　]*"/i', '<${1}${2} alt=""', $htmlStr);
// SCRIPTタグを消去
//$htmlStr = preg_replace('/<script[^>]*>.*<\/script>/i','', $htmlStr);
// ONLOADを消去
$htmlStr = preg_replace('/onload="[^"]*"/i', '', $htmlStr);
$htmlStr = preg_replace('/.*\.onload.*/i', '', $htmlStr);
$htmlStr = preg_replace('/<script.*<\/script>/i', '', $htmlStr);
$p = 0;
while (getMidString($htmlStr, "<script", "</script>", $p) !== FALSE) {
	$hitStr = getMidString($htmlStr, "<script", "</script>", $p);
	$htmlStr = str_replace("<script" . $hitStr . "</script>", "", $htmlStr);
	$p++;
}

// 各種チェック設定情報取得
$objDac->setTableName("tbl_check_config");
$where = $objDac->_addslashesC("class", CHECK_CLASS_HEADER);
$objDac->select($where);
$header_check_flg = FLAG_ON;
while ($objDac->fetch()) {
	$header_check_flg = $objDac->fld['check_flg'];
}

//見出しチェック用CSS挿入
$headline_css = '<link rel="stylesheet" href="' . RPW . '/admin/style/shared.css" type="text/css">' . "\n";
$headline_css .= '<link rel="stylesheet" href="' . RPW . '/admin/style/headline.css" type="text/css">' . "\n";
$htmlStr = preg_replace('/<\/head>/i', $headline_css . '</head>', $htmlStr);
//見出しチェック用JavaScript挿入
$headline_js = '<script type="text/javascript" src="' . RPW . '/admin/js/headlinechecker.js"></script>' . "\n";
$headline_js .= '<script type="text/javascript">' . "\n";
// ページプロパティのページタイトルを取得
$page_title = (isset($pv_fld['page_title']) ? htmlspecialchars($pv_fld['page_title']) : '');
$headline_js .= 'var page_title = "' . $page_title . '";' . "\n";
$headline_js .= 'var header_check_flg = "' . $header_check_flg . '";' . "\n";
$headline_js .= 'var headline = new HeadlineChecker(page_title);' . "\n";
$headline_js .= '</script>' . "\n";
$htmlStr = preg_replace('/(<\/body>)/i', $headline_js . "\n" . '${1}', $htmlStr);
$htmlStr = preg_replace('/<body([^>]*)>/i', '<body${1} style="display:none">', $htmlStr);

//見出しチェック時のみタイトルをエスケープする
if(($title_str = getMidString($htmlStr,'<title>','</title>')) !== FALSE){
	$htmlStr = str_replace('<title>' . $title_str . '</title>', '<title>' . htmlDisplay($title_str, 'convert_space') . '</title>', $htmlStr);
}

print $htmlStr;
?>