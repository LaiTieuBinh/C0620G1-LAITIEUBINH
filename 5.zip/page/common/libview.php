<?php
/*
 *
 */
/** require **/
require ("../.htsetting");
//
function lbyError($msg) {
	$err = "<html>\n" . "<head>\n" . "<title>ライブラリプレビューエラー</title>\n" . "</head>\n" . "<body>\n" . "<script>\n" . "alert('" . $msg . "')\n" . "window.close();\n" . "</script>\n" . "</body>\n" . "</html>\n";
	print $err;
	exit();
}
//
if (!isset($_GET["id"]) || $_GET["id"] == "") {
	$msg = "パラメータに誤りがあります。";
	lbyError($msg);
}

$headStr = "";
//テンプレートIDが指定されている場合は、ライブラリ用のCSSを取得するため、テンプレート情報を取得
if (isset($_GET["tpl_id"]) && $_GET["tpl_id"] != "") {
	$template_id = $_GET["tpl_id"];
	require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
	$objTool = new dac_tools($objCnc);
	if (!$objTool->selectTemplate($template_id)) {
		$msg = "テンプレート情報が取得できませんでした。";
		lbyError($msg);
	}
	
	$template_path = DOCUMENT_ROOT . DIR_PATH_TEMPLATE . $objTool->fld['temp_txt'];
	if (!file_exists($template_path)) {
		$msg = "対象のテンプレートが存在しません。";
		lbyError($msg);
	}
	$fp = fopen($template_path, "r");
	$htmlStr = fread($fp, filesize($template_path));
	fclose($fp);
	$htmlStr_split = explode("<body", $htmlStr);
	$headStr = $htmlStr_split[0];
}

//エディタ用CSSが指定されている場合は、パーツ用のCSSを取得する
if (isset($_GET["editor_css"]) && $_GET["editor_css"] != "") {
	$headStr = '<html><head><link rel="stylesheet" type="text/css" href="' . $_GET["editor_css"] . '"></head>';
}

$library_id = $_GET["id"];
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_library.inc');
$objLibrary = new tbl_library($objCnc);
if (!$objLibrary->selectFromID($library_id)) {
	$msg = "ライブラリ情報が取得できませんでした。";
	lbyError($msg);
}
else {
	$context = $objLibrary->fld['context'];
	
	//ヘッダ情報がない場合は、CSSを適用せずに表示する
	if ($headStr == "") {
		$html = "<html><body><div>" . $context . "</div></body></html>";
	}
	else {
		$html = $headStr . "<body><div>" . $context . "</div></body></html>";
	}
	// イベントの無効化
	if (isset($_GET['non_event']) && $_GET['non_event'] == 1) {
		$html = del_escapes($html);
		$html = repNonEvent($html);
	}
	print $html;
}
?>