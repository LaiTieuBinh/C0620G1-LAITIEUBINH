<?php
/*
 *
 */
/** プレビュー **/
require ("../.htsetting");

// 親ページ設定用のインクルードファイルを読み込み
require_once (DOCUMENT_ROOT . RPW . '/admin/page/common/pankuzu_set/pankuzu_set_common.inc');

global $objCnc;
if (isset($_SESSION['page']['pankuzu_set'])) unset($_SESSION['page']['pankuzu_set']);
// 別ウィンドウ用
//	gd_errorhandler_ini_set("template_user_error", "template_user_error_win");
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");

if (isset($_POST) && count($_POST) > 0) $post = $_POST;
if (isset($_GET['pid']) && $_GET['pid'] != '') $post['cms_page_id'] = $_GET['pid'];
// 編集中ページIDを保持する
if (isset($_GET['edit_pid']) && $_GET['edit_pid'] != '') {
	$edit_page_id = $_GET['edit_pid'];
	$_SESSION['page']['edit_page_id'] = $_GET['edit_pid'];
}
elseif (isset($_SESSION['page']['edit_page_id']) && $_SESSION['page']['edit_page_id'] != "") {
	$edit_page_id = $_SESSION['page']['edit_page_id'];
}
else {
	$edit_page_id = "";
}
if (!isset($post) || !isset($_SESSION['cms_pankuzu_id'])) {
	user_error('ページを表示できません');
}

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
if ($objPage->selectFromID($post['cms_page_id'], 1, 'p.work_class, p.status, p.user_id, p.file_path') === FALSE) {
	if ($objPage->selectFromPath(SITE_TOP_PAGE) === FALSE) {
		user_error("dac execute error. <br>tbl_page->selectFromID(" . $post['cms_page_id'] . ", 1);", E_USER_ERROR);
	}
	$post['cms_page_id'] = $objPage->fld['page_id'];
}
$fld = $objPage->fld;

//新規以外は、公開中の情報を表示
if ($fld['work_class'] != WORK_CLASS_NEW) $dispMode = PUBLISH_TABLE;
//新規の場合
else {
	//ページ作成者 or ウェブマスターの場合
	if ($fld['user_id'] == $objLogin->get('user_id') || $objLogin->get('class') == USER_CLASS_WEBMASTER) $dispMode = WORK_TABLE;
	//他のページ作成者
	else {
		//サイトトップページを表示
		if ($objPage->selectFromPath(SITE_TOP_PAGE) === FALSE) user_error("ページが見つかりません", E_USER_ERROR);
		$fld = $objPage->fld;
		//サイトトップページが公開されている場合
		if ($fld['work_class'] != WORK_CLASS_NEW) $dispMode = PUBLISH_TABLE;
		//サイトトップページが公開されていない場合
		else user_error('ページを表示できません', E_USER_ERROR);
	}
}

$post['cms_dispMode'] = $dispMode;
// プレビュー情報をセットする
include (APPLICATION_ROOT . "/common/inc/set_preview.inc");

// イベントを無効化する
$event_flg = FLAG_ON;

// プレビューを生成する
include (APPLICATION_ROOT . "/common/inc/set_preview_htmlStr.inc");

// フォーム
$form_start = '<form name="cms_fPanset" id="cms_fPanset" class="cms8341-form" method="post" action="" target="">' . "\n" . '<input type="hidden" name="cms_page_id" id="cms_page_id" value="' . $PID . '"></form>';

// 公開テーブルよりパンくずを取得
$pid_int = $post['cms_page_id']; // ページID　代入用
// $p_file_path = "";				// 編集中ページのファイルパス(PUBLISH_TABLE)
$error_flg = 0; // エラーフラグ


// 親ページにしようとしているページが編集中のページ
if ($post['cms_page_id'] == $_SESSION['cms_pankuzu_id']) {
	$error_flg = 1;
}
elseif (isDisasterPage($post['cms_page_id'])) {
	$error_flg = 5;
}
else {
	// 編集中のページのパス
	if ($objPage->selectFromID($_SESSION['cms_pankuzu_id'], PUBLISH_TABLE, "file_path") !== FALSE) {
		$p_file_path = $objPage->fld['file_path'];
	}
}
// エラーがない場合チェック
while ($error_flg == 0) {
	// PUBLISH_TABLE の親ページ情報チェック
	if ($objPage->selectFromID($pid_int, PUBLISH_TABLE, "ancestor_path") !== FALSE && isset($p_file_path)) {
		$ancestor_path = $objPage->fld['ancestor_path'];
		$ary['ancestor_path'] = explode(',', $ancestor_path);
		foreach ($ary['ancestor_path'] as $k => $v) {
			// 編集中のファイルパスが存在するかチェック
			if ($v == $p_file_path) {
				$error_flg = 2;
			}
			// 親ページに大規模災害ページが含まれるかチェック
			if ($objPage->selectFromPath($v) && isDisasterPage($objPage->fld['page_id'])) {
				$error_flg = 5;
			}
		
		}
	}
	// WORK_TABLE の親ページ情報チェック
	if ($objPage->selectFromID($pid_int, WORK_TABLE, "parent_id , file_path") !== FALSE && isset($p_file_path)) {
		// WORK_TABLE
		$pid_int = $objPage->fld['parent_id'];
		if ($objPage->selectFromID($pid_int) !== FALSE) {
			if ($p_file_path == $objPage->fld['file_path']) {
				$error_flg = 2;
			}
			// 親ページに大規模災害ページが含まれるかチェック
			if (isDisasterPage($pid_int)) {
				$error_flg = 5;
			}
		
		}
		else {
			break;
		}
		continue;
	}
	break;
}

if ($post['cms_page_id'] != $edit_page_id && $error_flg == 0) {
	// 親ページパスよりパンくず階層制限チェックを行う
	if (is_pankuzu_limit_over($fld['file_path'])) {
		$error_flg = 3;
	}
}
if ($edit_page_id != "" && $post['cms_page_id'] != $edit_page_id && $error_flg == 0) {
	// 末端子ページ階層制限チェック
	if (is_pankuzu_limit_over($fld['file_path'], $edit_page_id)) {
		$error_flg = 4;
	}
}

// 親ページ設定ボタン
$message = "";
$panset = '<a href="javascript:" onClick="return cxSetParent();"><img src="' . RPW . '/admin/images/pageproperty/btn_panset.jpg" alt="親ページに設定" style="margin-right:5px;" width="170" height="30" border="0"></a>';
if ($error_flg == 1) {
	// 親ページにしようとしているページと編集のページが同一かチェック
	$message = '<p style="color:#FF0000;font-weight:bold;margin-bottom:5px">' . '<img src="' . RPW . '/admin/images/icon/result_error.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px">' . 'このページは現在編集中のページなので、親ページに設定できません' . '</p>' . "\n";
}
elseif ($error_flg == 2) {
	// 親ページにしようとしているページの親ページに編集中のページが存在
	$message = '<p style="color:#FF0000;font-weight:bold;margin-bottom:5px">' . '<img src="' . RPW . '/admin/images/icon/result_error.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px">' . 'このページは現在編集中のページを親ページに含んでいるため、親ページに設定できません' . '</p>' . "\n";
}
elseif ($error_flg == 3) {
	// 親ページのパンくずがパンくず階層制限に達していた場合
	$message = '<p style="color:#FF0000;font-weight:bold;margin-bottom:5px">' . '<img src="' . RPW . '/admin/images/icon/result_error.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px">' . 'このページを親ページとするとパンくず階層制限として指定されている階層を越えるため、親ページに設定できません' . '</p>' . "\n";
}
elseif ($error_flg == 4) {
	$err_child_msg = "";
	if (isset($_SESSION['pankuzu_check']) && count($_SESSION['pankuzu_check'])) {
		$child_page_id = reset($_SESSION['pankuzu_check']);
		if ($objPage->selectFromID($child_page_id)) {
			$err_child_msg .= '<br>' . '<img src="' . RPW . '/admin/images/icon/result_error.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px;visibility:hidden">' . '※階層制限を越える子ページ【' . 'ページタイトル：' . htmlDisplay($objPage->fld['page_title']) . '】';
		}
	}
	// 親ページのパンくずがパンくず階層制限に達していた場合
	$message = '<p style="color:#FF0000;font-weight:bold;margin-bottom:5px">' . '<img src="' . RPW . '/admin/images/icon/result_error.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px">' . '編集中ページを親ページに含む子ページの階層がパンくず階層制限を超えるため、このページを親ページに設定できません' . $err_child_msg . '</p>' . "\n";
}
// 親ページに大規模災害ページが含まれる場合
elseif ($error_flg == 5) {
	$message = '<p style="color:#FF0000;font-weight:bold;margin-bottom:5px">' . '<img src="' . RPW . '/admin/images/icon/result_error.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px">' . '大規模災害用に作成されたページを親ページに設定できません。' . '</p>' . "\n";
}

if (strlen($message) > 0) {
	$panset = '<img src="' . RPW . '/admin/images/pageproperty/btn_panset_off.jpg" alt="このページは親ページに設定できません" style="margin-right:5px;" width="170" height="30" border="0">';
}
$params = array(
		'msg' => $message
);

// ONLOADを消去
$htmlStr = preg_replace('/onload="[^"]*"/i', '', $htmlStr);
$htmlStr = preg_replace('/.*\.onload.*/i', '', $htmlStr);
$htmlStr = preg_replace('/<script.*<\/script>/i', '', $htmlStr);
// HTML 生成
createHtml($htmlStr, "1", $panset, $form_start, $params);
// 特殊な置き換え
$htmlStr = preg_replace('/(<body[^>]*>)/i', '${1}' . '<span style="width:100%;height:100%;margin-bottom:1px;">' . "\n", $htmlStr);
$htmlStr = preg_replace('/(<\/body>)/i', '</span>' . '${1}' . "\n", $htmlStr);
// HTML 表示
print $htmlStr;
?>