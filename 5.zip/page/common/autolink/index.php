<?php
/*
 * ページ編集画面：自動リンク設定
 */
// ** require -------------------------------
require_once ("./.htsetting");
require ("../../autolink/include/autolinkCommonFunc.inc");
global $objLogin;

// ** 定数 ----------------------------------
// 開く、閉じるのモード
define("PLUS_MODE", FLAG_ON);
define("MINUS_MODE", FLAG_OFF);

// 画像
$CATE_PLUS_IMG = RPW . "/admin/master/images/dir_plus.jpg";
$CATE_MINUS_IMG = RPW . "/admin/master/images/dir_minus.jpg";
if (isset($INDEX_TITLE)) unset($INDEX_TITLE);

// POST
if ($_SERVER['REQUEST_METHOD'] == "POST") {
	$CATE_SELECT = (isset($_POST['cate_code'])) ? $_POST['cate_code'] : "";
	$CATE_SELECT_LEVEL = (isset($_POST['cate_level'])) ? $_POST['cate_level'] : 1;
	$ALINK_SELECT_ID = (isset($_POST['a_link_id'])) ? $_POST['a_link_id'] : "";
	if (isset($_POST['index_title'])) $INDEX_TITLE = $_POST['index_title'];
	// GET
}
else {
	$CATE_SELECT = (isset($_GET['cate_code'])) ? $_GET['cate_code'] : "";
	$CATE_SELECT_LEVEL = (isset($_GET['cate_level'])) ? $_GET['cate_level'] : 1;
	$ALINK_SELECT_ID = (isset($_GET['a_link_id'])) ? $_GET['a_link_id'] : 1;
	if (isset($_GET['index_title'])) $INDEX_TITLE = $_GET['index_title'];
}

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_auto_link.inc');
$objAlink = new tbl_auto_link($objCnc);
$sel_a_link_id = "";
$admin_a_link_id = "";
foreach (explode(",", $ALINK_SELECT_ID) as $a_link_id) {
	if ($objAlink->selectFromID($a_link_id) === FALSE) continue;
	if ($objAlink->fld['auth'] == FLAG_ON && $objLogin->get('class') != USER_CLASS_WEBMASTER) {
		$admin_a_link_id = $a_link_id . ":" . $objAlink->fld['name'];
	}
	else {
		if ($sel_a_link_id != "") $sel_a_link_id .= AUTOLINK_DELIMITER;
		$sel_a_link_id .= $a_link_id . ":" . $objAlink->fld['name'];
	}
}

// DB内容取得
$strHTML = "";
$hiddenHTML = "";

// リンク掲載用タイトル
if (isset($INDEX_TITLE)) {
	$strHTML .= '<table width="100%" border="0" cellpadding="10" cellspacing="0" class="cms8341-dataTable" style="margin-top:10px;">';
	$strHTML .= '<tr>';
	$strHTML .= '<th align="left" valign="middle">';
	$strHTML .= '<label for="cms_index_title">リンク掲載用タイトル</label>';
	$strHTML .= '</th>';
	$strHTML .= '<td><input type="text" maxlength="128" id="index_title" name="index_title" value="' . htmlspecialchars($INDEX_TITLE) . '" style="width:260px;"></td>';
	$strHTML .= '</tr>';
	$strHTML .= '</table>';
	$strHTML .= '<hr>';
}

// HIDDEN項目生成
$hiddenHTML .= '' . "\n";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>自動リンク一覧</title>
<base target="_self">
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<style>
<!--
#cms8341-categories div {
	margin: 12px 0px;
}

.dir_first {
	padding-left: 5px;
	padding-top: 10px;
}

.dir_second {
	padding-left: 35px;
	padding-top: 10px;
}

.dir_third {
	padding-left: 35px;
	padding-top: 10px;
}

.dir_fourth {
	padding-left: 15px;
	padding-top: 10px;
}

.cms8341-autolinksettingarea {
	overflow: auto;
	margin: 0px 0px 10px 0px;
	background-color: #FFFFFF;
	padding: 15px 19px 15px 19px;
	text-align: left;
	border: solid 1px #999999;
	font-size: 14px;
}

.cms8341-wrapper {
	width: 510px;
}
//
-->
</style>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/faq/js/common.js"
	type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

PLUS_MODE  = "<?=PLUS_MODE?>";
MINUS_MODE = "<?=MINUS_MODE?>";

function cxCheck(val) {
	valtmp = val.split(":");
	id = valtmp[0];
	if($("a_link_id_"+id).checked){
		tmp = $("sel_a_link_id").value.split(AUTOLINK_DELIMITER);
		tmp.push(val);
		$("sel_a_link_id").value = tmp.join(AUTOLINK_DELIMITER);
	} else {
		tmp2 = new Array();
		tmp = $("sel_a_link_id").value.split(AUTOLINK_DELIMITER);
		for(i=0;i<tmp.length;i++){
			if(tmp[i].split(":")[0] != id){
				tmp2.push(tmp[i]);
			}
		}
		$("sel_a_link_id").value = tmp2.join(AUTOLINK_DELIMITER);
	}
	if($("sel_a_link_id").value.substring(0,AUTOLINK_DELIMITER.length) == AUTOLINK_DELIMITER){
		$("sel_a_link_id").value = $("sel_a_link_id").value.substring(AUTOLINK_DELIMITER.length)
	}
}

function cxShow(cate_code, level) {
	if(cate_code == ""){
		area = "data_area";
	} else {
		area = "cate_"+cate_code;
	}
	if(cate_code == "" || $("img_"+cate_code).src.indexOf("<?=$CATE_PLUS_IMG?>") > 0){
		mode = PLUS_MODE;
	} else {
		mode = MINUS_MODE;
	}
	if ( mode == PLUS_MODE ) {
		var prm = "cate_code="+cate_code+"&cate_level="+level+"&sel_a_link_id="+$F('sel_a_link_id');
		var regAjax = new Ajax.Request(
			cms8341admin_path+'/page/common/autolink/list.php',
			{
				method: 'post',
				parameters: prm,
				onSuccess: function(request) {
					rText = request.responseText;
					new Insertion.Bottom(area, rText);
					window.frameElement.autoUpdateWH();
				},   
				onFailure: function(request) {   
					alert('失敗しました');   
				}   
			}
		);
		if($("img_"+cate_code)) $("img_"+cate_code).src = "<?=$CATE_MINUS_IMG?>";
	} else {
		$(area).innerHTML = "<span id=\"catename_"+cate_code+"\">"+$("catename_"+cate_code).innerHTML+"</span>";
		if($("img_"+cate_code)) $("img_"+cate_code).src = "<?=$CATE_PLUS_IMG?>";
	}

	return false;

}

function cxSubmit(){
	var retObj = new Object();
	retObj["a_link_id"] = $("sel_a_link_id").value;
	if(retObj["a_link_id"] != "" && $("admin_a_link_id").value != ""){
		retObj["a_link_id"] += AUTOLINK_DELIMITER;
	}
	retObj["a_link_id"] += $("admin_a_link_id").value;

	if($('index_title')) retObj["index_title"] = $F('index_title');
	cxIframeLayerCallback(retObj);
}
//リセット
function cxReset(){
	if (!confirm("設定している情報をリセットします。\nよろしいですか？")) {
		return false;
	}
	$("sel_a_link_id").value = "";
	autoLinkitems = $("data_area");
	for (i = 0; i < autoLinkitems.getElementsByTagName("input").length; i++) {
	    id = autoLinkitems.getElementsByTagName("input")[i].getAttribute("ID");
	    if(id == null)continue;
	    $(id).checked = false;
	}
}

function cxKeyPress(event){
	if(event.keyCode == 13){
		return false;
	}
}
function cxInit() {
	Event.observe(document,'keypress',cxKeyPress,false);
	cxShow('',1);
}

Event.observe(window,'load',cxInit,false);

//-->
</script>
</head>
<body id="cms8341-mainbg">
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	style="margin: 0px; padding: 0px">
	<tr>
		<td width="100%" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="100%" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="images/title_autolinks.jpg" alt="自動リンク依頼先" width="200"
					height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="#"
					onclick="cxIframeLayerCallback();" id="header_close"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div class="cms8341-autolinksettingarea">
		<div class="cms8341-wrapper">
						<?=$strHTML?>
						<div id="data_area"></div>
		</div>
		<p align="center"><a href="javascript:" onClick="return cxSubmit()"><img
			src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" border="0"></a>
		<a href="javascript:" onClick="return cxReset()"><img
			src="<?=RPW?>/admin/images/btn/btn_reset100.jpg" alt="リセットする"
			border="0"></a></p>
		</div>
		<input type="hidden" name="sel_a_link_id" id="sel_a_link_id"
			value="<?=$sel_a_link_id?>"> <input type="hidden"
			name="admin_a_link_id" id="admin_a_link_id"
			value="<?=$admin_a_link_id?>"></td>
	</tr>
</table>
</body>

</html>