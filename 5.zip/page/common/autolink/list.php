<?php
/*
 * ページ編集画面：自動リンク設定
 */
// ** require -------------------------------
require_once ("./.htsetting");
require ("../../autolink/include/autolinkCommonFunc.inc");

// ** global 宣言 ---------------------------
global $objCnc;

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

// ** 定数 ----------------------------------
define("G_CATE_LEVEL01", 1); //第1分類
define("G_CATE_LEVEL02", 2); //第2分類
define("G_CATE_LEVEL03", 3); //第3分類
define("G_CATE_LEVEL04", 4); //第4分類


// スタイル
$CATE_CSS_CLASS = array(
		G_CATE_LEVEL01 => "dir_first", 
		G_CATE_LEVEL02 => "dir_second", 
		G_CATE_LEVEL03 => "dir_third", 
		G_CATE_LEVEL04 => "dir_fourth"
);

// POST
$CATE_SELECT = (isset($_POST['cate_code'])) ? $_POST['cate_code'] : "";
$CATE_SELECT_LEVEL = (isset($_POST['cate_level'])) ? $_POST['cate_level'] : 1;
$ALINK_SELECT_ID = (isset($_POST['sel_a_link_id'])) ? $_POST['sel_a_link_id'] : "";
foreach (explode(AUTOLINK_DELIMITER, $ALINK_SELECT_ID) as $a_link_info) {
	list($a_link_id, ) = explode(":", $a_link_info);
	$select_id_ary[] = $a_link_id;
}

// 画像
$CATE_PLUS_IMG = RPW . "/admin/master/images/dir_plus.jpg";
$CATE_MINUS_IMG = RPW . "/admin/master/images/dir_minus.jpg";

// 開く、閉じるのモード
define("PLUS_MODE", FLAG_ON);
define("MINUS_MODE", FLAG_OFF);

// カテゴリ一覧を取得
$where = "";
if ($CATE_SELECT != "") {
	$where .= $objDac->_addslashesC("cate_code", substr($CATE_SELECT, 0, $CATE_SELECT_LEVEL * CODE_DIGIT_CATE) . "%", "LIKE");
	$where .= " AND " . $objDac->_addslashesC("level", $CATE_SELECT_LEVEL + 1);
}
else {
	$where .= $objDac->_addslashesC("level", $CATE_SELECT_LEVEL);
}
$objDac->setTableName("tbl_category");
$objDac->select($where, "*", "cate_code");

// DB内容取得
$strHTML = "";
$hiddenHTML = "";

if ($CATE_SELECT == "") {
	// トップの一覧
	$strHTML .= '<img src="../../autolink/images/label_top.gif" class="cms8341-verticalMiddle">';
	createAutolinkListFromEdit($strHTML, $select_id_ary, AUTOLINK_SITE_TOP_CATEGORY);
}

// カテゴリの一覧
if ($objDac->getRowCount() > 0) {
	while ($objDac->fetch()) {
		$fld = $objDac->fld;
		// DB値
		$level = $fld['level'];
		$cate_code = htmlspecialchars($fld['cate_code']);
		$name = htmlDisplay($fld['name']);
		
		// style
		$css_cls = (isset($CATE_CSS_CLASS[$level])) ? $CATE_CSS_CLASS[$level] : "dir_first";
		// image
		$img = $CATE_PLUS_IMG;
		$mode = PLUS_MODE;
		
		if ($level < $CATE_SELECT_LEVEL && substr($CATE_SELECT, 0, 3 * $level) == substr($cate_code, 0, 3 * $level)) {
			$img = $CATE_MINUS_IMG;
			$mode = MINUS_MODE;
		}
		
		// html表記の作成
		$strHTML .= "<div id=\"cate_" . $cate_code . "\" align=\"left\" class=\"" . $css_cls . "\">";
		
		$strHTML .= "<span id=\"catename_" . $cate_code . "\">";
		if ($level < G_CATE_LEVEL04) {
			$strHTML .= "<a href=\"javascript:\" onClick=\"return cxShow('" . $cate_code . "'," . $level . ")\">";
			$strHTML .= "<img id=\"img_" . $cate_code . "\" src=\"" . $img . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\">";
			$strHTML .= "</a>";
		}
		else {
			$strHTML .= "<img src=\"" . RPW . "/admin/master/images/dir_none.jpg\" alt=\"\" width=\"60\" height=\"20\" border=\"0\">";
		}
		
		// 分類名
		$strHTML .= $name;
		// 一覧ページ作成へのボタン
		createAutolinkListFromEdit($strHTML, $select_id_ary, $cate_code, $level);
		$strHTML .= "</span>";
		$strHTML .= "</div>" . PHP_EOL;
	}
}

if ($CATE_SELECT == "") {
	// そのたの一覧
	$strHTML .= '<hr>';
	createAutolinkListFromEdit($strHTML, $select_id_ary);
}

header("Content-Type: text/html; charset=UTF-8");
print $strHTML;
exit();

?>
