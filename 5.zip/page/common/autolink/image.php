<?php
/*
 * 画像の設定を行う
 */
//設定ファイル読み込み
require_once ("./.htsetting");

//エラー画面設定 別ウィンドウ用
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");
gd_errorhandler_ini_set("html9", '<base target="_self">');

//DBアクセス用ファイルの読み込み
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

if (isset($_SESSION['post']) && $_SESSION['post'] != "") {
	$POST = $_SESSION['post'];
	unset($_SESSION['post']);
}

//変数の初期化
//フォルダパス(絶対パス)
$real_base_path = DOCUMENT_ROOT . RPW;

//フォルダパスの取得
//SESSIONを取得できる場合
/*	if(isset($_SESSION['cms_page_id']) && $_SESSION['cms_page_id'] != ""){
	//パス取得
	if($objPage->selectFromID($_SESSION['cms_page_id'],WORK_TABLE,"file_path") !== FALSE){
		$real_base_path .= cms_dirname($objPage->fld['file_path']) . FCK_IMAGES_FORDER;
	}
	else if($objPage->selectFromID($_SESSION['cms_page_id'],PUBLISH_TABLE,"file_path") !== FALSE){
		$real_base_path .= cms_dirname($objPage->fld['file_path']) . FCK_IMAGES_FORDER;
	}
	else user_error('ページ情報を取得できませんでした。',E_USER_ERROR);
}
else user_error('ログイン情報を取得できませんでした。現在の開いている全てのブラウザを閉じて再度実行してください。',E_USER_ERROR);*/
$real_base_path .= AUTOLINK_IMAGE_DIR;

//値の取得
if (isset($_GET['value'])) {
	$value = str_replace("＃", "#", $_GET['value']);
	$values = explode(KANKO_LINK_DELIMITER, $value);
	if (isset($values[0])) $src = htmlDisplay($values[0], "nonspace");
	if (isset($values[1])) $alt = htmlDisplay($values[1], "nonspace");
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex, nofollow" />
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>画像設定</title>
<base target="_self">
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet"
	href="<?=RPW?>/ckeditor/gd_files/css/dialog.css"
	type="text/css" />
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>

<script
	src="<?=RPW?>/ckeditor/gd_files/js/dialog_common.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/ckeditor/plugins/gd_image/pages/js/com_func.js"
	type="text/javascript"></script>

<script src="<?=RPW?>/admin/page/common/autolink/js/image.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/page/common/autolink/js/image_upload.js"
	type="text/javascript"></script>

<script type="text/javascript">
			<!--
				var get_mode = '<?php
				print((isset($_GET["mode"]) && $_GET["mode"] == "upload" ? "upload" : "property"));
				?>';
				var err_msg = '<?php
				print((isset($_SESSION["err_msg"]) ? $_SESSION["err_msg"] : ""));
				?>';
				var template_kind = '<?php
				print((isset($_SESSION["use_template_kind"]) ? $_SESSION["use_template_kind"] : ""));
				?>';
				<?php
				unset($_SESSION["err_msg"]);
				?>
				var POST = new Object();
				POST["url"] = '<?php
				print((isset($_POST["url"]) ? javaStringEscape($_POST["url"]) : ""));
				?>';
				POST["width"] = '<?php
				print((isset($_POST["width"]) ? javaStringEscape($_POST["width"]) : ""));
				?>';
				POST["height"] = '<?php
				print((isset($_POST["height"]) ? javaStringEscape($_POST["height"]) : ""));
				?>';
				POST["alt"] = '<?php
				print((isset($_POST["alt"]) ? javaStringEscape($_POST["alt"]) : ""));
				?>';
				var GET = new Object();
				GET["id"] = '<?php
				print((isset($_GET["id"]) ? javaStringEscape($_GET["id"]) : ""));
				?>';
				GET["src"] = '<?php
				print((isset($src) ? javaStringEscape($src) : ""));
				?>';
				GET["alt"] = '<?php
				print((isset($alt) ? javaStringEscape($alt) : ""));
				?>';
				<?php
				//上書きがあった場合、編集画面に表示されている画像を差し替える
				if (isset($_SESSION["updata_file"]) && count($_SESSION["updata_file"]) > 0) {
					$script = 'window.dialogArguments = window.frameElement.args; var targetArea = window.dialogArguments.document.getElementById(\'data_area\');' . "\n";
					$script .= 'var img_ary = targetArea.getElementsByTagName(\'img\');' . "\n";
					$script .= 'var updata_ary = [' . "\n";
					foreach ((array) $_SESSION["updata_file"] as $val) {
						$script .= '"' . $val . '",' . "\n";
					}
					$script = substr($script, 0, strrpos($script, ",")) . "\n";
					$script .= ']' . "\n";
					$script .= 'for(var i = 0;i < updata_ary.length;i++){' . "\n";
					$script .= 'for(var j = 0;j < img_ary.length;j++){' . "\n";
					$script .= 'if(updata_ary[i] == img_ary[j].src.substring(img_ary[j].src.indexOf(baseUrl),(img_ary[j].src.indexOf(\'?\') > 0 ? img_ary[j].src.indexOf(\'?\') : img_ary[j].src.length))){' . "\n";
					$rnd = rand();
					$script .= 'cxPreImages(updata_ary[i] + "?rnd=' . $rnd . '");' . "\n";
					$script .= 'img_ary[j].src = updata_ary[i] + "?rnd=' . $rnd . '";' . "\n";
					$script .= '}' . "\n";
					$script .= '}' . "\n";
					$script .= '}' . "\n";
					print($script);
					unset($_SESSION["updata_file"]);
				}
				?>
				<?php
				echo loadSettingVars();
				?>
			//-->
		</script>
</head>
<body bgcolor="#FFFFFF">
<div id="cms8341-headareaZero" style="margin-bottom: 0px !important">
<table width="624px" height="608px" border="0" cellspacing="0"
	cellpadding="0">
	<tr>
		<td width="100%" height="100%" align="center" valign="top"
			bgcolor="#DFDFDF"
			style="margin-bottom: 0px; border: solid 1px #343434;">
		<table width="100%" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/fckimage/title_imageset.jpg" alt="画像設定"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a
					href="javascript:void(0)" onClick="cxIframeLayerCallback();"><img
					src="<?=RPW?>/admin/images/fckimage/btn_close.jpg" alt="閉じる"
					width="58" height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 97%; height: 556px; overflow: auto; margin: 10px 0px; background-color: #DFDFDF; padding: 0px; text-align: left; border: solid 1px #343434">
		<div id="divProperty">
		<div id="cms8341-tab">
		<table border="0" cellspacing="0" cellpadding="0"
			style="border-collapse: collapse;">
			<tr>
				<td><a
					href="<?=RPW?>/admin/page/common/autolink/image.php?mode=upload"><img
					src="<?=RPW?>/admin/images/fckimage/tab_pc_off.jpg" alt="PCから選んで登録"
					width="150" height="21" border="0"></a></td>
				<td><img src="<?=RPW?>/admin/images/fckimage/tab_server_on.jpg"
					alt="登録済画像から選択" width="150" height="21" border="0"></td>
			</tr>
		</table>
		</div>
		<table width="100%" height="520px" cellspacing="0" cellpadding="5"
			style="background-color: #FFFFFF; border-top: solid 1px #999999;">
			<tr>
				<td valign="top">
				<div
					style="border-collapse: collapse; text-align: left; padding: 15px 2px 10px 2px; align: center">
				<img src="<?=RPW?>/admin/images/fckimage/bar_imageinfo.jpg"
					width="430" height="20" alt="画像情報"></div>
				<form name="cms_fck_image_property" id="cms_fck_image_property"
					action="javascript:void(0)" method="post"
					enctype="multipart/form-data"
					onsubmit="cxSubmit_Property(); return false;">
				<table width="90%" border="0" cellspacing="0" align="center"
					style="border: solid 1px #999999;">
					<tr>
						<td width="30%" align="center" valign="top"
							style="padding-top: 20px; padding-bottom: 15px;"><img
							id="imgPreview" src="<?=RPW?>/admin/images/spacer.gif" alt=""
							width="0" height="0"></td>
						<td width="70%" align="center" valign="top"
							style="border-left: solid 1px #999999;" nowrap>
						<table width="100%" border="0" cellspacing="0" cellpadding="0"
							style="border: none; margin: 0px; padding-top: 2px; padding-bottom: 2px;">
							<tr style="padding-top: 10px;">
								<td
									style="font-size: 15px; font-weight: bold; padding-left: 5px;">代替テキスト</td>
							</tr>
							<tr>
								<td style="padding-left: 5px;"><input id="txtAlt"
									style="WIDTH: 90%" type="text"></td>
							</tr>
							<tr style="padding-bottom: 10px;">
								<td style="padding-left: 1px;"><input id="chkAlt"
									type="checkbox" onClick="setAlt();"><label for="chkAlt"><span
									style="font-size: 12px;">代替テキストを設定しない</span></label></td>
							</tr>
						</table>
						</td>
					</tr>
				</table>
				<div align="center" style="margin: 15px 0px;"><input type="image"
					name="submit_property" id="submit_property"
					src="<?=RPW?>/admin/images/fckimage/btn_setting.jpg" width="100"
					height="20" alt="設定" border="0"> &nbsp; &nbsp; &nbsp; <a
					href="<?=RPW?>/admin/page/common/autolink/image_list.php"><img
					src="<?=RPW?>/admin/images/fckimage/btn_listview.jpg" width="100"
					height="20" alt="一覧画面へ" border="0"></a></div>
				</form>
				</td>
			</tr>
		</table>
		</div>
		<div id="divUpload" style="DISPLAY: none">
		<div id="cms8341-tab">
		<table border="0" cellspacing="0" cellpadding="0"
			style="border-collapse: collapse;">
			<tr>
				<td><img src="<?=RPW?>/admin/images/fckimage/tab_pc_on.jpg"
					alt="PCから選んで登録" width="150" height="21" border="0"></td>
				<td><a href="<?=RPW?>/admin/page/common/autolink/image_list.php"><img
					src="<?=RPW?>/admin/images/fckimage/tab_server_off.jpg"
					alt="登録済画像から選択" width="150" height="21" border="0"></a></td>
			</tr>
		</table>
		</div>
		<table width="100%" height="520px" cellspacing="0" cellpadding="0"
			style="background-color: #FFFFFF; border-top: solid 1px #999999;">
			<tr>
				<td valign="top">
				<form name="cms_fck_image_upload" id="cms_fck_image_upload"
					action="<?=RPW?>/admin/page/common/autolink/image_upload.php"
					method="post" enctype="multipart/form-data"
					onsubmit="cxSubmit_Upload('<?=$real_base_path?>'); return false;">
													<?php
													for($i = 0; $i < 5; $i++) {
														print('<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center" class="cms8341-dataTable" style="border-collapse:collapse;margin-top: 10px;">');
														print('<tr style="padding:2px;">');
														print('<th width="30%" align="left" valign="top" style="font-size:12px;padding-left:4px;border-top:none;border-left:none;" nowrap>画像名称' . ($i + 1) . '</td>');
														print('<td width="70%" valign="top" style="padding-left:4px;border-left:none;">');
														print('<input id="cms_image_name_' . $i . '" name="cms_image_name_' . $i . '" style="WIDTH: 98%;" type="text" maxlength="64" value="' . (isset($POST['cms_image_name_' . $i]) ? htmlDisplay($POST['cms_image_name_' . $i]) : "") . '">');
														print('</td>');
														print('</tr>');
														print('<tr style="padding:2px;">');
														print('<th width="30%" align="left" valign="top" style="font-size:12px;padding-left:4px;border-top:none;" nowrap>ファイル' . ($i + 1) . '</td>');
														print('<td style="padding-left:4px;border-top:none;border-left:none;">');
														print('<input id="cms_image_path_' . $i . '" name="cms_image_path_' . $i . '" type="file" style="WIDTH: 98%;">');
														print('</td>');
														print('</tr>');
														print('</table>');
														print('<input type="hidden" id="cms_rename_file_path_' . $i . '" name="cms_rename_file_path_' . $i . '">');
													}
													?>
													<br />
				<br />
				<div align="center"><input type="image" name="submit_upload"
					id="submit_upload"
					src="<?=RPW?>/admin/images/fckimage/btn_regist_on.jpg" border="0"
					alt="登録"></div>
				</form>
				</td>
			</tr>
		</table>
		</div>
							<?php
							print($objTool->setAccessibility());
							?>
						</div>
		</td>
	</tr>
</table>
</div>
</body>
</html>
