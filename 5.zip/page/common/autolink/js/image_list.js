/*
 * 画像リスト処理用javascript
 */

// イメージ読み込み
cxPreImages(cms8341admin_path+'/images/fckimage/btn_imageedit_on.jpg',
		    cms8341admin_path+'/images/fckimage/btn_setup_on.jpg',
		    cms8341admin_path+'/images/fckimage/title_imageset.jpg',
		    cms8341admin_path+'/images/fckimage/btn_close.jpg',
		    cms8341admin_path+'/images/fckimage/tab_pc_off.jpg',
		    cms8341admin_path+'/images/fckimage/tab_server_on.jpg',
		    cms8341admin_path+'/images/fckimage/bar_search.jpg',
		    cms8341admin_path+'/images/fckimage/bar_filelist.jpg',
		    cms8341admin_path+'/images/fckimage/btn_search.jpg'
		    );


//-------------------------------------------------
// ドキュメントロード時
//	【引数】
//		e : イベント
//	【戻値】
//		true
//-------------------------------------------------
window.document.onkeydown = function(e){
	e = e || event || this.parentWindow.event;
	switch(e.keyCode){
		//ESC
		case 27:
			window.parent.Cancel();
			return false;
			break;
	}
	return true;
}

//-------------------------------------------------
// 親画面にオブジェクトを返す
//	【引数】
//		id : 画像のID
//	【戻値】
//		なし
//-------------------------------------------------
function cxReturn( id ){
	// 代入
	$('url').value = RPW+$F('cms_url_' + id);
	$('width').value = $F('cms_width_' + id);
	$('height').value = $F('cms_height_'+ id);
	$('alt').value = $('cms_image_name_'+ id).innerHTML.unescapeHTML();

	$('cms_fck_image_select').submit();
	return false;
}

//-------------------------------------------------
// プロパティを開く
//	【引数】
//		id	: 画像のID
//	【戻値】
//		なし
//-------------------------------------------------
function cxShowProperty( id ) {
	cxIframeLayer(
		RPW + "/ckeditor/plugins/gd_image/pages/fck_image_property.php?id=" + id,
		460,
		320,
		COVER_SETTING.COLOR,
		'',
		function (pObj) {
			if ( pObj != undefined ) cxSearch();
		}
	);
}

//-------------------------------------------------
// 検索ボタン押下後サブミット
//	【引数】
//		なし
//	【戻値】
//		なし
//-------------------------------------------------
function cxSearch() {
	$('cms_fck_image_list').submit();
	return false;
}

//-------------------------------------------------
//画像編集ダイアログを表示する
//	【引数】
//		id	: 画像のID
//	【戻値】
//		なし
//-------------------------------------------------
function cxEdit(id){
	var newDlg;
	var Open_URL;
	var Open_Title;
	var Open_Width;
	var Open_Height;
	Open_URL = RPW + "/ckeditor/plugins/gd_image/pages/fck_image_controll.php?id="+id+"&prev_page=autolink";
	Open_Title = "サイト内にリンク";
	Open_Width = Infinity;
	Open_Height = Infinity;
	Open_resize = 1;
	//ダイアログ表示
	cxIframeLayer(
		Open_URL,
		Open_Width,
		Open_Height,
		COVER_SETTING.COLOR,
		'',
		function (pObj) {
			cxImgEditFolderDelete( pObj );
			//戻り値がundefined以外なら再検索
			if ( pObj != undefined ) {
				if(pObj['endFlg']) cxSearch();
			}
		},
		false,
		true
	);
}

/**
 * 指定された画像を削除する
 * @param id 画像のID
 * @param name 画像の名称
 * @return false
 */
function cxDeleteImage(id,name){
	//確認用ダイアログを表示
	if(confirm(name + "を削除します。よろしいですか？")){
		//削除実行PHPを呼び出す(Ajax)
		var a = new Ajax.Request(
			baseUrl + 'ckeditor/plugins/gd_image/pages/fck_image_delete.php',
			{
				method: 'post',
				postBody: 'cms_image_id=' + id,
				//成功した場合
				onComplete: function(originalRequest){
					if(originalRequest.responseText != "") alert(originalRequest.responseText);
					else cxSearch();
				},
				//失敗した場合
				onFailure: function(request){
					alert(name + 'の削除に失敗しました');   
				}
			}   
		);
	}
	return false;
}

/**
 * 指定された画像のプロパティを登録する(fck_image_property.js#cxSubmitのオーバーライド)
 * @return false
 */
function cxSubmit(){
	// ファイル名称チェック
	if ( $('cms_fck_image_name') ) {
		// 必須
		if ( $F('cms_fck_image_name') == "" ) {
			alert( "画像名称を入力してください。" );
			$('cms_fck_image_name').focus();
			return false;
		}
		// 機種依存
		var info = new Array();
		info = fckCheck( '画像名称' , $F('cms_fck_image_name') , info );
		if(!info)return false;
		if (info.length > 0) {
			var msg = info.join('\n') + '\nよろしいですか？';
			if (!confirm(msg)) {
				$('cms_fck_image_name').focus();
				return false;
			}
		}
	}
	//登録用PHPを呼び出す(Ajax)
	var prm = 'cms_fck_image_id=' + $F('cms_fck_image_id') + '&cms_fck_image_name=' + $F('cms_fck_image_name');
	var a = new Ajax.Request(
		baseUrl + 'ckeditor/plugins/gd_image/pages/fck_image_register.php',
		{
			method: 'post',
			postBody: prm,
			//成功した場合
			onComplete: function(originalRequest){
				if(originalRequest.responseText != "") alert(originalRequest.responseText);
				else location.reload();
			},
			//失敗した場合
			onFailure: function(request){
				alert('登録に失敗しました');   
			}
		}   
	);
	return false;
}

/**
 * 指定された画像の差し替えページを開く
 * @param id 画像のID
 * @return false
 */
function cxChangeImage( id ) {
	//formを作成する
	var form = document.createElement('form');
	form.method = 'post';
	form.id = "changeimage";
	form.name = form.id;
	form.action = "image_form.php";
	//POSTするデータを作成する
	var input = document.createElement('input');
	input.type = 'hidden';
	input.id = 'cms_image_id';
	input.name = input.id;
	input.value = id;
	//formにinputを追加
	form.appendChild(input);
	//bodyにformを追加
	$$('body')[0].appendChild(form);
	//formを送信する
	form.submit();
	return false;
}

/**
 * ページ番号をPOSTする
 * @param page ページ番号
 * @return false
 */
function cxPageSet(page){
	$('cms_page_post').cms_page.value = page;
	$('cms_page_post').maxrow.value = $('dispNum').value;
	$('cms_page_post').submit();
	return false;
}

/**
 * 表示件数を変える
 * @param prev_num 表示件数
 * @return false
 */
function cxDispNum(prev_num){
	$('cms_page_post').cms_page.value = 1;
	$('cms_page_post').maxrow.value = prev_num;
	$('cms_page_post').submit();
	return false;
}
