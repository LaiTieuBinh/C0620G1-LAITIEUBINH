<?php
/*
 * 承認依頼予定のグループ
 */
//外部ファイル読み込み
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_contents_group.inc');
$objCGrp = new tbl_contents_group($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_approve_handler.inc');
$objAppHandler = new tbl_approve_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_auto_link.inc');
$objALink = new tbl_auto_link($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/page_control.inc');
$objP = new page_control();
require_once ('./include/workflowCommonFunc.inc');

//定数の宣言
$LIST_NAME = "skip";

//変数の宣言
$login = $objLogin->login;
$html = "";
$group_no = 0;
$menu_no = 0;
$page = (isset($_POST['cms_page']) && is_numeric($_POST['cms_page']) ? floor($_POST['cms_page']) : 1);
$row_cnt = 0;
$MAXROW_LIST = getDefineArray("MAXROW_LIST");
$maxRow = (isset($_POST['maxrow']) && is_numeric($_POST['maxrow']) ? floor($_POST['maxrow']) : key($MAXROW_LIST));

//ページ情報の作成
$objCGrp->selectApproveRequestBySkip($login);
$row_cnt = $objCGrp->getRowCount();
$objP->limit = $maxRow;
$objP->set($page, $row_cnt);
if ($row_cnt > 0) {
	$html .= '<table width="100%" border="0" cellspacing="0" cellpadding="0" style="margin-bottom:10px;padding:1px">';
	$html .= '<tr valign="top">';
	$html .= '<td colspan="3" align="right">';
	$html .= mkcombobox($MAXROW_LIST, "dispNum_skiplist", $maxRow, "cxDispNum(this.value,'skiplist')");
	$html .= '</td>';
	$html .= '</tr>';
	$html .= '<tr>';
	$html .= '<td width="30%" align="left" valign="middle" scope="row">' . $objP->getBackLink('cxPageSet_Skiplist') . '</td>';
	$html .= '<td width="40%" align="center" valign="middle">' . $objP->getViewCount('cxPageSet_Skiplist') . '</td>';
	$html .= '<td width="30%" align="right" valign="middle">' . $objP->getNextLink('cxPageSet_Skiplist') . '</td>';
	$html .= '</tr>';
	$html .= '</table>';
	//全体を囲う枠を付ける
	$html .= '<div style="padding:10px;margin:0px;border:solid 1px #CCCCCC;">';
}
else
	$html .= '<input type="hidden" id="dispNum_skiplist" value="' . $maxRow . '">';
	//承認依頼コンテンツ情報を取得
$objCGrp->selectApproveRequestBySkip($login, $objP->getOffset(), $objP->getLimit());
$cntCG = 0;
//取得した件数分ループ
while ($objCGrp->fetch()) {
	$group_id = $objCGrp->fld['group_id'];
	$objPage->selectApproveWait($group_id);
	if ($objPage->getRowCount() == 0) continue;
	$cntCG++;
	$group_box = array();
	//否認済みのグループ
	if ($objCGrp->fld['status'] == 305) {
		//グループは閉じておく
		$group_box = array(
			'display' => 'none', 
			'icon' => 'icon_plus.jpg', 
			'background' => ''
		);
		$status_icon = '<img src="' . RPW . '/admin/page/workflow/images/icon_denial.jpg" alt="否認" width="104" height="23">';
	} //承認依頼のグループ
	else {
		//グループを開いておく
		$group_box = array(
			'display' => 'none', 
			'icon' => 'icon_plus.jpg', 
			'background' => ''
		);
		$status_icon = '<img src="' . RPW . '/admin/images/spacer.gif" alt="" width="133" height="1">';
	}
	//グループの状態を取得
	if ($objCGrp->fld['status'] == 304) {
		if ($objCGrp->fld['approve4'] == WEB_MASTER_CODE) {
			$wait_img = 'icon_wait_master.jpg';
			$wait_alt = 'ウェブマスター承認待ち';
		}
		else {
			$wait_img = 'icon_wait_opener.jpg';
			$wait_alt = '公開責任者承認待ち';
		}
	}
	else if ($objCGrp->fld['status'] == 303) {
		$wait_img = 'icon_wait_approver3.jpg';
		$wait_alt = '第三承認者承認待ち';
	}
	else if ($objCGrp->fld['status'] == 302) {
		$wait_img = 'icon_wait_approver2.jpg';
		$wait_alt = '第二承認者承認待ち';
	}
	else if ($objCGrp->fld['status'] == 301) {
		$wait_img = 'icon_wait_approver1.jpg';
		$wait_alt = '第一承認者承認待ち';
	}
	
	$group_no++;
	$pub_end = explode(" ", $objCGrp->fld['publish_end']);
	
	$html .= '<table width="100%" border="0" cellspacing="0" cellpadding="0">';
	$html .= '<tr>';
	$html .= '<td width="133" align="left" valign="top"><img src="' . RPW . '/admin/page/workflow/images/' . $wait_img . '" alt="' . $wait_alt . '" width="104" height="38"></td>';
	$html .= '<td width="27" align="center" valign="top" id="cms_group_cell_' . $LIST_NAME . $group_no . '"' . $group_box['background'] . '><a href="javascript:" onClick="return cxContentsGroupToggle(\'' . $LIST_NAME . $group_no . '\')"><img src="' . RPW . '/admin/page/workflow/images/' . $group_box['icon'] . '" alt="" width="13" height="13" border="0" id="cms_group_icon_' . $LIST_NAME . $group_no . '"></a></td>';
	$html .= '<td align="left" valign="top">';
	$html .= '<p><strong>' . htmlDisplay($objCGrp->fld['group_name']) . '</strong></p>';
	$html .= '<p>';
	
	$html .= '<small>公開期間：<span id="cms_publish_skip_start_' . $cntCG . '">' . dtFormat($objCGrp->fld['publish_start'], 'Y年n月j日H時') . '</span>から<span id="cms_publish_skip_end_' . $cntCG . '">' . get_publish_end_date($objCGrp->fld['publish_end']) . '</span>まで</small>&nbsp;';
	if (get_publish_end_date($objCGrp->fld['publish_end']) == PUB_INDEFINITE) {
		$unrestricted_checked = "checked";
	}
	else {
		$unrestricted_checked = "";
	}
	
	$html .= '<a href="javascript:" onClick="return cxPublicSetting(\'cms_publish_skip_\',' . $cntCG . ')"><img src="' . RPW . '/admin/images/btn/btn_setup_on.gif" alt="設定" width="60" height="20" border="0" class="cms8341-verticalMiddle" style="border:0px;"></a>';
	$html .= '</p>';
	$html .= '<p><small>承認依頼者：' . htmlDisplay($objCGrp->fld['dept_name']) . ' ' . htmlDisplay($objCGrp->fld['name']) . '</small></p>';
	$html .= '<p><small>承認依頼日：' . dtFormat($objCGrp->fld['request_datetime'], 'Y年n月j日H時i分s秒') . '</small></p>';
	$html .= '<div id="cms_group_block_' . $LIST_NAME . $group_no . '" class="cms8341-groupcontents" style="display:' . $group_box['display'] . '">';
	$checkbox_ary = array();
	while ($objPage->fetch()) {
		$menu_no++;
		$fld = $objPage->fld;
		if ($fld['work_class'] == 1) {
			$wc_img = 'pc_new.jpg';
			$wc_alt = '新規';
			$link_mode = 'edit';
		}
		else if ($fld['work_class'] == 2) {
			$wc_img = 'pc_edit.jpg';
			$wc_alt = '更新';
			$link_mode = 'edit';
		}
		else if ($fld['close_flg'] == 1) {
			$wc_img = 'pc_close.jpg';
			$wc_alt = '非公開';
			$link_mode = 'del';
		}
		else {
			$wc_img = 'pc_del.jpg';
			$wc_alt = '削除';
			$link_mode = 'del';
		}
		$output_str = "";
		if (ENABLE_OPTION_OUTPUT && count(getOutputPageFromPageId($fld['page_id'], HANDLER_OUTPUT_CLASS_WORK_PAGE)) > 0) {
			$output_str = '<img src="' . RPW . '/admin/page/workflow/images/icon_output.gif" alt="外部連携データ出力あり" width="16" height="16" class="cms8341-verticalMiddle">';
		}
		// ページ出力設定がされていない場合アイコン表示
		$not_output_html_str = "";
		$output_html_flg = (isset($fld['output_html_flg']) ? $fld['output_html_flg'] : FLAG_ON);
		if ($output_html_flg == FLAG_OFF) {
			$not_output_html_str = '<img src="' . RPW . '/admin/page/workflow/images/icon_not_output_html.gif" alt="ページ出力なし" width="16" height="16" class="cms8341-verticalMiddle">';
		}
		
		$autolink_str = "";
		$objALink->selectFromPageID($fld['page_id'], WORK_TABLE);
		if ($objALink->getRowCount() > 0) {
			$autolink_str = '<img src="' . RPW . '/admin/page/workflow/images/icon_autolink.gif" alt="自動リンクあり" width="18" height="16" class="cms8341-verticalMiddle">';
		}
		
		// 前回否認されたページの場合ボタンを表示(承認依頼されたグループ)
		$denial_btn = '';
		if ($objCGrp->fld['status'] != 305 && $objAppHandler->is_denial_msg($fld['page_id'])) {
			$denial_btn = '<a href="javascript:" onclick="return cxDenialMsg(\'' . $fld['page_id'] . '\')"><img src="' . RPW . '/admin/images/btn/btn_denial_msg.jpg" alt="前回の否認理由" width="80" height="20" class="cms8341-verticalMiddle" border="0"></a>';
		}
		
		$html .= '<p><img src="' . RPW . '/admin/page/workflow/images/' . $wc_img . '" alt="' . $wc_alt . '" width="70" height="20"><a href="javascript:" onClick="return cxContentsMenu2(event, \'cms_menu_' . $LIST_NAME . $menu_no . '\',' . $fld['page_id'] . ',\'cms_CMenu\',\'' . $LIST_NAME . '\')"  onContextMenu="cxContentsMenu2(event, \'cms_menu_' . $LIST_NAME . $menu_no . '\',' . $fld['page_id'] . ',\'cms_CMenu\',\'' . $LIST_NAME . '\');return false;">' . htmlDisplay($fld['page_title']) . '</a>&nbsp;' . $not_output_html_str . $output_str . $autolink_str . $denial_btn . '</p>';
		//メニューの作成
		$html .= '<div id="cms_menu_' . $LIST_NAME . $menu_no . '" class="cms8341-layer"></div>';
		//チェックボックス作成用配列に格納
		$checkbox_ary[$fld['page_id']] = $fld['page_title'];
	}
	
	$html .= '<div class="cms8341-requestarea">';
	$html .= '<p><img src="' . RPW . '/admin/page/workflow/images/label_request_w.jpg" alt="依頼内容" width="56" height="14"></p>';
	$html .= '<p>' . htmlDisplay($objCGrp->fld['note1']) . '</p>';
	$html .= '</div>';
	
	//（承認依頼）承認・否認ボタン
	if ($objCGrp->fld['status'] != 305) {
		$html .= '<p>';
		$html .= '<a href="javascript:" onClick="return cxApprove(\'cms_publish_skip_\',\'' . $group_id . '\',\'' . $cntCG . '\')"><img src="' . RPW . '/admin/images/btn/btn_recog.jpg" alt="承認する" width="100" height="20" hspace="20" border="0" align="absmiddle"></a>';
		$html .= '<a href="javascript:" onClick="return cxDenailReason(\'' . $group_id . '\',\'1\')"><img src="' . RPW . '/admin/images/btn/btn_denail.jpg" alt="否認する" width="100" height="20" border="0" align="absmiddle"></a>';
		$html .= '</p>';
	} //（否認済み）否認理由を表示 
	else {
		$html .= '<div class="cms8341-denailarea">';
		$html .= '<p><img src="' . RPW . '/admin/page/workflow/images/label_denial.jpg" alt="否認理由" width="55" height="14"></p>';
		$html .= '<p>' . htmlDisplay($objCGrp->fld['note2']) . '</p>';
		$html .= '</div>';
	}
	$html .= '</div>';
	$html .= '</td>';
	$html .= '</tr>';
	$html .= '</table>';
	if ($objCGrp->fetchrow < $objCGrp->getRowCount()) $html .= '<hr>';
}
//1件も無い場合
if ($cntCG == 0) {
	$html .= '<table width="100%" border="0" cellspacing="0" cellpadding="0" id="cms8341-skiplist_none">' . "\n";
	$html .= '<tr><td>承認依頼されたグループはありません。</td></tr>' . "\n";
	$html .= '</table>' . "\n";
} //1件以上ある場合
else {
	//全体を囲う枠を閉じる
	$html .= '</div>';
	//ページ数の表示
	$html .= '<table width="100%" border="0" cellspacing="0" cellpadding="0" style="margin-bottom:10px;padding:1px">';
	$html .= '<tr>';
	$html .= '<td width="30%" align="left" valign="middle" scope="row">' . $objP->getBackLink('cxPageSet_Skiplist') . '</td>';
	$html .= '<td width="40%" align="center" valign="middle">' . $objP->getViewCount('cxPageSet_Skiplist') . '</td>';
	$html .= '<td width="30%" align="right" valign="middle">' . $objP->getNextLink('cxPageSet_Skiplist') . '</td>';
	$html .= '</tr>';
	$html .= '</table>';
}
print $html;
?>
