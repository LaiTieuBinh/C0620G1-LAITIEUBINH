<?php
/*
 * 否認されたグループ
 */
?>
<div class="cms8341-areamessage" id="cms8341-denaillist-msg"
	style="display: none">※「修正する」ボタンをクリックすると、承認グループのページがワークスペースに展開されます。
&nbsp;展開後、各ページに対して必要な修正を行い、再度承認依頼をしてください。</div>
<div class="cms8341-area-box">
<?php
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

//定数の宣言
$LIST_NAME = "denail";

// 否認コンテンツ情報を取得
$objCGrp->selectDenial($login['user_id']);
$cntCG = 0;
while ($objCGrp->fetch()) {
	$objPage->selectFromGroupID($objCGrp->fld['group_id']);
	
	// 移行作業用：否認時ファイル添付機能
	// 移行モードカスタマイズ 否認したユーザーのユーザー名を出力する
	if (IKOU_MODE == TRUE) {
		$denial_user_department = '';
		$denial_user_name = '';
		$obj_dac = new dac($objCnc);
		$sql = "SELECT name, dept_name FROM tbl_user WHERE user_id=" . $objCGrp->fld['approver_id'];
		$obj_dac->execute($sql);
		if ($obj_dac->fetch()) {
			// 取得したユーザー名を保存
			$denial_user_department = $obj_dac->fld['dept_name'];
			$denial_user_name = $obj_dac->fld['name'];
		}
	}
	
	if ($objPage->getRowCount() == 0) continue;
	$cntCG++;
	$pub_end = explode(" ", $objCGrp->fld['publish_end']);
	?>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="133" align="left" valign="top"><img
			src="images/icon_denial.jpg" alt="否認" width="104" height="23"></td>
		<td width="27" align="center" valign="top"
			style="background: url(images/bg_open.jpg) center repeat-y"><img
			src="<?=RPW?>/admin/page/workflow/images/icon_minus.jpg" alt=""
			width="13" height="13" border="0"></td>
		<td align="left" valign="top">
		<p><strong><?=htmlDisplay($objCGrp->fld['group_name'])?></strong><a
			href="javascript:"
			onClick="return cxRevise('<?=$objCGrp->fld['group_id']?>')"><img
			src="<?=RPW?>/admin/images/btn/btn_fix_mini.jpg" alt="修正する"
			width="60" height="20" hspace="20" border="0" align="absmiddle"></a></p>
		<p><small>公開期間：<?=dtFormat($objCGrp->fld['publish_start'], 'Y年m月d日H時')?>から<?=get_publish_end_date($objCGrp->fld['publish_end'])?>まで</small></p>
		<p><small>承認依頼日：<?=dtFormat($objCGrp->fld['request_datetime'], 'Y年n月j日H時i分s秒')?></small></p>
		<?php
		
		// 移行作業用：否認時ファイル添付機能
		if (IKOU_MODE == TRUE) {
			if ($denial_user_department != '') {
				print '<p><small>否認したユーザー：[' . $denial_user_department . ']&nbsp;' . $denial_user_name . '</small></p>';
			}
			else {
				print '<p><small>否認したユーザー：'. $denial_user_name . '</small></p>';
			}
			print '<p><small>否認日時：' . dtFormat($objCGrp->fld['approve_datetime'], 'Y年n月j日H時i分') . '</small></p>';
		}
		
		?>
		<div class="cms8341-groupcontents">
					<?php
	while ($objPage->fetch()) {
		$menu_no++;
		$fld = $objPage->fld;
		//デザインビュー用のファイルパスを公開側テーブルより取得
		if (!isset($fld['pub_file_path']) || $fld['pub_file_path'] == "") {
			$objPage_menu = new tbl_page($objCnc);
			$objPage_menu->selectFromID($fld['page_id'], PUBLISH_TABLE);
			$fld['pub_file_path'] = $objPage_menu->fld['file_path'];
		}
		if ($fld['work_class'] == 1) {
			$wc_img = 'pc_new.jpg';
			$wc_alt = '新規';
			$link_mode = 'edit';
		}
		else if ($fld['work_class'] == 2) {
			$wc_img = 'pc_edit.jpg';
			$wc_alt = '更新';
			$link_mode = 'edit';
		}
		else if ($fld['close_flg'] == 1) {
			$wc_img = 'pc_close.jpg';
			$wc_alt = '非公開';
			$link_mode = 'del';
		}
		else {
			$wc_img = 'pc_del.jpg';
			$wc_alt = '削除';
			$link_mode = 'del';
		}
		$output_str = "";
		if (ENABLE_OPTION_OUTPUT && count(getOutputPageFromPageId($fld['page_id'], HANDLER_OUTPUT_CLASS_WORK_PAGE)) > 0) {
			$output_str = '<img src="' . RPW . '/admin/page/workflow/images/icon_output.gif" alt="外部連携データ出力あり" width="16" height="16" class="cms8341-verticalMiddle">';
		}
		
		// ページ出力設定がされていない場合アイコン表示
		$not_output_html_str = "";
		$output_html_flg = (isset($fld['output_html_flg']) ? $fld['output_html_flg'] : FLAG_ON);
		if ($output_html_flg == FLAG_OFF) {
			$not_output_html_str = '<img src="' . RPW . '/admin/page/workflow/images/icon_not_output_html.gif" alt="ページ出力なし" width="16" height="16" class="cms8341-verticalMiddle">';
		}
		
		$autolink_str = "";
		$objALink->selectFromPageID($fld['page_id'], WORK_TABLE);
		if ($objALink->getRowCount() > 0) {
			$autolink_str = '<img src="' . RPW . '/admin/page/workflow/images/icon_autolink.gif" alt="自動リンクあり" width="18" height="16" class="cms8341-verticalMiddle">';
		}
		$fields = "p.*, w.file_path as w_file_path, w.page_title as w_page_title, w.close_flg AS w_close_flg, w.user_id AS work_user_id, u.dept_code AS dept_code, w.output_html_flg AS w_output_html_flg";
		$where = $objDac->_addslashesC("p.page_id", $fld['page_id']);
		$objDac->setTableName("tbl_publish_page AS p LEFT JOIN tbl_work_page AS w ON (p.page_id = w.page_id) LEFT JOIN tbl_user AS u ON (p.user_id = u.user_id)");
		$objDac->select($where, $fields);
		$objDac->fetch();
		$fld = array_merge($fld, $objDac->fld);
		
		echo '<p><img src="' . RPW . '/admin/page/workflow/images/' . $wc_img . '" alt="' . $wc_alt . '" width="70" height="20">';
		echo '<a href="javascript:"';
		echo ' onClick="return cxContentsMenu2(event, \'cms_menu_' . $LIST_NAME . $menu_no . '\',\'' . $fld['page_id'] . '\',\'cms_CMenu\',\'' . $LIST_NAME . '\')"';
		echo ' onContextMenu="cxContentsMenu2(event, \'cms_menu_' . $LIST_NAME . $menu_no . '\',\'' . $fld['page_id'] . '\',\'cms_CMenu\',\'' . $LIST_NAME . '\');return false;">';
		echo htmlDisplay((!empty($fld['w_page_title']) ? $fld['w_page_title'] : $fld['page_title'])) . '</a>&nbsp;' . $not_output_html_str . $output_str . $autolink_str . '</p>';
		echo '<div id="cms_menu_' . $LIST_NAME . $menu_no . '" class="cms8341-layer"></div>';
	}
	?>
		<div class="cms8341-denailarea">
		<p><img src="<?=RPW?>/admin/page/workflow/images/label_denial.jpg"
			alt="否認理由" width="55" height="14"></p>
		<p><?=htmlDisplay($objCGrp->fld['note2'])?></p>
		<?php
		
		// 移行作業用：否認時ファイル添付機能
		if (IKOU_MODE == TRUE && $objCGrp->fld['attached_file'] != NULL) {
			// 添付ファイルのダウンロードリンクを表示する
			print '<br /><br />';
			print '<p><a href="' . RPW . '/admin/page/common/file_download.php?dl_file_path=' . ATTACHED_FILE_SAVE_PATH . '/' . $objCGrp->fld['attached_file'] . '">否認理由添付ファイルダウンロード</a></p>' . "\n";
		}
		
		?>
		
		</div>
		</td>
	</tr>
</table>
<?php
	if ($objCGrp->fetchrow < $objCGrp->getRowCount()) {
		print '<hr>' . "\n";
	}
}
if ($cntCG == 0) {
	print '<table width="100%" border="0" cellspacing="0" cellpadding="0" id="cms8341-approvelist_none">' . "\n";
	print '<tr><td>否認されたグループはありません。</td></tr>' . "\n";
	print '</table>' . "\n";
}
else {
	print '<SCRIPT LANGUAGE="JavaScript">' . "\n";
	print '$(\'cms8341-denaillist-msg\').style.display = \'block\';' . "\n";
	print '</SCRIPT>' . "\n";
}
?>
</div>
