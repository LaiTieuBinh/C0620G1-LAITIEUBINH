<?php
/*
 *
 */
//外部ファイル読み込み
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/page_control.inc');
$objP = new page_control();
require_once ('./include/workflowCommonFunc.inc');

//定数の宣言
$LIST_NAME = "publicwait";

//変数の宣言
$login = $objLogin->login;
$search = array();
$html = "";
$menu_no = 0;
$page = (isset($_POST['cms_page']) && is_numeric($_POST['cms_page']) ? floor($_POST['cms_page']) : 1);
$row_cnt = 0;
$MAXROW_LIST = getDefineArray("MAXROW_LIST");
$maxRow = (isset($_POST['maxrow']) && is_numeric($_POST['maxrow']) ? floor($_POST['maxrow']) : key($MAXROW_LIST));
//検索条件の取得
// ページID検索
if (!empty($_POST['page_id'])) {
	$search['page_id'] = explode(' ', preg_replace('/\s+/', ' ', $_POST['page_id']));
}
if (isset($_POST['page_title']) && $_POST['page_title'] != '') {
	$search['page_title'] = str_replace('　', ' ', $_POST['page_title']);
	$search['page_title'] = str_replace('＆', '&', $search['page_title']);
	$search['page_title'] = trim($search['page_title']);
}
if (isset($_POST['search_keywords']) && $_POST['search_keywords'] != '') {
	$search['search_keywords'] = str_replace('　', ' ', $_POST['search_keywords']);
	$search['search_keywords'] = str_replace('＆', '&', $search['search_keywords']);
	$search['search_keywords'] = trim($search['search_keywords']);
}
if (isset($_POST['is_tag_search']) && $_POST['is_tag_search'] != '') {
	$search['is_tag_search'] = $_POST['is_tag_search'];
}
if (isset($_POST['pdsy']) && isset($_POST['pdsm']) && isset($_POST['pdsd']) && ($_POST['pdsy'] != '') && ($_POST['pdsm'] != '') && ($_POST['pdsd'] != '')) $search['publish_start'] = $_POST['pdsy'] . '-' . $_POST['pdsm'] . '-' . $_POST['pdsd'];
if (isset($_POST['pdey']) && isset($_POST['pdem']) && isset($_POST['pded']) && ($_POST['pdey'] != '') && ($_POST['pdem'] != '') && ($_POST['pded'] != '')) $search['publish_end'] = $_POST['pdey'] . '-' . $_POST['pdem'] . '-' . $_POST['pded'] . ' 23:59:59';

if (isset($_POST['mode'])) {
	if ($_POST['mode'] == "last_condition") {
		$search = $_SESSION['last_search_condition']['publicwaitlist'];
		$maxRow = $search['maxrow'];
		$page = 1;
	}
	elseif ($_POST['mode'] == "search") {
		$search['maxrow'] = $maxRow;
		$_SESSION['last_search_condition']['publicwaitlist'] = $search;
	}
}

//ページ情報の作成
$objPage->selectPublishWait($search);
$row_cnt = $objPage->getRowCount();
$objP->limit = $maxRow;
$objP->set($page, $row_cnt);
if ($row_cnt > 0) {
	$html .= '<table width="100%" border="0" cellspacing="0" cellpadding="0" style="margin-bottom:10px;padding:1px">';
	$html .= '<tr valign="top">';
	$html .= '<td colspan="3" align="right">';
	if (isset($_SESSION['last_search_condition']['publicwaitlist'])) {
		$html .= '<span style="margin:15px;" class="cms8341-verticalMiddle"><a href="javascript:" onclick="return cxLastSearch()"><img src="' . RPW . '/admin/images/btn/btn_search_condition.jpg" alt="前回の条件で検索" width="150" height="20" border="0" class="cms8341-verticalMiddle"></a></span>';
	}
	$html .= mkcombobox($MAXROW_LIST, "dispNum_publicwaitlist", $maxRow, "cxDispNum(this.value,'publicwaitlist')");
	$html .= '</td>';
	$html .= '</tr>';
	$html .= '<tr>';
	$html .= '<td width="30%" align="left" valign="middle" scope="row">' . $objP->getBackLink('cxPageSet_Publicwaitlist') . '</td>';
	$html .= '<td width="40%" align="center" valign="middle">' . $objP->getViewCount('cxPageSet_Publicwaitlist') . '</td>';
	$html .= '<td width="30%" align="right" valign="middle">' . $objP->getNextLink('cxPageSet_Publicwaitlist') . '</td>';
	$html .= '</tr>';
	$html .= '</table>';
}
else
	$html .= '<input type="hidden" id="dispNum_publicwaitlist" value="' . $maxRow . '">';
	//公開待ちページ情報を取得
$search['p'] = $page;
$search['disp_num'] = $maxRow;
$objPage->selectPublishWait($search);

//一件も無い場合
if ($objPage->getRowCount() == 0) {
	if (isset($_SESSION['last_search_condition']['publicwaitlist'])) {
		$html .= '<div style="margin-bottom:10px;padding:1px" align="right">';
		$html .= '<span style="margin:15px;" class="cms8341-verticalMiddle"><a href="javascript:" onclick="return cxLastSearch()"><img src="' . RPW . '/admin/images/btn/btn_search_condition.jpg" alt="前回の条件で検索" width="150" height="20" border="0" class="cms8341-verticalMiddle"></a></span>';
		$html .= '</div>';
	}
	$html .= '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable" id="cms8341-waitinglist_none">';
	$html .= '<tr><th align="center" valign="middle" scope="col" style="font-weight:normal">&nbsp;</th></tr>';
	$html .= '<tr><td align="center" valign="middle">公開待ちのページはありません。</td></tr>';
	$html .= '</table>';
}
else {
	$html .= '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">';
	$html .= '<tr>';
	$html .= '<th width="80" align="center" valign="middle" scope="col" style="font-weight:normal">状態</th>';
	$html .= '<th align="center" valign="middle" scope="col" style="font-weight:normal">タイトル</th>';
	$html .= '</tr>';
	$menu_no = 0;
	while ($objPage->fetch()) {
		$menu_no++;
		$fld = $objPage->fld;
		$pub_end = explode(" ", $fld['publish_end']);
		
		$pubdate = '公開期間：' . dtFormat($fld['publish_start'], 'Y年m月d日H時') . 'から' . get_publish_end_date($fld['publish_end']) . 'まで';
		
		if ($fld['work_class'] == 1) {
			$icon_img = 'icon_new.jpg';
			$icon_alt = '新規';
			$link_mode = 'edit';
			$prop_mode = '2';
		}
		else if ($fld['work_class'] == 2) {
			$icon_img = 'icon_edit.jpg';
			$icon_alt = '更新';
			$link_mode = 'edit';
			;
			$prop_mode = '2';
		}
		else if ($fld['close_flg'] == 1) {
			$icon_img = 'icon_close.jpg';
			$icon_alt = '非公開';
			$link_mode = 'del';
			$pubdate = '非公開日時：' . dtFormat($fld['publish_start'], 'Y年m月d日H時');
			$prop_mode = '1';
		}
		else {
			$icon_img = 'icon_del.jpg';
			$icon_alt = '削除';
			$link_mode = 'del';
			$pubdate = '削除日時：' . dtFormat($fld['publish_start'], 'Y年m月d日H時');
			$prop_mode = '1';
		}
		
		// ページ出力設定がされていない場合アイコン表示
		$not_output_html_str = "";
		$output_html_flg = (isset($fld['output_html_flg']) ? $fld['output_html_flg'] : FLAG_ON);
		if ($output_html_flg == FLAG_OFF) {
			$not_output_html_str = '<img src="' . RPW . '/admin/page/workflow/images/icon_not_output_html.gif" alt="ページ出力なし" width="16" height="16" class="cms8341-verticalMiddle">';
		}
		
		$html .= '<tr>';
		$html .= '<td width="80" align="center" valign="middle"><img src="' . RPW . '/admin/page/workflow/images/' . $icon_img . '" alt="' . $icon_alt . '" width="70" height="25"></td>';
		$html .= '<td align="left" valign="top">';
		$html .= '<div>';
		$html .= '<p><strong><a href="javascript:" onClick="return cxContentsMenu2(event, \'cms_menu_' . $LIST_NAME . $menu_no . '\',' . $fld['page_id'] . ',\'cms_CMenu\',\'' . $LIST_NAME . '\')" onContextMenu="cxContentsMenu2(event, \'cms_menu_' . $LIST_NAME . $menu_no . '\',' . $fld['page_id'] . ',\'cms_CMenu\',\'' . $LIST_NAME . '\');return false;">' . htmlDisplay($fld['page_title']) . '</a></strong>&nbsp;' . $not_output_html_str . '</p>';
		$html .= '<div id="cms_menu_' . $LIST_NAME . $menu_no . '" class="cms8341-layer"></div>';
		$html .= '</div>';
		$html .= '<p><small>' . $pubdate . '</small></p>';
		if ($fld['request_datetime'] != "") {
			$html .= '<p><small>承認依頼者：' . htmlDisplay($fld['dept_name']) . ' ' . htmlDisplay($objPage->fld['name']) . '</small></p>';
			$html .= '<p><small>承認依頼日：' . dtFormat($fld['request_datetime'], 'Y年n月j日H時i分s秒') . '</small></p>';
		}
		//メニューの作成
		//$html .= '<div id="cms_menu_' . $LIST_NAME . $menu_no . '" class="cms8341-layer"></div>';
		$html .= '</td>';
		$html .= '</tr>';
	}
	$html .= '</table>';
	//ページ数の表示
	$html .= '<table width="100%" border="0" cellspacing="0" cellpadding="0" style="margin-bottom:10px;padding:1px">';
	$html .= '<tr>';
	$html .= '<td width="30%" align="left" valign="middle" scope="row">' . $objP->getBackLink('cxPageSet_Publicwaitlist') . '</td>';
	$html .= '<td width="40%" align="center" valign="middle">' . $objP->getViewCount('cxPageSet_Publicwaitlist') . '</td>';
	$html .= '<td width="30%" align="right" valign="middle">' . $objP->getNextLink('cxPageSet_Publicwaitlist') . '</td>';
	$html .= '</tr>';
	$html .= '</table>';
}
//検索条件の追加
if (isset($search['publish_start'])) $pub_st_date = explode("-", $search['publish_start']);
if (isset($search['publish_end'])) $pub_ed_date = explode("-", $search['publish_end']);
// ページID検索
$html .= '<input type="hidden" id="search_page_id" value="' . (!empty($search['page_id']) ? implode(' ', $search['page_id']) : '') . '">';
$html .= '<input type="hidden" id="search_page_title" value="' . (isset($search['page_title']) ? $search['page_title'] : "") . '">';
$html .= '<input type="hidden" id="search_keywords" value="' . (isset($search['search_keywords']) ? $search['search_keywords'] : "") . '">';
$html .= '<input type="hidden" id="is_tag_search" value="' . (isset($search['is_tag_search']) ? $search['is_tag_search'] : "") . '">';
$html .= '<input type="hidden" id="search_pdsy" value="' . (isset($pub_st_date[0]) ? $pub_st_date[0] : "") . '">';
$html .= '<input type="hidden" id="search_pdsm" value="' . (isset($pub_st_date[1]) ? $pub_st_date[1] : "") . '">';
$html .= '<input type="hidden" id="search_pdsd" value="' . (isset($pub_st_date[2]) ? (int) $pub_st_date[2] : "") . '">';
$html .= '<input type="hidden" id="search_pdey" value="' . (isset($pub_ed_date[0]) ? $pub_ed_date[0] : "") . '">';
$html .= '<input type="hidden" id="search_pdem" value="' . (isset($pub_ed_date[1]) ? $pub_ed_date[1] : "") . '">';
$html .= '<input type="hidden" id="search_pded" value="' . (isset($pub_ed_date[2]) ? (int) $pub_ed_date[2] : "") . '">';
print $html;
?>
