<?php
/*
 * ワークフロー
 */
require ("../.htsetting");

// 戻り先設定
//	$_SESSION['back_path'] = $_SERVER['SCRIPT_NAME'];


$login = $objLogin->login;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_contents_group.inc');
$objCGrp = new tbl_contents_group($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_auto_link.inc');
$objALink = new tbl_auto_link($objCnc);

//定数の宣言
$MAXROW_LIST = getDefineArray("MAXROW_LIST");

//変数の宣言
$group_no = 0;
$menu_no = 0;

// エリアの開閉状態
$boxClose = array(
		'display' => 'none', 
		'btn' => 'btn_open_mini.jpg', 
		'alt' => '開く'
);
$boxOpen = array(
		'display' => 'block', 
		'btn' => 'btn_close_mini.jpg', 
		'alt' => '閉じる'
);
$area_box = array(
		'main' => $boxClose, 
		'progress' => $boxClose, 
		'skip' => $boxClose, 
		'waiting' => $boxClose
);
if (isset($_GET['open'])) {
	if ($_GET['open'] == 'p') {
		$area_box['progress'] = $boxOpen;
	}
	elseif ($_GET['open'] == 'w') {
		$area_box['waiting'] = $boxOpen;
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ワークフロー</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/workflow.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/term.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/workflow.js" type="text/javascript"></script>
<script type="text/javascript">
			<!--
				<?php
				echo loadSettingVars();
				?>
			//-->
		</script>
</head>
<body id="cms8341-mainbg">
		<?php
		// ヘッダーメニュー挿入
		$headerMode = 'workflow';
		include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
		?>
		<form name="cms_CMenu" id="cms_CMenu" class="cms8341-form"
	method="post" action="" target=""><input type="hidden" name="cms_preview_color"
	id="cms_preview_color" value="" disabled> <input type="hidden"
	name="cms_dispMode" value=""> <input type="hidden" name="cms_page_id"
	value=""></form>
<form name="cms_fApprove" id="cms_fApprove" class="cms8341-form"
	method="post" action="<?=RPW?>/admin/page/common/approve.php"><input
	type="hidden" name="cms_dispMode" id="cms_dispMode" value=""> <input type="hidden"
	name="cms_group_id" id="cms_group_id" value=""> <input type="hidden"
	name="cms_note2" id="cms_note2" value=""> <input type="hidden"
	name="cms_publish_start" id="cms_publish_start" value=""> <input
	type="hidden" name="cms_publish_end" id="cms_publish_end" value=""> <input
	type="hidden" name="cms_isSkip" id="cms_isSkip" value="0"> <input
	type="hidden" name="cms_denial_page" id="cms_denial_page" value=""></form>
<div align="center" id="cms8341-contents">
			<?php
			// 否認ページリスト -- 作成者
			if ($login['class'] == USER_CLASS_WRITER && $login['isRegain'] == FALSE) {
				?>
				<div class="cms8341-workgroup" id="cms8341-denaillist">
<div><img src="images/bar_denial.jpg" alt="否認されたグループ" width="920"
	height="30"></div>
<div id="cms8341-approvelist" style="display: none">
						<?php
				include ("./denaillist.php");
				?>
					</div>
<div style="width:910px;height:17px;background:url(<?=RPW?>/admin/page/workflow/images/barbottom_approve.jpg) no-repeat;padding-right:10px;padding-top:2px;" align="right"><img
	src="<?=RPW?>/admin/images/spacer.gif" alt="" width="80" height="15"
	border="0" id="cms-approveSwitch"
	onClick="cxBlind('cms8341-approvelist','cms-approveSwitch')"
	style="cursor: pointer"></div>
</div>
			<?php
			} //承認依頼されたグループ -- 作成者以外
			else {
				?>
				<div class="cms8341-workgroup" id="cms-requestlist">
<div><img src="<?=RPW?>/admin/page/workflow/images/bar_request.jpg"
	alt="承認依頼されたグループ" width="920" height="30"></div>
<div class="cms8341-area-box" id="cms8341-approvelist"
	style="display: none;">
						<?php
				$params = array(
						'objCnc' => $objCnc, 
						'objLogin' => $objLogin
				);
				print(get_include_contents('./approvelist.php', $params));
				?>
					</div>
<div style="margin: 0 auto;width:910px;height:17px;background:url(<?=RPW?>/admin/page/workflow/images/barbottom_approve.jpg) no-repeat;padding-right:10px;padding-top:2px;" align="right"><img
	src="<?=RPW?>/admin/images/spacer.gif" alt="" width="80" height="15"
	border="0" id="cms-approveSwitch"
	onClick="cxBlind('cms8341-approvelist','cms-approveSwitch')"
	style="cursor: pointer"></div>
</div>
			<?php
			}
			//承認待ちグループ -- ウェブマスター以外
			if ($login['class'] != USER_CLASS_WEBMASTER && $login['isRegain'] == FALSE) {
				?>
				<div class="cms8341-workgroup">
<div><img src="<?=RPW?>/admin/page/workflow/images/bar_progress.jpg"
	alt="承認待ちグループ" width="920" height="30"></div>
<div class="cms8341-area-box" id="cms8341-progresslist"
	style="display: none;">
						<?php
				$params = array(
						'objCnc' => $objCnc, 
						'objLogin' => $objLogin
				);
				print(get_include_contents('./progresslist.php', $params));
				?>
					</div>
<div style="margin: 0 auto;width:910px;height:17px;background:url(<?=RPW?>/admin/page/workflow/images/barbottom_progress.jpg) no-repeat;padding-right:10px;padding-top:2px;" align="right"><img
	src="<?=RPW?>/admin/images/spacer.gif" alt="" width="80" height="15"
	border="0" id="cms-progressSwitch"
	onClick="cxBlind('cms8341-progresslist','cms-progressSwitch')"
	style="cursor: pointer"></div>
</div>
			<?php
			}
			//承認依頼予定のグループ -- ウェブマスター以外
			if ($login['class'] != USER_CLASS_WRITER && $login['isRegain'] == FALSE) {
				?>
				<div class="cms8341-workgroup">
<div><img src="<?=RPW?>/admin/page/workflow/images/bar_skip.jpg"
	alt="承認依頼予定のグループ" width="920" height="30"></div>
<div class="cms8341-area-box" id="cms8341-skiplist"
	style="display: none;">
						<?php
				$params = array(
						'objCnc' => $objCnc, 
						'objLogin' => $objLogin
				);
				print(get_include_contents('./skiplist.php', $params));
				?>
					</div>
<div style="margin: 0 auto;width:910px;height:17px;background:url(<?=RPW?>/admin/page/workflow/images/bottom_skip.jpg) no-repeat;padding-right:10px;padding-top:2px;" align="right"><img
	src="<?=RPW?>/admin/images/spacer.gif" alt="" width="80" height="15"
	border="0" id="cms-skipSwitch"
	onClick="cxBlind('cms8341-skiplist','cms-skipSwitch')"
	style="cursor: pointer"></div>
</div>
			<?php
			}
			//公開待ちリスト
			?>
			<div class="cms8341-workgroup">
<div><img src="<?=RPW?>/admin/page/workflow/images/bar_waiting.jpg"
	alt="公開待ちページリスト" width="920" height="30"></div>
<div class="cms8341-area-box" id="cms8341-waitinglist"
	style="display: none;">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td>
		<table width="100%" border="0" cellspacing="0" cellpadding="10">
			<!-- ページID検索 -->
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページID</th>
				<td align="left" valign="middle"><input type="text"
					id="cms_search_page_id" name="cms_search_page_id"
					style="width: 250px; ime-mode: disabled;">
					<br><small>※複数指定する場合はスペース区切りで指定してください。</small></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページタイトル</th>
				<td><input type="text" id="cms_search_page_title"
					name="cms_search_page_title" style="width: 500px;"></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">キーワード</th>
				<td align="left" valign="middle"><input type="radio"
					name="cms_is_tag_search" id="cms_is_tag_search_0" value="0" checked><label
					for="cms_is_tag_search_0">HTMLのタグを対象としない</label><input type="radio"
					name="cms_is_tag_search" id="cms_is_tag_search_1" value="1"><label
					for="cms_is_tag_search_1">HTMLのタグを対象とする</label><br>
				<input type="text" id="cms_search_keywords"
					name="cms_search_keywords" style="width: 500px;"> <small>※大文字と小文字は区別されません。</small>
				</td>
			</tr>
			<tr>
				<th width="70" align="left" valign="middle" nowrap scope="row">公開日</th>
				<td><input type="text" value="" maxlength="4" id="cms_pdsy"
					name="cms_pdsy" style="width: 60px; ime-mode: disabled"> 年 <input
					type="text" value="" maxlength="2" id="cms_pdsm" name="cms_pdsm"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					value="" maxlength="2" id="cms_pdsd" name="cms_pdsd"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="cxComboHidden();return cxCalendarSet('cms_pdsy','cms_pdsm','cms_pdsd')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a> から <input
					type="text" maxlength="4" id="cms_pdey" name="cms_pdey"
					style="width: 60px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="cms_pdem" name="cms_pdem"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="cms_pded" name="cms_pded"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="cxComboHidden();return cxCalendarSet('cms_pdey','cms_pdem','cms_pded')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a></td>
			</tr>
		</table>
		</td>
		<td width="26" align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="113" align="right" valign="middle"><a href="javascript:"
			onClick="return cxSearch()"><img
			src="<?=RPW?>/admin/images/btn/btn_search.jpg" alt="検索する" width="101"
			height="21" border="0"></a></td>
	</tr>
</table>
</div>
<div id="cms8341-publicwaitlist">
						<?php
						$params = array(
								'objCnc' => $objCnc, 
								'objLogin' => $objLogin
						);
						print(get_include_contents('./publicwaitlist.php', $params));
						?>
					</div>
</div>
<div style="margin: 0 auto;width:910px;height:17px;background:url(<?=RPW?>/admin/page/workflow/images/barbottom_waiting.jpg) no-repeat;padding-right:10px;padding-top:2px;" align="right"><img
	src="<?=RPW?>/admin/images/spacer.gif" alt="" width="80" height="15"
	border="0" id="cms-waitingSwitch"
	onClick="cxBlind('cms8341-waitinglist','cms-waitingSwitch')"
	style="cursor: pointer"></div>
</div>
</div>
<!--***公開開始日、終了日設定レイヤー ここから********************************-->
<div id="cms8341-public_setting" class="cms8341-layer">
<form name="cms_public_setting" class="cms8341-form" method="post"
	action="">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0" style="background-image:url(<?=RPW?>/admin/images/layer/titlebar_bg.jpg);height:30px;">
			<tr>
				<td width="220" align="left" valign="middle"><img
					src="<?=RPW?>/admin/page/workflow/images/change_publish.jpg"
					alt="公開期間設定" width="200" height="20" style="margin: 4px 10px;"></td>
				<td align="right" valign="middle"><a href="javascript:"
					onClick="return delLayer('cms8341-public_setting')"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div id="cms8341-termarea">
		<div align="center"><input name="cms_page_id" type="hidden" value="">
		<table width="95%" border="0" cellpadding="5" cellspacing="0">
			<tr>
				<th width="170" align="left" valign="top"><label for="cms_psy_l">公開開始日
				<span class="font-red">（必須）</span></label></th>
				<td align="left" valign="top"><input name="cms_psy_l" type="text"
					maxlength="4" style="width: 40px;" id="cms_psy_l"
					style="ime-mode:disabled;"><label for="cms_psy_l">年</label> <input
					name="cms_psm_l" type="text" maxlength="2" style="width: 20px;"
					id="cms_psm_l" style="ime-mode:disabled;"><label for="cms_psm_l">月</label>
				<input name="cms_psd_l" type="text" maxlength="2"
					style="width: 20px;" id="cms_psd_l" style="ime-mode:disabled;"><label
					for="cms_psd_l">日</label> <input name="cms_psh_l" type="text"
					maxlength="2" style="width: 20px;" id="cms_psh_l"
					style="ime-mode:disabled;"><label for="cms_psh_l">時</label> <a
					href="javascript:"
					onClick="cxComboHidden();return cxCalendarSet('cms_psy_l','cms_psm_l','cms_psd_l','layer')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a></td>
			</tr>
			<tr>
				<th align="left" valign="top"><label for="cms_pey_l">公開終了日 <span
					class="font-red">（必須）</span></label></th>
				<td align="left" valign="top"><input name="cms_pey_l" type="text"
					maxlength="4" style="width: 40px;" id="cms_pey_l"
					style="ime-mode:disabled;"><label for="cms_pey_l"
					id="cms_pey_l_label">年</label> <input name="cms_pem_l" type="text"
					maxlength="2" style="width: 20px;" id="cms_pem_l"
					style="ime-mode:disabled;"><label for="cms_pem_l"
					id="cms_pem_l_label">月</label> <input name="cms_ped_l" type="text"
					maxlength="2" style="width: 20px;" id="cms_ped_l"
					style="ime-mode:disabled;"><label for="cms_ped_l"
					id="cms_ped_l_label">日</label> <input name="cms_peh_l" type="text"
					maxlength="2" style="width: 20px;" id="cms_peh_l"
					style="ime-mode:disabled;"><label for="cms_peh_l">時</label> <a
					href="javascript:"
					onClick="cxComboHidden();return cxCalendarSet('cms_pey_l','cms_pem_l','cms_ped_l','layer')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a>
<?php
if (USE_INDEFINITE == true) {
	?>
<br>
				<input name="cms-pubend-Unrestricted-wf" type="checkbox"
					id="cms-pubend-Unrestricted-wf" style="width: 15px" value=""
					onclick="cxPublicEndUnrestricted();"><label
					for="cms-pubend-Unrestricted-wf"><?=PUB_INDEFINITE?></label>
<?php
}
?>
</td>
			</tr>
		</table>
		<p><a href="javascript:"
			onClick="return cxPublicSettingSubmit('2','/admin/nonpublic.php')"><img
			src="<?=RPW?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
			height="21" border="0"></a></p>
		</div>
		</div>
		</td>
	</tr>
</table>
</form>
</div>
<!--***公開開始日、終了日設定ここまで********************************-->
<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return delLayer('cms8341-calendar')"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px;">
		<div id="cms8341-calbody"
			style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
<!--***ページプロパティレイヤー ここから********************************-->
<div id="cms8341-property" class="cms8341-layer">
<table width="600" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="600" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="600" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/pageproperty/title_pageproperty.jpg"
					alt="ページプロパティ" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return delLayer('cms8341-property')"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 560px; height: 470px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center" id="cms8341-propertybody"><!-- ****** ページプロパティ表示領域 ここから ********* -->
		ここに各ページのページプロパティが代入されます。 <!-- ****** ページプロパティ表示領域 ここまで ********* --></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***ページプロパティレイヤー ここまで********************************-->
<!-- ** 否認理由レイヤー　ここから *************************************** -->
<div id="cms8341-denailreason" class="cms8341-layer">
<?php

// 移行作業用：否認時ファイル添付機能
if (IKOU_MODE == TRUE) {
?>
<form name="cms_denial_form" id="cms_denial_form" class="cms8341-form" method="post" action="<?=RPW?>/admin/page/common/approve.php" enctype="multipart/form-data">
<?php
}

?>
<table width="600" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="600" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="600" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/page/workflow/images/title_denial.jpg" alt="否認"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return delLayer('cms8341-denailreason')"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div id="cms-denail-back-area"
			style="width: 560px; height: 270px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<p align="left" id="cms-denail-progress">処理中です・・・</p>
		<table id="cms_denail_table" width="540" border="0" cellpadding="5"
			cellspacing="0" class="cms8341-dataTable"
			style="border-collapse: collapse; border: solid 1px #CCCCCC;">
			<tr id="cms_denail_pages_tr">
				<th width="145" align="left" valign="top" nowrap scope="row">否認理由入力ページ
				<span class="cms_require">（必須）</span> <br>
				<br>
				<!--
				移行作業用：否認時ファイル添付機能
				否認理由入力ダイアログのサイズ調整
				-->
				<span style="font-size: small; font-weight: normal;">※否認理由を入力するページを<br />選択してください</span></th>
				
				<td align="left" valign="top" id="cms_denail_pages_td">
				ここに対象ページのチェックボックスが代入されます。</td>
			</tr>
			<tr id="cms_denail_note_tr">
				<th width="145" align="left" valign="top" nowrap scope="row">否認理由 <span
					class="cms_require">（必須）</span></th>
				<td align="left" valign="middle" id="cms_denail_note_td">
				ここに対象ページのテキストエリアが代入されます。</td>
			</tr>
			<?php
			
			// 移行作業用：否認時ファイル添付機能
			// 移行モードの場合、否認する際に添付ファイルの指定を可能とする
			if (IKOU_MODE == TRUE) {
			?>
				<tr id="cms_denial_file_tr">
					<th width="145" align="left" valign="top" nowrap scope="row">添付ファイル<br></th>
					<td align="left" valign="middle" id="cms_denial_file_td">
					<input type="file" id="denial_file" name="denial_file" style="width: 320px;"></td>
				</tr>
			<?php
			}
			
			?>
		</table>
		</div>
		</div>
		<p align="center" style="margin: 10px 0px;"><a id="cms-denail-submit"
			href="javascript:" onClick=""><img
			src="<?=RPW?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
			height="21" border="0"></a></p>
		</td>
	</tr>
</table>
<?php

// 移行作業用：否認時ファイル添付機能
if (IKOU_MODE == TRUE) {
?>
</form>
<?php
}

?>
</div>
<!-- ** 否認理由レイヤー　ここまで *************************************** -->
<?php
if ($login['class'] != USER_CLASS_WRITER || $login['isRegain'] === TRUE) {
	?>
<!-- ** 自動リンク設定レイヤー　ここから *************************************** -->
<form name="cms_fProperty2" class="cms8341-form" id="cms_fProperty2">
<div id="cms8341-autolinks" class="cms8341-layer">
<table width="350" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="350" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="350" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/autolinks/title_autolinks.jpg"
					alt="自動リンク依頼先" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxAutoLinksClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div id="cms8341-autolinksbody"><!-- ****** 自動リンク設定表示領域 ここから ********* -->
		ここに各ページの自動リンク設定が代入されます。 <!-- ****** 自動リンク設定表示領域 ここまで ********* --></div>

</table>
</div>
</form>
<!-- ** 自動リンク設定レイヤー　ここまで *************************************** -->
<?php
}
?>
<!--***エラーメッセージレイヤー ここから********************************-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return delLayer('cms8341-error')"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー ここまで********************************-->
<!--***処理中プロパティレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0" style="background-image:url(<?=RPW?>/admin/images/layer/titlebar_bg.jpg);height:30px;">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg">メッセージ</div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理中プロパティレイヤー ここまで********************************-->
<!--***否認理由メッセージレイヤー ここから********************************-->
<div id="cms8341-denial" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/denail/title_denialmsg.jpg"
					alt="前回の否認理由" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return delLayer('cms8341-denial')"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div id="cms8341-denialmsg"
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			　id="cms8341-denialmsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return delLayer('cms8341-denial')"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***否認理由メッセージレイヤー ここまで********************************-->
</body>
</html>