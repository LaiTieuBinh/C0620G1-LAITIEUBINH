<?php
/*
 *
 */
/** ワークスペース **/
require ("../.htsetting");

// サイトのトップページがあればそこへ飛ばす
if (@file_exists(DOCUMENT_ROOT . RPW . SITE_TOP_PAGE)) {
	header("Location: " . HTTP_ROOT . RPW . SITE_TOP_PAGE);
	exit();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>サイトビュー</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/workspace.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'siteview';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<div align="center" id="cms8341-contents">
<div><img src="<?=RPW?>/admin/images/workspace/bar_workspace.jpg"
	alt="ワークスペース" width="920" height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-workspace">
	<tr>
		<th valign="middle" scope="col" style="font-weight: normal">&nbsp;</th>
	</tr>
	<tr>
		<td align="center" valign="middle">現在ページは登録されていません。</td>
	</tr>
</table>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents -->
</body>
</html>
