<?php
/*
 *
 */
/** 編集の保存 **/
require ("../.htsetting");

// ページIDが渡されなければエラー
if (!isset($_POST['cms_page_id']) || $_POST['cms_page_id'] == '') {
	user_error("It isn't setted cms_page_id in _post.", E_USER_ERROR);
}
// ファイルの保存先が渡されなければエラー
if (!isset($_POST['cms_p_file_path']) || $_POST['cms_p_file_path'] == '') {
	user_error("It isn't setted cms_p_file_path in _post.", E_USER_ERROR);
}
// ファイルの保存変更先が渡されなければエラー（変更がなければ元の保存先が渡されるはず）
if (!isset($_POST['cms_w_file_path']) || $_POST['cms_w_file_path'] == '') {
	user_error("It isn't setted cms_w_file_path in _post.", E_USER_ERROR);
}
// テンプレート種類が渡されなければエラー
if (!isset($_POST['cms_template_kind'])) {
	user_error("It isn't setted cms_template_kind in _post.", E_USER_ERROR);
}
$PID = $_POST['cms_page_id'];
$tpl_kind = $_POST['cms_template_kind'];

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$objLinks = new tbl_links($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_library.inc');
$objLibrary = new tbl_library($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInquiry = new tbl_inquiry($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete.inc');
$objEnq = new tbl_enquete($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete_detail.inc');
$objEnqDtl = new tbl_enquete_detail($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFAQ = new tbl_faq($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output_handler.inc');
$objOpHndl = new tbl_output_handler($objCnc);
// イベントカレンダー複数日
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_event.inc');
$obj_event = new tbl_event($objCnc);
// オープンデータ
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_open_data.inc');
$obj_open_data_edit = new tbl_open_data($objCnc);

// 公開ページの情報を取得
if ($objPage->selectFromID($PID, PUBLISH_TABLE) === FALSE) {
	user_error('公開ページ情報の取得に失敗しました。【ページID：' . $PID . '】', E_USER_ERROR);
}
// ページのステータスが編集開始時から変更されていた場合
if ($objPage->fld['status'] != $_SESSION['cms_edit_back_status']) {
	user_error('編集ページ情報が既に変更されています。');
}

// ファイル名を小文字に変換
$_POST['cms_filename'] = strtolower($_POST['cms_filename']);

// 実際の保存先のパス
$p_file_path = $_POST['cms_p_file_path'];
$current_dir = cms_dirname($_POST['cms_p_file_path']);
if ($current_dir == '') $current_dir = '/';
if (substr($current_dir, -1) != '/') $current_dir .= '/';
// 今回編集前の保存先のパス
$w_file_path = $_POST['cms_w_file_path'];
// 今回変更しようとしている保存先のパス
$file_path = $_POST['cms_dir_path'] . $_POST['cms_filename'];
// 保存先の変更があった場合：パスを確保するためにダミーでhtmlファイルを生成する
if ($file_path != $p_file_path && $file_path != $w_file_path) {
	// ファイルの既存チェック
	if (@file_exists(DOCUMENT_ROOT . RPW . $file_path)) {
		user_error('ページを移動できません。<br>' . $file_path . ' は既に存在します。');
	}
	// ダミーhtmlの生成
	@copy(APPLICATION_ROOT . '/common/templates/dummypage.txt', DOCUMENT_ROOT . RPW . $file_path);
	@chmod(DOCUMENT_ROOT . RPW . $file_path, 0777);
}
// 今回編集前にダミーhtmlを作っていたら、そのファイルを削除する
if ($p_file_path != $w_file_path && $w_file_path != $file_path) {
	// delete dummy HTML
	@unlink(DOCUMENT_ROOT . RPW . $w_file_path);
}
if (!@file_exists(DOCUMENT_ROOT . RPW . $file_path)) $file_path = $w_file_path;

if ($objTool->checkMobileTemplate($PID)) {
	$mp_file_path = DIR_PATH_MOBILE . $_POST['cms_p_file_path'];
	// 今回編集前の保存先のパス
	$mw_file_path = DIR_PATH_MOBILE . $_POST['cms_w_file_path'];
	// 今回変更しようとしている保存先のパス
	$mfile_path = DIR_PATH_MOBILE . $_POST['cms_dir_path'] . $_POST['cms_filename'];
	// 保存先の変更があった場合：パスを確保するためにダミーでhtmlファイルを生成する
	if ($mfile_path != $mp_file_path && $mfile_path != $mw_file_path) {
		// ファイルの既存チェック
		if (@file_exists(DOCUMENT_ROOT . RPW . $mfile_path)) {
			user_error('ページを移動できません。<br>' . $mfile_path . ' は既に存在します。');
		}
		// ダミーファイル作成先フォルダ作成
		if (!mkNewDirectory(DOCUMENT_ROOT . RPW . $mfile_path)) {
			user_error('自動生成先フォルダの作成に失敗しました。<br>【' . DOCUMENT_ROOT . RPW . $mfile_path . '】');
		}
		// ダミーhtmlの生成
		@copy(APPLICATION_ROOT . '/common/templates/dummypage.txt', DOCUMENT_ROOT . RPW . $mfile_path);
		@chmod(DOCUMENT_ROOT . RPW . $mfile_path, 0777);
	}
	// 今回編集前にダミーhtmlを作っていたら、そのファイルを削除する
	if ($mp_file_path != $mw_file_path && $mw_file_path != $mfile_path) {
		// delete dummy HTML
		@unlink(DOCUMENT_ROOT . RPW . $mw_file_path);
	}
}

// テンプレートの最新情報を取得
if ($objTool->selectTemplate($_POST['cms_template_id']) === FALSE) {
	user_error("Can't find template data.<br>dac_tools selectTemplate(" . $_POST['cms_template_id'] . ")", E_USER_ERROR);
}
$temp_fld = $objTool->fld;

// トランザクション
$objCnc->begin();

// 編集領域の整形
$context = '';
if (isset($_POST['cms_context'])) {
	// HTTPルートを削除する
	$context = delHttpRoot($_POST['cms_context']);
	// パスから作業用ルートを削除
	$context = delRootPath($context);
	// 絶対パスにする
	$mobile_flg = FALSE;
	if ($tpl_kind == TEMPLATE_KIND_MOBILE) $mobile_flg = TRUE;
	$context = setAbsolutePath($context, $current_dir, '', $mobile_flg);
	// 自動リンクの表示用DIVを削除
	$context = deleteAutolinkDiv($context);
	// メニュー生成の表示用DIVを削除
	$context = delete_lnavi_div($context);
	// 画像 src から 引数を削除
	$context = replace_src($context);
}

// ページファイルがフォルダを移動した場合、関連ファイルの移動
if ($tpl_kind != TEMPLATE_KIND_NONE) {
	$error_msg = "";
	if (!$objTool->moveRelationFiles($objCnc, $PID, $_POST['cms_dir_path'] . $_POST['cms_filename'], $_POST['cms_template_id'], $_POST['cms_template_ver'], $tpl_kind, $context, $_POST, $error_msg)) {
		$objCnc->rollback();
		user_error($error_msg, E_USER_ERROR);
	}
}

// 自動生成領域を除外する
$chkContext = $context;
// 自動リンク領域を除外
$chkContext = deleteAutolinkArea($chkContext);
// メニュー生成領域を除外
$chkContext = deleteLnaviArea($chkContext);

// リンク情報の削除（DELETE FROM tbl_work_links）
if ($objLinks->deleteFromPageID($PID, 2) === FALSE) user_error('リンク情報の削除に失敗しました。', E_USER_ERROR);
// リンク情報の登録
$p = 0;
$link_no = 0;
$nontpl_no = 0;
while (1) {
	$r = dac_insertLink($chkContext, $objLinks, $PID, $link_no, $p);
	if ($r == -9) break;
	if ($r == -8) user_error('リンク情報の登録に失敗しました。', E_USER_ERROR);
}
$nontpl_no = $link_no;

// 画像情報の削除（DELETE FROM tbl_work_images）
if ($objImages->deleteFromPageID($PID, 2) === FALSE) user_error('画像情報の削除に失敗しました。', E_USER_ERROR);
// 画像情報の登録
$p = 0;
$img_no = 0;
while (1) {
	$r = dac_insertImage($chkContext, $objImages, $PID, $img_no, $p);
	if ($r == -9) break;
	if ($r == -8) user_error('画像情報の登録に失敗しました。', E_USER_ERROR);
}

if ($_POST['cms_template_kind'] == TEMPLATE_KIND_NONE) {
	dac_insertLink_nontpl($chkContext, $PID, $nontpl_no);
}

// 公開ページ情報取得
if ($objPage->selectFromID($PID, 1) === FALSE) {
	user_error("dac execute error. <br>tbl_page->selectFromID(" . $PID . ", 1);", E_USER_ERROR);
}
$fld = $objPage->fld;
$w_fld = $objPage->fld;

// 編集情報の取得
if ($objPage->selectFromID($PID, WORK_TABLE) !== FALSE) {
	$w_fld = $objPage->fld;
}

// 自動生成領域の有無をチェックするために、ページ生成の要素となる文字列を取得
$total_str = $context;
$total_str .= $objTool->getTemplateContext($_POST['cms_template_id']);

// 問い合わせ領域が存在するかチェック
$inquiry_exists = FLAG_OFF;
if (getMidString($total_str, '<!-- InstanceBeginEditable name="inquiry" -->', '<!-- InstanceEndEditable -->') !== FALSE) {
	$inquiry_exists = FLAG_ON;
}

// ライブラリ設定の削除（DELETE FROM tbl_handler WHERE class = HANDLER_CLASS_LIBRARY_P2）
if ($objHandler->deleteLibrary($PID, 2) === FALSE) user_error('ライブラリ設定の削除に失敗しました。', E_USER_ERROR);
// ライブラリ設定の登録


// テンプレート変更の場合
if ($w_fld['template_id'] != $_POST['cms_template_id']) {
	//
	$libHtmlStr = $total_str;
	$libAry = array();
	// ライブラリ領域を検索
	while (getLibraryArea($libAry, $libHtmlStr, 0)) {
		// 初期化
		$ary6 = array();
		
		// ライブラリ情報を登録
		if (isset($_POST['cms_library'][$libAry['area']])) {
			// 変更前に同じエリア名のライブラリがあれば優先
			// ライブラリ情報を取得
			if ($objLibrary->selectFromID($_POST['cms_library'][$libAry['area']]) !== FALSE) {
				// 取得できた場合のみDB保存用の配列を作成
				$total_str .= $objLibrary->fld['context'];
				$ary6['page_id'] = $PID;
				$ary6['area'] = $libAry['area'];
				$ary6['library_id'] = $_POST['cms_library'][$libAry['area']];
				$ary6['library_ver'] = $objLibrary->fld['library_ver'];
			}
		}
		elseif (isset($libAry["id"]) && $libAry["id"] != "" && $objLibrary->selectFromID($libAry["id"]) !== FALSE) {
			// 優先するライブラリ情報がない場合、デフォルトライブラリを設定
			// 登録情報の作成
			$total_str .= $objLibrary->fld['context'];
			$ary6['page_id'] = $PID;
			$ary6['area'] = $libAry["area"];
			$ary6['library_id'] = $libAry["id"];
			$ary6['library_ver'] = $objLibrary->fld['library_ver'];
		}
		// DBに登録
		if (count($ary6) > 0) {
			if ($objHandler->insertLibrary($ary6, WORK_TABLE) === FALSE) user_error('ライブラリ設定の登録に失敗しました。', E_USER_ERROR);
		}
		// 登録したエリア情報を対象から除外
		$libHtmlStr = str_replace($libAry["match"], "", $libHtmlStr);
	}
} // テンプレート変更なしの場合
else {
	if (isset($_POST['cms_library']) && is_array($_POST['cms_library'])) {
		foreach ($_POST['cms_library'] as $area => $library_id) {
			// ライブラリ情報を取得
			if ($objLibrary->selectFromID($library_id) === FALSE) continue;
			$total_str .= $objLibrary->fld['context'];
			$ary6 = array();
			$ary6['page_id'] = $PID;
			$ary6['area'] = $area;
			$ary6['library_id'] = $library_id;
			$ary6['library_ver'] = $objLibrary->fld['library_ver'];
			// （INSERT INTO tbl_handler VALUES class = HANDLER_CLASS_LIBRARY_P2）
			if ($objHandler->insertLibrary($ary6, 2) === FALSE) user_error('ライブラリ設定の登録に失敗しました。', E_USER_ERROR);
		}
	}
}

// ログイン情報
$login = $objLogin->login;

// 公開情報のステータス変更
$ary1 = array();
$ary1['page_id'] = $PID;
$ary1['user_lock'] = '';

// 作成者の場合
if ($login['class'] == USER_CLASS_WRITER) {
	// ステータスをPOSTの値に変更する（一時保存、編集完了）
	$ary1['status'] = $_POST['cms_status'];
}
// ウェブマスターの場合
else if ($login['class'] == USER_CLASS_WEBMASTER) {
	// 承認中以外のステータスの場合
	$tmp_ary = array(
		STATUS_APPROVE_1,
		STATUS_APPROVE_2,
		STATUS_APPROVE_3,
		STATUS_APPROVE_LAST,
		STATUS_DENIAL
	);
	if (!in_array($fld['status'], $tmp_ary)) {
		// ステータスを公開待ちに変更する
		$ary1['status'] = 401;
		if ($fld['status'] == 402) {
			$ary1['bak_status'] = 402;
		}
	}
}

// 公開ページ情報の更新（UPDATE tbl_publish_page）
if ($objPage->update($ary1, PUBLISH_TABLE) === FALSE) {
	user_error('公開ページ情報の更新に失敗しました。', E_USER_ERROR);
}

// ウェブマスターが公開済みページを新規に更新したときwork_pageに情報をコピー
if ($login['class'] == USER_CLASS_WEBMASTER && $fld['status'] == 402) {
	// （INSERT INTO tbl_work_page SELECT FROM tbl_publish_page）
	if ($objPage->insertWorkFromPublish($PID, $login) === FALSE) {
		user_error('編集ページ情報の登録に失敗しました。', E_USER_ERROR);
	}
}
// 公開ページ情報取得
if ($objPage->selectFromID($PID, 2) === FALSE) {
	user_error('編集ページ情報が削除された可能性があります。(ページID：' . $PID . ')<br>※同一アカウントでログインしているユーザーによりこのページの作業の取り消しが行われた可能性があります。');
}
$_fld['update_datetime'] = $objPage->fld['update_datetime'];
$_fld_s['status'] = $objPage->fld['status'];

// 080612 >>>> 編集時と編集完了時でステータスが変化していないかのチェック
if ($login['class'] == USER_CLASS_WRITER && !in_array($_fld_s['status'], array(
	STATUS_NEW,
	STATUS_SAVE,
	STATUS_COMP
))) {
	user_error('編集ページ情報が既に変更されています。');
}
// 承認者が編集完了した場合
else if ($login['class'] == USER_CLASS_APPROVER1 || $login['class'] == USER_CLASS_APPROVER2 || $login['class'] == USER_CLASS_APPROVER3) {
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_contents_group.inc');
	$obj_cg = new tbl_contents_group($objCnc);
	$tmp_ary = array(
		STATUS_APPROVE_1,
		STATUS_APPROVE_2,
		STATUS_APPROVE_3,
		STATUS_APPROVE_LAST
	);
	if (!in_array($_fld_s['status'], $tmp_ary) || !$obj_cg->isApprover($login, $PID)) {
		user_error('編集ページ情報が既に変更されています。');
	}
}
// ウェブマスターが編集完了した場合
else if ($login['class'] == USER_CLASS_WEBMASTER && !in_array($_fld_s['status'], array(
	STATUS_NEW,
	STATUS_SAVE,
	STATUS_COMP,
	STATUS_APPROVE_LAST,
	STATUS_PUBLISH_WAIT
))) {
	user_error('編集ページ情報が既に変更されています。');
}
// 080612 <<<<
// 080616 >>>> 承認依頼中のエラー
if ($login['class'] == USER_CLASS_WRITER && in_array($_fld_s['status'], array(
	STATUS_APPROVE_1,
	STATUS_APPROVE_2,
	STATUS_APPROVE_3,
	STATUS_APPROVE_LAST
))) {
	user_error('このページは既に承認依頼に出されています。');
}
// 080616 >>>> 親ページが不正ならエラーを表示


if (isset($_POST['cms_parent_id'])) $parent_id = $_POST['cms_parent_id'];
$error_flg = 0;
if (isset($parent_id)) {
	if ($parent_id == $PID) {
		$error_flg = 1;
	}
	else {
		// 編集中のページのパス
		if ($objPage->selectFromID($PID, PUBLISH_TABLE, "file_path") !== FALSE) {
			$p_file_path = $objPage->fld['file_path'];
		}
	}
	// エラーがない場合チェック
	while ($error_flg == 0) {
		// PUBLISH_TABLE の親ページ情報チェック
		if ($objPage->selectFromID($parent_id, PUBLISH_TABLE, "ancestor_path") !== FALSE) {
			$ancestor_path = $objPage->fld['ancestor_path'];
			$ary['ancestor_path'] = explode(',', $ancestor_path);
			foreach ($ary['ancestor_path'] as $k => $v) {
				// 編集中のファイルパスが存在するかチェック
				if ($v == $p_file_path) {
					$error_flg = 2;
					break;
				}
			}
		}
		// WORK_TABLE の親ページ情報チェック
		if ($objPage->selectFromID($parent_id, WORK_TABLE, "parent_id , file_path") !== FALSE) {
			// WORK_TABLE
			// 親ページID取得
			$parent_id = $objPage->fld['parent_id'];
			// 親ページ情報取得
			if ($objPage->selectFromID($parent_id) !== FALSE) {
				if ($p_file_path == $objPage->fld['file_path']) {
					$error_flg = 2;
					break;
				}
			}
			else {
				// 取得できなければbreak
				break;
			}
			continue;
		}
		break;
	}
}
if ($error_flg != 0) {
	user_error('親ページの中に編集中のページを含んでいるため、編集を保存できません。<br>親ページの設定を変更してください。');
}

// 080616 <<<<


// 編集情報の登録
$inquiry_flg = FLAG_OFF;
$inquiry_id = "";
if ((isset($_POST['cms_inquiry_cnt']) && $_POST['cms_inquiry_cnt'] > 0) || (isset($_POST['cms_inquiry_prop_memo']) && $_POST['cms_inquiry_prop_memo'] != "")) {
	for ($i = 1; $i < $_POST['cms_inquiry_cnt'] + 1; $i++) {
		if (isset($_POST['cms_inquiry_prop_dept1_1']) || isset($_POST['cms_inquiry_prop_charge_1']) || isset($_POST['cms_inquiry_prop_anExtensionNumber_1']) || isset($_POST['cms_inquiry_prop_directNumber_1']) || isset($_POST['cms_inquiry_prop_fax_1']) || isset($_POST['cms_inquiry_prop_email_1']) || (isset($_POST['cms_inquiry_prop_memo']) && $_POST['cms_inquiry_prop_memo'] != "")) {
			$inquiry_flg = FLAG_ON;
			if ($_POST['cms_inquiry_id'] != "") {
				$inquiry_id = $_POST['cms_inquiry_id'];
			}
			else {
				$inquiry_id = $objInquiry->getSeqNextval();
			}
			break;
		}
	}
}
$ary2 = array();
$ary2['page_id'] = $PID;
if (isset($ary1['status'])) $ary2['status'] = $ary1['status'];
if (isset($_POST['cms_parent_id'])) $ary2['parent_id'] = $_POST['cms_parent_id'];
if (isset($_POST['cms_page_title'])) $ary2['page_title'] = $_POST['cms_page_title'];
if ($fld['template_kind'] == TEMPLATE_KIND_NONE) {
	$page_title = (preg_match('/<title.*?>(.*)<\/title>/si', $context, $r, PREG_OFFSET_CAPTURE)) ? $r[1][0] : '';
	if ($page_title == "") $page_title = getMidString($context, '<title>', '</title>');
	$ary2['page_title'] = htmlEncode($page_title);
}
if (isset($_POST['cms_header'])) $ary2['header'] = $_POST['cms_header'];
$ary2['context'] = $context;
$ary2['file_path'] = $file_path;
if (isset($_POST['cms_keywords'])) $ary2['keywords'] = str_replace("、", ",", $_POST['cms_keywords']);
if (isset($_POST['cms_description'])) $ary2['description'] = $_POST['cms_description'];
if (isset($_POST['cms_summary'])) $ary2['summary'] = $_POST['cms_summary'];
if (isset($_POST['cms_index_title'])) $ary2['index_title'] = $_POST['cms_index_title'];
$ary2['contents_top_flg'] = (isset($_POST['cms_contents_top_flg'])) ? $_POST['cms_contents_top_flg'] : 0;
if ($fld['template_kind'] != TEMPLATE_KIND_NONE) {
	$cate_code = $_POST['cms_cate1']; // 第一カテゴリ（必須）しか選択されていなければ$_POST['cms_cate1']がカテゴリコードになる
	if (isset($_POST['cms_cate2']) && $_POST['cms_cate2']) $cate_code = $_POST['cms_cate2']; // 第二カテゴリが選択されていれば$_POST['cms_cate2']がカテゴリコードになる
	if (isset($_POST['cms_cate2']) && $_POST['cms_cate3']) $cate_code = $_POST['cms_cate3']; // 第三カテゴリが選択されていれば$_POST['cms_cate3']がカテゴリコードになる
	if (isset($_POST['cms_cate2']) && $_POST['cms_cate4']) $cate_code = $_POST['cms_cate4']; // 第四カテゴリが選択されていれば$_POST['cms_cate4']がカテゴリコードになる
	$ary2['cate_code'] = $cate_code;
}

$ary2['update_datetime'] = 'NOW';
//	$ary2['index_flg'] = (isIncludeIndex($total_str)) ? 1 : 0;	// 自動生成領域の有無をチェック：自動生成あり=1 / なし=0

// 定型テンプレート【イベント】の場合
if ($tpl_kind == TEMPLATE_KIND_FIXED && $objTool->selectTemplateKankoType($_POST['cms_template_id']) == KANKO_TYPE_EVENT) {
	// イベントカレンダー複数日
	if (EVENT_CAL_MULTI_FLAG) {
		$open_start = array();
		$open_end = array();
		
		//開催日の要素数を取得
		$open_start_count = count($_POST['cms_pdsy']);
		
		//要素ごとに開催日を変数に格納
		for($i = 0; $i < $open_start_count; $i++) {
			//開始日が空の場合はスキップ
			if (empty($_POST['cms_pdsy'][$i]) && empty($_POST['cms_pdsm'][$i]) && empty($_POST['cms_pdsd'][$i])) {
				continue;
			}
			//開始時間
			if (intval($_POST['cms_pdsh'][$i]) == 0 && intval($_POST['cms_pdsi'][$i]) == 0) {
				$pdsh = '00';
				$pdsi = '00';
			}
			else {
				//0埋め
				$pdsh = sprintf("%02d", $_POST['cms_pdsh'][$i]);
				$pdsi = sprintf("%02d", $_POST['cms_pdsi'][$i]);
			}
			
			//終了時間
			if (intval($_POST['cms_pdeh'][$i] == 0) && intval($_POST['cms_pdei'][$i]) == 0) {
				$pdeh = '00';
				$pdei = '00';
			}
			else {
				//0埋め
				$pdeh = sprintf("%02d", $_POST['cms_pdeh'][$i]);
				$pdei = sprintf("%02d", $_POST['cms_pdei'][$i]);
			}
			
			//日時を配列に格納
			$open_start[] = $_POST['cms_pdsy'][$i] . '-' . $_POST['cms_pdsm'][$i] . '-' . $_POST['cms_pdsd'][$i] . ' ' . $pdsh . ':' . $pdsi . ':00';
			if (strlen($_POST['cms_pdey'][$i] . $_POST['cms_pdem'][$i] . $_POST['cms_pded'][$i]) > 0) {
				$open_end[] = $_POST['cms_pdey'][$i] . '-' . $_POST['cms_pdem'][$i] . '-' . $_POST['cms_pded'][$i] . ' ' . $pdeh . ':' . $pdei . ':00';
			}
			else {
				$open_end[] = '';
			}
		}
		$ary2['open_start'] = $open_start;
		$ary2['open_end'] = $open_end;
	}
	// イベントカレンダー単一日
	else {
		// 開催日を設定
		$ary2['open_start'] = $_POST['cms_pdsy'] . '-' . $_POST['cms_pdsm'] . '-' . $_POST['cms_pdsd'] . ' 00:00:00';
		if (strlen($_POST['cms_pdey'] . $_POST['cms_pdem'] . $_POST['cms_pded']) > 0) {
			$ary2['open_end'] = $_POST['cms_pdey'] . '-' . $_POST['cms_pdem'] . '-' . $_POST['cms_pded'] . ' 00:00:00';
		}
		else {
			$ary2['open_end'] = "";
		}
	}
}
// ウェブマスターの場合は公開日を更新
if ($login['class'] == USER_CLASS_WEBMASTER && $fld['status'] != STATUS_APPROVE_LAST && $fld['template_kind'] != TEMPLATE_KIND_NONE) {
	$ary2['publish_start'] = $_POST['cms_pubsy'] . '-' . $_POST['cms_pubsm'] . '-' . $_POST['cms_pubsd'] . ' ' . $_POST['cms_pubsh'] . ':00:00';
	$ary2['publish_end'] = $_POST['cms_pubey'] . '-' . $_POST['cms_pubem'] . '-' . $_POST['cms_pubed'] . ' ' . $_POST['cms_pubeh'] . ':00:00';
}
$ary2['inquiry_memo'] = (isset($_POST['cms_inquiry_prop_memo'])) ? $_POST['cms_inquiry_prop_memo'] : "";
$ary2['inquiry_id'] = ($inquiry_exists == FLAG_ON ? $inquiry_id : "");
$ary2['inquiry_flg'] = $inquiry_flg;

// アンケート(問い合わせ)
if ($tpl_kind == TEMPLATE_KIND_ENQUETE && $fld['enquete_kind'] == ENQ_KIND_MAIL && isset($_POST['cms_enq_email'])) {
	$ary2['enquete_email'] = $_POST['cms_enq_email'];
}

// テンプレート
if ($tpl_kind == TEMPLATE_KIND_FREE) {
	$ary2['template_id'] = $_POST['cms_template_id'];
	$ary2['template_ver'] = $_POST['cms_template_ver'];
	// 承認フローの変更
	$ary2['approve_id'] = $temp_fld['approve_id'];
	// 承認依頼中または公開待ち
	if (in_array($fld['status'], array(
		STATUS_APPROVE_1,
		STATUS_APPROVE_2,
		STATUS_APPROVE_3,
		STATUS_APPROVE_LAST,
		STATUS_PUBLISH_WAIT
	)) && // 承認フローが変更された
$temp_fld['approve_id'] != $w_fld['approve_id']) {
		user_error('承認依頼中・公開待ちのページは承認フローの変更されるテンプレートを選択できません。', E_USER_ERROR);
	}
}

//非公開中の場合があるため、強制的に公開中にする
$ary2['close_flg'] = 0;

// ページ出力フラグ
if (ENABLE_OPTION_OUTPUT) {
	$ary2['output_html_flg'] = (!isset($_POST['cms_output_html_flg']) || $_POST['cms_output_html_flg'] == FLAG_OFF ? FLAG_OFF : FLAG_ON);
}
else {
	$ary2['output_html_flg'] = FLAG_ON;
}

// （UPDATE tbl_work_page）
if ($objPage->update($ary2, WORK_TABLE) === FALSE) user_error('編集ページ情報の更新に失敗しました。', E_USER_ERROR);

if(ENABLE_OPEN_DATA_FLG){
	// オープンデータ
	// オープンデータ編集情報登録
	// 登録前に既存の情報を削除する
	if (!$obj_open_data_edit->deleteFromID($PID, '', '', '', WORK_TABLE)) {
		user_error('オープンデータ編集情報の削除に失敗しました。', E_USER_ERROR);
	}
	// noを初期化
	$opendata_no = 0;
	// ページをオープンデータとして登録
	if (isset($_POST['opendata_id'])) {
		if (setOpenData($PID, $_POST, $opendata_no) == FALSE) {
			user_error('オープンデータ編集情報の更新に失敗しました。', E_USER_ERROR);
		}
	}
	// 本文領域内のオープンデータ情報をオープンデータテーブルに登録する
	if (isset($_POST['context_odfile_count'])) {
		if (setContextOpenDataFiles($PID, $_POST, $opendata_no) == FALSE) {
			user_error('編集領域のオープンデータファイル編集情報の更新に失敗しました。', E_USER_ERROR);
		}
	}
	// オープンデータファイルの可変登録情報を登録
	if (isset($_POST['disp_sort'])) {
		// リンク情報テーブルへの登録用に、登録noを流用する
		if (!isset($link_no)) {
			$link_no = 0;
		}
		
		// オープンデータファイルの可変登録項目をDBに登録する($opendata_noは参照渡し)
		if (setVariableOpenDataFiles($PID, $_POST, $opendata_no, $link_no) == FALSE) {
			user_error('可変登録領域のオープンデータファイル編集情報の更新に失敗しました。', E_USER_ERROR);
		}
	}
}

// イベントカレンダー複数日
if (EVENT_CAL_MULTI_FLAG) {
	// （UPDATE tbl_work_event）
	if ($objTool->selectTemplateKankoType($_POST['cms_template_id']) == KANKO_TYPE_EVENT) {
		if ($obj_event->update($ary2, WORK_TABLE) === FALSE) {
			user_error('開催期間の更新に失敗しました。', E_USER_ERROR);
		}
	}
}

// 問い合わせの登録 (INSERT INTO tbl_inquiry)
// 新しい問い合わせIDの取得
$no = 1;
$objInquiry->deleteFromID($inquiry_id, WORK_TABLE);
if ($inquiry_exists == FLAG_ON) {
	for ($i = 1; $i < $_POST['cms_inquiry_cnt'] + 1; $i++) {
		if (!isset($_POST['cms_inquiry_prop_dept1_' . $i]) && !isset($_POST['cms_inquiry_prop_charge_' . $i]) && !isset($_POST['cms_inquiry_prop_anExtensionNumber_' . $i]) && !isset($_POST['cms_inquiry_prop_directNumber_' . $i]) && !isset($_POST['cms_inquiry_prop_fax_' . $i]) && !isset($_POST['cms_inquiry_prop_email_' . $i])) {
			continue;
		}
		$dept_code = "";
		$inq_ary = array();
		$inq_ary['inquiry_id'] = $inquiry_id;
		$inq_ary['inquiry_no'] = $no;
		if (isset($_POST['cms_inquiry_prop_dept3_' . $i]) && $_POST['cms_inquiry_prop_dept3_' . $i]) {
			$dept_code = $_POST['cms_inquiry_prop_dept3_' . $i];
		}
		else if (isset($_POST['cms_inquiry_prop_dept2_' . $i]) && $_POST['cms_inquiry_prop_dept2_' . $i]) {
			$dept_code = $_POST['cms_inquiry_prop_dept2_' . $i];
		}
		else if (isset($_POST['cms_inquiry_prop_dept1_' . $i]) && $_POST['cms_inquiry_prop_dept1_' . $i]) {
			$dept_code = $_POST['cms_inquiry_prop_dept1_' . $i];
		}
		$inq_ary['dept_code'] = $dept_code;
		$inq_ary['name'] = (isset($_POST['cms_inquiry_prop_charge_' . $i])) ? $_POST['cms_inquiry_prop_charge_' . $i] : "";
		$inq_ary['anex_number'] = (isset($_POST['cms_inquiry_prop_anExtensionNumber_' . $i])) ? $_POST['cms_inquiry_prop_anExtensionNumber_' . $i] : "";
		$inq_ary['drxt_number'] = (isset($_POST['cms_inquiry_prop_directNumber_' . $i])) ? $_POST['cms_inquiry_prop_directNumber_' . $i] : "";
		$inq_ary['fax'] = (isset($_POST['cms_inquiry_prop_fax_' . $i])) ? $_POST['cms_inquiry_prop_fax_' . $i] : "";
		$inq_ary['email'] = (isset($_POST['cms_inquiry_prop_email_' . $i])) ? $_POST['cms_inquiry_prop_email_' . $i] : "";
		if ($inq_ary['dept_code'] == "" && $inq_ary['name'] == "" && $inq_ary['anex_number'] == "" && $inq_ary['drxt_number'] == "" && $inq_ary['fax'] == "") {
			continue;
		}
		$objInquiry->insert($inq_ary, WORK_TABLE);
		$no++;
	}
}

//アンケート
if ($tpl_kind == TEMPLATE_KIND_ENQUETE) {
	//新規登録または問い合わせの場合
	 if ($_POST['cms_work_class'] == WORK_CLASS_NEW || $_POST['cms_from_type'] == ENQ_KIND_MAIL) {
		$objEnq->add_where("page_id", $PID);
		$objEnq->delete("", WORK_TABLE);
		if (isset($_POST['ctrl'])) {
			foreach ($_POST['ctrl'] as $no => $ctrl) {
				$enq_ary = array();
				$enquete_id = $objEnq->getSeqNextval();
				$enq_ary['enquete_id'] = $enquete_id;
				$enq_ary['page_id'] = $PID;
				$enq_ary['name'] = $_POST['item_title'][$no];
				$enq_ary['sort_order'] = $no + 1;
				$enq_ary['require_flg'] = $_POST['item_nes'][$no];
				$enq_ary['desc_mail_flg'] = (ENQ_RETURN_MAIL_SEND_FLG == TRUE ? ($_POST['item_desc_mail'][$no] == FLAG_ON ? FLAG_ON : FLAG_OFF) : FLAG_OFF);
				$enq_ary['comment'] = $_POST['item_memo'][$no];
				$enq_ary['control_kind'] = $_POST['item_ctrl'][$no];
				if (isset($_POST['img'][$no]) && $_POST['img'][$no] != "") {
					$enq_ary['img_src'] = $_POST['img'][$no];
					$enq_ary['img_src'] = str_replace(HTTP_ROOT, "", $enq_ary['img_src']);
					$enq_ary['img_src'] = str_replace(RPW, "", $enq_ary['img_src']);
					$enq_ary['img_alt'] = $_POST['img_alt'][$no];
					
					// 画像情報に登録（INSERT INTO tbl_work_images）
					$ary = array();
					$ary['page_id'] = $PID;
					$ary['src'] = $enq_ary['img_src'];
					$ary['alt'] = $enq_ary['img_alt'];
					$ary['no'] = $img_no;
					if ($objImages->insert($ary, WORK_TABLE) === FALSE) user_error('アンケート画像情報の画像情報への登録に失敗しました。', E_USER_ERROR);
					$img_no++;
				}
				$objEnq->insert($enq_ary, WORK_TABLE);
				foreach ($ctrl as $no => $info) {
					$enq_dtl_ary = array();
					$enq_dtl_ary['enquete_id'] = $enquete_id;
					$enq_dtl_ary['enquete_no'] = $no + 1;
					$enq_dtl_ary['setting_info1'] = trim($info[0]);
					$enq_dtl_ary['setting_info2'] = trim($info[1]);
					$enq_dtl_ary['setting_info3'] = trim($info[2]);
					if ($enq_ary['control_kind'] == "input" || $enq_ary['control_kind'] == "radio" || $enq_ary['control_kind'] == "checkbox") {
						$enq_dtl_ary['setting_info4'] = trim($info[3]);
					}
					else {
						$enq_dtl_ary['setting_info4'] = 0;
					}
					$enq_dtl_ary['setting_info5'] = (ENQ_RETURN_MAIL_SEND_FLG == TRUE ? (isset($info[4]) && $info[4] == 1 ? 1 : 0) : 0);
					$objEnqDtl->insert($enq_dtl_ary, WORK_TABLE);
				}
			}
		}
	 }
		//更新登録
		else if ($_POST['cms_work_class'] == WORK_CLASS_PUBLISH) {
			if ($objEnq->selectFromPID($PID, PUBLISH_TABLE) === FALSE) {
				user_error('アンケート情報の取得に失敗しました。', E_USER_ERROR);
			}
			$enquete_id = $objEnq->fld['enquete_id'];
			$objEnq->insertWfromP($enquete_id);
			$item_cnt = $objEnq->getRowCount();
			for ($ctrl_cnt = 1; $ctrl_cnt <= $item_cnt; $ctrl_cnt++) {
				if (isset($_POST['img_' . $ctrl_cnt])) {
					$ary['page_id'] = $PID;
					$ary['src'] = str_replace(HTTP_REAL_ROOT, "", $_POST['img_' . $ctrl_cnt]);
					$ary['alt'] = $_POST['img_alt_' . $ctrl_cnt];
					$ary['no'] = $img_no;
					if ($objImages->insert($ary, WORK_TABLE) === FALSE) user_error('アンケート画像情報の画像情報への登録に失敗しました。', E_USER_ERROR);
					$img_no++;
				}
			}
		}
	//}
}

// 観光情報
$fixed_chk_ary = array();
if ($tpl_kind == TEMPLATE_KIND_FREE) {
	$fixed_chk_ary['template_id'] = $ary2['template_id'];
	$fixed_chk_ary['template_ver'] = $ary2['template_ver'];
	$fixed_chk_ary['template_kind'] = $tpl_kind;
}
else {
	$fixed_chk_ary = $w_fld;
}

// 編集中の情報に、定型の項目がある場合
if (isFixed($fixed_chk_ary)) {
	if (!isset($link_no)) $link_no = 0;
	if (!isset($img_no)) $img_no = 0;
	// オープンデータ
	// 定型typeオープンデータ
	if (!isset($opendata_no)) {
		$opendata_no = 0;
	}
	if(setData($PID, $_POST, $link_no, $img_no, $opendata_no) === FALSE) {
		user_error('定型項目の編集情報の更新に失敗しました。', E_USER_ERROR);
	}
	
	// FLASH動画
	if ($objTool->selectTemplateKankoType($_POST['cms_template_id']) == KANKO_TYPE_FLASH_VIDEO) {
		//FlashVideoフォルダへ一時フォルダの内容を移動する
		if (!copyFlashVideoFolderFromFlashTempFolder($PID)) {
			user_error('動画ファイルの移動に失敗しました。', E_USER_ERROR);
		}
		//移動していなければ、エラーとする
		if (!@is_dir(DOCUMENT_ROOT . RPW . FLASH_VIDEO_DIR . '/' . $PID)) {
			user_error('動画ファイルの移動に失敗しました。', E_USER_ERROR);
		}
	}
	// 外部出力先登録
	$objOpHndl->deletePage($PID, HANDLER_OUTPUT_CLASS_WORK_PAGE);
	if (isset($_POST['cms_output']) && count($_POST['cms_output']) > 0) {
		foreach ($_POST['cms_output'] as $output_id) {
			$insAry = array();
			$insAry['class'] = HANDLER_OUTPUT_CLASS_WORK_PAGE;
			$insAry['output_id'] = $output_id;
			$insAry['page_id'] = $PID;
			if ($objOpHndl->insertPage($insAry) === FALSE) {
				user_error("外部出力先の登録に失敗しました。", E_USER_ERROR);
			}
		}
	}
}
// 編集中の情報に、定型の項目がない場合
else {
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
	$objKanko = new tbl_kanko($objCnc);
	// 定型項目がある場合は削除
	$objKanko->deleteFromID($w_fld['page_id'], '', WORK_TABLE);
}

// FAQページ
if (isset($_POST['cms_template_id']) && $objFAQ->targetCheckFAQ($_POST['cms_template_id']) !== FALSE) {
	setDataFAQ($PID, $_POST);
	$faq_id = $objFAQ->getFAQIDfromPageID($PID);
	if ($faq_id !== FALSE) {
		if ($objFAQ->selectFromID($faq_id) !== FALSE) {
			$faqAry = array(
				"faq_id" => $faq_id,
				"cate_code" => $cate_code
			);
			// カテゴリが変更された場合
			if ($faqAry["cate_code"] != $objFAQ->fld['cate_code']) {
				$objFAQ_Sort = new tbl_faq($objCnc);
				$faqAry["sort_order"] = $objFAQ_Sort->getNextID('sort_order', $objFAQ->_addslashesC('cate_code', $cate_code, 'LIKE', 'TEXT'));
			}
			
			if ($objFAQ->update($faqAry) === FALSE) {
				user_error('FAQ情報の更新に失敗しました。', E_USER_ERROR);
			}
		}
	}
}

// 自動リンク依頼の登録
if (entryAutolink($_POST['cms_a_link_id'], $PID) === FALSE) {
	user_error('自動リンク依頼の登録に失敗しました。', E_USER_ERROR);
}
// ページで使用する自動リンク情報を登録
if (entryAutolinkPage($total_str, $PID) === FALSE) {
	user_error('ページで使用する自動リンク依頼の登録に失敗しました。', E_USER_ERROR);
}
// ページで使用するローカルナビ情報を登録
if (entry_lnavi_page($total_str, $PID) === FALSE) {
	user_error('ページで使用するローカルナビの登録に失敗しました。', E_USER_ERROR);
}
// 広告使用ページ情報を登録
if (entryAdvertPage($total_str, $PID) === FALSE) {
	user_error('広告使用ページ情報の登録に失敗しました。', E_USER_ERROR);
}
// サイトマップ使用ページ情報を登録
if (entry_sitemap_page($total_str, $PID) === FALSE) {
	user_error('サイトマップ使用ページ情報の登録に失敗しました。', E_USER_ERROR);
}
// 大規模災害用分類ページ情報を登録
if (entryDisasterListTop($total_str, $PID) === FALSE) {
	user_error('大規模災害用分類ページ情報の登録に失敗しました。', E_USER_ERROR);
}

//マップ情報の登録
if (ENABLE_OPTION_GOOGLEMAP && $tpl_kind != TEMPLATE_KIND_NONE) {
	// マップ付のテンプレートかどうかチェックする
	if ($objTool->selectTemplate($_POST['cms_template_id'], $_POST['cms_template_ver']) === FALSE) {
		$objCnc->rollback();
		user_error('テンプレート情報の取得に失敗しました。', E_USER_ERROR);
	}
	$tmpfile_path = DOCUMENT_ROOT . DIR_PATH_TEMPLATE . $objTool->fld['temp_txt'];
	// ページが使用するテンプレートファイルの存在チェック
	if (!@file_exists($tmpfile_path)) {
		$objCnc->rollback();
		user_error('テンプレート情報の取得に失敗しました。', E_USER_ERROR);
	}
	// 内容取得
	$tmp_text = @file_get_contents($tmpfile_path);
	// マップが使用されている場合は登録／使用されていない場合は削除
	if (map_InsertDB($PID, (preg_match('/' . MAP_BEGIN . '([\\s\\S]*?) ' . MAP_END . '/i', $tmp_text) ? $_POST : array())) === FALSE) {
		$objCnc->rollback();
		user_error('マップ情報の登録に失敗しました。', E_USER_ERROR);
	}
}

// 公開時削除するファイルを handler テーブルに保持
if (isset($_POST['cms_publish_delete']) && $_POST['cms_publish_delete'] == FLAG_ON && isset($_SESSION['pub_depend']['dellist'])) {
	
	foreach ($_SESSION['pub_depend']['dellist'] as $path) {
		// 同一データは登録しない
		if ($objHandler->selectPublishDeleteFile($PID, $path) !== FALSE) continue;
		// 指定されたパスを削除予定リストに追加
		$temp_ary = array(
			'class' => HANDLER_CLASS_PUBLISH_DELETE_FILE,
			'item1' => $PID,
			'item2' => $path
		);
		if ($objHandler->insert($temp_ary) === FALSE) {
			$objCnc->rollback();
			user_error('ファイル情報の登録に失敗しました。', E_USER_ERROR);
		}
	}
	unset($_SESSION['pub_depend']);
}

// ログ登録
if ($_POST['cms_status'] == 201) {
	$log_flg = WRITE_INFO_LOG_PAGEEDIT_TMPSAVE;
	$log_status = LOG_STATUS_PAGEEDIT_TMPSAVE;
}
else {
	$log_flg = WRITE_INFO_LOG_PAGEEDIT_END;
	$log_status = LOG_STATUS_PAGEEDIT_END;
}
if ($log_flg) {
	if (set_log_data($log_status, $PID, WORK_TABLE) === FALSE) {
		$objCnc->rollback();
		user_error('ログ情報の登録に失敗しました。', E_USER_ERROR);
	}
}

// 作業中にアップロードした未使用ファイルの削除
if (isset($_POST['cms_unuse_delete']) && $_POST['cms_unuse_delete'] == FLAG_ON && isset($_SESSION['depend']['dellist'])) {
	
	// 削除(はい)を選択した場合のみ
	

	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
	$objFCKImages = new tbl_fck_images($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_links.inc');
	$objFCKLinks = new tbl_fck_links($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
	$objKanko = new tbl_kanko($objCnc);
	
	// エラー文章代入用
	$error_msg = "";
	// ファイル削除
	if (!filesDelete($objLinks, $objImages, $objFCKLinks, $objFCKImages, $objEnq, $objKanko, $_SESSION['depend']['dellist'], $error_msg)) {
		$objCnc->rollback();
		user_error($error_msg, E_USER_ERROR);
	}
	// セッション情報削除
	unset($_SESSION['depend']);
}

// コミット
$objCnc->commit();

// 編集が完了したらSESSION消去（編集ページのID）
if (isset($_SESSION['cms_page_id'])) unset($_SESSION['cms_page_id']);
if (isset($_SESSION['cms_pankuzu_id'])) unset($_SESSION['cms_pankuzu_id']);
if (isset($_SESSION['cms_edit_back_status'])) unset($_SESSION['cms_edit_back_status']);

// 一時保存の場合は編集モードで戻る
if ($_POST['cms_status'] == 201) {
	header("Location: " . HTTP_ROOT . RPW . $p_file_path . "?edit=1");
	// セッションに戻り先がセットされているときはそこに移動
}
elseif (isset($_SESSION['back_path'])) {
	header("Location: " . HTTP_ROOT . $_SESSION['back_path']);
	// ワークスペースに移動
}
elseif ($login['class'] == USER_CLASS_WEBMASTER) {
	header("Location: " . HTTP_ROOT . RPW . "/admin/page/workspace/workspace_wm.php");
}
elseif ($login['class'] == USER_CLASS_WRITER) {
	header("Location: " . HTTP_ROOT . RPW . "/admin/page/workspace/workspace.php");
}
else {
	header("Location: " . HTTP_ROOT . RPW . "/admin/page/workflow/workflow.php");
}

?>