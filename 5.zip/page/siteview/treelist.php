<?php
/*
 *
 */
// ヘッダーメニュー挿入
$headerMode = 'treelist';

/** ファイルのディレクトリツリー表示 **/

/*--- 設定ファイル読み込み ---*/
require ("../.htsetting");
$IMGDIR = RPW . "/admin/images/treelist";
$objLogin = new login();
$login = $objLogin->login;

//表示ディレクトリ
$dir_path = '/';
if (isset($_POST['dir_path'])) $dir_path = $_POST['dir_path'];
else if (isset($_GET['dir_path'])) $dir_path = $_GET['dir_path'];
if (substr($dir_path, 0, 1) != '/') $dir_path = '/' . $dir_path;
if (substr($dir_path, -1) != '/') {
	if (strpos(basename($dir_path), ".") === FALSE) {
		$dir_path .= '/';
	}
}
$ary = explode('/', $dir_path);
if (isset($ary[0]) && $ary[0] == '') unset($ary[0]);
if (isset($ary[count($ary)]) && $ary[count($ary)] == '') unset($ary[count($ary)]);
$aryDir = array(
		'/'
);
$c_dir = '';
foreach ($ary as $dir) {
	$c_dir .= '/' . $dir;
	$aryDir[] = $c_dir;
}

// 各種チェックメニューにて表示させるメニューフラグを取得する
$total_check_menu_flg_ary = get_total_check_menu_flg();

include (APPLICATION_ROOT . '/common/dbcontrol/commands.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandle = new tbl_handler($objCnc);
$html = '<div id="cms_dir_/" style="display: none;" class="directory"></div>';
foreach ($aryDir as $dir) {
	if ($objLogin->get('class') == USER_CLASS_WEBMASTER) {
		$isAll = 1;
	}
	else if (isset($_POST['cms_target']) && $_POST['cms_target'] == 1) {
		$isAll = 1;
	}
	else if ($dir_path == "/") {
		$isAll = 0;
	}
	else if (isset($_GET['dir_path'])) {
		$isAll = ($objHandle->IsEditableDir($login['dept_code'], $dir_path)) ? "0" : "1";
	}
	else {
		$isAll = 0;
	}
	$rText = cxGetTreeList($objCnc, $dir, $isAll);
	if ($rText == -1) {
		$html = '<p>指定されたフォルダが存在しません。</p>';
		break;
	}
	if ($rText == -2) {
		$html = '<p>指定されたファイルが存在しません。</p>';
		break;
	}
	//ディレクトリdivを可視状態にする
	$o_str = '<div id="cms_dir_' . $dir . '" style="display: none;" class="directory"></div>';
	$r_str = '<div id="cms_dir_' . $dir . '" style="display: block;" class="directory">' . $rText . '</div>';
	$html = str_replace($o_str, $r_str, $html);
	//フォルダアイコンを開いた状態にする
	$o_ptt = '/<img src="([^"]+)" alt="([^"]+)" id="cms_folder_' . reg_replace($dir) . '"([^>]*)>/i';
	$r_str = '<img src="' . $IMGDIR . '/FolderOpened.gif" alt="閉じる" id="cms_folder_' . $dir . '"{$3}>';
	$html = preg_replace($o_ptt, $r_str, $html);
}
//初期表示ディレクトリ位置に移動（スクロール）
if ($aryDir[count($aryDir) - 1] != '/') $html .= '<script type="text/javascript">if($("cms_dir_' . $aryDir[count($aryDir) - 1] . '")) Element.scrollTo("cms_dir_' . $aryDir[count($aryDir) - 1] . '");</script>';
//ディレクトリ削除フラグが１の場合、$dir_pathを「/」に初期化する
if (isset($_POST['cms_treelist_dirDel']) && $_POST['cms_treelist_dirDel'] == 1) $dir_path = '/';

$disp = '';
if ($objLogin->get('class') == USER_CLASS_WEBMASTER) {
	$disp = ' style="display:none" ';
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>フォルダビュー</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/treelist.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/treelist.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'treelist';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<form name="cms_fTreeList" id="cms_fTreeList" class="cms8341-form"
	method="post" action=""><input type="hidden" name="cms_preview_color"
	id="cms_preview_color" value="" disabled> <input type="hidden" name="cms_dispMode"
	id="cms_dispMode" value=""> <input type="hidden" name="cms_page_id"
	id="cms_page_id" value=""> <input type="hidden" name="cms_file_path"
	id="cms_file_path" value=""></form>
<div id="cms8341-contents">
<div align="center" id="cms8341-treelist">
<div><img src="images/bar_treelist.jpg" alt="フォルダビュー" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<form name="fSearchDir" class="cms8341-form" method="post" action=""
	onsubmit="return cxInputCheck();"><input type="hidden" name="cms_isAll"
	id="cms_isAll" value="">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle" style="background-image:url(<?=RPW?>/admin/page/publiclist/images/bar_topbg.jpg);height:31px;"><img
			src="images/bar_search.jpg" alt="検索" width="200" height="20"
			style="margin-left: 10px;"></td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<td>
		<table width="100%" border="0" cellpadding="10" cellspacing="0"
			bgcolor="#F0F0F0">
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row"><label
					for="del_dir">対象フォルダ</label></th>
				<td align="left" valign="middle"><?=HTTP_REAL_ROOT?>&nbsp;<input
					type="text" id="dir_path" name="dir_path" value="<?=$dir_path?>"
					style="width: 300px;" class="no-ime"></td>
			</tr>
		</table>
		</td>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="121" align="center" valign="middle"><input type="image"
			src="<?=RPW?>/admin/images/btn/btn_search.jpg" alt="検索する" width="101"
			height="21" border="0"></td>
	</tr>
	<tr <?=$disp?>>
		<td>
		<table width="100%" border="0" cellpadding="10" cellspacing="0"
			bgcolor="#F0F0F0">
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row"><label
					for="del_dir">対象</label></th>
				<td align="left" valign="middle">
<?php
if ($isAll == 1) {
	echo '<input type="radio" id="cms_target1" name="cms_target" value="0">&nbsp;<label for="cms_target1">自分が作成したページ</label>';
	echo '<input type="radio" id="cms_target2" name="cms_target" value="1" checked>&nbsp;<label for="cms_target2">全てのページ</label>';
}
else {
	echo '<input type="radio" id="cms_target1" name="cms_target" value="0" checked>&nbsp;<label for="cms_target1">自分が作成したページ</label>';
	echo '<input type="radio" id="cms_target2" name="cms_target" value="1">&nbsp;<label for="cms_target2">全てのページ</label>';
}
?>
						<input type="hidden" name="cms_target2" value=""><input
					type="hidden" name="cms_target3" value=""></td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</div>
<input type="hidden" name="cms_treelist_dirDel" id="cms_treelist_dirDel"
	value="0"></form>
<?php
// ディレクトリツリー（初期）
echo $html;
?>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!--***ページプロパティレイヤー ここから********************************-->
<div id="cms8341-property" class="cms8341-layer">
<table width="600" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="600" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="600" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/pageproperty/title_pageproperty.jpg"
					alt="ページプロパティ" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxPagePropertyClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 560px; height: 470px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center" id="cms8341-propertybody"><!-- ****** ページプロパティ表示領域 ここから ********* -->
		ここに各ページのページプロパティが代入されます。 <!-- ****** ページプロパティ表示領域 ここまで ********* --></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***ページプロパティレイヤー ここまで********************************-->
<!--***エラーメッセージレイヤー ここから********************************-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxCloseError()"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー ここまで********************************-->
</body>
</html>
