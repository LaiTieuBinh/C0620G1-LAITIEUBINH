<?php
/*
 * 自動リンク確認画面
 */
/** require **/
require ("../.htsetting");
require_once ('./include/autolinkCommonFunc.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/commands.inc');

/** init **/
$dat = array();
unset($_SESSION["hidden"]);
// 表示設定許可ユーザーの情報を格納する配列
$user_ary = array();

/** get post date **/
if (!isset($_POST["behavior"])) {
	autolinkError("パラメータエラー（behavior）");
}
$bv = $_POST["behavior"];

if (!isset($_POST["a_link_id"])) {
	autolinkError("パラメータ取得エラー(a_link_id)");
}
if (!isset($_POST["cate_code"])) {
	autolinkError("パラメータ取得エラー(cate_code)");
}

switch ($bv) {
	case AUTOLINK_ADD :
		$disp_msg = '<p>この情報で登録してもよろしいですか？</p>';
		$image = '<input type="image" src="' . RPW . '/admin/images/btn/btn_add.jpg" alt="追加" width="150" height="20" border="0" style="margin-right:10px">';
		$dat = getAutolinkPostData();
		checkAutolinkData($dat);
		// 表示設定許可ユーザー情報を取得する
		if(isset($_POST['hdn_cms_user_select_list']) && $_POST['hdn_cms_user_select_list'] != ''){
			$user_ary = getAutoLinkUserByUserid($_POST['hdn_cms_user_select_list']);
			if($user_ary === FALSE){
				autolinkError("表示設定許可ユーザー情報の取得に失敗しました");
			}
		}
		break;
	case AUTOLINK_UPD :
		$disp_msg = '<p>この情報で登録してもよろしいですか？</p>';
		$image = '<input type="image" src="' . RPW . '/admin/images/btn/btn_fix.jpg" alt="修正" width="150" height="20" border="0" style="margin-right:10px">';
		$dat = getAutolinkPostData();
		checkAutolinkData($dat);
		// 表示設定許可ユーザー情報を取得する
		if(isset($_POST['hdn_cms_user_select_list']) && $_POST['hdn_cms_user_select_list'] != ''){
			$user_ary = getAutoLinkUserByUserid($_POST['hdn_cms_user_select_list']);
			if($user_ary === FALSE){
				autolinkError("表示設定許可ユーザー情報の取得に失敗しました");
			}
		}
		break;
	case AUTOLINK_DEL :
		$disp_msg = '<p>この情報を削除してもよろしいですか？</p>';
		$image = '<input type="image" src="' . RPW . '/admin/images/btn/btn_del.jpg" alt="削除" width="150" height="20" border="0" style="margin-right:10px">';
		$dat = craeteEmptyAutolinkData();
		if (($ary = getAutolinkDbData($_POST["a_link_id"])) === FALSE) {
			autolinkError("自動リンク情報の取得に失敗しました");
		}
		$dat = array_merge($dat, $ary);
		convertDBtoDISP($dat);
		$user_ary = getAutoLinkUserByAid($dat['a_link_id']);
		if($user_ary === FALSE){
			autolinkError("表示設定許可ユーザー情報の取得に失敗しました");
		}
		break;
	case AUTOLINK_INF :
		$disp_msg = '';
		$image = '';
		$dat = craeteEmptyAutolinkData();
		if (($ary = getAutolinkDbData($_POST["a_link_id"])) === FALSE) {
			autolinkError("自動リンク情報の取得に失敗しました");
		}
		$dat = array_merge($dat, $ary);
		convertDBtoDISP($dat);
		checkAutolinkData($dat);
		// 表示設定許可ユーザー情報を取得する
		$user_ary = getAutoLinkUserByAid($dat['a_link_id']);
		if($user_ary === FALSE){
			autolinkError("表示設定許可ユーザー情報の取得に失敗しました");
		}
		break;
	default :
		autolinkError("パラメータエラー（behavior）");
}
$_SESSION["hidden"] = $dat;

$autolink_str = "";
if ($dat['link_target'] == AUTOLINK_CONDITION_PLURALS) {
	$autolink_str = cxGetAutolinkName($dat['w_a_link_id']);
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>自動リンク先確認</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="autolink.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function init(){
<?php
if ($dat['w_parent_id'] != "") {
	?>
	var prm = 'page_id=<?=$dat['w_parent_id']?>&target_column=page_title';
	cxAjaxUpdater('cxGetPageInfo',prm,'parent_page_title');
<?php
}
?>
}

Event.observe(window,'load',init,false);
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'autolink';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-autolink">
<div><img src="images/bar_conf.jpg" alt="自動リンク先確認" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?=$disp_msg?>
<form id="form" class="cms8341-form" name="form" action="submit.php"
	method="post">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="200" align="left" valign="top" scope="row">自動リンク先名称 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><?=htmlDisplay($dat['name'])?></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">抽出条件 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top">
			<?=htmlDisplay($AUTOLINK_CONDITION_ARY[$dat['link_target']])?>
			<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable">
				<?php
				if ($dat['link_target'] == AUTOLINK_CONDITION_PAGE) {
					?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">選択権限</th>
				<td align="left" valign="top"><?=htmlDisplay($auth_ary[$dat['auth']])?>
					</td>
			</tr>
				<?php
				}
				?>
				<?php
				if ($dat['link_target'] == AUTOLINK_CONDITION_MASTER) {
					?>
				<?php
					if ($dat['w_template_kind'] != "") {
						?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">テンプレート種類</th>
				<td align="left" valign="top">
						<?php
						foreach (explode(",", $dat['w_template_kind']) as $value) {
							echo htmlDisplay($TEMPLATE_KIND[$value]) . "&nbsp;&nbsp;&nbsp;";
						}
						?>
					</td>
			</tr>
				<?php
					}
					?>
				<?php
					if ($dat['w_enquete_kind'] != "") {
						?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">アンケート種類</th>
				<td align="left" valign="top">
						<?php
						foreach (explode(",", $dat['w_enquete_kind']) as $value) {
							echo htmlDisplay($ENQUETE_KIND[$value]) . "&nbsp;&nbsp;&nbsp;";
						}
						?>
					</td>
			</tr>
				<?php
					}
					?>
				<?php
					if ($dat['w_fixed'] != "") {
						?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">定型項目</th>
				<td align="left" valign="top"><?=htmlDisplay($dat['w_fixed'])?></td>
			</tr>
				<?php
					}
					?>
				<?php
					if ($dat['w_template_id'] != "") {
						?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">テンプレートID</th>
				<td align="left" valign="top"><?=htmlDisplay($dat['w_template_id'])?></td>
			</tr>
				<?php
					}
					?>
				<?php
					if ($dat['w_file_path'] != "") {
						?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">ファイルパス</th>
				<td align="left" valign="top"><?=htmlDisplay($dat['w_file_path'])?></td>
			</tr>
				<?php
					}
					?>
				<?php
					if ($dat['w_cate_code'] != "") {
						?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">カテゴリコード</th>
				<td align="left" valign="top"><?=htmlDisplay($dat['w_cate_code'])?></td>
			</tr>
				<?php
					}
					?>
				<?php
					if ($dat['w_cate_level'] != "") {
						?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">カテゴリ階層</th>
				<td align="left" valign="top"><?=$cate_level_ary[$dat["w_cate_level"]]?></td>
			</tr>
				<?php
					}
					?>
				<?php
					if ($dat['w_dept_code'] != "") {
						?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">組織コード</th>
				<td align="left" valign="top"><?=htmlDisplay($dat['w_dept_code'])?></td>
			</tr>
				<?php
					}
					?>
				<?php
					if ($dat['w_dept_level'] != "") {
						?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">組織階層</th>
				<td align="left" valign="top"><?=$dept_level_ary[$dat["w_dept_level"]]?></td>
			</tr>
				<?php
					}
					?>
				<?php
					if ($dat['w_contents_top'] != "") {
						?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">コンテンツトップ</th>
				<td align="left" valign="top"><?=$content_top_ary[$dat["w_contents_top"]]?></td>
			</tr>
				<?php
					}
					?>
				<?php
					if ($dat['w_parent_id'] != "") {
						?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">親ページ設定</th>
				<td align="left" valign="top">
				<p id="parent_page_title"></p>
				</td>
			</tr>
				<?php
					}
					?>
				<?php
					if ($dat['w_parent_class'] != "") {
						?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">親ページ抽出階層</th>
				<td align="left" valign="top"><?=$parent_class_ary[$dat["w_parent_class"]]?></td>
			</tr>
				<?php
					}
					?>
				<?php
				}
				?>
				<?php
				if ($dat['link_target'] == AUTOLINK_CONDITION_PLURALS) {
					?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">自動リンク先設定</th>
				<td align="left" valign="top">
				<ul id="cms-auto-links"><?=$autolink_str?></ul>
				</td>
			</tr>
				<?php
				}
				?>
			</table>
		</td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">表示順</th>
		<td align="left" valign="top">
		<?php
		$order_ary = explode(",", $dat['order']);
		foreach ($order_ary as $order) {
			$col = "page_id";
			$asc = "asc";
			if ($order != "") {
				if (strpos($order, " ") !== FALSE) {
					LIST($col, $asc) = explode(" ", $order);
				}
				else {
					$col = $order;
				}
			}
			echo '<p style="margin:3px;">';
			echo $AUTOLINK_ORDER_ARY[$col] . "&nbsp;" . $asc_ary[$asc];
			echo '</p>';
		}
		?>
		</td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">最大抽出件数</th>
		<td align="left" valign="top"><?=htmlDisplay($dat["max_result"])?>件</td>
	</tr>
	<?php
	$AUTOLINK_PUBLISH_SPAN_TYPE_ARY = getDefineArray('AUTOLINK_PUBLISH_SPAN_TYPE_ARY');
	?>
	<tr>
		<th width="200" align="left" valign="top" scope="row">掲載期間</th>
		<td align="left" valign="top">
			<?php
			//掲載期間の指定を表示
			print(htmlDisplay($AUTOLINK_PUBLISH_SPAN_TYPE_ARY[$dat["w_publish_span_type"]]));
			//掲載期間の指定がある場合
			if ($dat["w_publish_span_type"] != AUTOLINK_PUBLISH_SPAN_TYPE_NONE) {
				//表示日数を表示
				print('<table class="cms8341-dataTable" width="100%" border="0" cellpadding="5" cellspacing="0" style="margin-top: 5px;">');
				print('<tr>');
				print('<th width="200" align="left" valign="top" scope="row">表示日数</th>');
				print('<td align="left" valign="top">');
				print(htmlDisplay($dat["w_publish_span_days"]) . "日");
				print('</td>');
				print('</tr>');
				print('</table>');
			}
			?>
		</td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">デザイン設定 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top">
		<?php
		foreach (explode(",", $dat['use_group']) as $value) {
			echo htmlDisplay($AUTOLINK_GROUP[$value]) . "&nbsp;&nbsp;&nbsp;";
		}
		?>
		</td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">RSS設定 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top">
			<?=$rss_flg_ary[$dat["rss_flg"]]?>
			<table width="100%" border="0" cellpadding="5" cellspacing="0"
			id="rss_table" class="cms8341-dataTable">
				<?php
				if ($dat['rss_file'] != "") {
					?>
				<tr>
				<th width="200" align="left" valign="top" scope="row">ファイル名 <span
					class="cms_require">（必須）</span></th>
				<td align="left" valign="top"><?=htmlDisplay($dat['rss_file'])?>.xml</td>
			</tr>
				<?php
				}
				?>
			</table>
		</td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">表示設定許可ユーザー</th>
		<td align="left" valign="top">
			<table cellspacing="0" cellpadding="5" border="1" style="margin-top:10px;border-collapse:collapse">
<?php 

$user_select_list = "";
foreach($user_ary as $user){
	// ユーザーIDのリスト(カンマ区切り文字列)を作成する
	if($user_select_list != ''){
		$user_select_list .= ',';
	}
	$user_select_list .= $user['user_id'];
	
?>
				<tr>
					<td><span><?=htmlspecialchars($user['dept_name'])?></span></td>
					<td><span><?=htmlspecialchars($user['name'])?></span></td>
				</tr>
<?php
}
?>
			</table>
			<input type="hidden" id="hdn_cms_user_select_list" name="hdn_cms_user_select_list" value="<?=$user_select_list?>">
		</td>
	</tr>
<?php
$temp_ary = array(
		AUTOLINK_INF, 
		AUTOLINK_DEL
);
if (in_array($bv, $temp_ary)) {
	?>
	<tr>
		<th width="200" align="left" valign="top" scope="row">自動リンク設定コード</th>
		<td align="left" valign="top"><?=htmlDisplay(createAutolinkCode($dat))?></td>
		<input type="hidden" name="a_link_id" value="<?=$dat['a_link_id']?>">
	</tr>
<?php
}
?>
</table>
<p align="center"><?=$image?><a href="javascript:history.back()"><img
	src="<?=RPW?>/admin/images/btn/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0" style="margin-left: 10px"></a></p>

</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<input type="hidden" name="behavior" value="<?=$bv?>">
</form>
</body>
</html>
