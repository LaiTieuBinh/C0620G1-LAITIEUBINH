<?php
/*
 *
 */
//外部ファイル読み込み
require_once ("../.htsetting");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>カテゴリ別表示順設定画面</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
</head>
<body id="cms8341-mainbg">
		<?php
		// ヘッダーメニュー挿入
		$headerMode = 'autolink';
		include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
		require_once (APPLICATION_ROOT . '/common/function/func_progressbar.inc');
		$pgrs_func = new progressbar();
		?>
		<div align="center" id="cms8341-contents">
<div><img src="images/bar_conf.jpg" alt="" width="920" height="30"></div>
<div class="cms8341-area-corner">
				<?=$pgrs_func->get_progress_area()?>
			</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents -->
</body>
</html>
<?php
require_once ('./include/autolinkCommonFunc.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_auto_link_pages.inc');
global $objCnc;

//DBアクセス用ファイルの読み込み
$objAlp = new tbl_auto_link_pages($objCnc);

//POST値の取得
if (!isset($_POST['cms_a_link_id'])) {
	autolinkError("不正なパラメータです。");
}
$a_link_id = $_POST['cms_a_link_id'];
$mode = $_POST['mode'];

// POSTより取得したデータを配列化
$insAry = array();
foreach ($_POST as $target => $data) {
	if (strpos($target, "__") === FALSE) continue;
	list($page_id, $key) = explode("__", $target);
	$insAry[$page_id][$key] = $data;
}
// プライマリキーを設定
foreach ($insAry as $key => $value) {
	if ($mode == "close") $value['sort_order'] = "";
	if ($value['group'] == 0 && $value['sort_order'] == "" && $value['image_path'] == "" && $value['image_alt'] == "") {
		unset($insAry[$key]);
		continue;
	}
	$insAry[$key]['a_link_id'] = $a_link_id;
	$insAry[$key]['page_id'] = $key;
}

// 即公開を行う場合は排他制御を行う
if (isset($_POST['public']) && $_POST['public'] == FLAG_ON) {
	if (lock_file_management('lock') === FALSE) {
		autolinkError("現在アップロード処理中のため即公開を行うことができません。<br>しばらく時間をおいてから再度お試しください。<br>");
	}
}

$ret = NONE;
//トランザクション開始
$objCnc->begin();
$objAlp->delete($a_link_id, $mode);
//DB登録処理
foreach ($insAry as $ary) {
	if (!$objAlp->insert($ary)) {
		lock_file_management('unlock');
		autolinkError("自動リンクページ情報の登録に失敗しました。");
	}
}

//  ページの生成
if (isset($_POST['public']) && $_POST['public'] == FLAG_ON) {
	$ftpCnc = connectFTP("cms");
	if (ENABLE_OPTION_ADVERT) $ftpCgiCnc = connectFTP("click_cgi");
	$ret = publishAutolinkPages($a_link_id, $ftpCnc, $pgrs_func);
	cx_ftp_close($ftpCnc);
	if (ENABLE_OPTION_ADVERT) cx_ftp_close($ftpCgiCnc);
}

//トランザクション終了
$objCnc->commit();
lock_file_management('unlock');

if ($ret === NONE) {
	header("Location: " . HTTP_ROOT . RPW . "/admin/page/autolink/list.php?a_link_id=" . $a_link_id . "&mode=" . $mode);
	exit();
}
$pgrs_func->send_msg("再公開が終了しました。");
$pgrs_func->disp_btn(RPW . "/admin/page/autolink/list.php?a_link_id=" . $a_link_id . "&mode=" . $mode);
$pgrs_func->end();
?>
