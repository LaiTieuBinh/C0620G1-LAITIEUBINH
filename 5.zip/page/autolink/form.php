<?php
/*
 * 自動リンク先設定　登録・更新画面(form.php)
 */
/** require **/
require ("../.htsetting");
require_once ('./include/autolinkCommonFunc.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/commands.inc');

/** init **/
$iUser = array();
$user_ary = array();

//main
if (!isset($_POST["behavior"]) || !isset($_POST["cate_code"])) {
	autolinkError("パラメータエラー（behavior）");
}
$bv = $_POST["behavior"];
switch ($bv) {
	case AUTOLINK_ADD : // 新規登録
		$label = '自動リンク先追加';
		$image = '<img src="images/bar_add.jpg" alt="自動リンク先追加" width="920" height="30">';
		$dat = craeteEmptyAutolinkData();
		$dat['cate_code'] = $_POST['cate_code'];
		break;
	case AUTOLINK_UPD : // 修正
		if (!isset($_POST["a_link_id"])) {
			autolinkError("パラメータ取得エラー(a_link_id)");
		}
		$label = '自動リンク先修正';
		$image = '<img src="images/bar_fix.jpg" alt="自動リンク先修正" width="920" height="30">';
		$dat = craeteEmptyAutolinkData();
		if (($ary = getAutolinkDbData($_POST["a_link_id"])) === FALSE) {
			autolinkError("自動リンク情報の取得に失敗しました");
		}
		$dat = array_merge($dat, $ary);
		convertDBtoDISP($dat);
		// 表示設定許可ユーザー情報を取得する
		$user_ary = getAutoLinkUserByAid($dat['a_link_id']);
		if($user_ary === FALSE){
			autolinkError("表示設定許可ユーザー情報の取得に失敗しました");
		}
		break;
	default :
		autolinkError("パラメータエラー（behavior）");
}

$autolink_str = "";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$label?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="autolink.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/autolink.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
function cxSubmit(){
	// 入力チェック
	if(!isEmpty('name',"自動リンク先名称") ) return false;
	//if(!isSelect('rss_flg',"RSS設定") ) return false;
	if($('rss_flg_1').checked){
		if(!isEmpty('rss_file',"ファイル名") ) return false;
		if(!isFile('rss_file',"ファイル名") ) return false;
	} else if($('rss_flg_0').checked){
		$('rss_file').value = "";
	} else {
		alert('RSS設定が選択されていません');
		return false;
	}
	if(!isId('w_template_id',"テンプレートID") ) return false;
	
	// デザイングループが選択されていない場合
	if(!isCheck('use_group[]')){
		alert("デザイングループを選択してください");
		return false;
	}
	// アンケートのチェックがついていない場合
	if(!$('w_template_kind_'+TEMPLATE_KIND_ENQUETE).checked){
		clearCheck('w_enquete_kind[]');
	}
	// 親ページ設定チェック
	if(($F('w_parent_id') != "" && $('w_parent_class').selectedIndex == 0) ||
	   ($F('w_parent_id') == "" && $('w_parent_class').selectedIndex != 0) ){
	   alert("親ページ設定を指定する場合は親ページ抽出階層も指定してください");
	   return false;
	}
	
	if($('link_target_'+AUTOLINK_CONDITION_MASTER).checked &&
	   !isCheck('w_template_kind[]') && 
	   $F('w_fixed') == "" &&
	   $F('w_template_id') == "" && 
	   $F('w_file_path') == "" && 
	   $F('w_cate_code') == "" && 
	   $('w_cate_level').selectedIndex == 0 && 
	   $F('w_dept_code') == "" && 
	   $('w_dept_level').selectedIndex == 0 && 
	   $('w_contents_top').selectedIndex == 0 &&
	   ($F('w_parent_id') == "" || $('w_parent_class').selectedIndex == 0) ){
	   alert("抽出条件を指定してください");
	   return false;
	}
	if($('link_target_'+AUTOLINK_CONDITION_PLURALS).checked &&
	   $('w_a_link_id').value == ""){
	   alert("自動リンク先を指定してください");
	   return false;
	}
	// 最大抽出件数をtrim
	$('max_result').value = trim($F('max_result'));
	if($F('max_result') != "" && !cxDateNumeric($F('max_result'))){
	   alert("最大抽出件数は半角数字を入力してください");
	   return false;
	}
	// 表示順
	var tmp_ary = new Array();
	var elements = Form.getElements('form', 'text'); 
	is_err = false;
	var order = "";
	elements.each( 
		function(elem,idx) { 
			id = elem.id;
			if(id.indexOf("order_select_") == 0) {
				for(i =0; i<tmp_ary.length;i++){
					if(tmp_ary[i] == elem.value){
						is_err = true;
						return;
					}
				}
				tmp_ary.push(elem.value);
		    	num = id.replace("order_select_","");
		    	asc = $('asc_select_'+num).value;
				order += elem.value+" "+asc+",";
			}
		} 
	); 	
	if(is_err == true){
		alert("表示順で重複している値があります");
		return false;
	}
	order = order.substr(0,order.length-1);
	$('order').value = order;

	//掲載期間
	if($F('w_publish_span_type') == "" || !cxDateNumeric($F('w_publish_span_type'))){
		alert("掲載期間を選択してください");
		return false;
	}
	//掲載期間が設定されている場合
	if($F('w_publish_span_type') != 0){
		//表示日数をチェック
		if($F('w_publish_span_days') == ""){
			alert("表示日数を指定してください");
			return false;
		}
		if(!cxDateNumeric($F('w_publish_span_days'))){
			alert("表示日数は半角数字で指定してください");
			return false;
		}
	}

	clearData();
	
	$('form').submit();
	return false;
}

function clearData(){
	if($('link_target_'+AUTOLINK_CONDITION_PAGE).checked){
		clearPlurals();
		clearMaster();
	}
	if($('link_target_'+AUTOLINK_CONDITION_MASTER).checked){
		clearPlurals();
	}
	if($('link_target_'+AUTOLINK_CONDITION_PLURALS).checked){
		clearMaster();
	}
	cmUserNameStringCreate();
}

function clearMaster(){
	$('w_template_id').value = "";
	$('w_file_path').value = "";
	$('w_cate_code').value = "";
	$('w_cate_level').selectedIndex = 0;
	$('w_dept_code').value = "";
	$('w_dept_level').selectedIndex = 0;
	$('w_contents_top').selectedIndex = 0;
}

function clearPlurals(){
	$('w_a_link_id').value = "";
}

// 空チェック
function isEmpty(id,name){
	if($F(id) == ""){
		alert(name+"が入力されていません")
		$(id).focus();
		return false;
	}
	return true;
}
// 選択チェック
function isSelect(id,name){
	if($F(id) == ""){
		alert(name+"が選択されていません")
		$(id).focus();
		return false;
	}
	return true;
}
// チェックされているかチェック
function isCheck(name){
	ret = false;
	var nodes = Form.getInputs($('form'),'checkbox',name);
	$A(nodes).each( function(obj) { 
						if(obj.checked) ret = true; 
					} ); 
	return ret;
}
// チェックを全てONまたはOFFにする
function clearCheck(name){
	var nodes = Form.getInputs($('form'),'checkbox',name);
	$A(nodes).each( function(obj) { 
						obj.checked = false; 
					} ); 
	return;
}
// 数字チェック
function isNumric(id,name,max){
	num = new Number($F(id));
	if(!cxDateNumeric($F(id))){
		alert(name+"は1以上"+max+"以下の数字を入力してください")
		$(id).focus();
		return false;
	}
	if(num < 1 || num > max){
		alert(name+"は1以上"+max+"以下の数字を入力してください")
		$(id).focus();
		return false;
	}
	return true;
}
// ファイル名チェック
function isFile(id,name) {
	var str = $(id).value;
	if( str.match( /[^A-Za-z0-9_-]+/ ) ) {
		alert(name+"は半角英数字と「-_」のみを入力してください")
		return false;
	}
	return true;
}
// IDチェック
function isId(id,name) {
	var str = $(id).value;
	if( str.match( /[^0-9,]+/ ) ) {
		alert(name+"は半角数字と「,」のみを入力してください")
		return false;
	}
	return true;
}
// RSS設定を選択したとき
function cxRssChange() {
	if($('rss_flg_1').checked){
		Element.show($('rss_table'));
	} else {
		Element.hide($('rss_table'));
	}
	return;
}
// テンプレート種別を選択したとき
function cxTemplateKind() {
	if($('w_template_kind_'+TEMPLATE_KIND_ENQUETE).checked){
		Element.show($('enquete_kind_tr'));
	} else {
		Element.hide($('enquete_kind_tr'));
	}
	return;
}
// 抽出条件を選択したとき
function cxCondition() {
	if($('link_target_0').checked){
		Element.show($('page_table'));
		Element.hide($('condition_table'));
		Element.hide($('plurals_table'));
	} else if($('link_target_1').checked){
		Element.hide($('page_table'));
		Element.show($('condition_table'));
		Element.hide($('plurals_table'));
	} else if($('link_target_2').checked){
		Element.hide($('page_table'));
		Element.hide($('condition_table'));
		Element.show($('plurals_table'));
	}
	return;
}

function cxAutoLinksSetting(){
	var li = '';
	var a_link_id = '';
	prm = "a_link_id="+$F('w_a_link_id');
	//ダイアログの表示
	cxIframeLayer(
		cms8341admin_path + "/page/common/autolink/index.php?"+prm,
		630,
		660,
		COVER_SETTING.COLOR,
		'',
		function (retObj) {
			if(retObj== undefined) return;
			if(retObj['a_link_id'] != ""){
				tmpAry = retObj['a_link_id'].split(AUTOLINK_DELIMITER);
				for(i = 0; i < tmpAry.length; i++){
					a_link_ary = tmpAry[i].split(":");
					if(a_link_id != "") a_link_id += ",";
					a_link_id += a_link_ary[0];
					li += '<li>' + a_link_ary[1] + '</li>';
				}
			}
			if(li) {
				$('cms-auto-links').innerHTML = li;
				$('cms-auto-links').style.display = 'block';
			} else {
				$('cms-auto-links').style.display = 'none';
			}
			$('w_a_link_id').value = a_link_id;
		}
	);
}

function cxGetAutolinkName(r){
	var rText = r.responseText;
	$('cms-auto-links').innerHTML = rText;
}

// パンくず（親ページ）の変更
function cxOpenPanset() {
	var pid = $('w_parent_id').value;
	if (pid == '') pid = 1;
	var uri = cms8341admin_path+'/page/autolink/pankuzu_set.php?pid='+pid;
	window.name='win_cms8341Main';
        cxIframeLayer(uri, 800, 600, COVER_SETTING.COLOR, 'panset' );
	return false;
}
function cxPankuzuSet(pid,ptitle) {
	$('w_parent_id').value = pid;
	$('parent_page_title').innerHTML = ptitle;
}

//親ページを削除する
function cxParentDel(){
	//ダイアログで確認
	if(!confirm("現在設定されている親ページの指定を削除します。\nよろしいですか？")) return false;
	$('w_parent_id').value = "";
	$('parent_page_title').innerHTML = "";
	return false;
}

function cx_add_order(){
	var ins_str = "";
	var num = 0;
	var elements = Form.getElements('form', 'text'); 
	elements.each( 
		function(elem,idx) { 
			id = elem.id;
			if(id.indexOf("order_select_") == 0) {
		    	tmp_num = id.replace("order_select_","");
		    	if(num < tmp_num) num = tmp_num;
			}
		} 
	); 
	num++;
	ins_str += '<p style="margin:3px;" id="order_p_@@replace@@">';
	ins_str += '<?=mkcombobox($AUTOLINK_ORDER_ARY, "order_select_@@replace@@");?>';
	ins_str += '&nbsp;<?=mkcombobox($asc_ary, "asc_select_@@replace@@");?>';
	ins_str += '&nbsp;<a href="javascript:" onClick="cx_del_order(\'@@replace@@\')"><img src="<?=RPW?>/admin/images/btn/btn_del_mini.gif" border="0" width="60" height="20"></a>';
	ins_str += '</p>';
	ins_str = replaceAll(ins_str,"@@replace@@",num);
	new Insertion.Bottom('order_td', ins_str); 
	
}

function cx_del_order(key){
	Element.remove($("order_p_"+key));
}

//掲載期間の設定を変更した場合
function cngPublishSpanType(){
	//「設定しない」を選択した場合
	if($('w_publish_span_type').value == 0){
		//日数の設定を消す
		$('w_publish_span_days').disabled = true;
		$('publish_span_table').style.display = 'none';
	}
	//それ以外を選択した場合
	else{
		//日数の設定を表示する
		$('w_publish_span_days').disabled = false;
		$('publish_span_table').style.display = 'block';
	}
}

function init(){
	if($('rss_table')) cxRssChange();
	cxTemplateKind();
	cxCondition();
	cngPublishSpanType();
	var prm = 'a_link_ids='+$('w_a_link_id').value;
	cxAjaxCommand('cxGetAutolinkName', prm, cxGetAutolinkName);
	var prm = 'page_id='+$('w_parent_id').value+'&target_column=page_title';
	cxAjaxUpdater('cxGetPageInfo',prm,'parent_page_title');
	cxOnloadAutLinkUser('cms_user_select_list', $('hdn_cms_user_select_list').value, $('hdn_dept_name_list').value, $('hdn_user_name_list').value);
}

Event.observe(window,'load',init,false);

//-->
</script>

</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'autolink';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-spell_check">
<div><?=$image?></div>
<div class="cms8341-area-corner">
<form id="form" class="cms8341-form" name="form" method="post"
	action="confirm.php">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="200" align="left" valign="top" scope="row">自動リンク先名称 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top"><input id="name" name="name" type="text"
			style="width: 300px" value="<?=htmlspecialchars($dat['name'])?>"></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">ページ抽出方法 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top">
	<?=mkradiobutton($AUTOLINK_CONDITION_ARY, "link_target", $dat['link_target'], 0, "", "cxCondition()")?>
	<table width="100%" border="0" cellpadding="5" cellspacing="0"
			id="page_table" class="cms8341-dataTable">
			<tr>
				<th width="200" align="left" valign="top" scope="row">選択権限</th>
				<td align="left" valign="top"><?=mkradiobutton($auth_ary, "auth", $dat['auth'])?></td>
			</tr>
		</table>
		<table width="100%" border="0" cellpadding="5" cellspacing="0"
			id="condition_table" class="cms8341-dataTable">
			<tr>
				<th width="200" align="left" valign="top" scope="row">テンプレート種類</th>
				<td align="left" valign="top">
			<?php
			$template_kind_ary = ($dat["w_template_kind"] != "") ? explode(",", $dat["w_template_kind"]) : "";
			echo mkcheckbox($TEMPLATE_KIND, "w_template_kind", $template_kind_ary, 0, "", "cxTemplateKind()");
			?>
			</td>
			</tr>
			<tr id="enquete_kind_tr" style="display: none">
				<th width="200" align="left" valign="top" scope="row">アンケート種類</th>
				<td align="left" valign="top">
			<?php
			$enquete_kind_ary = ($dat["w_enquete_kind"] != "") ? explode(",", $dat["w_enquete_kind"]) : "";
			echo mkcheckbox($ENQUETE_KIND, "w_enquete_kind", $enquete_kind_ary, 0);
			?>
			</td>
			</tr>
			<tr id="fixed_tr">
				<th width="200" align="left" valign="top" scope="row">定型項目</th>
				<td align="left" valign="top"><input type="text" name="w_fixed"
					id="w_fixed" value="<?=htmlspecialchars($dat['w_fixed'])?>"
					style="width: 300px; ime-mode: disabled;"> <br>
				<span style="font-size: 12px;">※複数指定する場合は「，」区切りで指定してください。<br>
				例）item1=2,item2=1,item3=100</span></td>
			</tr>
			<tr>
				<th width="200" align="left" valign="top" scope="row">テンプレートID</th>
				<td align="left" valign="top"><input type="text"
					name="w_template_id" id="w_template_id"
					value="<?=htmlspecialchars($dat['w_template_id'])?>"
					style="width: 300px; ime-mode: disabled;"> <br>
				<span style="font-size: 12px;">※複数指定する場合は「，」区切りで指定してください。例）1,3,6</span>
				</td>
			</tr>
			<tr>
				<th width="200" align="left" valign="top" scope="row">ファイルパス</th>
				<td align="left" valign="top"><input type="text" name="w_file_path"
					id="w_file_path" value="<?=htmlspecialchars($dat['w_file_path'])?>"
					style="width: 300px; ime-mode: disabled;"> <br>
				<span style="font-size: 12px;">※正規表現が使用できます。<br>
				例）/about/.*は全ての階層のaboutフォルダを対象としています。<br>
				^/about/.*は先頭のaboutフォルダを対象としています。<br>
				OR指定する場合は「，」区切りで指定してください。</span></td>
			</tr>
			<tr>
				<th width="200" align="left" valign="top" scope="row">カテゴリコード</th>
				<td align="left" valign="top"><input type="text" name="w_cate_code"
					id="w_cate_code" value="<?=htmlspecialchars($dat['w_cate_code'])?>"
					style="width: 300px; ime-mode: disabled;"> <br>
				<span style="font-size: 12px;">※正規表現が使用できます。<br>
				例）002.*は002がつくカテゴリを対象としています。<br>
				^002は先頭に002のカテゴリを対象としています。<br>
				OR指定する場合は「，」区切りで指定してください。</span></td>
			</tr>
			<tr>
				<th width="200" align="left" valign="top" scope="row">カテゴリ階層</th>
				<td align="left" valign="top"><?=mkcombobox($cate_level_ary, "w_cate_level", $dat["w_cate_level"], 0)?></td>
			</tr>
			<tr>
				<th width="200" align="left" valign="top" scope="row">組織コード</th>
				<td align="left" valign="top"><input type="text" name="w_dept_code"
					id="w_dept_code" value="<?=htmlspecialchars($dat['w_dept_code'])?>"
					style="width: 300px; ime-mode: disabled;"> <br>
				<span style="font-size: 12px;">※正規表現が使用できます。<br>
				例）002.*は002がつく組織コードを対象としています。<br>
				^002.*は先頭に002がつく組織コードを対象としています。<br>
				OR指定する場合は「，」区切りで指定してください。</span></td>
			</tr>
			<tr>
				<th width="200" align="left" valign="top" scope="row">組織階層</th>
				<td align="left" valign="top"><?=mkcombobox($dept_level_ary, "w_dept_level", $dat["w_dept_level"], 0)?></td>
			</tr>
			<tr>
				<th width="200" align="left" valign="top" scope="row">コンテンツトップ</th>
				<td align="left" valign="top"><?=mkcombobox($content_top_ary, "w_contents_top", $dat["w_contents_top"], 0)?></td>
			</tr>
			<tr>
				<th width="200" align="left" valign="top" scope="row">親ページ設定</th>
				<td align="left" valign="top">
				<p id="parent_page_title">&nbsp;</p>
				<input type="hidden" name="w_parent_id" id="w_parent_id"
					value="<?=$dat['w_parent_id']?>">
				<p><a href="javascript:" onClick="return cxOpenPanset()"><img
					src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
					height="20" border="0" class="cms8341-verticalMiddle"></a> <a
					href="javascript:" onClick="return cxParentDel()"><img
					src="<?=RPW?>/admin/images/btn/btn_parent_unset.jpg"
					alt="親ページなしにする" width="150" height="20" border="0"
					class="cms8341-verticalMiddle"></a> <br>
				<span style="font-size: 12px;">※親ページを指定した場合は「親ページ抽出階層」の指定は必須となります。</span></p>
				</td>
			</tr>
			<tr>
				<th width="200" align="left" valign="top" scope="row">親ページ抽出階層</th>
				<td align="left" valign="top">
				<?=mkcombobox($parent_class_ary, "w_parent_class", $dat["w_parent_class"], 0)?>
				<br>
				<span style="font-size: 12px;">※階層数は親ページを含めない階層数です。</span></td>
			</tr>
		</table>
		<table width="100%" border="0" cellpadding="5" cellspacing="0"
			id="plurals_table" class="cms8341-dataTable">
			<tr>
				<th width="200" align="left" valign="top" scope="row">自動リンク先設定</th>
				<td align="left" valign="top">
				<ul id="cms-auto-links"><?=$autolink_str?></ul>
				<p><a href="javascript:" onClick="return cxAutoLinksSetting()"><img
					src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
					height="20" border="0" class="cms8341-verticalMiddle"></a></p>
				</td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">表示順</th>
		<td id="order_td" align="left" valign="top"><a href="javascript:"
			onClick="cx_add_order()"><img
			src="<?=RPW?>/admin/images/btn/btn_add_mini.jpg" border="0"
			width="102" height="21"></a>
	<?php
	$order_ary = explode(",", $dat['order']);
	foreach ($order_ary as $key => $order) {
		$key++;
		$col = "";
		$asc = "asc";
		if ($order != "") {
			if (strpos($order, " ") !== FALSE) {
				LIST($col, $asc) = explode(" ", $order);
			}
			else {
				$col = $order;
			}
		}
		echo '<p style="margin:3px;" id="order_p_' . $key . '">';
		echo mkcombobox($AUTOLINK_ORDER_ARY, "order_select_" . $key, $col);
		echo '&nbsp;' . mkcombobox($asc_ary, "asc_select_" . $key, $asc);
		if ($key > 1) echo '&nbsp;<a href="javascript:" onClick="cx_del_order(' . $key . ')"><img src="' . RPW . '/admin/images/btn/btn_del_mini.gif" border="0" width="60" height="20"></a>';
		echo '</p>';
	}
	
	?>
</td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">最大抽出件数</th>
		<td align="left" valign="top"><input type="text" name="max_result"
			id="max_result" value="<?=htmlspecialchars($dat['max_result'])?>"
			style="width: 100px; ime-mode: disabled;">件</td>
	</tr>
	<tr>
		<?php
		$AUTOLINK_PUBLISH_SPAN_TYPE_ARY = getDefineArray('AUTOLINK_PUBLISH_SPAN_TYPE_ARY');
		?>
		<th width="200" align="left" valign="top" scope="row">掲載期間</th>
		<td align="left" valign="top">
			<?=mkcombobox($AUTOLINK_PUBLISH_SPAN_TYPE_ARY, 'w_publish_span_type', $dat['w_publish_span_type'], 'cngPublishSpanType();')?>
			<table id="publish_span_table" class="cms8341-dataTable" width="100%"
			border="0" cellpadding="5" cellspacing="0"
			style="margin-top: 5px; display: none;">
			<tr>
				<th width="200" align="left" valign="top" scope="row">表示日数<span
					class="cms_require">（必須）</span></th>
				<td align="left" valign="top"><input type="text"
					name="w_publish_span_days" id="w_publish_span_days"
					value="<?=htmlspecialchars($dat['w_publish_span_days'])?>"
					style="width: 100px; ime-mode: disabled;">日</td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">デザイン設定 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top">
	<?php
	$use_group_ary = ($dat["use_group"] != "") ? explode(",", $dat["use_group"]) : "";
	echo mkcheckbox($AUTOLINK_GROUP, "use_group", $use_group_ary, 0);
	?>
	<br>
		<span style="font-size: 12px;">※使用するグループにチェックを入れてください</span></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">RSS設定 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top">
	<?=mkradiobutton($rss_flg_ary, "rss_flg", $dat["rss_flg"], 0, "", "cxRssChange()")?>
	<table width="100%" border="0" cellpadding="5" cellspacing="0"
			id="rss_table" class="cms8341-dataTable">
			<tr>
				<th width="200" align="left" valign="top" scope="row">ファイル名 <span
					class="cms_require">（必須）</span></th>
				<td align="left" valign="top"><input type="text" name="rss_file"
					id="rss_file" value="<?=htmlspecialchars($dat['rss_file'])?>"
					style="width: 200px; ime-mode: disabled;">.xml</td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">表示設定許可ユーザー</th>
		<td align="left" valign="top">
			<a href="javascript:" onClick="cxOpenUserSelect('cms_user_select_list')">
				<img id="cms_user_select" alt="追加" src="<?=RPW?>/admin/images/btn/btn_add_mini.jpg" 
				width="100" height="20" border="0"
				style="cursor: pointer;" class="cms8341-verticalMiddle">
			</a>
		<div id="cms_user_select_list"></div>
<?php	
$user_select_list = '';
$user_dept_list = '';
$user_name_list = '';
foreach($user_ary as $user){
	// ユーザーIDのリスト(カンマ区切り文字列)を作成する
	if($user_select_list != ''){
		$user_select_list .= ',';
		$user_dept_list .= '\',\'';
		$user_name_list .= '\',\'';
	}
	$user_select_list .= $user['user_id'];
	$user_dept_list .= htmlspecialchars($user['dept_name']);
	$user_name_list .= htmlspecialchars($user['name']);
	
}
?>
		<?php // 追加したuser_idすべてを格納するhidden値 ?>
		<input type="hidden" id="hdn_cms_user_select_list" name="hdn_cms_user_select_list" value="<?=$user_select_list?>">
		<input type="hidden" id="hdn_dept_name_list" name="hdn_dept_name_list" value="<?=$user_dept_list?>">
		<input type="hidden" id="hdn_user_name_list" name="hdn_user_name_list" value="<?=$user_name_list?>">
		</td>
	</tr>
</table>
<p align="center"><a href="javascript;" onClick="return cxSubmit();"><img
	src="<?=RPW?>/admin/images/btn/btn_conf.jpg" alt="確認" width="150"
	height="20" border="0" style="margin-right: 10px"></a> <a
	href="javascript:history.back()"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px"></a></p>
<input type="hidden" name="behavior" id="behavior" value="<?=$bv?>"> <input
	type="hidden" name="a_link_id" id="a_link_id"
	value="<?=$dat['a_link_id']?>"> <input type="hidden" name="cate_code"
	id="cate_code" value="<?=$dat["cate_code"]?>"> <input type="hidden"
	name="w_a_link_id" id="w_a_link_id" value="<?=$dat["w_a_link_id"]?>"> <input
	type="hidden" name="order" id="order" value="<?=$dat["order"]?>"></form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
