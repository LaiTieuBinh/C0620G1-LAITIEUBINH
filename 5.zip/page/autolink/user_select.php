<?php
/*
 *
 */
require ("./.htsetting");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ユーザー追加</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/master/user/user.css"
	type="text/css">
<style type="text/css">
.cms8341-enqsettingarea {
	width: 732px;
	height: 621px;
	overflow: auto;
	margin: 0px 0px 10px 0px;
	background-color: #FFFFFF;
	padding: 15px 19px 15px 19px;
	text-align: left;
	border: solid 1px #999999;
	font-size: 14px;
}

.cms8341-wrapper {
	width: 710px;
}
</style>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
//
function cxDeptReload(url){
	var a = new Ajax.Updater(
       'data_area',
       cms8341admin_path+'/page/autolink/user_dept_exec.php',
       {   
          method: 'post',
          postBody: url,
          onSuccess: function(request) {
          },   
          onFailure: function(request) {   
             alert('失敗しました');   
          }   
       }   
    );   
}
function cxSubmit(user_id,name,dept){
	var retObj = new Object();
	retObj["user_id"] = user_id;
	retObj["name"]   = name;
	retObj["dept"] = dept;
	cxIframeLayerCallback(retObj);
}

function cxInit() {
	$('data_area').innerHTML = "";
	cxDeptReload("");
}
Event.observe(window,'load',cxInit,false);
//-->
</script>
</head>

<body id="cms8341-mainbg">
<table width="792" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="792" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="792" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/page/autolink/images/title_useradd.jpg"
					alt="ユーザー追加" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="#"
					onclick="cxIframeLayerCallback();" id="header_close"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div class="cms8341-enqsettingarea">
		<div class="cms8341-wrapper">
		<div id="data_area"></div>
		</div>
		</div>

</body>
</html>