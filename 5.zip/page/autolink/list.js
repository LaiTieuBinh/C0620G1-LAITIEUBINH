/*
 * 自動リンク設定機能：表示順設定画面javascript
 */

/**
 * グループのプルダウンにより表示する場所を変更する
 * 
 * @param page_id
 *            ページID
 * @return false;
 */
function cx_ChangeSP(page_id) {
	//移動するノードの作成
	var node = $('page_id_' + page_id + '_tr').cloneNode(true);

	// 通常->得だし
	if ($('page_id_' + page_id + '_chk').checked) {
		$('page_id_' + page_id + '_tr').removeNode(true);
		$('tbody_' + FLAG_ON).appendChild(node);
		$('page_id_' + page_id + '_chk').checked = true;
	}
	//得だし->通常
	else {
		$('page_id_' + page_id + '_tr').removeNode(true);
		$('tbody_' + FLAG_OFF).appendChild(node);
		$('page_id_' + page_id + '_chk').checked = false;
	}
	//ボタン表示加工処理
	cx_ChangeShiftButton();
	return false;
}

/**
 * 上下ボタンにより表示する場所を変更する
 * @param obj_tr trタグ
 * @param flg 動かすフラグ UP：上へ DN:下へ
 * @return false;
 */
function cx_Shift_Tr(obj_tr, flg) {
	//tbodyの取得
	var tbody = $(obj_tr).parentNode;
	// 動かすチェックボックスの状態を取得
	var obj_chk = $(obj_tr).getElementsByTagName('input')[0].checked;
	// 「上へ」ボタンの処理
	if (flg == 'UP' && $(obj_tr).previousSibling)
		tbody.insertBefore($(obj_tr), $(obj_tr).previousSibling);
	// 「下へ」ボタンの処理
	else if (flg == 'DN' && $(obj_tr).nextSibling)
		tbody.insertBefore($(obj_tr), $(obj_tr).nextSibling.nextSibling);
	// チェックボックスの状態をセット
	$(obj_tr).getElementsByTagName('input')[0].checked = obj_chk;
	// ボタン表示加工処理
	cx_ChangeShiftButton();
	return false;
}

/**
 * リストの内容が変更された場合の上下ボタンの表示変更処理
 * @return false;
 */
function cx_ChangeShiftButton() {
	/*	//テーブルID
	 var tbody_id = Array('tbody_' + FLAG_ON,'tbody_' + FLAG_OFF);
	 for(i = 0;i < tbody_id.length;i++){
	 //trタグを取得
	 var tr_ary = $(tbody_id[i]).getElementsByTagName('tr');
	 for(j = 0;j < tr_ary.length;j++){
	 //FAQIDを取得
	 page_id = tr_ary[j].id.replace('_tr','');
	 page_id = page_id.substring(page_id.lastIndexOf('_',page_id.length) + 1,page_id.length);
	 // 全てのtrタグ
	 $('page_id_' + page_id + '_td_sort_order').innerHTML = '' + 
	 // 「上へ」ボタン
	 '<a href="javascript:void(0)" id="page_id_' + page_id + '_a_up" onClick="cx_Shift_Tr(\'page_id_' + page_id + '_tr\',\'UP\')">' + 
	 '<img id="page_id_' + page_id + '_img_up" src="' + RPW + '/admin/images/btn/btn_up_on.jpg" width="61" height="20" alt="上へ" border="0" style="margin:0px;padding:0px;vertical-align:middle;">' + 
	 '</a>' + 
	 '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + 
	 // 「下へ」ボタン
	 '<a href="javascript:void(0)" id="page_id_' + page_id + '_a_dn" onClick="cx_Shift_Tr(\'page_id_' + page_id + '_tr\',\'DN\')">' + 
	 '<img id="page_id_' + page_id + '_img_dn" src="' + RPW + '/admin/images/btn/btn_down_on.jpg" width="61" height="20" alt="下へ" border="0" style="margin:0px;padding:0px;vertical-align:middle;">' + 
	 '</a>';
	 // 最初のtrタグ
	 if(tr_ary[j] == $(tbody_id[i]).firstChild){
	 //キーの無効(Aタグ削除)
	 $('page_id_' + page_id + '_img_up').src = RPW + '/admin/images/btn/btn_up_off.jpg';
	 $('page_id_' + page_id + '_a_up').removeNode(false);
	 }
	 //最後のtrタグ
	 if(tr_ary[j] == $(tbody_id[i]).lastChild){
	 //キーの無効(Aタグ削除)
	 $('page_id_' + page_id + '_img_dn').src = RPW + '/admin/images/btn/btn_down_off.jpg';
	 $('page_id_' + page_id + '_a_dn').removeNode(false);
	 }
	 }
	 }*/
	return false;
}

/**
 * 設定ボタンを押した時の処理
 * @return 登録処理に成功した場合は、true。それ以外の場合はfalseを返す
 */
function cx_Submit() {
	//設定中レイヤー表示
	$('cms8341-progressmsg').innerHTML = '設定中．．．';
	cxLayer('cms8341-progress', 1, 500, 500);
	// テーブルID
	var tbody_id = Array('tbody_' + FLAG_ON, 'tbody_' + FLAG_OFF);
	// 変数の宣言
	var page_id_ary = Array();
	var sp_out_flg_ary = Array();
	var public_page_flg = ($('cms_public_page_flg').checked ? $('cms_public_page_flg').value
			: '');

	// テーブルIDの数分ループ
	for (i = 0; i < tbody_id.length; i++) {
		//trタグを取得
		var tr_ary = $(tbody_id[i]).getElementsByTagName('tr');
		for (j = 0; j < tr_ary.length; j++) {
			//特だしフラグ
			sp_out_flg_ary[page_id_ary.length] = (i == 0 ? FLAG_ON : FLAG_OFF);
			// ソート順(id)
			page_id = tr_ary[j].id.replace('_tr', '');
			page_id_ary[page_id_ary.length] = page_id.substring(page_id
					.lastIndexOf('_', page_id.length) + 1, page_id.length);
		}
	}
	//登録処理用PHPを呼び出す(Ajax)
	var a = new Ajax.Request(
			baseUrl + 'admin/special/faq/list/list_sort_complete.php', {
				method : 'post',
				postBody : 'cms_page_id_ary=' + page_id_ary
						+ '&cms_sp_out_flg_ary=' + sp_out_flg_ary
						+ '&cms_public_page_flg=' + public_page_flg,
				//成功した場合
				onComplete : function(originalRequest) {
					//設定中レイヤーを閉じる
					cxLayer('cms8341-progress', 0);
					// エラーがあった場合
					if (originalRequest.responseText != "")
						alert(originalRequest.responseText);
					// 正常終了した場合
					else
						location.replace('index.php');
				},
				//失敗した場合
				onFailure : function(request) {
					//設定中レイヤーを閉じる
					cxLayer('cms8341-progress', 0);
					alert('登録処理に失敗しました');
				}
			});
	return false;
}
