<?php
/*
 *
 */
/** プレビュー **/
require ("../.htsetting");

// 親ページ設定用のインクルードファイルを読み込み
require_once (DOCUMENT_ROOT . RPW . '/admin/page/common/pankuzu_set/pankuzu_set_common.inc');

global $objCnc;
global $objLogin;
// 別ウィンドウ用
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");

if (isset($_POST) && count($_POST) > 0) $post = $_POST;
if (isset($_GET['pid']) && $_GET['pid'] != '') $post['cms_page_id'] = $_GET['pid'];
if (!isset($post)) user_error('ページを表示できません');

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
if ($objPage->selectFromID($post['cms_page_id'], PUBLISH_TABLE, 'p.work_class, p.status, p.user_id, p.file_path,p.page_title') === FALSE) {
	if ($objPage->selectFromPath(SITE_TOP_PAGE) === FALSE) {
		user_error("dac execute error. <br>tbl_page->selectFromID(" . $post['cms_page_id'] . ", 1);", E_USER_ERROR);
	}
	$post['cms_page_id'] = $objPage->fld['page_id'];
}
$fld = $objPage->fld;

//新規以外は、公開中の情報を表示
if ($fld['work_class'] != WORK_CLASS_NEW) $dispMode = PUBLISH_TABLE;
//新規の場合
else {
	//ページ作成者 or ウェブマスターの場合
	if ($fld['user_id'] == $objLogin->get('user_id') || $objLogin->get('class') == USER_CLASS_WEBMASTER) $dispMode = WORK_TABLE;
	//他のページ作成者
	else {
		//サイトトップページを表示
		if ($objPage->selectFromPath(SITE_TOP_PAGE) === FALSE) user_error("ページが見つかりません", E_USER_ERROR);
		$fld = $objPage->fld;
		//サイトトップページが公開されている場合
		if ($fld['work_class'] != WORK_CLASS_NEW) $dispMode = PUBLISH_TABLE;
		//サイトトップページが公開されていない場合
		else user_error('ページを表示できません', E_USER_ERROR);
	}
}

$post['cms_dispMode'] = $dispMode;
// プレビュー情報をセットする
include (APPLICATION_ROOT . "/common/inc/set_preview.inc");

// イベントを無効化する
$event_flg = FLAG_ON;

// プレビューを生成する
include (APPLICATION_ROOT . "/common/inc/set_preview_htmlStr.inc");

// フォーム
$form_start = '<form name="cms_fPanset" id="cms_fPanset" class="cms8341-form" method="post" action="" target="">' . "\n" . '<input type="hidden" name="cms_page_id" id="cms_page_id" value="' . $PID . '">' . "\n" . '<input type="hidden" name="cms_page_title" id="cms_page_title" value="' . $fld['page_title'] . '"></form>';

// 親ページ設定ボタン
$message = "";
$panset = '<a href="javascript:" onClick="return cxSetParent(\'autolink\');"><img src="' . RPW . '/admin/images/pageproperty/btn_panset.jpg" alt="親ページに設定" style="margin-right:5px;" width="170" height="30" border="0"></a>';
$params = array(
		'msg' => $message, 
		'mode' => "autolink"
);

// ONLOADを消去
$htmlStr = preg_replace('/onload="[^"]*"/i', '', $htmlStr);
$htmlStr = preg_replace('/.*\.onload.*/i', '', $htmlStr);
$htmlStr = preg_replace('/<script.*<\/script>/i', '', $htmlStr);
// HTML 生成
createHtml($htmlStr, "autolink", $panset, $form_start, $params);
// 特殊な置き換え
$htmlStr = preg_replace('/(<body[^>]*>)/i', '${1}' . '<span style="width:100%;height:100%;margin-bottom:1px;">' . "\n", $htmlStr);
$htmlStr = preg_replace('/(<\/body>)/i', '</span>' . '${1}' . "\n", $htmlStr);
// HTML 表示
print $htmlStr;
?>