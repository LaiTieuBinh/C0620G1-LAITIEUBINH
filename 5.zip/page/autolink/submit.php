<?php
/*
 * 自動リンク決定処理
 */
/** require **/
require ("../.htsetting");
require_once ('./include/autolinkCommonFunc.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
global $objCnc;
$objCnc->begin();

/** get post data **/
$bv = $_POST["behavior"];
switch ($bv) {
	case AUTOLINK_ADD :
		$dat = $_SESSION['hidden'];
		convertDISPtoDB($dat);
		if (insertAutolink($dat) === FALSE) {
			autolinkError("自動リンク情報の登録に失敗しました");
		}
		// 表示設定許可ユーザー情報を登録する
		$a_ret = insertAutoLinkUser($dat['a_link_id'], $_POST["hdn_cms_user_select_list"]);
		if($a_ret === FALSE){
			$objCnc->rollback();
			autolinkError("表示設定許可ユーザーの登録に失敗しました");
		}
		break;
	case AUTOLINK_UPD :
		$dat = $_SESSION['hidden'];
		convertDISPtoDB($dat);
		updateAutolink($dat);
		// 表示設定許可ユーザーを総入れ替え(DELETE/INSERT)する
		$a_ret = deleteInsertAutoLinkUser($dat['a_link_id'],$_POST["hdn_cms_user_select_list"]);
		if($a_ret === FALSE){
			$objCnc->rollback();
			autolinkError("表示設定許可ユーザーの登録に失敗しました");
		}
		break;
	case AUTOLINK_DEL :
		$dat = $_SESSION['hidden'];
		if (deleteAutolink($_POST['a_link_id']) === FALSE) {
			autolinkError("自動リンク情報の削除に失敗しました");
		}
		// 表示設定許可ユーザー情報を削除する
		$a_ret = deleteAutoLinkUserHandl($dat['a_link_id']);
		if($a_ret === FALSE){
			$objCnc->rollback();
			autolinkError("表示設定許可ユーザーの削除に失敗しました");
		}
		break;
	default :
		autolinkError("パラメータ取得エラー（behavior）");
}
$objCnc->commit();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>自動リンク先設定完了</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/special/advert/advert.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'autolink';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-templates">
<div><img src="images/bar_conf.jpg" alt="自動リンク先設定完了" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?php
if ($_POST['behavior'] != AUTOLINK_DEL) {
	?>
	<p align="center">自動リンク先の設定が完了しました。</p>
<p style="margin-bottom: 10px">自動リンク設定コード</p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<td><?=htmlDisplay(createAutolinkCode($dat))?></td>
	</tr>
</table>
<?php
}
else {
	echo '<p align="center">自動リンク先の削除が完了しました。</p>';
}
?>	
	<p align="center">
		<?php
		if ($dat['cate_code'] == "" || $dat['cate_code'] == AUTOLINK_SITE_TOP_CATEGORY) {
			$get_param = "";
		}
		else {
			$objCate = new tbl_category($objCnc);
			$objCate->selectFromCode($dat['cate_code']);
			$cate_level = $objCate->fld['level'];
			$get_param = '?cate_code=' . $dat['cate_code'] . '&cate_level=' . $cate_level;
		}
		?>
		<a href="index.php<?=$get_param?>"><img
	src="<?=RPW?>/admin/images/btn/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0" style="margin-right: 10px"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>