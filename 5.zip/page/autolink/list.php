<?php
/*
 * 自動リンク設定：一覧画面
 */
//外部ファイル読み込み
require_once ("../.htsetting");
require_once ('./include/autolinkCommonFunc.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_auto_link.inc');

//変数の指定
$strHTML = ""; //HTML表示用文字列
// アップロード処理中か確認
$is_lock = lock_file_management('check');

if ($_SERVER['REQUEST_METHOD'] == "GET") {
	if (!isset($_GET["a_link_id"])) {
		autolinkError("パラメータ取得エラー(a_link_id)");
	}
	$a_link_id = $_GET["a_link_id"];
	$mode = (!isset($_GET["mode"])) ? "public" : $_GET["mode"];
}
else {
	if (!isset($_POST["a_link_id"])) {
		autolinkError("パラメータ取得エラー(a_link_id)");
	}
	$a_link_id = $_POST["a_link_id"];
	$mode = (!isset($_POST["mode"])) ? "public" : $_POST["mode"];
}

if (($dat = getAutolinkDbData($a_link_id)) === FALSE) {
	autolinkError("自動リンク情報の取得に失敗しました");
}
convertDBtoDISP($dat);

// デザインのプルダウンを生成
$use_group_ary = explode(",", $dat['use_group']);
$AUTOLINK_GROUP = getDefineArray("AUTOLINK_GROUP");
foreach ($AUTOLINK_GROUP as $key => $value) {
	if (in_array($key, $use_group_ary)) continue;
	unset($AUTOLINK_GROUP[$key]);
}
if ($mode == "public") {
	$AUTOLINK_GROUP[AUTOLINK_GROUP_CLOSE] = "表示しない";
	$bg_color = "#78C1F8";
}
else {
	$AUTOLINK_GROUP[AUTOLINK_GROUP_CLOSE] = "表示しない";
	$AUTOLINK_GROUP[AUTOLINK_GROUP_DELETE] = "削除する";
	$bg_color = "#C6C4FD";
}

//修正内容の作成
$correction = array(
	'mode' => $mode,
	'prev_mode' => ""
);
//ページ取得
if (($listAry = getAutolinkPages($a_link_id, '', '', $correction)) === FALSE) {
	autolinkError("自動リンクページリストの取得に失敗しました");
}

$strHTML .= '<table width="100%" style="margin-top:10px;margin-bottom:10px;margin-left:0px;padding:8px;position:relative;background-color:#FFFFCC;border:solid 1px" border="0"  cellspacing="0" cellpadding="0"><tr><td>' . htmlspecialchars($dat['name']) . '</td></tr></table>';

$strHTML .= '<table border="0" width="100%" class="cms8341-dataTable" style="margin-bottom:20px;">' . "\n";
$strHTML .= '<tr align="center" valign="middle"><th width="10%"' . (($mode == "close") ? ' style="display:none;"' : '') . '>表示順</th><th width="50%">ページタイトル<br>自動リンクタイトル</th><th width="15%">デザイン</th><th width="25%">画像</th></tr>' . "\n";

foreach ((array) $listAry as $list) {
	$title = ($list['page_title'] != $list['index_title'] && $list['index_title'] != "") ? htmlDisplay($list['page_title']) . "<br>" . htmlDisplay($list['index_title']) : htmlDisplay($list['page_title']);
	$strHTML .= '<tr>' . "\n";
	if ($mode == "public") {
		$strHTML .= '<td align="center"><input type="text" name="' . $list['page_id'] . "__sort_order" . '" id="' . $list['page_id'] . "__sort_order" . '" value="' . htmlspecialchars($list['sort_order']) . '" maxlength="3" style="width:50px;ime-mode:disabled;"></td>' . "\n";
	}
	$strHTML .= '<td>' . $title . '<br>' . $list['file_path'] . '</td>' . "\n";
	$strHTML .= '<td align="center">' . mkcombobox($AUTOLINK_GROUP, $list['page_id'] . "__group", $list['group']) . '</td>' . "\n";
	$strHTML .= '<td>' . "\n";
	$strHTML .= '<div id="' . $list['page_id'] . '__image_area">';
	if ($list['image_path'] != "") {
		$strHTML .= '<img src="' . RPW . $list['image_path'] . '" alt="' . $list['image_alt'] . '">';
	}
	$strHTML .= '</div>';
	$strHTML .= '<a href="javascript:" onClick="return cxUploadImage(\'' . $list['page_id'] . '\')"><img src="' . RPW . '/admin/images/btn/btn_setup_on.gif" width="60" height="20" alt="設定" border="0" style="margin:0px;padding:0px;vertical-align:middle;cursor:pointer; border:0px;"></a>&nbsp;';
	$strHTML .= '<a href="javascript:" onClick="return cxDeleteImage(\'' . $list['page_id'] . '\')"><img id="' . $list['page_id'] . '__image_del" src="' . RPW . '/admin/images/btn/btn_del_mini.gif" width="60" height="20" alt="削除する" border="0" style="margin:0px;padding:0px;vertical-align:middle;cursor:pointer;border:0px;"></a>';
	$strHTML .= '<input type="hidden" name="' . $list['page_id'] . '__image_path" id="' . $list['page_id'] . '__image_path" value="' . $list['image_path'] . '">';
	$strHTML .= '<input type="hidden" name="' . $list['page_id'] . '__image_alt" id="' . $list['page_id'] . '__image_alt" value="' . $list['image_alt'] . '">';
	$strHTML .= '</td>' . "\n";
	$strHTML .= '</tr>' . "\n";

}
$strHTML .= '</table>' . "\n";

if (count($listAry) == 0) {
	$strHTML = '<table width="100%" style="margin-top:10px;margin-bottom:10px;margin-left:0px;padding:8px;position:relative;background-color:#FFFFCC;border:solid 1px" border="0"  cellspacing="0" cellpadding="0"><tr><td>' . htmlspecialchars($dat['name']) . '</td></tr></table>';
	$strHTML .= '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">' . "\n";
	$strHTML .= '<tr><td>対象のページは存在しません。</td></tr>' . "\n";
	$strHTML .= '</table>' . "\n";
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>カテゴリ別表示順設定画面</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
			<!--
				<?php
				echo loadSettingVars();
				?>
			//-->
		</script>
<script type="text/javascript">
			<!--
			/**
			 * 画像のアップロード
			 *
			 */
			function cxUploadImage(page_id){
				value = $F(page_id+'__image_path')+KANKO_LINK_DELIMITER+$F(page_id+'__image_alt');
				value = value.replace("#","＃");
				value = encodeURIComponent(value);
				prm = "id="+page_id+"&value="+value;
				var retObj = new Object();
				prm += "&size=1000";
				//ダイアログの表示
				cxIframeLayer(
					cms8341admin_path + "/page/common/autolink/image.php?" + prm,
					630,
					660,
					COVER_SETTING.COLOR,
					'',
					function (retObj) {
						if(retObj== undefined) return;
						tmpAry = retObj['ret'].split(KANKO_LINK_DELIMITER);
						tmpAry[1] = tmpAry[1].replace("＃","#");
						path = tmpAry[0];
						alt = tmpAry[1];
						var img_path = (baseUrl + path).replace(/\/+/g,'/');
						cxPreImages(img_path);
						$(page_id+'__image_area').innerHTML = '<img src="' + img_path + '?rnd=' + parseInt((Math.random() * 10000) + 1) + '" alt="' + alt + '">';
						$(page_id+'__image_del').src = RPW + '/admin/images/btn/btn_del_mini.gif';
						$(page_id+'__image_path').value = tmpAry[0];
						$(page_id+'__image_alt').value = tmpAry[1];
					}
				);
			}
			
			/**
			 * 画像の削除
			 *
			 */
			function cxDeleteImage(page_id){
				if($(page_id+'__image_path').value == "") return;
				$(page_id+'__image_area').innerHTML = '';
				$(page_id+'__image_path').value = '';
				$(page_id+'__image_alt').value = '';
			}
			
			/**
			 * 設定ボタンを押した時の処理
			 * @return 登録処理に成功した場合は、true。それ以外の場合はfalseを返す
			 */
			function cx_Submit(){
				order_ary = new Array();
				isError = false;
				var nodes = Form.getInputs($('form'),'text');
				$A(nodes).each( function(obj) { 
									if(obj.id.indexOf("__sort_order") == -1) return;
									if($F(obj.id) == "") return;
									if($F(obj.id).match(/\D/)) {
										alert("表示順には半角数字を入力してください。");
										isError = true;
										return;
									}
									for(i=0;i<order_ary.length;i++){
										if($F(obj.id) == order_ary[i]){
											alert("表示順に重複している値が存在します。");
											isError = true;
											return;
										}
									}
									order_ary.push($F(obj.id));
								} ); 
				if(isError) return false;
				if($('public').checked){
					if(!confirm("この自動リンクを使用しているページの再公開を行います。\nよろしいですか？")){
						return false;
					}
				}
				$('form').submit();
				return false;
			}

			/**
			 * 初期化
			 */
			function cxInit(){
			}
			
			// イベント監視
			Event.observe(window,'load',cxInit,false);
			
			//-->
		</script>
</head>
<body id="cms8341-mainbg">
		<?php
		// ヘッダーメニュー挿入
		$headerMode = 'autolink';
		include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
		?>
		<form id="form" class="cms8341-form" name="form"
	action="./list_submit.php" method="post"><input type="hidden" id="mode"
	name="mode" value="<?=$mode?>"> <input type="hidden" id="cms_a_link_id"
	name="cms_a_link_id" value="<?=$a_link_id?>">
<div align="center" id="cms8341-contents">
<div style="width:920px;text-align:left;background:url(<?=RPW?>/admin/page/autolink/images/tab_bg.jpg) bottom repeat-x;">
<table border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="240"><a
			href="list.php?a_link_id=<?=$a_link_id?>&mode=public"><img
			src="images/tab_publiclist.jpg" alt="表示ページリスト" width="240"
			height="25" border="0"></a></td>
		<td width="5"><img src="images/tab_bg.jpg" alt="" width="5"
			height="25"></td>
		<td width="240"><a
			href="list.php?a_link_id=<?=$a_link_id?>&mode=close"><img
			src="images/tab_closelist.jpg" alt="非表示ページリスト" width="240"
			height="25" border="0"></a></td>
	</tr>
</table>
</div>
<div style="width:918px;border:solid 1px #CCCCCC;border-top:none;background-color:<?=$bg_color?>;"><img
	src="<?=RPW?>/admin/images/spacer.gif" width="1" height="8" alt=""></div>
<?php
if ($is_lock) {
	?>
<div class="cms8341-areamessage" id="cms8341-denaillist-msg">
現在アップロード処理中のため即公開を行うことができません。<br>
即公開を行う場合はしばらく時間をおいてから再度お試しください。</div>
<?php
}
?>
<div class="cms8341-area-corner"><span id="data_area"><?=$strHTML?></span>
					<?php
					if (count($listAry) > 0) {
						?>
					<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="200" align="left" valign="top" scope="row">公開設定</th>
		<td align="left" valign="top" scope="row"><input type="checkbox"
			id="public" name="public" value="<?=FLAG_ON?>"
			<?=($is_lock ? " disabled" : "")?>><label for="public">即公開する</label></td>
	</tr>
</table>
					<?php
					}
					?>
					<div align="center">
						<?php
						if (count($listAry) > 0) {
							?>
						<a href="javascript:void(0)" onClick="return cx_Submit()"><img
	src="<?=RPW?>/admin/images/btn/btn_set.jpg" width="100" height="20"
	alt="設定する" border="0" style="margin: 10px"></a>
						<?php
						}
						?>
						<a href="index.php"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel.jpg" width="101" height="21"
	alt="キャンセル" border="0" style="margin: 10px"></a></div>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents --></form>
</body>
</html>
