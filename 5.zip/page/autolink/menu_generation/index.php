<?php
/*
 * メニュー生成順変更画面
 *
 * $Rev $
 * $Date $
 * $Author $
 */
?>
<?php

/*--- 設定ファイル読み込み ---*/
require ("../.htsetting");
require_once (APPLICATION_ROOT . "/common/dbcontrol/commands.inc");
//SESSION削除
unset($_SESSION['menu_generation_order']);
//初期表示
$html_str = cxGetMenuGenerationOrder('');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>メニュー生成順変更</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<link rel="stylesheet" href="./menu_generation.css" type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="./menu_generation.js" type="text/javascript"></script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'autolink';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<div id="cms8341-contents">
<div align="center">
<div><img src="images/bar_menu_generation.jpg" alt="メニュー生成順変更" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<p align="right"><a href="./export.php"><img
	src="images/btn_menu_generation_export.jpg" alt="エクスポート" width="100"
	height="20" border="0"></a> <a href="./import.php"><img
	src="images/btn_menu_generation_import.jpg" alt="インポート" width="100" height="20"
	border="0"></a></p>
<form name="cms_sTreeList" class="cms8341-form" method="post"
	action="./submit.php">
<div id="cms_menu_generation_top">
					<?=$html_str?>
				</div>
</form>
<p align="center"><a href="javascript:void(0)"
	onClick="return menu_generation_submit()"><img
	src="<?=RPW?>/admin/images/btn/btn_set.jpg" width="100" height="20"
	alt="設定する" border="0" style="margin: 10px"></a> <a
	href="javascript:void(0)" onClick="return menu_generation_cancel()"><img
	src="./images/btn_back.jpg" width="100" height="20" alt="元に戻す"
	border="0" style="margin: 10px"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
</body>
</html>