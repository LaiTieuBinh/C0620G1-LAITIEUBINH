<?php
/*
 * メニュー生成順更新
 *
 * $Rev $
 * $Date $
 * $Author $
 */
?>
<?php

/* 設定ファイル */
require ("../.htsetting");
/* DB */
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
/* POST値チェック */
if (!isset($_POST['cms_menu_generation_value'])) {
	DispError("不正なパラメータです。", 'autolink', "javascript:history.back()", MENU_KIND_PAGE);
	exit();
}

/* 変数 */
$order_ary = $_POST['cms_menu_generation_value']; //POST値格納
$session = (isset($_SESSION['menu_generation_order'])) ? $_SESSION['menu_generation_order'] : array(); //SESSION値格納
$sort_ary = array(); //DB更新用配列


//キーの昇順でソート(親ページから処理をしていくため)
ksort($order_ary, SORT_STRING);
ksort($session, SORT_STRING);

//ポスト値から変更の必要があるデータの変更を行う
foreach ($order_ary as $parent_order => $data) {
	//値の変更
	$sort_data = menu_generation_order_sort($data);
	//変更されていない値を削除する。
	$sort_data = array_diff_assoc($sort_data, $data);
	//格納 (key => 変更前ID,　値 => ページIDと変更後ID)で格納していく。
	foreach ($data as $page_id => $menu_generation_order) {
		//値が変更されていたら入替
		if (isset($sort_data[$page_id])) $sort_ary[$data[$page_id]] = array(
				'page_id' => $page_id, 
				'menu_generation_order' => $sort_data[$page_id]
		);
	}
}
//セッション値から変更の必要のあるデータの変更を行う
foreach ($session as $parent_order => $data) {
	//POST値で送られてきているデータは処理しない
	if (isset($order_ary[$parent_order])) continue;
	//値の変更
	$sort_data = menu_generation_order_sort($data);
	//変更されていない値を削除する。
	$sort_data = array_diff_assoc($sort_data, $data);
	//格納 (key => 変更前ID,　値 => ページIDと変更後ID)で格納していく。
	foreach ($data as $page_id => $menu_generation_order) {
		//値が変更されていたら入替
		if (isset($sort_data[$page_id])) $sort_ary[$data[$page_id]] = array(
				'page_id' => $page_id, 
				'menu_generation_order' => $sort_data[$page_id]
		);
	}
}
//トラン開始
$objCnc->begin();
//DBのデータから変更の必要があるデータの変更を行う
foreach ($sort_ary as $old_order => $data) {
	//DBから子ページをすべて取得
	$child_page_ary = get_child_page($data['page_id']);
	//変換して、更新配列に格納する。
	foreach ($child_page_ary as $page_data) {
		$sort_ary[$page_data['menu_generation_order']]['page_id'] = $page_data['page_id'];
		$sort_ary[$page_data['menu_generation_order']]['menu_generation_order'] = preg_replace("/^" . $old_order . "/", $data['menu_generation_order'], $page_data['menu_generation_order']);
	}
}
//DB更新
$err_flg = FALSE;
foreach ($sort_ary as $menu_generation_order => $upd_ary) {
	//ページがすでに存在しない
	if ($objPage->selectFromID($upd_ary['page_id'], PUBLISH_TABLE, 'menu_generation_order') === FALSE) $err_flg = TRUE;
	//表示順が変更されている。
	if ($objPage->fld['menu_generation_order'] != $menu_generation_order) $err_flg = TRUE;
	//更新
	if (!$err_flg && $objPage->update($upd_ary, WORK_TABLE) === TRUE && $objPage->update($upd_ary, PUBLISH_TABLE) === TRUE) {
		continue;
	}
	$objCnc->rollback();
	DispError("ページの更新に失敗しました。", 'autolink', "javascript:history.back()", MENU_KIND_PAGE);
	exit();
}
//コミット
$objCnc->commit();

header("Location: " . HTTP_ROOT . RPW . "/admin/page/autolink/menu_generation/index.php");
exit();
/**
 * 配列の格納順を基準に値の昇順に入れ替えを行う
 * @param $ary 対象配列
 * @return 変更された配列
 * 【例】
 * 	   param		　return
 * 	[b] => 1002		[b] => 1001
 * 	[a] => 1001		[a] => 1002
 * 	[c] => 1003		[c] => 1003
 */
function menu_generation_order_sort($ary) {
	//キー
	$key = array_keys($ary);
	//昇順にソート
	sort($ary, SORT_STRING);
	//値
	$val = array_values($ary);
	//キーと値で新しい配列作成
	return array_combine($key, $val);
}
/**
 * 子ページ情報をすべて取得する
 * @param $id ページID
 * @return ページ情報配列
 *
 */
function get_child_page($page_id) {
	//データアクセスクラス
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
	$objPage = new tbl_page($objCnc);
	//戻り値
	$ret = array();
	//ファイルパス取得
	if (!$objPage->selectFromID($page_id, PUBLISH_TABLE, 'file_path')) return $ret;
	//子ページ情報取得
	$where = "ancestor_path REGEXP '^(.*,)?" . $objPage->fld['file_path'] . "(,.*)?$'";
	$objPage->select($where, 'page_id,menu_generation_order', 'menu_generation_order ASC');
	while ($objPage->fetch())
		$ret[] = $objPage->fld;
	return $ret;
}
?>