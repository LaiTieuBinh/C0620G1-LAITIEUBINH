<?php
/*
 * メニュー生成順情報のインポート実行)
 * $Rev: 539 $
 * $Date: 2010-02-03 10:43:51 +0900 (水, 03 2 2010) $
 * $Author: kawarazaki $
 */
?>
<?php

//--- 設定ファイル読み込み
require ("../.htsetting");
//csvファイル最大行
define("G_CSV_MAX_LINE", 20000);

define("THROUGH", 0); // スルー
define("CHECK", 1); // チェック


$column_ary['menu_generation_order'] = array(
		"no" => 0, 
		"need" => CHECK, 
		'name' => "メニュー生成順"
);
$column_ary['file_path'] = array(
		"no" => 1, 
		"need" => CHECK, 
		'name' => "ファイルパス"
);
//$column_ary['page_title']		= array("no"=>2, "need"=>THROUGH,'name'=>"ページタイトル");


//---引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError("インポートをするcsvファイルを指定してください。", 'autolink', "javascript:history.back()", MENU_KIND_PAGE);
	exit();
}
// 拡張子チェック
$sExtension = substr($frmCsvFnm, (strrpos($frmCsvFnm, '.') + 1));
$sExtension = strtolower($sExtension);
if ($sExtension != "csv") {
	DispError("csvファイルを指定してください。", 'autolink', "javascript:history.back()", MENU_KIND_PAGE);
	exit();
}
//---ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError("csvファイルのファイルサイズが0バイトです。", 'autolink', "javascript:history.back()", MENU_KIND_PAGE);
	exit();
}

//ディレクトリの作成
$tmpUpFile = DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/' . $frmCsvFnm;
if (!mkNewDirectory($tmpUpFile)) {
	DispError("csvファイルのアップロードフォルダの作成に失敗しました。", 'autolink', "javascript:history.back()", MENU_KIND_PAGE);
	exit();
}

//---アップロード
if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $tmpUpFile) == FALSE) {
	DispError("csvファイルのアップロードに失敗しました。", 'autolink', "javascript:history.back()", MENU_KIND_PAGE);
	exit();
}
//(念のため)ファイル存在チェック
if (file_exists($tmpUpFile) == FALSE) {
	$wk_str = "指定されたファイル【" . $tmpUpFile . "】が存在しません。";
	DispError($wk_str, 'autolink', "javascript:history.back()", MENU_KIND_PAGE);
	exit();
}

//データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

// CSVファイルをUTF-8として読み込む
$CsvFno = csvRead_UTF8($tmpUpFile);

//一行目は飛ばす
$data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE);

// トランザクション開始
$objCnc->begin();

//EOFになるまで読み出し
$err_msg = "";
$line = 1;
$upd_ary = array();
while ($data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
	$line++;
	//各項目の必須チェック
	if (check_item($data, $column_ary, $line, $err_msg) === FALSE) continue;
	//DB更新用の配列に格納
	$upd_ary[] = create_upd_ary($data, $column_ary);
}
//エラー出力
if ($err_msg != "") disp_err($err_msg, $objCnc, $CsvFno, $tmpUpFile);
//メニュー生成順のチェック
if (check_menu_generation_order($upd_ary, $err_msg) === FALSE) disp_err($err_msg, $objCnc, $CsvFno, $tmpUpFile);
//DB更新
exec_upd($upd_ary);
// コミット
$objCnc->commit();
//表示順変更画面に戻る
header("Location: " . HTTP_ROOT . RPW . "/admin/page/autolink/menu_generation/index.php");
exit();

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/**
 * 項目の必須チェックを行う
 * @param $data       １行分のCSV内容
 * @param $column_ary 項目の配列
 * @param $line       読み込み行番号
 * @param $err_msg    エラーメッセージ
 * @return TRUE:FALSE
 * 
 */
function check_item(&$data, $column_ary, $line, &$err_msg) {
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
	$objPage = new tbl_page($objCnc);
	foreach ($column_ary as $column => $info) {
		//チェックなし
		if ($info["need"] == THROUGH) continue;
		//必須チェック
		if (!isset($data[$info["no"]]) || $data[$info["no"]] == "") {
			$err_msg .= $info["name"] . "が指定されていないデーターが存在します。【" . $line . "行目】<br>";
		}
		//ファイルパスの場合ページの存在チェック
		if ($column != "file_path") continue;
		if ($objPage->selectFromPath($data[$info["no"]]) === FALSE) {
			$err_msg .= "存在しないファイルパスが指定されています。【" . $line . "行目】<br>";
			//ページID格納
		}
		else {
			$data[$info["no"]] = $objPage->fld["page_id"];
		}
	}
	return ($err_msg == "") ? TRUE : FALSE;
}
/**
 * メニュー生成順のチェックを行う
 * @param $upd_ary 		挿入用配列
 * @param $err_msg    	エラーメッセージ
 * @return TRUE:FALSE
 * 
 */
function check_menu_generation_order($upd_ary, &$err_msg) {
	
	// データアクセスクラス
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
	$objPage = new tbl_page($objCnc);
	
	//挿入用配列からチェック用配列を作成する。
	$check_ary = array();
	foreach ($upd_ary as $line => $data) {
		$check_ary[$data['page_id']] = $data['menu_generation_order'];
	}
	//重複のチェック
	$repetition_ary = get_not_unique(array_values($check_ary));
	foreach ($repetition_ary as $val) {
		$err_msg .= "重複しているメニュー生成順が存在します。【" . htmlDisplay($val) . "】<br>";
		return FALSE;
	}
	//メニュー生成順のチェックを行う
	$select = 'p.page_id,p.menu_generation_order';
	$table = "tbl_publish_page AS p" . " INNER JOIN tbl_user AS u ON (u.user_id = p.user_id)";
	//指定ページ分ループ
	foreach ($check_ary as $page_id => $menu_generation_order) {
		//ページ情報取得
		if ($objPage->selectFromID($page_id, PUBLISH_TABLE, 'parent_id, menu_generation_order') === FALSE) {
			$err_msg .= "ページ情報の取得に失敗しました。【" . htmlDisplay($page_id) . "】<br>";
			continue;
		}
		//変更がない場合スキップ
		if ($objPage->fld['menu_generation_order'] == $menu_generation_order) continue;
		//桁数のチェック
		if (strlen($objPage->fld['menu_generation_order']) != strlen($menu_generation_order)) {
			$err_msg .= "指定されたメニュー生成順の桁数が一致しません。【" . htmlDisplay($menu_generation_order) . "】<br>";
			continue;
		}
		//親ページの指定がない場合は親ページの情報部分の変更はできない。
		$parent_id = $objPage->fld['parent_id'];
		if (!isset($check_ary[$parent_id])) {
			if (substr($objPage->fld['menu_generation_order'], 0, 0 - MENU_GENERATION_ORDER_DIGIT) != substr($menu_generation_order, 0, 0 - MENU_GENERATION_ORDER_DIGIT)) {
				$err_msg .= "指定されたメニュー生成順の指定が正しくありません。【" . htmlDisplay($menu_generation_order) . "】<br>";
				continue;
			}
			//親ページ情報と比較
		}
		else {
			$len = strlen($check_ary[$parent_id]);
			if ($check_ary[$parent_id] != substr($menu_generation_order, 0, $len)) {
				$err_msg .= "指定されたメニュー生成順が親ページのメニュー生成順と一致しません。【" . htmlDisplay($menu_generation_order) . "】<br>";
				continue;
			}
		}
		//子ページ情報取得
		$where = $objPage->_addslashesC('p.parent_id', $page_id);
		$objPage->select($where, $select);
		while ($objPage->fetch()) {
			$fld = $objPage->fld;
			//親ページが指定されていて子ページの指定が存在しない。
			if (!isset($check_ary[$fld['page_id']])) {
				$err_msg .= "親ページのメニュー生成順を変更する場合は、子ページのメニュー生成順も変更してください。【" . htmlDisplay($page_id) . "】<br>";
				break;
			}
		}
	}
	return ($err_msg == "") ? TRUE : FALSE;
}

/**
 * 挿入用の配列を作成する
 * @param $data       １行分のCSV内容
 * @param $column_ary 項目の配列
 * @return 挿入用の配列
 * 
 */
function create_upd_ary($data, $column_ary) {
	$ary = array();
	$ary['page_id'] = $data[$column_ary['file_path']['no']];
	$ary['menu_generation_order'] = $data[$column_ary['menu_generation_order']['no']];
	return $ary;
}
/**
 * 配列の重複している要素を取得する
 * @param $ary    配列
 * @return 重複している要素の配列
 * 
 */
function get_not_unique($ary) {
	//リターン値
	$ret = array();
	//値の数をカウント
	$v_cnt_ary = @array_count_values($ary);
	//重複している値をリターン配列に格納
	foreach ($v_cnt_ary as $val => $cnt) {
		if ($cnt == 1) continue;
		$ret[] = $val;
	}
	return $ret;
}
/**
 * サイトマップ情報を更新する
 * @param $upd_ary   挿入用の配列
 * 
 */
function exec_upd($upd_ary) {
	// データアクセスクラス
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
	$objPage = new tbl_page($objCnc);
	
	// DBへ登録
	foreach ($upd_ary as $ary) {
		//更新（編集ページ）（公開ページ）
		if ($objPage->update($ary, WORK_TABLE) === TRUE && $objPage->update($ary, PUBLISH_TABLE) === TRUE) continue;
		//失敗
		disp_err("メニュー生成順情報の更新に失敗しました。", $objCnc);
	}
}
/**
 * エラー画面表示
 */
function disp_err($err_msg, $objCnc, $CsvFno = NULL, $frmCsvFnm = NULL) {
	// ロールバック
	$objCnc->rollback();
	// ファイルClose
	if ($CsvFno !== NULL) fclose($CsvFno);
	// ファイルを削除
	if ($CsvFno !== NULL) unlink($frmCsvFnm);
	// エラーページの表示
	DispError($err_msg, 'autolink', "javascript:history.back()", MENU_KIND_PAGE);
	exit();
}

?>
