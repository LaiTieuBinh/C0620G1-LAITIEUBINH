/*
 * メニュー生成順変更用JS
 *
 * $Rev:  $
 * $Date:  $
 * $Author:  $
 */

//dragdrop.js
Sortable.destroy = function(element){
    element = $(element);
	var s = Sortable.sortables[element.id];
    if(s) {
      Draggables.removeObserver(s.element);
      s.droppables.each(function(d){ Droppables.remove(d) });
      s.draggables.invoke('destroy');
      
      delete Sortable.sortables[s.element.id];
    }
}


//画像先読み
var img_plus = cms8341admin_path+'/master/images/dir_plus.jpg';
var img_minus = cms8341admin_path+'/master/images/dir_minus.jpg';
cxPreImages(img_plus,img_minus);

//ドラッグ＆ドロッププロパティ
var dragdrop_op = {tag: 'div'};

//ドラッグ＆ドロップ処理追加
Event.observe(window,'load',function(){ Sortable.create("cms_menu_generation_top", dragdrop_op ); });
//DIVの幅調整
Event.observe(window,'load',function(){ set_div_width($('cms_menu_generation_top')); });
/**
 * リスト表示/非表示
 * @param id 対象のエレメントの識別ID(ページID)
 */
function cxOpenList(id){
	//非表示
	if($('cms_menu_generation_' + id).style.display != 'none'){
		cxCloseList(id);
		$('cms_menu_generation_' + id).innerHTML = '処理中...';
		return false;
	}
	//表示
	var prm = "page_id=" + id;
	var onSuccess = function(r){
						var rText = r.responseText;
						$('cms_menu_generation_' + id).innerHTML = rText;
						set_div_width($('cms_menu_generation_' + id));
						Sortable.create("cms_menu_generation_" + id, dragdrop_op );
					};
	//ajax
	cxAjaxCommand('cxGetMenuGenerationOrder', prm, onSuccess);
	$('cms_icon_' + id).src = img_minus;
	$('cms_menu_generation_' + id).innerHTML = '読み込み中...';
	$('cms_menu_generation_' + id).style.display = 'block'; 
	return false;
}
/**
 * リスト非表示 セッションに値を格納
 * @param id 対象のエレメントの識別ID(ページID)
 */
function cxCloseList(id){
	var prm = get_menu_generation_info(id);
	prm = prm.slice(0 , -1);
	var onSuccess = function(){
						$('cms_icon_' + id).src = img_plus;
						$('cms_menu_generation_' + id).style.display = 'none';
						$('cms_menu_generation_' + id).innerHTML = '';
						Sortable.destroy($('cms_menu_generation_' + id));
					};
	cxAjaxCommand('cxSetMenuGenerationOrder', prm, onSuccess);
	return false;
}
/**
 * リストで開いているデータの取得
 * @param id 対象のエレメントの識別ID(ページID)
 * 【備考】
 *  id以下の開いているページの情報をすべて取得する。
 */
function get_menu_generation_info(id){
	var ele = document.getElementsByName("cms_ses_" + id);
	if(!ele || ele.length < 2) return '';
	var str = '';
	var child_str = '';
	for(var i=0; i < ele.length; i++){
		child_str += get_menu_generation_info(ele[i].getAttribute('_id'));
		str += 'menu_generation_info[' + id + '][' + ele[i].getAttribute('_id') + ']=' + ele[i].getAttribute('_order') + '&';
	}
	return str + child_str;
}
//ajax失敗処理
function cxFailure() {
	alert('情報通信中にエラーが発生しました。');
}
/**
 * DIVの横幅を調整する。
 * @param ele 子要素挿入領域のエレメント
 */
function set_div_width(ele){
	var target = document.getElementsByClassName("cms8341-menu_generationlist", ele);
	target.each( function(val){
		val.style.width = document.getElementsByClassName("cms8341-menu_generationlist-inline",val)[0].offsetWidth;
	});
}
/**
 * 元に戻すボタン押下時
 */
function menu_generation_cancel(){
	if (!confirm("変更中のメニュー生成順を元に戻します。\nよろしいですか？")) {
		return false;
	}
	cms_sTreeList.action = './index.php';
	cms_sTreeList.submit();
	return false;
}
/**
 * 設定するボタン押下時
 */
function menu_generation_submit(){
	if (!confirm("メニュー生成順を更新します。\nよろしいですか？")) {
		return false;
	}
	cms_sTreeList.action = './submit.php';
	cms_sTreeList.submit();
	return false;
}