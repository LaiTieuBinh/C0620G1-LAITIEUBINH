<?php
/*
 * メニュー生成順情報のエクスポート
 * $Rev: 539 $
 * $Date: 2010-02-03 10:43:51 +0900 (水, 03 2 2010) $
 * $Author: kawarazaki $
 */
?>
<?php

//設定ファイル読み込み
require ("../.htsetting");
//データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage->setTableName(PUBLISH_TABLE);
//取得カラム => 見出し文字
$set_ary = array(
		"menu_generation_order" => "メニュー生成順", 
		"file_path" => "ファイルパス", 
		"page_title" => "ページタイトル"
);

//見出し文字
$head_ary = array_values($set_ary);
//取得カラム
$column_ary = array_keys($set_ary);

//ページ情報取得 ---▼
$order_by = 'menu_generation_order ASC';
$objPage->select('', implode(',', $column_ary), $order_by);
//出力データの作成
$csv_data_ary = array();
while ($objPage->fetch()) {
	$csv_data_ary[] = $objPage->fld;
}
//CSV出力処理
create_Csv("menu_generation_order.csv", $csv_data_ary, $head_ary, 0, "", "utf-8", "\"");
?>
