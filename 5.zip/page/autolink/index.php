<?php
/*
 *
 */
// ** require -------------------------------
require ("../.htsetting");
require ("include/autolinkCommonFunc.inc");

// ** global 宣言 ---------------------------
global $objCnc;
global $objLogin;

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

// ** 定数 ----------------------------------
define("G_CATE_LEVEL01", 1); //第1分類
define("G_CATE_LEVEL02", 2); //第2分類
define("G_CATE_LEVEL03", 3); //第3分類
define("G_CATE_LEVEL04", 4); //第4分類


// スタイル
$CATE_CSS_CLASS = array(
		G_CATE_LEVEL01 => "dir_first", 
		G_CATE_LEVEL02 => "dir_second", 
		G_CATE_LEVEL03 => "dir_third", 
		G_CATE_LEVEL04 => "dir_fourth"
);

// POST
if ($_SERVER['REQUEST_METHOD'] == "POST") {
	$CATE_SELECT = (isset($_POST['cate_code'])) ? $_POST['cate_code'] : "";
	$CATE_SELECT_LEVEL = (isset($_POST['cate_level'])) ? $_POST['cate_level'] : 1;
	// GET
}
else {
	$CATE_SELECT = (isset($_GET['cate_code'])) ? $_GET['cate_code'] : "";
	$CATE_SELECT_LEVEL = (isset($_GET['cate_level'])) ? $_GET['cate_level'] : 1;
}

// 画像
$CATE_PLUS_IMG = RPW . "/admin/master/images/dir_plus.jpg";
$CATE_MINUS_IMG = RPW . "/admin/master/images/dir_minus.jpg";

// 開く、閉じるのモード
define("PLUS_MODE", FLAG_ON);
define("MINUS_MODE", FLAG_OFF);

// カテゴリ一覧を取得
$objDac->setTableName("tbl_category");
$objDac->select("", "*", "cate_code");

// DB内容取得
$strHTML = "";

// ウェブマスターか、それ以外かを判定するフラグ(true:ウェブマスター)
$web_mst_flg = true;
// ウェブマスター以外の場合で、表示設定が許可された自動リンクの情報を保持する配列
$use_alink_ary = array();
// ウェブマスター以外の場合は、表示設定が許可された自動リンクの情報を取得する
if ($objLogin->get('class') != USER_CLASS_WEBMASTER || $objLogin->get('isOpenUser')) {
	// 表示設定が許可されている自動リンクのa_link_idをキーにした自動リンクの情報を取得する
	$use_alink_ary = getUseAutoLinkList($objLogin->get('user_id'));
	// ウェブマスターではないので、falseを設定する
	$web_mst_flg = false;
}

$str_html_work = '';
createAutolinkListFromAutolink($str_html_work, $use_alink_ary, AUTOLINK_SITE_TOP_CATEGORY);
if($str_html_work != ''){
	// トップの一覧
	$strHTML .= '<img src="images/label_top.gif" class="cms8341-verticalMiddle">';
	$strHTML .= $str_html_work;
}

// カテゴリの一覧
if ($objDac->getRowCount() > 0) {
	while ($objDac->fetch()) {
		$fld = $objDac->fld;
		// DB値
		$level = $fld['level'];
		$cate_code = htmlspecialchars($fld['cate_code']);
		$name = htmlDisplay($fld['name']);
		
		if ($CATE_SELECT_LEVEL < $level) continue;
		if ($CATE_SELECT != "") {
			if (substr($CATE_SELECT, 0, 3 * ($level - 1)) != substr($cate_code, 0, 3 * ($level - 1))) continue;
		}
		
		// style
		$css_cls = (isset($CATE_CSS_CLASS[$level])) ? $CATE_CSS_CLASS[$level] : "dir_first";
		$css_disp = ($level <= $CATE_SELECT_LEVEL) ? $css_disp = "display:block;" : "display:none;";
		// image
		$img = $CATE_PLUS_IMG;
		$mode = PLUS_MODE;
		
		if ($level < $CATE_SELECT_LEVEL && substr($CATE_SELECT, 0, 3 * $level) == substr($cate_code, 0, 3 * $level)) {
			$img = $CATE_MINUS_IMG;
			$mode = MINUS_MODE;
		}
		
		// 余分に表示される項目の削除
		if ($level > G_CATE_LEVEL01 && $level <= $CATE_SELECT_LEVEL && substr($CATE_SELECT, 0, 3 * ($level - 1)) != substr($cate_code, 0, 3 * ($level - 1))) $css_disp = "display:none;";
		if ($level <= $CATE_SELECT_LEVEL && substr($CATE_SELECT, 0, 3 * ($level - 1)) != substr($cate_code, 0, 3 * ($level - 1))) $css_disp = "display:none;";
		
		// ウェブマスター以外の場合は、表示設定が許可された自動リンクの分類コードを取得し、
		// 表示設定が許可された分類のみ、画面に表示する
		if($web_mst_flg == false){
			// 表示設定が許可された自動リンクの分類コード全て取得する。
			// (現在処理中の分類コードのレベルに応じた長さに、分類コードをsubstrしている)
			$use_cate_code_level_ary = getUseAutoLinkCateCodeLvl($use_alink_ary, $level);
			// 表示設定が許可された自動リンクの分類コードの、上位の分類は画面に表示し、
			// それ以外は、画面に表示しない
			if(!in_array(substr($cate_code, 0, 3 * $level), $use_cate_code_level_ary)){
				continue;
			}
		}
		
		// html表記の作成
		$strHTML .= "<p align=\"left\" class=\"" . $css_cls . "\" style=\"" . $css_disp . "\">";
			
		if ($level < G_CATE_LEVEL04) {
			$strHTML .= "<a href=\"javascript:\" onClick=\"return cxShow('" . $cate_code . "'," . $level . ",'" . $mode . "')\">";
			$strHTML .= "<img src=\"" . $img . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\">";
			$strHTML .= "</a>";
		}
		else {
			$strHTML .= "<img src=\"" . RPW . "/admin/master/images/dir_none.jpg\" alt=\"\" width=\"60\" height=\"20\" border=\"0\">";
		}
			
		// 分類名
		$strHTML .= $name;
		// 一覧ページ作成へのボタン
		createAutolinkListFromAutolink($strHTML, $use_alink_ary, $cate_code, $level);
		$strHTML .= "</p>" . PHP_EOL;
	}
}

$str_html_work = '';
createAutolinkListFromAutolink($str_html_work, $use_alink_ary);
if($str_html_work != ''){
	// そのたの一覧
	$strHTML .= '<hr>';
	$strHTML .= $str_html_work;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>自動リンク一覧</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<style>
<!--
#cms8341-categories p {
	margin: 12px 0px;
}

.dir_first {
	padding-left: 5px;
}

.dir_second {
	padding-left: 65px;
}

.dir_third {
	padding-left: 125px;
}

.dir_fourth {
	padding-left: 150px;
}
//
-->
</style>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/faq/js/common.js"
	type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

function cxCreate(behavior, cate_code, a_link_id ) {

	$('behavior').value  = behavior;
	$('cate_code').value  = cate_code;
	if(a_link_id) $('a_link_id').value = a_link_id;
	$('cms_fCateList').action = 'form.php';
	$('cms_fCateList').target = '_self';
	$('cms_fCateList').submit();

	return false;

}
function cxConfirm(behavior, cate_code, a_link_id ) {

	$('behavior').value  = behavior;
	$('cate_code').value  = cate_code;
	if(a_link_id) $('a_link_id').value = a_link_id;
	$('cms_fCateList').action = 'confirm.php';
	$('cms_fCateList').target = '_self';
	$('cms_fCateList').submit();

	return false;

}

PLUS_MODE  = "<?=PLUS_MODE?>";
MINUS_MODE = "<?=MINUS_MODE?>";
function cxShow( cate_code, level, mode ) {

	$('cate_code').value  = cate_code;
	if ( mode == PLUS_MODE ) {
		$('cate_level').value = level + 1;
	} else if ( mode == MINUS_MODE ) {
		$('cate_level').value = level;
	}
	$('cms_fCateList').action = 'index.php';
	$('cms_fCateList').target = '_self';
	$('cms_fCateList').submit();

	return false;

}

function cxList(a_link_id){
	if(a_link_id) $('a_link_id').value = a_link_id;
	$('cms_fCateList').action = 'list.php';
	$('cms_fCateList').target = '_self';
	$('cms_fCateList').submit();

	return false;
}

//-->
</script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'autolink';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
	<div align="center" id="cms8341-contents">
<div><img src="images/bar_autolink.jpg" alt="自動リンク設定" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<div class="cms8341-categories">
<form name="cms_fCateList" id="cms_fCateList" class="cms8341-form"
	method="post" action=""><input type="hidden" id="cate_code"
	name="cate_code" value=""> <input type="hidden" id="cate_level"
	name="cate_level" value=""> <input type="hidden" id="a_link_id"
	name="a_link_id" value=""> <input type="hidden" id="behavior"
	name="behavior" value="">
<?=$strHTML?>
				</form>
</div>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents -->
</body>
</html>