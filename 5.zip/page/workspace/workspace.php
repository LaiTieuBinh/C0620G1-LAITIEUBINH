<?php
/*
 * ワークスペース
 */

require ("../.htsetting");

// 戻り先設定
$_SESSION['back_path'] = $_SERVER['SCRIPT_NAME'];

$login = $objLogin->login;
if ($login['class'] != USER_CLASS_WRITER || $login['isRegain'] == TRUE) {
	user_error('不正アクセスです。');
}

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage2 = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_approve_handler.inc');
$objAppHandler = new tbl_approve_handler($objCnc);

$menu_no = 0;

// （承認依頼）公開期間の初期値
$Y = date('Y');
$n = date('n');
$j = date('j');

$eY = date('Y', strtotime("+" . PUBLISH_END_MONTH . " month"));
$en = date('n', strtotime("+" . PUBLISH_END_MONTH . " month"));
$ej = date('j', strtotime("+" . PUBLISH_END_MONTH . " month"));

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ワークスペース</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/workspace.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/workspace.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>

</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'workspace';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<form name="cms_CMenu" class="cms8341-form" id="cms_CMenu" method="post"
	action="" target=""><input type="hidden" name="cms_preview_color"
	id="cms_preview_color" value="" disabled> <input type="hidden" name="cms_dispMode"
	id="cms_dispMode" value=""> <input type="hidden" name="cms_page_id"
	id="cms_page_id" value=""> <input type="hidden" name="cms_unuse_delete"
	id="cms_unuse_delete" value=""></form>
<form name="cms_fAppreq" class="cms8341-form" id="cms_fAppreq"
	method="post" action="<?=RPW?>/admin/page/common/approverequest.php"><input
	type="hidden" name="cms_approve_id" id="cms_approve_id" value="">
<div align="center" id="cms8341-contents">
<div><img src="<?=RPW?>/admin/images/workspace/bar_workspace.jpg"
	alt="ワークスペース" width="920" height="30"></div>
<?php
// 作業中ページ情報を取得
$objPage->selectWorkspace($login['user_id']);
// メッセージ表示（作業中ページあり）
if ($objPage->getRowCount() > 0) {
	print '<div class="cms8341-areamessage">' . "\n";
	print '※作業が完了しているページをグループで承認依頼できます。&nbsp;同一承認フローの中から依頼するページを選択してください。</div>' . "\n";
}
echo '<div class="cms8341-area-corner">' . "\n";
if ($objPage->getRowCount() == 0) { // ▼作業中ページなし
	echo '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable" id="cms8341-workspace">' . "\n";
	echo '<tr><th valign="middle" scope="col" style="font-weight:normal">&nbsp;</th></tr>' . "\n";
	echo '<tr><td align="center" valign="middle">作業中のページはありません。</td></tr>' . "\n";
	echo '</table>' . "\n";
}
else { // ▼作業中ページあり
	$approve_id = '';
	$comp_flg = FALSE;
	while ($objPage->fetch()) {
		if ($objPage->fld['approve_id'] != $approve_id) {
			if ($approve_id != '') print '</table>' . "\n";
			$approve_id = $objPage->fld['approve_id'];
			echo '<p class="approve">' . $objTool->getArrproveFlow($approve_id) . '</p>' . "\n";
			echo '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable" id="cms8341-workspace">' . "\n";
			echo '<tr>' . "\n";
			echo '<th width="80" align="center" valign="middle" scope="col" style="font-weight:normal">状態</th>' . "\n";
			echo '<th width="57" align="center" valign="middle" scope="col" style="font-weight:normal">選択</th>' . "\n";
			echo '<th align="center" valign="middle" scope="col" style="font-weight:normal">タイトル</th>' . "\n";
			echo '</tr>' . "\n";
		}
		$menu_no++;
		$fld = $objPage->fld;
		if ($fld['work_class'] == WORK_CLASS_DELETE) {
			if ($fld['close_flg'] == 1) {
				$status_img = 'icon_close.jpg';
				$status_alt = '非公開';
				$link_mode = 'del';
				$comp_flg = TRUE;
			}
			else {
				$status_img = 'icon_del.jpg';
				$status_alt = '削除';
				$link_mode = 'del';
				$comp_flg = TRUE;
			}
		}
		else {
			$link_mode = 'edit';
			if ($fld['work_class'] == WORK_CLASS_NEW) {
				$status_img = 'icon_new';
				$status_alt = '新規';
			}
			elseif ($fld['work_class'] == WORK_CLASS_PUBLISH) {
				$status_img = 'icon_edit';
				$status_alt = '更新';
			}
			if ($fld['status'] == STATUS_COMP) {
				$status_img .= '_comp.jpg';
				$status_alt .= '完了';
				$comp_flg = TRUE;
			}
			else {
				$status_img .= '_save.jpg';
				$status_alt .= '保存中';
			}
		}
		
		// 否認されたページの場合ボタンを表示(承認依頼されたグループ)
		$denial_btn = '';
		if ($objAppHandler->is_denial_msg($fld['page_id'])) {
			$denial_btn = '<a href="javascript:" onclick="return cxDenialMsg(\'' . $fld['page_id'] . '\')"><img src="' . RPW . '/admin/images/btn/btn_denial_msg.jpg" alt="前回の否認理由" width="80" height="20" class="cms8341-verticalMiddle" border="0"></a>';
		}
		
		$fields = "p.*, w.file_path as w_file_path, w.page_title as w_page_title, w.close_flg AS w_close_flg, w.user_id AS work_user_id, u.dept_code AS dept_code, w.output_html_flg AS w_output_html_flg";
		$where = $objDac->_addslashesC("p.file_path", $fld['file_path']);
		$objDac->setTableName("tbl_publish_page AS p LEFT JOIN tbl_work_page AS w ON (p.page_id = w.page_id) LEFT JOIN tbl_user AS u ON (p.user_id = u.user_id)");
		$objDac->select($where, $fields);
		$objDac->fetch();
		$fld = array_merge($fld, $objDac->fld);
		
		echo '<tr>' . "\n";
		echo '<td width="80" align="center" valign="middle"><img src="' . RPW . '/admin/images/workspace/' . $status_img . '" alt="' . $status_alt . '" width="70" height="25"></td>' . "\n";
		// ▼承認依頼チェックボックスあり（完了）
		if ($fld['status'] == 202) {
			echo '<td align="center" valign="middle"><input type="checkbox" name="cms_page_id[]" value="' . $fld['page_id'] . '"></td>' . "\n";
			// ▼承認依頼チェックボックスなし（保存） 
		}
		else {
			echo '<td width="57" align="center" valign="middle">&nbsp;</td>' . "\n";
		}
		// ▲承認依頼チェックボックス有無 
		echo '<td align="left" valign="top"><p><small>' . setRootPath($objTool->getPankuzu(FLAG_OFF, $fld['template_kind'], $objTool->selectTemplateKankoType($fld['template_id']), $fld['ancestor_path'], '', $login['user_id'], FALSE)) . ' &gt;</small></p>' . "\n";
		echo '<p><a href="javascript:" onClick="return cxContentsMenu2(event, \'cms_menu_' . $menu_no . '\',\'' . $fld['page_id'] . '\',\'cms_CMenu\',\'' . $headerMode . '\')"  onContextMenu="cxContentsMenu2(event, \'cms_menu_' . $menu_no . '\',\'' . $fld['page_id'] . '\',\'cms_CMenu\',\'' . $headerMode . '\');return false;"><span id="cms_page_title_' . $menu_no . '">' . htmlDisplay($fld['w_page_title']) . '</span></a>&nbsp;' . $denial_btn . '</p>' . "\n";
		echo '<div id="cms_menu_' . $menu_no . '" class="cms8341-layer"></div>' . "\n";
		echo '</td>' . "\n";
		echo '</tr>' . "\n";
	}
	// ▲while 
	echo '</table>' . "\n";
	echo '<p align="center"><img src="' . RPW . '/admin/images/icon/icon-flow.jpg" alt="" width="36" height="26"></p>' . "\n";
	// ▼承認依頼ボタン有効 
	if ($comp_flg) {
		echo '<p align="center"><a href="javascript:" onClick="return cxRequestSet()"><img src="' . RPW . '/admin/images/btn/btn_request.jpg" alt="承認依頼" width="150" height="20" border="0"></a></p>' . "\n";
		// ▼承認依頼ボタン無効 
	}
	else {
		echo '<p align="center"><img src="' . RPW . '/admin/images/btn/btn_request_off.jpg" alt="承認依頼" width="150" height="20" border="0"></p>' . "\n";
	}
	// ▲承認依頼ボタン 
}
// ▲作業中ページ有無 
?>
</div>
<!-- cms8341-contents -->
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!--</div>--> <!--***承認依頼レイヤー　　　　 ここから********************************-->
<div id="cms8341-request" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/request/title_request.jpg" alt="承認依頼"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxRequestClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 270px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<table width="440" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable"
			style="border-collapse: collapse; border: solid 1px #CCCCCC;">
			<tr>
				<th width="110" align="left" valign="top" nowrap scope="row"><label
					for="cms_group_name">承認グループ名<br>
				<span class="cms_require">（必須）</span></label></th>
				<td align="left" valign="middle"><input type="text"
					name="cms_group_name" id="cms_group_name" style="width: 300px;"></td>
			</tr>
			<tr>
				<th width="110" align="left" valign="top" nowrap scope="row"><label
					for="cms_note1">依頼内容</label></th>
				<td align="left" valign="top"><textarea name="cms_note1" rows="5"
					id="cms_note1" style="width: 300px;"></textarea></td>
			</tr>

			<tr>
				<th width="110" align="left" valign="top" nowrap scope="row">公開期間<br>
				<span class="cms_require">（必須）</span></th>
				<td align="left" valign="top">
				<p><input type="text" maxlength="4" id="cms_pdsy" name="cms_pdsy"
					value="<?=$Y?>" style="width: 46px; ime-mode: disabled"> 年 <input
					type="text" maxlength="2" id="cms_pdsm" name="cms_pdsm"
					value="<?=$n?>" style="width: 28px; ime-mode: disabled"> 月 <input
					type="text" maxlength="2" id="cms_pdsd" name="cms_pdsd"
					value="<?=$j?>" style="width: 28px; ime-mode: disabled"> 日 <input
					type="text" maxlength="2" id="cms_pdsh" name="cms_pdsh" value="0"
					style="width: 28px; ime-mode: disabled"> 時 <a href="javascript:"
					onClick="return cxCalendarSet('cms_pdsy','cms_pdsm','cms_pdsd','cms_pdsh')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a> から</p>
				<p><input type="text" maxlength="4" id="cms_pdey" name="cms_pdey"
					value="<?=$eY?>" style="width: 46px; ime-mode: disabled"> 年 <input
					type="text" maxlength="2" id="cms_pdem" name="cms_pdem"
					value="<?=$en?>" style="width: 28px; ime-mode: disabled"> 月 <input
					type="text" maxlength="2" id="cms_pded" name="cms_pded"
					value="<?=$ej?>" style="width: 28px; ime-mode: disabled"> 日 <input
					type="text" maxlength="2" id="cms_pdeh" name="cms_pdeh" value="0"
					style="width: 28px; ime-mode: disabled"> 時 <a href="javascript:"
					onClick="return cxCalendarSet('cms_pdey','cms_pdem','cms_pded','cms_pdeh')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a>　まで<br>
<?php
if (USE_INDEFINITE == true) {
	?>
<input name="cms-pubend-Unrestricted-ws" type="checkbox"
					id="cms-pubend-Unrestricted-ws" style="width: 15px" value=""
					onclick="cxPublicEndUnrestricted();"><label
					for="cms-pubend-Unrestricted-ws"><?=PUB_INDEFINITE?></label></p>
<?php
}
?>
</td>
			</tr>

		</table>
		</div>
		</div>
		<p align="center" style="margin: 10px 0px;"><a href="javascript:"
			onClick="return cxRequestSubmit()"><img
			src="<?=RPW?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
			height="21" border="0"></a></p>
		</td>
	</tr>
</table>
</div>
<!--***承認依頼レイヤー　　　　 ここまで********************************-->
<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxLayer('cms8341-calendar',0)"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px">
		<div id="cms8341-calbody"
			style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
<!--***ページプロパティレイヤー ここから********************************-->
<div id="cms8341-property" class="cms8341-layer">
<table width="600" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="600" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="600" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/pageproperty/title_pageproperty.jpg"
					alt="ページプロパティ" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxLayer('cms8341-property',0)"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 560px; height: 470px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center" id="cms8341-propertybody"><!-- ****** ページプロパティ表示領域 ここから ********* -->
		ここに各ページのページプロパティが代入されます。 <!-- ****** ページプロパティ表示領域 ここまで ********* --></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***ページプロパティレイヤー ここまで********************************-->
<!--***警告メッセージレイヤー　 ここから********************************-->
<div id="cms8341-causion" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_causion.jpg" alt="警告"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-causionmsg"><!-- ****** 警告メッセージ表示領域 ここから ********* -->
		メッセージ <!-- ****** 警告メッセージ表示領域 ここまで ********* --></div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxCausionYes()"><img
			src="<?=RPW?>/admin/images/btn/btn_yes.jpg" alt="はい" width="100"
			height="20" border="0" style="margin-right: 5px;"></a><a
			href="javascript:" onClick="return cxLayerClose('cms8341-causion')"><img
			src="<?=RPW?>/admin/images/btn/btn_no.jpg" alt="いいえ" width="100"
			height="20" border="0" style="margin-left: 5px;"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***警告メッセージレイヤー　 ここまで********************************-->
<!--***処理中メッセージレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg"><!-- ****** 処理中メッセージ表示領域 ここから ********* -->
		メッセージ <!-- ****** 処理中メッセージ表示領域 ここまで ********* --></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理中メッセージレイヤー ここまで********************************-->
<!--***エラーメッセージレイヤー ここから********************************-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxLayerClose('cms8341-error')"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー ここまで********************************-->
<!--***否認理由メッセージレイヤー ここから********************************-->
<div id="cms8341-denial" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/denail/title_denialmsg.jpg"
					alt="前回の否認理由" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxLayer('cms8341-denial',0)"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div id="cms8341-denialmsg"
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			　id="cms8341-denialmsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxLayerClose('cms8341-denial')"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***否認理由メッセージレイヤー ここまで********************************--></form>
</body>
</html>
