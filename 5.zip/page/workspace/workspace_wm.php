<?php
/*
 * ワークスペース
 */
require ("../.htsetting");

// 戻り先設定
$_SESSION['back_path'] = $_SERVER['SCRIPT_NAME'];

$login = $objLogin->login;
if ($login['class'] != USER_CLASS_WEBMASTER) {
	user_error('不正アクセスです。');
}

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

$menu_no = 0;

// （承認依頼）公開期間の初期値
$Y = date('Y');
$n = date('n');
$j = date('j');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ワークスペース</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/workspace.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/workspace_wm.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'workspace';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<form name="cms_CMenu" class="cms8341-form" id="cms_CMenu" method="post"
	action="" target=""><input type="hidden" name="cms_preview_color"
	id="cms_preview_color" value="" disabled> <input type="hidden" name="cms_dispMode"
	id="cms_dispMode" value=""> <input type="hidden" name="cms_page_id"
	id="cms_page_id" value=""> <input type="hidden" name="cms_unuse_delete"
	id="cms_unuse_delete" value=""></form>
<form name="cms_fAppreq" class="cms8341-form" id="cms_fAppreq"
	method="post" action="<?=RPW?>/admin/page/common/approverequest.php"><input
	type="hidden" name="cms_approve_id" id="cms_approve_id" value="">
<div align="center" id="cms8341-contents">
<div><img src="<?=RPW?>/admin/images/workspace/bar_workspace.jpg"
	alt="ワークスペース" width="920" height="30"></div>
<div class="cms8341-area-corner">
<?php
// 作業中ページ情報を取得
$objPage->selectWorkspace($login['user_id']);
if ($objPage->getRowCount() == 0) { // ▼作業中ページなし
	?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-workspace">
	<tr>
		<th valign="middle" scope="col" style="font-weight: normal">&nbsp;</th>
	</tr>
	<tr>
		<td align="center" valign="middle">作業中のページはありません。</td>
	</tr>
</table>
<?php
}
else { // ▼作業中ページあり
	$approve_id = '';
	$comp_flg = FALSE;
	while ($objPage->fetch()) {
		if ($objPage->fld['approve_id'] != $approve_id) {
			if ($approve_id != '') print '</table>' . "\n";
			$approve_id = $objPage->fld['approve_id'];
			?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-workspace">
	<tr>
		<th width="80" align="center" valign="middle" scope="col"
			style="font-weight: normal">状態</th>
		<th align="center" valign="middle" scope="col"
			style="font-weight: normal">タイトル</th>
	</tr>
<?php
		}
		$menu_no++;
		$fld = $objPage->fld;
		if ($fld['work_class'] == WORK_CLASS_DELETE) {
			if ($fld['close_flg'] == FLAG_ON) {
				$status_img = 'icon_close.jpg';
				$status_alt = '非公開';
				$link_mode = 'del';
				$comp_flg = TRUE;
			}
			else {
				$status_img = 'icon_del.jpg';
				$status_alt = '削除';
				$link_mode = 'del';
				$comp_flg = TRUE;
			}
		}
		else {
			$link_mode = 'edit';
			if ($fld['work_class'] == WORK_CLASS_NEW) {
				$status_img = 'icon_new';
				$status_alt = '新規';
			}
			elseif ($fld['work_class'] == WORK_CLASS_PUBLISH) {
				$status_img = 'icon_edit';
				$status_alt = '更新';
			}
			if ($fld['status'] == STATUS_COMP) {
				$status_img .= '_comp.jpg';
				$status_alt .= '完了';
				$comp_flg = TRUE;
			}
			else {
				$status_img .= '_save.jpg';
				$status_alt .= '保存中';
			}
		}
		$fields = "p.*, w.file_path as w_file_path, w.page_title as w_page_title, w.close_flg AS w_close_flg, w.user_id AS work_user_id, u.dept_code AS dept_code, w.output_html_flg AS w_output_html_flg";
		$where = $objDac->_addslashesC("p.file_path", $fld['file_path']);
		$objDac->setTableName("tbl_publish_page AS p LEFT JOIN tbl_work_page AS w ON (p.page_id = w.page_id) LEFT JOIN tbl_user AS u ON (p.user_id = u.user_id)");
		$objDac->select($where, $fields);
		$objDac->fetch();
		$fld = array_merge($fld, $objDac->fld);
		$toolbar_msg = "";
		
		echo '<tr>' . "\n";
		echo '<td width="80" align="center" valign="middle"><img src="' . RPW . '/admin/images/workspace/' . $status_img . '" alt="' . $status_alt . '" width="70" height="25"></td>' . "\n";
		// ▲承認依頼チェックボックス有無 
		echo '<td align="left" valign="top"><p><small>' . setRootPath($objTool->getPankuzu(FLAG_OFF, $fld['template_kind'], $objTool->selectTemplateKankoType($fld['template_id']), $fld['ancestor_path'], '', $login['user_id'], FALSE)) . ' &gt;</small></p>' . "\n";
		echo '<div>';
		echo '<p><a href="javascript:" onClick="return cxContentsMenu2(event, \'cms_menu_' . $menu_no . '\',\'' . $fld['page_id'] . '\',\'cms_CMenu\',\'' . $headerMode . '\')"  onContextMenu="cxContentsMenu2(event, \'cms_menu_' . $menu_no . '\',\'' . $fld['page_id'] . '\',\'cms_CMenu\',\'' . $headerMode . '\');return false;"><span id="cms_page_title_' . $menu_no . '">' . htmlDisplay($fld['w_page_title']) . '</span></a></p>' . "\n";
		echo '<div id="cms_menu_' . $menu_no . '" class="cms8341-layer"></div>' . "\n";
		echo '</div>';
		echo '</td>' . "\n";
		echo '</tr>' . "\n";
	}
	// ▲while 
	echo '</table>' . "\n";
	echo '<p align="center"><img src="' . RPW . '/admin/images/icon/icon-flow.jpg" alt="" width="36" height="26"></p>' . "\n";
	// ▼承認依頼ボタン有効 
	//	if ($comp_flg) {
	//		echo '<p align="center"><a href="javascript:" onClick="return cxRequestSet()"><img src="' . RPW . '/admin/images/btn/btn_request.jpg" alt="承認依頼" width="150" height="20" border="0"></a></p>' . "\n";
	//		// ▼承認依頼ボタン無効 
	//	}
	//	else {
	echo '<p align="center"><img src="' . RPW . '/admin/images/btn/btn_request_off.jpg" alt="承認依頼" width="150" height="20" border="0"></p>' . "\n";
	//	}
// ▲承認依頼ボタン 
}
// ▲作業中ページ有無 
?>
</div>
	<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
		width="920" height="10"></div>
	</div>
	<!--</div>-->
	<!--***ページプロパティレイヤー ここから********************************-->
	<div id="cms8341-property" class="cms8341-layer">
	<table width="600" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="600" align="center" valign="top" bgcolor="#DFDFDF"
				style="border: solid 1px #343434;">
			<table width="600" border="0" cellspacing="0" cellpadding="0"
				class="cms8341-layerheader">
				<tr>
					<td align="left" valign="middle"><img
						src="<?=RPW?>/admin/images/pageproperty/title_pageproperty.jpg"
						alt="ページプロパティ" width="200" height="20" style="margin: 4px 10px;"></td>
					<td width="78" align="right" valign="middle"><a href="javascript:"
						onClick="return cxLayer('cms8341-property',0)"><img
						src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
						height="19" border="0" style="margin: 4px 10px;"></a></td>
				</tr>
			</table>
			<div
				style="width: 560px; height: 470px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
			<div align="center" id="cms8341-propertybody"><!-- ****** ページプロパティ表示領域 ここから ********* -->
			ここに各ページのページプロパティが代入されます。 <!-- ****** ページプロパティ表示領域 ここまで ********* -->
			</div>
			</div>
			</td>
		</tr>
	</table>
	</div>
	<!--***ページプロパティレイヤー ここまで********************************-->
	<!--***処理中メッセージレイヤー ここから********************************-->
	<div id="cms8341-progress" class="cms8341-layer">
	<table width="500" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
				style="border: solid 1px #343434;">
			<table width="500" border="0" cellspacing="0" cellpadding="0"
				class="cms8341-layerheader">
				<tr>
					<td align="left" valign="middle"><img
						src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
						width="480" height="20" style="margin: 4px 10px;"></td>
				</tr>
			</table>
			<div
				style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
			<div align="center">
			<div
				style="width: 430px; height: 120px; padding: 5px; text-align: left"
				id="cms8341-progressmsg"><!-- ****** 処理中メッセージ表示領域 ここから ********* -->
			メッセージ <!-- ****** 処理中メッセージ表示領域 ここまで ********* --></div>
			</div>
			</div>
			</td>
		</tr>
	</table>
	</div>
	<!--***処理中メッセージレイヤー ここまで********************************-->
	<!--***エラーメッセージレイヤー ここから********************************-->
	<div id="cms8341-error" class="cms8341-layer">
	<table width="500" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
				style="border: solid 1px #343434;">
			<table width="500" border="0" cellspacing="0" cellpadding="0"
				class="cms8341-layerheader">
				<tr>
					<td align="left" valign="middle"><img
						src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
						width="480" height="20" style="margin: 4px 10px;"></td>
				</tr>
			</table>
			<div
				style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
			<div align="center">
			<div
				style="width: 430px; height: 120px; padding: 5px; text-align: left"
				id="cms8341-errormsg">メッセージ</div>
			<div style="margin: 15px 0px;"><a href="javascript:"
				onClick="return cxLayer('cms8341-error')"><img
				src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
				height="20" border="0"></a></div>
			</div>
			</div>
			</td>
		</tr>
	</table>
	</div>
	<!--***エラーメッセージレイヤー ここまで********************************-->
	</form>

</body>
</html>
