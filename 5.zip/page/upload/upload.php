<?php
/*
 * 手動アップロード
 */
require ("../.htsetting");

$login = $objLogin->login;

if ($login['class'] != USER_CLASS_WEBMASTER && $login['isRegain'] == FALSE) {
	user_error('不正アクセスです。');
}

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/page_control.inc');
$objP = new page_control();

$set_target1 = '';
$page = (isset($_POST['cms_page']) && is_numeric($_POST['cms_page']) ? floor($_POST['cms_page']) : 1);
$row_cnt = 0;
$MAXROW_LIST = getDefineArray("MAXROW_LIST");
$maxRow = (isset($_POST['maxrow']) && is_numeric($_POST['maxrow']) ? floor($_POST['maxrow']) : key($MAXROW_LIST));
$search_flg = FLAG_OFF; //検索条件エリアの開閉フラグ
$disp_last_condition = "";
// アップロード処理中か確認
$is_lock = lock_file_management('check');
// アップロード不可
if ($is_lock) {
	$btn_allselect = '<img src="' . RPW . '/admin/images/upload/btn_allselect_off.jpg" alt="全て選択する" width="120" height="20" border="0">';
	$btn_allcansel = '<img src="' . RPW . '/admin/images/upload/btn_allcansel_off.jpg" alt="全て解除する" width="120" height="20" hspace="20" border="0">';
	$btn_upload = '<img src="' . RPW . '/admin/images/upload/btn_upload_off.jpg" alt="アップロード" width="150" height="20" border="0">';
	$btn_unlock = '<a href="javascript:" onClick="return cxUnlock();"><img src="' . RPW . '/admin/images/btn/btn_unlock.jpg" alt="ロック解除" width="150" height="20" hspace="20" border="0"></a>';
	$disabled = ' disabled';
	//ロック情報取得
	$lock_date = lock_file_management('get');
}
// アップロード可
else {
	$btn_allselect = '<a href="javascript:" onClick="return cxCheckAll();"><img src="' . RPW . '/admin/images/upload/btn_allselect.jpg" alt="全て選択する" width="120" height="20" border="0"></a>';
	$btn_allcansel = '<a href="javascript:" onClick="return cxReleaseAll();"><img src="' . RPW . '/admin/images/upload/btn_allcansel.jpg" alt="全て解除する" width="120" height="20" hspace="20" border="0"></a>';
	$btn_upload = '<a href="javascript:" onClick="return cxUpload();"><img src="' . RPW . '/admin/images/upload/btn_upload.jpg" alt="アップロード" width="150" height="20" border="0"></a>';
	$btn_unlock = '';
	$disabled = '';
}

// 検索条件
$search = array(
		// ページID検索
		'page_id' => '',
		'page_title' => '', 
		'search_keywords' => '', 
		'is_tag_search' => FLAG_OFF, 
		'publish_start' => '', 
		'publish_end' => '', 
		'pdsy' => '', 
		'pdsm' => '', 
		'pdsd' => '', 
		'pdey' => '', 
		'pdem' => '', 
		'pded' => '', 
		'class' => USER_CLASS_WEBMASTER, 
		'target1' => $set_target1, 
		'target2' => '', 
		'target3' => '', 
		'expired' => ''
);

//同一ページ以外から来た場合、SESSIONを削除する
if (!isset($_SERVER['HTTP_REFERER']) || preg_replace('/\?.*$/i', '', $_SERVER['HTTP_REFERER']) != HTTP_ROOT . $_SERVER['PHP_SELF']) unset($_SESSION['upload_search']);

if (isset($_GET['ini']) && $_GET['ini'] == 1) {
	if (isset($_SESSION['upload_search'])) unset($_SESSION['upload_search']);
}
elseif (isset($_SESSION['upload_search'])) {
	$search = $_SESSION['upload_search'];
}
if (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'search') {
	$search = array();
	// ページID検索
	if (!empty($_POST['cms_search_page_id'])) {
		$search['page_id'] = explode(' ', preg_replace('/\s+/', ' ', $_POST['cms_search_page_id']));
	}
	$search['page_title'] = str_replace('　', ' ', $_POST['cms_search_page_title']);
	$search['page_title'] = preg_replace('/(^ | $)/', '', $search['page_title']);
	$search['search_keywords'] = str_replace('　', ' ', $_POST['cms_search_keywords']);
	$search['search_keywords'] = preg_replace('/(^ | $)/', '', $search['search_keywords']);
	$search['is_tag_search'] = $_POST['cms_is_tag_search'];
	$search['pdsy'] = $_POST['cms_pdsy'];
	$search['pdsm'] = $_POST['cms_pdsm'];
	$search['pdsd'] = $_POST['cms_pdsd'];
	$search['pdey'] = $_POST['cms_pdey'];
	$search['pdem'] = $_POST['cms_pdem'];
	$search['pded'] = $_POST['cms_pded'];
	if (($search['pdsy'] != '') && ($search['pdsm'] != '') && ($search['pdsd'] != '')) $search['publish_start'] = $search['pdsy'] . '-' . $search['pdsm'] . '-' . $search['pdsd'];
	if (($search['pdey'] != '') && ($search['pdem'] != '') && ($search['pded'] != '')) $search['publish_end'] = $search['pdey'] . '-' . $search['pdem'] . '-' . $search['pded'] . ' 23:59:59';
	//**2006/09/28
	$search['target1'] = $_POST['cms_target1'];
	$search['target2'] = $_POST['cms_target2'];
	$search['target3'] = $_POST['cms_target3'];
	//**2006/09/28
	$search['expired'] = (isset($_POST['cms_expired'])) ? $_POST['cms_expired'] : '';
	$_SESSION['upload_search'] = $search;
	$_SESSION['last_search_condition']['upload_search'] = $search;
	$search_flg = FLAG_ON;
}
elseif (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'pageset') {
	$_SESSION['upload_search'] = $search;
}
elseif (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'last_condition') {
	$search = $_SESSION['last_search_condition']['upload_search'];
	$_SESSION['upload_search'] = $search;
	$search_flg = FLAG_ON;
}
//前回の検索ボタン
if (isset($_SESSION['last_search_condition']['upload_search'])) {
	$disp_last_condition = '<span style="margin:15px;" class="cms8341-verticalMiddle"><a href="javascript:" onclick="return cxLastSearch()"><img src="' . RPW . '/admin/images/btn/btn_search_condition.jpg" alt="前回の条件で検索" width="150" height="20" border="0"></a></span>' . "\n";
}

//対象項目生成
// ページID検索
$search_page_id = (!empty($search['page_id'])) ? implode(' ', $search['page_id']) : '';


// タグ内検索
$var = array(
		FLAG_OFF => "HTMLのタグを対象としない", 
		FLAG_ON => "HTMLのタグを対象とする"
);
$name = "cms_is_tag_search";
$cms_is_tag_search = mkradiobutton($var, $name, $search["is_tag_search"], 2);

$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level=1";
if ($search["target1"] != '') {
	$digit = 1 * CODE_DIGIT_DEPT;
	$d_cd = "^" . substr($search["target1"], 0, $digit);
	$sql .= " OR (level=2 AND dept_code REGEXP '" . $d_cd . "')";
}
if ($search["target2"] != '') {
	$digit = 2 * CODE_DIGIT_DEPT;
	$d_cd = "^" . substr($search["target2"], 0, $digit);
	$sql .= " OR (level=3 AND dept_code REGEXP '" . $d_cd . "')";
}
$sql .= " ORDER BY dept_code, sort_order, dept_id";
$objPage->execute($sql);
$dept_s1 = '<select id="cms_target1" name="cms_target1" onChange="javascript:cxChangeDept(1, this.value)" style="width:150px;">';
$dept_s2 = '<select id="cms_target2" name="cms_target2" onChange="javascript:cxChangeDept(2, this.value)" style="width:150px;">';
$dept_s3 = '<select id="cms_target3" name="cms_target3" style="width:150px;">';
$dept_opn = '<option value="" selected>----------------</option>';
$dept_opd = '<option value="">指定なし</option>';
$dept_ops = '<option value="" selected>指定なし</option>';
$dept_op1 = '';
$dept_op2 = '';
$dept_op3 = '';
$dept_e = '</select>&nbsp;&nbsp;';
$d1 = 0;
$d2 = 0;
$d3 = 0;
while ($objPage->fetch()) {
	//print_dp($objPage->fld);
	$lv = $objPage->fld['level'];
	if ($search["target1"] == '' && $lv == 2) continue;
	if ($search["target2"] == '' && $lv == 3) continue;
	//
	$cd = $objPage->fld['dept_code'];
	$nm = $objPage->fld['name'];
	$t = '';
	if ($lv == 1) {
		if ($search["target1"] == $cd) {
			$t = ' selected';
			$d1 = 1;
		}
		$dept_op1 .= '<option value="' . $cd . '"' . $t . '>' . $nm . '</option>';
	}
	elseif ($search["target1"] != '' && $lv == 2) {
		if ($search["target2"] == $cd) {
			$t = ' selected';
			$d2 = 1;
		}
		$dept_op2 .= '<option value="' . $cd . '"' . $t . '>' . $nm . '</option>';
	}
	elseif ($search["target2"] != '' && $lv == 3) {
		if ($search["target3"] == $cd) {
			$t = ' selected';
			$d3 = 1;
		}
		$dept_op3 .= '<option value="' . $cd . '"' . $t . '>' . $nm . '</option>';
	}
}
;
//
if ($d1 == 1) {
	$target1 = $dept_s1 . $dept_opd . $dept_op1 . $dept_e;
}
else {
	$target1 = $dept_s1 . $dept_ops . $dept_op1 . $dept_e;
}
if ($search["target1"] != '' && $d2 == 1) {
	$target2 = $dept_s2 . $dept_opd . $dept_op2 . $dept_e;
}
elseif ($search["target1"] != '' && $d2 == 0) {
	$target2 = $dept_s2 . $dept_ops . $dept_op2 . $dept_e;
}
else {
	$target2 = $dept_s2 . $dept_opn . $dept_e;
}
if ($search["target2"] != '' && $d3 == 1) {
	$target3 = $dept_s3 . $dept_opd . $dept_op3 . $dept_e;
}
elseif ($search["target2"] != '' && $d3 == 0) {
	$target3 = $dept_s3 . $dept_ops . $dept_op3 . $dept_e;
}
else {
	$target3 = $dept_s3 . $dept_opn . $dept_e;
}
$cms_target = $target1 . $target2 . $target3;

// 公開待ち情報の取得
$objPage->selectPublishWait($search);
//全件数取得
$row_cnt = $objPage->getRowCount();
//取得件数を指定し再取得
$objP->limit = $maxRow;
$objP->set($page, $row_cnt);
$search['p'] = $page;
$search['disp_num'] = $maxRow;
$objPage->selectPublishWait($search);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>手動アップロード</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/upload.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/upload.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'upload';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
?>
<div align="center" id="cms8341-contents">
<div align="center" id="cms8341-upload">
<div><img src="<?=RPW?>/admin/images/upload/bar_upload.jpg"
	alt="手動アップロード" width="920" height="30"></div>
<?php
if ($is_lock) {
	?>
<div class="cms8341-areamessage" id="cms8341-denaillist-msg">
<div style="float: left; text-align: left;">現在アップロード処理中のためアップロードを行うことができません。<br>
しばらく時間をおいてから再度お試しください。<br>
時間をおいても手動アップロードが行えない場合は、「ロック解除」ボタンからロックを解除してください。</div>
<div style="text-align: right;">ロック日時：<?=$lock_date?></div>
<div style="text-align: right; margin-top: 10px;"><?=$btn_unlock?></div>
</div>
<?php
}
?>
<div class="cms8341-area-corner">
<div id="cms8341-searcharea">
<form name="cms_fSearch" id="cms_fSearch" class="cms8341-form"
	method="post" action="upload.php"><input type="hidden"
	name="cms_dispMode" value="">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle" style="background-image:url(<?=RPW?>/admin/page/publiclist/images/bar_topbg.jpg);height:31px;"><img
			src="<?=RPW?>/admin/page/publiclist/images/bar_search.jpg" alt="検索"
			width="200" height="20" style="margin-left: 10px;"></td>
	</tr>
</table>
<div id="cms8341-search"
	<?=($search_flg == FLAG_OFF ? 'style="display:none"' : '')?>>
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<td>
		<table width="100%" border="0" cellpadding="10" cellspacing="0"
			bgcolor="#F0F0F0">
			<!-- ページID検索 -->
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページID</th>
				<td align="left" valign="middle"><input type="text"
					id="cms_search_page_id" name="cms_search_page_id"
					value="<?=htmlspecialchars($search_page_id)?>"
					style="width: 250px; ime-mode: disabled;">
					<br><small>※複数指定する場合はスペース区切りで指定してください。</small></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページタイトル</th>
				<td align="left" valign="middle"><input type="text"
					id="cms_search_page_title" name="cms_search_page_title"
					value="<?=htmlspecialchars($search['page_title'])?>"
					style="width: 500px;"></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">キーワード</th>
				<td align="left" valign="middle"><?=$cms_is_tag_search?><input
					type="text" id="cms_search_keywords" name="cms_search_keywords"
					value="<?=htmlspecialchars($search['search_keywords'])?>"
					style="width: 500px;"><br>
				<small>※大文字と小文字は区別されません。</small></td>
			</tr>
			<tr>
				<th width="80" align="left" valign="middle" nowrap scope="row">公開日</th>
				<td align="left" valign="middle"><input type="text" maxlength="4"
					id="cms_pdsy" name="cms_pdsy"
					value="<?=htmlspecialchars($search['pdsy'])?>"
					style="width: 60px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="cms_pdsm" name="cms_pdsm"
					value="<?=htmlspecialchars($search['pdsm'])?>"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="cms_pdsd" name="cms_pdsd"
					value="<?=htmlspecialchars($search['pdsd'])?>"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('cms_pd','start')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a> から <input
					type="text" maxlength="4" id="cms_pdey" name="cms_pdey"
					value="<?=htmlspecialchars($search['pdey'])?>"
					style="width: 60px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="cms_pdem" name="cms_pdem"
					value="<?=htmlspecialchars($search['pdem'])?>"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="cms_pded" name="cms_pded"
					value="<?=htmlspecialchars($search['pded'])?>"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('cms_pd','end')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a></td>
			</tr>
			<tr>
				<th align="left" valign="middle" nowrap scope="row">対象</th>
				<td align="left" valign="middle"><?=$cms_target?></td>
			</tr>
		</table>
		</td>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="121" align="center" valign="middle"><a href="javascript:"
			onClick="return cxSearch()"><img
			src="<?=RPW?>/admin/images/btn/btn_search.jpg" alt="検索する" width="101"
			height="21" border="0"></a></td>
	</tr>
</table>
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right" valign="middle" style="background-image:url(<?=RPW?>/admin/page/publiclist/images/bar_bottombg.jpg);height:32px;"><a
			href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			<?=($search_flg == FLAG_OFF ? 'src="' . RPW . '/admin/images/btn/btn_open_mini.jpg" alt="開く"' : 'src="' . RPW . '/admin/images/btn/btn_close_mini.jpg" alt="閉じる"')?>
			width="80" height="15" border="0" style="margin-right: 10px;"
			id="cms-searchSwitch"></a></td>
	</tr>
</table>
<input type="hidden" name="maxrow" id="search_maxrow"
	value="<?=$maxRow?>"></form>
</div>
<?php
if ($objPage->getRowCount() == 0) {
	?>
<?php

	if ($disp_last_condition != "") {
		?>
<p style="margin-bottom: 0px;"><span style="float: right;"><?=$disp_last_condition?></span>
</p>
<?php
	}
	?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-uploadlist">
	<tr>
		<th align="center" valign="middle" scope="col"
			style="font-weight: normal">&nbsp;</th>
	</tr>
	<tr>
		<td align="center" valign="middle">該当するページはありません。</td>
	</tr>
</table>
<?php
}
else {
	?>
<form name="cms_CPreview" id="cms_CPreview" class="cms8341-form"
	method="post" action="preview.php" target="_new"><input type="hidden"
	name="cms_dispMode" value="2"> <input type="hidden" name="cms_page_id"
	value=""></form>
<form name="cms_fUpload" id="cms_fUpload" class="cms8341-form"
	method="post" action="submit.php"><input type="hidden"
	name="cms_dispMode" value="upload">
<p style="margin-bottom: 0px;"><span style="float: right;"><?=$disp_last_condition?><?=($row_cnt > 0 ? mkcombobox($MAXROW_LIST, "dispNum", $maxRow, "cxDispNum(this.value)") : "")?></span>
<?=$btn_allselect?>
<?=$btn_allcansel?>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	style="margin-bottom: 10px; padding: 1px">
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objP->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objP->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objP->getNextLink()?></td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-uploadlist">
	<tr>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">選択</th>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">状態</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">タイトル</th>
	</tr>
<?php
	while ($objPage->fetch()) {
		$fld = $objPage->fld;
		
		$pubdate = '公開期間：' . dtFormat($fld['publish_start'], 'Y年m月d日H時') . 'から' . get_publish_end_date($fld['publish_end']) . 'まで';
		
		if ($fld['work_class'] == 1) {
			$icon_img = 'icon_new.jpg';
			$icon_alt = '新規';
			$link_mode = 'edit';
		}
		elseif ($fld['work_class'] == 2) {
			$icon_img = 'icon_edit.jpg';
			$icon_alt = '更新';
			$link_mode = 'edit';
		}
		elseif ($fld['close_flg'] == 1) {
			$icon_img = 'icon_close.jpg';
			$icon_alt = '非公開';
			$link_mode = 'del';
			$pubdate = '非公開日時：' . dtFormat($fld['publish_start'], 'Y年m月d日H時');
		}
		else {
			$icon_img = 'icon_del.jpg';
			$icon_alt = '削除';
			$link_mode = 'del';
			$pubdate = '削除日時：' . dtFormat($fld['publish_start'], 'Y年m月d日H時');
		}
		// ページ出力設定がされていない場合アイコン表示
		$not_output_html_str = "";
		$output_html_flg = (isset($fld['output_html_flg']) ? $fld['output_html_flg'] : FLAG_ON);
		if ($output_html_flg == FLAG_OFF) {
			$not_output_html_str = '<img src="' . RPW . '/admin/page/workflow/images/icon_not_output_html.gif" alt="ページ出力なし" width="16" height="16" class="cms8341-verticalMiddle">';
		}
		
		print '<tr>' . "\n";
		print '<td align="center" valign="middle"><input type="checkbox" name="cms_page_id[]" value="' . $fld['page_id'] . '"' . $disabled . '></td>' . "\n";
		print '<td align="center" valign="middle"><img src="' . RPW . '/admin/page/workflow/images/' . $icon_img . '" alt="' . $icon_alt . '" width="70" height="25"></td>' . "\n";
		print '<td align="left" valign="top"><p><strong><a href="javascript:" onClick="return cxPreview(\'cms_CPreview\',\'' . $fld['page_id'] . '\',\'2\');">' . htmlDisplay($fld['page_title']) . '</a></strong>&nbsp;' . $not_output_html_str . '</p>' . "\n";
		print '<p><small>' . $pubdate . '</small></p>' . "\n";
		// 外部取り込み対策
		if ($fld['request_datetime'] != "") {
			print '<p><small>承認依頼者：' . htmlDisplay($fld['dept_name']) . ' ' . htmlDisplay($fld['name']) . '</small></p>' . "\n";
			print '<p><small>承認依頼日：' . dtFormat($fld['request_datetime'], 'Y年n月j日H時i分s秒') . '</small></p>' . "\n";
		}
		print '</td>' . "\n";
		print '</tr>' . "\n";
	}
	?>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	style="margin-bottom: 10px; padding: 1px">
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objP->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objP->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objP->getNextLink()?></td>
	</tr>
</table>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center">選択したページを今すぐアップロードします。</p>
<p align="center"><?=$btn_upload?></p>
</form>
<form name="cms_page_post" id="cms_page_post" method="post" action=""><input
	type="hidden" name="cms_page" id="cms_page" value=""> <input
	type="hidden" name="maxrow" id="maxrow" value=""></form>
<?php
}
?>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCalendarClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px;">
		<div id="cms8341-calbody"
			style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
<!--***エラーメッセージレイヤー ここから********************************-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxCloseError()"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー ここまで********************************-->
</body>
</html>
