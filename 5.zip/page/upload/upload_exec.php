<?php
/*
 *
 */
/** データのアップロード **/
global $success_list;
global $fail_list;
$fail_list = array();
$errmsg = "";
// 手動アップロード（ウェブマスター）
if (isset($_POST['cms_dispMode'])) {
	require ("../.htsetting");
	if ($_POST['cms_dispMode'] != 'upload' || !isset($_POST['cms_page_id'])) {
		user_error("It isn't setted cms_page_id in _post.", E_USER_ERROR);
	}
	$aryID = $_POST['cms_page_id'];
	$cronFlg = false;
	
// 自動アップロード（cron起動）
}
else {
	$aryID = array();
	$cronFlg = true;
	$_POST['cms_dispMode'] = 5;
}

// 排他制御 -----------------------------------------
if ($cronFlg) {
	if (lock_file_management('lock_retry') === FALSE) {
		errorWrite("自動アップロード : リトライ回数が上限に達しました");
		exit();
	}
}
else if (lock_file_management('lock') === FALSE) {
	user_error("ロックに失敗しました。<br>自動アップロード又は他ユーザがアップロード中の可能性があります。", E_USER_ERROR);
}

global $objCnc;

// 自動非公開フラグ( セットされていなければオフ )
if (!isset($close_upload)) $close_upload = FLAG_OFF;
// 定型情報保持セッションを削除
$_SESSION['fixed'] = array();
// FAQ 一覧ページの自動公開フラグ(カテゴリコード)
$faqListUploadCate = array();

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage1 = new tbl_page($objCnc);
$objPage2 = new tbl_page($objCnc);
$objPage3 = new tbl_page($objCnc);
$objPage4 = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$objLinks = new tbl_links($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInquiry = new tbl_inquiry($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_contents_group.inc');
$objCGrp = new tbl_contents_group($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
$objKanko = new tbl_kanko($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete.inc');
$objEnq = new tbl_enquete($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete_detail.inc');
$objEnqDtl = new tbl_enquete_detail($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/commands.inc');

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFAQ = new tbl_faq($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_auto_link_pages.inc');
$objAutoLinkPages = new tbl_auto_link_pages($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_map.inc');
$objMap = new tbl_map($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_links.inc');
$objFCKLinks = new tbl_fck_links($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_lnavi_handler.inc');
$objGHandler = new tbl_lnavi_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output_handler.inc');
$objOpHndl = new tbl_output_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/b_dac.inc');

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_approve_handler.inc');
$objAppHandler = new tbl_approve_handler($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap.inc');
$objSitemap = new tbl_sitemap($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap_handler.inc');
$objSitemapHandler = new tbl_sitemap_handler($objCnc);
// イベントカレンダー複数日
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_event.inc');
$obj_event = new tbl_event($objCnc);
// オープンデータ
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_open_data.inc');
$obj_open_data_edit = new tbl_open_data($objCnc);

// 自動非公開フラグのチェック -----------------------------------------


// 自動非公開フラグがオン /_/_/_/_/_/_/_/_/_/_/_/
if ($close_upload == FLAG_ON) {
	// 公開期限切れ一覧を取得
	$objPage1->selectUploadClose();
	// 通常アップロード(従来) /_/_/_/_/_/_/_/_/_/_/_/
}
else {
	// 公開ページ一覧取得
	$objPage1->selectUpload($aryID);
}

// 処理するページが存在しない場合 -------------------------------------


if ($objPage1->getRowCount() <= 0) {
	// 排他制御解除
	lock_file_management('unlock');
	// クーロンでないなら公開リストへ移動
	if (!$cronFlg) {
		header("Location: " . HTTP_ROOT . RPW . "/admin/page/publiclist/publiclist.php?ini=1");
	}
	// クローンなら処理終了
	exit();
}

if (!$cronFlg) $pgrs_func->start("公開処理中です。");

//ページを公開する順番にソートする(パンくずが末端のページから公開する)
$sort_ary = array();
while ($objPage1->fetch()) {
	$sort_ary[$objPage1->fld['page_id']] = substr_count($objPage1->fld['p_ancestor_path'], ",");
}
arsort($sort_ary);

// ページの公開処理 ---------------------------------------------------
// 全ての公開したページを格納する配列(自動リンク時に使用)
$allUploadPages = array();
$allDeletePages = array();

// 外部連携自動出力用テンプレートID配列削除・初期化
unset($_SESSION['template_id_of_output_page']);
$_SESSION['template_id_of_output_page'] = array();

// 大規模災害状態フラグ
$is_disaster_flg = isDisasterFlg();

if (!SFTP_FLG) {
	$ftpCnc = connectFTP("cms");
	if (ENABLE_OPTION_ADVERT) $ftpCgiCnc = connectFTP("click_cgi");
}

// 自動リンク更新用のSESSION情報を保持する配列
$session_temp_ary = array();

$upload_cnt = 0;
foreach ((array) $sort_ary as $page_id => $count_val) {
	unset($_SESSION['temp']['l_navi']);
	if (SFTP_FLG) {
		$ftpCnc = connectFTP("cms");
		if (ENABLE_OPTION_ADVERT) $ftpCgiCnc = connectFTP("click_cgi");
	}
	$continue_flg = FLAG_OFF;
	$uploadPages = array();
	if ($close_upload == FLAG_ON) { // 自動非公開の場合
		$objPage4->selectUploadClose($page_id);
	}
	else { // 通常公開の場合
		$temp_ary = array(
				$page_id
		);
		$objPage4->selectUpload($temp_ary);
	}
	if (!$objPage4->fetch()) continue;
	$fld = $objPage4->fld;
	
	$faqListPageFLG = FLAG_OFF; // FAQ一覧ページ公開フラグ
	$faqCateUpdate = array(); // カテゴリ情報
	$faq_id = $objFAQ->getFAQIDfromPageID($fld['page_id']);
	
	// FAQ関連の公開チェック
	getUpLoadPageFAQ($fld, $faqListUploadCate, $faqListPageFLG, $faqCateUpdate);
	
	$fixed_edit_items = array();
	if (isFixed($fld)) {
		if (isset($_SESSION['fixed'][$fld['template_id']])) {
			$fixed_edit_items = $_SESSION['fixed'][$fld['template_id']];
		}
		else {
			$fixed_edit_items = getItem($fld['template_id'], "", "edit");
			$_SESSION['fixed'][$fld['template_id']] = $fixed_edit_items;
		}
	}
	
	// トランザクション開始
	$objCnc->begin();
	
	$objPage2->selectFromID($fld['page_id'], PUBLISH_TABLE);
	$_SESSION['temp']['publish_page'] = $objPage2->fld;
	
	$objPage2->selectFromID($fld['page_id'], WORK_TABLE);
	$_SESSION['temp']['work_page'] = (isset($objPage2->fld)) ? $objPage2->fld : "";
	
	// イベントカレンダー複数日
	if (EVENT_CAL_MULTI_FLAG) {
		$format_tbl_name = (isFixed($fld)) ? getTableName($fld['template_id']) : '';
	
		// イベントCSV用の配列
		$open_start_w = array();
		$open_end_w = array();
		$open_start_p = array();
		$open_end__p = array();
		
		if ($objTool->selectTemplateKankoType($fld['template_id']) == KANKO_TYPE_EVENT && $format_tbl_name == KANKO_XML_TYPE_CSV) {
			// 変更前のデータを取得
			if ($obj_event->selectFromID($fld['page_id'], PUBLISH_TABLE) === FALSE) {
				user_error('dac execute error. <br>tbl_event->selectFromID(' . $fld['page_id'] . ', ' . PUBLISH_TABLE . ');', E_USER_ERROR);
			}
			while ($obj_event->fetch()) {
				$open_start_p[$fld['page_id']][] = $obj_event->fld['open_start'];
				$open_end_p[$fld['page_id']][] = $obj_event->fld['open_end'];
			}
			// 変更後のデータを取得
			if ($obj_event->selectFromID($fld['page_id'], WORK_TABLE) === FALSE) {
				user_error('dac execute error. <br>tbl_event->selectFromID(' . $fld['page_id'] . ', ' . WORK_TABLE . ');', E_USER_ERROR);
			}
			while ($obj_event->fetch()) {
				$open_start_w[$fld['page_id']][] = $obj_event->fld['open_start'];
				$open_end_w[$fld['page_id']][] = $obj_event->fld['open_end'];
			}
		}
	}

	$objKanko->selectFromPID($fld['page_id'], '', '', PUBLISH_TABLE);
	$tmp_ary = array();
	while ($objKanko->fetch()) {
		$tmp_ary[$objKanko->fld['item']] = $objKanko->fld;
	}
	$_SESSION['temp']['publish_kanko'] = $tmp_ary;
	
	$objKanko->selectFromPID($fld['page_id'], '', '', WORK_TABLE);
	$tmp_ary = array();
	while ($objKanko->fetch()) {
		$tmp_ary[$objKanko->fld['item']] = $objKanko->fld;
	}
	$_SESSION['temp']['work_kanko'] = $tmp_ary;
	
	$objHandler->selectAutoLinkFromPID($fld['page_id'], PUBLISH_TABLE);
	$tmp_ary = array();
	while ($objHandler->fetch()) {
		$tmp_ary[] = $objHandler->fld['item2'];
	}
	$_SESSION['temp']['publish_page_a_link'] = $tmp_ary;
	
	$objHandler->selectAutoLinkFromPID($fld['page_id'], WORK_TABLE);
	$tmp_ary = array();
	while ($objHandler->fetch()) {
		$tmp_ary[] = $objHandler->fld['item2'];
	}
	$_SESSION['temp']['work_page_a_link'] = $tmp_ary;
	
	// 影響のある自動リンクのチェック用SESSION情報を保持
	$session_temp_ary[$fld['page_id']] = $_SESSION['temp'];
	
	// 影響のある自動リンクのチェック
	$a_link_page_ary = array();
	$a_link_page_ary[] = $fld['page_id'];
	get_autolink_related_pages($a_link_page_ary, $close_upload, $allUploadPages);
	
	// 影響のあるサイトマップのチェック
	$sitemap_page_id_ary = is_sitemap_page($fld['page_id']);
	foreach ($sitemap_page_id_ary as $sitemap_page_id) {
		$allUploadPages[] = $sitemap_page_id;
	}
	
	// 大規模災害の特殊公開のためのページID情報
	$disaster_base_page_id = getDisasterBasePageId($fld['page_id']);
	$disaster_page_id = getDisasterPageId($fld['page_id']);
	// 大規模災害の特殊公開のためのファイルパス
	$disaster_file_path = $fld['p_file_path'];
	// 大規模災害に関係するページの場合
	if ($disaster_base_page_id != $disaster_page_id) {
		// 紐付けされているページのファイルパス取得
		$disaster_file_path = getDisasterModePage($fld['page_id'], 'file_path');
	}
	// 影響のある大規模災害関連ページのチェック
 	$allUploadPages = array_merge($allUploadPages, getRelatedDisasterPage($fld['page_id']));
	
	// ページ出力しない新規・更新
	if ($fld['work_class'] != WORK_CLASS_DELETE && (isset($fld['w_output_html_flg']) && $fld['w_output_html_flg'] == FLAG_OFF)) {
		// ページ出力なしのページを公開
		if (!output_html_flg_off_upload_exec($fld, $uploadPages, $allUploadPages, $cronFlg)) {
			continue;
		}
		$success_list[$fld['page_id'] . ":" . $fld['p_page_title']] = 'ページ出力設定がされていないためページの出力は行いませんでした。';
		
		if (!in_array($fld['page_id'], $allUploadPages)) $allUploadPages[] = $fld['page_id'];
	}
	//非公開中のページを非公開する
	else if ($fld['work_class'] == WORK_CLASS_DELETE && $fld['p_close_flg'] == FLAG_ON && $fld['w_close_flg'] == FLAG_ON) {
		//非公開中のページを非公開とする（編集情報で公開情報の更新は行う）
		if (!close_flg_on_upload_exec($fld, $uploadPages, $allUploadPages, $cronFlg)) {
			continue;
		}
		
		// ページの生成＋アップロード（パンくず変更のページ）
		$u_cnt = 0;
		$uploadPages = array_unique($uploadPages);
		if (!$cronFlg && count($uploadPages) > 0) $pgrs_func->send_msg("関連するページを処理中です。");
		foreach ($uploadPages as $pid => $path) {
			// ページ出力設定チェック
			if (is_output_html($pid) === FALSE) continue;
			create_html($pid, $path, $objCnc, $ftpCnc, $errmsg, $cronFlg);
			if (!$cronFlg) $pgrs_func->progress(++$u_cnt, count($uploadPages));
		}
		if (!$cronFlg && count($uploadPages) > 0) $pgrs_func->send_msg("公開処理中です。");
		
		//成功時の文言を追加
		$success_list[$fld['page_id'] . ":" . $fld['p_page_title']] = '非公開に成功しました。<br>【' . preg_replace('/\/+/i', '/', FTP_ROOT_DIR . $fld['p_file_path']) . '】';
		//アップロード完了ページとして、ページIDを追加
		if (!in_array($fld['page_id'], $allUploadPages)) {
			$allUploadPages[] = $fld['page_id'];
		}
	}
	//非公開・削除
	else if ($fld['work_class'] == WORK_CLASS_DELETE || $close_upload == FLAG_ON) {
		// 削除フラグ（FLAG_OFFの場合は非公開）
		$delete_flg = ($fld['w_close_flg'] == FLAG_OFF && $close_upload == FLAG_OFF ? FLAG_ON : FLAG_OFF);
				
		$allUploadPages[] = $fld['page_id'];
		// 大規模災害状態の場合
		if ($is_disaster_flg) {
			// 大規模災害ページが削除された場合
			if ($delete_flg == FLAG_ON && $disaster_base_page_id != $fld['page_id']) {
				// 作成元ページを関連ページに追加
				$allUploadPages[] = $disaster_base_page_id;
			}
		}
		$menu_generation_order_ary = array();
		// 公開ページ情報のぱんくず修正
		$where = "ancestor_path REGEXP '^(.*,)?" . $fld['p_file_path'] . "(,.*)?$'";
		$fields = "page_id, file_path, ancestor_path, close_flg, work_class,menu_generation_order";
		$orderby = "menu_generation_order";
		$objDac->setTableName('tbl_publish_page');
		$objDac->select($where, $fields, $orderby);
		while ($objDac->fetch()) {
			if ($objDac->fld['page_id'] == $fld['page_id']) continue;
			$reg_path = reg_replace($fld['p_file_path']);
			$ancestor_path = $objDac->fld['ancestor_path'];
			$ancestor_path = preg_replace('/^' . $reg_path . '(,)*/', '', $ancestor_path);
			$ancestor_path = preg_replace('/,' . $reg_path . '/', '', $ancestor_path);
			// パスの先頭に「,」が存在したら削除する
			$ancestor_path = preg_replace("/^(,)*/", '', $ancestor_path);
			// パスの末端に「,」が存在したら削除する
			$ancestor_path = preg_replace("/(,)*$/", '', $ancestor_path);
			//親ページのIDを取得
			$pos = strrpos($ancestor_path, ",");
			if ($pos !== false) $ancestor = substr($ancestor_path, ($pos + 1));
			else $ancestor = $ancestor_path;
			if ($ancestor != "" && !$objPage2->selectFromPath($ancestor, PUBLISH_TABLE, 'page_id')) {
				create_error('公開ページ情報の取得に失敗しました。<br>【' . $ancestor . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			$ary = array(
					'page_id' => $objDac->fld['page_id'], 
					'parent_id' => (($ancestor != "" && isset($objPage2->fld['page_id'])) ? $objPage2->fld['page_id'] : "")
			);
			if ($ary['parent_id'] == "" || !isset($menu_generation_order_ary[$ary['parent_id']])) {
				if (($ary['menu_generation_order'] = $objPage2->getNextMenuGenerationOrder($ary['parent_id'])) === FALSE) {
					create_error('サイトマップ表示順の取得に失敗しました。<br>【' . $objDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					$continue_flg = FLAG_ON;
					break;
				}
			}
			else {
				$menu_generation_order_rep = reg_replace($menu_generation_order_ary[$ary['parent_id']]['old']);
				$ary['menu_generation_order'] = preg_replace("/^" . $menu_generation_order_rep . "/", $menu_generation_order_ary[$ary['parent_id']]['new'], $objDac->fld['menu_generation_order']);
			}
			$menu_generation_order_ary[$objDac->fld['page_id']] = array(
					'old' => $objDac->fld['menu_generation_order'], 
					'new' => $ary['menu_generation_order']
			);
			if (!$objPage2->update($ary, WORK_TABLE)) {
				create_error('編集ページ情報の更新に失敗しました。<br>【' . $objDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			$ary['ancestor_path'] = $ancestor_path;
			if (!$objPage2->update($ary, PUBLISH_TABLE)) {
				create_error('公開ページ情報の更新に失敗しました。<br>【' . $objDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			//tbl_work_pageに削除・非公開対象のページIDが指定されていた場合、変更する
			$sql = "UPDATE tbl_work_page SET parent_id=" . $objPage2->_addslashes($fld['p_parent_id'], 'INT') . " WHERE parent_id='" . $fld['page_id'] . "'";
			if (!$objPage2->execute($sql)) {
				create_error('編集ページ情報の更新に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			//新規以外で非公開でない場合
			if ($objDac->fld['work_class'] != WORK_CLASS_NEW && $objDac->fld['close_flg'] == FLAG_OFF) {
				$uploadPages[$objDac->fld['page_id']] = $objDac->fld['file_path'];
			}
		}
		
		if ($continue_flg == FLAG_ON) continue;
		
		// 関連ファイル
		$aryExclusive = array();
		$objLinks->selectExclusive($fld['page_id'], PUBLISH_TABLE);
		while ($objLinks->fetch()) {
			if ($objLinks->fld['path'] == '') continue;
			$aryExclusive[] = $objLinks->fld['path'];
		}
		$objImages->selectExclusive($fld['page_id'], PUBLISH_TABLE);
		while ($objImages->fetch()) {
			if ($objImages->fld['src'] == '') continue;
			$aryExclusive[] = $objImages->fld['src'];
		}
		
		// 削除の場合
		if ($fld['w_close_flg'] == FLAG_OFF && $close_upload == FLAG_OFF) {
			// ゴミ箱フォルダに一時保存
			if (ENABLE_OPTION_TRASH == true && $delete_flg == FLAG_ON) {
				if (!putToRecycleBin($fld)) {
					errorWrite('ゴミ箱にページ情報が保存できませんでした。【' . $fld['page_id'] . '】');
				}
			}
			// ページ情報の削除
			if (!$objPage2->deleteFromPageID($fld['page_id'], PUBLISH_TABLE)) {
				create_error('公開ページ情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// リンク情報の削除
			if (!$objLinks->deleteFromPageID($fld['page_id'], PUBLISH_TABLE)) {
				create_error('公開リンク情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// 画像情報の削除
			if (!$objImages->deleteFromPageID($fld['page_id'], PUBLISH_TABLE)) {
				create_error('公開画像情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// ライブラリの削除
			if (!$objHandler->deleteLibrary($fld['page_id'], PUBLISH_TABLE)) {
				create_error('公開ライブラリ設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// RSSファイルの削除
			$allDeletePages[] = $fld['page_id'];
			deleteRss($fld, $ftpCnc);
			// 広告情報の削除
			if (!$objHandler->deleteAdvertPage($fld['page_id'], PUBLISH_TABLE)) {
				create_error('公開広告設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// お問い合わせ情報の削除
			if (!$objInquiry->deleteFromID($fld['w_inquiry_id'], PUBLISH_TABLE)) {
				create_error('公開お問い合わせ情報の削除に失敗しました。<br>【' . $fld['w_inquiry_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// 観光情報の削除
			if (!$objKanko->deleteFromID($fld['page_id'], '', PUBLISH_TABLE)) {
				create_error('公開観光情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// カテゴリテーブルからFAQ情報の削除
			if ($faqListPageFLG == FLAG_ON) {
				// FAQ一覧ページ情報の削除
				$faqCateUpdate["faqpage_id"] = "";
				// カテゴリテーブル更新
				if ($objCate->update($faqCateUpdate) == FALSE) {
					create_error('分類情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
			}
			// アンケート
			if ($fld['template_kind'] == TEMPLATE_KIND_ENQUETE) {
				// アンケートの登録、削除
				$p_enq_id_ary = $objEnq->getEnqueteId($fld['page_id'], PUBLISH_TABLE);
				$objEnq->add_where("page_id", $fld['page_id']);
				if (!$objEnq->delete("", PUBLISH_TABLE)) {
					create_error('公開アンケート情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				foreach ($p_enq_id_ary as $enq_id) {
					$objEnqDtl->add_where("enquete_id", $enq_id);
					if (!$objEnqDtl->delete("", PUBLISH_TABLE)) {
						create_error('公開アンケート詳細情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						continue 2;
					}
				}
			}
			//地図情報の削除
			if (ENABLE_OPTION_GOOGLEMAP) {
				if (!$objMap->deleteFromPID($fld['page_id'], PUBLISH_TABLE)) {
					create_error('地図情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
			}
			// ローカルナビを使用しているページ情報の登録、削除
			if (!$objGHandler->delete_lnavi_page($fld['page_id'], PUBLISH_TABLE)) {
				create_error('ローカルナビ情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// サイトマップを使用しているページ情報の削除
			if (!$objSitemapHandler->delete_entry_page($fld['page_id'], PUBLISH_TABLE)) {
				create_error('サイトマップ設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// 緊急情報　紐付け情報削除
			if (!deleteDisasterPage($fld['page_id'])) {
				create_error('緊急情報ページ情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// 大規模災害用分類一覧ページ作成情報の削除
			if (!deleteDisasterListPage($fld['page_id'])) {
				create_error('大規模災害用分類一覧ページ作成情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// 大規模災害用分類一覧ページ紐付け情報の削除
			if (!deleteDisasterListTop($fld['page_id'], PUBLISH_TABLE)) {
				create_error('公開大規模災害用分類一覧ページ情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			
			// イベントカレンダー複数日
			if (EVENT_CAL_MULTI_FLAG) {
				// イベントカレンダー複数日対応
				// 開催期間情報の削除
				if (!$obj_event->delete($fld['page_id'], PUBLISH_TABLE)) {
					create_error('開催期間の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
			}
			// オープンデータ
			// オープンデータ編集情報の削除
			if (ENABLE_OPEN_DATA_FLG && !$obj_open_data_edit->deleteFromID($fld['page_id'], '', '', '', PUBLISH_TABLE)) {
				create_error('オープンデータ編集情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
		}
		else {
			$ary = array(
					'page_id' => $fld['page_id'], 
					'work_class' => WORK_CLASS_PUBLISH, 
					'status' => STATUS_PUBLISH, 
					'close_flg' => FLAG_ON, 
					'bak_status' => ''
			);
			if ($close_upload == FLAG_ON) {
				// 自動非公開
				// tbl_work_page の確認
				if ($objPage2->selectFromID($fld['page_id'], WORK_TABLE) !== FALSE) {
					// ワークページの非公開フラグをオン
					$temp_ary = array(
							'page_id' => $fld['page_id'], 
							'close_flg' => FLAG_ON
					);
					$objPage2->update($temp_ary, WORK_TABLE);
					// 編集中ならステータスを保持
					$ary['status'] = $objPage2->fld['status'];
					$ary['bak_status'] = STATUS_PUBLISH;
				}
			}
			$objPage2->update($ary, PUBLISH_TABLE);
		}
		// 自動非公開以外の場合（自動非公開の場合、WORK_TABLEに対して処理を行わない）
		if ($close_upload == FLAG_OFF) {
			if (!$objPage2->deleteFromPageID($fld['page_id'], WORK_TABLE)) {
				create_error('編集ページ情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			if (!$objLinks->deleteFromPageID($fld['page_id'], WORK_TABLE)) {
				create_error('編集リンク情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			if (!$objImages->deleteFromPageID($fld['page_id'], WORK_TABLE)) {
				create_error('編集画像情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			if (!$objHandler->deleteLibrary($fld['page_id'], WORK_TABLE)) {
				create_error('編集ライブラリ設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			if (!$objHandler->deleteAutoLink($fld['page_id'], WORK_TABLE)) {
				create_error('編集自動リンク設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			if (!$objHandler->deleteAutoLinkPage($fld['page_id'], WORK_TABLE)) {
				create_error('編集自動リンク設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// 広告情報の削除
			if (!$objHandler->deleteAdvertPage($fld['page_id'], WORK_TABLE)) {
				create_error('編集広告設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			if (!$objInquiry->deleteFromID($fld['w_inquiry_id'], WORK_TABLE)) {
				create_error('編集お問い合わせ情報の削除に失敗しました。<br>【' . $fld['w_inquiry_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			if ($objCGrp->deleteFromID($fld['w_group_id']) === FALSE) {
				create_error('承認グループの削除に失敗しました。<br>【' . $fld['w_group_id'] . '】', $cronFlg, $objCnc, $ftpCnc, $fld['w_page_title']);
				continue;
			}
			if (!$objKanko->deleteFromID($fld['page_id'], '', WORK_TABLE)) {
				create_error('編集観光情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// アンケート
			if ($fld['template_kind'] == TEMPLATE_KIND_ENQUETE) {
				// アンケートの登録、削除
				$w_enq_id_ary = $objEnq->getEnqueteId($fld['page_id'], WORK_TABLE);
				$objEnq->add_where("page_id", $fld['page_id']);
				if (!$objEnq->delete("", WORK_TABLE)) {
					create_error('編集アンケート情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				foreach ($w_enq_id_ary as $enq_id) {
					$objEnqDtl->add_where("enquete_id", $enq_id);
					if (!$objEnqDtl->delete("", WORK_TABLE)) {
						create_error('編集アンケート詳細情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						continue 2;
					}
				}
			}
			//地図情報の削除
			if (ENABLE_OPTION_GOOGLEMAP) {
				if (!$objMap->deleteFromPID($fld['page_id'], WORK_TABLE)) {
					create_error('地図情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
			}
			// ローカルナビを使用しているページ情報の登録、削除
			if (!$objGHandler->delete_lnavi_page($fld['page_id'], WORK_TABLE)) {
				create_error('編集ローカルナビ情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// 否認理由のひも付け削除
			if (!$objAppHandler->delete_denial_msg($fld['page_id'])) {
				create_error('前回の否認理由の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// サイトマップを使用しているページ情報の削除
			if (!$objSitemapHandler->delete_entry_page($fld['page_id'], WORK_TABLE)) {
				create_error('サイトマップ設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// 大規模災害用分類一覧ページ紐付け情報の削除
			if (!deleteDisasterListTop($fld['page_id'], WORK_TABLE)) {
				create_error('編集大規模災害用分類一覧ページ情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// オープンデータ
			// オープンデータ編集情報の削除
			if (ENABLE_OPEN_DATA_FLG && !$obj_open_data_edit->deleteFromID($fld['page_id'], '', '', '', WORK_TABLE)) {
				create_error('オープンデータ編集情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
		}
		// サイトマップから情報を削除
		if (!update_sitemap_delete_page($fld['page_id'], $fld['w_parent_id'], $errmsg)) {
			create_error($errmsg, $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		
		require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_auto_link_pages.inc');
		$objAlp = new tbl_auto_link_pages($objCnc);
		$objAlp->selectFromPID($fld['page_id']);
		while ($objAlp->fetch()) {
			if (in_array($objAlp->fld['a_link_id'], $allUploadPages)) continue;
			$objHandler->selectAutoLinkPageFromAlinkID($objAlp->fld['a_link_id']);
			while ($objHandler->fetch()) {
				if (in_array($objHandler->fld['item1'], $allUploadPages)) continue;
				$allUploadPages[] = $objHandler->fld['item1'];
			}
		}
		
		// ローカルナビを使用している親、兄弟、子ページをチェック
		$lnavi_page_id_ary = check_lnavi_page($fld['page_id'], "close");
		foreach ($lnavi_page_id_ary as $lnavi_page_id) {
			$allUploadPages[] = $lnavi_page_id;
		}
		
		// ページの非公開・削除により、リンク切れとなるリンクのaタグを削除
		if (UPLOAD_DEL_A_TAGS_FLG) {
			if (delete_a_tags_del_link($fld, $uploadPages, $errmsg) === FALSE) {
				create_error('リンク切れとなるaタグの削除に失敗しました。<br>【' . $fld['page_id'] . '】' . $errmsg, $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
		}
		
		// ページの生成＋アップロード（パンくず変更のページ）
		$u_cnt = 0;
		$uploadPages = array_unique($uploadPages);
		if (!$cronFlg && count($uploadPages) > 0) $pgrs_func->send_msg("関連するページを処理中です。");
		foreach ($uploadPages as $pid => $path) {
			// ページ出力設定チェック
			if (is_output_html($pid) === FALSE) continue;
			create_html($pid, $path, $objCnc, $ftpCnc, $errmsg, $cronFlg);
			if (!$cronFlg) $pgrs_func->progress(++$u_cnt, count($uploadPages));
		}
		if (!$cronFlg && count($uploadPages) > 0) $pgrs_func->send_msg("公開処理中です。");
		
		// CMS内の関連ファイルの削除
		$deleteReration = array();
		$temp_ary = array(
			"item1" => $fld['page_id']
		);
		$objHandler->_select(HANDLER_CLASS_PUBLISH_DELETE_FILE, $temp_ary, "item2");
		while ($objHandler->fetch()) {
			$deleteReration[] = $objHandler->fld;
		}
		// 
		$objEnq = new tbl_enquete($objCnc);
		$error_msg = "";
		foreach ($deleteReration as $info) {
			// 関連ファイルのパス
			$path = $info['item2'];
			// ページで使用されている場合は無視
			if ($objLinks->useLinkFileCheck($path, PUBLISH_TABLE) === FALSE) {
				continue;
			}
			if ($objLinks->useLinkFileCheck($path, WORK_TABLE) === FALSE) {
				continue;
			}
			if ($objImages->useImageCheck($path, PUBLISH_TABLE) === FALSE) {
				continue;
			}
			if ($objImages->useImageCheck($path, WORK_TABLE) === FALSE) {
				continue;
			}
			// アンケートで使用されている場合は無視
			$objEnq->add_where("img_src", $path, "LIKE");
			$objEnq->setTableName(PUBLISH_TABLE);
			$objEnq->select();
			if ($objEnq->getRowCount() > 0) continue;
			$objEnq->add_where("img_src", $path, "LIKE");
			$objEnq->setTableName(WORK_TABLE);
			$objEnq->select();
			if ($objEnq->getRowCount() > 0) continue;
			
			// 定型情報（公開）
			if ($objKanko->checkUseFiles($path, PUBLISH_TABLE)) continue;
			
			// 定型情報（編集）
			if ($objKanko->checkUseFiles($path, WORK_TABLE)) continue;
			
			// 情報の削除
			if (!$objHandler->deletePublishDeleteFilePath($path)) {
				create_error('関連ファイル情報の削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			// FCKテーブルの情報削除
			if (!$objFCKLinks->deleteFromPageID($path)) {
				create_error('ファイル情報の削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			if (!$objFCKImages->deleteFromImagePath($path)) {
				create_error('画像情報の削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			// ファイルが存在すれば削除
			if (@is_file(DOCUMENT_ROOT . RPW . $path) && !@unlink(DOCUMENT_ROOT . RPW . $path)) {
				create_error('関連ファイルの削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			// ファイルが存在すれば削除
			if (@is_file(DOCUMENT_ROOT . RPR . $path) && !@unlink(DOCUMENT_ROOT . RPR . $path)) {
				create_error('関連ファイルの削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			// 公開先からも削除
			if (FTP_UPLOAD_FLG) @deleteFile_ftp($ftpCnc, FTP_ROOT_DIR . $path);
		}
		if ($continue_flg == FLAG_ON) continue;
		
		// ページで保存した削除関連ファイル情報の削除
		if (!$objHandler->deletePublishDeleteFile($fld['page_id'])) {
			create_error('関連ファイル情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			$continue_flg = FLAG_ON;
			break;
		}
		if ($continue_flg == FLAG_ON) continue;
		
		// 関連ファイルの削除
		foreach ($aryExclusive as $path) {
			if (@is_file(DOCUMENT_ROOT . RPR . $path) && !@unlink(DOCUMENT_ROOT . RPR . $path)) {
				create_error('関連ファイルの削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			if (FTP_UPLOAD_FLG) deleteFile_ftp($ftpCnc, FTP_ROOT_DIR . $path);
			
		}
		if ($continue_flg == FLAG_ON) continue;
		
		// 削除するページのファイルパス（公開側）
		$delete_real_file_path = $fld['p_file_path'];
		// 大規模災害状態、かつ大規模災害元ページの非公開の場合
		if ($is_disaster_flg && $delete_flg == FLAG_OFF && $disaster_page_id != $fld['page_id']) {
			$delete_real_file_path = $disaster_file_path;
		}
		
		// ファイルの削除
		if (@file_exists(DOCUMENT_ROOT . RPR . $delete_real_file_path) && !@unlink(DOCUMENT_ROOT . RPR . $delete_real_file_path)) {
			create_error('公開用HTMLファイルの削除に失敗しました。<br>【' . $delete_real_file_path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		//非公開でない場合
		if ($fld['w_close_flg'] == FLAG_OFF && $close_upload == FLAG_OFF) {
			if (@file_exists(DOCUMENT_ROOT . RPW . $fld['p_file_path']) && !@unlink(DOCUMENT_ROOT . RPW . $fld['p_file_path'])) {
				create_error('作業用HTMLファイルの削除に失敗しました。<br>【' . $fld['p_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
		}
		if (FTP_UPLOAD_FLG) deleteFile_ftp($ftpCnc, FTP_ROOT_DIR . $delete_real_file_path);
		
		if ($objTool->selectTemplate($fld['template_id']) !== FALSE) {
			if ($objTool->fld['mobile_temp_txt'] != "") {
				//非公開でない場合
				if ($fld['w_close_flg'] == FLAG_OFF && $close_upload == FLAG_OFF) {
					if (@file_exists(DOCUMENT_ROOT . RPW . DIR_PATH_MOBILE . $fld['p_file_path']) && !@unlink(DOCUMENT_ROOT . RPW . DIR_PATH_MOBILE . $fld['p_file_path'])) {
						create_error('作業用HTMLファイルの削除に失敗しました。<br>【' . DIR_PATH_MOBILE . $fld['p_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						continue;
					}
				}
				// ファイルの削除
				if (@file_exists(DOCUMENT_ROOT . RPR . DIR_PATH_MOBILE . $delete_real_file_path) && !@unlink(DOCUMENT_ROOT . RPR . DIR_PATH_MOBILE . $delete_real_file_path)) {
					create_error('公開用HTMLファイルの削除に失敗しました。<br>【' . DIR_PATH_MOBILE . $delete_real_file_path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				if (FTP_UPLOAD_FLG) deleteFile_ftp($ftpCnc, FTP_ROOT_DIR . DIR_PATH_MOBILE . $delete_real_file_path);
			}
		}
		
		// イベントカレンダー定型対応追加　---------
		$format_tbl_name = (isFixed($fld)) ? getTableName($fld['template_id']) : "";
		$KANKO_XML_TYPE = getDefineArray('KANKO_XML_TYPE');
		//観光
		if (isFixed($fld)) {
			// イベント
			if ($objTool->selectTemplateKankoType($fld['template_id']) == KANKO_TYPE_EVENT && $format_tbl_name == KANKO_XML_TYPE_CSV) {
				// イベントカレンダー複数日
				if (EVENT_CAL_MULTI_FLAG) {
					// CSV対象年月格納用配列
					$target_open_date = array();
					// 作業用配列
					$open_start_ary = array();
					$open_end_ary = array();
					
					// 編集開催期間が存在する場合
					if (!empty($open_start_w[$fld['page_id']])) {
						$open_start_ary = $open_start_w;
						$open_end_ary = $open_end_w;
					}
					// 編集開催期間が存在せず、公開開催期間が存在する場合(自動非公開等)
					else if (!empty($open_start_p[$fld['page_id']])) {
						$open_start_ary = $open_start_p;
						$open_end_ary = $open_end_p;
					}
					// 編集開催期間・公開開催期間ともに存在しない場合、エラーを出力
					else {
						create_error('イベント開催期間取得に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
						continue;
					}
					
					// 開始日と終了日対で取得
					foreach ($open_start_ary[$fld['page_id']] as $open_date_num => $open_start_date) {
						// 開催開始日のチェック
						if (empty($open_start_date)) {
							create_error('イベント開催開始日の取得に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
							$continue_flg = FLAG_ON;
							break;
						}
						// 開催開始日を分割
						$match_open_start = preg_split('/\W/', $open_start_date);
						if (in_array($open_start_date, $match_open_start)) {
							// マッチングに失敗した場合
							create_error('イベント開催期間の取得に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
							$continue_flg = FLAG_ON;
							break;
						}
						// 開催開始日のチェック
						if (checkdate($match_open_start[1], $match_open_start[2], $match_open_start[0]) == FALSE) {
							create_error('イベント開催開始日の指定が正しくありません。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
							$continue_flg = FLAG_ON;
							break;
						}
						// 開催終了日が指定されていない場合
						if (empty($open_end_ary[$fld['page_id']][$open_date_num])) {
							// CSV対象年月格納用配列に含まれていなければ、CSV対象年月格納用配列に格納
							if (!in_array($match_open_start[0] . $match_open_start[1] . '01', $target_open_date)) {
								$target_open_date[] = $match_open_start[0] . $match_open_start[1] . '01';
							}
						}
						// 開催終了日が指定されている場合
						else {
							// 開催終了日を分割
							$match_open_end = preg_split('/\W/', $open_end_ary[$fld['page_id']][$open_date_num]);
							if (in_array($open_end_ary[$fld['page_id']][$open_date_num], $match_open_end)) {
								// マッチングに失敗した場合
								create_error('イベント開催期間の取得に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
								$continue_flg = FLAG_ON;
								break;
							}
							// 年のカウンタ
							$year_cnt = (int)$match_open_start[0];
							// 月のカウンタ
							$month_cnt = (int)$match_open_start[1];
							// 年月が終了日を超えていない場合
							while (($year_cnt < (int)$match_open_end[0]) || ($year_cnt == (int)$match_open_end[0] && $month_cnt <= (int)$match_open_end[1])) {
								// CSV対象年月格納用配列に含まれていなければ、CSV対象年月格納用配列に格納
								if (in_array(sprintf('%04d%02d01', $year_cnt, $month_cnt), $target_open_date) == FALSE) {
									$target_open_date[] = sprintf('%04d%02d01', $year_cnt, $month_cnt);
								}
								// カウントアップ
								$month_cnt++;
								if ($month_cnt > 12) {
									$year_cnt++;
									$month_cnt = 1;
								}
							}
						}
					}
					// フラグがONの場合次処理ページへ
					if ($continue_flg == FLAG_ON) {
						continue;
					}
					// CSVを出力する
					if (_createEventCsvMulti($objCnc, $fld['w_page_title'], $target_open_date, $cronFlg, $fld, $fld['template_id']) === FALSE) {
						continue;
					}
				}
				// イベントカレンダー単一日
				else {
					// イベントの場合はCSVを出力する。
					if (_createEventCsv($objCnc, $fld['w_page_title'], $fld['w_open_start'], $fld['w_open_end'], $cronFlg) === FALSE) continue;
				}
			}
			else if ($objFAQ->targetCheckFAQ($fld['template_id']) !== FALSE) {
				// FAQページの場合はFAQ情報を更新する(掲載済みフラグをオフ)
				if (publishRegFAQ($fld['page_id'], 'del', $faq_id) === FALSE) {
					create_error('FAQ情報の更新に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
			}
			//FLASH動画
			else if ($objTool->selectTemplateKankoType($fld['template_id']) == KANKO_TYPE_FLASH_VIDEO) {
				//FLASHデータを削除
				if (ftpFlashData($ftpCnc, 2, $fld) === FALSE) {
					//エラー処理
					create_error('FTPサーバの動画ファイル削除に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
			}
			else {
				//観光情報の場合は検索用テーブルから削除
				if (syncKankoDataToDB(2, $fld) === FALSE) {
					//エラー処理
					create_error('観光検索用データベースの削除に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				if (syncThumbnail(2, $fld, $ftpCnc) === FALSE) {
					//エラー処理
					create_error('サムネイル削除処理に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				//非公開でない場合
				if ($fld['w_close_flg'] == FLAG_OFF && $close_upload == FLAG_OFF) {
					//CMS内のサムネイル画像を削除する
					if (deleteThumbnail_CMS($fld['page_id']) === FALSE) {
						//エラー処理
						create_error('サムネイル削除処理に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
						continue;
					}
				}
			}
			// イベントカレンダー定型対応追加　---------
		}
		
		if ($fld['template_kind'] == TEMPLATE_KIND_ENQUETE) {
			//非公開でない場合
			if ($fld['w_close_flg'] == FLAG_OFF && $close_upload == FLAG_OFF) {
				$objEnq->add_where("page_id", $fld['page_id']);
				$objEnq->delete("", PUBLISH_TABLE);
			}
			$ftpDataCnc = connectFTP("enquete");
			if ($fld['w_enquete_kind'] == ENQ_KIND_CGI) {
				if ($fld['w_close_flg'] == FLAG_OFF && $close_upload == FLAG_OFF) {
					@unlink(DOCUMENT_ROOT . DIR_PATH_ENQUETECSV . $fld['page_id'] . ".csv");
					if (FTP_UPLOAD_FLG) cx_ftp_delete($ftpDataCnc, FTP_ROOT_DIR_ENQUETE . "/" . $fld['page_id'] . ".csv");
				}
			}
			
			if ($fld['w_close_flg'] == FLAG_OFF && $fld['w_enquete_kind'] == ENQ_KIND_MAIL && $close_upload == FLAG_OFF) {
				// メールの場合は送信先指定を記述したファイルを削除
				@unlink(DOCUMENT_ROOT . DIR_PATH_TEMP . $fld['page_id'] . ".dat");
				// 公開側に保存された回答CSV一覧を取得
				if (FTP_UPLOAD_FLG && ($ftp_files = cx_ftp_nlist($ftpDataCnc, FTP_MAIL_CSV_DIR_ENQUETE . "/" . $fld['page_id'])) !== FALSE) {
					// 全て削除
					foreach ((array) $ftp_files as $ftp_path)
						cx_ftp_delete($ftpDataCnc, $ftp_path);
				}
				// ページIDフォルダを削除
				if (FTP_UPLOAD_FLG) cx_ftp_rmdir($ftpDataCnc, FTP_MAIL_CSV_DIR_ENQUETE . "/" . $fld['page_id']);
			}
			$ftp_path = FTP_MAIL_CSV_DIR_ENQUETE . "/" . $fld['page_id'] . ".dat";
			if (FTP_UPLOAD_FLG) cx_ftp_delete($ftpDataCnc, $ftp_path);
		}
		
		//施設情報
		if (isFixed($fld) && $objTool->selectTemplateKankoType($fld['template_id']) == KANKO_TYPE_WELFARE) {
			//地図情報の使用の有無チェック
			if (ENABLE_OPTION_GOOGLEMAP && MAP_DATA_CSV_FLG) {
				//CSVの作成・アップロード処理
				if (!map_data_csv($ftpCnc)) {
					create_error('地図関連ファイルの更新に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
			}
		}
		
		// オープンデータ
		// オープンデータ 公開側DB同期処理
		if (ENABLE_OPEN_DATA_FLG && !syncOpenDataDB(2, $fld['page_id'])) {
			create_error('オープンデータ情報の同期に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		
		// 外部連携自動出力機能
		if (ENABLE_OPTION_OUTPUT && isset($fld['template_id'])) {
			// 外部連携自動出力用にテンプレートIDを保持
			if (!in_array($fld['template_id'], $_SESSION['template_id_of_output_page'])) {
				$_SESSION['template_id_of_output_page'][] = $fld['template_id'];
			}
		}
		
		// メール送信（リンク切れ）TO:リンク切れが起こるページの作成者
		if (MAIL_FLG_DELLINK) {
			// リンク切れが起こるページの情報を取得
			$sql = "SELECT u.name,u.dept_name,u.email, p.page_title,p.file_path" . " FROM tbl_publish_links AS l" . " INNER JOIN tbl_publish_page AS p ON(p.page_id = l.page_id)" . " INNER JOIN tbl_user AS u ON (u.user_id = p.user_id)" . " WHERE l.outer_flg = 0 AND l.path = '" . gd_addslashes($fld['p_file_path']) . "'";
			if ($objDac->execute($sql)) {
				if ($fld['w_close_flg'] == FLAG_OFF && $close_upload == FLAG_OFF) {
					$mode_name = "削除";
				}
				else {
					$mode_name = "非公開";
				}
				while ($objDac->fetch()) {
					// ---メール本文作成用配列
					$mail_fld = array();
					$dellink_fld = $objDac->fld;
					$mail_fld['url'] = HTTP_REAL_ROOT;
					$mail_fld['cms_url'] = HTTP_ROOT . RPW;
					$mail_fld['now_date'] = date('Y-m-d H:i:s'); //現在日付
					$mail_fld['dept_name'] = $dellink_fld['dept_name']; //送信先組織名
					$mail_fld['user_name'] = $dellink_fld['name']; //送信先ユーザ名
					$mail_fld['mode_name'] = $mode_name; //削除｜非公開
					$mail_fld['page_title'] = $fld['p_page_title']; //対象ページタイトル
					$mail_fld['file_path'] = $fld['p_file_path']; //対象ページファイルパス
					$mail_fld['dellink_page_title'] = $dellink_fld['page_title']; //リンク切れの起こるページタイトル
					$mail_fld['dellink_file_path'] = $dellink_fld['file_path']; //リンク切れの起こるページファイルパス
					$head = get_mail_str($mail_fld, MAIL_SUBJECT_DELLINK);
					$body = get_mail_str($mail_fld, MAIL_BODY_DELLINK);
					if (!send_mail($dellink_fld['email'], MAIL_ADDR_FROM, $head, $body)) {
						create_error('メール送信に失敗しました。<br>To:' . $dellink_fld['email'], $cronFlg, $objCnc, $fld['w_page_title']);
						$continue_flg = FLAG_ON;
						break;
					}
				}
				if ($continue_flg == FLAG_ON) continue;
			}
		}
		if ($fld['w_close_flg'] == FLAG_OFF && $close_upload == FLAG_OFF) {
			$success_list[$fld['page_id'] . ":" . $fld['p_page_title']] = '削除に成功しました。<br>【' . preg_replace('/\/+/i', '/', FTP_ROOT_DIR . $fld['p_file_path']) . '】';
		}
		else {
			$success_list[$fld['page_id'] . ":" . $fld['p_page_title']] = '非公開に成功しました。<br>【' . preg_replace('/\/+/i', '/', FTP_ROOT_DIR . $fld['p_file_path']) . '】';
		}
	}
	// 新規・更新
	else {
		$uploadPages[$fld['page_id']] = $fld['w_file_path'];
		// 大規模災害状態の場合、かつ大規模災害ページが新規公開された場合
		if ($fld['work_class'] == WORK_CLASS_NEW && $is_disaster_flg) {
			// 元ページ情報を関連公開ページに追加
			if ($disaster_base_page_id != $fld['page_id']) {
				$allUploadPages[] = $disaster_base_page_id;
			}
		}
		// 保存先が変更されたとき、ぱんくず、編集領域を修正
		if ($fld['p_file_path'] != $fld['w_file_path'] && (!$objPage2->selectFromPath($fld['w_file_path'], PUBLISH_TABLE) || strtolower($fld['p_file_path']) == strtolower($fld['w_file_path']))) {
			// リンク情報、編集領域の修正
			$tbl_ary = array(
					WORK_TABLE, 
					PUBLISH_TABLE
			);
			foreach ($tbl_ary as $tbl) {
				// 公開・編集リンク情報更新
				$rep_page_id_ary = array();
				$link_tbl = ($tbl == PUBLISH_TABLE) ? "tbl_publish_links" : "tbl_work_links";
				$objBDac = new b_dac($objCnc, $link_tbl, "page_id");
				$objBDac->add_where("path", $fld['p_file_path']);
				$objBDac->select();
				while ($objBDac->fetch()) {
					$rep_page_id_ary[] = $objBDac->fld['page_id'];
					$u_ary = $objBDac->fld;
					$u_ary["path"] = $fld['w_file_path'];
					$objLinks->setTableName($link_tbl);
					if ($objLinks->update($u_ary) === FALSE) {
						create_error('リンク情報の更新に失敗しました。<br>【' . $objBDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						$continue_flg = FLAG_ON;
						break 2;
					}
				}
				
				// 公開・編集定型情報更新
				$fixed_tbl = ($tbl == PUBLISH_TABLE) ? "tbl_publish_kanko" : "tbl_work_kanko";
				$objBDac = new b_dac($objCnc, $fixed_tbl, "page_id");
				
				// 定型タイプが「cutomarea」のcontext内href抽出用正規表現の定義
				$reg_href_kanko = '(\"|\')?(' . reg_replace(RPW) . ')?(' . reg_replace($fld['p_file_path']) . ')(\"|\')?';
				
				// 定型タイプが「link」または「file」のcontextの内容に対象のファイルパスが存在する場合※「/cms8341」が先頭にある場合、ない場合ともに対象とする
				$where = '((';
				$where .= $objBDac->_addslashesC('type', 'link');
				$where .= ' OR ';
				$where .= $objBDac->_addslashesC('type', 'file');
				$where .= ') AND (';
				$where .= $objBDac->_addslashesC('context', RPW . $fld['p_file_path'] . KANKO_LINK_DELIMITER . '%', 'LIKE');
				$where .= ' OR ';
				$where .= $objBDac->_addslashesC('context', $fld['p_file_path'] . KANKO_LINK_DELIMITER . '%', 'LIKE');
				$where .= '))';
				
				// または、定型タイプ「customarea」のcontext内にhrefの対象ファイルパスがある場合
				$where .= ' OR (';
				$where .= $objBDac->_addslashesC('type', 'customarea');
				$where .= ' AND ';
				$where .= $objBDac->_addslashesC('context', 'href[[:space:]]*=[[:space:]]*' . $reg_href_kanko, 'REGEXP', 'TEXT');
				$where .= ')';
				$objBDac->where[] = $where;
				
				$objBDac->select();
				while ($objBDac->fetch()) {
					$rep_page_id_ary[] = $objBDac->fld['page_id'];
					$u_ary = $objBDac->fld;
					// 変更前のパスを変更後に変換する※「/cms8341」が先頭にある場合、ない場合ともに変換する
					
					// 定型タイプが「customarea」の場合、href抽出用正規表現でヒットした箇所を変更後の値に置き換える
					if ($u_ary['type'] == 'customarea') {
						$u_ary['context'] = preg_replace('/href(\s)*=(\s)*' . $reg_href_kanko . '/i', 'href="' . $fld['w_file_path'] . '"', $u_ary['context']);
						
					}
					// 定型タイプが「link」や「file」の場合、以下を処理
					else {
						$u_ary['context'] = preg_replace('/^(' . reg_replace(RPW) . ')?' . reg_replace($fld['p_file_path'] . KANKO_LINK_DELIMITER) . '/', RPW . $fld['w_file_path'] . KANKO_LINK_DELIMITER, $u_ary['context']);
					}
					
					if ($objKanko->update($u_ary, $fixed_tbl) === FALSE) {
						create_error('定型情報のリンクの更新に失敗しました。<br>【' . $objBDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						$continue_flg = FLAG_ON;
						break 2;
					}
				}
				
				// 更新するページがなければ飛ばす
				if (count($rep_page_id_ary) == 0) continue;
				
				// 公開・編集　FCK領域更新
				$rep_page_id_ary = array_unique($rep_page_id_ary);
				$page_tbl = ($tbl == PUBLISH_TABLE) ? "tbl_publish_page" : "tbl_work_page";
				$objBDacTran = new b_dac($objCnc, $page_tbl, "page_id");
				$objBDac = new b_dac($objCnc, $page_tbl, "page_id");
				$objBDac->add_where("page_id", implode(",", $rep_page_id_ary), "IN");
				$objBDac->select();
				while ($objBDac->fetch()) {
					// 編集領域内のリンクを修正
					$reg_href = 'href="(' . reg_replace(HTTP_ROOT . RPW) . '|' . reg_replace(HTTP_ROOT . RPR) . ')?' . reg_replace($fld['p_file_path']) . '([^\"]+)?"';
					$context = preg_replace('/' . $reg_href . '/', 'href="' . $fld['w_file_path'] . '$2"', $objBDac->fld['context']);
					$ary = array(
							'page_id' => $objBDac->fld['page_id'], 
							'context' => $context
					);
					$objBDacTran->where = array();
					if (!$objBDacTran->update($ary)) {
						create_error('FCK領域の更新に失敗しました。<br>【' . $objBDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						$continue_flg = FLAG_ON;
						break 2;
					}
					if ($tbl == PUBLISH_TABLE && $objBDac->fld['work_class'] != WORK_CLASS_NEW && $objBDac->fld['close_flg'] == FLAG_OFF) {
						$uploadPages[$objBDac->fld['page_id']] = $objBDac->fld['file_path'];
					}
				}
			}
			if ($continue_flg == FLAG_ON) continue;
			
			// パンくずの更新
			$objBDacTran = new b_dac($objCnc, "tbl_publish_page", "page_id");
			$where = "ancestor_path REGEXP '^(.*,)?" . $fld['p_file_path'] . "(,.*)?$'";
			$fields = "page_id, ancestor_path, work_class, close_flg, file_path";
			$objDac->setTableName('tbl_publish_page');
			$objDac->select($where, $fields);
			while ($objDac->fetch()) {
				$reg_path = reg_replace($fld['p_file_path']);
				$ancestor_path = $objDac->fld['ancestor_path'];
				$ancestor_path = preg_replace('/^' . $reg_path . '/', $fld['w_file_path'], $ancestor_path);
				$ancestor_path = preg_replace('/,' . $reg_path . '/', ',' . $fld['w_file_path'], $ancestor_path);
				// パスの先頭に「,」が存在したら削除する
				$ancestor_path = preg_replace("/^(,)*/", '', $ancestor_path);
				// パスの末端に「,」が存在したら削除する
				$ancestor_path = preg_replace("/(,)*$/", '', $ancestor_path);
				$ary = array(
						'page_id' => $objDac->fld['page_id'], 
						'ancestor_path' => $ancestor_path
				);
				$objBDacTran->where = array();
				if (!$objBDacTran->update($ary)) {
					create_error('パンくずの更新に失敗しました。<br>【' . $objDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					$continue_flg = FLAG_ON;
					break;
				}
				if ($objDac->fld['work_class'] != WORK_CLASS_NEW && $objDac->fld['close_flg'] == FLAG_OFF) {
					$uploadPages[$objDac->fld['page_id']] = $objDac->fld['file_path'];
				}
			}
			if ($continue_flg == FLAG_ON) continue;
		}
		// 親ページが変更されたとき、ancestor_pathを更新
		if ($fld['w_parent_id'] != $fld['p_parent_id']) {
			$fields = "file_path, ancestor_path";
			//親ページを更新した場合
			if ($objPage2->selectFromID($fld['w_parent_id'], PUBLISH_TABLE, $fields) !== FALSE) {
				if (preg_match("/(^|,)" . reg_replace($fld['w_file_path']) . "(,|$)/", $objPage2->fld['ancestor_path'])) {
					create_error('親ページに自身のページを含んでいるため、設定に失敗しました。<br>【' . $fld['w_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				$w_ancestor_path = $objPage2->fld['ancestor_path'];
				if ($w_ancestor_path != '') $w_ancestor_path .= ",";
				$w_ancestor_path .= $objPage2->fld['file_path'];
				$ary = array(
						'page_id' => $fld['page_id']
				);
				if (($ary['menu_generation_order'] = $objPage2->getNextMenuGenerationOrder($fld['w_parent_id'])) === FALSE) {
					create_error('メニュー生成順の取得に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				if (!$objPage2->update($ary, WORK_TABLE)) {
					create_error('メニュー生成順の更新に失敗しました。<br>【' . $objDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				$ary['parent_id'] = $fld['w_parent_id'];
				$ary['ancestor_path'] = $w_ancestor_path;
				if (!$objPage2->update($ary, PUBLISH_TABLE)) {
					create_error('パンくず用パスの更新に失敗しました。<br>【' . $objDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				$menu_generation_order_rep = reg_replace($fld['menu_generation_order']);
				$p_menu_generation_order = $ary['menu_generation_order'];
				$w_ancestor_path .= ',' . $fld['w_file_path'];
				$p_ancestor_path = $fld['p_ancestor_path'];
				if ($p_ancestor_path != '') $p_ancestor_path .= ",";
				//					$p_ancestor_path .= ",";
				$p_ancestor_path .= $fld['w_file_path'];
				//					$where = "ancestor_path REGEXP '^".$p_ancestor_path."(,.*)?$'";
				$where = "ancestor_path REGEXP '^(,*)?" . $p_ancestor_path . "(,.*)?$'";
				$fields = "page_id, file_path, ancestor_path, work_class, close_flg, menu_generation_order";
				$orderby = "page_id";
				$objDac->setTableName('tbl_publish_page');
				$objDac->select($where, $fields, $orderby);
				while ($objDac->fetch()) {
					$ancestor_path = str_replace($p_ancestor_path, $w_ancestor_path, $objDac->fld['ancestor_path']);
					// パスの先頭に「,」が存在したら削除する
					$ancestor_path = preg_replace("/^(,)*/", '', $ancestor_path);
					// パスの末端に「,」が存在したら削除する
					$ancestor_path = preg_replace("/(,)*$/", '', $ancestor_path);
					$menu_generation_order = preg_replace("/^" . $menu_generation_order_rep . "/", $p_menu_generation_order, $objDac->fld['menu_generation_order']);
					$ary = array(
							'page_id' => $objDac->fld['page_id'], 
							'menu_generation_order' => $menu_generation_order
					);
					if (!$objPage2->update($ary, WORK_TABLE)) {
						create_error('編集ページのメニュー生成順の更新に失敗しました。 <br>【' . $objDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						$continue_flg = FLAG_ON;
						break;
					}
					$ary['ancestor_path'] = $ancestor_path;
					if (!$objPage2->update($ary, PUBLISH_TABLE)) {
						create_error('公開ページのパンくず用パスの更新に失敗しました。 <br>【' . $objDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						$continue_flg = FLAG_ON;
						break;
					}
					if ($objDac->fld['work_class'] != WORK_CLASS_NEW && $objDac->fld['close_flg'] == FLAG_OFF) $uploadPages[$objDac->fld['page_id']] = $objDac->fld['file_path'];
				}
				if ($continue_flg == FLAG_ON) continue;
			}
			//親ページを消した場合
			else {
				//アップロードするページのパンくずを変更する
				if ($fld['w_parent_id'] == NULL && $fld['p_ancestor_path'] != "") {
					$ary = array(
							'page_id' => $fld['page_id']
					);
					if (($ary['menu_generation_order'] = $objPage2->getNextMenuGenerationOrder($fld['w_parent_id'])) === FALSE) {
						create_error('メニュー生成順の取得に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						$continue_flg = FLAG_ON;
						break;
					}
					if (!$objPage2->update($ary, WORK_TABLE)) {
						create_error('メニュー生成順の更新に失敗しました。 <br>【' . $objDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						$continue_flg = FLAG_ON;
						break;
					}
					$ary['ancestor_path'] = "";
					if (!$objPage2->update($ary, PUBLISH_TABLE)) {
						create_error('公開ページのパンくず用パスの更新に失敗しました。 <br>【' . $objDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						$continue_flg = FLAG_ON;
						break;
					}
				}
				$menu_generation_order_rep = reg_replace($fld['menu_generation_order']);
				$p_menu_generation_order = (isset($ary['menu_generation_order'])) ? $ary['menu_generation_order'] : $fld['menu_generation_order'];
				//パンくずにアップロードするページが入っているもののパンくずを変更する
				$w_ancestor_path = $fld['w_file_path'];
				$where = "ancestor_path REGEXP '(^|,)" . $w_ancestor_path . "(,|$)'";
				$objDac->setTableName('tbl_publish_page');
				$objDac->select($where);
				while ($objDac->fetch()) {
					$pos = strpos($objDac->fld['ancestor_path'], $w_ancestor_path);
					$ancestor_path = substr($objDac->fld['ancestor_path'], $pos);
					// パスの先頭に「,」が存在したら削除する
					$ancestor_path = preg_replace("/^(,)*/", '', $ancestor_path);
					// パスの末端に「,」が存在したら削除する
					$ancestor_path = preg_replace("/(,)*$/", '', $ancestor_path);
					$menu_generation_order = preg_replace("/^" . $menu_generation_order_rep . "/", $p_menu_generation_order, $objDac->fld['menu_generation_order']);
					$ary = array(
							'page_id' => $objDac->fld['page_id'], 
							'menu_generation_order' => $menu_generation_order
					);
					if (!$objPage2->update($ary, WORK_TABLE)) {
						create_error('メニュー生成順の更新に失敗しました。 <br>【' . $objDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						$continue_flg = FLAG_ON;
						break;
					}
					$ary['ancestor_path'] = $ancestor_path;
					if (!$objPage2->update($ary, PUBLISH_TABLE)) {
						create_error('公開ページのパンくず用パスの更新に失敗しました。 <br>【' . $objDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						$continue_flg = FLAG_ON;
						break;
					}
					if ($objDac->fld['work_class'] != WORK_CLASS_NEW && $objDac->fld['close_flg'] == FLAG_OFF) $uploadPages[$objDac->fld['page_id']] = $objDac->fld['file_path'];
				}
			}
			// パンくずが変更された場合はサイトマップから情報を削除
			if (!$objSitemapHandler->delete_sitemap_page($fld['page_id'])) {
				create_error('サイトマップ設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
		}
		// パンくずの最適化
		if ($objPage2->deflag_ancestor_path($fld['page_id'], $fld['p_ancestor_path']) === FALSE) {
			create_error('公開ページのパンくず用パスの最適化に失敗しました。 <br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		
		// タイトルが変更されたとき、ぱんくずだけ生成しなおすためにページＩＤをセット
		if ($fld['w_page_title'] != $fld['p_page_title']) {
			$where = "ancestor_path REGEXP '^(.*,)?" . $fld['w_file_path'] . "(,.*)?$'";
			//非公開の条件を追加
			$where .= " AND " . create_common_public_sql();
			$where .= " AND " . $objDac->_addslashesC('output_html_flg', FLAG_ON);
			$objDac->setTableName('tbl_publish_page');
			$objDac->select($where, 'page_id, file_path', 'page_id');
			while ($objDac->fetch())
				$uploadPages[$objDac->fld['page_id']] = $objDac->fld['file_path'];
		}
		
		// 関連ファイル（公開テーブルよりデータの取得）
		$aryExclusive = array();
		$objLinks->selectExclusive($fld['page_id'], PUBLISH_TABLE);
		while ($objLinks->fetch()) {
			if ($objLinks->fld['path'] == '') continue;
			$aryExclusive[] = $objLinks->fld['path'];
		}
		$objImages->selectExclusive($fld['page_id'], PUBLISH_TABLE);
		while ($objImages->fetch()) {
			if ($objImages->fld['src'] == '') continue;
			$aryExclusive[] = $objImages->fld['src'];
		}
		
		// 関連ファイル（編集テーブルよりデータの取得）
		$aryRelated = array();
		$objLinks->selectRelated($fld['page_id'], WORK_TABLE);
		while ($objLinks->fetch()) {
			$aryRelated[] = $objLinks->fld['path'];
		}
		$objImages->selectFromPageID($fld['page_id'], WORK_TABLE);
		while ($objImages->fetch()) {
			if ($objImages->fld['src'] == '') continue;
			if (checkFixedUpload($objImages->fld['src'], $fld, $fixed_edit_items) === FALSE) continue;
			$aryRelated[] = $objImages->fld['src'];
		}
		
		//公開側を基準とし、編集側に存在しないファイルを抽出（公開側のファイル削除用）
		$aryExclusive = array_diff($aryExclusive, $aryRelated);
		
		// ページ情報の更新、削除
		if (!$objPage2->updatePublishForUP($fld['page_id'])) {
			create_error('公開ページ情報の更新に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		if (!$objPage2->deleteFromPageID($fld['page_id'], WORK_TABLE)) {
			create_error('編集ページ情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// リンク情報の登録、削除
		if (!$objLinks->insertPublishFromWork($fld['page_id'])) {
			create_error('公開リンク情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		if (!$objLinks->deleteFromPageID($fld['page_id'], WORK_TABLE)) {
			create_error('編集リンク情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// 画像情報の登録、削除
		if (!$objImages->insertPublishFromWork($fld['page_id'])) {
			create_error('公開画像情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		if (!$objImages->deleteFromPageID($fld['page_id'], WORK_TABLE)) {
			create_error('編集画像情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// ライブラリの登録、削除
		if (!$objHandler->insertLibraryPfromW($fld['page_id'])) {
			create_error('公開ライブラリ設定の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		if (!$objHandler->deleteLibrary($fld['page_id'], WORK_TABLE)) {
			create_error('編集ライブラリ設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		
		// 自動リンク設定の登録、削除
		if (!$objHandler->insertAutoLinkPfromW($fld['page_id'])) {
			create_error('公開自動リンク設定の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		if (!$objHandler->deleteAutoLink($fld['page_id'], WORK_TABLE)) {
			create_error('編集自動リンク設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// 自動リンク設定の登録、削除
		if (!$objHandler->insertAutoLinkPagePfromW($fld['page_id'])) {
			create_error('公開自動リンク設定の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		if (!$objHandler->deleteAutoLinkPage($fld['page_id'], WORK_TABLE)) {
			create_error('編集自動リンク設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// 広告情報の登録（コピー）
		if (!$objHandler->copyAdvertPage($fld['page_id'], PUBLISH_TABLE)) {
			create_error('公開広告設定の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// 広告情報の削除
		if (!$objHandler->deleteAdvertPage($fld['page_id'], WORK_TABLE)) {
			create_error('編集広告設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// お問い合わせ情報の登録、削除
		if (!$objInquiry->insertPublishFromWork($fld['w_inquiry_id'])) {
			create_error('公開お問い合わせ情報の登録に失敗しました。<br>【' . $fld['w_inquiry_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		if (!$objInquiry->deleteFromID($fld['w_inquiry_id'], WORK_TABLE)) {
			create_error('編集お問い合わせ情報の削除に失敗しました。<br>【' . $fld['w_inquiry_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		if ($objCGrp->deleteFromID($fld['w_group_id']) === FALSE) {
			create_error('承認グループの削除に失敗しました。<br>【' . $fld['w_group_id'] . '】', $cronFlg, $objCnc, $ftpCnc, $fld['w_page_title']);
			continue;
		}
		// 観光情報の登録、削除
		if (!$objKanko->insertPublishFromWork($fld['page_id'])) {
			create_error('公開観光情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		if (!$objKanko->deleteFromID($fld['page_id'], '', WORK_TABLE)) {
			create_error('編集観光情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// アンケート
		if ($fld['template_kind'] == TEMPLATE_KIND_ENQUETE) {
			// アンケートの登録、削除
			$w_enq_id_ary = $objEnq->getEnqueteId($fld['page_id'], WORK_TABLE);
			$p_enq_id_ary = $objEnq->getEnqueteId($fld['page_id'], PUBLISH_TABLE);
			if (!$objEnq->insertPfromW($fld['page_id'])) {
				create_error('公開アンケート情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			$objEnq->add_where("page_id", $fld['page_id']);
			if (!$objEnq->delete("", WORK_TABLE)) {
				create_error('編集アンケート情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			foreach ($p_enq_id_ary as $enq_id) {
				$objEnqDtl->add_where("enquete_id", $enq_id);
				if (!$objEnqDtl->delete("", PUBLISH_TABLE)) {
					create_error('公開アンケート詳細情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue 2;
				}
			}
			foreach ($w_enq_id_ary as $enq_id) {
				// アンケート詳細の登録、削除
				if (!$objEnqDtl->insertPfromW($enq_id)) {
					create_error('公開アンケート詳細情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue 2;
				}
				$objEnqDtl->add_where("enquete_id", $enq_id);
				if (!$objEnqDtl->delete("", WORK_TABLE)) {
					create_error('編集アンケート詳細情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue 2;
				}
			}
		}
		//地図情報の登録、削除
		if (ENABLE_OPTION_GOOGLEMAP) {
			if (!$objMap->insertPublishFromWork($fld['page_id'])) {
				create_error('地図情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			if (!$objMap->deleteFromPID($fld['page_id'], WORK_TABLE)) {
				create_error('編集地図情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
		}
		// 外部連携データ管理設定登録、削除
		if (ENABLE_OPTION_OUTPUT) {
			if (!$objOpHndl->insertPublishFromWork($fld['page_id'])) {
				create_error('公開外部連携データ設定情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			if (!$objOpHndl->deletePage($fld['page_id'], HANDLER_OUTPUT_CLASS_WORK_PAGE)) {
				create_error('編集外部連携データ設定情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
		}
		// ローカルナビを使用しているページ情報の登録、削除
		if (!$objGHandler->insertPfromW($fld['page_id'])) {
			create_error('公開ローカルナビ情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		if (!$objGHandler->delete_lnavi_page($fld['page_id'], WORK_TABLE)) {
			create_error('編集ローカルナビ情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// 否認理由のひも付け削除
		if (!$objAppHandler->delete_denial_msg($fld['page_id'])) {
			create_error('前回の否認理由の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// サイトマップ情報の登録（コピー）
		if (!$objSitemapHandler->copy_entry_page($fld['page_id'], PUBLISH_TABLE)) {
			create_error('公開サイトマップ設定の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// サイトマップ情報の削除
		if (!$objSitemapHandler->delete_entry_page($fld['page_id'], WORK_TABLE)) {
			create_error('編集サイトマップ設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// 大規模災害用分類一覧ページ紐付け情報のコピー
		if (!copyDisasterListTop($fld['page_id'], PUBLISH_TABLE)) {
			create_error('大規模災害用分類一覧ページ情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// 大規模災害用分類一覧ページ紐付け情報の削除
		if (!deleteDisasterListTop($fld['page_id'], WORK_TABLE)) {
			create_error('大規模災害用分類一覧ページ情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		// イベントカレンダー複数日
		if (EVENT_CAL_MULTI_FLAG) {
			// 開催期間の登録（コピー）
			if (!$obj_event->insertPublishFromWork($fld['page_id'])) {
				create_error('開催期間の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// 開催期間の削除
			if (!$obj_event->delete($fld['page_id'], WORK_TABLE)) {
				create_error('開催期間の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
		}
		if(ENABLE_OPEN_DATA_FLG){
			// オープンデータ
			// オープンデータ編集情報の登録（コピー）
			if (!$obj_open_data_edit->insertPublishFromWork($fld['page_id'])) {
				create_error('オープンデータ編集情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			// オープンデータ編集情報の削除
			if (!$obj_open_data_edit->deleteFromID($fld['page_id'], '', '', '', WORK_TABLE)) {
				create_error('オープンデータ編集情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
		}
		// ローカルナビを使用している親、兄弟、子ページをチェック
		$lnavi_page_id_ary = check_lnavi_page($fld['page_id']);
		foreach ($lnavi_page_id_ary as $lnavi_page_id) {
			$allUploadPages[] = $lnavi_page_id;
		}
		
		// CMS内の関連ファイルの削除
		$deleteReration = array();
		$temp_ary = array(
				"item1" => $fld['page_id']
		);
		$objHandler->_select(HANDLER_CLASS_PUBLISH_DELETE_FILE, $temp_ary, "item2");
		while ($objHandler->fetch()) {
			$deleteReration[] = $objHandler->fld;
		}
		// 
		$objEnq = new tbl_enquete($objCnc);
		$error_msg = "";
		foreach ($deleteReration as $info) {
			// 関連ファイルのパス
			$path = $info['item2'];
			// ページで使用されている場合は無視
			if ($objLinks->useLinkFileCheck($path, PUBLISH_TABLE) === FALSE) continue;
			if ($objLinks->useLinkFileCheck($path, WORK_TABLE) === FALSE) continue;
			if ($objImages->useImageCheck($path, PUBLISH_TABLE) === FALSE) continue;
			if ($objImages->useImageCheck($path, WORK_TABLE) === FALSE) continue;
			// アンケートで使用されている場合は無視
			$objEnq->add_where("img_src", $path, "LIKE");
			$objEnq->setTableName(PUBLISH_TABLE);
			$objEnq->select();
			if ($objEnq->getRowCount() > 0) continue;
			$objEnq->add_where("img_src", $path, "LIKE");
			$objEnq->setTableName(WORK_TABLE);
			$objEnq->select();
			if ($objEnq->getRowCount() > 0) continue;
			
			// 定型情報
			

			// 公開
			if ($objKanko->checkUseFiles($path, PUBLISH_TABLE)) continue;
			
			// 編集
			if ($objKanko->checkUseFiles($path, WORK_TABLE)) continue;
			
			// 情報の削除
			if (!$objHandler->deletePublishDeleteFilePath($path)) {
				create_error('関連ファイル情報の削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			// FCKテーブルの情報削除
			if (!$objFCKLinks->deleteFromPageID($path)) {
				create_error('ファイル情報の削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			if (!$objFCKImages->deleteFromImagePath($path)) {
				create_error('画像情報の削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			// ファイルが存在すれば削除
			if (@is_file(DOCUMENT_ROOT . RPW . $path) && !@unlink(DOCUMENT_ROOT . RPW . $path)) {
				create_error('関連ファイルの削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			// ファイルが存在すれば削除
			if (@is_file(DOCUMENT_ROOT . RPR . $path) && !@unlink(DOCUMENT_ROOT . RPR . $path)) {
				create_error('関連ファイルの削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			// 公開先からも削除
			if (FTP_UPLOAD_FLG) @deleteFile_ftp($ftpCnc, FTP_ROOT_DIR . $path);
		}
		if ($continue_flg == FLAG_ON) continue;
		
		// ページで保存した削除関連ファイル情報の削除
		if (!$objHandler->deletePublishDeleteFile($fld['page_id'])) {
			create_error('関連ファイル情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			$continue_flg = FLAG_ON;
			break;
		}
		
		// 関連ファイルの削除
		foreach ($aryExclusive as $path) {
			//共通ファイルアップロード先フォルダのパスが入っている場合は、削除しない
			if (preg_match('/^' . reg_replace(SHARED_UPLOAD_DIR) . '\//i', $path)) continue;
			if (@is_file(DOCUMENT_ROOT . RPR . $path) && !@unlink(DOCUMENT_ROOT . RPR . $path)) {
				create_error('関連ファイルの削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			if (FTP_UPLOAD_FLG) deleteFile_ftp($ftpCnc, FTP_ROOT_DIR . $path);
		}
		if ($continue_flg == FLAG_ON) continue;
		
		// 大規模災害状態でない場合で、かつ大規模災害ページの場合
		if (!isDisasterFlg() && (isDisasterPage($fld['page_id']) || isDisasterListPage($fld['page_id']))) {
			// 関連ファイルをFTPアップロードしない
			$aryRelated = array();
		}
		
		// 関連ファイルのFTPアップロード
		foreach (array_unique($aryRelated) as $path) {
			if (!@is_file(DOCUMENT_ROOT . RPW . $path) || !@file_exists(DOCUMENT_ROOT . RPW . $path)) continue;
			// check file need uploading
			if (!is_upload_file($path, $ftpCnc)) {
				continue;
			}
			if (mkNewDirectory(DOCUMENT_ROOT . RPR . $path) === FALSE || !@copy(DOCUMENT_ROOT . RPW . $path, DOCUMENT_ROOT . RPR . $path)) {
				create_error('関連ファイルのコピーに失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
			// 拡張子txt,htmのものはASCII、その他はBINARYでアップ
			$sExtension = substr($path, (strrpos($path, '.') + 1));
			$sExtension = strtolower($sExtension);
			$temp_ary = array(
					'txt', 
					'htm'
			);
			$ftp_mode = (in_array($sExtension, $temp_ary)) ? FTP_ASCII : FTP_BINARY;
			if (FTP_UPLOAD_FLG && !@uploadFile_ftp($ftpCnc, FTP_ROOT_DIR . $path, DOCUMENT_ROOT . RPW . $path, $ftp_mode)) {
				create_error('FTPサーバへの関連ファイルのコピーに失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				$continue_flg = FLAG_ON;
				break;
			}
		}
		if ($continue_flg == FLAG_ON) continue;
		
		// ファイルの移動+削除
		if ($fld['p_file_path'] != $fld['w_file_path']) {
			// 公開側ページ移動フラグ
			$real_page_move_flg = FLAG_ON;
			// 大規模災害状態の場合
			if ($is_disaster_flg) {
				// 大規模災害ページが作成されているページが移動された場合
				if ($disaster_page_id != $fld['page_id']) {
					// 関連ページに大規模災害ページ追加
					$allUploadPages[] = $disaster_page_id;
				}
				// 大規模災害ページが移動された場合
				if ($disaster_base_page_id != $fld['page_id']) {
					// 作成元ページを関連ページに追加
					$allUploadPages[] = $disaster_base_page_id;
					// 元ページが非公開の場合は公開側を移動しない
					if (getDisasterModePage($fld['page_id'], 'close_flg') == FLAG_ON) {
						$real_page_move_flg = FLAG_OFF;
					}
				}
			}
			// 大規模災害状態でない場合
			else {
				// 大規模災害ページが移動された場合
				if (getDisasterBasePageId($fld['page_id']) != $fld['page_id']) {
					$real_page_move_flg = FLAG_OFF;
				}
			}
			if (mkNewDirectory(DOCUMENT_ROOT . RPW . $fld['w_file_path']) == FALSE || !@copy(DOCUMENT_ROOT . RPW . $fld['p_file_path'], DOCUMENT_ROOT . RPW . $fld['w_file_path'])) {
				create_error('HTMLファイルの移動に失敗しました。<br>【' . $fld['p_file_path'] . ' ⇒ ' . $fld['w_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			if (!@unlink(DOCUMENT_ROOT . RPW . $fld['p_file_path'])) {
				create_error('作業用HTMLファイルの削除に失敗しました。<br>【' . $fld['p_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				continue;
			}
			
			//新規ページの場合、公開ページの移動＋削除は行わない
			if ($fld['work_class'] != WORK_CLASS_NEW && $fld['p_close_flg'] == FLAG_OFF && $real_page_move_flg == FLAG_ON) {
				if (mkNewDirectory(DOCUMENT_ROOT . RPR . $fld['w_file_path']) == FALSE || !@copy(DOCUMENT_ROOT . RPR . $fld['p_file_path'], DOCUMENT_ROOT . RPR . $fld['w_file_path'])) {
					create_error('HTMLファイルの移動に失敗しました。<br>【' . $fld['p_file_path'] . ' ⇒ ' . $fld['w_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				if (!@unlink(DOCUMENT_ROOT . RPR . $fld['p_file_path'])) {
					create_error('公開用HTMLファイルの削除に失敗しました。<br>【' . $fld['p_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				if (FTP_UPLOAD_FLG) @deleteFile_ftp($ftpCnc, FTP_ROOT_DIR . $fld['w_file_path']);
				if (FTP_UPLOAD_FLG && !@uploadFile_ftp($ftpCnc, FTP_ROOT_DIR . $fld['w_file_path'], DOCUMENT_ROOT . RPR . $fld['w_file_path'], FTP_ASCII)) {
					create_error('FTPサーバへの関連ファイルのコピーに失敗しました。<br>【' . $fld['w_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				if (FTP_UPLOAD_FLG) deleteFile_ftp($ftpCnc, FTP_ROOT_DIR . $fld['p_file_path']);
			}
			//自動掲載された携帯ページの移動+削除
			if ($objTool->checkMobileTemplate($fld['page_id'])) {
				if (mkNewDirectory(DOCUMENT_ROOT . RPW . DIR_PATH_MOBILE . $fld['w_file_path']) == FALSE || !@copy(DOCUMENT_ROOT . RPW . DIR_PATH_MOBILE . $fld['p_file_path'], DOCUMENT_ROOT . RPW . DIR_PATH_MOBILE . $fld['w_file_path'])) {
					create_error('HTMLファイルの移動に失敗しました。<br>【' . $fld['p_file_path'] . ' ⇒ ' . $fld['w_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				if (!@unlink(DOCUMENT_ROOT . RPW . DIR_PATH_MOBILE . $fld['p_file_path'])) {
					create_error('作業用HTMLファイルの削除に失敗しました。<br>【' . $fld['p_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				
				//新規ページの場合、公開ページの移動＋削除は行わない
				if ($fld['work_class'] != WORK_CLASS_NEW && $fld['p_close_flg'] == FLAG_OFF && $real_page_move_flg == FLAG_ON) {
					
					if (mkNewDirectory(DOCUMENT_ROOT . RPR . DIR_PATH_MOBILE . $fld['w_file_path']) == FALSE || !@copy(DOCUMENT_ROOT . RPR . DIR_PATH_MOBILE . $fld['p_file_path'], DOCUMENT_ROOT . RPR . DIR_PATH_MOBILE . $fld['w_file_path'])) {
						create_error('HTMLファイルの移動に失敗しました。<br>【' . $fld['p_file_path'] . ' ⇒ ' . $fld['w_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						continue;
					}
					if (!@unlink(DOCUMENT_ROOT . RPR . DIR_PATH_MOBILE . $fld['p_file_path'])) {
						create_error('公開用HTMLファイルの削除に失敗しました。<br>【' . $fld['p_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						continue;
					}
					if (FTP_UPLOAD_FLG) @deleteFile_ftp($ftpCnc, FTP_ROOT_DIR . DIR_PATH_MOBILE . $fld['w_file_path']);
					if (FTP_UPLOAD_FLG && !@uploadFile_ftp($ftpCnc, FTP_ROOT_DIR . DIR_PATH_MOBILE . $fld['w_file_path'], DOCUMENT_ROOT . RPR . DIR_PATH_MOBILE . $fld['w_file_path'], FTP_ASCII)) {
						create_error('FTPサーバへの関連ファイルのコピーに失敗しました。<br>【' . $fld['w_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
						continue;
					}
					if (FTP_UPLOAD_FLG) deleteFile_ftp($ftpCnc, FTP_ROOT_DIR . DIR_PATH_MOBILE . $fld['p_file_path']);
				}
			}
		}
		// イベントカレンダー定型対応追加　--------
		$format_tbl_name = (isFixed($fld)) ? getTableName($fld['template_id']) : "";
		$KANKO_XML_TYPE = getDefineArray('KANKO_XML_TYPE');
		//観光
		if (isFixed($fld) && !in_array($format_tbl_name, $KANKO_XML_TYPE)) {
			// イベントカレンダー定型対応追加　---------
			if ($objFAQ->targetCheckFAQ($fld['template_id']) !== FALSE) {
				// FAQページの場合はFAQ情報を更新する
				if (publishRegFAQ($fld['page_id'], 'upd') === FALSE) {
					create_error('FAQ情報の更新に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
			}
		}
		if (isFixed($fld)) {
			//イベント
			if ($objTool->selectTemplateKankoType($fld['template_id']) == KANKO_TYPE_EVENT && $format_tbl_name == KANKO_XML_TYPE_CSV) {
				// イベントカレンダー複数日
				if (EVENT_CAL_MULTI_FLAG) {
					if (!empty($open_start_p)) {
						// CSV対象年月格納用配列
						$target_open_date = array();
						
						// 開始日と終了日対で取得
						foreach ($open_start_p[$fld['page_id']] as $open_date_num => $open_start_date) {
							// 開催開始日を分割
							$match_open_start = preg_split('/\W/', $open_start_date);
							if (in_array($open_start_date, $match_open_start)) {
								// マッチングに失敗した場合
								create_error('イベント開催期間の取得に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
								$continue_flg = FLAG_ON;
								break;
							}
							// 開催開始日のチェック
							if (checkdate($match_open_start[1], $match_open_start[2], $match_open_start[0]) == FALSE) {
								create_error('イベント開催開始日の指定が正しくありません。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
								$continue_flg = FLAG_ON;
								break;
							}
							// 開催終了日が指定されていない場合
							if (empty($open_end_p[$fld['page_id']][$open_date_num])) {
								// CSV対象年月格納用配列に含まれていなければ、CSV対象年月格納用配列に格納
								if (!in_array($match_open_start[0] . $match_open_start[1] . '01', $target_open_date)) {
									$target_open_date[] = $match_open_start[0] . $match_open_start[1] . '01';
								}
							}
							// 開催終了日が指定されている場合
							else {
								// 開催終了日を分割
								$match_open_end = preg_split('/\W/', $open_end_p[$fld['page_id']][$open_date_num]);
								if (in_array($open_end_p[$fld['page_id']][$open_date_num], $match_open_end)) {
									// マッチングに失敗した場合
									create_error('イベント開催期間の取得に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
									$continue_flg = FLAG_ON;
									break;
								}
								// 年のカウンタ
								$year_cnt = (int)$match_open_start[0];
								// 月のカウンタ
								$month_cnt = (int)$match_open_start[1];
								// 年月が終了日を超えていない場合
								while (($year_cnt < (int)$match_open_end[0]) || ($year_cnt == (int)$match_open_end[0] && $month_cnt <= (int)$match_open_end[1])) {
									// CSV対象年月格納用配列に含まれていなければ、CSV対象年月格納用配列に格納
									if (in_array(sprintf('%04d%02d01', $year_cnt, $month_cnt), $target_open_date) == FALSE) {
										$target_open_date[] = sprintf('%04d%02d01', $year_cnt, $month_cnt);
									}
									// カウントアップ
									$month_cnt++;
									if ($month_cnt > 12) {
										$year_cnt++;
										$month_cnt = 1;
									}
								}
							}
						}
						// フラグがONの場合次処理ページへ
						if ($continue_flg == FLAG_ON) {
							continue;
						}
	
						if (_createEventCsvMulti($objCnc, $fld['w_page_title'], $target_open_date, $cronFlg, $fld, $fld['template_id']) === FALSE) {
							continue;
						}
					}
					
					if (!empty($open_start_w)) {
						// CSV対象年月格納用配列
						$target_open_date = array();
						
						// 開始日と終了日対で取得
						foreach ($open_start_w[$fld['page_id']] as $open_date_num => $open_start_date) {
							// 開催開始日を分割
							$match_open_start = preg_split('/\W/', $open_start_date);
							if (in_array($open_start_date, $match_open_start)) {
								// マッチングに失敗した場合
								create_error('イベント開催期間の取得に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
								$continue_flg = FLAG_ON;
								break;
							}
							// 開催開始日のチェック
							if (checkdate($match_open_start[1], $match_open_start[2], $match_open_start[0]) == FALSE) {
								create_error('イベント開催開始日の指定が正しくありません。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
								$continue_flg = FLAG_ON;
								break;
							}
							// 開催終了日が指定されていない場合
							if (empty($open_end_w[$fld['page_id']][$open_date_num])) {
								// CSV対象年月格納用配列に含まれていなければ、CSV対象年月格納用配列に格納
								if (!in_array($match_open_start[0] . $match_open_start[1] . '01', $target_open_date)) {
									$target_open_date[] = $match_open_start[0] . $match_open_start[1] . '01';
								}
							}
							// 開催終了日が指定されている場合
							else {
								// 開催終了日を分割
								$match_open_end = preg_split('/\W/', $open_end_w[$fld['page_id']][$open_date_num]);
								if (in_array($open_end_w[$fld['page_id']][$open_date_num], $match_open_end)) {
									// マッチングに失敗した場合
									create_error('イベント開催期間の取得に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
									$continue_flg = FLAG_ON;
									break;
								}
								// 年のカウンタ
								$year_cnt = (int)$match_open_start[0];
								// 月のカウンタ
								$month_cnt = (int)$match_open_start[1];
								// 年月が終了日を超えていない場合
								while (($year_cnt < (int)$match_open_end[0]) || ($year_cnt == (int)$match_open_end[0] && $month_cnt <= (int)$match_open_end[1])) {
									// CSV対象年月格納用配列に含まれていなければ、CSV対象年月格納用配列に格納
									if (in_array(sprintf('%04d%02d01', $year_cnt, $month_cnt), $target_open_date) == FALSE) {
										$target_open_date[] = sprintf('%04d%02d01', $year_cnt, $month_cnt);
									}
									// カウントアップ
									$month_cnt++;
									if ($month_cnt > 12) {
										$year_cnt++;
										$month_cnt = 1;
									}
								}
							}
						}
						// フラグがONの場合次処理ページへ
						if ($continue_flg == FLAG_ON) {
							continue;
						}
						if (_createEventCsvMulti($objCnc, $fld['w_page_title'], $target_open_date, $cronFlg, $fld, $fld['template_id']) === FALSE) {
							continue;
						}
					}
				}
				// イベントカレンダー単一日
				else {
					//イベントの場合はCSVを出力する。
					if (_createEventCsv($objCnc, $fld['w_page_title'], $fld['w_open_start'], $fld['w_open_end'], $cronFlg) === FALSE) continue;
					if (_createEventCsv($objCnc, $fld['w_page_title'], $fld['p_open_start'], $fld['p_open_end'], $cronFlg) === FALSE) continue;
				}				
			}
			//FLASH動画
			else if ($objTool->selectTemplateKankoType($fld['template_id']) == KANKO_TYPE_FLASH_VIDEO) {
				//FLASHデータをアップロード
				if (ftpFlashData($ftpCnc, 1, $fld) === FALSE) {
					//エラー処理
					create_error('FTPサーバへの動画ファイルのコピーに失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
			}
			else {
				//観光情報の場合は検索用テーブルに登録
				if (syncKankoDataToDB(1, $fld) === FALSE) {
					//エラー処理
					create_error('観光検索用データベースの同期に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				//サムネイル画像の削除
				if (syncThumbnail(2, $fld, $ftpCnc) === FALSE) {
					//エラー処理
					create_error('サムネイル削除処理に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
				//サムネイル画像の公開
				if (syncThumbnail(1, $fld, $ftpCnc) === FALSE) {
					//エラー処理
					create_error('サムネイル登録処理に失敗しました。<br>', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
			}
		}
		//アンケート
		if ($fld['template_kind'] == TEMPLATE_KIND_ENQUETE) {
			$ftpDataCnc = connectFTP("enquete");
			// メールの場合は送信先指定を記述したファイルをアップロード
			if ($fld['w_enquete_kind'] == ENQ_KIND_MAIL) {
				$mail_file = DOCUMENT_ROOT . DIR_PATH_TEMP . $fld['page_id'] . ".dat";
				$fp = @fopen($mail_file, 'w+');
				$enquete_email = $fld['w_enquete_email'];
				$mailStr = "";
				foreach (explode(",", $enquete_email) as $key => $data) {
					$enq_mail = explode(":", $data);
					$mailStr .= ($mailStr == "") ? $enq_mail[0] : "," . $enq_mail[0];
				}
				$mailStr = csvWrite(ENQ_MAIL_ADDR_FROM) . "\n" . csvWrite($mailStr);
				$r = @fwrite($fp, $mailStr);
				if ($fp == FALSE || !$r) {
					$out_errmsg = 'メール指定ファイルの生成に失敗しました。【' . $mail_file . '】';
					create_error($out_errmsg, $cronFlg, $objCnc, "");
					return FALSE;
				}
				@fclose($fp);
				@chmod($mail_file, 0777);
				$ftp_path = FTP_MAIL_CSV_DIR_ENQUETE . "/" . $fld['page_id'] . ".dat";
				if (FTP_UPLOAD_FLG && !@uploadFile_ftp($ftpDataCnc, $ftp_path, $mail_file, FTP_ASCII)) {
					create_error('FTPサーバへの関連ファイルのコピーに失敗しました。<br>【' . $mail_file . '⇒' . $ftp_path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
			}
		}
		
		//施設情報
		if (isFixed($fld) && $objTool->selectTemplateKankoType($fld['template_id']) == KANKO_TYPE_WELFARE) {
			//地図情報の使用の有無チェック
			if (ENABLE_OPTION_GOOGLEMAP && MAP_DATA_CSV_FLG) {
				//CSVの作成・アップロード処理
				if (!map_data_csv($ftpCnc)) {
					create_error('地図関連ファイルの更新に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					continue;
				}
			}
		}
		
		// オープンデータ
		// オープンデータ 公開側DB同期処理
		if (ENABLE_OPEN_DATA_FLG && !syncOpenDataDB(1, $fld['page_id'])) {
			create_error('オープンデータ情報の同期に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			continue;
		}
		
		// 自身のページ(再設定)
		$uploadPages[$fld['page_id']] = $fld['w_file_path'];
		
		// ページの生成＋アップロード
		$u_cnt = 0;
		$uploadPages = array_unique($uploadPages);
		if (!$cronFlg && count($uploadPages) > 0) $pgrs_func->send_msg("関連するページを処理中です。");
		foreach ($uploadPages as $pid => $path) {
			// ページ出力設定チェック
			if (is_output_html($pid) === FALSE) continue;
			create_html($pid, $path, $objCnc, $ftpCnc, $errmsg, $cronFlg);
			if (!$cronFlg) $pgrs_func->progress(++$u_cnt, count($uploadPages));
		}
		if (!$cronFlg && count($uploadPages) > 0) $pgrs_func->send_msg("公開処理中です。");
		
		// メール送信（公開）TO:ページ作成者
		if (MAIL_FLG_PUBLISH) {
			if ($fld['work_class'] == WORK_CLASS_NEW) $work_class = '（新規）';
			elseif ($fld['work_class'] == WORK_CLASS_PUBLISH) $work_class = '（更新）';
			else $work_class = '';
			while (1) {
				// ページ作成者情報を取得
				$sql = "SELECT user_id,name,dept_name,email,dept_code FROM tbl_user WHERE user_id = " . $fld['w_user_id'];
				if ($objDac->execute($sql) == FALSE) break;
				if (!$objDac->fetch()) break;
				
				// メールに記載するファイルパス
				$mail_file_path = (!$is_disaster_flg || $disaster_base_page_id == $disaster_page_id ? $fld['w_file_path'] : $disaster_file_path);
				
				$user_fld = $objDac->fld;
				// ---メール本文作成用配列
				$mail_fld = array();
				$mail_fld['url'] = HTTP_REAL_ROOT;
				$mail_fld['cms_url'] = HTTP_ROOT . RPW;
				$mail_fld['now_date'] = date('Y-m-d H:i:s');
				$mail_fld['dept_name'] = $user_fld['dept_name']; //送信先組織
				$mail_fld['user_name'] = $user_fld['name']; //送信先ユーザ
				$mail_fld['work_class'] = $work_class; //新規｜更新
				$mail_fld['page_title'] = $fld['w_page_title']; //対象ページタイトル
				$mail_fld['file_path'] = $mail_file_path; //対象ページファイルパス
				$mail_fld['mobile_file_path'] = ''; //対象ページの携帯ページファイルパス
				$mail_fld['publish_start'] = $fld['w_publish_start']; //公開開始日
				$mail_fld['publish_end'] = $fld['w_publish_end']; //公開終了日
				if ($objTool->checkMobileTemplate($fld['page_id'])) {
					$mail_fld['mobile_file_path'] = DIR_PATH_MOBILE . $mail_file_path;
				}
				// 大規模災害ページ（ページ出力なしの時）
				if (!$is_disaster_flg && (isDisasterPage($fld['page_id']) || isDisasterListPage($fld['page_id']))) {
					// 専用のメール設定
					$head = get_mail_str($mail_fld, MAIL_SUBJECT_PUBLISH_DISASTER);
					$body = get_mail_str($mail_fld, MAIL_BODY_PUBLISH_DISASTER);
				}
				// その他
				else {
					// 通常の公開用メール設定
					$head = get_mail_str($mail_fld, MAIL_SUBJECT_PUBLISH);
					$body = get_mail_str($mail_fld, MAIL_BODY_PUBLISH);
				}
				if (!send_mail($user_fld['email'], MAIL_ADDR_FROM, $head, $body)) {
					create_error('メール送信に失敗しました。<br>To:' . $user_fld['email'], $cronFlg, $objCnc, $fld['w_page_title']);
					$continue_flg = FLAG_ON;
					break;
				}
				break;
			}
			if ($continue_flg == FLAG_ON) continue;
		}
	
	}
	
	//--- CMS-8341 Version2 --------------------------------------------------------------------------------------------//
	// ログ登録(ページの公開・ページの非公開・ページの削除)
	if ($fld['work_class'] == WORK_CLASS_DELETE || $close_upload == FLAG_ON) {
		if ($fld['w_close_flg'] == FLAG_OFF && $close_upload == FLAG_OFF) {
			$log_flg = WRITE_INFO_LOG_UPLOAD_DELETE;
			$log_status = LOG_STATUS_DELETE;
		}
		else {
			$log_flg = WRITE_INFO_LOG_UPLOAD_CLOSE;
			$log_status = LOG_STATUS_CLOSE;
		}
	}
	else {
		$log_flg = WRITE_INFO_LOG_UPLOAD_PUBLISH;
		$log_status = LOG_STATUS_UPLOAD;
	}
	if ($log_flg) {
		$user_info = array();
		$page_info = array(
				'page_id' => $fld['page_id'], 
				'page_title' => $fld['w_page_title'], 
				'file_path' => $fld['w_file_path']
		);
		if ($cronFlg) {
			$user_info['user_name'] = ($close_upload == FLAG_ON) ? "自動非公開" : "自動公開";
			$user_info['user_class'] = LOG_USER_CLASS_CRON;
		}
		set_log_data($log_status, $page_info, '', $user_info);
	}
	//--- CMS-8341 Version2 --------------------------------------------------------------------------------------------//
	

	$objCnc->commit();
	// コミットオープンデータ
	if (ENABLE_OPEN_DATA_FLG) {
		global $obj_cnc_pub;
		if (!is_null($obj_cnc_pub)) {
			$obj_cnc_pub->commit();
		}
	}
	if (!$cronFlg) $pgrs_func->progress(++$upload_cnt, count($sort_ary));
}
if (!$cronFlg) {
	$pgrs_func->clear_bar();
	$pgrs_func->send_msg("関連するページを処理中です。");
}

//  FAQ一覧ページの再公開 ----------------------------------------------------------------------------- ---- --//
$err_page = '';
if (faqListCsvCreate($faqListUploadCate, $ftpCnc, $cronFlg, $err_page) == FALSE) {
	create_error("FAQ一覧ページの公開に失敗しました。", $cronFlg, $objCnc, $err_page);
}

// 影響する自動リンクページを取得
$success_page_id_ary = array();
if (count($session_temp_ary) > 0) {
	foreach ($session_temp_ary as $page_id => $temp_ary) {
		$a_link_page_ary = array();
		$a_link_page_ary[] = $page_id;
		$_SESSION['temp'] = $temp_ary;
		get_autolink_related_pages($a_link_page_ary, $close_upload, $allUploadPages);
	}
}

//  ページの生成＋アップロード（自動生成の対象ページ）
$allUploadPages = array_unique($allUploadPages);
$upload_cnt = 0;
foreach ($allUploadPages as $key => $page_id) {
	// ページ出力設定チェック
	if (is_output_html($page_id) === FALSE || is_output_html($page_id, WORK_TABLE) === FALSE) {
		unset($allUploadPages[$key]);
		continue;
	}
	if ($objPage1->selectFromID($page_id) === FALSE) {
		unset($allUploadPages[$key]);
		continue;
	}
	$pFld = $objPage1->fld;
	if ($pFld['work_class'] == WORK_CLASS_NEW) {
		unset($allUploadPages[$key]);
		continue;
	}
	if ($pFld['close_flg'] == FLAG_ON) {
		unset($allUploadPages[$key]);
		continue;
	}
}

// キャッシュを消去
unset($_SESSION['temp']['l_navi']);
foreach ($allUploadPages as $page_id) {
	$out_errmsg = '';
	$objPage1->selectFromID($page_id);
	$pFld = $objPage1->fld;
	if (create_html($pFld['page_id'], $pFld['file_path'], $objCnc, $ftpCnc, $errmsg, false) === FALSE) {
		create_error("自動リンク関連ページの公開に失敗しました。", $cronFlg, $objCnc, $err_page);
	}
	// 不要な自動リンクページ情報を削除する
	$objAutoLinkPages->deleteNonUse($page_id, "public");
	if (!$cronFlg) $pgrs_func->progress(++$upload_cnt, count($allUploadPages));
}

// 削除時は最後にhandler情報を消す
foreach ($allDeletePages as $page_id) {
	$objHandler->deleteAutoLink($page_id);
	$objHandler->deleteAutoLinkPage($page_id);
}

// 外部連携自動出力機能
if (count($_SESSION['template_id_of_output_page']) > 0) {
	$template_id_ary = $_SESSION['template_id_of_output_page'];
	$output_err_msg = "";
	if (!auto_upload_output($template_id_ary, $output_err_msg)) {
		// 外部連携自動出力用テンプレートID配列削除
		unset($_SESSION['template_id_of_output_page']);
		create_error($output_err_msg, $cronFlg, $objCnc, "");
	}
}
// 外部連携自動出力用テンプレートID配列削除
unset($_SESSION['template_id_of_output_page']);

if (FTP_UPLOAD_FLG) {
	// FTP ストリームを閉じる
	cx_ftp_close($ftpCnc);
	if (ENABLE_OPTION_ADVERT) cx_ftp_close($ftpCgiCnc);
}

// 排他制御解除
lock_file_management('unlock');

if ($cronFlg) {
	exit();
}

if (!$cronFlg) {
	$pgrs_func->send_msg("処理が終了しました。");
	$pgrs_func->clear();
	$pgrs_func->end();
}

/*
 * 非公開中のページを非公開する際の処理
 * @param $fld ページ情報
 * @param $uploadPages ページ出力するページの情報
 * @param $allUploadPages 全ての公開したページを格納する配列(自動リンク時に使用)
 * @param $cronFlg クーロンからの処理か判定する用のフラグ
 * @return TRUE : 成功	FALSE : 失敗
 */
function close_flg_on_upload_exec($fld, &$uploadPages, &$allUploadPages, $cronFlg) {
	//外部ファイルの読み込み
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
	$objDac = new dac($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
	$objTool = new dac_tools($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
	$objPage2 = new tbl_page($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
	$objLinks = new tbl_links($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
	$objImages = new tbl_images($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
	$objInquiry = new tbl_inquiry($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
	$objHandler = new tbl_handler($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_contents_group.inc');
	$objCGrp = new tbl_contents_group($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
	$objKanko = new tbl_kanko($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_approve_handler.inc');
	$objAppHandler = new tbl_approve_handler($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_map.inc');
	$objMap = new tbl_map($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output_handler.inc');
	$objOpHndl = new tbl_output_handler($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_lnavi_handler.inc');
	$objGHandler = new tbl_lnavi_handler($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_sitemap_handler.inc');
	$objSitemapHandler = new tbl_sitemap_handler($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete.inc');
	$objEnq = new tbl_enquete($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete_detail.inc');
	$objEnqDtl = new tbl_enquete_detail($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_links.inc');
	$objFCKLinks = new tbl_fck_links($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
	$objFCKImages = new tbl_fck_images($objCnc);
	// オープンデータ
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_open_data.inc');
	$obj_open_data_edit = new tbl_open_data($objCnc);
	
	//保存先が変更されたとき、ぱんくず、編集領域を修正
	if ($fld['p_file_path'] != $fld['w_file_path'] && (!$objPage2->selectFromPath($fld['w_file_path'], PUBLISH_TABLE) || strtolower($fld['p_file_path']) == strtolower($fld['w_file_path']))) {
		//リンク情報、編集領域の修正
		$tbl_ary = array(
				WORK_TABLE, 
				PUBLISH_TABLE
		);
		foreach ($tbl_ary as $tbl) {
			//公開・編集リンク情報更新
			$rep_page_id_ary = array();
			$link_tbl = ($tbl == PUBLISH_TABLE ? 'tbl_publish_links' : 'tbl_work_links');
			$objBDac = new b_dac($objCnc, $link_tbl, "page_id");
			$objBDac->add_where("path", $fld['p_file_path']);
			$objBDac->select();
			while ($objBDac->fetch()) {
				$rep_page_id_ary[] = $objBDac->fld['page_id'];
				$u_ary = $objBDac->fld;
				$u_ary["path"] = $fld['w_file_path'];
				$objLinks->setTableName($link_tbl);
				if ($objLinks->update($u_ary) === FALSE) {
					create_error('リンク情報の更新に失敗しました。<br>【' . $objBDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					return FALSE;
				}
			}
			
			//公開・編集定型情報更新
			$fixed_tbl = ($tbl == PUBLISH_TABLE ? 'tbl_publish_kanko' : 'tbl_work_kanko');
			$objBDac = new b_dac($objCnc, $fixed_tbl, "page_id");

			// 定型タイプが「cutomarea」のcontext内href抽出用正規表現の定義
			$reg_href_kanko = '(\"|\')?(' . reg_replace(RPW) . ')?(' . reg_replace($fld['p_file_path']) . ')(\"|\')?';

			// 定型タイプが「link」または「file」のcontextの内容に対象のファイルパスが存在する場合
			$where = '((';
			$where .= $objBDac->_addslashesC("type", "link");
			$where .= ' OR ';
			$where .= $objBDac->_addslashesC("type", "file");
			$where .= ') AND (';
			$where .= $objBDac->_addslashesC("context", RPW . $fld['p_file_path'] . KANKO_LINK_DELIMITER . "%", "LIKE");
			$where .= ' OR ';
			$where .= $objBDac->_addslashesC("context", $fld['p_file_path'] . KANKO_LINK_DELIMITER . "%", "LIKE");
			$where .= '))';
			
			// または、定型タイプ「customarea」のcontext内にhrefの対象ファイルパスがある場合
			$where .= ' OR (';
			$where .= $objBDac->_addslashesC('type', 'customarea');
			$where .= ' AND ';
			$where .= $objBDac->_addslashesC('context', 'href[[:space:]]*=[[:space:]]*' . $reg_href_kanko, 'REGEXP', 'TEXT');
			$where .= ')';
			$objBDac->where[] = $where;
			
			$objBDac->select();
			while ($objBDac->fetch()) {
				$rep_page_id_ary[] = $objBDac->fld['page_id'];
				$u_ary = $objBDac->fld;
				// 変更前のパスを変更後に変換する※「/cms8341」が先頭にある場合、ない場合ともに変換する
				
				// 定型タイプが「customarea」の場合、href抽出用正規表現でヒットした箇所を変更後の値に置き換える
				if ($u_ary['type'] == 'customarea') {
					$u_ary['context'] = preg_replace('/href(\s)*=(\s)*' . $reg_href_kanko . '/i', 'href="' . $fld['w_file_path'] . '"', $u_ary['context']);
					
				}
				// 定型タイプが「link」や「file」の場合、以下を処理
				else {
					$u_ary['context'] = preg_replace('/^(' . reg_replace(RPW) . ')?' . reg_replace($fld['p_file_path'] . KANKO_LINK_DELIMITER) . '/', RPW . $fld['w_file_path'] . KANKO_LINK_DELIMITER, $u_ary['context']);
				}
				
				if ($objKanko->update($u_ary, $fixed_tbl) === FALSE) {
					create_error('定型情報のリンクの更新に失敗しました。<br>【' . $objBDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					return FALSE;
				}
			}
			
			//更新するページがなければ飛ばす
			if (count($rep_page_id_ary) == 0) {
				continue;
			}
			
			//公開・編集　FCK領域更新
			$rep_page_id_ary = array_unique($rep_page_id_ary);
			$page_tbl = ($tbl == PUBLISH_TABLE ? 'tbl_publish_page' : 'tbl_work_page');
			$objBDacTran = new b_dac($objCnc, $page_tbl, "page_id");
			$objBDac = new b_dac($objCnc, $page_tbl, "page_id");
			$objBDac->add_where("page_id", implode(",", $rep_page_id_ary), "IN");
			$objBDac->select();
			while ($objBDac->fetch()) {
				//編集領域内のリンクを修正
				$reg_href = 'href="(' . reg_replace(HTTP_ROOT . RPW) . '|' . reg_replace(HTTP_ROOT . RPR) . ')?' . reg_replace($fld['p_file_path']) . '([^\"]+)?"';
				$context = preg_replace('/' . $reg_href . '/', 'href="' . $fld['w_file_path'] . '$2"', $objBDac->fld['context']);
				$ary = array(
						'page_id' => $objBDac->fld['page_id'], 
						'context' => $context
				);
				$objBDacTran->where = array();
				if (!$objBDacTran->update($ary)) {
					create_error('FCK領域の更新に失敗しました。<br>【' . $objBDac->fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
					return FALSE;
				}
				if ($tbl == PUBLISH_TABLE && $objBDac->fld['work_class'] != WORK_CLASS_NEW && $objBDac->fld['close_flg'] == FLAG_OFF) {
					$uploadPages[$objBDac->fld['page_id']] = $objBDac->fld['file_path'];
				}
			}
		}
	}
	
	//ページ情報の更新、削除
	if (!$objPage2->updatePublishPageForClose($fld['page_id'])) {
		create_error('公開ページ情報の更新に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	if (!$objPage2->deleteFromPageID($fld['page_id'], WORK_TABLE)) {
		create_error('編集ページ情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	//リンク情報の登録、削除
	if (!$objLinks->insertPublishFromWork($fld['page_id'])) {
		create_error('公開リンク情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	if (!$objLinks->deleteFromPageID($fld['page_id'], WORK_TABLE)) {
		create_error('編集リンク情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	//画像情報の登録、削除
	if (!$objImages->insertPublishFromWork($fld['page_id'])) {
		create_error('公開画像情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	if (!$objImages->deleteFromPageID($fld['page_id'], WORK_TABLE)) {
		create_error('編集画像情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	//ライブラリの登録、削除
	if (!$objHandler->insertLibraryPfromW($fld['page_id'])) {
		create_error('公開ライブラリ設定の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	if (!$objHandler->deleteLibrary($fld['page_id'], WORK_TABLE)) {
		create_error('編集ライブラリ設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	//自動リンク設定の登録、削除
	if (!$objHandler->insertAutoLinkPfromW($fld['page_id'])) {
		create_error('公開自動リンク設定の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	if (!$objHandler->deleteAutoLink($fld['page_id'], WORK_TABLE)) {
		create_error('編集自動リンク設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	//自動リンク設定の登録、削除
	if (!$objHandler->insertAutoLinkPagePfromW($fld['page_id'])) {
		create_error('公開自動リンク設定の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	if (!$objHandler->deleteAutoLinkPage($fld['page_id'], WORK_TABLE)) {
		create_error('編集自動リンク設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	//お問い合わせ情報の登録、削除
	if (!$objInquiry->insertPublishFromWork($fld['w_inquiry_id'])) {
		create_error('公開お問い合わせ情報の登録に失敗しました。<br>【' . $fld['w_inquiry_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	if (!$objInquiry->deleteFromID($fld['w_inquiry_id'], WORK_TABLE)) {
		create_error('編集お問い合わせ情報の削除に失敗しました。<br>【' . $fld['w_inquiry_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	//承認依頼の削除
	if ($objCGrp->deleteFromID($fld['w_group_id']) === FALSE) {
		create_error('承認グループの削除に失敗しました。<br>【' . $fld['w_group_id'] . '】', $cronFlg, $objCnc, $ftpCnc, $fld['w_page_title']);
		return FALSE;
	}
	//観光情報の登録、削除
	if (!$objKanko->insertPublishFromWork($fld['page_id'])) {
		create_error('公開観光情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	if (!$objKanko->deleteFromID($fld['page_id'], '', WORK_TABLE)) {
		create_error('編集観光情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	//アンケート
	if ($fld['template_kind'] == TEMPLATE_KIND_ENQUETE) {
		$w_enq_id_ary = $objEnq->getEnqueteId($fld['page_id'], WORK_TABLE);
		$p_enq_id_ary = $objEnq->getEnqueteId($fld['page_id'], PUBLISH_TABLE);
		//アンケート情報の登録
		if (!$objEnq->insertPfromW($fld['page_id'])) {
			create_error('公開アンケート情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
		//アンケート情報の削除
		$objEnq->add_where("page_id", $fld['page_id']);
		if (!$objEnq->delete("", WORK_TABLE)) {
			create_error('編集アンケート情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
		//アンケート詳細情報の数分ループ
		foreach ($p_enq_id_ary as $enq_id) {
			//アンケート詳細情報の削除
			$objEnqDtl->add_where("enquete_id", $enq_id);
			if (!$objEnqDtl->delete("", PUBLISH_TABLE)) {
				create_error('公開アンケート詳細情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				return FALSE;
			}
		}
		//アンケート詳細情報の数分ループ
		foreach ($w_enq_id_ary as $enq_id) {
			//アンケート詳細情報の登録
			if (!$objEnqDtl->insertPfromW($enq_id)) {
				create_error('公開アンケート詳細情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				return FALSE;
			}
			//アンケート詳細情報の削除
			$objEnqDtl->add_where("enquete_id", $enq_id);
			if (!$objEnqDtl->delete("", WORK_TABLE)) {
				create_error('編集アンケート詳細情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				return FALSE;
			}
		}
	}
	//ローカルナビを使用しているページ情報の登録、削除
	if (!$objGHandler->insertPfromW($fld['page_id'])) {
		create_error('公開グロナビ情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	if (!$objGHandler->delete_lnavi_page($fld['page_id'], WORK_TABLE)) {
		create_error('編集グロナビ情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	//否認理由のひも付け削除
	if (!$objAppHandler->delete_denial_msg($fld['page_id'])) {
		create_error('前回の否認理由の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	//サイトマップ情報の登録（コピー）
	if (!$objSitemapHandler->copy_entry_page($fld['page_id'], PUBLISH_TABLE)) {
		create_error('公開サイトマップ設定の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	//サイトマップを使用しているページ情報の削除
	if (!$objSitemapHandler->delete_entry_page($fld['page_id'], WORK_TABLE)) {
		create_error('サイトマップ設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	// 大規模災害用分類一覧ページ紐付け情報の削除
	if (!deleteDisasterListTop($fld['page_id'], WORK_TABLE)) {
		create_error('大規模災害用分類一覧ページ情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	//広告情報の登録、削除
	if (ENABLE_OPTION_ADVERT) {
		//広告情報の登録（コピー）
		if (!$objHandler->copyAdvertPage($fld['page_id'], PUBLISH_TABLE)) {
			create_error('公開広告設定の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
		//広告情報の削除
		if (!$objHandler->deleteAdvertPage($fld['page_id'], WORK_TABLE)) {
			create_error('編集広告設定の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
	}
	//外部連携データ管理設定登録、削除
	if (ENABLE_OPTION_OUTPUT) {
		if (!$objOpHndl->insertPublishFromWork($fld['page_id'])) {
			create_error('公開外部連携データ設定情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
		if (!$objOpHndl->deletePage($fld['page_id'], HANDLER_OUTPUT_CLASS_WORK_PAGE)) {
			create_error('編集外部連携データ設定情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
	}
	
	//地図情報の登録、削除
	if (ENABLE_OPTION_GOOGLEMAP) {
		if (!$objMap->insertPublishFromWork($fld['page_id'])) {
			create_error('地図情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
		if (!$objMap->deleteFromPID($fld['page_id'], WORK_TABLE)) {
			create_error('地図情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
	}
	if(ENABLE_OPEN_DATA_FLG){
		// オープンデータ
		// オープンデータ編集情報の登録（コピー）
		if (!$obj_open_data_edit->insertPublishFromWork($fld['page_id'])) {
			create_error('オープンデータ編集情報の登録に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
		// オープンデータ編集情報の削除
		if (!$obj_open_data_edit->deleteFromID($fld['page_id'], '', '', '', WORK_TABLE)) {
			create_error('オープンデータ編集情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
	}
	
	//CMS内の関連ファイルの削除
	$deleteReration = array();
	$ary = array(
			"item1" => $fld['page_id']
	);
	$objHandler->_select(HANDLER_CLASS_PUBLISH_DELETE_FILE, $ary, "item2");
	while ($objHandler->fetch()) {
		$deleteReration[] = $objHandler->fld;
	}
	//ファイルを削除するかチェック
	$error_msg = "";
	foreach ($deleteReration as $info) {
		//関連ファイルのパス
		$path = $info['item2'];
		//ページで使用されている場合は無視
		if ($objLinks->useLinkFileCheck($path, PUBLISH_TABLE) === FALSE) {
			continue;
		}
		if ($objLinks->useLinkFileCheck($path, WORK_TABLE) === FALSE) {
			continue;
		}
		if ($objImages->useImageCheck($path, PUBLISH_TABLE) === FALSE) {
			continue;
		}
		if ($objImages->useImageCheck($path, WORK_TABLE) === FALSE) {
			continue;
		}
		//アンケートで使用されている場合は無視
		$where = $objEnq->_addslashesC("img_src", $path, "LIKE", "TEXT");
		$objEnq->setTableName(PUBLISH_TABLE);
		$objEnq->select($where);
		if ($objEnq->getRowCount() > 0) {
			continue;
		}
		$objEnq->setTableName(WORK_TABLE);
		$objEnq->select($where);
		if ($objEnq->getRowCount() > 0) {
			continue;
		}
		
		// 定型情報
		//公開
		if ($objKanko->checkUseFiles($path, PUBLISH_TABLE)) {
			continue;
		}
		//編集
		if ($objKanko->checkUseFiles($path, WORK_TABLE)) {
			continue;
		}
		
		//情報の削除
		if (!$objHandler->deletePublishDeleteFilePath($path)) {
			create_error('関連ファイル情報の削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
		//FCKテーブルの情報削除
		if (!$objFCKLinks->deleteFromPageID($path)) {
			create_error('ファイル情報の削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
		if (!$objFCKImages->deleteFromImagePath($path)) {
			create_error('画像情報の削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
		//ファイルが存在すれば削除
		if (@is_file(DOCUMENT_ROOT . RPW . $path) && !@unlink(DOCUMENT_ROOT . RPW . $path)) {
			create_error('関連ファイルの削除に失敗しました。<br>【' . $path . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
	}
	
	//ページで保存した削除関連ファイル情報の削除
	if (!$objHandler->deletePublishDeleteFile($fld['page_id'])) {
		create_error('関連ファイル情報の削除に失敗しました。<br>【' . $fld['page_id'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
		return FALSE;
	}
	
	//ページファイルの移動
	if ($fld['p_file_path'] != $fld['w_file_path']) {
		//ファイルのコピー
		if (mkNewDirectory(DOCUMENT_ROOT . RPW . $fld['w_file_path']) == FALSE || !@copy(DOCUMENT_ROOT . RPW . $fld['p_file_path'], DOCUMENT_ROOT . RPW . $fld['w_file_path'])) {
			create_error('HTMLファイルの移動に失敗しました。<br>【' . $fld['p_file_path'] . ' ⇒ ' . $fld['w_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
		//移動前のファイルを削除
		if (!@unlink(DOCUMENT_ROOT . RPW . $fld['p_file_path'])) {
			create_error('作業用HTMLファイルの削除に失敗しました。<br>【' . $fld['p_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
			return FALSE;
		}
		//自動掲載された携帯ページの移動
		if ($objTool->checkMobileTemplate($fld['page_id'])) {
			//ファイルのコピー
			if (mkNewDirectory(DOCUMENT_ROOT . RPW . DIR_PATH_MOBILE . $fld['w_file_path']) == FALSE || !@copy(DOCUMENT_ROOT . RPW . DIR_PATH_MOBILE . $fld['p_file_path'], DOCUMENT_ROOT . RPW . DIR_PATH_MOBILE . $fld['w_file_path'])) {
				create_error('HTMLファイルの移動に失敗しました。<br>【' . $fld['p_file_path'] . ' ⇒ ' . $fld['w_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				return FALSE;
			}
			//移動前のファイルを削除
			if (!@unlink(DOCUMENT_ROOT . RPW . DIR_PATH_MOBILE . $fld['p_file_path'])) {
				create_error('作業用HTMLファイルの削除に失敗しました。<br>【' . $fld['p_file_path'] . '】', $cronFlg, $objCnc, $fld['w_page_title']);
				return FALSE;
			}
		}
	}
	
	//正常に終了
	return TRUE;
}
			
?>
