<?php
/*
 *
 */
require ("../.htsetting");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>手動アップロード</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/upload.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/upload.js" type="text/javascript"></script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'upload';
include (APPLICATION_ROOT . "/common/inc/header_menu.inc");
require_once (APPLICATION_ROOT . '/common/function/func_progressbar.inc');
$pgrs_func = new progressbar();
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-upload">
<div><img src="<?=RPW?>/admin/images/upload/bar_upload.jpg"
	alt="手動アップロード" width="920" height="30"></div>
<div class="cms8341-area-corner">
<?php
echo $pgrs_func->get_progress_area();
// アップロードPHP
require_once (DOCUMENT_ROOT . RPW . '/admin/page/upload/upload_exec.php');
if (count($success_list) == 0) {
	?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="center" valign="middle" scope="col"
			style="font-weight: normal">&nbsp;</th>
	</tr>
	<tr>
		<td align="center" valign="middle">成功したページはありません。</td>
	</tr>
</table>
<?php
}
else {
	?>
<table width="100%" border="10" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-uploadlist">
	<tr>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">タイトル</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">結果</th>
	</tr>
<?php
	foreach ($success_list as $key => $value) {
		LIST(, $page_title) = explode(":", $key, 2);
		print '<tr>' . "\n";
		print '<td width="350" align="left" valign="top" nowrap><strong>' . htmlDisplay($page_title) . '</strong></td>' . "\n";
		print '<td align="left" valign="top" style="word-break:break-all;">' . $value . '</td>' . "\n";
		print '</tr>' . "\n";
	}
	?>
</table>
<?php
}
?>
<br>
<?php
if (count($fail_list) == 0) {
	?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="center" valign="middle" scope="col"
			style="font-weight: normal">&nbsp;</th>
	</tr>
	<tr>
		<td align="center" valign="middle">失敗したページはありません。</td>
	</tr>
</table>
<?php
}
else {
	?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-uploadlist">
	<tr>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">タイトル</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">結果</th>
	</tr>
<?php
	foreach ($fail_list as $key => $value) {
		print '<tr>' . "\n";
		print '<td width="350" align="left" valign="top" nowrap><strong>' . htmlDisplay($key) . '</strong></td>' . "\n";
		print '<td align="left" valign="top" style="word-break:break-all;">' . $value . '</td>' . "\n";
		print '</tr>' . "\n";
	}
	?>
</table>
<?php
}
?>


</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
