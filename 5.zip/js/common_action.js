/*
 * 共通関数javascript
 */
var active_menu;
//edit
function cxEdit(form, url) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	$(form).action = url;
	$(form).target = '';
	$(form).cms_dispMode.value = 'edit';
	$(form).submit();
	return false;
}
//cancel
function cxCancel(form, pid) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	if (!confirm("編集中の情報は削除されます。\n作業の取り消しをしてよろしいですか？")) {
		return false;
	}
	// チェック
	if ( cxWorkDependFileDeleteCheck(pid, callAfterCxWorkDependFileDeleteCheck) == false ) {
		return false;
	}
	
	function callAfterCxWorkDependFileDeleteCheck() {
		$(form).action = cms8341admin_path+'/page/common/editcancel.php';
		$(form).target = '';
		if(pid != undefined && pid != "")$(form).cms_page_id.value = pid;
		if($('cms_dispMode')) $('cms_dispMode').value = 'edit_cancel';
		$(form).submit();
	}
	
	return false;
}
//newpage
var add_newpage_form;
var add_newpage_pid;
function cxAddNewpage(form, pid) {
	add_newpage_form = form;
	add_newpage_pid = pid;
	var prm = 'page_id='+pid;
	cxAjaxCommand('cxIsPankuzuLimitOver', prm, cxIsPankuzuLimitOverSuccess);
}
// 自動リンクで親ページの設定がされていないかチェック
function cxIsPankuzuLimitOverSuccess(r){
	var rText = r.responseText;
	if(rText == "true"){
		alert("新規作成したページの階層がパンくず階層制限を越えるため作成できません。");
		return false;
	}
	cxAddNewpageExec(add_newpage_form, add_newpage_pid);
}
function cxAddNewpageExec(form, pid) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	$(form).action = cms8341admin_path+'/page/common/newpage.php';
	$(form).target = '';
	$(form).cms_dispMode.value = 'new';
	if(pid != undefined && pid != "")$(form).cms_page_id.value = pid;
	$(form).submit();
	return false;
}
//newpage
function cxAddCopy(form, pid) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	$(form).action = cms8341admin_path+'/page/common/newpage.php';
	$(form).target = '';
	$(form).cms_dispMode.value = 'copy';
	if(pid != undefined && pid != "")$(form).cms_page_id.value = pid;
	$(form).submit();
	return false;
}
//Preview
function cxPreview(form, pid, mode, color) {
	if(element_id) cxCloser(element_id);
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	if($('cms_template_kind') && $('cms_work_class')){
		if($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE){
			if($F('cms_work_class') == 1 || $F("cms_from_type") == ENQ_KIND_MAIL){
				EnqItemCreateForm();
			}
		}
		if($F('cms_template_kind') == TEMPLATE_KIND_FIXED || ($('kanko_xml') && $F('kanko_xml') != "")){
			kankoCustomItemCreate();
		}
	}
	window.open(cms8341admin_path+'/page/common/blank.html','preview','status=no,menubar=no,toolbar=no,scrollbars=yes,resizable=yes');
	$(form).target = 'preview';
	$(form).action = cms8341admin_path+'/page/common/preview.php';
	if(pid != undefined && pid != "")$(form).cms_page_id.value = pid;
	$(form).cms_dispMode.value = mode;
	if (color) {
		$(form).cms_preview_color.value = color;
		$(form).cms_preview_color.disabled = false;
	}
	$(form).submit();
	$(form).cms_preview_color.disabled = true;
	return false;
}
//デザインビュー
function cxView(t, url) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	$(t).action = url;
	$(t).target = '';
	//$(t).cms_dispMode.value = 'view';
	$(t).submit();
	return false;
}
function cxFolderView(t,dir) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	$(t).action = cms8341admin_path+'/page/siteview/treelist.php?dir_path='+dir;
	$(t).target = '';
	$(t).submit();
	return false;
}
// accessibility check window open
function cxAccessibilityCheck(form, pid, mode) {
	if(prev_submenu_id) {
		cxTotalCheckCloser(prev_submenu_id);
		prev_submenu_id = false;
	}
	if($('cms_template_kind') && $('cms_work_class')){
		if($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE){
			if($F('cms_work_class') == 1 || $F("cms_from_type") == ENQ_KIND_MAIL){
				EnqItemCreateForm();
			}
		}
		if($F('cms_template_kind') == TEMPLATE_KIND_FIXED || ($('kanko_xml') && $F('kanko_xml') != "")){
			kankoCustomItemCreate();
		}
	}
	edit_closet_flg = false;
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	window.name='win_cms8341Main';
	window.open(cms8341admin_path+'/page/common/blank.html','access','status=no,menubar=no,toolbar=no,scrollbars=yes,resizable=yes');
	$(form).action = cms8341admin_path+'/page/common/accessibility_check.php';
	$(form).target = 'access';
	if(pid != undefined && pid != "")$(form).cms_page_id.value = pid;
	$(form).cms_dispMode.value = mode;
	$(form).submit();
	return false;
}
// link check window open
function cxLinkCheck(form, pid, mode) {
	if(prev_submenu_id) {
		cxTotalCheckCloser(prev_submenu_id);
		prev_submenu_id = false;
	}
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	window.open(cms8341admin_path+'/page/common/blank.html','link','width=500,height=500,status=no,menubar=no,toolbar=no,scrollbars=no,resizable=no');
	$(form).action = cms8341admin_path+'/page/common/link_check.php';
	$(form).target = 'link';
	if(pid != undefined && pid != "")$(form).cms_page_id.value = pid;
	$(form).cms_dispMode.value = mode;
	$(form).submit();
	return false;
}
//headline check open
function cxHeadlineCheck(form, pid, mode) {
	if(prev_submenu_id) {
		cxTotalCheckCloser(prev_submenu_id);
		prev_submenu_id = false;
	}
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	window.open(cms8341admin_path+'/page/common/blank.html','headline','width=500,height=500,status=no,menubar=no,toolbar=no,scrollbars=no,resizable=no');
	$(form).action = cms8341admin_path+'/page/common/headline_check.php';
	$(form).target = 'headline';
	if(pid != undefined && pid != "")$(form).cms_page_id.value = pid;
	$(form).cms_dispMode.value = mode;
	$(form).submit();
	return false;
}
//contrast check open
function cxContrastCheck(form, pid, mode) {
	if(prev_submenu_id) {
		cxTotalCheckCloser(prev_submenu_id);
		prev_submenu_id = false;
	}
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	window.open(cms8341admin_path+'/page/common/blank.html','contrast','status=no,menubar=no,toolbar=no,scrollbars=yes,resizable=yes');
	$(form).action = cms8341admin_path+'/page/common/contrast_check.php';
	$(form).target = 'contrast';
	if(pid != undefined && pid != "")$(form).cms_page_id.value = pid;
	$(form).cms_dispMode.value = mode;
	$(form).submit();
	return false;
}
// spell check window open
function cxSpellCheck(form, pid, mode) {
	if(prev_submenu_id) {
		cxTotalCheckCloser(prev_submenu_id);
		prev_submenu_id = false;
	}
	if($('cms_template_kind') && $('cms_work_class')){
		if($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE){
			if($F('cms_work_class') == 1 || $F("cms_from_type") == ENQ_KIND_MAIL){
				EnqItemCreateForm();
			}
		}
		if($F('cms_template_kind') == TEMPLATE_KIND_FIXED || ($('kanko_xml') && $F('kanko_xml') != "")){
			kankoCustomItemCreate();
		}
	}
	edit_closet_flg = false;
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	window.name='win_cms8341Main';
	window.open(cms8341admin_path+'/page/common/blank.html','spell','status=no,menubar=no,toolbar=no,scrollbars=yes,resizable=yes');
	$(form).action = cms8341admin_path+'/page/common/spell_check.php';
	$(form).target = 'spell';
	if(pid != undefined && pid != "")$(form).cms_page_id.value = pid;
	$(form).cms_dispMode.value = mode;
	$(form).submit();
	return false;
}
// delete
var exec_mode;
var exec_form;
var exec_pid;
// 削除
function cxDelete(form, pid) {
	exec_mode = "delete";
	exec_form = form;
	if(pid == "") pid = $(form).cms_page_id.value;
	exec_pid = pid;
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	if (!confirm('ページのステータスを削除にします。\nよろしいですか？')) {
		return false;
	}
	var prm = 'page_id='+pid;
	cxAjaxCommand('cxIsParentCondition', prm, cxIsParentConditionSuccess);
}	
function cxDeleteExec(form,pid){
	$(form).action = cms8341admin_path+'/page/common/deleterequest.php';
	$(form).target = '';
	$(form).cms_dispMode.value = 'delete';
	if(pid != undefined && pid != "")$(form).cms_page_id.value = pid;
	$(form).submit();
	return false;
}
// close
function cxClose(form, pid) {
	exec_mode = "close";
	exec_form = form;
	if(pid == "") pid = $(form).cms_page_id.value;
	exec_pid = pid;
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	if (!confirm('ページのステータスを非公開にします。\nよろしいですか？')) {
		return false;
	}
	var prm = 'page_id='+pid;
	cxAjaxCommand('cxIsParentCondition', prm, cxIsParentConditionSuccess);
}
function cxCloseExec(form,pid){
	$(form).action = cms8341admin_path+'/page/common/closerequest.php';
	$(form).target = '';
	$(form).cms_dispMode.value = 'delete';
	if(pid != undefined && pid != "")$(form).cms_page_id.value = pid;
	$(form).submit();
	return false;
}
// 自動リンクで親ページの設定がされていないかチェック
function cxIsParentConditionSuccess(r){
	var rText = r.responseText;
	if(rText == "true"){
		alert("このページは自動リンクの親ページに設定されているため実行できません");
		return false;
	}
	if(exec_mode == "delete"){
		cxDeleteExec(exec_form, exec_pid);
	} else if(exec_mode == "close") {
		cxCloseExec(exec_form, exec_pid);
	}
}
// publish cancel
function cxPubCancel(form, pid) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	if (!confirm("公開を中止してよろしいですか？")) {
		return false;
	}
	$(form).action = cms8341admin_path+'/page/common/publishcancel.php';
	$(form).target = '';
	if(pid != undefined && pid != "")$(form).cms_page_id.value = pid;
	$(form).submit();
	return false;
}

// 組織からお問い合わせ情報を取得
function cxGetInquiryDeptInfo(num,target){
	target_add = "";
	edit_closet_flg = false;
	if($('cms8341-property')) target_add = "prop_";
	dept_code = "";
	inq_num = num;
	inq_target = target;
	for(i = 1; i < 4; i++){
		if($('cms_inquiry_'+target_add+'dept'+i+'_'+inq_num).value == "") continue;
		dept_code = $('cms_inquiry_'+target_add+'dept'+i+'_'+inq_num).value;
	}
	if(dept_code == "")return;
	var prm = 'dept_code='+dept_code+'&target='+inq_target;
	cxAjaxCommand('cxGetInquiryDeptInfo', prm, cxGetInquiryDeptInfoSuccess);
}
function cxGetInquiryDeptInfoSuccess(r){
	target_add = "";
	if($('cms8341-property')) target_add = "prop_";
	var rText = r.responseText;
	switch(inq_target){
		case "tel":
			$('cms_inquiry_'+target_add+'directNumber_'+inq_num).value = rText;
			break;
		case "fax":
			$('cms_inquiry_'+target_add+'fax_'+inq_num).value = rText;
			break;
		case "email":
			$('cms_inquiry_'+target_add+'email_'+inq_num).value = rText;
			break;
	}

}

function cxContentsMenu(t) {
	//display:none
/*	if($('cms8341-calendar')){
		var c = $('cms8341-calendar');
		if(c.style.display=='block') c.style.display = 'none';
	}
	if($('cms8341-template-select')){
		var temp = $('cms8341-template-select');
		if(temp.style.display=='block') temp.style.display = 'none';
	}
*/
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	//main
	$(t).style.display = 'block';
	$(t).style.left = event.clientX + 'px';
	var wh = document.documentElement.clientHeight;
	var st = (document.compatMode == "CSS1Compat") ? document.documentElement.scrollTop: document.body.scrollTop;
	var ey = event.clientY;
	var eh = $(t).clientHeight;
	$(t).style.top = ey + st + 'px';
	var sc_sw = ey + eh > wh ? true:false;
	if(sc_sw) {
		var scSize = (ey+eh) - wh + 20;
		var smax = 0;
		while(smax < scSize) {
			window.scrollBy(0,20);
			smax += 20;
		}
	}
	//keep
	active_menu = t.substr(t.lastIndexOf("_")+1);
	cms_prev_layer = $(t);
}
//blindup toggle
function cxBlind(t,btn) {
	cxComboVisible();
	//display:none
	if($('cms8341-calendar')){
		var c = $('cms8341-calendar');
		if(c.style.display=='block') c.style.display = 'none';
	}
	if($('cms8341-property')){
		var p = $('cms8341-property');
		if(p.style.display=='block') p.style.display = 'none';
	}
	if($('cms8341-template-select')){
		var temp = $('cms8341-template-select');
		if(temp.style.display=='block') temp.style.display = 'none';
	}
	//main
	$(btn).blur();
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	Effect.toggle(t,'blind',
				{duration:0.5,
					afterFinishInternal:function(){
											var alt = $(btn).alt;
											if(alt=='開く') {
												$(btn).src = cms8341admin_path+'/images/btn/btn_close_mini.jpg';
												$(btn).alt = '閉じる';
//												new Effect.ScrollTo(t,{duration:0.5})
											} else {
												$(t).style.display = 'none';
												$(btn).src = cms8341admin_path+'/images/btn/btn_open_mini.jpg';
												$(btn).alt = '開く';
											}
										}
	});
}
//pageproperty open
function cxPageProperty(pid,mode,num) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	if($('cms8341-calendar')){
		var c = $('cms8341-calendar');
		if(c.style.display=='block') c.style.display = 'none';
	}
	if($('cms8341-template-select')){
		var temp = $('cms8341-template-select');
		if(temp.style.display=='block') temp.style.display = 'none';
	}
	cxComboHidden();
	cxLayer('cms8341-property',1,502,525);
	var pb = $('cms8341-propertybody');
	pb.innerHTML = '<p>処理中です...</p>';
	var prm = 'cms_page_id='+pid+'&mode='+mode;
	cxAjaxCommand('cxGetProperty', prm, cxPPSuccess);
	if(num != undefined && num != "")active_menu = num;
//	return false;
}
function cxPPSuccess (r) {
	var rText = r.responseText;
	ret = rText.split("<!--AutoLinksBody-->");
	if (ret[0]) {
		var pb = $('cms8341-propertybody');
		pb.innerHTML = ret[0];
//		$('cms_publish_start_prop').innerHTML = $('cms_publish_skip_start_'+active_menu).innerHTML+"から";
//		$('cms_publish_end_prop').innerHTML = $('cms_publish_skip_start_'+active_menu).innerHTML+"まで";
	}
	if (ret[1]) {
		var al = $('cms8341-autolinksbody');
		al.innerHTML = ret[1];
	}
}
//通信失敗処理
function cxFailure() {
	if($('cms8341-propertybody')){
		var pb = $('cms8341-propertybody');
		pb.innerHTML = '<p align="center">情報取得中に通信エラーが発生しました</p>';
	}
}
// カレンダー
function cxCalendarOpen(target, mode) {
	if($('cms8341-reffer'))cxLayer('cms8341-reffer',0);
	if($('cms8341-denail')) $('cms8341-denail').style.display = 'none';
	if($('cms8341-request')) $('cms8341-request').style.display = 'none';
	if ($('cms8341-category')) {
		cxLayer('cms8341-category', 0);
	}
	
//	cxAutoLinksClose();
//	cxTemplateClose();
	edit_closet_flg = false;
	if (mode == undefined || mode == ""){
		cxCalendarSet(target+'y',target+'m',target+'d',target+'h');
	} else if (mode == 'start') {
		cxCalendarSet(target+'sy',target+'sm',target+'sd',target+'sh');
	} else if (mode == 'end') {
		cxCalendarSet(target+'ey',target+'em',target+'ed',target+'eh');
	}
	// イベントカレンダー複数日対応
	else if (mode == 'select' && EVENT_CAL_MULTI_FLAG == true) {
		cxCheckboxCalendarSet(target);
	}
	cxComboHidden(new Array("cms_template_id", 'opendata_license'));
}
function cxCalendarClose() {
	//プロパティレイヤーが表示されていない場合
	if(!$('cms8341-property') || $('cms8341-property').style.display == 'none'){
		//セレクトボックスを表示する
		cxComboVisible();
	}
	else {
		// プロパティレイヤー内のセレクトボックスを表示する
		cxComboVisible('cms8341-property');
	}
	edit_closet_flg = false;
	cxLayer('cms8341-calendar',0);
}
function cxAutoLinksSet() {
	edit_closet_flg = false;
	var li = '';
	var a_link_id = '';
	prm = "a_link_id=" + $F('cms_a_link_id') + "&index_title=" + encodeURIComponent($F('cms_index_title'));
	//ダイアログの表示
	cxIframeLayer(
			cms8341admin_path + "/page/common/autolink/index.php?" + prm,
			630,
			660,
			COVER_SETTING.COLOR,
			'',
			function (retObj) {
				if (retObj == undefined) {
					return;
				}
				if (retObj['a_link_id'] != "") {
					tmpAry = retObj['a_link_id'].split(AUTOLINK_DELIMITER);
					for (i = 0; i < tmpAry.length; i++) {
						a_link_ary = tmpAry[i].split(":");
						if (a_link_id != "") {
							a_link_id += ",";
						}
						a_link_id += a_link_ary[0];
						li += '<li>' + a_link_ary[1] + '</li>';
					}
				}
				if (li) {
					$('cms-auto-links').innerHTML = li;
					$('cms-auto-links').style.display = 'block';
				} else {
					$('cms-auto-links').style.display = 'none';
				}
				if (retObj['index_title'] == "") {
					$('cms-link-title').innerHTML = "リンク掲載用タイトルは設定されていません。";
				} else {
					$('cms-link-title').innerHTML = "リンク掲載用タイトルに【" + cxEscapeHtmlChars(retObj['index_title']) + "】を設定します。";
				}
				$('cms_a_link_id').value = a_link_id;
				$('cms_index_title').value = retObj['index_title'];
			}
	);
}

function cxPublicEndUnrestricted(){
	var y = "";
	var m = "";
	var d = "";
	var h = "";
	
	var checkbox_name = "cms-pubend-Unrestricted-ws";
	if ($('cms-pubend-Unrestricted-ws')) {
		checkbox_name = "cms-pubend-Unrestricted-ws";
		y = "cms_pdey";
		m = "cms_pdem";
		d = "cms_pded";
		h = "cms_pdeh";
	}
	else if ($('cms-pubend-Unrestricted-wf')) {
		checkbox_name = "cms-pubend-Unrestricted-wf";
		y = "cms_pey_l";
		m = "cms_pem_l";
		d = "cms_ped_l";
		h = "cms_peh_l";
	}
	else if ($('cms-pubend-Unrestricted-edit')) {
		checkbox_name = "cms-pubend-Unrestricted-edit";
		y = "cms_pubey";
		m = "cms_pubem";
		d = "cms_pubed";
		h = "cms_pubeh";
	}

	cxDisabledChange(y);
	cxDisabledChange(m);
	cxDisabledChange(d);
	cxDisabledChange(h);

	if($(checkbox_name) && $(checkbox_name).value == ""){
		$(checkbox_name).value = "1";
	} else {
		$(checkbox_name).value = "";
	}

	if($(checkbox_name).checked == true){
		$(y).style.backgroundColor="#C0C0C0";
		$(m).style.backgroundColor="#C0C0C0";
		$(d).style.backgroundColor="#C0C0C0";
		$(h).style.backgroundColor="#C0C0C0";
	} else {
		$(y).style.backgroundColor="#FFFFFF";
		$(m).style.backgroundColor="#FFFFFF";
		$(d).style.backgroundColor="#FFFFFF";
		$(h).style.backgroundColor="#FFFFFF";
	}
}

// 表示／非表示切り替え
function cxDisabledChange(id){
	if($(id).disabled){
		$(id).disabled = false;
	} else {
		$(id).disabled = true;
	}	
}

function cxOpenMailForm() {
		cxIframeLayer(
						cms8341admin_path + "/page/common/enq/mail_form.php",
						800,
						780,
						COVER_SETTING.COLOR,
						'',
						function (retObj) {
								if (retObj == undefined)
										return;
								mailAry = new Array();
								nameAry = new Array();
								enqEl = document.getElementById("cms_enquete_emai_list");
								for (i = 0; i < enqEl.getElementsByTagName("span").length; i++) {
										id = enqEl.getElementsByTagName("span")[i].getAttribute("ID");
										if (id == null)
												return;
										if (id == "cms_enqmail_" + retObj['email'])
												return;
										if (id.indexOf("cms_enqmail_") == 0) {
												mailAry.push(id);
										}
										if (id.indexOf("cms_enqname_") == 0) {
												nameAry.push(id);
										}
								}
								newStr = '<table cellspacing="0" cellpadding="5" border="1" style="margin-top:10px;border-collapse:collapse">';
								for (i = 0; i < mailAry.length; i++) {
										email_id = mailAry[i];
										name_id = nameAry[i];
										newStr = newStr + '<tr id="mail_tr_' + email_id + '">';
										newStr = newStr + '<td><span id="cms_enqname_' + email_id.slice("cms_enqmail_".length) + '">' + $(name_id).innerHTML + '</span></td>';
										newStr = newStr + '<td><span id="' + email_id + '">' + $(email_id).innerHTML + '</span></td>';
										newStr = newStr + '<td><img src="' + cms8341admin_path + '/images/set_enquete/item_del.gif" alt="削除する" onClick="cxEnqMailDel(\'mail_tr_' + email_id + '\')" style="cursor:pointer"></td>';
										newStr = newStr + '</tr>';
								}
								newStr = newStr + '<tr id="mail_tr_cms_enqmail_' + retObj['email'] + '">';
								newStr = newStr + '<td><span id="cms_enqname_' + retObj['email'] + '">' + htmlspecialcharsMailForm(retObj['name']) + '</span></td>';
								newStr = newStr + '<td><span id="cms_enqmail_' + retObj['email'] + '">' + retObj['email'] + '</span></td>';
								newStr = newStr + '<td><img src="' + cms8341admin_path + '/images/set_enquete/item_del.gif" alt="削除する" onClick="cxEnqMailDel(\'mail_tr_cms_enqmail_' + retObj['email'] + '\')" style="cursor:pointer"></td>';
								newStr = newStr + '</tr>';
								newStr = newStr + '</table>';
								$('cms_enquete_emai_list').innerHTML = newStr;
						});
}
/******************************************************
htmlspecialcharsMailForm
問い合わせ時のメールフォールで使用
HTML表示用文字に置換する
******************************************************/
function htmlspecialcharsMailForm(ch){
	ch = ch.replace(/&/g,"&amp;");
	ch = ch.replace(/"/g,"&quot;");
	ch = ch.replace(/'/g,"&#039;");
	ch = ch.replace(/</g,"&lt;");
	ch = ch.replace(/>/g,"&gt;");
	return ch;
}
function cxEnqMailDel(id){
	Element.remove($(id));
}
function cmEnqEmailStringCreate( ) {
	mail_cnt = 0;
	
	$('cms_enq_email').value = "";
	
	enqEl = document.all("cms_enquete_emai_list");
	for (i = 0; i < enqEl.getElementsByTagName("span").length; i++) {
		id = enqEl.getElementsByTagName("span")[i].getAttribute("ID");
		if(id == null)continue;
		if(id.indexOf("cms_enqmail_") == 0){
			id = id.slice("cms_enqmail_".length); 
			$('cms_enq_email').value = ($F('cms_enq_email') != "" ? $F('cms_enq_email') + "," : "" ) + $('cms_enqmail_'+id).innerHTML + ":" + $('cms_enqname_'+id).innerHTML;
			mail_cnt++;
		}
	}
	return mail_cnt;
}

var set_keywords_element = "";
// テンプレートに指定された検索エンジン用キーワードを取得
function cxGetTemplateKeywords(element, id_element, ver_element ){
	// ID格納エレメントの指定がない
	if ( ! id_element || ! $(id_element) ) return ;
	// 戻り値格納先
	set_keywords_element = element;
	// パラメータ
	var prm = "cms_template_id="+$F(id_element);
	if (ver_element && $(ver_element)) prm += "&cms_template_ver="+$(ver_element).value;
	// Ajaxで取得
	cxAjaxCommand('cxGetTemplateKeywords', prm, cxGetTemplateKeywordsSuccess);
}
function cxGetTemplateKeywordsSuccess(r){
	// 
	if ( $(set_keywords_element) ) {
		// 取得した文字列
		var rText = r.responseText;
		// カンマで区切る
		var rAry = rText.split(",");
		var nAry = $(set_keywords_element).value.split(",");
		// 取得したキーワードの数だけループ
		for ( var i = 0 ; i < rAry.length ; i ++ ) {
			// 既存の検索エンジン用キーワードに指定がない場合追加
			if ( rAry[i] != "" && ! in_array( rAry[i], nAry ) ) {
				// 検索エンジン用キーワードに追加
				$(set_keywords_element).value += ( $(set_keywords_element).value != "" ? "," : "" ) + rAry[i];
				// 既存配列に挿入
				nAry.push( rAry[i] );
			}
		}
	}
}

var cms_l_sid;
var cms_l_inv_cnt = 0;
var cms_l_inv_tim = 200;
var cms_l_inv_max = 25;

function cxSelectLibrary() {
	var si = $('cms-library-combo').options.selectedIndex;
	var id = $('cms-library-combo').options[si].value;
	
	if ( si > 0 ) {
		$('cms_thumb_library').src = cms8341admin_path+"/page/common/libview.php?id="+id+"&non_event=1";
		if(cms_l_sid) clearInterval(cms_l_sid);
		cms_l_sid = 0;
		cms_l_inv_cnt = 0;
		cms_l_sid = setInterval(cxIFrameZoomLibrary,cms_l_inv_tim);
	} else {
		$('cms_thumb_library').src = 'javascript:';
	}
}

function cxIFrameZoomLibrary() {
	if($('cms_thumb_library').contentWindow.document.body){
		var thumb_body = $('cms_thumb_library').contentWindow.document.body;
		thumb_body.style.position = "relative";
		thumb_body.style.transform = "scale(0.5)";
		thumb_body.style.transformOrigin = "0 0";
		thumb_body.style.webkitTransform = "scale(0.5)";
		thumb_body.style.webkitTransformOrigin = "0 0";
	}
	//
	cms_l_inv_cnt++;
	if(cms_l_inv_cnt > cms_l_inv_max) {
		clearInterval(cms_l_sid);
		cms_l_inv_cnt = 0;
	}
}

// fileuse check window open
function cxUseFileCheck(form,path) {
	if(prev_submenu_id) {
		cxTotalCheckCloser(prev_submenu_id)
		prev_submenu_id = false;
	}
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	if ($('cms_file_path')) {
		$('cms_file_path').value = path;
	}
		cxIframeLayer(cms8341admin_path+'/page/common/blank.html', 500, 550, COVER_SETTING.COLOR, 'usefile');
		$(form).action = cms8341admin_path+'/page/common/usefile_check.php';
	$(form).target = 'usefile';
	$(form).submit();
	return false;
}
// 作業の取り消し時の依存ファイル削除チェック
function cxWorkDependFileDeleteCheck(pid, callback){
	var ret_ajax_pf;
	var params = "";
	// パラメーターの作成
	params = 'pid=' + pid;
	// Ajax でPHPに接続
	var ajax = new Ajax.Request(
		cms8341admin_path+'/page/common/linkfile/w_del_confirm.php',
		{
			method: 'post',
			asynchronous: false,
			parameters: params
		}
	);
	// PHP からの戻り値(print)を取得
	ret_ajax_pf = ajax.transport.responseText;
	
	// エラーフラグ
	var _error = ret_ajax_pf.charAt(0);
	// 削除フラグ
	var _exec = ret_ajax_pf.substr(2);
	
	// 戻り値が不正な場合はアラート
	if ( _error == "-1" ) {
		alert( _exec );
		return false;
	}
	// true の場合は削除できるファイルがあるので確認画面を表示
	else if (_exec == 'true') {
		cxIframeLayer(
			cms8341admin_path + '/page/common/linkfile/w_del_dialog.php',
			628,
			400,
			COVER_SETTING.COLOR,
			'',
			function (retObj) {
				// 削除しない
				$('cms_unuse_delete').value = FLAG_OFF;

				//「はい」選択の場合は削除する
				if (retObj['delete'] && retObj['delete'] == FLAG_ON)
					$('cms_unuse_delete').value = FLAG_ON;
				
				if (callback) {
					callback();
				}
			}
		);
	}
	else {
		if (callback) {
			callback();
		}
	}
	return true;
}
/*
 * 否認理由表示
 * @palam	page_id		対象ページID
 * @return	false
 */
function cxDenialMsg(page_id) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	if(typeof WorkFlowdelLayer == "function") WorkFlowdelLayer();
	cxComboHidden();
	cxLayer('cms8341-denial',1,500,280);
	$('cms8341-denialmsg').innerHTML = '<p>処理中です...</p>';
	var prm = 'cms_page_id='+page_id;
	cxAjaxCommand('cxGetDenialMsg', prm, cxGetDenialMsgOK);
	return false;
}
/*
 * 否認理由表示(Ajaxの戻り値)
 */
function cxGetDenialMsgOK(r){
	var rText = r.responseText;
	if(rText != 'false'){
		$('cms8341-denialmsg').innerHTML = rText;
	}
	else{
		$('cms8341-denialmsg').innerHTML = '<p>否認理由を取得できませんでした。<br>別のユーザーにより作業の取り消しまたは公開されている可能性があります。<p>';
	}
	return false;
}

// 緊急情報

function cxAddDisasterNewpageExec(form, page_id) {
	// レイヤーを消す
	if(cms_prev_layer) {
		cms_prev_layer.style.display = 'none';
	}
	// 新規作成画面
	$(form).action = cms8341admin_path + '/page/common/newpage.php';
	$(form).target = '';
	// 緊急情報作成
	$(form).cms_dispMode.value = 'disaster';
	// ページID
	if (page_id != undefined && page_id != "") {
		$(form).cms_page_id.value = page_id;
	}
	else {
		alert("error");
		return false;
	}
	// フォーム送信
	$(form).submit();
	return false;
}

/**
 * ページ用コンテンツメニュー表示
 * ページタイトル押下時にメニューを生成し表示する
 * @param event
 * @param t メニュー表示用タグID
 * @param page_id ページID
 * @param form フォーム名
 * @param disp 表示画面
 * @return
 */
function cxContentsMenu2(event,t,page_id,form,disp) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	var prm = 'menu_id='+t+'&page_id='+page_id+'&form='+form+'&disp='+disp;
	cxAjaxUpdater('cxContentsMenu2', prm, t);
	
	//main
	$(t).style.display = 'block'
	$(t).style.left = event.clientX + 'px';
	//var wh = document.documentElement.clientHeight;
	//var st = (document.compatMode == "CSS1Compat") ? document.documentElement.scrollTop: document.body.scrollTop;
	//var ey = event.clientY;
	//var eh = $(t).clientHeight;
//	var eh = 300;
	//IE8以上
	//if(cxGetIeVersion() >= 8) $(t).style.top = (ey + st - 140) + 'px';
	//IE7以下
	//if(cxGetIeVersion() == 7) $(t).style.top = ey + st + 'px';	
	//var sc_sw = ey + eh > wh ? true:false;
	// if(sc_sw) {
	// 	var scSize = (ey+eh) - wh + 20;
	// 	var smax = 0;
	// 	while(smax < scSize) {
	// 		window.scrollBy(0,20);
	// 		smax += 20;
	// 	}
	// }
	//keep
	active_menu = t.substr(t.lastIndexOf("_")+1);
	cms_prev_layer = $(t);
	
}

// オープンデータ
/**
 * オープンデータ情報指定領域作成
 */
function cxSetOpendata() {
	if ($F('cms_dispMode') =="copy") {
		page_id = $F('cms_copy_page_id');
	}
	else {
		page_id = '';
	}
	// テンプレート取得
	var prm = 'page_id='+page_id;
	cxAjaxCommand('cxGetOpendataMetaStr', prm, cxOpendataMetaSuccess);
	return false;
}

function cxOpendataMetaSuccess (r) {
	var rText = r.responseText;
	$('cms_opendata_area').innerHTML = rText;
}

/**
 * オープンデータ選択切り替え
 */
function dispChangeOpendata() {
	// オープンデータが選択されているかチェック
	var select_opendata_flg = false;
	var opendata_id_elem = document.getElementsByName("opendata_id[]");
	for (i = 0; i < opendata_id_elem.length; i++ ) {
		if (opendata_id_elem.item(i).checked == true) {
			select_opendata_flg = true;
		}
	}
	// 概要
	if ($('opendata_summary_area')) {
		$('opendata_summary_area').style.display = 'none';
		if (select_opendata_flg) {
			$('opendata_summary_area').style.display = '';
		}
	}
	// ライセンス
	if ($('opendata_license_area')) {
		$('opendata_license_area').style.display = 'none';
		if (select_opendata_flg) {
			$('opendata_license_area').style.display = '';
		}
	}
	// データ時点
	if ($('opendata_point_time_area')) {
		$('opendata_point_time_area').style.display = 'none';
		if (select_opendata_flg) {
			$('opendata_point_time_area').style.display = '';
		}
	}
	// 掲載日
	if ($('opendata_pub_date_area')) {
		$('opendata_pub_date_area').style.display = 'none';
		if (select_opendata_flg) {
			$('opendata_pub_date_area').style.display = '';
		}
	}
	// カテゴリー
	if ($('opendata_category_area')) {
		$('opendata_category_area').style.display = 'none';
		if (select_opendata_flg) {
			$('opendata_category_area').style.display = '';
		}
	}
	// データタイプ
	if ($('od_data_type_area')) {
		$('od_data_type_area').style.display = 'none';
		if (select_opendata_flg) {
			$('od_data_type_area').style.display = '';
		}
	}
	// キーワード検索タグ
	if ($('opendata_keywords_area')) {
		$('opendata_keywords_area').style.display = 'none';
		if (select_opendata_flg) {
			$('opendata_keywords_area').style.display = '';
		}
	}
	
	return true;
}