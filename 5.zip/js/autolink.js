/******************************************************
cxOpenUserSelect
自動リンク領域設定画面で使用
ユーザーの追加を行う
******************************************************/
function cxOpenUserSelect(id_name) {
		cxIframeLayer(
						cms8341admin_path + "/page/autolink/user_select.php",
						800,
						780,
						COVER_SETTING.COLOR,
						'',
						function (retObj) {
								if (retObj == undefined)
										return;
								dept_ary = new Array();
								name_ary = new Array();
								user_el = document.getElementById(id_name);
								for (i = 0; i < user_el.getElementsByTagName("span").length; i++) {
										id = user_el.getElementsByTagName("span")[i].getAttribute("ID");
										if (id == null)
												return;
										if (id == "cms_dept_" + retObj['user_id'])
												return;
										if (id.indexOf("cms_dept_") == 0) {
												dept_ary.push(id);
										}
										if (id.indexOf("cms_name_") == 0) {
												name_ary.push(id);
										}
								}
								newStr = '<table cellspacing="0" cellpadding="5" border="1" style="margin-top:10px;border-collapse:collapse">';
								for (i = 0; i < dept_ary.length; i++) {
										dept_id = dept_ary[i];
										name_id = name_ary[i];
										user_id = dept_id.slice("cms_dept_".length);
										newStr = newStr + '<tr id="user_tr_' + dept_id + '">';
										newStr = newStr + '<td><span id="' + dept_id + '">' + $(dept_id).innerHTML + '</span></td>';
										newStr = newStr + '<td><span id="cms_name_' + user_id + '">' + $(name_id).innerHTML + '</span></td>';
										newStr = newStr + '<td><img src="' + cms8341admin_path + '/images/btn/btn_del_mini.jpg" alt="削除する" onClick="cxUserSelDel(\'user_tr_' + dept_id + '\')" style="cursor:pointer"></td>';
										newStr = newStr + '<input type="hidden" id="hdn_dept_' + user_id + '" name="hdn_dept_' + user_id + '" value="' + $(dept_id).innerHTML + '">';
										newStr = newStr + '<input type="hidden" id="hdn_name_' + user_id + '" name="hdn_name_' + user_id + '" value="' + $(name_id).innerHTML + '">';
										newStr = newStr + '</tr>';
								}
								newStr = newStr + '<tr id="user_tr_cms_dept_' + retObj['user_id'] + '">';
								newStr = newStr + '<td><span id="cms_dept_' + retObj['user_id'] + '">' + htmlspecialcharsAutoLink(retObj['dept']) + '</span></td>';
								newStr = newStr + '<td><span id="cms_name_' + retObj['user_id'] + '">' + htmlspecialcharsAutoLink(retObj['name']) + '</span></td>';
								newStr = newStr + '<td><img src="' + cms8341admin_path + '/images/btn/btn_del_mini.jpg" alt="削除する" onClick="cxUserSelDel(\'user_tr_cms_dept_' + retObj['user_id'] + '\')" style="cursor:pointer"></td>';
								newStr = newStr + '<input type="hidden" id="hdn_dept_' + retObj['user_id'] + '" name="hdn_dept_' + retObj['user_id'] + '" value="' + htmlspecialcharsAutoLink(retObj['dept']) + '">';
								newStr = newStr + '<input type="hidden" id="hdn_name_' + retObj['user_id'] + '" name="hdn_name_' + retObj['user_id'] + '" value="' + htmlspecialcharsAutoLink(retObj['name']) + '">';
								newStr = newStr + '</tr>';
								newStr = newStr + '</table>';
								$(id_name).innerHTML = newStr;
						}
		);
}
/******************************************************
cxUserSelDel
自動リンク領域設定画面で使用
ユーザーの削除を行う
******************************************************/
function cxUserSelDel(id){
	Element.remove($(id));
}
/******************************************************
cmUserNameStringCreate
自動リンク領域設定画面で使用
hidden値を作成する
******************************************************/
function cmUserNameStringCreate( ) {
	// hidden値を初期化
	$('hdn_cms_user_select_list').value = "";
	$('hdn_dept_name_list').value = "";
	$('hdn_user_name_list').value = "";
	
	user_el = document.all("cms_user_select_list");
	for (i = 0; i < user_el.getElementsByTagName("span").length; i++) {
	    id = user_el.getElementsByTagName("span")[i].getAttribute("ID");
	    if(id == null)continue;
		if(id.indexOf("cms_dept_") == 0){
			id = id.slice("cms_dept_".length); 
			$('hdn_cms_user_select_list').value = ($F('hdn_cms_user_select_list') != "" ? $F('hdn_cms_user_select_list') + "," : "" ) + id;
			$('hdn_dept_name_list').value = ($F('hdn_dept_name_list') != "" ? $F('hdn_dept_name_list') + "','" : "" ) +  $F('hdn_dept_'+id);
			$('hdn_user_name_list').value = ($F('hdn_user_name_list') != "" ? $F('hdn_user_name_list') + "','" : "" ) +  $F('hdn_name_'+id);
		}
	}
}


/******************************************************
cxOnloadAutLinkUser
自動リンク領域設定画面で使用
自動リンク領域設定画面ロード時に、
表示設定許可ユーザー欄を作成し直す
******************************************************/
function cxOnloadAutLinkUser(id_name, user_list, dept_list, name_list){
	if(user_list == ''){
		return false;
	}

	user_list_ary = user_list.split(',');
	dept_list_ary = dept_list.split('\',\'');
	name_list_ary = name_list.split('\',\'');

	newStr = '<table cellspacing="0" cellpadding="5" border="1" style="margin-top:10px;border-collapse:collapse">';
	for(count = 0; count < user_list_ary.length; count++){
		user_id =  user_list_ary[count];
		dept = dept_list_ary[count];
		name = name_list_ary[count];
		newStr = newStr + '<tr id="user_tr_cms_dept_' + user_id + '">';
		newStr = newStr + '<td><span id="cms_dept_'+user_id+'">'+htmlspecialcharsAutoLink(dept)+'</span></td>';
		newStr = newStr + '<td><span id="cms_name_'+user_id+'">'+htmlspecialcharsAutoLink(name)+'</span></td>';
		newStr = newStr + '<td><img src="' + cms8341admin_path + '/images/btn/btn_del_mini.jpg" alt="削除する" onClick="cxUserSelDel(\'user_tr_cms_dept_'+ user_id + '\')" style="cursor:pointer"></td>';
		newStr = newStr + '<input type="hidden" id="hdn_dept_'+user_id+'" name="hdn_dept_'+user_id+'" value="'+htmlspecialcharsAutoLink(dept)+'">';
		newStr = newStr + '<input type="hidden" id="hdn_name_'+user_id+'" name="hdn_name_'+user_id+'" value="'+htmlspecialcharsAutoLink(name)+'">';
		newStr = newStr + '</tr>';
	}
	newStr = newStr + '</table>';
	$(id_name).innerHTML = newStr;

}

/******************************************************
htmlspecialcharsAutoLink
自動リンク領域設定画面で使用
HTML表示用文字に置換する
******************************************************/
function htmlspecialcharsAutoLink(ch){
	ch = ch.replace(/&/g,"&amp;");
	ch = ch.replace(/"/g,"&quot;");
	ch = ch.replace(/'/g,"&#039;");
	ch = ch.replace(/</g,"&lt;");
	ch = ch.replace(/>/g,"&gt;");
	return ch;
}

