/*
 *
 */
cxPreImages(cms8341admin_path+'/images/menu/logout01_btn.jpg',
			cms8341admin_path+'/images/menu/logout02_btn.jpg',
			cms8341admin_path+'/images/btn/btn_close_mini.jpg',
			cms8341admin_path+'/images/btn/btn_prev.gif',
			cms8341admin_path+'/images/contentsmenu/menu_edit01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_linkcheck01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_accessibilitycheck01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_totalcheck01.jpg',				// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_spellcheck01.jpg',				// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_headlinecheck01.jpg',		// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_contrastcheck01.jpg',		// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_preview01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_pageproperty01.jpg',
			cms8341admin_path+'/images/btn/btn_set.jpg',			// CMS-8341 Version2
			cms8341admin_path+'/images/icon/result_error.gif');		// CMS-8341 Version2

var active_menu;
function cxPagePropertyClose() {
	cxComboVisible();
	cxLayer('cms8341-property',0);
}
// ラジオボタンがチェックされているかチェック
function isRadioCheck(name){
	ret = false;
	var nodes = Form.getInputs($('cms_Replace'),'radio',name);
	$A(nodes).each( function(obj) { 
						if(obj.checked && obj.value != "") ret = true; 
					} ); 
	return ret;
}
//search
function cxSubmit() {
	if (!isRadioCheck('cms_target_status')) {
		alert("ステータスが指定されていません。");
		return false;
	}
	if (!isRadioCheck('cms_after_status')) {
		alert("置換後のステータスが指定されていません。");
		return false;
	}
	if (!('cms_target_word') || $('cms_target_word').value == "") {
		alert("置換対象文字列が指定されていません。");
		return false;
	}
	
	if(!($F('cms_pdsy') == "" && $F('cms_pdsm') == "" && $F('cms_pdsd') == "")){
		dc = cxDateCheckNew("cms_pd","ymd",2,"公開開始日");
		if(!disp_date_error(dc,"cms_pdsd")) return false;
	}
	if(!($F('cms_pdey') == "" && $F('cms_pdem') == "" && $F('cms_pded') == "")){
		dc = cxDateCheckNew("cms_pd","ymd",3,"公開開始日");
		if(!disp_date_error(dc,"cms_pded")) return false;
	}
	if($F('cms_pdsy') != "" && $F('cms_pdsm') != "" && $F('cms_pdsd') != "" &&
		$F('cms_pdey') != "" && $F('cms_pdem') != "" && $F('cms_pded') != ""){
		dc = cxDateCheckNew("cms_pd","ymd",1,"公開開始日");
		if(!disp_date_error(dc,"cms_pdsd")) return false;
	}
	
	//main
	document.cms_Replace.cms_dispMode.value = "search";
	document.cms_Replace.submit();
	return false;
}
function cxConfSubmit() {
	if (!$('cms_target_status') || $('cms_target_status').value == "") {
		alert("ステータスが指定されていません。");
		return false;
	}
	if (!$('cms_after_status') || $('cms_after_status').value == "") {
		alert("置換後のステータスが指定されていません。");
		return false;
	}
	if (!('cms_target_word') || $('cms_target_word').value == "") {
		alert("置換対象文字列が指定されていません。");
		return false;
	}
	
	document.cms_Replace.action = "replace_exec.php";
	document.cms_Replace.submit();
	return false;		
}
function cxConfBak() {
	document.cms_Replace.action = "replace_index.php?bak=1";
	document.cms_Replace.submit();
	return false;		
}

// page sending
function cxPageSet(p) {
	document.cms_Replace.cms_dispMode.value = "pageset";
	document.cms_Replace.cms_p.value = p;
	document.cms_Replace.action = "replace_conf.php";
	document.cms_Replace.submit();
	return false;
}

// 組織変更プルダウン処理
function cxChangeDept(lv, val) {
	//reset
	if(val=="") {
		var t = lv + 1;
		for(var i=t;i<=3;i++) {
			var obj = $('cms_target_'+i);
			while(obj.length>1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "";
		}
	} else {
		//get data
		lv++;
		var prm = 'level='+lv+'&code='+val;
		cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
	}
}
function cxGetDeptComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Department') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for (var i=level; i<=3; i++) {
		var obj = $('cms_target_'+i);
		while (obj.length > 1) {
				obj.options[1] = null;
		}
		if(i==level) {
				obj.options[0].text = "指定なし";
		} else {
				obj.options[0].text = "";
		}
	}
	var obj = $('cms_target_'+level);
	var xmlDocfix = xmlDoc.childElementCount;
	for (var i=0; i<xmlDocfix; i++) {
		nodeL = xmlDoc.firstElementChild;
		obj.length++;
		obj.options[i+1].text = nodeL.textContent;
		var val = nodeL.attributes.getNamedItem('value').value;
		obj.options[i+1].value = val;
		xmlDoc.removeChild(xmlDoc.firstElementChild);
	}
}

function cxCloseError() {
	cxLayer('cms8341-error',0);
	cxComboVisible();
}

function cxPublicCalendarOpen (id, mode) {
	$('cms8341-property').style.display = 'none';
	if($('cms8341-template-select')){
		var temp = $('cms8341-template-select');
		if(temp.style.display=='block') temp.style.display = 'none';
	}

	return cxCalendarOpen(id,mode);
}

var cate_id;
function cxChangeCate(level, id, code) {
	cate_id = id;
	var prm = 'level='+level+'&code='+code;
	cxAjaxCommand('cxGetCateCombo', prm, cxGetCateComboOK);
	
}
function cxGetCateComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Categories') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for (var i=level; i<=4; i++) {
		var cmb = $(cate_id+i);
		while (cmb.length > 1) {
				cmb.options[1] = null;
		}
	}
	var cmb = $(cate_id+level);
	var xmlDocfix = xmlDoc.childElementCount;
	for (var i=0; i<xmlDocfix; i++) {
		nodeL = xmlDoc.firstElementChild;
		cmb.length++;
		cmb.options[i+1].text = nodeL.textContent;
		var val = nodeL.attributes.getNamedItem('value').value;
		cmb.options[i+1].value = val;
		xmlDoc.removeChild(xmlDoc.firstElementChild);
	}
}


//テンプレート選択処理
var cmsTemplate = null;
var cms_template_id_name = "cms_all_template_id";
function cxTemplateSet() {
	if ($('cms_target1') && $('cms_target1').checked) {
		cms_template_id_name = "cms_template_id";
		$('cms_template_id').style.display = 'none';
		$('cms_all_template_id').style.display = 'none';
	} else {
		cms_template_id_name = "cms_all_template_id";
		$('cms_template_id').style.display = 'none';
		$('cms_all_template_id').style.display = 'none';
	}
	$(cms_template_id_name).style.display = 'block';

	$('cms8341-property').style.display = 'none';
	$(cms_template_id_name).style.visibility = 'visible';

	cmsTemplate = $(cms_template_id_name).options.selectedIndex;
	//close
	cxCalendarClose();
	cxSelectTemplate();
	//hidden
	cxComboHidden(new Array(cms_template_id_name));
	$('cms_thumb').contentWindow.document.body.style.zoom = 0.5;
	$('cms_thumb').contentWindow.document.body.style.position = "relative";
	cxLayer('cms8341-template-select',1,800,490);
}
//
var cms_sid;
var cms_inv_cnt = 0;
var cms_inv_tim = 200;
var cms_inv_max = 25;
function cxSelectTemplate() {
	var si,src;
	si = $(cms_template_id_name).options.selectedIndex;

	if(si >= 0) {
		src = $(cms_template_id_name).options[si].id;
		//
		// テンプレート選択画面のプレビューでレスポンシブをOFF
		$('cms_thumb').src = cms8341admin_path+"/page/common/tplview.php?path=" + encodeURI(src) + '&thum=1';
		if(cms_sid) clearInterval(cms_sid);
		cms_sid = 0;
		cms_inv_cnt = 0;
		cms_sid = setInterval(cxIFrameZoom,cms_inv_tim);
	} else {
		$('cms_thumb').src = 'javascript:';
	}
}
function cxIFrameZoom() {
	if($('cms_thumb').contentWindow.document.body){
		var thumb_body = $('cms_thumb').contentWindow.document.body;
		thumb_body.style.position = "relative";
		thumb_body.style.transform = "scale(0.5)";
		thumb_body.style.transformOrigin = "0 0";
		thumb_body.style.webkitTransform = "scale(0.5)";
		thumb_body.style.webkitTransformOrigin = "0 0";
	}
	//
	cms_inv_cnt++;
	if(cms_inv_cnt > cms_inv_max) {
		clearInterval(cms_sid);
		cms_inv_cnt = 0;
	}
}
function cxTemplateSubmit() {
	var si,label;
	var flg = false;
	var temp_innerHTML = "";
	var temp_id = "";

	if (!$('cms_template_ids')) {
		return false;
	}
	
	si = $(cms_template_id_name).options.selectedIndex;
	cmsTemplate = si;
	if (si >= 0) {
		temp_id = $('cms_template_ids').value;
		temp_id = temp_id.split(",");
		for (i = 0; i < temp_id.length; i++) {
			if (temp_id[i] == $(cms_template_id_name).options[si].value) {
				flg = true;
				break;
			}
		}
		
		if(!flg){
			$('cms_template_ids').value = $('cms_template_ids').value + ($('cms_template_ids').value != "" ? ",":"") + $(cms_template_id_name).options[si].value;
			temp_id = $('cms_template_ids').value;
			temp_id = temp_id.split(",");
			
			for (i = 0; i < temp_id.length; i++) {
				label = "";
				for(j = 0; j < $(cms_template_id_name).options.length; j++) {
					if (temp_id[i] == $(cms_template_id_name).options[j].value) {
						label = $(cms_template_id_name).options[j].text;
						break;
					}
				}
				if (label != "") {
					temp_innerHTML = temp_innerHTML +
					'<span id="template_id_'+temp_id[i]+'">' +
						'&nbsp;<a href="javascript:" onClick="return cxTemplateUnSet(template_id_'+temp_id[i]+',\''+temp_id[i]+'\')">' +
							'<img src="'+cms8341admin_path+'/images/icon/result_error.gif" alt="削除" width="12" height="12" border="0">' +
						'</a>' + label +
					'</span>';
				}
			}
			
			$('cms-template-selected').innerHTML = temp_innerHTML;
		}
	}
	//
	cxLayer('cms8341-template-select',0);
	//visible
	cxComboVisible();
}
function cxTemplateClose() {
	//close
	cxLayer('cms8341-template-select',0);
	//visible
	cxComboVisible();
	if (cmsTemplate != null) {
		$(cms_template_id_name).options.selectedIndex = cmsTemplate;
		//re select
		cxSelectTemplate();
	}
	cmsTemplate = null;
}
function cxTemplateUnSet(id_name,template_id) {
	if (!$('cms_template_ids')) {
		return false;
	}

	temp_id = $('cms_template_ids').value;
	$('cms_template_ids').value = "";
	temp_id = temp_id.split(",");
	for (i = 0; i < temp_id.length; i++) {
		if (temp_id[i] != template_id) {
			$('cms_template_ids').value = $('cms_template_ids').value + ($('cms_template_ids').value != "" ? ",":"") + temp_id[i];
		}
	}
	
	Element.remove(id_name); // ドキュメントから要素を削除 
}

function cxCheck(page_id){
	var cnt = 0;
	chbox_id = new Array();
	if($('page_id_'+page_id).checked){
		checked = 1;
	} else {
		checked = 0;
	}

	// ページチェックボックスが選択されたら置換対象チェックボックスをすべて選択する
	if (!page_id.match("_")) {
		var inputs = document.getElementsByTagName("input");
		$('page_id_'+page_id).disabled = '';
		for (var i = 0, l = inputs.length; i < l; i++) {
			var input = inputs[i];
			if (input.type == "checkbox" && input.id.match("_"+page_id+"_[0-9]+")) {
				if (checked == 1) {
					input.checked = "checked";
				} else {
					input.checked = "";
				}
				chbox_id[cnt] = input.id;
				cnt++;
			}
		}
	} else {
		var check_cnt = 0;
		var chbox_cnt = 0;
		var inputs = document.getElementsByTagName("input");
		var $id = page_id.split("_");
		for (var i = 0, l = inputs.length; i < l; i++) {
			var input = inputs[i];
			if (input.type == "checkbox" && input.id.match("_"+$id[0]+"_[0-9]+")) {
				if (input.checked) {
					check_cnt++;
				}
				chbox_cnt++;
			}
		}
		$('page_id_'+$id[0]).disabled = '';
		if (check_cnt == 0) {
			$('page_id_'+$id[0]).checked = '';
		} else {
			$('page_id_'+$id[0]).checked = 'checked';
			if (check_cnt != chbox_cnt) {
				$('page_id_'+$id[0]).disabled = 'disabled';
			}
		}
	}

	var prm = 'page_id='+page_id+'&checked='+checked+'&chbox_id='+chbox_id;
	cxAjaxCommand('cxReplaceCheck', prm, cxCheckSuccess);
}
function cxCheckSuccess(r){}

function cxCheckAll() {
	_checkAll(document['cms_Replace']['cms_target_page[]']);
}

function cxReleaseAll() {
	_releaseAll(document['cms_Replace']['cms_target_page[]']);
}
function _checkAll(alElem) {
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = true;
			cxCheck(alElem.value);
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = true;
				cxCheck(alElem[i].value);
			}
		}
	}
}
function _releaseAll(alElem) {
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = false;
			cxCheck(alElem.value);
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = false;
				cxCheck(alElem[i].value);
			}
		}
	}
}

function cxDispNum(){
	document.cms_Replace.cms_dispMode.value = "change_num";
	document.cms_Replace.action = "replace_conf.php";
	document.cms_Replace.submit();
	return false;		
}

//Preview
function cxReplacePreview(form, pid, mode, prev_mode) {
	if(element_id) cxCloser(element_id);
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	if($('cms_template_kind') && $('cms_work_class')){
		if($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE && $F('cms_work_class') == 1){
			EnqItemCreateForm();
		}
		if($F('cms_template_kind') == TEMPLATE_KIND_FIXED){
			kankoCustomItemCreate();
		}
	}
	$(form).target = '_new';
	$(form).action = cms8341admin_path+'/revision/replace/rep_preview.php';
	if(pid != undefined && pid != "")$(form).cms_page_id.value = pid;
	$(form).cms_dispMode.value = mode;
	$(form).cms_prevMode.value = prev_mode;
	$(form).submit();
	return false;
}

function cxRepContentsMenu(t) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	//main
	$(t).style.display = 'block'
	$(t).style.left = event.clientX + 'px';
	// var wh = document.documentElement.clientHeight;
	// var st = (document.compatMode == "CSS1Compat") ? document.documentElement.scrollTop: document.body.scrollTop;
	// var ey = event.clientY;
	// var eh = $(t).clientHeight;
	// //IE8
	// if(cxGetIeVersion() >= 8) $(t).style.top = (ey + st - 140) + 'px';
	// //IE7以下
	// else $(t).style.top = ey + st + 'px';
	// var sc_sw = ey + eh > wh ? true:false;
	// if(sc_sw) {
	// 	var scSize = (ey+eh) - wh + 20;
	// 	var smax = 0;
	// 	while(smax < scSize) {
	// 		window.scrollBy(0,20);
	// 		smax += 20;
	// 	}
	// }
	//keep
	active_menu = t.substr(t.lastIndexOf("_")+1);
	cms_prev_layer = $(t);
}
