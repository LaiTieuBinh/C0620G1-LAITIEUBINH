window.onload = function() {
	// save preview title and restore it after convert
	var title = document.getElementById('preview-title');
	var inner = title.innerHTML;
	var cbs = new ColorBlindessSimulator(previewColorCode);
	cbs.convert(function() {
		title.innerHTML = inner;
		// show converted body
		document.body.style.visibility = '';
	});
}

function NeedConvertElement(ele, type, cb) {
	this.ele = ele;
	this.type = type;
	this.cb = cb;
	this.recvData = function(data) {
		if ('img' == this.type) {
			this.ele.src = data;
		}
		else if ('background' == this.type) {
			this.ele.style.backgroundImage = 'url("' + data + '")';
		}
		this.cb.checkAllImageLoadDone();
	}
	this.recvDataFailed = function() {
		this.cb.checkAllImageLoadDone();
	}
}

function ColorBlindessSimulator(type) {
	var typeNumToName = {
		1: 'Protanopia',
		2: 'Deuteranopia',
		3: 'Tritanopia',
		4: 'Achromatopsia'
	};
	this.type = typeNumToName[type];

	this.convert = function(dolast) {
		if (this.type == undefined) {
			return;
		}
		
		var elements = document.body.getElementsByTagName("*");
		var len = elements.length;
		this.dolast = dolast;
		this.loadImageCount = 0;

		for (var idx = 0; idx < len; ++idx) {
			var tag = elements[idx].tagName;
			switch (tag) {
				case "IMG":
					this.convertImageFromURL(
						elements[idx].src,
						new NeedConvertElement(elements[idx], 'img', this)
					);
					break;
				default:
					this.convertElementColor(elements[idx]);
					break;
			}
		}
	}

	this.convertImageFromURL = function(imageURL, needConvertElement) {
		// get image extetions to proper convert gif, png with transparent background and jpg
		fileExt = this.checkFileExt(imageURL);

		var tmpimg = new Image();
		var cb = this;
		tmpimg.onload = function() {
			var h = tmpimg.naturalHeight || tmpimg.height;
			var w = tmpimg.naturalWidth || tmpimg.width;

			document.body.removeChild(tmpimg);

			var canvas = document.createElement('canvas');
			var ctx = canvas.getContext("2d");
			
			canvas.height = h;
			canvas.width = w;

			if (w != 0 && h != 0) {
				// if with or height == 0 image not exist or could be loaded, return dummy url
				// return canvas.toDataURL('image/' + fileExt);
				try {
					ctx.drawImage(tmpimg, 0, 0);
					var pixels = cb.changeImageDataColors(ctx.getImageData(0, 0, w, h));
					ctx.putImageData(pixels, 0, 0);

					needConvertElement.recvData(canvas.toDataURL('image/' + fileExt));
				} catch (error) {
					needConvertElement.recvDataFailed();
				}
			}
			else {
				needConvertElement.recvDataFailed();
			}
		}
		tmpimg.onerror = function(){
			needConvertElement.recvDataFailed();
		}
		this.loadImageCount++;

		// width and height require for canvas, to get it from image load to DOM
		document.body.appendChild(tmpimg);
		tmpimg.src = imageURL;
	}

	this.convertElementColor = function(element) {
		var cssProperties = ['color', 'border-bottom-color', "border-right-color", "border-left-color", "border-top-color", "background-color", "background-image"];

		for (var idx = 0; idx < cssProperties.length; ++idx) {
			var propertyValue = window.getComputedStyle(element, null).getPropertyValue(cssProperties[idx]);
			if (typeof (propertyValue) !== 'undefined' && propertyValue !== 'none') {
				if (propertyValue !== 'rgb(0, 0, 0)' && propertyValue !== 'rgba(0, 0, 0, 0)') {
					var propertyValue = this.changeRGB(propertyValue)
					switch (cssProperties[idx]) {
					case "color":
						element.style.color = propertyValue;
						break;
					case "border-bottom-color":
						element.style.borderBottomColor = propertyValue;
						break;
					case "border-left-color":
						element.style.borderLeftColor = propertyValue;
						break;
					case "border-right-color":
						element.style.borderRightColor = propertyValue;
						break;
					case "border-top-color":
						element.style.borderTopColor = propertyValue;
						break;
					case "background-color":
					case "background-image":
						element.style.background = propertyValue;
						break;
					default:
					}
				}
			}
		}
		
		var backgroundImage = window.getComputedStyle(element, null).getPropertyValue("background-image");
		if (typeof (backgroundImage) !== 'undefined' && backgroundImage !== 'none') {
			var URL = backgroundImage.match(/url\(["|']?([^"']*)["|']?\)/);
			if (URL !== null) {
				this.convertImageFromURL(
					URL[1],
					new NeedConvertElement(element, 'background', this)
				);
			} else {
				return;
			}
		}
	}

	this.changeImageDataColors = function(pixels) {
		// get filter function from coblis library
		var filterFunction = getFilterFunction(this.type);

		for (var i = 0; i < pixels.data.length; i += 4) {
			var rgb = [pixels.data[i], pixels.data[i + 1], pixels.data[i + 2]];
			var filteredRGB = filterFunction(rgb);
			pixels.data[i] = filteredRGB[0];
			pixels.data[i + 1] = filteredRGB[1];
			pixels.data[i + 2] = filteredRGB[2];
		}
		return pixels;
	}

	this.changeRGB = function(rgb) {
		// get filter function from coblis library
		var filterFunction = getFilterFunction(this.type);
		if (rgb.indexOf("gradient") != -1) {
			var text_replace = 'GD_color';
			var new_rgb = rgb;
			var regex = /gradient\((.*)\)/;
			var list = regex.exec(rgb);
			// get string color in ()
			var str_color = list[1];
			var rgb_ary = str_color.match(/(rgb|rgba)\(.*?\)/gi);
			var list_rgb = [];
			// replace rgb color to temp text
			if (rgb_ary != null && rgb_ary.length > 0) {
				for (var j = 0; j < rgb_ary.length; j++) {
					str_color = str_color.replace(rgb_ary[j], text_replace + j);
					list_rgb[text_replace + j] = rgb_ary[j];
				}
			}
			var list_color = str_color.split(/ |, |,/);
			
			for (var i = 0; i < list_color.length; i++) {
				var rgb_item_replace, rgb_item;
				// case color is rgb
				if (list_color[i].indexOf(text_replace) != -1) {
					rgb_item_replace = list_rgb[list_color[i]];
					rgb_item = list_rgb[list_color[i]];
				} else {
					// case color is string
					rgb_item_replace = list_color[i];
					rgb_item_replace = rgb_item_replace.trim();
					rgb_item = this.nameToRGB(list_color[i]);
				}
				// convert color
				if (this.isColor(rgb_item)) {
					var tmp_rgb_ary = rgb_item.replace(/[^\d,]/g, '').split(',');
					var nc = filterFunction(tmp_rgb_ary);
					var converted_rgb = "rgb(" + Math.round(nc[0]) + "," + Math.round(nc[1]) + "," + Math.round(nc[2]) + ")";
					new_rgb = new_rgb.replace(rgb_item_replace, converted_rgb);
				}
			}
			return new_rgb;
		} else {
			rgb = rgb.replace(/[^\d,]/g, '').split(',');
			var nc = filterFunction(rgb);
			rgb = "rgb(" + Math.round(nc[0]) + "," + Math.round(nc[1]) + "," + Math.round(nc[2]) + ")";
			return rgb;
		}
	}
	
	// conver string to rgb
	this.nameToRGB = function(name) {
		if (!this.isColor(name)) {
			return name;
		}
		// Create fake div
		var fakeDiv = document.createElement("div");
		fakeDiv.style.color = name;
		document.body.appendChild(fakeDiv);

		// Get color of div
		var cs = window.getComputedStyle(fakeDiv),
		
		pv = cs.getPropertyValue("color");
		// Remove div after obtaining desired color value
		document.body.removeChild(fakeDiv);

		return pv;
	}
	
	// check if string is a valid color
	this.isColor = function(strColor) {
		var s = new Option().style;
		s.color = strColor;
		return s.color.toLocaleLowerCase() == strColor.toLocaleLowerCase();
	}

	this.checkFileExt = function(path) {
		var fileExt = path.split('.').pop().toLowerCase();
		if (fileExt == 'jpg') {
			fileExt = 'jpeg';
		}
		if (fileExt == 'gif') {
			fileExt = 'png';
		}
		return fileExt;
	}

	this.checkAllImageLoadDone = function() {
		this.loadImageCount--;
		if (0 == this.loadImageCount) {
			// done all load
			this.dolast();
		}
	}
}

// maths function
function getFilterFunction(type) {
	var lib = colorMatrixFilterFunctions;
	if (type in lib) {
		return lib[type];
	} else {
		throw 'Library does not support Filter Type: ' + type;
	}
}

var ColorMatrixMatrixes = {
	Protanopia: {
		R: [56.667, 43.333, 0],
		G: [55.833, 44.167, 0],
		B: [0, 24.167, 75.833]
	},
	Deuteranopia: {
		R: [62.5, 37.5, 0],
		G: [70, 30, 0],
		B: [0, 30, 70]
	},
	Tritanopia: {
		R: [95, 5, 0],
		G: [0, 43.333, 56.667],
		B: [0, 47.5, 52.5]
	},
	Achromatopsia: {
		R: [29.9, 58.7, 11.4],
		G: [29.9, 58.7, 11.4],
		B: [29.9, 58.7, 11.4]
	}
};

function matrixFunction(matrix) {
	return function(rgb) {
		var r = rgb[0];
		var g = rgb[1];
		var b = rgb[2];
		return [r * matrix.R[0] / 100.0 + g * matrix.R[1] / 100.0 + b * matrix.R[2] / 100.0, r * matrix.G[0] / 100.0 + g * matrix.G[1] / 100.0 + b * matrix.G[2] / 100.0, r * matrix.B[0] / 100.0 + g * matrix.B[1] / 100.0 + b * matrix.B[2] / 100.0];
	}
	;
}

var colorMatrixFilterFunctions = {};
for (var t in ColorMatrixMatrixes) {
	if (ColorMatrixMatrixes.hasOwnProperty(t)) {
		colorMatrixFilterFunctions[t] = matrixFunction(ColorMatrixMatrixes[t]);
	}
}
