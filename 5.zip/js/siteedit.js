/*
 *
 */
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
cxPreImages(cms8341admin_path + '/images/menu/comp01_btn.jpg',
	cms8341admin_path + '/images/menu/comp02_btn.jpg',
	cms8341admin_path + '/images/menu/save01_btn.jpg',
	cms8341admin_path + '/images/menu/save02_btn.jpg',
	cms8341admin_path + '/images/menu/preview01_btn.jpg',
	cms8341admin_path + '/images/menu/preview02_btn.jpg',
	cms8341admin_path + '/images/menu/close01_btn.jpg',
	cms8341admin_path + '/images/menu/close02_btn.jpg',
	cms8341admin_path + '/images/menu/totalcheck01_btn.jpg',		// CMS-8341 Version2
	cms8341admin_path + '/images/menu/totalcheck02_btn.jpg',		// CMS-8341 Version2
	cms8341admin_path + '/images/contentsmenu/menu_linkcheck01.jpg',
	cms8341admin_path + '/images/contentsmenu/menu_accessibilitycheck01.jpg',
	cms8341admin_path + '/images/contentsmenu/menu_spellcheck01.jpg',				// CMS-8341 Version2
	cms8341admin_path + '/images/contentsmenu/menu_headlinecheck01.jpg',		// CMS-8341 Version2
	cms8341admin_path + '/images/contentsmenu/menu_contrastcheck01.jpg',		// CMS-8341 Version2
	cms8341admin_path + '/images/contentsmenu/menu_htmlcleanup01.jpg',		// CMS-8341 Version2
	cms8341admin_path + '/images/menu/property01_btn.jpg',
	cms8341admin_path + '/images/menu/property02_btn.jpg',
	cms8341admin_path + '/images/btn/btn_del_mini.jpg',
	cms8341admin_path + '/images/btn/btn_del_mini.gif');

//propery layer events
var cmsPropObj = new Object();
var cmsPanAncestor = '';

function cxPropertyOpen() {

	// プロパティの複数回起動は禁止
	if ($('cms8341-property').style.display == 'block') return false;

	//close
	if ($('cms8341-library').style.display == 'block') cxLayer('cms8341-library', 0);
	if ($('cms8341-reffer').style.display == 'block') cxLayer('cms8341-reffer', 0);
	if ($('cms8341-category').style.display == 'block') cxLayer('cms8341-category', 0);
	if ($('cms8341-calendar').style.display == 'block') cxLayer('cms8341-calendar', 0);
	if ($('cms8341-template-select')) cxLayer('cms8341-template-select', 0);
	//keep init value pageproperty
	cmsPropObj.page_title = $('cms_page_title').value;
	cmsPropObj.keywords = $('cms_keywords').value;
	cmsPropObj.description = $('cms_description').value;
	cmsPropObj.summary = $('cms_summary').value;
//	cmsPropObj.index_title = $('cms_index_title').value;
	cmsPropObj.dir_path = $('cms_dir_path').value;
	cmsPropObj.filename = $('cms_filename').value;
	if ($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE && $F('cms_ssl_flg') == FLAG_ON) {
		$('cms_file_name').value = cmsPropObj.filename.replace(/\.html$/, '');
	} else {
		$('cms_file_path').innerHTML = cmsPropObj.dir_path + cmsPropObj.filename;
	}
	cmsPropObj.cate1 = getComboValues($('cms_cate1'));
	cmsPropObj.cate2 = getComboValues($('cms_cate2'));
	cmsPropObj.cate3 = getComboValues($('cms_cate3'));
	cmsPropObj.cate4 = getComboValues($('cms_cate4'));
	cmsPropObj.cate_name = $('cms-cate-name').innerHTML;
	if ($('cms_contents_top_flg')) cmsPropObj.contents_top_flg = $('cms_contents_top_flg').checked;
	cmsPropObj.file_path = $('cms_file_path').innerHTML;
	cmsPropObj.parent_id = $('cms_parent_id').value;
	if ($('cms-prop-pankuzu')) cmsPropObj.prop_pankuzu = $('cms-prop-pankuzu').innerHTML;
	if ($('cms-pan-ancestor')) {
		cmsPropObj.pan_ancestor = $('cms-pan-ancestor').innerHTML;
		cmsPanAncestor = $('cms-pan-ancestor').innerHTML;
	}
	if (($F('cms_template_kind') == TEMPLATE_KIND_FIXED) && ($F('cms_template_kanko_type') == KANKO_TYPE_EVENT)) {
		// イベントカレンダー複数日
		if (EVENT_CAL_MULTI_FLAG == true) {
			// 開催期間の入力欄を格納
			cmsPropObj.pd = document.getElementById('property_calendar_input_area').innerHTML;
		}
		// イベントカレンダー単一日
		else {
			cmsPropObj.pdsy = $F('cms_pdsy');
			cmsPropObj.pdsm = $F('cms_pdsm');
			cmsPropObj.pdsd = $F('cms_pdsd');
			cmsPropObj.pdey = $F('cms_pdey');
			cmsPropObj.pdem = $F('cms_pdem');
			cmsPropObj.pded = $F('cms_pded');
		}
	}
	tmp = "";
	if ($F('cms_template_kind') == TEMPLATE_KIND_FIXED) {
		cmsPropObj.output = getCheckValue2('cms_fEdit', 'checkbox', 'cms_output[]');
	}
	if ($F('cms_usr_class') == USER_CLASS_WEBMASTER && $F('cms_status') != STATUS_APPROVE_LAST) {
		cmsPropObj.pubsy = $F('cms_pubsy');
		cmsPropObj.pubsm = $F('cms_pubsm');
		cmsPropObj.pubsd = $F('cms_pubsd');
		cmsPropObj.pubsh = $F('cms_pubsh');
		cmsPropObj.pubey = $F('cms_pubey');
		cmsPropObj.pubem = $F('cms_pubem');
		cmsPropObj.pubed = $F('cms_pubed');
		cmsPropObj.pubeh = $F('cms_pubeh');

		if (USE_INDEFINITE == false) {
			$('cms-pubend-Unrestricted-edit').style.display = 'none';
			var ctl = document.getElementById("indefinite");
			ctl.style.display = "none";
		}
		if ((cmsPropObj.pubey == PUB_INDEFINITE_YAER && cmsPropObj.pubem == PUB_INDEFINITE_MONTH && cmsPropObj.pubed == PUB_INDEFINITE_DAY && cmsPropObj.pubeh == PUB_INDEFINITE_HOUR) && USE_INDEFINITE == true) {
			if ($('cms-pubend-Unrestricted-edit')) {
				$('cms_pubey').value = "";
				$('cms_pubem').value = "";
				$('cms_pubed').value = "";
				$('cms_pubeh').value = "";
				$('cms-pubend-Unrestricted-edit').value = "";
				$('cms-pubend-Unrestricted-edit').checked = true;
				cxPublicEndUnrestricted();
			}
		}
	}

	// メール送信先(アンケート・問い合わせ)
	if ($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE && $F("cms_from_type") == ENQ_KIND_MAIL && $("cms_enquete_emai_list")) {
		cmsPropObj.enquete_email_list = $("cms_enquete_emai_list").innerHTML;
	}

	// テンプレート
	if ($F('cms_template_kind') == TEMPLATE_KIND_FREE && $("cms-template-selected")) {
		cmsPropObj.cms_template_selected = $("cms-template-selected").innerHTML;
		cmsPropObj.cms_s_template_id = $("cms_s_template_id").options.selectedIndex;
		cmsPropObj.cms_template_id = $("cms_template_id").value;
		cmsPropObj.cms_template_ver = $('cms_template_ver').value;
	}

	cmsPropObj.inquiry_cnt = $F('cms_inquiry_cnt');
	cmsPropObj.inquiry = new Array();
	for (i = 1; i < Number($F('cms_inquiry_cnt')) + 1; i++) {
		var inq_deil = new Array();
		if ($('cms_inquiry_prop_dept1_' + i)) inq_deil['cms_inquiry_dept'] = $('cms_inquiry_dept_td_' + i).innerHTML;
		if ($('cms_inquiry_prop_charge_' + i)) inq_deil['cms_inquiry_charge'] = $F('cms_inquiry_prop_charge_' + i);
		if ($('cms_inquiry_prop_anExtensionNumber_' + i)) inq_deil['cms_inquiry_anExtensionNumber'] = $F('cms_inquiry_prop_anExtensionNumber_' + i);
		if ($('cms_inquiry_prop_directNumber_' + i)) inq_deil['cms_inquiry_directNumber'] = $F('cms_inquiry_prop_directNumber_' + i);
		if ($('cms_inquiry_prop_fax_' + i)) inq_deil['cms_inquiry_fax'] = $F('cms_inquiry_prop_fax_' + i);
		if ($('cms_inquiry_prop_email_' + i)) inq_deil['cms_inquiry_email'] = $F('cms_inquiry_prop_email_' + i);
		cmsPropObj.inquiry[i] = inq_deil;
	}
	if ($('cms_inquiry_prop_memo')) cmsPropObj.inquiryMemo = $F('cms_inquiry_prop_memo');
	if ($F('cms_template_kind') == TEMPLATE_KIND_FIXED || ($('kanko_xml') && $F('kanko_xml') != "")) {
		kankoPropertyOpen("cms8341-property");
	}

	// ページ出力設定
	if ($('cms_output_html_flg')) cmsPropObj.output_html_flg = $('cms_output_html_flg').checked;
	
	// オープンデータ
	dispChangeOpendata();
	// オープンデータ情報
	select_opendata_id = new Array;
	var opendata_id_elem = document.getElementsByName("opendata_id[]");
	for (i = 0; i < opendata_id_elem.length; i++ ) {
		if (opendata_id_elem.item(i).checked == true) {
			select_opendata_id.push(opendata_id_elem.item(i).value);
		}
	}
	cmsPropObj.select_opendata_id = select_opendata_id;

	edit_closet_flg = false;
	//全てのプルダウンを消す
	cxComboHidden();
	//open
	cxLayer('cms8341-property', 1, 900, 600);
	//プロパティのプルダウンのみ表示
	cxComboVisible("cms8341-property");
}

function cxPropertyClose() {
	//close
	cxLayer('cms8341-reffer', 0);
	cxLayer('cms8341-property', 0);
	cxLayer('cms8341-category', 0);
	cxLayer('cms8341-calendar', 0);
	if ($('cms8341-template-select')) cxLayer('cms8341-template-select', 0);
	//reset pageproperty
	$('cms_page_title').value = cmsPropObj.page_title;
	$('cms_keywords').value = cmsPropObj.keywords;
	$('cms_description').value = cmsPropObj.description;
	$('cms_summary').value = cmsPropObj.summary;
//	$('cms_index_title').value = cmsPropObj.index_title;
	if ($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE && $F('cms_ssl_flg') == FLAG_ON) {
		$('cms_file_name').value = cmsPropObj.file_path;
	} else {
		$('cms_file_path').innerHTML = cmsPropObj.file_path;
	}
	$('cms_dir_path').value = cmsPropObj.dir_path;
	$('cms_filename').value = cmsPropObj.filename;
	setComboValues('cms_cate1', cmsPropObj.cate1);
	setComboValues('cms_cate2', cmsPropObj.cate2);
	setComboValues('cms_cate3', cmsPropObj.cate3);
	setComboValues('cms_cate4', cmsPropObj.cate4);
	$('cms-cate-name').innerHTML = cmsPropObj.cate_name
	if ($('cms_contents_top_flg')) $('cms_contents_top_flg').checked = cmsPropObj.contents_top_flg;
	$('cms_parent_id').value = cmsPropObj.parent_id;
	if ($('cms-prop-pankuzu')) $('cms-prop-pankuzu').innerHTML = cmsPropObj.prop_pankuzu;
	if ($('cms-pan-ancestor')) $('cms-pan-ancestor').innerHTML = cmsPropObj.pan_ancestor;
	if (($F('cms_template_kind') == TEMPLATE_KIND_FIXED) && ($F('cms_template_kanko_type') == KANKO_TYPE_EVENT)) {
		// イベントカレンダー複数日
		if (EVENT_CAL_MULTI_FLAG == true) {
			// 修正前の状態に戻す
			document.getElementById('property_calendar_input_area').innerHTML = cmsPropObj.pd;

			// 追加ボタンのイベントを定義
			document.getElementById('add_event_date').onclick = function () {
				cxAddEventDate();
			}

			// カレンダー(一括選択)のイベントを定義
			document.getElementById('cms_pd_calendar').onclick = function () {
				cxCheckboxCalendarSet();
			}

			// 要素数の取得
			var element_no = document.getElementById('cms_pd_count').value;

			// 要素ごとのイベントを定義
			for (var i = 1; i <= element_no; i++) {
				// 入力欄削除により要素が無ければスキップ
				if (document.getElementById('cms_pd' + i + 'sy') == null) {
					continue;
				}

				// 削除ボタン
				if (i > 1) {
					document.getElementById('del_event_date' + i).onclick = function () {
						cxDelEventDate(this.id.replace('del_event_date', ''));
					}
				}
			}
		}
		// イベントカレンダー単一日
		else {
			$('cms_pdsy').value = cmsPropObj.pdsy;
			$('cms_pdsm').value = cmsPropObj.pdsm;
			$('cms_pdsd').value = cmsPropObj.pdsd;
			$('cms_pdey').value = cmsPropObj.pdey;
			$('cms_pdem').value = cmsPropObj.pdem;
			$('cms_pded').value = cmsPropObj.pded;
		}
	}
	if ($F('cms_usr_class') == USER_CLASS_WEBMASTER && $F('cms_status') != STATUS_APPROVE_LAST) {
		$('cms_pubsy').value = cmsPropObj.pubsy;
		$('cms_pubsm').value = cmsPropObj.pubsm;
		$('cms_pubsd').value = cmsPropObj.pubsd;
		$('cms_pubsh').value = cmsPropObj.pubsh;
		$('cms_pubey').value = cmsPropObj.pubey;
		$('cms_pubem').value = cmsPropObj.pubem;
		$('cms_pubed').value = cmsPropObj.pubed;
		$('cms_pubeh').value = cmsPropObj.pubeh;
		if ($('cms-pubend-Unrestricted-edit') && $('cms-pubend-Unrestricted-edit').checked) {
			$('cms-pubend-Unrestricted-edit').checked = false;
			cxPublicEndUnrestricted();
		}
	}
	for (i = 1; i < Number($F('cms_inquiry_cnt')) + 1; i++) {
		if (i > cmsPropObj.inquiry_cnt) {
			if ($('cms_inquiry_' + i)) Element.remove($('cms_inquiry_' + i));
			continue;
		}
		if ($('cms_inquiry_dept_td_' + i)) $('cms_inquiry_dept_td_' + i).innerHTML = cmsPropObj.inquiry[i]['cms_inquiry_dept'];
		if ($('cms_inquiry_prop_charge_' + i)) $('cms_inquiry_prop_charge_' + i).value = cmsPropObj.inquiry[i]['cms_inquiry_charge'];
		if ($('cms_inquiry_prop_anExtensionNumber_' + i)) $('cms_inquiry_prop_anExtensionNumber_' + i).value = cmsPropObj.inquiry[i]['cms_inquiry_anExtensionNumber'];
		if ($('cms_inquiry_prop_directNumber_' + i)) $('cms_inquiry_prop_directNumber_' + i).value = cmsPropObj.inquiry[i]['cms_inquiry_directNumber'];
		if ($('cms_inquiry_prop_fax_' + i)) $('cms_inquiry_prop_fax_' + i).value = cmsPropObj.inquiry[i]['cms_inquiry_fax'];
		if ($('cms_inquiry_prop_email_' + i)) $('cms_inquiry_prop_email_' + i).value = cmsPropObj.inquiry[i]['cms_inquiry_email'];
	}
	if ($('cms_inquiry_prop_memo')) $('cms_inquiry_prop_memo').value = cmsPropObj.inquiryMemo;
	$('cms_inquiry_cnt').value = cmsPropObj.inquiry_cnt;
	if ($F('cms_template_kind') == TEMPLATE_KIND_FIXED || ($('kanko_xml') && $F('kanko_xml') != "")) {
		kankoPropertyClose("cms8341-property");
	}
	// メール送信先(アンケート・問い合わせ)
	if ($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE && $F("cms_from_type") == ENQ_KIND_MAIL && $("cms_enquete_emai_list")) {
		$("cms_enquete_emai_list").innerHTML = cmsPropObj.enquete_email_list;
	}

	// テンプレート
	if ($F('cms_template_kind') == TEMPLATE_KIND_FREE && $("cms-template-selected")) {
		$("cms-template-selected").innerHTML = cmsPropObj.cms_template_selected;
		$("cms_s_template_id").options.selectedIndex = cmsPropObj.cms_s_template_id;
		$("cms_template_id").value = cmsPropObj.cms_template_id;
		$('cms_template_ver').value = cmsPropObj.cms_template_ver;
	}

	if ($F('cms_template_kind') == TEMPLATE_KIND_FIXED) {
		// ページ出力設定
		if ($('cms_output_html_flg')) $('cms_output_html_flg').checked = cmsPropObj.output_html_flg;
		// 外部連携
		output_id_ary = cmsPropObj.output.split(",");
		var elements = Form.getInputs('cms_fEdit', 'checkbox', 'cms_output[]');
		elements.each(
			function (el, idx) {
				if ($('cms_output_' + el.value)) {
					if (output_id_ary.indexOf(el.value) != -1) {
						$('cms_output_' + el.value).checked = true;
					} else {
						$('cms_output_' + el.value).checked = false;
					}
				}
			}
		);
	}
	
	// オープンデータ
	// オープンデータ情報
	if (cmsPropObj.select_opendata_id) {
		select_opendata_id = cmsPropObj.select_opendata_id;
		// チェックボックスを全て非選択にする
		var opendata_id_elem = document.getElementsByName("opendata_id[]");
		for (i = 0; i < opendata_id_elem.length; i++ ) {
			opendata_id_elem.item(i).checked = false;
		}
		
		// プロパティ表示時に選択されていた状態に戻す
		for (i = 0; i < select_opendata_id.length; i++) {
			if ($('opendata_id_' + select_opendata_id[i])) {
				$('opendata_id_' + select_opendata_id[i]).checked = true;
			}
		}
	}

	edit_closet_flg = false;
	cxComboVisible();
}

function cxPropertySubmit() {
	if ($('cms-pubend-Unrestricted-edit') && $('cms-pubend-Unrestricted-edit').checked) {
		$('cms-pubend-Unrestricted-edit').checked = false;
		cxPublicEndUnrestricted();
		$('cms_pubey').value = PUB_INDEFINITE_YAER;
		$('cms_pubem').value = PUB_INDEFINITE_MONTH;
		$('cms_pubed').value = PUB_INDEFINITE_DAY;
		$('cms_pubeh').value = PUB_INDEFINITE_HOUR;
	}

	if (!cxPropertyCheck()) return false;
	cxLayer('cms8341-calendar', 0);
	var pt = $('cms_page_title').value;
	var emptyFlag = true;
	document.title = pt;
	if ($('cms-pan-title')) $('cms-pan-title').innerHTML = replace_consecutive_space(pt.escapeHTML());
	if ($('cms-pan-ancestor')) $('cms-pan-ancestor').innerHTML = cmsPanAncestor;
	if ($('cms-page-title')) $('cms-page-title').innerHTML = replace_consecutive_space(pt.escapeHTML());
	if ($('kanko_page_title')) $('kanko_page_title').innerHTML = replace_consecutive_space(pt.escapeHTML());
	if (($F('cms_template_kind') == TEMPLATE_KIND_FIXED) && ($F('cms_template_kanko_type') == KANKO_TYPE_EVENT)) {
		// イベントカレンダー複数日
		if (EVENT_CAL_MULTI_FLAG == true) {
			// 要素数取得
			var element_cnt = document.getElementById('cms_pd' + '_count').value;
			var params = '';
			var cnt = 0;
			// 追加された入力欄を削除
			for (var i = 1; i <= element_cnt; i++) {
				if (document.getElementById('cms_pd' + i + 'sy') != null && document.getElementById('cms_pd' + i + 'sy') != undefined && document.getElementById('cms_pd' + i + 'sy').value != '') {
					// 開始日【年】取得
					var open_sy = (document.getElementById('cms_pd' + i + 'sy').value != '') ? document.getElementById('cms_pd' + i + 'sy').value : '0000';
					open_sy = ('0000' + open_sy).slice(-4);
					// 開始日【月】取得
					var open_sm = (document.getElementById('cms_pd' + i + 'sm').value != '') ? document.getElementById('cms_pd' + i + 'sm').value : '00';
					open_sm = ('00' + open_sm).slice(-2);
					// 開始日【日】取得
					var open_sd = (document.getElementById('cms_pd' + i + 'sd').value != '') ? document.getElementById('cms_pd' + i + 'sd').value : '00';
					open_sd = ('00' + open_sd).slice(-2);
					// 開始日【時】取得
					var open_sh = (document.getElementById('cms_pd' + i + 'sh').value != '') ? ('00' + document.getElementById('cms_pd' + i + 'sh').value).slice(-2) : '';
					// 開始日【分】取得
					var open_si = (document.getElementById('cms_pd' + i + 'si').value != '') ? ('00' + document.getElementById('cms_pd' + i + 'si').value).slice(-2) : '';
					// 開始日【秒】取得
					var open_ss = '00';
					// 開始日連結
					var open_s_date = open_sy + '/' + open_sm + '/' + open_sd;
					if (open_sh != '' && open_si != '') {
						open_s_date += ' ' + open_sh + ':' + open_si + ':' + open_ss;
					}

					// 終了日【年】取得
					var open_ey = (document.getElementById('cms_pd' + i + 'ey').value != '') ? document.getElementById('cms_pd' + i + 'ey').value : '0000';
					open_ey = ('0000' + open_ey).slice(-4);
					// 終了日【月】取得
					var open_em = (document.getElementById('cms_pd' + i + 'em').value != '') ? document.getElementById('cms_pd' + i + 'em').value : '00';
					open_em = ('00' + open_em).slice(-2);
					// 終了日【日】取得
					var open_ed = (document.getElementById('cms_pd' + i + 'ed').value != '') ? document.getElementById('cms_pd' + i + 'ed').value : '00';
					open_ed = ('00' + open_ed).slice(-2);
					// 終了日【時】取得
					var open_eh = (document.getElementById('cms_pd' + i + 'eh').value != '') ? ('00' + document.getElementById('cms_pd' + i + 'eh').value).slice(-2) : '';
					// 終了日【分】取得
					var open_ei = (document.getElementById('cms_pd' + i + 'ei').value != '') ? ('00' + document.getElementById('cms_pd' + i + 'ei').value).slice(-2) : '';
					// 終了日【秒】取得
					var open_es = '00';
					// 開始日連結
					var open_e_date = '';
					if (open_ey != '0000') {
						open_e_date = open_ey + '/' + open_em + '/' + open_ed;
						if (open_eh != '' || open_ei != '') {
							open_e_date += ' ' + open_eh + ':' + open_ei + ':' + open_es;
						}
					}

					// パラメータの作成
					if (params != '') {
						params += '&';
					}
					params += 'open_date_ary[' + cnt + '][open_start]=' + open_s_date;
					params += '&open_date_ary[' + cnt + '][open_end]=' + open_e_date;
					cnt++;
				}

				if (document.getElementById('del_event_date' + i) != null) {
					// 削除するtd要素を取得
					var element = document.getElementById('cms_pd' + i);

					// 親要素を取得
					var parent = element.parentNode;

					// 指定された要素を削除
					parent.parentNode.removeChild(parent);
				}
			}

			// 一度入力欄の日付をクリア
			document.getElementById('cms_pd' + '1sy').value = '';
			document.getElementById('cms_pd' + '1sm').value = '';
			document.getElementById('cms_pd' + '1sd').value = '';
			document.getElementById('cms_pd' + '1sh').value = '';
			document.getElementById('cms_pd' + '1si').value = '';
			document.getElementById('cms_pd' + '1ey').value = '';
			document.getElementById('cms_pd' + '1em').value = '';
			document.getElementById('cms_pd' + '1ed').value = '';
			document.getElementById('cms_pd' + '1eh').value = '';
			document.getElementById('cms_pd' + '1ei').value = '';

			// ajaxによる開催期間の集約実行
			rText = cxAjaxCommandAnSync('cxMergeOpenDate', params, '').transport.responseText;
			// 「false」が返された場合エラー出力
			if (rText == 'false') {
				alert('開催期間の集約に失敗しました。');
				return false;
			}
			else if (rText != '') {
				var result = eval('(' + rText + ')');
				var input_cnt = 1;
				document.getElementById('cms_pd' + '_count').value = 1;
				// 集約された情報をもとに入力ボックスを再生成する
				for (result_cnt = 0; result_cnt < result.length; result_cnt++) {
					if (input_cnt > 1) {
						// 入力欄を追加（IE11やその他ブラウザで動かないため処理を変更）
						//document.getElementById('add_event_date').fireEvent('onclick');
						// イベントオブジェクトを作成
						var event_obj = document.createEvent( "MouseEvents" );
						// イベントの内容を設定
						event_obj.initEvent("click", false, true);
						// イベントを実行する
						document.getElementById('add_event_date').dispatchEvent(event_obj);
						
						// 入力欄の要素数を再取得
						element_cnt = document.getElementById('cms_pd' + '_count').value;
					}

					// セットする要素が存在しない場合はスキップ
					if (document.getElementById('cms_pd' + input_cnt + 'sy') == null) continue;

					// 開始日【年月日】をセット
					document.getElementById('cms_pd' + input_cnt + 'sy').value = result[result_cnt]['open_start']['y'];
					document.getElementById('cms_pd' + input_cnt + 'sm').value = result[result_cnt]['open_start']['m'].replace(/^0+([0-9]+)/, "$1");
					document.getElementById('cms_pd' + input_cnt + 'sd').value = result[result_cnt]['open_start']['d'].replace(/^0+([0-9]+)/, "$1");
					// 要素の属性値を取得し、無い場合は、属性値を設定する
					if (!document.getElementById('cms_pd' + input_cnt + 'sy').getAttribute('value')) {
						document.getElementById('cms_pd' + input_cnt + 'sy').setAttribute('value', result[result_cnt]['open_start']['y']);
						document.getElementById('cms_pd' + input_cnt + 'sm').setAttribute('value', result[result_cnt]['open_start']['m'].replace(/^0+([0-9]+)/, "$1"));
						document.getElementById('cms_pd' + input_cnt + 'sd').setAttribute('value', result[result_cnt]['open_start']['d'].replace(/^0+([0-9]+)/, "$1"));
					}

					// 開始日【時間】をセット
					document.getElementById('cms_pd' + input_cnt + 'sh').value = result[result_cnt]['open_start']['h'].replace(/^0+([0-9]+)/, "$1");
					document.getElementById('cms_pd' + input_cnt + 'si').value = result[result_cnt]['open_start']['i'];
					// 要素の属性値を取得し、無い場合は、属性値を設定する
					if (!document.getElementById('cms_pd' + input_cnt + 'sh').getAttribute('value') ||
						!document.getElementById('cms_pd' + input_cnt + 'si').getAttribute('value')) {
						document.getElementById('cms_pd' + input_cnt + 'sh').setAttribute('value', result[result_cnt]['open_start']['h'].replace(/^0+([0-9]+)/, "$1"));
						document.getElementById('cms_pd' + input_cnt + 'si').setAttribute('value', result[result_cnt]['open_start']['i']);
					}

					// 終了日【年月日】をセット
					document.getElementById('cms_pd' + input_cnt + 'ey').value = (result[result_cnt]['open_end']['y']) ? result[result_cnt]['open_end']['y'] : '';
					document.getElementById('cms_pd' + input_cnt + 'em').value = (result[result_cnt]['open_end']['m']) ? result[result_cnt]['open_end']['m'].replace(/^0+([0-9]+)/, "$1") : '';
					document.getElementById('cms_pd' + input_cnt + 'ed').value = (result[result_cnt]['open_end']['d']) ? result[result_cnt]['open_end']['d'].replace(/^0+([0-9]+)/, "$1") : '';
					// 要素の属性値を取得し、無い場合は、属性値を設定する
					if (!document.getElementById('cms_pd' + input_cnt + 'ey').getAttribute('value')) {
						document.getElementById('cms_pd' + input_cnt + 'ey').setAttribute('value', (result[result_cnt]['open_end']['y']) ? result[result_cnt]['open_end']['y'] : '');
						document.getElementById('cms_pd' + input_cnt + 'em').setAttribute('value', (result[result_cnt]['open_end']['m']) ? result[result_cnt]['open_end']['m'].replace(/^0+([0-9]+)/, "$1") : '');
						document.getElementById('cms_pd' + input_cnt + 'ed').setAttribute('value', (result[result_cnt]['open_end']['d']) ? result[result_cnt]['open_end']['d'].replace(/^0+([0-9]+)/, "$1") : '');
					}

					// 終了日【時間】をセット
					document.getElementById('cms_pd' + input_cnt + 'eh').value = (result[result_cnt]['open_end']['h']) ? result[result_cnt]['open_end']['h'].replace(/^0+([0-9]+)/, "$1") : '';
					document.getElementById('cms_pd' + input_cnt + 'ei').value = (result[result_cnt]['open_end']['i']) ? result[result_cnt]['open_end']['i'] : '';
					// 要素の属性値を取得し、無い場合は、属性値を設定する
					if (!document.getElementById('cms_pd' + input_cnt + 'eh').getAttribute('value') ||
						!document.getElementById('cms_pd' + input_cnt + 'ei').getAttribute('value')) {
						document.getElementById('cms_pd' + input_cnt + 'eh').setAttribute('value', (result[result_cnt]['open_end']['h']) ? result[result_cnt]['open_end']['h'].replace(/^0+([0-9]+)/, "$1") : '');
						document.getElementById('cms_pd' + input_cnt + 'ei').setAttribute('value', (result[result_cnt]['open_end']['i']) ? result[result_cnt]['open_end']['i'] : '');
					}

					// 処理数(input_cnt)を+1
					++input_cnt;
				}
			}

			// 要素数の取得
			var element_no = document.getElementById('cms_pd_count').value;

			// つなぎ文字を取得
			var open_op = (document.getElementById('cms-open_op_def') != null) ? document.getElementById('cms-open_op_def').value : '';

			// テンプレート取得
			var temp = (document.getElementById('cms-open_date_temp') != null) ? document.getElementById('cms-open_date_temp').value : '';

			// 開始日フォーマット取得
			var temp_st = (document.getElementById('cms-open_start') != null) ? document.getElementById('cms-open_start').value : '';

			// 終了日フォーマット取得
			var temp_ed = (document.getElementById('cms-open_end') != null) ? document.getElementById('cms-open_end').value : '';

			// 要素ごとの日付を処理
			var open_date = '';
			for (var i = 1; i <= element_no; i++) {
				// 入力欄削除により要素が無ければスキップ
				if (document.getElementById('cms_pd' + i + 'sy') == null) {
					continue;
				}

				// 開始日が未入力の場合はスキップ
				if (document.getElementById('cms_pd' + i + 'sy').value == '' && document.getElementById('cms_pd' + i + 'sm').value == '' && document.getElementById('cms_pd' + i + 'sd').value == '') {
					continue;
				}

				// 開始日
				var open_start = '';
				if (document.getElementById('cms-open_date') != null) {
					var sy = document.getElementById('cms_pd' + i + 'sy').value;
					var sm = document.getElementById('cms_pd' + i + 'sm').value;
					var sd = document.getElementById('cms_pd' + i + 'sd').value;
					var sh = document.getElementById('cms_pd' + i + 'sh').value;
					var si = document.getElementById('cms_pd' + i + 'si').value;

					open_start = eventDayFormat(temp_st, sy, sm, sd, sh, si, 'start');
				}

				// 終了日
				var open_end = '';
				if (document.getElementById('cms_pd' + i + 'ey').value + document.getElementById('cms_pd' + i + 'em').value + document.getElementById('cms_pd' + i + 'ed').value != '') {
					var ey = document.getElementById('cms_pd' + i + 'ey').value;
					var em = document.getElementById('cms_pd' + i + 'em').value;
					var ed = document.getElementById('cms_pd' + i + 'ed').value;
					var eh = document.getElementById('cms_pd' + i + 'eh').value;
					var ei = document.getElementById('cms_pd' + i + 'ei').value;

					open_end = eventDayFormat(temp_st, ey, em, ed, eh, ei, 'end');
				}

				// 置き換え文字を置換
				var temp_open_date = temp;
				if (open_start == open_end || open_end == '') {
					temp_open_date = temp_open_date.replace('open_start', open_start);
					temp_open_date = temp_open_date.replace(open_op, '');
					temp_open_date = temp_open_date.replace('open_end', '');
				} else {
					temp_open_date = temp_open_date.replace('open_start', open_start);
					temp_open_date = temp_open_date.replace('open_end', open_end);
				}
				open_date += temp_open_date;
			}

			// 編集ページにセット
			if (document.getElementById('cms-open_date') != null) {
				document.getElementById('cms-open_date').innerHTML = open_date;
			}
		}
		// イベントカレンダー単一日
		else {

			if ($('cms-open_start')) $('cms-open_start').innerHTML = $('cms_pdsy').value + "年" + $('cms_pdsm').value + "月" + $('cms_pdsd').value + "日";
			if ($F('cms_pdey') + $F('cms_pdem') + $F('cms_pded') != "") {
				if ($('cms-open_end')) $('cms-open_end').innerHTML = $('cms_pdey').value + "年" + $('cms_pdem').value + "月" + $('cms_pded').value + "日";
				if ($('cms-open_op')) $('cms-open_op').innerHTML = $F('cms-open_op_def');
			} else {
				if ($('cms-open_end')) $('cms-open_end').innerHTML = "";
				if ($('cms-open_op')) $('cms-open_op').innerHTML = "";
			}
		}


	}
	if ($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE && $F('cms_ssl_flg') == FLAG_ON) {
		$('cms_filename').value = $('cms_file_name').value + ".html";
	}

	// ファイル名を小文字に変換
	$('cms_filename').value = $F('cms_filename').toLowerCase();

	inquiry_no = 1;
	for (i = 1; i < Number($F('cms_inquiry_cnt')) + 1; i++) {
		if (i > cmsPropObj.inquiry_cnt) {
			cxUpdateInquiry(i);
		}
		if (!$('cms_inquiry_' + i)) {
			if ($('cms_inquiry_' + i)) Element.remove($('cms_inquiry_' + i));
			if ($('cms_inquiry_detail_' + i)) Element.remove($('cms_inquiry_detail_' + i));
			continue;
		}
		var dept_val = "";
		if ($('cms_inquiry_prop_dept1_' + i)) {
			si1 = $('cms_inquiry_prop_dept1_' + i).options.selectedIndex;
			name1 = cxGetDeptCombText($('cms_inquiry_prop_dept1_' + i).options[si1].text);
		}
		if ($('cms_inquiry_prop_dept2_' + i)) {
			si2 = $('cms_inquiry_prop_dept2_' + i).options.selectedIndex;
			name2 = cxGetDeptCombText($('cms_inquiry_prop_dept2_' + i).options[si2].text);
		}
		if ($('cms_inquiry_prop_dept3_' + i)) {
			si3 = $('cms_inquiry_prop_dept3_' + i).options.selectedIndex;
			name3 = cxGetDeptCombText($('cms_inquiry_prop_dept3_' + i).options[si3].text);
		}
		if ($('cms_inquiry_dept_name_' + i)) {
			$('cms_inquiry_dept_name_' + i).innerHTML = name1 + name2 + name3;
			dept_val = $('cms_inquiry_dept_name_' + i).innerHTML;
		}
		if ($('cms_inquiry_name1_' + i)) {
			$('cms_inquiry_name1_' + i).innerHTML = name1;
			dept_val = dept_val + $('cms_inquiry_name1_' + i).innerHTML;
		}
		if ($('cms_inquiry_name2_' + i)) {
			$('cms_inquiry_name2_' + i).innerHTML = name2;
			dept_val = dept_val + $('cms_inquiry_name2_' + i).innerHTML;
		}
		if ($('cms_inquiry_name3_' + i)) {
			$('cms_inquiry_name3_' + i).innerHTML = name3;
			dept_val = dept_val + $('cms_inquiry_name3_' + i).innerHTML;
		}

		if (dept_val != "") emptyFlag = false;
		// すべて入力なしの場合は項目を削除
		var charge = "", anExtensionNumber = "", directNumber = "", fax = "", email = "";
		if ($('cms_inquiry_prop_charge_' + i)) charge = $F('cms_inquiry_prop_charge_' + i);
		if ($('cms_inquiry_prop_directNumber_' + i)) directNumber = $F('cms_inquiry_prop_directNumber_' + i);
		if ($('cms_inquiry_prop_anExtensionNumber_' + i)) anExtensionNumber = $F('cms_inquiry_prop_anExtensionNumber_' + i);
		if ($('cms_inquiry_prop_fax_' + i)) fax = $F('cms_inquiry_prop_fax_' + i);
		if ($('cms_inquiry_prop_email_' + i)) email = $F('cms_inquiry_prop_email_' + i);
		if (dept_val == "" && charge == "" && directNumber == "" && anExtensionNumber == "" && fax == "" && email == "") {
			var alive_cnt = 0;
			for (j = 1; j < Number($F('cms_inquiry_cnt')) + 1; j++) {
				if ($('cms_inquiry_' + j)) alive_cnt++;
			}
			if (alive_cnt > 1) {
				Element.remove($('cms_inquiry_' + i));
				Element.remove($('cms_inquiry_detail_' + i));
				continue;
			}
		}
		if ($('cms_inquiry_charge_' + i)) {
			$('cms_inquiry_charge_' + i).innerHTML = $F('cms_inquiry_prop_charge_' + i).escapeHTML();
			if ($F('cms_inquiry_prop_charge_' + i) != "") emptyFlag = false;
		}
		if ($('cms_inquiry_tel1_' + i)) {
			$('cms_inquiry_tel1_' + i).innerHTML = htmlEscape(cxEscapeHtmlChars($F('cms_inquiry_prop_directNumber_' + i)));
			if ($F('cms_inquiry_prop_directNumber_' + i) != "") emptyFlag = false;
		}
		if ($('cms_inquiry_tel2_' + i)) {
			$('cms_inquiry_tel2_' + i).innerHTML = htmlEscape(cxEscapeHtmlChars($F('cms_inquiry_prop_anExtensionNumber_' + i)));
			if ($F('cms_inquiry_prop_anExtensionNumber_' + i) != "") emptyFlag = false;
		}
		if ($('cms_inquiry_fax_' + i)) {
			$('cms_inquiry_fax_' + i).innerHTML = htmlEscape(cxEscapeHtmlChars($F('cms_inquiry_prop_fax_' + i)));
			if ($F('cms_inquiry_prop_fax_' + i) != "") emptyFlag = false;
		}
		if ($('cms_inquiry_email_' + i)) {
			$('cms_inquiry_email_' + i).innerHTML = htmlEscape(cxEscapeHtmlChars($F('cms_inquiry_prop_email_' + i)));
			if ($F('cms_inquiry_prop_email_' + i) != "") emptyFlag = false;
		}
		if ($('cms_inquiry_dept_td_' + i)) changeVisible(dept_val, $('cms_inquiry_style_dept_' + i));
		if ($('cms_inquiry_prop_charge_' + i)) changeVisible($F('cms_inquiry_prop_charge_' + i), $('cms_inquiry_style_charge_' + i));
		if ($('cms_inquiry_prop_directNumber_' + i)) changeVisible($F('cms_inquiry_prop_directNumber_' + i), $('cms_inquiry_style_tel1_' + i));
		if ($('cms_inquiry_prop_anExtensionNumber_' + i)) changeVisible($F('cms_inquiry_prop_anExtensionNumber_' + i), $('cms_inquiry_style_tel2_' + i));
		if ($('cms_inquiry_prop_fax_' + i)) changeVisible($F('cms_inquiry_prop_fax_' + i), $('cms_inquiry_style_fax_' + i));
		if ($('cms_inquiry_prop_email_' + i)) changeVisible($F('cms_inquiry_prop_email_' + i), $('cms_inquiry_style_email_' + i));
		$('cms_inquiry_prop_no_' + i).innerHTML = '問い合わせ先' + inquiry_no;

		$('cms_inquiry_' + i)._num = inquiry_no;

		// inquiry_no = 1 の場合は削除ボタンを消す
		if (inquiry_no == 1 && $('cms_inquiry_delete_td_' + i)) $('cms_inquiry_delete_td_' + i).style.display = "none";

		// 問い合わせ先の第三組織まで必須チェック機能
		var inquiry_detail = document.getElementById('cms_inquiry_detail_' + i);
		var inquiry_btn = inquiry_detail.getElementsByClassName('inquiry_btn')[0];
		if (!CHECK_INQUIRY_DISP_NO_DPT_INQ_BTN && dept_val == '') {
			inquiry_btn && Element.hide(inquiry_btn);
		}
		else {
			if(inquiry_btn && !inquiry_btn.visible()) {
				Element.show(inquiry_btn);
			}
		}
		
		inquiry_no++;
	}

	if ($('cms_inquiry_memo')) {
		$('cms_inquiry_memo').innerHTML = htmlEscape(cxEscapeHtmlChars($F('cms_inquiry_prop_memo')));
		//$('cms_inquiry_memo').innerHTML = htmlEscape($F('cms_inquiry_prop_memo').escapeHTML());
		if ($F('cms_inquiry_prop_memo') != "") emptyFlag = false;
	}
	if ($('cms_inquiry_prop_memo')) changeVisible($F('cms_inquiry_prop_memo'), $('cms_inquiry_style_memo'));

	if ($('cms_inquiry_set')) {
		if (emptyFlag) {
			Element.hide('cms_inquiry_set');
		} else {
			Element.show('cms_inquiry_set');
		}
	}
	//観光入力チェック
	if ($F('cms_template_kind') == TEMPLATE_KIND_FIXED || ($('kanko_xml') && $F('kanko_xml') != "")) {
		if (kankoCheck("cms8341-property") == false) return false;
	}

	if ($F('cms_template_kind') == TEMPLATE_KIND_FREE && $("cms-template-selected") && $("cms_template_id").value != cmsPropObj.cms_template_id) {

		var templateChangeComment = "テンプレートを変更する場合は一時保存を行います。\nよろしいですか？\n";

		if (confirm(templateChangeComment)) {
			cxSave(STATUS_SAVE);
		}
		return false;
	}

	cxLayer('cms8341-calendar', 0);
	cxLayer('cms8341-category', 0);
	cxLayer('cms8341-reffer', 0);
	cxLayer('cms8341-property', 0);
	if ($('cms8341-template-select')) cxLayer('cms8341-template-select', 0);
	edit_closet_flg = false;
	cxComboVisible();
}

function cxPropertyCheck() {
	var pt = $('cms_page_title').value;
	var info = new Array();
	if (!pt || pt == '') {
		alert('タイトルが入力されていません。');
		$('cms_page_title').focus();
		return false;
	}
	if (($F('cms_template_kind') == TEMPLATE_KIND_FIXED) && ($F('cms_template_kanko_type') == KANKO_TYPE_EVENT)) {
		// イベントカレンダー複数日
		if (EVENT_CAL_MULTI_FLAG == true) {
			// イベントカレンダー複数日対応
			// 要素数の取得
			var element_no = document.getElementById('cms_pd_count').value;

			// 開始日に入力箇所がある件数を取得
			var input_count = 0;
			for (var i = 1; i <= element_no; i++) {
				// 入力欄削除により要素が無ければスキップ
				if (document.getElementById('cms_pd' + i + 'sy') == null) {
					continue;
				}
				if (document.getElementById('cms_pd' + i + 'sy').value != "" && document.getElementById('cms_pd' + i + 'sm').value != "" && document.getElementById('cms_pd' + i + 'sd').value != "") {
					++input_count;
				}
			}
			var no_check_flg = (input_count == 0) ? false : true;
			var pd_elem = new Array('sy', 'sm', 'sd', 'sh', 'si', 'ey', 'em', 'ed', 'eh', 'ei');
			var pd = new Array();

			// 要素ごとの日付をチェック
			for (var i = 1; i <= element_no; i++) {
				// 入力欄削除により要素が無ければスキップ
				if (document.getElementById('cms_pd' + i + 'sy') == null) {
					continue;
				}

				// 日時を配列に格納
				for (var key in pd_elem) {
					if (document.getElementById('cms_pd' + i + pd_elem[key]) == null) {
						continue;
					}
					pd[pd_elem[key]] = document.getElementById('cms_pd' + i + pd_elem[key]).value;
				}

				// 1行でも開始日が入力されている場合に開始日と終了日が空白の場合はスキップ
				if ((pd['sy'] == '' && pd['sm'] == '' && pd['sd'] == '' && pd['sh'] == '' && pd['si'] == '' && pd['ey'] == '' && pd['em'] == '' && pd['ed'] == '' && pd['eh'] == '' && pd['ei'] == '') && no_check_flg == true) {
					continue;
				}

				// チェック結果格納用配列
				var dc = new Array();
				var res_error = new Array();

				// 開始日チェック
				if (document.getElementById('cms_pd' + i + 'sy').value != "" || document.getElementById('cms_pd' + i + 'sm').value != "" || document.getElementById('cms_pd' + i + 'sd').value != "" || input_count == 0) {
					var err = cxDateCheckNew('cms_pd' + i, 'ymd', 2, '開催日');
					res_error.push(err.join('\n'));
				}

				// 終了日チェック
				if (document.getElementById('cms_pd' + i + 'ey').value != "" || document.getElementById('cms_pd' + i + 'em').value != "" || document.getElementById('cms_pd' + i + 'ed').value != "") {
					var err = cxDateCheckNew('cms_pd' + i, 'ymd', 1, '開催日');
					res_error.push(err.join('\n'));
				}

				// 開始時間チェック
				if (document.getElementById('cms_pd' + i + 'sh').value != "" || document.getElementById('cms_pd' + i + 'si').value != "") {
					var err = cxDateCheckNew('cms_pd' + i, 'hi', 2, '開催日');
					res_error.push(err.join('\n'));
				}

				// 終了時間チェック
				if (document.getElementById('cms_pd' + i + 'eh').value != "" || document.getElementById('cms_pd' + i + 'ei').value != "") {
					var err = cxDateCheckNew('cms_pd' + i, 'hi', 3, '開催日');
					res_error.push(err.join('\n'));
				}

				// エラーの重複を取り除く
				var error_msg = new Array();
				for (var j in res_error) {
					if (j.match(/[^0-9]/g)) continue;
					if (res_error[j] == '') continue;
					if (error_msg.indexOf(res_error[j]) != -1) continue;
					error_msg.push(res_error[j]);
				}
				if (error_msg.length > 0) {
					dc.push(error_msg.join('\n'));
				}

				// エラーメッセージ作成
				msg = new Array();
				msg = msg.concat(dc);
				if (msg.length > 0) {
					msg_str = msg.join('\n');
					alert(msg_str);
					$('cms_pd' + i + 'sy').focus();
					return false;
				}
			}
			var cal_input_area = document.getElementById('calendar_input_area');
			var event_set_limit = parseInt(document.getElementById('cms_pd_limit').value);
			var element_cnt = cal_input_area.getElementsByTagName('tr').length;

			// 設定上限を超えている場合はアラートを表示
			if (event_set_limit < element_cnt) {
				alert("開催期間を設定可能な件数を超えています。\n設定可能な開催期間は"+ event_set_limit +"件までです。");
				return false;
			}
		}
		// イベントカレンダー単一日
		else {
			if ($F('cms_pdey') == "" && $F('cms_pdem') == "" && $F('cms_pded') == "") {
				dc = cxDateCheckNew('cms_pd', 'ymd', 2, '開催日');
			} else {
				dc = cxDateCheckNew('cms_pd', 'ymd', 1, '開催日');
			}
			msg = new Array();
			msg = msg.concat(dc);
			if (msg.length > 0) {
				msg_str = msg.join('\n');
				alert(msg_str);
				$('cms_pdsy').focus();
				return false;
			}
		}
	}
	if ($F('cms_usr_class') == USER_CLASS_WEBMASTER && $F('cms_status') != STATUS_APPROVE_LAST) {
		dc = cxDateCheckNew('cms_pub', 'ymdh', 1, '公開日');
		msg = new Array();
		msg = msg.concat(dc);
		if (msg.length > 0) {
			msg_str = msg.join('\n');
			alert(msg_str);
			$('cms_pubsy').focus();
			return false;
		}
	}
	// メール送信先(アンケート・問い合わせ)
	if ($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE && $F("cms_from_type") == ENQ_KIND_MAIL && $("cms_enquete_emai_list")) {
		if (cmEnqEmailStringCreate() == 0) {
			alert('アンケート種別が問い合わせの場合はメールアドレスを選択してください。');
			return false;
		}
	}
	
	// オープンデータ
	// オープンデータが選択されているかチェック
	var select_opendata_flg = false;
	var opendata_id_elem = document.getElementsByName("opendata_id[]");
	for (i = 0; i < opendata_id_elem.length; i++ ) {
		if (opendata_id_elem.item(i).checked == true) {
			select_opendata_flg = true;
		}
	}
	if (select_opendata_flg) {
		// オープンデータ概要
		var summary_txt = trim($F('opendata_summary'));
		// 必須チェック
		if(summary_txt.length == 0){
			alert("概要を入力してください。");
			$('opendata_summary').focus();
			return false;
		}
		// 機種依存文字チェック
		info = new Array();
		info = fckCheck('概要',summary_txt,info);
		info = accItemCheck('概要',summary_txt,info,'file');
		if (!info) {
			alert("[概要]入力値チェックエラー");
			return false;
		}
		if(info.length > 0){
			var msg = info.join('\n') + '\nよろしいですか？';
			if(!confirm(msg)){
				$('opendata_summary').focus();
				return false;
			}
		}
		// ライセンス必須チェック
		var license_txt = trim($('opendata_license').value);
		if(license_txt.length == 0){
			alert("ライセンスを選択してください。");
			$('opendata_license').focus();
			return false;
		}
		// データ時点入力日付チェック
		if (!($F('opendata_poit_timesy') == "" && $F('opendata_poit_timesm') == "" && $F('opendata_poit_timesd') == "")) {
			var date_check_result = cxDateCheckNew("opendata_poit_time", "ymd", 2, "データ時点");
			if (!disp_date_error(date_check_result, "opendata_poit_timesy")) {
				return false;
			}
		} else {
			alert("データ時点を入力してください。");
			$('opendata_poit_timesy').focus();
			return false;
		}
		// 掲載日
		if (!($F('opendata_pubsy') == "" && $F('opendata_pubsm') == "" && $F('opendata_pubsd') == "")) {
			var date_check_result = cxDateCheckNew("opendata_pub", "ymd", 2, "掲載日");
			if (!disp_date_error(date_check_result, "opendata_pubsy")) {
				return false;
			}
		} else {
			alert("掲載日を入力してください。");
			$('opendata_pubsy').focus();
			return false;
		}
		// カテゴリ必須チェック
		if (!isCheck('opendata_category[]', "checkbox") ) {
			alert("カテゴリを選択してください。");
			return false;
		}
		// データタイプ必須チェック
		var od_data_type_txt = trim($('od_data_type').value);
		if(od_data_type_txt.length == 0){
			alert("データタイプを選択してください。");
			$('od_data_type').focus();
			return false;
		}
		// キーワード検索タグ
		var keyword_search_txt = trim($F('opendata_keywords'));
		// 機種依存文字チェック
		info = new Array();
		info = fckCheck('キーワード検索タグ',keyword_search_txt,info);
		info = accItemCheck('キーワード検索タグ',keyword_search_txt,info,'file');
		if (!info) {
			alert("[キーワード検索タグ]入力値チェックエラー");
			return false;
		}
		if(info.length > 0){
			var msg = info.join('\n') + '\nよろしいですか？';
			if(!confirm(msg)){
				$('opendata_keywords').focus();
				return false;
			}
		}
	}
	
	var err = new Array();
	if ($('cms_page_title')) info = fckCheck('タイトル', $('cms_page_title').value, info);
	if ($('cms_keywords')) info = fckCheck('検索エンジン用キーワード', $('cms_keywords').value, info);
	if ($('cms_description')) info = fckCheck('検索エンジン用説明文', $('cms_description').value, info);
	if ($('cms_summary')) info = fckCheck('要約文', $('cms_summary').value, info);
//	if ($('cms_index_title') ) info = fckCheck('リンク掲載用タイトル',$('cms_index_title').value.replace(/"/g,'&quot;'), info);
	if ($('cms_inquiry_tr') && (!$('cms_inquiry_tr').style || $('cms_inquiry_tr').style.display != "none")) {
		info = cxInquiryCheck('cms_inquiry_prop', info);
	}
	if (!info) return false;
	// 問い合わせ先の第三組織まで必須チェック機能
	if (CHECK_INQUIRY_DEPARTMENT_FLG) {
		var inquiry_item = Number($('cms_inquiry_cnt').value);
		for (var i = 1; i <= inquiry_item; i++) {
			var dept_name_1 = $('cms_inquiry_prop_dept1_' + i);
			if (dept_name_1 && dept_name_1.value != '') {
				for (var index = 1; index <= CHECK_INQUIRY_DEPARTMENT_DEPTH; index++) {
					var dept_name = $('cms_inquiry_prop_dept' + index + '_' + i);
					if (dept_name.value == '') {
						alert($('cms_inquiry_prop_no_' + i ).innerHTML + '：所属課室には、第' + CHECK_INQUIRY_DEPARTMENT_DEPTH +'階層の組織まで指定してください。\n「指定なし」は選択できません。');
						dept_name.focus();
						return false;
					}
				}
			}
		}
	}
	if (info.length > 0) {
		var msg = info.join('\n') + '\n\nよろしいですか？';
		if (!confirm(msg)) {
			return false;
		}
	}
	return true;
}

function cxGetLabelText(e_id) {
	var le = document.getElementsByTagName('label');
	for (var i = 0; i < le.length; i++) {
		var o = le[i].outerHTML;
		var c = o.indexOf(e_id);
		if (c != -1) {
			return le[i].innerHTML;
		}
	}
	//return false;
}

//オープンデータ
/**
*	チェックされている値の取得
*	@palam id Name
*	@palam item アイテム名
*	return チェックされている項目が存在したらValue値、しなかったらFalse
*/
function getCheckValue(id, item){
	var ret = false;
	var nodes = Form.getInputs($('cms8341-property'), item, id);
	$A(nodes).each( function(obj) { 
						if(obj.checked) ret = obj.value;
					} ); 
	return ret;
}

//チェックされているかチェック
function isCheck(id, item){
	ret = getCheckValue(id, item);
	return ret;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//relation links set
var cms_rl_ele;

//Scroll & Drag
function cxSortableReset() {
	Position.includeScrollOffsets = true;
	Sortable.create('cms-list', {
		containment: ['cms-list', 'cms-dust'],
		dropOnEmpty: true,
		ghosting: true,
		onChange: cxChange
	});
	Sortable.create('cms-dust', {
		containment: ['cms-list', 'cms-dust'],
		dropOnEmpty: true,
		ghosting: true,
		onUpdate: cxDust
	});
}

//
function cxChange(element) {
	element.style.width = '80%';
}

//
function cxDust(element) {
	element.childNodes[0].removeNode(true);
	cms_rl_ele = null;
	$('cms-new_form').style.display = 'block';
	$('cms-edit_form').style.display = 'none';
}

//
function cxLayerAdd() {
	//
	var v01 = $('cms-e_add01').value;
	var v02 = $('cms-e_add02').value;
	if (!v01 || !v02) {
		alert('リンク情報を入力してください。');
		$('cms-e_add01').focus();
		return;
	}
	//
	var id = $('cms-list').childNodes.length;
	var e = document.createElement('li');
	var a = document.createElement('a');
	a.innerHTML = v01;
	a.href = v02;
	a.target = '_blank';
	e.appendChild(a);
	//add element
	$('cms-list').appendChild(e);
	//add listener
	Event.observe(e, 'click', captureEvent, false);
	//reset
	cxSortableReset();
	$('cms-e_add01').value = '';
	$('cms-e_add02').value = '';
}

//
function cxLayerEdit() {
	if (!cms_rl_ele) {
		alert('element none');
		return;
	}
	//get input data
	var v01 = $('cms-e_add11').value;
	var v02 = $('cms-e_add12').value;
	//create element
	var a = document.createElement('a');
	a.innerHTML = v01;
	a.href = v02;
	a.target = '_blank';
	//
	cms_rl_ele.removeChild(cms_rl_ele.firstChild);
	cms_rl_ele.appendChild(a);
	cms_rl_ele.style.backgroundColor = 'white';
	cms_rl_ele = null;
	$('cms-edit_form').style.display = 'none';
	$('cms-new_form').style.display = 'block';
}

function captureEvent(event) {
	var e = Event.element(event);
	if (e.tagName == 'A') {
		//var r = confirm('クリックした項目を編集モードにしますか？');
		r = false;
		if (!r) {
			return;
		} else {
			e = e.parentNode;
		}
	}
	//
	if (cms_rl_ele) {
		if (cms_rl_ele == e) {
			cms_rl_ele.style.backgroundColor = 'white';
			cms_rl_ele = null;
			$('cms-edit_form').style.display = 'none';
			$('cms-new_form').style.display = 'block';
			return;
		} else {
			//alert('編集中の項目があります。');
			cms_rl_ele.style.backgroundColor = 'white';
			cms_rl_ele = null;
			//return;
		}
	}
	//
	cms_rl_ele = e;
	//
	var pn_chk = cms_rl_ele.parentNode.id;
	if (pn_chk == 'cms-dust') {
		cms_rl_ele = null;
		return;
	}
	//
	cms_rl_ele.style.backgroundColor = 'yellow';
	$('cms-e_add11').value = cms_rl_ele.firstChild.innerHTML;
	$('cms-e_add12').value = cms_rl_ele.firstChild.href;
	$('cms-new_form').style.display = 'none';
	$('cms-edit_form').style.display = 'block';
}

function cxRelLinksSubmit() {
	cxLayer('cms-rellink', 0);
}

//PHPとの接続
var ret_ajax;

function cxPgSzChkAjaxCmd(param) {
	var params = 'param=' + encodeURI(param).replace(/&/g, "%26");
	var ajax = new Ajax.Request(
		cms8341admin_path + '/page/common/size_check.php',
		{
			method: 'post',
			asynchronous: false,
			parameters: params
		});
	ret_ajax = ajax.transport.responseText;
}

function cxPgSzChk(st, info) {
	if (!$('cms_context')) return true;
	if (!($('cms_accessibility_check_12') || $('cms_accessibility_check_12_w'))) return true;

	word = $('cms_accessibility_check_12_w').innerHTML;
	var opt = new Array(7);
	opt = word.split(",", 7);

	if ((opt[2] == 0) && (st == 201)) return true;
	if ((opt[3] == 0) && (st == 202)) return true;

	var oEditor = CKEDITOR.instances.cms_context;
	var context = oEditor.getData();

	cxPgSzChkAjaxCmd(context);

	if ($F('cms_template_kind') == TEMPLATE_KIND_MOBILE) {
		text_size = opt[5];
		use_file_size = opt[6];
	} else {
		text_size = opt[0];
		use_file_size = opt[1];
	}
	sz = ret_ajax.split(",");
	if ((sz.length != 2) || (sz[0] == -1)) {
		$('cms8341-errormsg').innerHTML = '<p align="center">ページ容量チェックに失敗しました</p>';
		cxLayer('cms8341-error', 1, 500, 500);
		return false;
	}

	var err_cnt = 0;
	var diff = parseInt(sz[0], 10) - parseInt(text_size, 10);
	if (0 < diff) {
//		info.push('テキストサイズが制限容量を超えています。(' + diff + 'KB容量オーバー)');
		err_cnt++;
	}

	diff = parseInt(sz[1], 10) - parseInt(use_file_size, 10);
	if (0 < diff) {
//		info.push('画像など非テキストコンテンツが制限容量を超えています。(' + diff + 'KB容量オーバー)');
		err_cnt++;
	}

	if (0 < err_cnt) {
		var msg = '編集領域に含まれている文字または画像の容量が設定値を超えています。\n';
		if ((st == 202) && ($F('cms_usr_class') != $F('cms_usr_webmaster'))) {
			msg = msg + '一時保存をするか、ページ容量を設定値以下にしてください。\n';
		}
		msg = msg + '　文字： ' + sz[0] + 'KB （上限： ' + text_size + 'KB)\n';
		msg = msg + '　画像： ' + sz[1] + 'KB （上限： ' + use_file_size + 'KB)\n';
		msg = msg + '※文字にはHTMLタグ情報も含まれます。';
		info.push(msg);

		if ((opt[4] != 0) && (st == 202) && ($F('cms_usr_class') != $F('cms_usr_webmaster'))) {// ウェブマスタは除く
			var m = info.join('\n');
			alert(m);
			return false;
		}
	}

	return true;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function cxSave(st) {
	if ($F('cms_template_kind') == TEMPLATE_KIND_NONE) {
		edit_closet_flg = false;
		cxComboHidden();
		$('cms8341-progressmsg').innerHTML = '保存中．．．';
		cxLayer('cms8341-progress', 1, 500, 500);
		document.cms_fEdit.action = cms8341admin_path + '/page/siteview/pageedit.php';
		document.cms_fEdit.target = '';
		document.cms_fEdit.cms_status.value = st;
		document.cms_fEdit.submit();
		return false;
	}
	//観光入力チェック
	if ($F('cms_template_kind') == TEMPLATE_KIND_FIXED || ($('kanko_xml') && $F('kanko_xml') != "")) {
		if (st != STATUS_COMP) kankoCustomItemCreate();
		if (st == STATUS_COMP && kankoCheck() == false) return false;
		//FLASH動画
		if ($('cms_template_kanko_type') && $F('cms_template_kanko_type') == KANKO_TYPE_FLASH_VIDEO) {
			//ファイルの存在チェックPHPを呼び出す(Ajax)
			if (!file_exists(DOCUMENT_ROOT + RPW + "/upload/video/" + $F('cms_page_id') + "/video.xml")) {
				alert("動画設定を完了させてください。");
				return false;
			}
		}
	}
	if ($('cms_context')) {
		var ckEditMode = CKEDITOR.instances.cms_context.mode;
		if (ckEditMode == "source") {
			alert('ソースモードの状態では保存を行うことはできません。\nソースモードを解除してから実行してください。');
			return false;
		}
	}
	
	// アクセシビリティチェック必須化
	// 編集完了ボタン押下であり、アクセシビリティチェック必須である場合、以下を処理
	if (st == STATUS_COMP && ENABLE_ACC_NEED_FLG == true) {
		// アクセシビリティチェック実行済フラグの確認
		var msg = ''
		if ((msg = cxAllTotalCheck()) != '') {
			// アラート表示
			alert('各種チェックで実行していない項目があります。' + "\n" + '下記のチェックを行ってください。' + "\n\n" + msg);
			return false;
		}
	}

	// 機種依存文字チェック
	var err = new Array();
	var info = new Array();

	if (cxPgSzChk(st, info) != true) {
		return false;
	}

	// 機種依存文字チェック
	var err = new Array();
	var info = new Array();

	if (cxPgSzChk(st, info) != true) {
		return false;
	}

	//見出し１用変数宣言
	var docHeader = document.getElementsByTagName('H1');
	var fckHeader = new Array();

	if ($('cms_page_title')) info = fckCheck('タイトル', $('cms_page_title').value, info);
	if ($('cms_header')) info = fckCheck('見出し', $('cms_header').value, info);
	if ($('cms_context')) {
		var oEditor = CKEDITOR.instances.cms_context;
		CKEDITOR.instances.cms_context.updateElement();
		var context = oEditor.getData();
		// Check accessibility
		var prm = 'cms_page_id=' + $('cms_page_id').value + '&cx_context=' + encodeURIComponent(context);
		var r = cxAjaxCommandAnSync('cxCheckAccessibility', prm, "").transport.responseText;
		// エラー文章表示(処理は中断しない)
		if (r != "") {
			info = info.concat(JSON.parse(r));
		}
		var chkContext = context;
		//終了タグが無い場合があるため、対象のタグをチェック
		var no_end_tag = ['LI'];
		for (var i = 0; i < no_end_tag.length; i++) {
			//対象タグが存在する場合
			if (context.match(no_end_tag[i])) {
				//対象タグのチェック
				var checkReg = RegExp('(<' + no_end_tag[i] + '[^>]*>)([\\s\\S]*?)(<\/?' + no_end_tag[i] + '[^>]*>)', 'i');
				while (chkContext.match(checkReg)) {
					//チェック用文字列から対象タグを削除する
					chkContext = chkContext.replace(checkReg, '$3');
					//置換用文字列を作成する
					var repTarget = RegExp.$1 + RegExp.$2 + RegExp.$3;
					var RepStr = RegExp.$1 + RegExp.$2;
					var chkTarget = RegExp.$3;
					//終了タグがあるかチェックする
					if (!chkTarget.match(RegExp('<\/' + no_end_tag[i] + '>', 'i'))) {
						//終了タグが無い場合は追加する
						context = context.replace(repTarget, RepStr + '</' + no_end_tag[i] + '>' + chkTarget);
					}
				}
			}
		}
		info = fckCheck('ページ本文', context, info);
		//見出し１を取得
		fckHeader = oEditor.document.getElementsByTag('H1');
	}
	if ($('cms_keywords')) info = fckCheck('検索エンジン用キーワード', $('cms_keywords').value, info);
	if ($('cms_description')) info = fckCheck('検索エンジン用説明文', $('cms_description').value, info);
	if ($('cms_summary')) info = fckCheck('要約文', $('cms_summary').value, info);
//	if ($('cms_index_title') ) info = fckCheck('リンク掲載用タイトル',$('cms_index_title').value.replace(/"/g,'&quot;'), info);
	if ($('cms_context')) {
		word = '<(img|area|input)( [^>]*)? src=\"(http:\/\/|https:\/\/)([^\"]*)\"[^>]*>';
		var regObj = new RegExp(word, "ig");
		ret = context.match(regObj)
		if (ret) {
			for (i = 0; i < ret.length; i++) {
				if (ret[i].match(/class="cke_anchor"/i)) {
					continue;
				}
				if (ret[i].match(/cms8341/i)) {
					continue;
				}
				info.push("インターネット上の画像を使用している箇所があります。\n正式公開後に表示されなくなる可能性があります。");
				break;
			}
		}
		//空リンクチェック
		//Aタグを取得
		var reg = /(<a(?:\s+[^>]*)?>)([\s\S]*?)(<\/a>)/mg;
		var check_context = CKEDITOR.instances['cms_context'].getData();
		var ret_ary;
		while ((ret_ary = reg.exec(check_context)) !== null) {
			// Aタグに「空hrefが存在するかチェックする」
			if(ret_ary[1].indexOf('href=""') >= 0 || ret_ary[1].indexOf("href=''") >= 0){
				alert("編集領域内にファイルが指定されていないリンクがあります。");
				return false;
			}
		}
		// imgタグを取得
		reg = /(<img[\s\S]*?>)/mg;
		while ((ret_ary = reg.exec(check_context)) !== null) {
			// imgタグに「空srcが存在するかチェックする」
			if(ret_ary[1].indexOf('src=""') >= 0 || ret_ary[1].indexOf("src=''") >= 0){
				alert("編集領域内にファイルが指定されていない画像があります。");
				return false;
			}
		}
	}

	//見出し１チェック
	if (typeof fckHeader.count == "function") {
		var h1_cnt = docHeader.length + fckHeader.count();
	} else {
		var h1_cnt = docHeader.length;
	}
	if (h1_cnt == 0) {
		info.push("見出し１が設定されていません。");
	} else if (h1_cnt > 1) {
		info.push("見出し１が複数設定されています。");
	} else {
		var getText = function (obj) {
			var keep = obj.innerHTML;
			var img = obj.getElementsByTagName('IMG');
			var alt;
			for (var i = 0; i < img.length; i++) {
				alt = img[i].alt;
				if (alt == "" || alt == "#" || alt == "＃") alt = '';
				keep = keep.replace(img[i].outerHTML, alt);
			}
			keep = keep.replace(/<\/?[^>]*>/g, '');
			return keep;
		};
		var h1Text = (docHeader.length == 1) ? getText(docHeader[0]) : getText(fckHeader.$[0]);
		var reObj = $('cms_page_title').value.replace(/\\|\^|\$|\*|\+|\?|\{|\}|\[|\]|\||\(|\)/gi, function ($0, $1) {
			return '\\' + $0;
		});
		h1Text = h1Text.replace(/&quot;|&amp;|&lt;|&gt;|&nbsp;/gi, function ($0) {
			switch ($0) {
				case "&quot;":
					return '"';
				case "&amp;":
					return '&';
				case "&lt;":
					return '<';
				case "&gt;":
					return '>';
				case "&nbsp;":
					return ' ';
			}
		});
		//var re = new RegExp("^"+$('cms_page_title').value+" ?$");
		if ($('cms_accessibility_check_13')) {
			var re = new RegExp("^" + reObj + " ?$");
			if (!h1Text.match(re)) info.push("見出し１がページタイトルと異なります。");
		}
	}

	var pt = $('cms_page_title').value;
	if (!pt || pt == '') {
		alert('タイトルが入力されていません。');
		$('cms_page_title').focus();
		return false;
	}
	if (($F('cms_template_kind') == TEMPLATE_KIND_FIXED) && ($F('cms_template_kanko_type') == KANKO_TYPE_EVENT)) {
		// イベントカレンダー複数日
		if (EVENT_CAL_MULTI_FLAG == true) {
			// 要素数の取得
			var element_no = document.getElementById('cms_pd_count').value;

			// 開始日に入力箇所がある件数を取得
			var input_count = 0;
			for (var i = 1; i <= element_no; i++) {
				// 入力欄削除により要素が無ければスキップ
				if (document.getElementById('cms_pd' + i + 'sy') == null) {
					continue;
				}
				if (document.getElementById('cms_pd' + i + 'sy').value != "" && document.getElementById('cms_pd' + i + 'sm').value != "" && document.getElementById('cms_pd' + i + 'sd').value != "") {
					++input_count;
				}
			}
			var no_check_flg = (input_count == 0) ? false : true;
			var pd_elem = new Array('sy', 'sm', 'sd', 'sh', 'si', 'ey', 'em', 'ed', 'eh', 'ei');
			var pd = new Array();

			// 要素ごとの日付をチェック
			for (var i = 1; i <= element_no; i++) {
				// 入力欄削除により要素が無ければスキップ
				if (document.getElementById('cms_pd' + i + 'sy') == null) {
					continue;
				}

				// 日時を配列に格納
				for (var key in pd_elem) {
					if (document.getElementById('cms_pd' + i + pd_elem[key]) == null) {
						continue;
					}
					pd[pd_elem[key]] = document.getElementById('cms_pd' + i + pd_elem[key]).value;
				}

				// 1行でも開始日が入力されている場合に開始日と終了日が空白の場合はスキップ
				if ((pd['sy'] == '' && pd['sm'] == '' && pd['sd'] == '' && pd['sh'] == '' && pd['si'] == '' && pd['ey'] == '' && pd['em'] == '' && pd['ed'] == '' && pd['eh'] == '' && pd['ei'] == '') && no_check_flg == true) {
					continue;
				}

				// チェック結果格納用配列
				var dc = new Array();
				var res_error = new Array();

				// 開始日チェック
				if (document.getElementById('cms_pd' + i + 'sy').value != "" || document.getElementById('cms_pd' + i + 'sm').value != "" || document.getElementById('cms_pd' + i + 'sd').value != "" || input_count == 0) {
					var err = cxDateCheckNew('cms_pd' + i, 'ymd', 2, '開催日');
					res_error.push(err.join('\n'));
				}

				// 終了日チェック
				if (document.getElementById('cms_pd' + i + 'ey').value != "" || document.getElementById('cms_pd' + i + 'em').value != "" || document.getElementById('cms_pd' + i + 'ed').value != "") {
					var err = cxDateCheckNew('cms_pd' + i, 'ymd', 1, '開催日');
					res_error.push(err.join('\n'));
				}

				// 開始時間チェック
				if (document.getElementById('cms_pd' + i + 'sh').value != "" || document.getElementById('cms_pd' + i + 'si').value != "") {
					var err = cxDateCheckNew('cms_pd' + i, 'hi', 2, '開催日');
					res_error.push(err.join('\n'));
				}

				// 終了時間チェック
				if (document.getElementById('cms_pd' + i + 'eh').value != "" || document.getElementById('cms_pd' + i + 'ei').value != "") {
					var err = cxDateCheckNew('cms_pd' + i, 'hi', 3, '開催日');
					res_error.push(err.join('\n'));
				}

				// エラーの重複を取り除く
				var error_msg = new Array();
				for (var j in res_error) {
					if (j.match(/[^0-9]/g)) continue;
					if (res_error[j] == '') continue;
					if (error_msg.indexOf(res_error[j]) != -1) continue;
					error_msg.push(res_error[j]);
				}
				if (error_msg.length > 0) {
					dc.push(error_msg.join('\n'));
				}

				// エラーメッセージ作成
				msg = new Array();
				msg = msg.concat(dc);
				if (msg.length > 0) {
					msg_str = msg.join('\n');
					alert(msg_str);
					$('cms_pd' + i + 'sy').focus();
					return false;
				}
			}
			var cal_input_area = document.getElementById('calendar_input_area');
			var event_set_limit = parseInt(document.getElementById('cms_pd_limit').value);
			var element_cnt = cal_input_area.getElementsByTagName('tr').length;

			// 設定上限を超えている場合はアラートを表示
			if (event_set_limit < element_cnt) {
				alert("開催期間を設定可能な件数を超えています。\n設定可能な開催期間は"+ event_set_limit +"件までです。");
				return false;
			}
		}
		// イベントカレンダー単一日
		else {
			if ($F('cms_pdey') == "" && $F('cms_pdem') == "" && $F('cms_pded') == "") {
				dc = cxDateCheckNew('cms_pd', 'ymd', 2, '開催日');
			} else {
				dc = cxDateCheckNew('cms_pd', 'ymd', 1, '開催日');
			}
			msg = new Array();
			msg = msg.concat(dc);
			if (msg.length > 0) {
				msg_str = msg.join('\n');
				alert(msg_str);
				$('cms_pdsy').focus();
				return false;
			}
		}
	}

	// メール送信先(アンケート・問い合わせ)
	if ($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE && $F("cms_from_type") == ENQ_KIND_MAIL && $("cms_enquete_emai_list")) {
		if (cmEnqEmailStringCreate() == 0) {
			alert('アンケート種別が問い合わせの場合はメールアドレスを選択してください。');
			return false;
		}
	}

	if ($F('cms_usr_class') == USER_CLASS_WEBMASTER && $F('cms_status') != STATUS_APPROVE_LAST) {
		if ($('cms-pubend-Unrestricted-edit') && $('cms-pubend-Unrestricted-edit').checked) {
			cxPublicEndUnrestricted();
			$('cms_pubey').value = PUB_INDEFINITE_YAER;
			$('cms_pubem').value = PUB_INDEFINITE_MONTH;
			$('cms_pubed').value = PUB_INDEFINITE_DAY;
			$('cms_pubeh').value = PUB_INDEFINITE_HOUR;
		}
		dc = cxDateCheckNew('cms_pub', 'ymdh', 1, '公開日');
		msg = new Array();
		msg = msg.concat(dc);
		if (msg.length > 0) {
			msg_str = msg.join('\n');
			alert(msg_str);
			$('cms_pubsy').focus();
			return false;
		}
	}

	if ($('cms_inquiry_tr') && (!$('cms_inquiry_tr').style || $('cms_inquiry_tr').style.display != "none")) {
		info = cxInquiryCheck('cms_inquiry_prop', info);
	}
	if (!info) return false;

	//GoogleMAP(地図情報)の入力が不正(&ll～がない)ならエラー
	allInput = document.getElementsByTagName("input");
	var regObjCMS = new RegExp('^cms_map_');
	var regObjMAP = new RegExp('&ll=\-?([0-9]+)(\.[0-9]+)?,\-?([0-9]+)(\.[0-9]+)?(&.*)?$');
	for (i = 0; i < allInput.length; i++) {
		if (allInput[i].id && allInput[i].id.match(regObjCMS) && $(allInput[i].id).value && $(allInput[i].id).value != "") {
			// 地図情報に指定された値を整形
			var map_input_value = trim($(allInput[i].id).value);
			map_input_value = map_input_value.replace(/ /g, '');

			// 入力値をチェックし、「&ll=～」の形式でない場合は入力値の先頭に「&ll=」を付与する
			if (!map_input_value.match(regObjMAP)) {
				map_input_value = '&ll=' + map_input_value;
			}

			if (!map_input_value.match(regObjMAP) || parseInt(RegExp.$1, 10) > 90 || parseInt(RegExp.$3, 10) > 180) {
				alert('地図URLの入力に誤りがあります。');
				$(allInput[i].id).focus();
				return false;
			}
			// 入力値に代入する
			document.getElementById(allInput[i].id).value = map_input_value;
		}
	}

	if (info.length > 0) {
		var msg = info.join('\n\n');
		if (st == 201) {
			msg = msg + '\n\n一時保存してよろしいですか？';
		} else {
			msg = msg + '\n\nよろしいですか？';
		}
		if (!confirm(msg)) {
			return false;
		}
	}

	if ($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE) {
		if ($F('cms_work_class') == 1 || $F("cms_from_type") == ENQ_KIND_MAIL) {
			EnqItemCreateForm();
		}
	}

	//
	var current_dir = $F('cms_dir_path');
	var n;
	// ファイル名を除外
	if ((n = current_dir.lastIndexOf("/")) != -1) current_dir = current_dir.substr(0, n);
	if (current_dir == '') current_dir = '/';
	if (current_dir.charAt(current_dir.length - 1) != '/') current_dir += '/';

	// アップロードした依存ファイルが削除可能かどうか調べる(一時保存以外)
	if (st != 201) {
		// チェック
		if (cxDependFileDeleteCheck(context, current_dir, callbackAfterCxDependFileDeleteCheck) == false) {
			return false;
		}
	}
	else {
		callbackAfterCxDependFileDeleteCheck();
	}
	
	function callbackAfterCxDependFileDeleteCheck() {
		// 使用されなくなる依存ファイルをチェック
		if (cxPublishDependFileDeleteCheck(context, current_dir, callbackAfterCxPublishDependFileDeleteCheck) == false) {
			return false;
		}
	}
	
	function callbackAfterCxPublishDependFileDeleteCheck() {
		edit_closet_flg = false;
		cxComboHidden();

		// オープンデータ
		// オープンデータ 編集領域内に設定されたオープンデータファイルリンクの情報をPOSTにセット
		if ($('cms_context') ) {
			setContextOpenDataFilesPost();
		}

		// ページ出力チェックボックスが存在しなかった場合エレメント追加
		if (!$('cms_output_html_flg')) {
			// 「imput」作成
			var inps = new Object;
			inps[0] = document.createElement('input');
			inps[0].setAttribute("type", "hidden");
			inps[0].setAttribute("name", "cms_output_html_flg");
			inps[0].setAttribute("value", 1);
			for (var i in inps) {
				document.cms_fEdit.appendChild(inps[i]);
			}
		}

		$('cms8341-progressmsg').innerHTML = '保存中．．．';
		cxLayer('cms8341-progress', 1, 500, 500);
		document.cms_fEdit.action = cms8341admin_path + '/page/siteview/pageedit.php';
		document.cms_fEdit.target = '';
		document.cms_fEdit.cms_status.value = st;
		document.cms_fEdit.submit();
	}
	
	return false;
}

function cxEditCancel(mode, bak) {
	if (!confirm("一時保存または編集完了をしていない場合、現在の状態が保存されません。\nよろしいですか？")) {
		return false;
	}
	var current_dir = $F('cms_p_file_path');
	var n;
	// ファイル名を除外
	if ((n = current_dir.lastIndexOf("/")) != -1) current_dir = current_dir.substr(0, n);
	if (current_dir == '') current_dir = '/';
	if (current_dir.charAt(current_dir.length - 1) != '/') current_dir += '/';
	// チェック
	if (cxDependFileDeleteCheck(undefined, undefined, callbackAfterCxDependFileDeleteCheck) == false) {
		return false;
	}
	
	function callbackAfterCxDependFileDeleteCheck() {
		// 不要ファイル削除で「はい」を選択した場合
		if ($F('cms_unuse_delete') == FLAG_ON) {
			// 削除実行
			var r = cxAjaxCommandAnSync('cxFilesDelete', "", "").transport.responseText;
			// エラー文章表示(処理は中断しない)
			if (r != "") {
				alert(r);
			}
		}
		edit_closet_flg = false;
		cxComboHidden();
		$('cms8341-progressmsg').innerHTML = '処理中．．．';
		cxLayer('cms8341-progress', 1, 500, 500);
		if (mode == 1) {
			document.cms_fEdit.action = cms8341admin_path + '/page/common/editcancel.php';
			if ($('cms_dispMode')) $('cms_dispMode').value = 'edit_close';
			document.cms_fEdit.target = '';
			document.cms_fEdit.submit();
		} else {
			var prm = 'page_id=' + $('cms_page_id').value;
			cxAjaxCommand('cxEditCancel', prm, null);
			if (mode == 2) location.href = bak;
			if (mode == 3) history.back();
		}
	}
	return false;
}

//通信失敗処理
function cxFailure() {
	$('cms8341-errormsg').innerHTML = '<p align="center">情報取得中に通信エラーが発生しました</p>';
	cxLayer('cms8341-error', 1, 500, 375);
}

/** 2006/08/31 *******************************************************************************************************/
//** cms8341-library（ライブラリ）レイヤー **/
var cmsLibraryArea = null;

function cxLibraryOpen(area) {
	edit_closet_flg = false;
	cmsLibraryArea = area;

	//close
	if ($('cms8341-property').style.display == 'block') cxPropertyClose();
	if ($('cms8341-reffer').style.display == 'block') cxLayer('cms8341-reffer', 0);
	if ($('cms8341-category').style.display == 'block') cxLayer('cms8341-category', 0);
	if ($('cms8341-template-select')) cxLayer('cms8341-template-select', 0);

	var prm = 'area=1&template_id=' + $F('cms_template_id') + '&lib_area_name=' + area;		//ライブラリのテンプレート領域コード（1）を渡す　※(2)は編集領域(3)はライブラリエリア名
	cxAjaxCommand('cxGetLibraryCombo', prm, cxLibraryOpenOK);
}

function cxLibraryOpenOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	var select_flg = false;
	if (!xmlDoc || xmlDoc.nodeName != 'Libraries') {
		cxFailure();
		return;
	}
	if (xmlDoc.attributes.getNamedItem('area_name').value != '') {
		$('cms-library-area').innerHTML = xmlDoc.attributes.getNamedItem('area_name').value;
	} else {
		$('cms-library-area').innerHTML = cmsLibraryArea;
	}
	var cmb = $('cms-library-combo');
	while (cmb.length > 1) {
		cmb.options[1] = null;
	}
	var xmlDocfix = xmlDoc.childElementCount;
	for (var i=0; i<xmlDocfix; i++) {
		nodeL = xmlDoc.firstElementChild;
		cmb.length++;
		cmb.options[i+1].text = nodeL.textContent;
		var val = nodeL.attributes.getNamedItem('value').value;
		cmb.options[i+1].value = val;
		xmlDoc.removeChild(xmlDoc.firstElementChild);
		if (val == document.getElementsByName('cms_library[' + cmsLibraryArea + ']')[0].value) {
			cmb.options[i + 1].selected = true;
			select_flg = true;
		}
	}
	if (select_flg == false) {
		$('cms-library-combo').options.selectedIndex = false;
	}
	cxComboHidden(new Array("cms-library-combo"));
	$("cms-library-combo").style.visibility = 'visible';
	cxLayer('cms8341-library', 1, 740, 370);

	cxSelectLibrary();

}

function cxLibraryClose() {
	edit_closet_flg = false;
	cmsLibraryArea = null;
	cxComboVisible();
	cxLayer('cms8341-library', 0);
}

function cxLibrarySubmit() {
	edit_closet_flg = false;
	var prm = 'library_id=' + $('cms-library-combo').value + '&e_flg=1&l_flg=1';
	cxComboVisible();
	cxAjaxCommand('cxGetLibraryContext', prm, cxLibrarySubmitOK);
}

function cxLibrarySubmitOK(r) {
	var rText = r.responseText;
	$('cms_library[' + cmsLibraryArea + ']').value = $('cms-library-combo').value;
	$('cms8341-library-' + cmsLibraryArea).innerHTML = rText;
	cxLibraryClose();
}

// カテゴリ設定
var cmsCateObj = new Object();

function cxCategorySet() {
	cmsCateObj.cate1 = getComboValues($('cms_cate1'));
	cmsCateObj.cate2 = getComboValues($('cms_cate2'));
	cmsCateObj.cate3 = getComboValues($('cms_cate3'));
	cmsCateObj.cate4 = getComboValues($('cms_cate4'));
	edit_closet_flg = false;
	//open
	cxComboHidden(new Array("cms_cate1", "cms_cate2", "cms_cate3", "cms_cate4"));
	if ($("cms_cate1").nodeName == "SELECT") {
		$("cms_cate1").style.visibility = 'visible';
	}
	if ($("cms_cate2").nodeName == "SELECT") {
		$("cms_cate2").style.visibility = 'visible';
	}
	if ($("cms_cate3").nodeName == "SELECT") {
		$("cms_cate3").style.visibility = 'visible';
	}
	if ($("cms_cate4").nodeName == "SELECT") {
		$("cms_cate4").style.visibility = 'visible';
	}
	if ($("cms_cate1_disabled")) {
		$("cms_cate1_disabled").style.visibility = 'visible';
	}
	if ($("cms_cate2_disabled")) {
		$("cms_cate2_disabled").style.visibility = 'visible';
	}
	if ($("cms_cate3_disabled")) {
		$("cms_cate3_disabled").style.visibility = 'visible';
	}
	if ($("cms_cate4_disabled")) {
		$("cms_cate4_disabled").style.visibility = 'visible';
	}
	cxLayer('cms8341-category', 1, 350, 250);
}

function cxCategoryClose() {
	setComboValues('cms_cate1', cmsCateObj.cate1);
	setComboValues('cms_cate2', cmsCateObj.cate2);
	setComboValues('cms_cate3', cmsCateObj.cate3);
	setComboValues('cms_cate4', cmsCateObj.cate4);
	//close
	cxLayer('cms8341-category', 0);
	edit_closet_flg = false;
	cxComboVisible("cms8341-property");
}

var catePros = false;

function cxChangeCate(level, code) {
	var kind = $F('cms_template_kind')
	if (catePros) return;
	move_level = level;
	catePros = true;
	var prm = 'level=' + level + '&code=' + code;
	cxAjaxCommand('cxGetCateCombo', prm, cxGetCateComboOK);
	if (move_level == 5) {
		nextId = 'cms_cate_submit';
	} else {
		nextId = 'cms_cate' + move_level;
	}
	$(nextId).focus();
}

function cxGetCateComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Categories') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for (var i = level; i <= 4; i++) {
		var cmb = $('cms_cate' + i);
		while (cmb.length > 1) {
			cmb.options[1] = null;
		}
	}
	var cmb = $('cms_cate' + level);
	var xmlDocfix = xmlDoc.childElementCount;
	for (var i=0; i<xmlDocfix; i++) {
		nodeL = xmlDoc.firstElementChild;
		cmb.length++;
		cmb.options[i+1].text = nodeL.textContent;
		var val = nodeL.attributes.getNamedItem('value').value;
		cmb.options[i+1].value = val;
		xmlDoc.removeChild(xmlDoc.firstElementChild);
	}
	catePros = false;
}

function cxCategorySubmit() {
	if (!$('cms_cate1').value) {
		alert('分類が選択されていません。');
		$('cms_cate1').focus();
		return false;
	}
	var cname = new Array();
	var ccode = '';
	for (var i = 1; i <= 4; i++) {
		var cmb = $('cms_cate' + i);
		if (cmb.nodeName == "SELECT") {
			var idx = cmb.selectedIndex;
			if (idx > 0 || cmb.options[idx].value) {
				cname.push(cmb.options[idx].text);
				ccode = cmb.options[idx].value;
			}
		}
		else {
			cname.push($('cms_cate' + i + '_name').value);
			ccode = cmb.value;
		}
	}
	var cate_name = '';
	if (cname.length > 0) cate_name = cname.join(' &gt; ');
	$('cms-cate-name').innerHTML = cate_name;
	//close
	cxLayer('cms8341-category', 0);
	edit_closet_flg = false;
	cxComboVisible("cms8341-property");
}

function getCheckedValue(id) {
	var ret = '';
	var cmb = $(id);
	for (var i = 1; i <= cmb.length; i++) {
		if (cmb.options[i].checked) {
			ret = cmb.options[i].value;
		}
	}
	return ret;
}

function getCheckValue2(f_name, type, id) {
	var tmp = "";
	var elements = Form.getInputs(f_name, type, id);
	elements.each(
		function (el, idx) {
//	 	if(el.checked)tmp += ","+idx;
			if (el.checked) tmp += "," + el.value;
		}
	);
	return tmp.slice(1);
}

function getComboValues(cmb) {
	var obj = new Array();
	for (var i = 0; i < cmb.length; i++) {
		var opt = new Object();
		opt.text = cmb.options[i].text;
		opt.value = cmb.options[i].value;
		opt.id = cmb.options[i].id;
		opt.selected = cmb.options[i].selected;
		obj.push(opt);
	}
	return obj;
}

function setComboValues(id, obj) {
	var cmb = $(id);
	while (cmb.length > 0) {
		cmb.options[0] = null;
	}
	for (var i = 0; i < obj.length; i++) {
		cmb.length++;
		cmb.options[i].text = obj[i].text;
		cmb.options[i].value = obj[i].value;
		cmb.options[i].id = obj[i].id;
		cmb.options[i].selected = obj[i].selected;
	}
}

// 問い合わせ
function cxChangeInq() {
	if ($('cms_inquiry_flg').checked) {
		$('cms8341-inquiry-set').style.display = 'block';
	} else {
		$('cms8341-inquiry-set').style.display = 'none';
	}
}

// パンくず（親ページ）の変更
function cxOpenPanset() {
	var pid = $('cms_parent_id').value;
	if (pid == '') pid = $('cms_page_id').value;
	var uri = cms8341admin_path + '/page/common/pankuzu_set.php?pid=' + pid + '&edit_pid=' + $('cms_page_id').value;
	cxIframeLayer(uri, 830, 660, COVER_SETTING.COLOR, 'panset');
	return false;
}

function cxPankuzuSet(pid) {
	$('cms_parent_id').value = pid;
	var prm = 'page_id=' + pid;
	cxAjaxCommand('cxGetPankuzu', prm, cxPankuzuSetSubmit);
}

function cxPankuzuSetSubmit(r) {
	var rText = r.responseText;
	cmsPanAncestor = rText.replace(/<(a|area)( [^>]*)?>/ig, '<$1 href="#">');
	if ($('cms-prop-pankuzu')) $('cms-prop-pankuzu').innerHTML = rText.replace(/<\/?(a|area)( [^>]*)?>/ig, '');
}


//親ページを削除する
function cxParentDel() {
	//ダイアログで確認
	if (!confirm("現在設定されている親ページ情報を削除します。\n本当によろしいですか？")) return false;
	//親ページのvalueを消す
	$('cms_parent_id').value = "";
	//パンくず表示を消す
	$('cms-prop-pankuzu').innerHTML = "";
	cmsPanAncestor = "";
	return false;
}

//HTMLソースのクリーンアップ
function cxHtmlCleanup() {
	if (!confirm("一時保存または編集完了をしていない場合、書式処理を行うと元に戻すことができません。\nよろしいですか？")) {
		return false;
	}

	if ($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE) {
		if ($F('cms_work_class') == 1 || $F("cms_from_type") == ENQ_KIND_MAIL) {
			EnqItemCreateForm();
		}
	}
	if ($F('cms_template_kind') == TEMPLATE_KIND_FIXED || ($('kanko_xml') && $F('kanko_xml') != "")) {
		kankoCustomItemCreate();
	}
	edit_closet_flg = false;
	$('cms8341-progressmsg').innerHTML = 'HTMLソースのクリーンアップ処理中．．．';
	cxLayer('cms8341-progress', 1, 500, 500);
	document.cms_fEdit.action = cms8341admin_path + '/page/common/htmlcleanup.php';
	document.cms_fEdit.target = '';
	document.cms_fEdit.cms_dispMode.value = '';
	document.cms_fEdit.submit();
	return false;
}

/**
 * HTMLソースにファイル情報の付加
 * @retrun false
 */
function cxHtmlAddFileDetail() {
	if (!confirm("一時保存または編集完了をしていない場合、元に戻すことはできません。\nよろしいですか？")) return false;
	if ($F('cms_template_kind') == TEMPLATE_KIND_FIXED || ($('kanko_xml') && $F('kanko_xml') != "")) {
		kankoCustomItemCreate();
	}
	edit_closet_flg = false;
	$('cms8341-progressmsg').innerHTML = 'HTMLソースへ添付ファイル表記の挿入処理中．．．';
	cxLayer('cms8341-progress', 1, 500, 500);
	document.cms_fEdit.action = cms8341admin_path + '/page/common/htmladdfiledetail.php';
	document.cms_fEdit.target = '';
	document.cms_fEdit.cms_dispMode.value = '';
	document.cms_fEdit.submit();
	return false;
}

/**
 * HTMLソースの外部リンク・画像をダウンロードし、HTMLソースのパス修正
 * @retrun false
 */
function cxOuterFileDownload() {
	// 確認ダイアログ
	if (!confirm("編集領域に指定した外部ファイル・画像をCMSにダウンロードします。\n一時保存または編集完了をしていない場合、元に戻すことはできません。\nよろしいですか？")) return false;

	if ($F('cms_template_kind') == TEMPLATE_KIND_FIXED || ($('kanko_xml') && $F('kanko_xml') != "")) {
		kankoCustomItemCreate();
	}
	// 編集領域
	var context = "";
	if ($('cms_context')) {
		var oEditor = CKEDITOR.instances.cms_context;
		context = oEditor.getData();
	}
	//
	if ($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE) {
		if ($F('cms_work_class') == 1 || $F("cms_from_type") == ENQ_KIND_MAIL) {
			EnqItemCreateForm();
		}
	}
	// 処理中レイヤー
	$('cms8341-progressmsg').innerHTML = '外部ファイルのダウンロード処理中．．．';
	cxLayer('cms8341-progress', 1, 500, 500);

	// Ajax でダウンロード処理

	// パラメーターの作成
	var params = "";
	params = 'cms_page_id=' + $F('cms_page_id');
	params += '&cms_template_kind=' + $F('cms_template_kind');
	params += '&cms_context=' + encodeURIComponent(context).replace(/&/g, "%26");

	// Ajax でPHPに接続
	var ajax = new Ajax.Request(
		cms8341admin_path + '/page/common/outerfiledownload/download_exec.php',
		{
			method: 'post',
			asynchronous: true,
			parameters: params,
			onSuccess: function () {

				cxLayer('cms8341-progress', 0);

				// PHP からの戻り値(print)を取得
				var r = ajax.transport.responseText;
				// 固定の戻り値以外は予期せぬエラー
				if (r != "true") {
					alert("ダウンロード処理中に予期せぬエラーが発生しました。");
					return false;
				}

				// 結果ダイアログの表示
				cxIframeLayer(
					cms8341admin_path + '/page/common/outerfiledownload/result_dialog.php?cms_page_id=' + $F('cms_page_id'),
					800,
					490,
					COVER_SETTING.COLOR,
					'',
					function (retObj) {


						// ダウンロードしたファイルがある場合
						if (retObj['success_count'] && retObj['success_count'] > 0) {
							// 処理中レイヤー
							$('cms8341-progressmsg').innerHTML = 'HTMLソースのファイルリンク・画像パス修正中．．．';
							cxLayer('cms8341-progress', 1, 500, 500);

							if ($('cms_context')) {
								CKEDITOR.instances['cms_context'].setData(context);
							}

							//
							edit_closet_flg = false;
							// 処理
							document.cms_fEdit.action = cms8341admin_path + '/page/common/outerfiledownload/replace_context.php';
							document.cms_fEdit.target = '';
							document.cms_fEdit.cms_dispMode.value = '';
							document.cms_fEdit.submit();
						}
					}
				);
			},
			onFailure: function () {
				cxLayer('cms8341-progress', 0);
				alert("ダウンロード処理中に予期せぬエラーが発生しました。");
				return false;
			}
		}
	);
	//
	return false;
}

/**
 * HTMLソースのファイルパスの変換処理
 * @retrun false
 */
function cxFilePathConversion() {
	// 確認ダイアログ
	if (!confirm("一時保存または編集完了をしていない場合、元に戻すことはできません。\nよろしいですか？")) return false;
	if ($F('cms_template_kind') == TEMPLATE_KIND_FIXED || ($('kanko_xml') && $F('kanko_xml') != "")) {
		kankoCustomItemCreate();
	}
	edit_closet_flg = false;
	$('cms8341-progressmsg').innerHTML = 'ファイルパスの変換処理中．．．';
	cxLayer('cms8341-progress', 1, 500, 500);
	document.cms_fEdit.action = cms8341admin_path + '/page/common/filepathconversion.php';
	document.cms_fEdit.target = '';
	document.cms_fEdit.cms_dispMode.value = '';
	document.cms_fEdit.submit();
	return false;
}

// 組織変更プルダウン処理
var inquiryNum;

function cxChangeDept(lv, val, num) {
	inquiryNum = num;
	//reset
	if (val == "") {
		var t = lv + 1;
		for (var i = t; i <= 3; i++) {
			var obj = $('cms_inquiry_prop_dept' + i + '_' + inquiryNum);
			while (obj.length > 1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "";
		}
	} else {
		//get data
		lv++;
		var prm = 'level=' + lv + '&code=' + val;
		cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
	}
}

function cxGetDeptComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Department') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for (var i = level; i <= 3; i++) {
		var obj = $('cms_inquiry_prop_dept' + i + '_' + inquiryNum);
		while (obj.length > 1) {
			obj.options[1] = null;
		}
		if (i == level) {
			obj.options[0].text = "指定なし";
		} else {
			obj.options[0].text = "";
		}
	}
	var obj = $('cms_inquiry_prop_dept' + level + '_' + inquiryNum);
	var xmlDocfix = xmlDoc.childElementCount;
	for (var i=0; i<xmlDocfix; i++) {
		nodeL = xmlDoc.firstElementChild;
		obj.length++;
		obj.options[i+1].text = nodeL.textContent;
		var val = nodeL.attributes.getNamedItem('value').value;
		obj.options[i+1].value = val;
		xmlDoc.removeChild(xmlDoc.firstElementChild);
	}
}

// 問合せ先追加
function cxAddInquiry() {
	$('cms_inquiry_cnt').value = Number($('cms_inquiry_cnt').value) + 1;
	var no = $F('cms_inquiry_cnt');
	var inquiryStr = '<div id="cms_inquiry_' + no + '" _num="' + no + '"><table width="100%" border="0" class="cms8341-noneBorder"><tr><td><span style="font-weight:bold;font-size=15px" id="cms_inquiry_prop_no_' + no + '">問い合せ先' + no + '</span></td><td align="right"><span id="cms_inquiry_delete_td_' + no + '"><a href="javascript:" onClick="return cxInquiryDel(' + no + ')"><img src="' + cms8341admin_path + '/images/btn/btn_del_mini.gif" alt="削除する" width="60" height="20" border="0" style="border:0px;"></a></span></td></tr></table>';
	inquiryStr = inquiryStr + '<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable">';
	if ($('cms_inquiry_style_dept_dummy')) {
		inquiryStr = inquiryStr + '<tr><th style="width:140px;" id="cms_inquiry_dept_th" align="left">' + $('cms_inquiry_dept_th').innerHTML + '</th><td id="cms_inquiry_dept_td_' + no + '">';
		inquiryStr = inquiryStr + '<select name="cms_inquiry_prop_dept1_' + no + '" id="cms_inquiry_prop_dept1_' + no + '" onChange="javascript:cxChangeDept(1, this.value, ' + no + ')" style="width:120px;">' + $('cms_inquiry_prop_dept_def_sel').innerHTML + '</select>&nbsp;&nbsp;&nbsp;';
		inquiryStr = inquiryStr + '<select name="cms_inquiry_prop_dept2_' + no + '" id="cms_inquiry_prop_dept2_' + no + '" onChange="javascript:cxChangeDept(2, this.value, ' + no + ')" style="width:120px;"><option value=""></option></select>&nbsp;&nbsp;&nbsp;';
		inquiryStr = inquiryStr + '<select name="cms_inquiry_prop_dept3_' + no + '" id="cms_inquiry_prop_dept3_' + no + '" onChange="javascript:cxChangeDept(3, this.value, ' + no + ')" style="width:120px;"><option value=""></option></select>&nbsp;&nbsp;&nbsp;';
		inquiryStr = inquiryStr + '<div id="cms_inquiry_prop_dept_def" style="display:none">' + $('cms_inquiry_prop_dept_def').innerHTML + '</div></td></tr>';
	}
	if ($('cms_inquiry_style_charge_dummy')) {
		inquiryStr = inquiryStr + '<tr><th style="width:140px;" id="cms_inquiry_charge_th" align="left">' + $('cms_inquiry_charge_th').innerHTML + '</th><td style="font-size:10px;"><input type="text" name="cms_inquiry_prop_charge_' + no + '" id="cms_inquiry_prop_charge_' + no + '" style="width:240px;"></td></tr>';
	}
	if ($('cms_inquiry_style_tel2_dummy')) {
		inquiryStr = inquiryStr + '<tr><th style="width:140px;" id="cms_inquiry_anExtensionNumber_th" align="left">' + $('cms_inquiry_anExtensionNumber_th').innerHTML + '</th><td><input type="text" name="cms_inquiry_prop_anExtensionNumber_' + no + '" id="cms_inquiry_prop_anExtensionNumber_' + no + '" class="cms8341-verticalMiddle"></td></tr>';
	}
	if ($('cms_inquiry_style_tel1_dummy')) {
		inquiryStr = inquiryStr + '<tr><th style="width:140px;" id="cms_inquiry_directNumber_th" align="left">' + $('cms_inquiry_directNumber_th').innerHTML + '</th><td><input type="text" name="cms_inquiry_prop_directNumber_' + no + '" id="cms_inquiry_prop_directNumber_' + no + '"> (例： 03-3502-0000)&nbsp;<a href="javascript:" onClick="cxGetInquiryDeptInfo(' + no + ',\'tel\')"><img src="' + cms8341admin_path + '/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得" border="0" width="100" height="20" class="cms8341-verticalMiddle"></a></td></tr>';
	}
	if ($('cms_inquiry_style_fax_dummy')) {
		inquiryStr = inquiryStr + '<tr><th style="width:140px;" id="cms_inquiry_fax_th" align="left">' + $('cms_inquiry_fax_th').innerHTML + '</th><td><input type="text" name="cms_inquiry_prop_fax_' + no + '" id="cms_inquiry_prop_fax_' + no + '"> (例： 03-3502-0000)&nbsp;<a href="javascript:" onClick="cxGetInquiryDeptInfo(' + no + ',\'fax\')"><img src="' + cms8341admin_path + '/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得" border="0" width="100" height="20" class="cms8341-verticalMiddle"></a></td></tr>';
	}
	if ($('cms_inquiry_style_email_dummy')) {
		inquiryStr = inquiryStr + '<tr><th style="width:140px;" id="cms_inquiry_email_th" align="left">' + $('cms_inquiry_email_th').innerHTML + '</th><td><input type="text" name="cms_inquiry_prop_email_' + no + '" id="cms_inquiry_prop_email_' + no + '" style="ime-mode:disabled;">&nbsp;<a href="javascript:" onClick="cxGetInquiryDeptInfo(' + no + ',\'email\')"><img src="' + cms8341admin_path + '/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得" border="0" width="100" height="20" class="cms8341-verticalMiddle"></a></td></tr>';
	}
	inquiryStr = inquiryStr + '</table><br></div>';
	new Insertion.Before('cms_inquiry_add', inquiryStr);
	inquiry_no = 1;
	for (i = 1; i < Number($F('cms_inquiry_cnt')) + 1; i++) {
		if (!$('cms_inquiry_' + i)) continue;
		$('cms_inquiry_prop_no_' + i).innerHTML = '問い合わせ先' + inquiry_no;
		$('cms_inquiry_' + i)._num = inquiry_no;
		inquiry_no++;
	}
	edit_closet_flg = false;
}

// 問合せ先反映
function cxUpdateInquiry(cnt) {
	searchStr = '<span id="cms_inquiry_detail_' + cnt + '">';
	searchStr = searchStr + $('cms_inquiry_detail_dummy').innerHTML;
	if ($('cms_inquiry_style_dept_dummy')) {
		// 所属
		searchStr = searchStr.replace('cms_inquiry_dept_name_dummy', 'cms_inquiry_dept_name_' + cnt);
		searchStr = searchStr.replace('cms_inquiry_name1_dummy', 'cms_inquiry_name1_' + cnt);
		searchStr = searchStr.replace('cms_inquiry_name2_dummy', 'cms_inquiry_name2_' + cnt);
		searchStr = searchStr.replace('cms_inquiry_name3_dummy', 'cms_inquiry_name3_' + cnt);
		searchStr = searchStr.replace('cms_inquiry_style_dept_dummy', 'cms_inquiry_style_dept_' + cnt);
	}
	// 担当者
	if ($('cms_inquiry_style_charge_dummy')) {
		searchStr = searchStr.replace('cms_inquiry_charge_dummy', 'cms_inquiry_charge_' + cnt);
		searchStr = searchStr.replace('cms_inquiry_style_charge_dummy', 'cms_inquiry_style_charge_' + cnt);
	}
	// 内線
	if ($('cms_inquiry_style_tel2_dummy')) {
		searchStr = searchStr.replace('cms_inquiry_tel2_dummy', 'cms_inquiry_tel2_' + cnt);
		searchStr = searchStr.replace('cms_inquiry_style_tel2_dummy', 'cms_inquiry_style_tel2_' + cnt);
	}
	// ダイヤルイン
	if ($('cms_inquiry_style_tel1_dummy')) {
		searchStr = searchStr.replace('cms_inquiry_tel1_dummy', 'cms_inquiry_tel1_' + cnt);
		searchStr = searchStr.replace('cms_inquiry_style_tel1_dummy', 'cms_inquiry_style_tel1_' + cnt);
	}
	// FAX
	if ($('cms_inquiry_style_fax_dummy')) {
		searchStr = searchStr.replace('cms_inquiry_fax_dummy', 'cms_inquiry_fax_' + cnt);
		searchStr = searchStr.replace('cms_inquiry_style_fax_dummy', 'cms_inquiry_style_fax_' + cnt);
	}
	// Email
	if ($('cms_inquiry_style_email_dummy')) {
		searchStr = searchStr.replace('cms_inquiry_email_dummy', 'cms_inquiry_email_' + cnt);
		searchStr = searchStr.replace('cms_inquiry_style_email_dummy', 'cms_inquiry_style_email_' + cnt);
	}
	searchStr = searchStr + '</span>';
	new Insertion.Before('cms_inquiry_detail_end', searchStr);
}

function cxInquiryDel(no) {
	var delete_number = $('cms_inquiry_' + no)._num;
	if (!confirm("問合せ先" + delete_number + "を削除します。\nよろしいですか？")) {
		return false;
	}
	edit_closet_flg = false;
	Element.remove($('cms_inquiry_' + no));
}

function cxFileSubmit(event) {
	var item = Event.element(event);
	if ($('cms_file_submit') && item.id == "cms_new_file" && event.keyCode == 13) {
		cxRefferSubmit();
	}
}

function cxInit() {
	Event.observe(document, 'keypress', cxFileSubmit, false);
	if ($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE) {
		if ($F('cms_work_class') == 1 || $F("cms_from_type") == ENQ_KIND_MAIL) {
			cms8341_EnqClass = new EnqueteSet();
			Sortable.create('cms8341_EnqueteItems', {tag: 'div'});
		}
	}
	// オープンデータ
	// オープンデータ 可変登録
	if ($('cms8341_OpenDataItems') !== undefined) {
		cms8341_OpenDataClass = new OpenDataSet();
		Sortable.create('cms8341_OpenDataItems',{tag:'div'});
	}
	var prm = 'tpl_id=' + $F('cms_template_id');
	cxAjaxCommand('cxGetInquryDisp', prm, cxGetInquryDispOK);
	// 問い合わせ／メール送信先アドレス設定用ボタン
	if ($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE && $F("cms_from_type") == ENQ_KIND_MAIL && $('cms_enquete_mail_add')) {
		Event.observe($('cms_enquete_mail_add'), 'click', cxOpenMailForm, false);
	}
}

Event.observe(window, 'load', cxInit, false);

function cxGetInquryDispOK(r) {
	allShowFlg = false;
	inquiryShowFlg = false;
	var rText = r.responseText;
	inquiryItem = rText.split(",");
	for (i = 0; i < inquiryItem.length; i++) {
		inquiryDtl = inquiryItem[i].split(":");
		if (inquiryDtl[0] != "memo") {
			allItem = document;
			for (j = 0; j < allItem.getElementsByTagName("tr").length; j++) {
				id = allItem.getElementsByTagName("tr")[j].getAttribute("ID");
				if (id == null) continue;
				if (id.indexOf("cms_inquiry_" + inquiryDtl[0] + "_") == 0) {
					if (inquiryDtl[1] == "show") {
						Element.show(id);
						allShowFlg = true;
						inquiryShowFlg = true;
					} else {
						Element.hide(id);
					}
				}
			}
		} else {
			if (inquiryDtl[1] == "show") {
				allShowFlg = true;
				Element.show("cms_inquiry_memo_table");
			} else {
				Element.hide("cms_inquiry_memo_table");
			}
		}
	}
	if (!allShowFlg) {
		Element.hide("cms_inquiry_tr");
	} else {
		Element.show("cms_inquiry_tr");
	}
	if (!inquiryShowFlg) {
		Element.hide("cms_inquiry_table");
		Element.hide("cms_inquiry_add");
		Element.hide("cms_inquiry_1");

	} else {
		Element.show("cms_inquiry_table");
		Element.show("cms_inquiry_add");
		Element.show("cms_inquiry_1");
	}

}

//テンプレート選択処理
function cxSelectTemplate(v) {
	var t_id = 'cms_s_template_' + v;
	$('cms_template_image').src = $(t_id).src;
}

//テンプレート選択処理
var cmsTemplate = null;

function cxTemplateSet() {


	cmsTemplate = document.cms_fEdit.cms_s_template_id.options.selectedIndex;
	//close
	cxLayer('cms8341-reffer', 0);
	cxLayer('cms8341-category', 0);
	cxLayer('cms8341-calendar', 0);
	//hidden
	cxComboVisible();

	cxSelectTemplate();

	edit_closet_flg = false;
	cxComboHidden(new Array("cms_s_template_id"));
	$('cms_thumb').contentWindow.document.body.style.zoom = 0.5;
	$('cms_thumb').contentWindow.document.body.style.position = "relative";
	cxLayer('cms8341-template-select', 1, 800, 490);
}

//
var cms_sid;
var cms_inv_cnt = 0;
var cms_inv_tim = 200;
var cms_inv_max = 25;

function cxSelectTemplate() {
	var si, src;
	si = $('cms_s_template_id').options.selectedIndex;
	if (si >= 0) {
		src = $('cms_s_template_id').options[si].id;
		//
		// テンプレート選択画面のプレビューでレスポンシブをOFF
		$('cms_thumb').src = cms8341admin_path + "/page/common/tplview.php?path=" + encodeURI(src) + '&thum=1';
		if (cms_sid) clearInterval(cms_sid);
		cms_sid = 0;
		cms_inv_cnt = 0;
		cms_sid = setInterval(cxIFrameZoom, cms_inv_tim);
	} else {
		$('cms_thumb').src = 'javascript:';
	}
}

function cxIFrameZoom() {
	if ($('cms_thumb').contentWindow.document.body) {
		var thumb_body = $('cms_thumb').contentWindow.document.body;
		thumb_body.style.position = "relative";
		thumb_body.style.transform = "scale(0.5)";
		thumb_body.style.transformOrigin = "0 0";
		thumb_body.style.webkitTransform = "scale(0.5)";
		thumb_body.style.webkitTransformOrigin = "0 0";
	}
	//
	cms_inv_cnt++;
	if (cms_inv_cnt > cms_inv_max) {
		clearInterval(cms_sid);
		cms_inv_cnt = 0;
	}
}

function cxTemplateSubmit() {
	var si, label, cate;
	si = $('cms_s_template_id').options.selectedIndex;
	cmsTemplate = si;
	if (si >= 0) {
		$('cms-template-selected').innerHTML = $('cms_s_template_id').options[si].text;
		$('cms_template_id').value = $('cms_s_template_id').options[si].value;
		$('cms_template_ver').value = $('cms_s_template_id').options[si].getAttribute('_template_ver');
	}
	//
	cxLayer('cms8341-template-select', 0);
	edit_closet_flg = false;
	//visible
	cxComboVisible();
}

function cxTemplateClose() {
	//close
	cxLayer('cms8341-template-select', 0);
	//visible
	edit_closet_flg = false;
	cxComboVisible();
	if (cmsTemplate != null) {
		document.cms_fEdit.cms_s_template_id.options.selectedIndex = cmsTemplate;
		//re select
		cxSelectTemplate();
	}
	cmsTemplate = null;
}

// アップロードした関連ファイルで削除できるものがあるか調べる
var ret_ajax_f;

function cxDependFileDeleteCheck(context, current_dir, callback) {

	var params = "";

	// 指定がある場合のみパラメーターの作成
	if (current_dir) {
		params = 'current_dir=' + current_dir;
		if (context) {
			params += '&context=' + encodeURI(context).replace(/&/g, "%26");
		}
		params += createEnqueteImagesParam();
		params += createFixedFilesParam();
		// オープンデータ
		// オープンデータファイルの可変登録エリアに指定されたファイル情報をパラメータに追加
		if ($('cms8341_OpenDataItems') !== undefined) {
			params += createVariableOpenDataFilesParam();
		}
	}

	// Ajax でPHPに接続
	var ajax = new Ajax.Request(
			cms8341admin_path + '/page/common/linkfile/u_del_confirm.php?pid=' + $F('cms_page_id'),
			{
				method: 'post',
				asynchronous: false,
				parameters: params
			}
	);
	// PHP からの戻り値(print)を取得
	ret_ajax_f = ajax.transport.responseText;

	// エラーフラグ
	var _error = ret_ajax_f.charAt(0);
	// 削除フラグ
	var _exec = ret_ajax_f.substr(2);

	// 戻り値が不正な場合はアラート
	if (_error == "-1") {
		alert(_exec);
		return false;
	}
	// true の場合は削除できるファイルがあるので確認画面を表示
	else if (_exec == 'true') {
		cxIframeLayer(
			cms8341admin_path + '/page/common/linkfile/u_del_dialog.php',
			628,
			400,
			COVER_SETTING.COLOR,
			'',
			function (retObj) {
				// 削除しない
				$('cms_unuse_delete').value = FLAG_OFF;

				//「はい」選択の場合は削除する
				if (retObj['delete'] && retObj['delete'] == FLAG_ON)
					$('cms_unuse_delete').value = FLAG_ON;
				
				if (callback) {
					callback();
				}
			}
		);
	}
	else {
		if (callback) {
			callback();
		}
	}
	return true;
}


// 使用されなくなる関連ファイルで削除できるものがあるか調べる
var ret_ajax_pf;

function cxPublishDependFileDeleteCheck(context, current_dir, callback) {

	var params = "";

	// パラメーターの作成
	params = 'current_dir=' + current_dir;
	if (context) params += '&context=' + encodeURI(context).replace(/&/g, "%26");
	params += createEnqueteImagesParam();
	params += createFixedFilesParam();
	// オープンデータ
	// オープンデータファイルの可変登録エリアに指定されたファイル情報をパラメータに追加
	if ($('cms8341_OpenDataItems') !== undefined) {
		params += createVariableOpenDataFilesParam();
	}

	// Ajax でPHPに接続
	var ajax = new Ajax.Request(
		cms8341admin_path + '/page/common/linkfile/p_del_confirm.php?pid=' + $F('cms_page_id'),
		{
			method: 'post',
			asynchronous: false,
			parameters: params
		}
	);
	// PHP からの戻り値(print)を取得
	ret_ajax_pf = ajax.transport.responseText;

	// エラーフラグ
	var _error = ret_ajax_pf.charAt(0);
	// 削除フラグ
	var _exec = ret_ajax_pf.substr(2);

	// 戻り値が不正な場合はアラート
	if (_error == "-1") {
		alert(_exec);
		return false;
	}
	// true の場合は削除できるファイルがあるので確認画面を表示
	else if (_exec == 'true') {
		cxIframeLayer(
			cms8341admin_path + '/page/common/linkfile/p_del_dialog.php',
			628,
			400,
			COVER_SETTING.COLOR,
			'',
			function (retObj) {
				// 削除しない
				$('cms_publish_delete').value = FLAG_OFF;

				//「はい」選択の場合は削除する
				if (retObj['delete'] && retObj['delete'] == FLAG_ON)
					$('cms_publish_delete').value = FLAG_ON;
				
				if (callback) {
					callback();
				}
			}
		);
	}
	else {
		if (callback) {
			callback();
		}
	}
	return true;
}

function createEnqueteImagesParam(name, dem, bef, aft) {

	if (!name) name = "enquete_images";
	if (!dem) dem = ",";
	if (!bef) bef = "&";
	if (!aft) aft = "";

	var params = "";

	// アンケートの場合は パラメータに画像を追加
	if ($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE) {
		if ($F('cms_work_class') == 1 || $F("cms_from_type") == ENQ_KIND_MAIL) {
			var ih = document.getElementsByTagName('input');
			for (var i = 0; i < ih.length; i++) {
				if (ih[i].type != 'hidden') continue;
				if (!ih[i].name) continue;
				var r = ih[i].name.match(/img\[\d+\]/);
				if (r) {
					params += (params == "" ? bef + name + "=" : dem) + encodeURI(ih[i].value);
				}
			}
			if (params != "") params += aft;
		}
	}

	return params;
}

// 定型の「link」「file」「image」
function createFixedFilesParam(name, dem, bef, aft) {

	if (!name) name = "fixed_items";
	if (!dem) dem = ",";
	if (!bef) bef = "&";
	if (!aft) aft = "";

	var params = "";

	if ($F('cms_template_kind') == TEMPLATE_KIND_FIXED || ($('kanko_xml') && $F('kanko_xml') != "")) {
		var ih = document.getElementsByTagName('input');
		for (var i = 0; i < ih.length; i++) {
			if (ih[i].type != 'hidden') continue;
			if (!ih[i].name) continue;
			// 定型項目定義のhiddenかチェック
			var r = ih[i].name.match(/^cms_kanko_hidden_(.*)/);
			if (r) {
				// オープンデータ
				// タイプが「link」「file」「image」かチェック
				// タイプが「opendata」もチェックする
				r = ih[i].value.match(/^(link|file|image|customarea|opendata)\:.*/);
				// タイプが「link」「file」「image」かチェック
				if (r) {

					// ファイル情報を取得
					var item_name = ih[i].name.replace(/^(cms_kanko_)hidden_(.*)/, "$1$2");
					var file = "";

					if (r[1] == "customarea") {
						var a_prm = 'page_id=' + $('cms_page_id').value + "&context=" + encodeURI($F(item_name)).replace(/&/g, "%26");
						file = cxAjaxCommandAnSync('cxGetContextFileLinks', a_prm, cxGetContextFileLinksResult).transport.responseText;
					}
					else {
						var item = ($(item_name) ? $F(item_name).split(KANKO_LINK_DELIMITER) : "");
						file = (item[0]) ? item[0] : "";
					}
					// 必要部分の抽出
					if (file != "") {
						// パラメータに追加
						params += (params == "" ? bef + name + "=" : dem) + encodeURI(file).replace(/&/g, "%26");
					}
				}
			}
		}
	}
	return params;
}

//オープンデータ
//------------------------------------------------------------------
//オープンデータファイルの可変登録にて登録したファイルの情報を取得し、
//削除対象ファイルチェック処理へのパラメータとしてセットする
//------------------------------------------------------------------
function createVariableOpenDataFilesParam() {
	// ポスト名
	var post_name = 'variable_opendata_files';
	// 可変登録されている項目の要素数を判定
	var item_count = document.getElementsByName('disp_sort[]');
	// 予備元に返すparamを初期化
	var params = '';
	// 登録されたファイルがある場合のみ処理する
	if (item_count.length > 0){
		for (var $cnt = 0 ; $cnt < item_count.length ; $cnt++) {
			// ファイルパス情報を取得する
			if ($('file_path_' + item_count[$cnt].value) !== undefined) {
				// ファイルパスを保存
				params += ( params == '' ? '&' + post_name + "=" : ',' ) + encodeURI($('file_path_' + item_count[$cnt].value).value).replace(/&/g, "%26");
			}
		}
	}
	// パラメータを返す
	return params;
}

//------------------------------------------------------------------
//編集領域中のファイルリンクに設定されたオープンデータの情報をPOST値
//にセットする
//------------------------------------------------------------------
function setContextOpenDataFilesPost() {
	// 本文領域
	var oEditor = CKEDITOR.instances.cms_context;
	// オープンデータクラスが指定された要素を取得する(オープンデータファイルリンクのみ)
	var context_od_links = oEditor.document.find('.openDataFile').$;
	
	// 取得したデータ分、POSTデータの追加を行う
	// データ数管理ようパラメータ
	var context_odfile_count = 1;
	for (var count = 0 ; count < context_od_links.length ; count++) {
		// リンクの属性値を取得してPOSTにセット
		// まずインデックス番号を配列に指定
		setPostData('context_odfile_count[]', context_odfile_count);
		// nameにインデックスを付与して各属性値をPOSTにセットする
		if (context_od_links[count].getAttribute('od_file_path') != null) {
			 setPostData('od_file_path_' + context_odfile_count, context_od_links[count].getAttribute('od_file_path'));
		}
		if (context_od_links[count].getAttribute('od_link_target') != null) {
			 setPostData('od_link_target_' + context_odfile_count, context_od_links[count].getAttribute('od_link_target'));
		}
		if (context_od_links[count].getAttribute('od_link_text') != null) {
			 setPostData('od_link_text_' + context_odfile_count, context_od_links[count].getAttribute('od_link_text'));
		}
		if (context_od_links[count].getAttribute('od_category') != null) {
			 setPostData('od_category_' + context_odfile_count, context_od_links[count].getAttribute('od_category'));
		}
		if (context_od_links[count].getAttribute('od_od_data_type') != null) {
			setPostData('od_od_data_type_' + context_odfile_count, context_od_links[count].getAttribute('od_od_data_type'));
		}
		if (context_od_links[count].getAttribute('od_keywords') != null) {
			 setPostData('od_keywords_' + context_odfile_count, context_od_links[count].getAttribute('od_keywords'));
		}
		if (context_od_links[count].getAttribute('od_license') != null) {
			 setPostData('od_license_' + context_odfile_count, context_od_links[count].getAttribute('od_license'));
		}
		if (context_od_links[count].getAttribute('od_pssy') != null) {
			 setPostData('od_pssy_' + context_odfile_count, context_od_links[count].getAttribute('od_pssy'));
		}
		if (context_od_links[count].getAttribute('od_pssm') != null) {
			 setPostData('od_pssm_' + context_odfile_count, context_od_links[count].getAttribute('od_pssm'));
		}
		if (context_od_links[count].getAttribute('od_pssd') != null) {
			 setPostData('od_pssd_' + context_odfile_count, context_od_links[count].getAttribute('od_pssd'));
		}
		if (context_od_links[count].getAttribute('od_ptsy') != null) {
			 setPostData('od_ptsy_' + context_odfile_count, context_od_links[count].getAttribute('od_ptsy'));
		}
		if (context_od_links[count].getAttribute('od_ptsm') != null) {
			 setPostData('od_ptsm_' + context_odfile_count, context_od_links[count].getAttribute('od_ptsm'));
		}
		if (context_od_links[count].getAttribute('od_ptsd') != null) {
			 setPostData('od_ptsd_' + context_odfile_count, context_od_links[count].getAttribute('od_ptsd'));
		}
		if (context_od_links[count].getAttribute('od_summary') != null) {
			 setPostData('od_summary_' + context_odfile_count, context_od_links[count].getAttribute('od_summary'));
		}
		if (context_od_links[count].getAttribute('od_file_ext') != null) {
			 setPostData('od_file_ext_' + context_odfile_count, context_od_links[count].getAttribute('od_file_ext'));
		}
		if (context_od_links[count].getAttribute('od_file_size') != null) {
			 setPostData('od_file_size_' + context_odfile_count, context_od_links[count].getAttribute('od_file_size'));
		}
		// indexをインクリメント
		context_odfile_count++;
	}
}

//------------------------------------------------------------------
//パラメータで受け取るname,valueを設定したhiddenデータをcms_fEdit内
//に追加する
//------------------------------------------------------------------
function setPostData(name, value) {
	var fObj = $('cms_fEdit');
	var aObj = document.createElement('input');
	aObj.type = 'hidden';
	aObj.name = name;
	aObj.value = value;
	fObj.appendChild(aObj);
}

function cxGetContextFileLinksResult(r) {
	return r;
}

Event.observe(window, 'beforeunload', function (e) {
	if (edit_closet_flg) {
		event.returnValue = "一時保存または編集完了をしていない場合、現在の保存状態が保存されません。\n編集を終了する場合は、編集完了または閉じるボタンを押してください。";
	} else {
		edit_closet_flg = true;
	}
});

function cxGetTemplateKeywordsEdit(element, id_element, ver_element) {
	edit_closet_flg = false;
	return cxGetTemplateKeywords(element, id_element, ver_element);
}

// イベントカレンダー複数日
/**
 * 開催期間をフォーマット形式に変換
 * @param format 出力フォーマット
 * @param yyyy 出力対象【年】
 * @param mm 出力対象【月】
 * @param dd 出力対象【日】
 * @param hh 出力対象【時】
 * @param ii 出力対象【分】
 * @param mode start : 開始日 | end : 終了日
 * @returns フォーマット形式に変換された日付文字列
 */
function eventDayFormat(format, yyyy, mm, dd, hh, ii, mode) {
	// 指定された日付の先頭の「0」を削除
	yyyy = yyyy.replace(/^0+([0-9]+)/, "$1");
	mm = mm.replace(/^0+([0-9]+)/, "$1");
	dd = dd.replace(/^0+([0-9]+)/, "$1");
	hh = (hh == undefined || hh == '') ? '0' : hh.replace(/^0+([0-9]+)/, "$1");
	// 「秒」だけは先頭を「0」埋めする
	ii = (ii == undefined || ii == '') ? '00' : ("0" + ii).slice(-2);

	var open_str = '';
	var date = yyyy + '-' + mm + '-' + dd + ' ' + hh + ':' + ii + ':00';
	var params = 'date=' + date + '&format=' + format + '&mode=' + mode;

	// ajaxによる日付フォーマットの置き換え実行
	open_str = cxAjaxCommandAnSync('cxRreplaceEventTag', params, '').transport.responseText;

	return open_str;
}

// アクセシビリティチェック必須化
/**
 * 各種チェック実行済チェック
 * @return	未実行のチェック機能名
 */
function cxAllTotalCheck(){
	var msg = '';
	var r = cxAjaxCommandAnSync('cxAllTotalCheck', '', '').transport.responseText;
	if (r != '') {
		return r;
	}
	return '';
}
