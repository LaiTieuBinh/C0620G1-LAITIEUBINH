/*
 *
 */
var HeadlineChecker = function(title) {
	this.obj = document.body;
	//	this.siteTitleChar = siteTitle;
	this.resultType = 'HTML';					//HTML:見出し構造結果にHTMLを使用  TEXT:見出し構造結果にテキストを使用
	this.outputHtml = '<div id="cms8341-headlinecheck">' + 
		                '<table width="500" border="0" cellspacing="0" cellpadding="0">' + 
		                '<tr>' + 
	                  '<td width="500" align="center" valign="top" bgcolor="#DFDFDF" style="border:solid 1px #343434;">' + 
	                  '<table width="500" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader">' + 
	                  '<tr>' + 
	                  '<td align="left" valign="middle"><img src="../../images/headline/title_headline.jpg" alt="見出しチェック結果" width="200" height="20" style="margin:4px 10px;"></td>' + 
		                '<td width="78" align="right" valign="middle"><a href="javascript:" onClick="return window.close()"><img src="../../images/btn/btn_close.jpg" alt="閉じる" width="58" height="19" border="0" style="margin:4px 10px;"></a></td>' + 
	                  '</tr>' + 
	                  '</table>' + 
	                  '<div id="cms8341-checklistarea">' + 
	                  '<div align="center">' + 
		                '<table width="430" border="0" cellspacing="0" cellpadding="0" style="margin-bottom:10px;">' + 
	                  '<tr>' + 
	                  '<td align="left" valign="top">' + 
                    '<p style="margin-top:10px;margin-bottom:15px;"><img src="../../images/headline/bar_h1check.jpg" width="430" height="20" alt="見出し1チェック結果"></p>' + 
	                  '{#first_check_result#}' + 
	                  '</td>' + 
		                '</tr>' + 
	                  '<tr>' + 
	                  '<td align="left" valign="top">' + 
	                  '<p style="margin-top:25px;margin-bottom:15px"><img src="../../images/headline/bar_headlinecheck.jpg" width="430" height="20" alt="見出し構造チェック結果"></p>' + 
	                  '{#headline_check_result#}' + 
		                '</td>' + 
	                  '</tr>' + 
	                  '</table>' + 
	                  '</div>' + 
	                  '</div>' + 
		                '</td>' + 
	                  '</tr>' + 
	                  '</table>' + 
	                  '</div>';
	this.okIcon = '<img src="../../images/headline/icon_ok_h{#x#}.jpg" width="80" height="20" alt="" style="vertical-align:middle;margin-right:10px;">';
	this.ngIcon = '<img src="../../images/headline/icon_ng_h{#x#}.jpg" width="80" height="20" alt="" style="vertical-align:middle;margin-right:10px;">';

	//	// なぜかdocument.titleに半角スペースがある場合、見出しチェックがエラーになるので
	//	// 半角スペースの文字コードを判定して作り直す処理を追加
	//	doc_title = "";	
	//	for(i=0;i<document.title.length;i++){
	//		if(document.title.charCodeAt(i) == 160){
	//			doc_title += " ";
	//		} else {
	//			doc_title += String.fromCharCode(document.title.charCodeAt(i));
	//		}
	//	}
	//	var title = doc_title.replace(siteTitle,'');	//ページタイトルから共通文字列を除去
	var head1 = this.firstCheck();
	var datas = this.getHeadline();
	//
	this.output(title,head1, datas);
}
HeadlineChecker.prototype = {
	firstCheck : function() {
		var h1 = document.body.getElementsByTagName('H1');
		var retObj = new Object();
		retObj['length'] = h1.length;
		if(h1.length!=1) return retObj;
		
		retObj['html'] = this.getText(h1[0]);
		
		return retObj;
	},
	getHeadline : function() {
		var data = new Array();
		var head = this.obj.getElementsByTagName('*');
		for(var i=0;i<head.length;i++) {
			var tag = head[i].tagName;
			if(tag.match(/h[\d]/i)) data.push(head[i]);
		}
		return data;
	},
	output : function(title,h1,list) {
		//見出し１チェック結果
		var h1_replaceChar = '{#first_check_result#}';
		var h1_ngIcon = '<img src="../../images/icon/link_error.jpg" width="12" height="12" alt="">';
		var h1_okIcon = '<img src="../../images/icon/link_normal.jpg" width="12" height="12" alt="">';
		var h1_result = '';
		if(h1.length==0) {
			//見出し１がない
			h1_result = '<p class="cms8341-error">'+h1_ngIcon+'見出し１が設定されていません。</p>';
		} else if(h1.length>1) {
			//見出し１が複数設定されている
			h1_result = '<p class="cms8341-error">'+h1_ngIcon+'見出し１が複数設定されています。</p>';
		} else if(h1.length==1) {
			//見出し１が１つ設定されている
			//regTitle = title.replace(/\\|\^|\$|\*|\+|\?|\{|\}|\[|\]|\||\(|\)/gi,function($0,$1){return '\\'+$0;});
			//regTitle = regTitle.replace(/ |\s/gi,'');
			//var re = new RegExp("^"+regTitle+" ?$");
			//TITLEタグの文字参照対応
			title = title.replace(/&quot;/g,'"');
			title = title.replace(/&lt;/g,'<');
			title = title.replace(/&gt;/g,'>');
			title = title.replace(/&amp;/g,'&');
			//文字数の取得
			var hlength = h1.html.length;
			var tlength = title.length;
			var maxp = (hlength > tlength)? hlength : tlength;
			//
			var eflg = false;
			for(var i=0;i<maxp;i++) {
				var a = title.substr(i,1);
				var b = h1.html.substr(i,1);
				ac = a.charCodeAt(0);
				bc = b.charCodeAt(0);
				if(ac==bc) continue;
				if((ac=='32' || ac=='160') && (bc=='32' || bc=='160')) continue;
				if(((!ac && bc=='32')||(!bc && ac=='32')) && i==maxp) continue;
				eflg = true;
				break;
			}
			if(eflg==false || header_check_flg == false) {
				h1_result = '<p class="cms8341-normal">'+h1_okIcon+'見出し１は適切に設定されています。</p>';
			} else {
				h1_result = '<p class="cms8341-error">'+h1_ngIcon+'見出し１がページタイトルと異なります。</p>';
			}
		} else {
			//不明
			h1_result = '<p class="cms8341-error">'+h1_ngIcon+'見出し１が取得できませんでした。</p>';
		}
		this.outputHtml = this.outputHtml.replace(h1_replaceChar,h1_result);
		
		//見出し構造チェック
		var headline_result = '';
		var h = new Object();
		var struct_err = false;
		h['1'] = h['2'] = h['3'] = h['4'] = h['5'] = 0;	//見出しレベル出現カウント
		for(var i=0;i<list.length;i++){
			var tag = list[i].tagName;
			if(this.resultType=='TEXT') {
				var txt = this.getText(list[i]);
			} else {
				var txt = list[i].innerHTML;
				//href属性値は#とし、リンクを無効化
				txt = txt.replace(/href="[^"]*"/,'href="#"');
			}
			var num = tag.replace(/h(\d)/i,'$1');
			var wk_num = num - 1;
			var p = document.createElement('p');
			if(num==1) {
				headline_result += '<p style="padding-left:'+wk_num+'em;" class="cms8341-headline">'+this.okIcon.replace(/{#x#}/,num)+txt+'</p>';
			} else {
				var e = false;
				//
				for(var x=num;x<=6;x++) h[x] = 0;
				for(var j=1;j<parseInt(num);j++) {
					if(h[j]==0) {
						e=true;
						break;
					}
				}
				if(e) {
					headline_result += '<p style="padding-left:'+wk_num+'em;" class="cms8341-headline">'+this.ngIcon.replace(/{#x#}/,num)+txt+'</p>';
					struct_err = true;
				} else {
					headline_result += '<p style="padding-left:'+wk_num+'em;" class="cms8341-headline">'+this.okIcon.replace(/{#x#}/,num)+txt+'</p>';
				}
			}
			h[num]++;
		}
		if(struct_err==false) {
			headline_result = '<p class="cms8341-normal" style="margin-bottom:10px;"><img src="../../images/icon/link_normal.jpg" width="12" height="12" alt="">見出し構造に問題はありません。</p>' + headline_result;
		} else {
			headline_result = '<p class="cms8341-error" style="margin-bottom:10px;"><img src="../../images/icon/link_error.jpg" width="12" height="12" alt="">見出し構造に誤りがあります。</p>' + headline_result;
		}
		this.outputHtml = this.outputHtml.replace(/{#headline_check_result#}/,headline_result);
		document.body.innerHTML = this.outputHtml;
		document.body.style.display = '';
		document.title = '見出しチェック結果';
	},
	getText : function(obj) {
		var keep = obj.innerHTML;
		var img = obj.getElementsByTagName('IMG');
		var alt;
		for(var i=0;i<img.length;i++) {
			alt = img[i].alt;
			if(alt==""|| alt=="#") alt = '';
			(img[i].outerHTML)? img[i].outerHTML = alt : img[i].textContent = alt;
		}
		var retText = (obj.innerText)? obj.innerText : obj.textContent;

		obj.innerHTML = keep;
		return retText;
	}
}

/////////////////