/*
 *
 */
//adminルートパス
var baseUrl = location.pathname.substring(0,location.pathname.indexOf("/cms8341/")+"/cms8341/".length);
if(baseUrl.indexOf("/") != 0) baseUrl = "/"+baseUrl;
var cms8341admin_path = baseUrl + 'admin';
var cms_prev_layer;
var prev_submenu_id;
var prev_mobile_submenu_id;
var URLRegEx = new RegExp("^s?https?:\/\/[-_.!~*'()a-zA-Z0-9;\/?:\@&=+\$,%#]+$");
var EMailRegEx = new RegExp("^([a-zA-Z0-9\.\\-\/_]{1,})@([a-zA-Z0-9\.\\-\/_]{1,})\.([a-zA-Z0-9\.\\-\/_]{1,})$");
var edit_closet_flg = true;
var COVER_SETTING = {
  NOCOVER : {value: 0}, 
  TRANSPARENT: {value: 1, opacity: 0}, 
  COLOR : {value: 2, opacity: 0.3}
};
//PHPとの接続（非同期）
function cxAjaxCommand(command, p, SuccessFunc) {
	var params = 'Command=' + command;
	if ( p ) params += '&' + p;
	var regAjax = new Ajax.Request(
		cms8341admin_path+'/connector.php',
		{
			method: 'post',
			parameters: params,
			onSuccess: SuccessFunc,
			onFailure: cxFailure
		});
}

//PHPとの接続（同期）
function cxAjaxCommandAnSync(command, p, SuccessFunc) {
	var params = 'Command=' + command;
	if ( p ) params += '&' + p;
	var regAjax = new Ajax.Request(
		cms8341admin_path+'/connector.php',
		{
			method: 'post',
			parameters: params,
			asynchronous: false,
			onSuccess: SuccessFunc,
			onFailure: cxFailure
		});
	return regAjax;
}

function cxAjaxUpdater(command,p, id){
	var params = 'Command=' + command;
	if ( p ) params += '&' + p;
	var regAjax = new Ajax.Updater( 
		id, 
		cms8341admin_path+'/connector.php',
		{ 
			method: "post", 
			parameters: params, 
			onSuccess: function(request) {}, 
			onComplete: function(request) {}, 
			onFailure: function(request) { 
				alert('読み込みに失敗しました'); 
			}, 
			onException: function (request) { 
				alert('読み込み中にエラーが発生しました'); 
			} 
		} 
	); 
}

//画像のプリロード
function cxPreImages() {
	var d=document;
	if(d.images){
		if(!d.MM_p) d.MM_p=new Array();
		var i;
		var j=d.MM_p.length;
		var a=cxPreImages.arguments;
		for(i=0; i<a.length; i++) {
			if (a[i].indexOf("#")!=0){ 
				d.MM_p[j]=new Image;
				d.MM_p[j++].src=a[i];
			}
		}
	}
}
//画像変更処理
function cxImageChange(t,p) {
	t.src = p;
}
//date check
function cxDateCheck(obj) {
	var retAry = new Array();
	var stat;
	var c_days;
	//charactor check
	if(obj.sy) {
		stat = cxDateNumeric(obj.sy);
		if(!stat) {
			retAry.push('公開開始年に数字ではない文字列が入力されています。');
			obj.sy = false;
		} else if(Number(obj.sy) < 2000 || Number(obj.sy) > 2037) {
			retAry.push('公開開始年は2000年から2037年の間を指定してください。');
			obj.sy = false;
		}
	}
	if(obj.sm) {
		stat = cxDateNumeric(obj.sm);
		if(!stat) {
			retAry.push('公開開始月に数字ではない文字列が入力されています。');
			obj.sm = false;
		} else if(Number(obj.sm) < 1 || Number(obj.sm) > 12) {
			retAry.push('公開開始月には 1 ～ 12 を指定してください。');
			obj.sm = false;
		}
	}
	if(obj.sd) {
		stat = cxDateNumeric(obj.sd);
		if(!stat) {
			retAry.push('公開開始日に数字ではない文字列が入力されています。');
			obj.sd = false;
		} else if(Number(obj.sd) < 1) {
			retAry.push('公開開始日には 0 以下を指定することはできません。');
			obj.sd = false;
		}
	}
	if(obj.sy && obj.sm && obj.sd) {
		c_days = cxGetDays(Number(obj.sy),Number(obj.sm));
		if(Number(obj.sd) > c_days) {
			retAry.push('入力された公開開始日は存在しません。');
			obj.sd = false;
		}
	}
	if(obj.sh) {
		stat = cxDateNumeric(obj.sh);
		if(!stat) {
			retAry.push('公開開始時間に数字ではない文字列が入力されています。');
			obj.sh = false;
		} else if(Number(obj.sh) < 0 || Number(obj.sh) > 23) {
			retAry.push('公開開始時間には 0 ～ 23 を指定してください。');
			obj.sh = false;
		}
	}
	if(obj.ey) {
		stat = cxDateNumeric(obj.ey);
		if(!stat) {
			retAry.push('公開終了年に数字ではない文字列が入力されています。');
			obj.ey = false;
		} else if(Number(obj.ey) < 2000 || Number(obj.ey) > 2037) {
			retAry.push('公開終了年は2000年から2037年の間を指定してください。');
			obj.ey = false;
		}
	}
	if(obj.em) {
		stat = cxDateNumeric(obj.em);
		if(!stat) {
			retAry.push('公開終了月に数字ではない文字列が入力されています。');
			obj.em = false;
		} else if(Number(obj.em) < 1 || Number(obj.em) > 12) {
			retAry.push('公開終了月には 1 ～ 12 を指定してください。');
			obj.em = false;
		}
	}
	if(obj.ed) {
		stat = cxDateNumeric(obj.ed);
		if(!stat) {
			retAry.push('公開終了日に数字ではない文字列が入力されています。');
			obj.ed = false;
		} else if(Number(obj.ed) < 1) {
			retAry.push('公開終了日には 0 を指定することはできません。');
			obj.ed = false;
		}
	}
	if(obj.ey && obj.em && obj.ed) {
		c_days = cxGetDays(Number(obj.ey),Number(obj.em));
		if(Number(obj.ed) > c_days) {
			retAry.push('入力された公開終了日は存在しません。');
			obj.ed = false;
		}
	}
	if(obj.eh) {
		stat = cxDateNumeric(obj.eh);
		if(!stat) {
			retAry.push('公開終了時間に数字ではない文字列が入力されています。');
			obj.eh = false;
		} else if(Number(obj.eh) < 0 || Number(obj.eh) > 23) {
			retAry.push('公開終了時間には 0 ～ 23 を指定してください。');
			obj.eh = false;
		}
	}
	//
	if(obj.ey && obj.em && obj.ed && obj.eh) {
		var getToday	= new Date();
		var limit_today = getToday.getFullYear() * 1000000 + (getToday.getMonth()+1) * 10000 +getToday.getDate() * 100 + getToday.getHours();
		var limit_edate = Number(obj.ey) * 1000000 + Number(obj.em) * 10000 + Number(obj.ed) * 100 + Number(obj.eh);
		if(limit_today > limit_edate) {
			retAry.push('公開終了日時は既に経過しています。');
			//obj.ed = false;
		}
	}
	//
	if(obj.sy && obj.sm && obj.sd && obj.sh && obj.ey && obj.em && obj.ed && obj.eh) {
		var sdate = Number(obj.sy) * 1000000 + Number(obj.sm) * 10000 + Number(obj.sd) * 100 + Number(obj.sh);
		var edate = Number(obj.ey) * 1000000 + Number(obj.em) * 10000 + Number(obj.ed) * 100 + Number(obj.eh);
		if(sdate>=edate) {
			retAry.push('公開期間に矛盾があります。\n公開開始日時と公開終了日時を確認してください。');
			return retAry;
		}
	}
	//
	return retAry;
}


//date check
// id:idタグ ex)cms_pd
// format 日付フォーマット ex) ymd ymdh ymdhi
// mode 1:開始終了チェック 2:開始チェック 3:終了チェック 4:単独チェック
// target_name 名前 ex)公開
function cxDateCheckNew(id, format, mode,target_name) {
	var retAry = new Array();
	var stat;
	var c_days;
	var format_ary = format.toArray();
	
	var mode_ary = new Array();
	if(mode == 1){
		mode_ary[0] = 's';
		mode_ary[1] = 'e';
	} else if(mode == '2'){
		mode_ary[0] = 's';
	} else if(mode == '3'){
		mode_ary[0] = 'e';
	} else if(mode == '4'){
		mode_ary[0] = '_';
	} else {
		return;
	}

	for(var cnt = 0; cnt < mode_ary.length; cnt++){
		var this_mode = mode_ary[cnt];
		switch (this_mode){
			case 's':
				this_mode_name = "開始";
				break;
			case 'e':
				this_mode_name = "終了";
				break;
			case '_':
				this_mode_name = "";
				break;
			default:
				return;
		}
		// 入力チェック
		// 数字チェック
		for(var i = 0; i < format_ary.length; i++){
			if(!$F(id + this_mode + format_ary[i])){
				retAry.push(target_name+'に入力されていない箇所があります。');
				return retAry;
			}
			stat = cxDateNumeric($F(id + this_mode + format_ary[i]));
			if(!stat) {
				retAry.push(target_name+ cxGetDateString(format_ary[i], mode, this_mode_name) + 'に数字ではない文字列が入力されています。');
			} 
		}

		//charactor check
		stat = cxDateNumeric($F(id+this_mode+'y'));
		if($F(id+this_mode+'y') && (Number($F(id+this_mode+'y')) < 2000 || Number($F(id+this_mode+'y')) > 2037)) {
			retAry.push(target_name + cxGetDateString('y', mode,this_mode_name) + '2000年から2037年の間を指定してください。');
		}
		
		if($F(id+this_mode+'m') && (Number($F(id+this_mode+'m')) < 1 || Number($F(id+this_mode+'m')) > 12)) {
			retAry.push(target_name + cxGetDateString('m', mode,this_mode_name) + 'には 1 ～ 12 を指定してください。');
		}
			
		if($F(id+this_mode+'m') && Number($F(id+this_mode+'m')) < 1) {
			retAry.push(target_name + cxGetDateString('m', mode,this_mode_name) + 'には 0 以下を指定することはできません。');
		}
		
		c_days = cxGetDays(Number($F(id+this_mode+'y')),Number($F(id+this_mode+'m')));
		if($F(id+this_mode+'d') && Number($F(id+this_mode+'d')) > c_days) {
			retAry.push('入力された'+target_name+cxGetDateString('d', mode, this_mode_name)+'は存在しません。');
		}
		// (日)0以下のチェック
		if($F(id+this_mode+'d') && Number($F(id+this_mode+'d')) < 1) {
			retAry.push(target_name + cxGetDateString('d', mode,this_mode_name) + 'には 0 以下を指定することはできません。');
		}
		
		if(format.indexOf("h") != -1){
			if($F(id+this_mode+'h') && (Number($F(id+this_mode+'h')) < 0 || Number($F(id+this_mode+'h')) > 23)) {
				retAry.push(target_name+cxGetDateString('h', mode, this_mode_name)+'には 0 ～ 23 を指定してください。');
			}
		}
		
		if(format.indexOf("i") != -1){
			if($F(id+this_mode+'i') && (Number($F(id+this_mode+'i')) < 0 || Number($F(id+this_mode+'i')) > 59)) {
				retAry.push(target_name+cxGetDateString('i', mode, this_mode_name)+'には 0 ～ 59 を指定してください。');
			}
		}

		if(format.indexOf("s") != -1){
			if($F(id+this_mode+'s') && (Number($F(id+this_mode+'s')) < 0 || Number($F(id+this_mode+'s')) > 59)) {
				retAry.push(target_name+cxGetDateString('s', mode, this_mode_name)+'には 0 ～ 59 を指定してください。');
			}
		}
	}
	
	if(mode == 1 && retAry.length == 0){
		si = 0;
		ei = 0;
		if(format == "ymdh"){
			sh = $F(id+'sh');
			eh = $F(id+'eh');
		} else if (format == "ymdhi") {
			sh = $F(id+'sh');
			si = $F(id+'si');
			eh = $F(id+'eh');
			ei = $F(id+'ei');
		} else {
			sh = 0;
			eh = 0;
		}
		s_utime = Date.UTC($F(id+'sy'), $F(id+'sm')-1, $F(id+'sd'), sh, si, 0);
		e_utime = Date.UTC($F(id+'ey'), $F(id+'em')-1, $F(id+'ed'), eh, ei, 0);
		if(s_utime > e_utime){
			retAry.push(target_name + '終了日が' + target_name + '開始日より過去に設定されています。');
		}
	}
	// イベントカレンダー複数日
	if(mode == 3 && retAry.length == 0 && document.getElementById(id + 'sh') != null && EVENT_CAL_MULTI_FLAG == true){
		if (document.getElementById(id + 'sh') === null || $F(id + 'sh') == '') {
			sh = 0;
		} else {
			sh = $F(id + 'sh');
		}
		if (document.getElementById(id + 'si') === null || $F(id + 'si') == '') {
			si = 0;
		} else {
			si = $F(id + 'si');
		}
		if (document.getElementById(id + 'eh') === null || $F(id + 'eh') == '') {
			eh = 0;
		} else {
			eh = $F(id + 'eh');
		}
		if (document.getElementById(id + 'ei') === null || $F(id + 'ei') == '') {
			ei = 0;
		} else {
			ei = $F(id + 'ei');
		}
		
		s_utime = Date.UTC($F(id + 'sy'), $F(id + 'sm')-1, $F(id + 'sd'), sh, si, 0);
		e_utime = Date.UTC($F(id + 'ey'), $F(id + 'em')-1, $F(id + 'ed'), eh, ei, 0);
		
		if(s_utime > e_utime){
			retAry.push(target_name + '終了日が' + target_name + '開始日より過去に設定されています。');
		}
	}
	return retAry;
}

//
function cxDateNumeric(p) {
	var temp1,temp2;
	var regObj = new RegExp("[^0-9]","i");
	//
	temp1 = p.match(regObj)
	if(temp1) {
		return false;
	} else {
		return true;
	}
}

// format 日付フォーマット ex) y m d h i
// mode 1:開始終了チェック 2:開始チェック 3:終了チェック(未実装)
// target_name 名前 ex)開始 終了
function cxGetDateString(format, mode,target_name){
	switch(format){
		case 'y':
			return (mode == 1)?target_name+'年':'年';
		case 'm':
			return (mode == 1)?target_name+'月':'月';
		case 'd':
			return (mode == 1)?target_name+'日':'日';
		case 'h':
			return (mode == 1)?target_name+'時間':'時間';
		case 'i':
			return (mode == 1)?target_name+'分':'分';
	}
	return '';
}
// 機種依存文字チェック
function cxCheckMachineCode(str) {
	if (str.match(/[①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳㊤㊥㊦㊧㊨㈱㈲㈹ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩⅰⅱⅲⅳⅴⅵⅶⅷⅸⅹ㍾㍽㍼㍻〝〟№㏍℡≒≡∫∮∑√⊥∠∟⊿∵∩∪㍉㌔㌢㍍㌘㌧㌃㌶㍑㍗㌍㌦㌣㌫㍊㌻㎜㎝㎞㎎㎏㏄㎡]/g)) {
		return false;
	}
	return true;
}

function cxOnCheck(id){
	if(!$(id))return;
	$(id).checked = true;
}

// 西暦⇒和暦
function convertJpYear(y,m,d)
{
	if(m.length == 1)m = "0"+m;
	if(d.length == 1)d = "0"+d;
	ymd = y+m+d;
	if (ymd <= "19120729") {
		gg = "明治";
		yy = y - 1867;
	} else if (ymd >= "19120730" && ymd <= "19261224") {
		gg = "大正";
		yy = y - 1911;
	} else if (ymd >= "19261225" && ymd <= "19890107") {
		gg = "昭和";
		yy = y - 1925;
	} else if (ymd >= "19890108" && ymd <= "20190430") {
		gg = "平成";
		yy = y - 1988;
	} else if (ymd >= "20190501") {
		gg = "令和";
		yy = y - 2018;
	}
	if (yy == 1) {
		yy = '元';
	}
	return gg+yy+"年";
}

function trim(value){
	return String(value).replace(/^\s+|\s+$/g, "");
}

function cxGetDeptCombText(val){
	val = trim(val);
	if(val == "指定なし" || val == "----------------" || val == ""){
		return "";
	}
	return val;
}

function changeVisible(value,targetItem){
	if(trim(value) == ""){
		Element.hide(targetItem);
	} else {
		Element.show(targetItem);
	}
}

// 問い合わせチェック
function cxInquiryCheck(id, info){
	var retAry = new Array();
	var kind = $F('cms_template_kind');
	var focusId = "";
	for(var i = 1; i < Number($F('cms_inquiry_cnt'))+1; i++){
		if(!$('cms_inquiry_'+i)) continue;
		var dept1="",dept2="",dept3="",charge="",anExtensionNumber="",directNumber="",fax="",email="";
		if($(id+'_dept1_'+i)) dept1 = $F(id+'_dept1_'+i);
		if($(id+'_dept2_'+i)) dept2 = $F(id+'_dept2_'+i);
		if($(id+'_dept3_'+i)) dept3 = $F(id+'_dept3_'+i);
		if($(id+'_charge_'+i)) charge = $F(id+'_charge_'+i);
		if($(id+'_anExtensionNumber_'+i)) anExtensionNumber = $F(id+'_anExtensionNumber_'+i);
		if($(id+'_directNumber_'+i)) directNumber = $F(id+'_directNumber_'+i);
		if($(id+'_fax_'+i)) fax = $F(id+'_fax_'+i);
		if($(id+'_email_'+i)) email = $F(id+'_email_'+i);
		info = fckCheck($(id+'_no_'+i).innerHTML.stripTags() + 'の担当者',charge, info)
		if (anExtensionNumber != ''){
			$(id+'_anExtensionNumber_'+i).value = tranFulltoHalf(anExtensionNumber);
		}
/*		
		if (directNumber != '' && directNumber.match(/^[0-9]{2,4}\-[0-9]{2,4}\-[0-9]{3,4}$/) == null) {
			retAry.push($(id+'_no_'+i).innerHTML.stripTags() + 'の電話番号は正しい値ではありません。');
			if(focusId == "")focusId = id+'_directNumber_'+i;
		}
		if (fax != '' && fax.match(/^[0-9]{2,4}\-[0-9]{2,4}\-[0-9]{3,4}$/) == null) {
			retAry.push($(id+'_no_'+i).innerHTML.stripTags() + 'のファックス番号は正しい値ではありません。');
			if(focusId == "")focusId = id+'_fax_'+i;
		}
*/
		if (email != '' && email.match(/[!#-9A-~]+@+[a-z0-9]+.+[^.]$/) == null) {
			retAry.push($(id+'_no_'+i).innerHTML.stripTags() + 'のEmailは正しい値ではありません。');
			if(focusId == "")focusId = id+'_email_'+i;
		}
	}
	
	if($(id+'_memo')){
		info = fckCheck('フリー入力',$(id+'_memo').value, info)
	}
	var msg = new Array();
	msg = msg.concat(retAry);
	if (msg.length > 0) {
		msg_str = msg.join('\n');
		alert(msg_str);
		$(focusId).focus();
		return false;
	}
	return info;
 }

function htmlEscape(value){
	return String(value).replace(/\x0D\x0A|\x0D|\x0A/g,'<br>');
}

// XXXX年XX月XX日XX時にのみ対応
// str : XXXX年XX月XX日XX時
// mode : 0:0フォーマット 1:通常
function StringToDate(str,mode){
	date = new Array();
	var tmp = "";
	for (i = 0; i < str.length; i++) {
		ch = str.charAt(i)
		if(ch == "年"){
			date["y"] = tmp;
			tmp = "";
			continue;
		}
		if(ch == "月"){
			if(mode == 1 && tmp.charAt(0) == "0")tmp = tmp.slice(1);
			date["m"] = tmp;
			tmp = "";
			continue;
		}
		if(ch == "日"){
			if(mode == 1 && tmp.charAt(0) == "0")tmp = tmp.slice(1);
			date["d"] = tmp;
			tmp = "";
			continue;
		}
		if(ch == "時"){
			date["h"] = tmp;
			tmp = "";
			continue;
		}
		tmp = tmp + ch;
	}
	return date;
}

// 全角数字から半角数字へ変換
function tranFulltoHalf(rep){
	//全角数字配列
	var halfChar = new Array("１","２","３","４","５","６","７","８","９","０");
	//半角数字配列
	var fullChar = new Array(1,2,3,4,5,6,7,8,9,0);
	while(rep.match(/[０-９]/)){
		for(count = 0; count < halfChar.length; count++){
			rep = rep.replace(halfChar[count], fullChar[count]);
		}
	}
	return rep;
}
// リンクタイトル、代替テキスト等のアイテム毎のアクセシビリティチェック
function accItemCheck(target, context, info, type){
	switch(type){
		case 'link':
		case 'file':
		case 'mail':
			if($('cms_accessibility_check_15') && $('cms_accessibility_check_15_w')){
				word = $('cms_accessibility_check_15_w').innerHTML;
				var regObj = new RegExp('(' + word + ')');
				if (context.match(regObj)) {
					info.push(target+"にリンクテキストとして推奨されない文字が指定されています。");
				}
			}
			break;
		case 'image':
			if($('cms_accessibility_check_16') && $('cms_accessibility_check_16_w')){
				word = $('cms_accessibility_check_16_w').innerHTML;
				var regObj = new RegExp('^(' + word + ')$');
				if (context.match(regObj)) {
					info.push(target+"に画像代替テキストとして推奨されない文字が指定されています。");
				}
			}
			break;
	}
	return info;
}
// FCKエディッタ内コンテキストチェック
function fckCheck(target, context, info){
//	var err = new Array();
	// 機種依存文字変換
	if($('cms_accessibility_check_2') && $('cms_accessibility_check_2_w')){
		
		word = $('cms_accessibility_check_2_w').innerHTML;
		var regObj = new RegExp("["+word+"]","i");
		if (context.stripTags().match(regObj)) {
			info.push(target+"に文字化けの原因となる機種依存文字が含まれています。");
		}
	}
	// 全角スペース削除
	if($('cms_accessibility_check_3')){
		word = '　';
		var regObj = new RegExp("["+word+"]","i");
		if (context.stripTags().match(regObj)) {
			info.push(target+"に全角スペースが含まれています。");
		}
	}
	// 時間表記変換
	if($('cms_accessibility_check_4')){
		word = "(^|[^0-9０-９:：])([0-9０-９]{1,2}[:：][0-9０-９]{1,2}([:：][0-9０-９]{1,2})?|[0-9０-９]{1,2}('|’|&rsquo;)[0-9０-９]{1,2}(\"|&quot;|&rdquo;)?)([^0-9０-９:：]|$)";
		var regObj = new RegExp(word,"ig");
		if (context.stripTags().match(regObj)) {
			info.push(target+"に時間表記の誤りが含まれています。");
		}
	}
	// 日付表記変換
	if($('cms_accessibility_check_5')){
		word = "(^|[^0-9０-９\/／‐－．\.\-])((([0-9０-９]{2}|[0-9０-９]{4})[\/／])?[0-9０-９]{1,2}[\/／][0-9０-９]{1,2}|([0-9０-９]{2}|[0-9０-９]{4})[\.．][0-9０-９]{1,2}[\.．][0-9０-９]{1,2}|([0-9０-９]{2}|[0-9０-９]{4})[\-‐－][0-9０-９]{1,2}[\-‐－][0-9０-９]{1,2})([^0-9０-９\/／‐－．\.\-]|$)";
		var regObj = new RegExp(word,"i");
		if (context.stripTags().match(regObj)) {
			info.push(target+"に日付表記の誤りが含まれています。");
		}
	}
	// 曜日表記変換
	if($('cms_accessibility_check_6')){
		word = "[\(（](月|火|水|木|金|土|日|mon|tue|wed|thu|fri|sat|sun|"
				+ "[Ｍｍ][Ｏｏ][Ｎｎ]|[Ｔｔ][Ｕｕ][Ｅｅ]|[Ｗｗ][Ｅｅ][Ｄｄ]|"
				+ "[Ｔｔ][Ｈｈ][Ｕｕ]|[Ｆｆ][Ｒｒ][Ｉｉ]|[Ｓｓ][Ａａ][Ｔｔ]|[Ｓｓ][Ｕｕ][Ｎｎ])[\)）]";
		var regObj = new RegExp(word,"i");
		if (context.stripTags().match(regObj)) {
			info.push(target+"に曜日表記の誤りが含まれています。");
		}
	}
	// 行頭文字削除
	if($('cms_accessibility_check_7') && $('cms_accessibility_check_7_w')){
		char = $('cms_accessibility_check_7_w').innerHTML;
		word = '(<(p|h\d+|span|td|li)[^>]*>)(['+char+'])';
		var regObj = new RegExp(word,"i");
		if (context.stripTags().match(regObj)) {
			info.push(target+"に行頭文字表記の誤りが含まれています。");
		}
	}
	// 全角英数字変換
	if($('cms_accessibility_check_8') && $('cms_accessibility_check_8_w')){
		word = $('cms_accessibility_check_8_w').innerHTML;
		var regObj = new RegExp("["+word+"]");
		if (context.stripTags().match(regObj)) {
			info.push(target+"に全角英数字が含まれています。");
		}
	}
	// 半角カナ変換
	if($('cms_accessibility_check_9') && $('cms_accessibility_check_9_w')){
		word = $('cms_accessibility_check_9_w').innerHTML;
		var regObj = new RegExp("["+word+"]","i");
		if (context.stripTags().match(regObj)) {
			info.push(target+"に文字化けの原因となる半角カナが含まれています。");
		}
	}
	// ALT属性変換
	if($('cms_accessibility_check_10')){
		word = "<(img|area|input)( [^>]*)?>";
		var regObj = new RegExp(word,"ig");
		ary = context.match(regObj)
		if(ary){
			for(i = 0; i < ary.length; i++){
				word = ' (alt=""|alt= )';
				var regObj = new RegExp(word,"i");
				if (ary[i].match(regObj)) {
					info.push(target+"にALT属性が設定されていない画像が含まれています。");
					break;
				}
			}
		}
	}
	// 文中表記チェック
	if($('cms_accessibility_check_11') && $('cms_accessibility_check_11_w')){
		word = $('cms_accessibility_check_11_w').innerHTML;
		var regObj = new RegExp(word);
		if (context.stripTags().match(regObj)) {
			info.push(target+"に文中表記に推奨されない文字が含まれています。");
		}
	}
	
	// リンクテキストチェック
	if($('cms_accessibility_check_15') && $('cms_accessibility_check_15_w')){
		word = "<(a)( [^>]*)?>.*?<\/(a)>";
		var regObj = new RegExp(word,"ig");
		var err_flg = false;
		ary = context.match(regObj);
		if(ary){
			word = $('cms_accessibility_check_15_w').innerHTML;
			var regObj = new RegExp('(' + word + ')'); //部分一致
			
			for(link_cnt = 0; link_cnt < ary.length; link_cnt++){
				var link_text = ary[link_cnt];
				var link_dom = String2DOM(link_text);
				var link_img_arys = link_dom.getElementsByTagName("img");
				var alt_arys = new Array();
				
				for (i = 0; i < link_img_arys.length; i++) {
					alt_arys.push(link_img_arys[i].alt);
					link_img_arys[i].alt = "";
				}
				
				var link_text2 = link_dom.innerHTML;
				link_text2 = link_text2.replace(/<[^>]*?(>)/g, "@@CMS_TAG@@");
				var split_texts = new Array();
				split_texts = link_text2.split("@@CMS_TAG@@");
				
				var alt_text = "";
				for (i = 0; i < split_texts.length; i++) {
					alt_text += split_texts[i];
					if (split_texts[i].match(regObj)) {
						info.push(target+"にリンクテキストに推奨されない文字が指定されています。");
						err_flg = true;
						break;
					}
				}
				if (err_flg == true) break;
				for (i = 0; i < alt_arys.length; i++) {
					alt_text += alt_arys[i];
					if (alt_arys[i].match(regObj)) {
						info.push(target+"にリンクテキストに推奨されない文字が指定されています。");
						err_flg = true;
						break;
					}
				}
				
				if (err_flg == false) {
					// 「&nbsp;(文字参照スペース)」を「 (半角スペース)」に変換
					alt_text = alt_text.replace(/&nbsp;/g, " ");
					// 「　(文字参照全角スペース)」を「 (半角スペース)」に変換
					alt_text = alt_text.replace(/　/g, " ");
					// 「 (半角スペース)」を削除
					alt_text = alt_text.replace(/ /g, "");
					if (alt_text.length < 1) {
						info.push(target+"に画面に表示されない文言のみ指定されているリンクテキストが存在します。");
					}
				}
			}
		}
	}
	
	// 画像代替テキストチェック
	if($('cms_accessibility_check_16') && $('cms_accessibility_check_16_w')){
		word = "<(img|area|input)( [^>]*)?>";
		var regObj = new RegExp(word,"ig");
		ary = context.match(regObj)
		if(ary){
			word = $('cms_accessibility_check_16_w').innerHTML;
			var regObj = new RegExp('^(' + word + ')$'); //完全一致
			for(i = 0; i < ary.length; i++){
				// alt属性のみ抽出
				target_alt = ary[i].replace(/<.*?alt=(\")?/gi,'').replace(/(\")?(( \S+?)=.*?)?>/gi,'');
				if (target_alt.match(regObj)) {
					info.push(target+"に画像代替テキストに推奨されない文字が指定されています。");
					break;
				}
			}
		}
	}
	
	// 半角スペース変換
	if($('cms_accessibility_check_17')){
		// チェック用本文領域
		var check_context = context;
		var regObj = new RegExp(word);
		// タグ間に半スぺのみは対象外
		var regObjTagSpace = new RegExp("<([\\w]+)[^>]*>( |&nbsp;)</([^>]*)>", "gi");
		while(regObjTagSpace.exec(check_context)){
			if(RegExp.$1 != RegExp.$3) continue;
			regObj = new RegExp('<' + RegExp.$1 + '[^>]*>( |&nbsp;)</' + RegExp.$3 + '[^>]*>', "gi");
			check_context = check_context.replace(regObj, '');
		}
		// <li>タグの最後に半角スペースが入るので対応
		// remove space from beggining of newline
		check_context = check_context.replace(/(\n|\r\n) +/g,"");
		// remove space at the end of li tag
		check_context = check_context.replace(/\s<\/li>/gim,'</li>');
		// remove tags inside li tag
		check_context = check_context.stripTags();
		// 半角スペースチェック
		word = '( |&nbsp;)';
		regObj = new RegExp(word);
		if (regObj.test(check_context)) {
			info.push(target+"に半角スペースが含まれています。");
		}
	}
	
	return info;
}
function getElementPosition( e, x, y ) {
	// 指定要素がBODYまたはレイヤ要素であった場合、
	// 再帰処理を終了し、座標を返す
	if(e === document.body || e.style.position=='absolute' || e.className=='cms8341-layer') {
		if(arguments.length!=1) {
			return { x:x, y:y };
		} else {
			return { x:e.offsetLeft, y:e.offsetTop };
		}
	}
	
	if(arguments.length==1) {
		x = 0;
		y = 0;
	}
	// 再帰処理
	return arguments.callee(e.parentNode, e.offsetLeft+x, e.offsetTop+y);
	
}
var prev_submenu_id = false;
var ele_id = false;
function cxTotalCheckSubmenuOn(event, id) {
	if(totalcheckSubmenuIntervalId)	clearInterval(totalcheckSubmenuIntervalId);
	if(id == undefined){
		//フラッシュ(かん動)の表示を消す
		if($('flashcontent')) $('flashcontent').style.visibility = 'hidden';

		ele_id = 'cms_totalcheck_submenu';
		// UI要素を取得
		var u = event.srcElement || event.target;
		if(!u) return;
		// UI要素の座標を取得
		var p = getElementPosition(u);
		// UI要素の高さを取得
		var h = u.clientHeight;
		$(ele_id).style.top = 97 + h +'px';
		$(ele_id).style.left = p.x+'px';
		$(ele_id).style.display = 'block';
	} else {
		ele_id = 'cms_totalcheck_submenu_'+id;
		// UI要素を取得
		//if(event.srcElement!==o) return;
		var u = event.srcElement || event.target;
		if(!u) return;
		// DIV > IMG という構造で同じ位置にあるため、offsetTopが2倍されてしまう ???
		if(u.tagName=='IMG') u = u.parentNode;
		// UI要素の座標を取得
		var p = getElementPosition(u);
		// UI要素の幅を取得
		var w = u.clientWidth + 2;
		$(ele_id).style.top = p.y - 3 +'px';
		$(ele_id).style.left = p.x + w - 5 +'px';
		$(ele_id).style.display = 'block';
		prev_submenu_id = id;
	}
}

//	上記関数のele_id非固定関数	2008/10追加
var element_id = false;
function cxSubmenuOn(id, element, event) {
	if(SubmenuIntervalId[element_id])	clearInterval(SubmenuIntervalId[element_id]);
	if (element == undefined) {
		return false;
	}
	
	if(id == ""){
		element_id = element;
		// UI要素を取得
		var u = event.srcElement;
		if(!u) return;
		// UI要素の座標を取得
		var p = getElementPosition(u);
		// UI要素の高さを取得
		var h = u.clientHeight;
		$(element_id).style.top = 97 + h +'px';
		$(element_id).style.left = p.x+'px';
		$(element_id).style.display = 'block';
	} else {
		if (element_id != false) {
			cxCloser(element_id);
		}
		element_id = element + '_' + id;
		// UI要素を取得
		//if(event.srcElement!==o) return;
		var u = event.srcElement || event.target;
		if(!u) return;
		// DIV > IMG という構造で同じ位置にあるため、offsetTopが2倍されてしまう ???
		if(u.tagName=='IMG') u = u.parentNode;
		// UI要素の座標を取得
		var p = getElementPosition(u);
		// UI要素の幅を取得
		var w = u.clientWidth + 2;
		$(element_id).style.top = p.y - 3 +'px';
		$(element_id).style.left = p.x + w - 5 +'px';
		$(element_id).style.display = 'block';
		prev_submenu_id = id;
	}
}


var totalcheckSubmenuIntervalId;

function cxTotalCheckCloser(id) {
	//フラッシュ(かん動)を表示する（ページプロパティレイヤーがある場合は、ページプロパティレイヤーが閉じていれば表示する）
	if($('cms8341-property')) {
		if($('flashcontent') && $('cms8341-property').style.display == 'none') $('flashcontent').style.visibility = '';
	} else {
		if($('flashcontent')) $('flashcontent').style.visibility = '';
	}
	
	$(ele_id).style.display = 'none';
	clearInterval(totalcheckSubmenuIntervalId);
}

function cxTotalCheckSubmenuOff(id) {
	totalcheckSubmenuIntervalId = setInterval("cxTotalCheckCloser('"+id+"')",100);
}

function cxTotalCheckTimerControll(event, id) {
	var eventType = event.type;
	if(eventType=='mouseout') {
		cxTotalCheckSubmenuOff(id)
	} else {
		if(totalcheckSubmenuIntervalId)	clearInterval(totalcheckSubmenuIntervalId);
	}
}

//	ele_id非固定関数使用時用関数	2008/10追加
var SubmenuIntervalId = new Array();
function cxSubmenuOff(id, element) {
	if(id == ""){
		element_id = element;
	}
	else {
		element_id = element + '_' + id;
	}
	SubmenuIntervalId[element_id] = setInterval("cxCloser('"+element_id+"')",100);
}
function cxCloser(element_id) {
	$(element_id).style.display = 'none';
	clearInterval(SubmenuIntervalId[element_id]);
}
function cxTimerControll(id, element, event) {
	var prev_eventType = event.type;
	if(prev_eventType=='mouseout') {
		cxSubmenuOff(id, element)
	} else {
		if(id == ""){
			element_id = element;
		}
		else {
			element_id = element + '_' + id;
		}
		if(SubmenuIntervalId[element_id])	clearInterval(SubmenuIntervalId[element_id]);
	}
}


function cxComboHidden(exc){
	if(exc == undefined)exc = Array(0);
	oElms = document.getElementsByTagName("select");	
	for(i = 0; i < oElms.length; i++){
		flg = 0;
		if($(exc)){
			for(j = 0; j < exc.length; j++){
				if(oElms[i].id == exc[j])flg = 1;
			}
		}
		if(flg == 0){
			oElms[i].style.visibility = 'hidden';
		}
	}
	//テンプレートIDが存在する場合
	if($('cms_template_id')){
		//フラッシュ動画
		if($('cms_template_kanko_type') && $F('cms_template_kanko_type') == KANKO_TYPE_FLASH_VIDEO){
			//フラッシュの表示を消す
			if($('flashcontent')) $('flashcontent').style.visibility = 'hidden';
		}
	}
}

function cxComboVisible(id){
	if(id == undefined){
		oElms = document.getElementsByTagName("select");	
	} else {
		oElms = $(id).getElementsByTagName("select");	
	}
	for(i = 0; i < oElms.length; i++){
		if(oElms[i].id != "cms_template_id"){
			oElms[i].style.visibility = 'visible';
		}
	}
	//プロパティレイヤーが表示されていない場合
	if(!$('cms8341-property') || $('cms8341-property').style.display == 'none'){
		//テンプレートIDが存在する場合
		if($('cms_template_id')){
			//フラッシュ動画
			if($('cms_template_kanko_type') && $F('cms_template_kanko_type') == KANKO_TYPE_FLASH_VIDEO){
				//フラッシュを表示する
				if($('flashcontent')) $('flashcontent').style.visibility = '';
			}
		}
	}
}

/**
 * 操作ボタンON/OFF切り替え
 * 
 * @param flg ボタン切り替えフラグ 0 ： OFF 1 ： ON
 * @return false;
 */
function cxChangeOperationButton(flg){
	//ボタンON
	if(flg == FLAG_ON){
		//編集完了ボタン
		if($('btn_complete')){
			$('btn_complete').innerHTML = $('btn_complete_on').innerHTML;
			$('btn_complete').firstChild.onclick = $('btn_complete_on').firstChild.onclick;
		}
		//一時保存ボタン
		if($('btn_save')){
			$('btn_save').innerHTML = $('btn_save_on').innerHTML;
			$('btn_save').firstChild.onclick = $('btn_save_on').firstChild.onclick;
		}
		//プレビュー
		if($('btn_preview')){
			$('btn_preview').innerHTML = $('btn_preview_on').innerHTML;
			$('btn_preview').firstChild.onclick = $('btn_preview_on').firstChild.onclick;
		}
		if($('btn_preview_mobile')){
			$('btn_preview_mobile').src = $('btn_preview_mobile_on').src;
			$('btn_preview_mobile').onclick = $('btn_preview_mobile_on').onclick;
			$('btn_preview_mobile').onmouseover = $('btn_preview_mobile_on').onmouseover;
			$('btn_preview_mobile').onmouseout = $('btn_preview_mobile_on').onmouseout;
			$('btn_preview_mobile').onmousedown = $('btn_preview_mobile_on').onmousedown;
		}
		//各種チェック
		if($('btn_totalcheck')){
			$('btn_totalcheck').src = $('btn_totalcheck_on').src;
			$('btn_totalcheck').onclick = $('btn_totalcheck_on').onclick;
			$('btn_totalcheck').onmouseover = $('btn_totalcheck_on').onmouseover;
			$('btn_totalcheck').onmouseout = $('btn_totalcheck_on').onmouseout;
			$('btn_totalcheck').onmousedown = $('btn_totalcheck_on').onmousedown;
		}
		//プロパティ
		if($('btn_property')){
			$('btn_property').innerHTML = $('btn_property_on').innerHTML;
			$('btn_property').firstChild.onclick = $('btn_property_on').firstChild.onclick;
		}
		//閉じる
		if($('btn_close')){
			$('btn_close').innerHTML = $('btn_close_on').innerHTML;
			$('btn_close').firstChild.onclick = $('btn_close_on').firstChild.onclick;
		}
	}
	//ボタンOFF
	else{
		//編集完了ボタン
		if($('btn_complete')) $('btn_complete').innerHTML = $('btn_complete_off').innerHTML;
		//一時保存ボタン
		if($('btn_save')) $('btn_save').innerHTML = $('btn_save_off').innerHTML;
		//プレビュー
		if($('btn_preview')) $('btn_preview').innerHTML = $('btn_preview_off').innerHTML;
		if($('btn_preview_mobile')){
			$('btn_preview_mobile').src = $('btn_preview_mobile_off').src;
			$('btn_preview_mobile').onclick = $('btn_preview_mobile_off').onclick;
			$('btn_preview_mobile').onmouseover = $('btn_preview_mobile_off').onmouseover;
			$('btn_preview_mobile').onmouseout = $('btn_preview_mobile_off').onmouseout;
			$('btn_preview_mobile').onmousedown = $('btn_preview_mobile_off').onmousedown;
		}
		//各種チェック
		if($('btn_totalcheck')){
			$('btn_totalcheck').src = $('btn_totalcheck_off').src;
			$('btn_totalcheck').onclick = $('btn_totalcheck_off').onclick;
			$('btn_totalcheck').onmouseover = $('btn_totalcheck_off').onmouseover;
			$('btn_totalcheck').onmouseout = $('btn_totalcheck_off').onmouseout;
			$('btn_totalcheck').onmousedown = $('btn_totalcheck_off').onmousedown;
		}
		//プロパティ
		if($('btn_property')) $('btn_property').innerHTML = $('btn_property_off').innerHTML;
		//閉じる
		if($('btn_close')) $('btn_close').innerHTML = $('btn_close_off').innerHTML;
	}
}

/**
 * サーバ上にあるファイルの存在チェックを行う(Ajaxの同期処理)
 * 
 * @param file_path ファイルのパス
 * @return ファイルが存在する場合は、TRUE。そうでない場合は、FALSEを返す。
 */
function file_exists(file_path){
	//引数のチェック
	if(file_path == "") return false;

	//Ajaxを使い、PHPの関数を実行
	var request = new Ajax.Request(
		baseUrl + 'admin/page/common/kando/func_js/file_exists_for_js.php',
		{
			method: 'post',
			postBody: 'file_path=' + file_path,
			asynchronous:false,
			//失敗した場合
			onFailure: function(request){
				alert('サーバアクセス中にエラーが発生しました');
				return false;
			}
		}
	);
	try{
		var result = eval('(' + request.transport.responseText + ')');
		if(result == true) return true;
		else return false;
	}
	catch(err){
		return false;
	}
}

/**
 * 配列に値があるかチェックする
 * 
 * @param needle 探す値
 * @param haystack 配列
 * @param strict 型チェックの有無
 * @return 
 */
function in_array(needle,haystack,strict){
	//変数の宣言
	var ret_flg = false;
	var key = "";

	//引数が無くてもエラーにならないように。
	strict = !!strict;

	//チェック
	for(key in haystack){
		if((strict && haystack[key] === needle) || (!strict && haystack[key] == needle)){
			ret_flg = true;
			break;
		}
	}

	return ret_flg;
}

/**
 * ファイルサイズに3桁ごと「,」を付与する
 * 
 * @param val 3桁ごとに区切る数字（ファイルサイズ）
 * @return 3桁ごとに区切られた数字
 */
function numEdit(val){
	val += "";
	var cnt = 0;
	var ret = "";
	var len = val.length;
	for(var i = 0;i < len;i++){
		var s = val.substring(i,i + 1);
		ret += s;
		cnt++;
		if((len - cnt) / 3 > 0 && (len - cnt) % 3 == 0) ret += ',';
	}
	return ret;
}

/**
 * 添付ファイル表記の挿入で使用する変数を作成
 * 
 * @return 変数の擬似連想配列(Object)
 */
function getAddFileDetailExp(){
	//拡張子変換ルール
	var obj = new Object();
	//配列を作成
	var file_detail_ary = ADD_FILE_DETAIL_EXP.split(",")
	for(i = 0;i < file_detail_ary.length / 4;i++){
		$exp = file_detail_ary[0 + i * 4];
		//配列を定義
		obj[$exp] = new Object();
		obj[$exp]['JP'] = file_detail_ary[1 + i * 4];
		obj[$exp]['EN'] = file_detail_ary[2 + i * 4];
		obj[$exp]['CLASS'] = file_detail_ary[3 + i * 4];
	}
	return obj;
}

/**
 * 正規表現のメタ文字をエスケープする
 * @param str 文字列
 * @return 正規表現のメタ文字をエスケープした文字列
 */
function reg_replace(pStr){
	//エスケープするメタ文字
	var ary = [['\\','\\\\'],['/','\\\/'],['.','\\\.'],['*','\\\*'],['+','\\\+'],['-','\\\-'],['?','\\\?'],['(','\\\('],[')','\\\)'],['[','\\\['],[']','\\\]'],['|','\\\|']];
	//エスケープ処理
	for(var i = 0;i < ary.length;i++){
		pStr = pStr.replace(ary[i][0],ary[i][1]);
	}
	return pStr;
}

function cxEscapeHtmlChars(str) {
	return str.replace(/["<>&]/g,function($0){
		switch($0) {
			case '<':
				return "&lt;";
			case '>':
				return "&gt;";
			case '"':
				return "&quot;";
			case "&":
				return "&amp;";
		}
	 });
}

/**
 * HTML用にエスケープした文字を元に戻す
 * @param str 文字列
 * @return HTML用エスケープを元に戻した文字列
 */
function cxUnEscapeHtmlChars(str) {
	return str.replace(/(&lt;|&gt;|&quot;|&amp;)/g,function($0){
		switch($0) {
			case '&lt;':
				return "<";
			case '&gt;':
				return ">";
			case '&quot;':
				return '"';
			case '&amp;':
				return "&";
		}
	 });
}

/********** 二度押し防止アクション START************/
// window の Load イベントを取得する。
window.onload = window_Load;
	
function window_Load() {
	var i;

	// 全リンクのクリックイベントを submittableObject_Click で取得する。
	for (i = 0; i < document.links.length; i ++) {
		var item = document.links[i]
		Object.Aspect.around(item, "onclick", checkLoading);
	}

	if(document.getElementsByTagName("form").length == 0){
		return true;
	}

	// 全ボタンのクリックイベントを submittableObject_Click で取得する。
	for (i = 0; i < document.forms[0].elements.length; i ++) {
		var item = document.forms[0].elements[i]
		if (item.type == "button" ||
			item.type == "submit" ||
			item.type == "reset") {
		Object.Aspect.around(item, "onclick", checkLoading);
		}
	}

	return true;
}

//2度押し抑止アスペクト
var checkLoading = function(invocation) {
	if (isDocumentLoading()) {
		alert("処理中です…");
		return false;
	}

	return invocation.proceed();
}

//画面描画が終わったかどうか
function isDocumentLoading() {
	return (document.readyState != null &&
			document.readyState != "complete");
}

//アスペクト用
Object.Aspect = {
	_around: function(target, methodName, aspect) {
		var method = target[methodName];
		target[methodName] = function() {
			var invocation = {
				"target" : this,
				"method" : method,
				"methodName" : methodName,
				"arguments" : arguments,
				"proceed" : function() {
					if (!method) {
						return true;
					}
					return method.apply(target, this.arguments);
				}
			};
			return aspect.apply(null, [invocation]);
		};
	},
	around: function(target, methodName, aspect) {
		this._around(target, methodName, aspect);
	}
}
/********** 二度押し防止アクション END************/

// モーダルダイヤログ表示用
function cxShowModalDialog(path,name,status){
	dd = new Date();
	if(path.indexOf("?") == -1){
		path += "?refprm="+dd.getTime();
	} else {
		path += "&refprm="+dd.getTime();
	}
	retObj = showModalDialog(path,name,status);
	return retObj;
}
/**
 * 小窓表示
 * @param path 小窓に表示するファイルのURL
 * @param name ウィンドウ名
 * @param status パラメータ
 * @return 成功 -> ウィンドウオブジェクト 失敗 -> null
 */
function cxShowWindow(path,name,status){
	dd = new Date();
	if(path.indexOf("?") == -1){
		path += "?refprm="+dd.getTime();
	} else {
		path += "&refprm="+dd.getTime();
	}
	retObj = window.open(path,name,status);
	return retObj;
}

// 編集画面の閉じる対応
function cxEditNonProp(){
	edit_closet_flg = false;
}

// 日付チェックの共通アラート表示
function disp_date_error(dc,focus_id){
	msg = new Array();
	msg = msg.concat(dc);
	if (msg.length > 0) {
		msg_str = msg.join('\n');
		alert(msg_str);
		if(focus_id)$(focus_id).focus();
		return false;
	}
	return true;
}

// 全ての文字列 s1 を s2 に置き換える
function replaceAll(expression, org, dest){
	return expression.split(org).join(dest);
} 

//IE8対応用ラジオボタンチェック
function isSelectCheck(id) {
	var select_ch_flg = false;
	var select = document.getElementsByName(id);
	for(var i=0; i<select.length; i++) {
		if (select[i].checked == true) {
			select_ch_flg = true;
			break;
		}
	}
	return select_ch_flg;
}
/**
 * IEのバージョン取得
 * @return TRUE->Varの数字 FALSE->IE以外
 */
function cxGetIeVersion(){
	
	//ブラウザのエンジン名
	var user_agent = window.navigator.userAgent.toLowerCase();
	//ブラウザのバージョン
	var app_ver = window.navigator.appVersion.toLowerCase();
	// IEの場合
	if (user_agent.indexOf("msie") > -1) {
		// IE6
		if (app_ver.indexOf("msie 6.0") > -1) return 6;
		// IE7
		if (app_ver.indexOf("msie 7.0") > -1) return 7;
		// IE8
		if (app_ver.indexOf("msie 8.0") > -1) return 8;
		// IE9
		if (app_ver.indexOf("msie 9.0") > -1) return 9;
		// IE10
		if (app_ver.indexOf("msie 10.0") > -1) return 10;
	}
	// IE11
	else if (user_agent.indexOf("trident") > -1) {
		if (app_ver.indexOf("rv:11.0") > -1) return 11;
	}
	// IE以外のブラウザ
	return false;
}
/**
 * 文字列をDOMに変換する
 * @param str 変換対象文字列
 * @return 文字列をDOMに変換したもの(DIVに入っている）
 */
function String2DOM(str){
	var n = document.createElement("div");
	n.innerHTML = str;
	return n;
}

/**
 * 連続する半角スペース変換
 * @palam		$rep_str 置換対象文字列
 * @return		置換後文字列
 *
 * 【備考】
 *	半角スペース以外の文字列が含まれない場合は置換しない。
 */
function replace_consecutive_space(rep_str){
	//半スペのみは置換しない
	if (rep_str.replace(/(^\s+)|(\s+$)/g, "") == '') {
		return rep_str;
	}
	//置換
	rep_str = rep_str.replace(/( )( +)/g, function(){return arguments[1] + arguments[2].replace(/ /g,'&nbsp;')});
	return rep_str;
}

function setCookie(cname, cvalue, exdays) {
	var newcookie = cname + "=" + cvalue + ";"
	if (exdays > 0) {
		var d = new Date();
		d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
		newcookie += "expires=" + d.toUTCString() + ";";
	}
	newcookie += "path=/";
	document.cookie = newcookie;
}

function getCookie(cname) {
	var name = cname + "=";
	var ca = document.cookie.split(';');
	for (var i = 0; i < ca.length; i++) {
		var c = ca[i];
		while (c.charAt(0) == ' ') {
			c = c.substring(1);
		}
		if (c.indexOf(name) == 0) {
			return c.substring(name.length, c.length);
		}
	}
	return "";
}

function deleteCookie(cname) {
	document.cookie = cname + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;path=/';
}

function getSelectedRadioValue(name) {
	var radios = document.getElementsByName(name);
	for (var i = 0; i < radios.length; i++) {
		if (radios[i].checked) {
			return radios[i].value;
		}
	}
	return null;
}

function setSelectedRadio(name, value) {
	var radios = document.getElementsByName(name);
	for (var i = 0; i < radios.length; i++) {
		if (radios[i].value === value) {
			radios[i].checked = true;
			return true;
		}
	}
	return null;
}

function cxCreateCover(coverSetting) {
	if (coverSetting == undefined || coverSetting == null || coverSetting == COVER_SETTING.NOCOVER) {
		return undefined;
	}
	var cover = document.createElement('div');
	cover.style.position = 'absolute';
	cover.style.top = 0;
	cover.style.left = 0;
	// make it cover whole page
	cover.style.width = window.top.document.documentElement.scrollWidth + 'px';
	cover.style.height = window.top.document.documentElement.scrollHeight + 'px';
	cover.style.backgroundColor = 'rgba(0,0,0,' + coverSetting.opacity + ')';
	cover.style.zIndex = 99999;
	return cover;
}

/**
 * レイヤー中央表示/非表示
 *
 * t: id of layer
 * sw: = 1 then show layer, = 0 then hide layer
 * width: width of layer
 * height: height of layer
 * coverSetting: COVER_SETTING enum
**/
function cxLayer(t,sw,width,height,coverSetting){
	if (sw==1) {
		if (width && height) {
			//var wcw = window.screen.width;
			//var wch = document.body.clientHeight;
			var wcw = (window.document.documentElement.clientWidth > 0 ? window.document.documentElement.clientWidth : window.document.body.clientWidth);
			var wch = (window.document.documentElement.clientHeight > 0 ? window.document.documentElement.clientHeight : window.document.body.clientHeight);
			var tx = (wcw - width) / 2;
			tx = (tx < 0 ? 0 : tx);
			var ty = (wch - height) / 2;
			//ty = (ty < 175 ? 175 : ty);
			ty = (ty < 0 ? 0 : ty);
			var sx = (document.compatMode == "CSS1Compat") ? document.documentElement.scrollLeft: document.body.scrollLeft;
			var st = (document.compatMode == "CSS1Compat") ? document.documentElement.scrollTop: document.body.scrollTop;
			var x = sx + tx;
			var y = st + ty;
			//IE8以上
			if (cxGetIeVersion() >= 8) {
				if ($(t).parentNode.offsetParent) {
					y = (st + ty - $(t).parentNode.offsetParent.offsetTop);
				}
			}
			if (navigator.userAgent.indexOf('Edge') > -1) {
				$(t).style.left = window.pageXOffset + x + 'px';
				$(t).style.top = window.pageYOffset + y + 'px';
			}
			else {
				$(t).style.left = x + 'px';
				$(t).style.top = y + 'px';
			}
			//ヘッダーより上に出す
			$(t).style.zIndex = 99999;
			
			var cover = cxCreateCover(coverSetting);
			if (cover) {
				$(t).parentNode.insertBefore(cover, $(t));
				$(t).cover = cover;
			}
		}
		$(t).style.display = 'block';
	} else {
		if ($(t).cover != undefined) {
			if ($(t).cover != null) {
				$(t).cover.remove();
			}
			$(t).cover = undefined;
		}
		$(t).style.display = 'none';
	}
}

/**
 * Display dialog in iframe layer
 *
 * path: url to display in iframe
 * w: width
 * h: height
 * callback: call this func inside iframe to return data to parent window
 * name: iframe name
 * coverSetting: COVER_SETTING enum
 * addCloseBtn: add a close button for iframe
 * autoResize: adjust w and h after load
 * args: dialogArguments param
**/
function cxIframeLayer(path, w, h, coverSetting, name, callback, addCloseBtn, autoResize, args) {
	var iframe = top.document.createElement('iframe');
	top.document.body.appendChild(iframe);
	var cover = cxCreateCover(coverSetting);
	if (cover) {
		iframe.parentNode.insertBefore(cover, iframe);
		iframe.cover = cover;
	}
	var cxIframeLayerCallback = function(retObj) {
		if (retObj != undefined && callback != undefined) {
			callback(retObj);
		}
		if (iframe.cover != undefined && iframe.cover != null) {
			iframe.cover.remove();
		}
		iframe.remove();
	};
	iframe.cxIframeLayerCallback = cxIframeLayerCallback;
	iframe.onload = function() {
		iframe.autoUpdateWH = function() {
			var iframeNewWidth = iframe.contentWindow.document.body.scrollWidth;
			if (iframeNewWidth > w) {
				iframeNewWidth = w;
			}
			var iframeNewHeight = iframe.contentWindow.document.body.scrollHeight + (addCloseBtn ? 40 : 0);
			if (iframeNewHeight > h) {
				iframeNewHeight = h;
			}
			updateWHForIframe(iframeNewWidth, iframeNewHeight);
		}
		if (autoResize) {
			iframe.autoUpdateWH();
		}
		
		if (iframe.contentWindow != undefined && iframe.contentWindow != null) {
			iframe.contentWindow.cxIframeLayerCallback = cxIframeLayerCallback
			var body = iframe.contentWindow.document.body;
			body.style.backgroundColor = '#fff';
			if (addCloseBtn) {
				var closeBtn = iframe.contentWindow.document.createElement('div');
				closeBtn.innerHTML = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader"><tbody><tr><td align="left" valign="middle"></td><td width="78" align="right" valign="middle"><a href="javascript:cxIframeLayerCallback();"><img src="/cms8341/admin/images/btn/btn_close.jpg" alt="閉じる" width="58" height="19" border="0" style="margin: 4px 10px;"></a></td></tr></tbody></table>';
				body.insertBefore(closeBtn, body.firstElementChild);
			}
		}
	}
	iframe.src = path;
	iframe.contentWindow.name = name;
	if (args) {
		iframe.args = args;
	}
	else {
		iframe.args = this;
	}
	if (!autoResize) {
		updateWHForIframe(w, h);
	}
	function updateWHForIframe(w, h) {
		if (w && h) {
			//var wcw = window.screen.width;
			//var wch = document.body.clientHeight;
			var wcw = (window.top.document.documentElement.clientWidth > 0 ? window.top.document.documentElement.clientWidth : window.top.document.body.clientWidth);
			var wch = (window.top.document.documentElement.clientHeight > 0 ? window.top.document.documentElement.clientHeight : window.top.document.body.clientHeight);
			var tx = (wcw - w) / 2;
			tx = (tx < 0 ? 0 : tx);
			var ty = (wch - h) / 2;
			//ty = (ty < 175 ? 175 : ty);
			ty = (ty < 0 ? 0 : ty);
			var sx = (top.document.compatMode == "CSS1Compat") ? top.document.documentElement.scrollLeft: top.document.body.scrollLeft;
			var st = (top.document.compatMode == "CSS1Compat") ? top.document.documentElement.scrollTop: top.document.body.scrollTop;
			var x = sx + tx;
			var y = st + ty;
			//IE8以上
			if (cxGetIeVersion() >= 8) {
				if(iframe.parentNode.offsetParent) {
					y = (st + ty - iframe.parentNode.offsetParent.offsetTop);
				}
			}
			
			iframe.style.position = 'absolute';
			if (navigator.userAgent.indexOf('Edge') > -1) {
				iframe.style.left = window.top.pageXOffset + x + 'px';
				iframe.style.top = window.top.pageYOffset + y + 'px';
			}
			else {
				iframe.style.left = x + 'px';
				iframe.style.top = y + 'px';
			}
			iframe.style.zIndex = 99999;
			iframe.style.borderColor = 'transparent';
			iframe.style.width = w + 'px';
			iframe.style.height = h + 'px';
		}
	}
	return iframe.contentWindow;
}