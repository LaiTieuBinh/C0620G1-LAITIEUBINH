/*
 *
 */
cxPreImages(cms8341admin_path+'/images/menu/logout01_btn.jpg',
			cms8341admin_path+'/images/menu/logout02_btn.jpg');


//通信失敗処理
function cxFailure() {
	alert('情報取得中に通信エラーが発生しました');
}

//外部ページの取り込み
function cxSubmit() {
	var msg = new Array();
	if (!$('FrmZipnm').value) {
		msg.push('取り込みファイルを入力してください。');
	} else {
		var filetype = $('FrmZipnm').value.replace(/^.*\.([^\.]+$)/, '$1');
		filetype = filetype.toLowerCase();
		if (filetype != 'zip') msg.push('取り込みファイルはzip形式でアップロードしてください。');
		//
		// 「[a-z]:\～」または「\\～」で始まるパスの指定のみを許容する
		var filepath = $('FrmZipnm').value.match(/^([a-z]:\\|\\\\).+/i);
		if(!filepath) {
			msg.push('取り込みファイルの参照先を正しく指定してください。');
		}
	}
	dc = cxDateCheckNew('cms_pd', 'ymdh', 1, '公開期間');
	msg = msg.concat(dc);
	
	// 取り込み後のステータス選択チェック
	if (isSelectCheck('cms_status') != true) {
		msg.push('取り込み後のステータスを指定してください。');
	}
	if (!$('cms_user_id').value) msg.push('ページ作成者を選択してください。');
	// エラー表示
	if (msg.length > 0) {
		cxComboHidden(new Array("cms_template_id"));
		$('cms8341-errormsg').innerHTML = msg.join("<br>");
		cxLayer('cms8341-error',1,500,500);
		return false;
	}
	$('cms_filename').value = $('FrmZipnm').value;
	document.cms_fImport.submit();
	return false;
}

//組織選択
function cxChangeDept(lv, val) {
	//reset
	if(val=="") {
		var t = lv + 1;
		for(var i=t;i<=3;i++) {
			var obj = $('cms_target'+i);
			while(obj.length>1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "                ";
		}
		var obj = $('cms_user_id');
		while(obj.length>1) {
			obj.options[1] = null;
		}
		obj.options[0].text = "                ";
	} else {
		if (lv < 3) {
			//get data
			lv++;
			var prm = 'level='+lv+'&code='+val;
			cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
		} else {
			var prm = 'code='+val;
			cxAjaxCommand('cxGetUserCombo', prm, cxGetUserComboOK);
		}
	}
}
function cxGetDeptComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Department') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    for (var i = level; i <= 3; i++) {
        var obj = $('cms_target' + i);
        while (obj.length > 1) {
            obj.options[1] = null;
        }
        obj.options[0].text = "                ";
    }
    var obj = $('cms_user_id');
    while (obj.length > 1) {
        obj.options[1] = null;
    }
    obj.options[0].text = "                ";
    var obj = $('cms_target' + level);
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i = 0; i < xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        if (nodeL.textContent == " " || nodeL.textContent == "　")
            nodeL.textContent = "指定なし";
        obj.length++;
        obj.options[i + 1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        obj.options[i + 1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}
function cxGetUserComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'User') {
        cxFailure();
        return;
    }
    var obj = $('cms_user_id');
    while (obj.length > 1) {
        obj.options[1] = null;
    }
    obj.options[0].text = "------- 未選択 -------";
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i = 0; i < xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        obj.length++;
        obj.options[i + 1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        obj.options[i + 1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}

function cxErrorClose() {
	cxComboVisible();
	cxLayer('cms8341-error',0);
}
