/*
 * カレンダー用javascript
 */
//contentsmenu preload images
cxPreImages(cms8341admin_path+'/images/calendar/m_1.jpg',
			cms8341admin_path+'/images/calendar/m_2.jpg',
			cms8341admin_path+'/images/calendar/m_3.jpg',
			cms8341admin_path+'/images/calendar/m_4.jpg',
			cms8341admin_path+'/images/calendar/m_5.jpg',
			cms8341admin_path+'/images/calendar/m_6.jpg',
			cms8341admin_path+'/images/calendar/m_7.jpg',
			cms8341admin_path+'/images/calendar/m_8.jpg',
			cms8341admin_path+'/images/calendar/m_9.jpg',
			cms8341admin_path+'/images/calendar/m_10.jpg',
			cms8341admin_path+'/images/calendar/m_11.jpg',
			cms8341admin_path+'/images/calendar/m_12.jpg',
			cms8341admin_path+'/images/calendar/btn_prev.jpg',
			cms8341admin_path+'/images/calendar/btn_next.jpg',
			cms8341admin_path+'/images/calendar/th_sun.jpg',
			cms8341admin_path+'/images/calendar/th_mon.jpg',
			cms8341admin_path+'/images/calendar/th_tue.jpg',
			cms8341admin_path+'/images/calendar/th_wed.jpg',
			cms8341admin_path+'/images/calendar/th_thu.jpg',
			cms8341admin_path+'/images/calendar/th_fri.jpg',
			cms8341admin_path+'/images/calendar/th_sat.jpg'
);

/**
 * 指定年月の日数を取得
 * @param y 取得する対象【年】
 * @param m　取得する対象【月】
 * @returns 取得した日数
 */
function cxGetDays(y,m){
	var day;
	var days
	switch(m){
		case 1:
			days = 31;
			break;
		case 2:
			//うるう年のチェック
			if(cxLeapYear(y)){
				days = 29;
			}else{
				days = 28;
			}
			break;
		case 3:
			days = 31;
			break;
		case 4:
			days = 30;
			break;
		case 5:
			days = 31;
			break;
		case 6:
			days = 30;
			break;
		case 7:
			days = 31;
			break;
		case 8:
			days = 31;
			break;
		case 9:
			days = 30;
			break;
		case 10:
			days = 31;
			break;
		case 11:
			days = 30;
			break;
		case 12:
			days = 31;
			break;
		default:
			days = 0;
	}
	return days;
}

/**
 * うるう年のチェック
 * @param y チェック対象年
 * @returns true : うるう年 | false : うるう年以外
 */
function cxLeapYear(y){
	if(y%4 == 0 && y%100!= 0 || y%400 == 0){
        return true;
	}else{
		return false;
	}
}

/**
 * カレンダー生成
 * @param y 生成する対象【年】
 * @param m 生成する対象【月】
 * @returns 生成したカレンダーHTML
 */
function cxCalendar(y,m) {
	//init
	var set_y = y;
	var set_m = m;
	//指定年月の日数を取得
	var days  = cxGetDays(set_y,set_m);
	//指定年月における1日の曜日取得
	var tmp_m = set_m - 1;
	var firstday =	new Date(set_y,tmp_m,1);
	var startpos = firstday.getDay(); 
	//カレンダーに必要な行数
	var rows  = 0;
	rows = ( startpos + days ) / 7;
	rows = Math.floor(rows);
	temp = ( startpos + days ) % 7;
	if(temp!=0) rows++;
	//カレンダー本体生成
	var html = '';
	//
	html  = '<table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-bottom:solid 1px #005BAC;">';
	html += '<tr>';
	html += '<td align="left" valign="middle">';
	html += '<p style="margin:0px;padding:9px 12px 4px 12px">';
	html += '<img src="'+cms8341admin_path+'/images/calendar/m_'+set_m+'.jpg" alt=""></p>';
	html += '</td>';
	html += '<td align="right" valign="bottom">';
	html += '<p style="margin:0px;padding:9px 12px 4px 12px;color:#666666;font-size:18px;font-weight:bold">';
	html += set_y+'年</p>';
	html += '</td>';
	html += '</tr>';
	html += '</table>';
	html += '<table width="422" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse;border:solid 1px #010101;background-color:#F0F0F0;margin-top:15px;">';
	html += '<tr>';
	html += '<td width="90" align="left" valign="top" style="border:solid 1px #010101;">';
	html += '<a href="javascript:" onClick="cxPrevCal('+set_y+','+set_m+')"><img src="'+cms8341admin_path+'/images/calendar/btn_prev.jpg" alt="前の月" width="90" height="18" border="0"></a>';
	html += '</td>';
	html += '<td align="left" valign="top">&nbsp;</td>';
	html += '<td width="87" align="right" valign="top" style="border:solid 1px #010101;">';
	html += '<a href="javascript:" onClick="cxNextCal('+set_y+','+set_m+')"><img src="'+cms8341admin_path+'/images/calendar/btn_next.jpg" alt="次の月" width="87" height="18" border="0"></a>';
	html += '</td>';
	html += '</tr>';
	html += '</table>';
	html += '<table border="0" cellspacing="0" cellpadding="0" class="cms_calbox">';
	html += '<tr>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_sun.jpg" alt="日曜日" width="58" height="19"></td>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_mon.jpg" alt="月曜日" width="58" height="19"></td>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_tue.jpg" alt="火曜日" width="58" height="19"></td>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_wed.jpg" alt="水曜日" width="58" height="19"></td>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_thu.jpg" alt="木曜日" width="58" height="19"></td>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_fri.jpg" alt="金曜日" width="58" height="19"></td>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_sat.jpg" alt="土曜日" width="58" height="19"></td>';
	html += '</tr>';
	//
	for(i=0;i<rows;i++) {
		html += '<tr>';
		if(i==0) {
			//開始行
			for(j=0;j<startpos;j++) {
				if(j==0) {
					html += '<td align="center" valign="middle" class="cms_sun">&nbsp;</td>';
				} else if(j==6) {
					html += '<td align="center" valign="middle" class="cms_sat">&nbsp;</td>';
				} else {
					html += '<td align="center" valign="middle" class="cms_day">&nbsp;</td>';
				}
			}
			for(j=startpos;j<7;j++) {
				day = j - startpos + 1;
				if(j==0) {
					html += '<td align="center" valign="middle" class="cms_sun"';
				} else if(j==6) {
					html += '<td align="center" valign="middle" class="cms_sat"';
				} else {
					html += '<td align="center" valign="middle" class="cms_day"';
				}
				if(set_y==cms_yy && set_m==cms_mm && day==cms_dd){
					//当日処理
					html += ' id="cms_today">';
				} else {
					html += '>';
				}
				html += '<a href="javascript:" onClick="cxSetDate('+set_y+','+set_m+','+day+')">' + day + '</a>';
				html += '</td>';
			}
		} else if(i==rows-1) {
			//最終行
			for(k=1;k<=7;k++) {
				day++;
				if(day<=days) {
					if(k==1) {
						html += '<td align="center" valign="middle" class="cms_sun"';
					} else if(k==7) {
						html += '<td align="center" valign="middle" class="cms_sat"';
					} else {
						html += '<td align="center" valign="middle" class="cms_day"';
					}
					if(set_y==cms_yy && set_m==cms_mm && day==cms_dd){
						//当日処理
						html += ' id="cms_today">';
					} else {
						html += '>';
					}
					html += '<a href="javascript:" onClick="cxSetDate('+set_y+','+set_m+','+day+')">' + day + '</a>';
					html += '</td>';
				} else {
					if(k==1) {			//日曜
						html += '<td align="center" valign="middle" class="cms_sun">&nbsp;</td>';
					} else if(k==7) {	//土曜
						html += '<td align="center" valign="middle" class="cms_sat">&nbsp;</td>';
					} else {			//平日
						html += '<td align="center" valign="middle" class="cms_day">&nbsp;</td>';
					}
				}
			}
		} else {
			for(k=1;k<=7;k++) {
				day++;
				if(k==1) {
					html += '<td align="center" valign="middle" class="cms_sun"';
				} else if(k==7) {
					html += '<td align="center" valign="middle" class="cms_sat"';
				} else {
					html += '<td align="center" valign="middle" class="cms_day"';
				}
				if(set_y==cms_yy && set_m==cms_mm && day==cms_dd){
					//当日処理
					html += ' id="cms_today">';
				} else {
					html += '>';
				}
				html += '<a href="javascript:" onClick="cxSetDate('+set_y+','+set_m+','+day+')">' + day + '</a>';
				html += '</td>';
			}
		}
		html += '</tr>';
	}
	html += '</table>';
	html += '<p align="left" style="margin:15px 30px;">日付を選択してください。</p>';
	//
	return html;
}
/**
 * カレンダーの前月を表示
 * @param y 表示中年月【年】
 * @param m 表示中年月【月】
 */
function cxPrevCal(y, m) {
	if(m==1) {
		y--;
		m = 12;
	} else {
		m--;
	}
	var html = cxCalendar(y,m);
	$('cms8341-calbody').innerHTML = html;
}
/**
 * カレンダーの次月を表示
 * @param y 表示中年月【年】
 * @param m 表示中年月【月】
 */
function cxNextCal(y, m) {
	if(m==12) {
		y++;
		m = 1;
	} else {
		m++;
	}
	var html = cxCalendar(y,m);
	$('cms8341-calbody').innerHTML = html;
}
/**
 * 選択された日付の挿入
 * @param sy 選択された日付【年】
 * @param sm 選択された日付【月】
 * @param sd 選択された日付【日】
 */
function cxSetDate(sy,sm,sd) {
	var flg = false;
	if ($('cms-pubend-Unrestricted-ws') && $('cms-pubend-Unrestricted-ws').checked) {
		flg = true;
		cxPublicEndUnrestricted();
	}
	else if ($('cms-pubend-Unrestricted-wf') && $('cms-pubend-Unrestricted-wf').checked) {
		flg = true;
		cxPublicEndUnrestricted();
	}
	else if ($('cms-pubend-Unrestricted-edit') && $('cms-pubend-Unrestricted-edit').checked) {
		flg = true;
		cxPublicEndUnrestricted();
	}

	cms_calTargetObj["yy"].value = sy;
	cms_calTargetObj["mm"].value = sm;
	cms_calTargetObj["dd"].value = sd;
	if(cms_calTargetObj["hh"]){
		cms_calTargetObj["hh"].focus();
	}
	// 非表示にしていたプルダウンを表示する
	if ($('cms_cate1')) $('cms_cate1').style.visibility = 'visible';
	if ($('cms_cate2')) $('cms_cate2').style.visibility = 'visible';
	if ($('cms_cate3')) $('cms_cate3').style.visibility = 'visible';
	if ($('cms_cate4')) $('cms_cate4').style.visibility = 'visible';
	if ($('cms_target1')) $('cms_target1').style.visibility = 'visible';
	if ($('cms_target2')) $('cms_target2').style.visibility = 'visible';
	if ($('cms_target3')) $('cms_target3').style.visibility = 'visible';
	if ($('cms_user_id')) $('cms_user_id').style.visibility = 'visible';
	if ($('cms_target1_c')) $('cms_target1_c').style.visibility = 'visible';
	if ($('cms_target2_c')) $('cms_target2_c').style.visibility = 'visible';
	if ($('cms_target3_c')) $('cms_target3_c').style.visibility = 'visible';
	if ($('cms_user_id_c')) $('cms_user_id_c').style.visibility = 'visible';
	
	for (var i=1; i<=30; i++) {
		if(!$('cms_inquiry_dept1_'+i))break;
		if($('cms_inquiry_dept1_'+i)) $('cms_inquiry_dept1_'+i).style.visibility = 'visible';
		if($('cms_inquiry_dept2_'+i)) $('cms_inquiry_dept2_'+i).style.visibility = 'visible';
		if($('cms_inquiry_dept3_'+i)) $('cms_inquiry_dept3_'+i).style.visibility = 'visible';
	}
	if ($('cms_submit')) $('cms_submit').style.visibility = 'visible';
	if ($('cms_inquiry_cnt')){
		for (var i=1; i<=Number($F('cms_inquiry_cnt')) + 1; i++) {
			if($('cms_inquiry_prop_dept1_'+i)) $('cms_inquiry_prop_dept1_'+i).style.visibility = 'visible';
			if($('cms_inquiry_prop_dept2_'+i)) $('cms_inquiry_prop_dept2_'+i).style.visibility = 'visible';
			if($('cms_inquiry_prop_dept3_'+i)) $('cms_inquiry_prop_dept3_'+i).style.visibility = 'visible';
		}
	}
	if ($('cms_prop_submit')) $('cms_prop_submit').style.visibility = 'visible';
	
	if (flg == true) {
		cxPublicEndUnrestricted();
	}
	cxCalendarClose();
}

var cms_today;
var cms_yy;
var cms_mm;
var cms_dd;	
var cms_calTargetObj = new Object();
/**
 * カレンダーレイヤー表示
 * @param ty カレンダー表示日付【年】
 * @param tm カレンダー表示日付【月】
 * @param td カレンダー表示日付【日】
 * @param th カレンダー表示日付【時】
 */
function cxCalendarSet(ty,tm,td,th) {
	//**日付の取得
	cms_today = new Date();
	cms_yy  = cms_today.getFullYear();
	cms_mm  = cms_today.getMonth() + 1;
	cms_dd  = cms_today.getDate();
	//**ターゲットの取得
	cms_calTargetObj["yy"] = $(ty);
	cms_calTargetObj["mm"] = $(tm);
	cms_calTargetObj["dd"] = $(td);
	if(th) cms_calTargetObj["hh"] = $(th);
	//**カレンダーの生成と表示
	var html;
	var setYY = $(ty).value;
	var setMM = $(tm).value;
	if(setYY && Number(setYY) >= 2000 && setMM && Number(setMM) > 0 && Number(setMM) < 13) {
		html = cxCalendar(Number(setYY),Number(setMM));
	} else {
		html = cxCalendar(cms_yy,cms_mm);
	}
	$('cms8341-calbody').innerHTML = html;
	cxLayer('cms8341-calendar',1,500,415);
}

// イベントカレンダー複数日
/**
 * チェックボックスタイプカレンダーの表示
 * @param id エレメントID
 */
function cxCheckboxCalendarSet(id) {
	// 日付の取得
	var cms_today = new Date();
	cms_yy  = cms_today.getFullYear();
	cms_mm  = cms_today.getMonth() + 1;
	cms_dd  = cms_today.getDate();
	
	// IDが指定されていない場合
	if (id == '' || id == null || id == undefined) {
		id = 'cms_pd';
	}
	
	// 選択中のデータをリセット
	cms_select_date = new Array();
	cms_select_all = new Array();
	
	// 入力欄から日付を取得
	var element_no = document.getElementById('cms_pd_count').value;
	for(var i=1;i<=element_no;i++) {
		// 要素が無ければスキップ
		if(document.getElementById(id + i +'sy') == null) {
			continue;
		}
		
		// 開始日を取得
		var start_year = document.getElementById(id + i + 'sy').value;
		var start_month = document.getElementById(id + i + 'sm').value;
		var start_day = document.getElementById(id + i + 'sd').value;
		
		// 終了日を取得
		var end_year = document.getElementById(id + i + 'ey').value;
		var end_month = document.getElementById(id + i + 'em').value;
		var end_day = document.getElementById(id + i + 'ed').value;
		
		// 開始日と終了日の差を取得
		var diff_day = cxCompareDate(start_year, start_month, start_day, end_year, end_month, end_day);
		
		// 開始日または終了日が正しく入力していない場合はスキップ
		if(diff_day === false) {
			continue;
		}
		
		// 開始日と終了日が異なる場合
		if(diff_day > 0) {
			// 期間を選択状態とする
			for(var j=0;j<=diff_day;j++) {
				var dt = cxCalcDate(start_year, start_month, start_day, j);
				cms_select_date[dt.getFullYear() + '_' + (dt.getMonth() + 1) + '_' + dt.getDate()] = true;
			}
		} else {
			// 選択状態とする
			cms_select_date[start_year + '_' + start_month + '_' + start_day] = true;
		}
	}
	
	html = cxCheckboxCalendar(cms_yy, cms_mm);
	$('cms8341-calbody').innerHTML = html;
	cxLayer('cms8341-calendar', 1, 500, 415);
	
	edit_closet_flg = false;
}

/**
 * 開催期間の入力欄を追加
 * @param id エレメントID
 */
function cxAddEventDate(id) {
	// IDが指定されていない場合
	if (id == '' || id == null || id == undefined) {
		id = 'cms_pd';
	}
	
	// 各要素の定義
	var cal_input_area = document.getElementById('calendar_input_area');
	var element_no = parseInt(document.getElementById(id + '_count').value) + 1;
	var element_tr = document.createElement('tr');
	var element_td = document.createElement('td');
	var del_event_date = 'del_event_date' + element_no;
	var input_form = '';
	
	// 開催日の入力欄
	input_form += '<div style="float:left;">';
	input_form += '<input type="text" maxlength="4" id="' + id + element_no +'sy" name="' + id + 'sy[]" value="" style="width: 36px; ime-mode: disabled">&nbsp;年&nbsp;';
	input_form += '<input type="text" maxlength="2" id="' + id + element_no +'sm" name="' + id + 'sm[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;月&nbsp;';
	input_form += '<input type="text" maxlength="2" id="' + id + element_no +'sd" name="' + id + 'sd[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;日&nbsp;';
	input_form += '<input type="text" maxlength="2" id="' + id + element_no +'sh" name="' + id + 'sh[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;時&nbsp;';
	input_form += '<input type="text" maxlength="2" id="' + id + element_no +'si" name="' + id + 'si[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;分&nbsp;';
	input_form += 'から&nbsp;';
	input_form += '<input type="text" maxlength="4" id="' + id + element_no +'ey" name="' + id + 'ey[]" value="" style="width: 36px; ime-mode: disabled">&nbsp;年&nbsp;';
	input_form += '<input type="text" maxlength="2" id="' + id + element_no +'em" name="' + id + 'em[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;月&nbsp;';
	input_form += '<input type="text" maxlength="2" id="' + id + element_no +'ed" name="' + id + 'ed[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;日&nbsp;';
	input_form += '<input type="text" maxlength="2" id="' + id + element_no +'eh" name="' + id + 'eh[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;時&nbsp;';
	input_form += '<input type="text" maxlength="2" id="' + id + element_no +'ei" name="' + id + 'ei[]" value="" style="width: 18px; ime-mode: disabled">&nbsp;分&nbsp;';
	input_form += 'まで&nbsp;';
	input_form += '</div>';
	input_form += '<div style="float:left;">';
	input_form += '<a href="javascript:" id="' + del_event_date + '" name="'+ del_event_date + '" onclick="return cxDelEventDate(' + element_no + ')"><img src="/cms8341/admin/images/btn/btn_del_mini.jpg" width="60" height="20" border="0" /></a>';
	input_form += '</div>';
	
	// calendar_input_areaにtr要素追加
	document.getElementById("calendar_input_area").appendChild(element_tr);
	
	// tr要素にtd要素を追加
	element_tr.appendChild(element_td);
	
	// td要素に開催日の入力欄を追加
	element_td.innerHTML = input_form;
	
	// td要素にidを付与
	element_td.setAttribute('id', id + element_no);
	
	// 新しい要素数をセット
	document.getElementById(id + '_count').value = element_no;
	
	edit_closet_flg = false;
}

/**
 * 開催期間の入力欄を削除
 * @param element_no エレメントNO
 * @param id エレメントID
 */
function cxDelEventDate(element_no, id) {
	// IDが指定されていない場合
	if (id == '' || id == null || id == undefined) {
		id = 'cms_pd';
	}
	
	// 開始日を取得
	var start_year = document.getElementById(id + element_no +'sy').value;
	var start_month = document.getElementById(id + element_no +'sm').value;
	var start_day = document.getElementById(id + element_no +'sd').value;
	
	// 終了日を取得
	var end_year = document.getElementById(id + element_no + 'ey').value;
	var end_month = document.getElementById(id + element_no + 'em').value;
	var end_day = document.getElementById(id + element_no + 'ed').value;
	
	// 開始日と終了日の差を取得
	var diff_day = cxCompareDate(start_year, start_month, start_day, end_year, end_month, end_day);
	
	// 配列から日付を削除
	for(var i=0;i<=diff_day;i++) {
		var date = cxCalcDate(start_year, start_month, start_day, i);
		var year = date.getFullYear();
		var month = date.getMonth() + 1;
		var day = date.getDate();
		delete cms_select_date[year + '_' + month + '_' + day];
	}
	
	// 削除するtd要素を取得
	var element = document.getElementById(id + element_no);
	
	// 親要素を取得
	var parent = element.parentNode;
	
	// 指定された要素を削除
	parent.parentNode.removeChild(parent);
	
	edit_closet_flg = false;
}

/**
 * チェックボックスタイプカレンダー生成
 * @param y 生成する日付【年】
 * @param m 生成する日付【月】
 */
function cxCheckboxCalendar(y, m) {
	// init
	var set_y = y;
	var set_m = m;
	// 指定年月の日数を取得
	var days  = cxGetDays(set_y,set_m);
	// 指定年月における1日の曜日取得
	var tmp_m = set_m - 1;
	var firstday =	new Date(set_y, tmp_m, 1);
	var startpos = firstday.getDay(); 
	// カレンダーに必要な行数
	var rows  = 0;
	rows = ( startpos + days ) / 7;
	rows = Math.floor(rows);
	temp = ( startpos + days ) % 7;
	if(temp!=0) rows++;
	// カレンダー本体生成
	var html = '';
	//
	var id_name = '';
	//
	html  = '<table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-bottom:solid 1px #005BAC;">';
	html += '<tr>';
	html += '<td align="left" valign="middle">';
	html += '<p style="margin:0px;padding:9px 12px 4px 12px">';
	html += '<img src="'+cms8341admin_path+'/images/calendar/m_'+set_m+'.jpg" alt=""></p>';
	html += '</td>';
	html += '<td align="right" valign="bottom">';
	html += '<p style="margin:0px;padding:9px 12px 4px 12px;color:#666666;font-size:18px;font-weight:bold">';
	html += set_y+'年</p>';
	html += '</td>';
	html += '</tr>';
	html += '</table>';
	html += '<table width="422" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse;border:solid 1px #010101;background-color:#F0F0F0;margin-top:15px;">';
	html += '<tr>';
	html += '<td width="90" align="left" valign="top" style="border:solid 1px #010101;">';
	html += '<a href="javascript:" onClick="cxPrevEventDate('+set_y+','+set_m+')"><img src="'+cms8341admin_path+'/images/calendar/btn_prev.jpg" alt="前の月" width="90" height="18" border="0"></a>';
	html += '</td>';
	html += '<td align="left" valign="top">&nbsp;</td>';
	html += '<td width="87" align="right" valign="top" style="border:solid 1px #010101;">';
	html += '<a href="javascript:" onClick="cxNextEventDate('+set_y+','+set_m+')"><img src="'+cms8341admin_path+'/images/calendar/btn_next.jpg" alt="次の月" width="87" height="18" border="0"></a>';
	html += '</td>';
	html += '</tr>';
	html += '</table>';
	
	html += '<table border="0">';
	html += '<tr>';
	html += '<td align="center">';
	
	html += '<table border="0" cellspacing="0" cellpadding="0" class="cms_calbox">';
	html += '<tr>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_sun.jpg" alt="日曜日" width="58" height="19"></td>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_mon.jpg" alt="月曜日" width="58" height="19"></td>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_tue.jpg" alt="火曜日" width="58" height="19"></td>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_wed.jpg" alt="水曜日" width="58" height="19"></td>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_thu.jpg" alt="木曜日" width="58" height="19"></td>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_fri.jpg" alt="金曜日" width="58" height="19"></td>';
	html += '<td align="center" valign="middle" width="58"><img src="'+cms8341admin_path+'/images/calendar/th_sat.jpg" alt="土曜日" width="58" height="19"></td>';
	html += '</tr>';
	
	id_name ='cell-'+ set_y +'-'+ set_m;
	html += '<tr>';
	html += '<td align="center"><input type="button" id="'+ id_name +'-1-0" onclick="cxSelectAll(this, 1, 0)" value="週選択" style="width:58px; border:none;" /></td>';
	html += '<td align="center"><input type="button" id="'+ id_name +'-2-0" onclick="cxSelectAll(this, 2, 0)" value="週選択" style="width:58px; border:none;" /></td>';
	html += '<td align="center"><input type="button" id="'+ id_name +'-3-0" onclick="cxSelectAll(this, 3, 0)" value="週選択" style="width:58px; border:none;" /></td>';
	html += '<td align="center"><input type="button" id="'+ id_name +'-4-0" onclick="cxSelectAll(this, 4, 0)" value="週選択" style="width:58px; border:none;" /></td>';
	html += '<td align="center"><input type="button" id="'+ id_name +'-5-0" onclick="cxSelectAll(this, 5, 0)" value="週選択" style="width:58px; border:none;" /></td>';
	html += '<td align="center"><input type="button" id="'+ id_name +'-6-0" onclick="cxSelectAll(this, 6, 0)" value="週選択" style="width:58px; border:none;" /></td>';
	html += '<td align="center"><input type="button" id="'+ id_name +'-7-0" onclick="cxSelectAll(this, 7, 0)" value="週選択" style="width:58px; border:none;" /></td>';
	html += '</tr>';
	
	for(i=0;i<rows;i++) {
		html += '<tr>';
		if(i==0) {
			// 開始行
			for(j=0;j<startpos;j++) {
				if(j==0) {
					html += '<td align="center" valign="middle" class="cms_sun">&nbsp;</td>';
				} else if(j==6) {
					html += '<td align="center" valign="middle" class="cms_sat">&nbsp;</td>';
				} else {
					html += '<td align="center" valign="middle" class="cms_day">&nbsp;</td>';
				}
			}
			for(j=startpos;j<7;j++) {
				day = j - startpos + 1;
				id_name = 'cell-'+ i +'-'+ (j + 1);
				if(j==0) {
					html += '<td align="center" valign="middle" class="cms_sun"';
				} else if(j==6) {
					html += '<td align="center" valign="middle" class="cms_sat"';
				} else {
					html += '<td align="center" valign="middle" class="cms_day"';
				}
				if(set_y==cms_yy && set_m==cms_mm && day==cms_dd){
					// 当日処理
					html += ' id="cms_today">';
				} else {
					html += '>';
				}
				if(cms_select_date[set_y +'_'+ set_m +'_'+ day] == true) {
					html += '<label for="'+ id_name +'">'+ day + '</label><input type="checkbox" id="'+ id_name +'" onclick="cxSetSelectDate(this, '+ set_y +', '+ set_m +', '+ day +')" checked="checked" />';
				} else {
					html += '<label for="'+ id_name +'">'+ day + '</label><input type="checkbox" id="'+ id_name +'" onclick="cxSetSelectDate(this, '+ set_y +', '+ set_m +', '+ day +')" />';
				}
				html += '</td>';
			}
		} else if(i==rows-1) {
			// 最終行
			for(k=1;k<=7;k++) {
				id_name = 'cell-'+ i +'-'+ k;
				day++;
				if(day<=days) {
					if(k==1) {
						html += '<td align="center" valign="middle" class="cms_sun"';
					} else if(k==7) {
						html += '<td align="center" valign="middle" class="cms_sat"';
					} else {
						html += '<td align="center" valign="middle" class="cms_day"';
					}
					if(set_y==cms_yy && set_m==cms_mm && day==cms_dd){
						// 当日処理
						html += ' id="cms_today">';
					} else {
						html += '>';
					}
					if(cms_select_date[set_y +'_'+ set_m +'_'+ day] == true) {
						html += '<label for="'+ id_name +'">'+ day + '</label><input type="checkbox" id="'+ id_name +'" onclick="cxSetSelectDate(this, '+ set_y +', '+ set_m +', '+ day +')" checked="checked" />';
					} else {
						html += '<label for="'+ id_name +'">'+ day + '</label><input type="checkbox" id="'+ id_name +'" onclick="cxSetSelectDate(this, '+ set_y +', '+ set_m +', '+ day +')" />';
					}
					html += '</td>';
				} else {
					// 日曜
					if(k==1) {
						html += '<td align="center" valign="middle" class="cms_sun">&nbsp;</td>';
					}
					// 土曜
					else if(k==7) {
						html += '<td align="center" valign="middle" class="cms_sat">&nbsp;</td>';
					}
					// 平日
					else {
						html += '<td align="center" valign="middle" class="cms_day">&nbsp;</td>';
					}
				}
			}
		} else {
			for(k=1;k<=7;k++) {
				id_name = 'cell-' + i + '-' + k;
				day++;
				if(k==1) {
					html += '<td align="center" valign="middle" class="cms_sun"';
				} else if(k==7) {
					html += '<td align="center" valign="middle" class="cms_sat"';
				} else {
					html += '<td align="center" valign="middle" class="cms_day"';
				}
				if(set_y==cms_yy && set_m==cms_mm && day==cms_dd){
					//当日処理
					html += ' id="cms_today">';
				} else {
					html += '>';
				}
				if(cms_select_date[set_y +'_'+ set_m +'_'+ day] == true) {
					html += '<label for="'+ id_name +'">' + day + '</label><input type="checkbox" id="' + id_name + '" onclick="cxSetSelectDate(this, ' + set_y + ', ' + set_m + ', ' + day + ')" checked="checked" />';
				} else {
					html += '<label for="'+ id_name +'">' + day + '</label><input type="checkbox" id="' + id_name + '" onclick="cxSetSelectDate(this, ' + set_y + ', ' + set_m + ', ' + day + ')" />';
				}
				html += '</td>';
			}
		}
		html += '</tr>';
	}
	html += '</table>';
	
	html += '</td>';
	html += '</tr>';
	html += '</table>';
	
	html += '<p align="left" style="margin:15px 30px;">日付を選択してください。<br />週選択ボタンをクリックすると選択した曜日を一括で選択できます。</p>';
	html += '<a href="javascript:" onclick="cxSetEventDate()"><img src="/cms8341/admin/images/btn/btn_set.jpg" border="0" width="100" height="20" alt="設定する" /></a>';
	return html;
}

/**
 * チェックボックスタイプカレンダーの前月を表示
 * @param y 表示中年月【年】
 * @param m 表示中年月【月】
 */
function cxPrevEventDate(y, m) {
	if(m == 1) {
		y--;
		m = 12;
	} else {
		m--;
	}
	var html = cxCheckboxCalendar(y,m);
	$('cms8341-calbody').innerHTML = html;
}

/**
 * チェックボックスタイプカレンダーの次月を表示
 * @param y 表示中年月【年】
 * @param m 表示中年月【月】
 */
function cxNextEventDate(y, m) {
	if(m == 12) {
		y++;
		m = 1;
	} else {
		m++;
	}
	var html = cxCheckboxCalendar(y, m);
	$('cms8341-calbody').innerHTML = html;
}

var cms_select_all = new Array();
/**
 * チェックボックスの一括選択
 * @param elem 
 * @param x 行指定
 * @param y 列指定
 */
function cxSelectAll(elem, x, y) {
	// 一括選択した年月を取得
	var id_name_ary = elem.id.split('-');
	var year = id_name_ary[1];
	var month = id_name_ary[2];
	var check_flg = !elem.checked;
	// 行を一括処理
	if(x === 0) {
		for(var i=1; i <= 7; i++) {
			var element = document.getElementById('cell-' + y + '-' + i);
			if(element != null) {
				if(element.checked !== check_flg) {
					// IE11、その他ブラウザで動かないため処理変更
					//element.fireEvent('onclick');
					// イベントオブジェクトを作成
					var event_obj = document.createEvent("MouseEvents");
					// イベントの内容を設定
					event_obj.initEvent("click", false, true);
					// イベントを実行する
					element.dispatchEvent(event_obj);
				}
			}
		}
		elem.checked = check_flg;
	}
	// 列を一括処理
	else {
		for(var j=0; j <= 5; j++) {
			var element = document.getElementById('cell-' + j + '-' + x);
			if(element != null) {
				if(element.checked !== check_flg) {
					// IE11、その他ブラウザで動かないため処理変更
					//element.fireEvent('onclick');
					// イベントオブジェクトを作成
					var event_obj = document.createEvent( "MouseEvents" );
					// イベントの内容を設定
					event_obj.initEvent("click", false, true);
					// イベントを実行する
					element.dispatchEvent(event_obj);
				}
			}
		}
		elem.checked = check_flg;
	}
	// 一括選択の状態を配列に保存
	cms_select_all['cell-' + year + '-' + month + '-' + x + '-' + y] = elem.checked;
}

/**
 * 日付が選択状態かどうか判別
 * @param elem エレメントID（チェックボックス）
 * @returns true : 選択されている | false : 選択されていない
 */
function cxCheckboxFlg(elem) {
	// 選択状態であればtrue、そうでなければfalseを返す
	if(elem.checked) {
		return true;
	} else {
		return false;
	}
}

var cms_select_date = new Array();
/**
 * 選択した日付を配列に格納
 * @param elem エレメントID（チェックボックス）
 * @param year 選択した日付【年】
 * @param month 選択した日付【月】
 * @param day 選択した日付【日】
 */
function cxSetSelectDate(elem, year, month, day) {
	// 配列のキー(年_月_日)
	var key = year + '_' + month + '_' + day;
	
	// チェックした日付を配列に格納
	if(elem.checked == true) {
		cms_select_date[key] = true;
	}
	// チェックを外した日付を配列から削除
	else {
		delete cms_select_date[key];
	}
}

/**
 * カレンダーで選択された情報をもとに入力ボックスを再生成する
 * @param id エレメントID
 */
function cxSetEventDate(id) {
	var day_cnt = 1;
	var input_cnt = 1;
	
	var old_date_ary = new Array();
	var cal_date_ary = new Array();
	var ch_date_ary = new Array();
	
	// IDが指定されていない場合
	if (id == '' || id == null || id == undefined) {
		id = 'cms_pd';
	}
	
	// 要素数取得
	var element_cnt = document.getElementById(id + '_count').value;
	
	// 追加された入力欄を削除
	for(var i=1;i<=element_cnt;i++) {
		if(document.getElementById(id + i +'sy') != null) {
			var key_sy = (document.getElementById(id + i + 'sy').value != '')? document.getElementById(id + i + 'sy').value : '0000';
			key_sy = ('0000' + key_sy).slice(-4);
			
			var key_sm = (document.getElementById(id + i + 'sm').value != '')? document.getElementById(id + i + 'sm').value : '00';
			key_sm = ('00' + key_sm).slice(-2);
			
			var key_sd = (document.getElementById(id + i + 'sd').value != '')? document.getElementById(id + i + 'sd').value : '00';
			key_sd = ('00' + key_sd).slice(-2);
			
			var key_ey = (document.getElementById(id + i + 'ey').value != '')? document.getElementById(id + i + 'ey').value : '0000';
			key_ey = ('0000' + key_ey).slice(-4);
			
			var key_em = (document.getElementById(id + i + 'em').value != '')? document.getElementById(id + i + 'em').value : '00';
			key_em = ('00' + key_em).slice(-2);
			
			var key_ed = (document.getElementById(id + i + 'ed').value != '')? document.getElementById(id + i + 'ed').value : '00';
			key_ed = ('00' + key_ed).slice(-2);
			
			// 開始日と終了日をキーとする
			var key = key_sy + '_' + key_sm + '_' + key_sd + '_' + key_ey + '_' + key_em + '_' + key_ed;
			
			// 入力ボックスの内容を保持
			if (old_date_ary[key] == undefined || old_date_ary[key] == null) {
				old_date_ary[key] = new Array();
			}
			date_cnt = old_date_ary[key].length;
			// 開始日情報保持
			old_date_ary[key][date_cnt] = new Array();
			old_date_ary[key][date_cnt]['sy'] = key_sy;
			old_date_ary[key][date_cnt]['sm'] = key_sm;
			old_date_ary[key][date_cnt]['sd'] = key_sd;
			old_date_ary[key][date_cnt]['sh'] = '';
			if (document.getElementById(id + i + 'sh').value != '') {
				old_date_ary[key][date_cnt]['sh'] = ('00' + document.getElementById(id + i + 'sh').value).slice(-2);
			}
			old_date_ary[key][date_cnt]['si'] = '';
			if (document.getElementById(id + i + 'si').value != '') {
				old_date_ary[key][date_cnt]['si'] = ('00' + document.getElementById(id + i + 'si').value).slice(-2);
			}
			// 「時」「分」どちらかが入力されていない場合入力値を空にする
			if (old_date_ary[key][date_cnt]['sh'] == '' || old_date_ary[key][date_cnt]['si'] == '') {
				old_date_ary[key][date_cnt]['sh'] = '';
				old_date_ary[key][date_cnt]['si'] = '';
			}
			// 終了日情報保持
			old_date_ary[key][date_cnt]['ey'] = key_ey;
			old_date_ary[key][date_cnt]['em'] = key_em;
			old_date_ary[key][date_cnt]['ed'] = key_ed;
			old_date_ary[key][date_cnt]['eh'] = '';
			if (document.getElementById(id + i + 'eh').value != '') {
				old_date_ary[key][date_cnt]['eh'] = ('00' + document.getElementById(id + i + 'eh').value).slice(-2);
			}
			old_date_ary[key][date_cnt]['ei'] = '';
			if (document.getElementById(id + i + 'ei').value != '') {
				old_date_ary[key][date_cnt]['ei'] = ('00' + document.getElementById(id + i + 'ei').value).slice(-2);
			}
			// 「時」「分」どちらかが入力されていない場合入力値を空にする
			if (old_date_ary[key][date_cnt]['eh'] == '' || old_date_ary[key][date_cnt]['ei'] == '') {
				old_date_ary[key][date_cnt]['eh'] = '';
				old_date_ary[key][date_cnt]['ei'] = '';
			}
		}
		
		if(document.getElementById('del_event_date' + i) != null) {
			// 削除するtd要素を取得
			var element = document.getElementById(id + i);
			
			// 親要素を取得
			var parent = element.parentNode;
			
			// 指定された要素を削除
			parent.parentNode.removeChild(parent);
		}
	}

	// 一度入力欄の日付をクリア
	document.getElementById(id + '1sy').value = '';
	document.getElementById(id + '1sm').value = '';
	document.getElementById(id + '1sd').value = '';
	document.getElementById(id + '1sh').value = '';
	document.getElementById(id + '1si').value = '';
	document.getElementById(id + '1ey').value = '';
	document.getElementById(id + '1em').value = '';
	document.getElementById(id + '1ed').value = '';
	document.getElementById(id + '1eh').value = '';
	document.getElementById(id + '1ei').value = '';
	
	// キーでソート
	var select_date = new Array();
	for(var key in cms_select_date) {
		// データがtrueでなければスキップする
		if(cms_select_date[key] != true) {
			continue;
		}

		// キーが該当しなければスキップする
		if(key.match(/^[0-9]{4}_[0-9]{1,2}_[0-9]{1,2}$/) == null) {
			continue;
		}
		
		// 日付を0埋めに変換
		var date_ary = key.split('_');
		var year = date_ary[0];
		var month = ('00' + date_ary[1]).slice(-2);
		var day = ('00' + date_ary[2]).slice(-2);
		
		// 変換したキーで配列に格納
		select_date[year + '_' + month + '_' + day] = cms_select_date[key];
	}
	
	// ソートを実行
	select_date = cxKeySort(select_date, 'sort');
	
	// チェックを入れた日付を入力欄にセット
	for(var key in select_date) {
		// データがtrueでなければスキップする
		if(select_date[key] != true) {
			continue;
		}

		// キーが該当しなければスキップする
		if(key.match(/^[0-9]{4}_[0-9]{2}_[0-9]{2}$/) == null) {
			continue;
		}
		
		// 日付を取得
		var input_date_ary = key.split('_');
		var input_year = input_date_ary[0];
		var input_month = input_date_ary[1];
		var input_day = input_date_ary[2];
		
		// 取得した日付の1日後の日付を取得
		var date = cxCalcDate(input_year, input_month, input_day, 1);

		// 連日カウント(day_cnt)が1の時に開始日を別変数に格納
		if(day_cnt == 1) {
			var start_year = input_year;
			var start_month = input_month;
			var start_day = input_day;
		}
		
		// 連日である場合
		if(select_date[date.getFullYear() + '_' + ('00' + (date.getMonth() + 1)).slice(-2) + '_' + ('00' + date.getDate()).slice(-2)] == true) {
			// 連日カウントを+1
			++day_cnt;
		}
		// 連日でない場合
		else {
			// キーを作成
			var date_key = start_year + '_' + start_month + '_' + start_day + '_' + input_year + '_' + input_month + '_' + input_day;
			for(var i=1;i<=element_cnt;i++) {
				if (cal_date_ary[date_key] == undefined || cal_date_ary[date_key] == null) {
					cal_date_ary[date_key] = new Array();
				}
				
				cal_date_ary[date_key]['sy'] = start_year;
				cal_date_ary[date_key]['sm'] = start_month.replace(/^0+([0-9]+)/, "$1" );
				cal_date_ary[date_key]['sd'] = start_day.replace(/^0+([0-9]+)/, "$1" );
				cal_date_ary[date_key]['ey'] = input_year;
				cal_date_ary[date_key]['em'] = input_month.replace(/^0+([0-9]+)/, "$1" );
				cal_date_ary[date_key]['ed'] = input_day.replace(/^0+([0-9]+)/, "$1" );
			}
			// 連日カウント(day_cnt)を1に戻す
			day_cnt = 1;
			
			// 処理数(input_cnt)を+1
			++input_cnt;
		}
	}
	
	// 入力ボックスの内容とカレンダーのチェック内容とを結合しチェック用の情報を作成する
	cnt = 0;
	for(var key in cal_date_ary) {
		if(key.match(/^[0-9]{4}_[0-9]{2}_[0-9]{2}_[0-9]{4}_[0-9]{2}_[0-9]{2}$/) == undefined || key.match(/^[0-9]{4}_[0-9]{2}_[0-9]{2}_[0-9]{4}_[0-9]{2}_[0-9]{2}$/) == null) {
			continue;
		}
		
		// 入力ボックスの期間の指定とカレンダーの期間の指定に差異が無い場合
		if (old_date_ary[key]) {
			for (i = 0; i < old_date_ary[key].length; i++) {
				open_start = old_date_ary[key][i]['sy'] + '/' + old_date_ary[key][i]['sm'] + '/' + old_date_ary[key][i]['sd'];
				// 「時」「分」の入力がされている場合「時分秒」を追加
				if (old_date_ary[key][i]['sh'] != '' && old_date_ary[key][i]['si'] != '') {
					open_start += ' ' + old_date_ary[key][i]['sh'] + ':' + old_date_ary[key][i]['si'] + ':' + '00';
				}
				open_end = old_date_ary[key][i]['ey'] + '/' + old_date_ary[key][i]['em'] + '/' + old_date_ary[key][i]['ed'];
				// 「時」「分」の入力がされている場合「時分秒」を追加
				if (old_date_ary[key][i]['eh'] != '' && old_date_ary[key][i]['ei'] != '') {
					open_end += ' ' + old_date_ary[key][i]['eh'] + ':' + old_date_ary[key][i]['ei'] + ':' + '00';
				}
				// 入力ボックスの情報を格納
				ch_date_ary[cnt] = {'open_start' : open_start, 'open_end' : open_end};
				cnt++;
			}
		}
		// カレンダーの期間の指定
		else {
			open_start = cal_date_ary[key]['sy'] + '/' + cal_date_ary[key]['sm'] + '/' + cal_date_ary[key]['sd'];
			open_end = cal_date_ary[key]['ey'] + '/' + cal_date_ary[key]['em'] + '/' + cal_date_ary[key]['ed'];
			// カレンダーの情報を格納
			ch_date_ary[cnt] = {'open_start' : open_start, 'open_end' : open_end};
			cnt++;
		}
	}
	
	// パラメータの作成
	params = '';
	for (ch_date_cnt = 0; ch_date_cnt < ch_date_ary.length; ch_date_cnt++) {
		if (params != '') {
			params += '&';
		}
		params += 'open_date_ary[' + ch_date_cnt + '][open_start]=' + ch_date_ary[ch_date_cnt]['open_start'];
		params += '&open_date_ary[' + ch_date_cnt + '][open_end]=' + ch_date_ary[ch_date_cnt]['open_end'];
	}
	
	// ajaxによる開催期間の集約実行
	rText = cxAjaxCommandAnSync('cxMergeOpenDate', params, '').transport.responseText;
	
	// 「false」が返された場合エラー出力
	if(rText == 'false'){
		alert('開催期間の集約に失敗しました。');
		$ret = false;
	}
	else if (rText != '') {
		var result = eval('(' + rText + ')');
		var input_cnt = 1;
		document.getElementById(id + '_count').value = 1;
		
		// 集約された情報をもとに入力ボックスを再生成する
		for (result_cnt = 0; result_cnt < result.length; result_cnt++) {
			if(input_cnt > 1) {
				//入力欄を追加
				var evt = document.createEvent("MouseEvents");
				evt.initMouseEvent("click", true, true, window, 1, 0, 0, 0, 0,
				    false, false, false, false, 0, null);
				document.getElementById('add_event_date').dispatchEvent(evt);
				
				//入力欄の要素数を再取得
				element_cnt = document.getElementById(id + '_count').value;
			}
			
			//セットする要素が存在しない場合はスキップ
			if(document.getElementById(id + input_cnt + 'sy') == null) continue;
			
			// 開始日【年月日】をセット
			document.getElementById(id + input_cnt + 'sy').value = result[result_cnt]['open_start']['y'];
			document.getElementById(id + input_cnt + 'sm').value = result[result_cnt]['open_start']['m'].replace(/^0+([0-9]+)/, "$1");
			document.getElementById(id + input_cnt + 'sd').value = result[result_cnt]['open_start']['d'].replace(/^0+([0-9]+)/, "$1");
			// 要素の属性値を取得し、無い場合は、属性値を設定する
			if (!document.getElementById(id + input_cnt + 'sy').getAttribute('value')) {
				document.getElementById(id + input_cnt + 'sy').setAttribute('value', result[result_cnt]['open_start']['y']);
				document.getElementById(id + input_cnt + 'sm').setAttribute('value', result[result_cnt]['open_start']['m'].replace(/^0+([0-9]+)/, "$1"));
				document.getElementById(id + input_cnt + 'sd').setAttribute('value', result[result_cnt]['open_start']['d'].replace(/^0+([0-9]+)/, "$1"));
			}
			
			// 開始日【時間】をセット
			document.getElementById(id + input_cnt + 'sh').value = result[result_cnt]['open_start']['h'].replace(/^0+([0-9]+)/, "$1");
			document.getElementById(id + input_cnt + 'si').value = result[result_cnt]['open_start']['i'];
			// 要素の属性値を取得し、無い場合は、属性値を設定する
			if (!document.getElementById(id + input_cnt + 'sh').getAttribute('value') || 
				!document.getElementById(id + input_cnt + 'si').getAttribute('value')) {
				document.getElementById(id + input_cnt + 'sh').setAttribute('value', result[result_cnt]['open_start']['h'].replace(/^0+([0-9]+)/, "$1"));
				document.getElementById(id + input_cnt + 'si').setAttribute('value', result[result_cnt]['open_start']['i']);
			}
			
			// 終了日【年月日】をセット
			document.getElementById(id + input_cnt + 'ey').value = result[result_cnt]['open_end']['y'];
			document.getElementById(id + input_cnt + 'em').value = result[result_cnt]['open_end']['m'].replace(/^0+([0-9]+)/, "$1");
			document.getElementById(id + input_cnt + 'ed').value = result[result_cnt]['open_end']['d'].replace(/^0+([0-9]+)/, "$1");
			// 要素の属性値を取得し、無い場合は、属性値を設定する
			if (!document.getElementById(id + input_cnt + 'ey').getAttribute('value')) {
				document.getElementById(id + input_cnt + 'ey').setAttribute('value', result[result_cnt]['open_end']['y']);
				document.getElementById(id + input_cnt + 'em').setAttribute('value', result[result_cnt]['open_end']['m'].replace(/^0+([0-9]+)/, "$1"));
				document.getElementById(id + input_cnt + 'ed').setAttribute('value', result[result_cnt]['open_end']['d'].replace(/^0+([0-9]+)/, "$1"));
			}
			
			// 終了日【時間】をセット
			document.getElementById(id + input_cnt + 'eh').value = result[result_cnt]['open_end']['h'].replace(/^0+([0-9]+)/, "$1");
			document.getElementById(id + input_cnt + 'ei').value = result[result_cnt]['open_end']['i'];
			// 要素の属性値を取得し、無い場合は、属性値を設定する
			if (!document.getElementById(id + input_cnt + 'eh').getAttribute('value') || 
				!document.getElementById(id + input_cnt + 'ei').getAttribute('value')) {
				document.getElementById(id + input_cnt + 'eh').setAttribute('value', result[result_cnt]['open_end']['h'].replace(/^0+([0-9]+)/, "$1"));
				document.getElementById(id + input_cnt + 'ei').setAttribute('value', result[result_cnt]['open_end']['i']);
			}
			
			// 処理数(input_cnt)を+1
			++input_cnt;
		}
	}
	
	cxCalendarClose();
}

/**
 * n日後の日付を取得
 * @param year 基準となる日付【年】
 * @param month 基準となる日付【月】
 * @param day 基準となる日付【日】
 * @param add_day 何日後か指定【日】
 * @returns 取得した日付
 */
function cxCalcDate(year, month, day, add_day) {
	var dt = new Date(year, month - 1, day);
    var base_sec = dt.getTime();
    var add_sec = add_day * 86400000;
    var target_sec = base_sec + add_sec;
    dt.setTime(target_sec);
    return dt;
}

/**
 * 開始日と終了日との日数の差を取得
 * @param start_year 開始日【年】
 * @param start_month 開始日【月】
 * @param start_day 開始日【日】
 * @param end_year 開始日【年】
 * @param end_month 開始日【月】
 * @param end_day 開始日【日】
 * @returns 取得した日数
 */
function cxCompareDate(start_year, start_month, start_day, end_year, end_month, end_day) {
	if(end_year == '' && end_month == '' && end_day == '') {
		end_year = start_year;
		end_month = start_month;
		end_day = start_day;
	}
	if(start_year == '' || start_month == '' || start_day == '' || end_year == '' || end_month == '' || end_day == '') {
		return false;
	}
	var start_dt = new Date(start_year, start_month - 1, start_day);
	var end_dt = new Date(end_year, end_month - 1, end_day);
	var diff = end_dt - start_dt;
	var diff_day = diff / 86400000;
	return diff_day;
}

/**
 * 配列のキーによるソート
 * @param hash ソートを行う配列
 * @param sort 
 */
function cxKeySort(hash,sort){
	var sortFunc = sort || reverse;
	var keys = [];
	var newHash = {};
	for (var k in hash) keys.push(k);
	keys[sortFunc]();
	var length = keys.length;
	for(var i = 0; i < length; i++){
		newHash[keys[i]] = hash[keys[i]];
	}
	return newHash;	
}