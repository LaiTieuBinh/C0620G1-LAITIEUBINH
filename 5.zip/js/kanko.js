/*
 * 定型
 */
var cmsKankoPropAry = new Array();
for(i in cmsKankoPropAry){
	cmsKankoPropAry[i] = null;
}
function cxSetKanko(){
	if($F('cms_dispMode') =="copy"){
		page_id = $F('cms_copy_page_id');
	} else {
		page_id = "";
	}
	var prm = 'template_id='+$('cms_template_id').value+'&page_id='+page_id;
	cxAjaxCommand('cxGetKankoMetaStr', prm, cxKankoMetaSuccess);
	return false;
}

function cxKankoMetaSuccess (r) {
	var rText = r.responseText;
	$('cms_kanko_area').innerHTML = rText;
}

//通信失敗処理
function cxFailure() {
	alert("定型情報の取得に失敗");
}
var active_fixed_id;
var active_fixed_type;
function entryKanko(id, type) {
	edit_closet_flg = false;
	active_fixed_id = id;
	active_fixed_type = type;
	var retObj = new Object();
	value = $F('cms_kanko_' + id).replace("#", "＃");
	value = encodeURIComponent(value);
	prm = "value=" + value + "&id=" + id + "&type=" + type + "&dir=" + $F('cms_dir_path');
	// 画像設定
	if (type == "image") {
		prm += "&size[]=" + $F('cms_kanko_image_size_' + id);
		prm += "&size[]=" + $F('cms_kanko_image_size_height_' + id);
		// ダイアログの表示
		cxIframeLayer(
				cms8341admin_path + "/page/common/kanko/image.php?" + prm,
				680,
				720,
				COVER_SETTING.COLOR,
				'',
				kankoCallback
				);
	}
	//リンク設定
	// オープンデータ
	// 定型typeオープンデータ
	else if (type == "link" || type == "mail" || type == "file" || type == "opendata") {
		//ダイアログの表示
		cxIframeLayer(
				cms8341admin_path + "/page/common/kanko/link.php?" + prm,
				458,
				600,
				COVER_SETTING.COLOR,
				'',
				kankoCallback
				);
	}
	//YouTube設定
	else if (type == "youtube") {
		//ダイアログの表示
		cxIframeLayer(
				cms8341admin_path + "/page/common/kanko/youtube.php?" + prm,
				600,
				460,
				COVER_SETTING.COLOR,
				'',
				kankoCallback
				);
	}
	else
		return;
	function kankoCallback(retObj) {
		if (retObj == undefined)
			return;
		tmpAry = retObj['ret'].split(KANKO_LINK_DELIMITER);
		if (tmpAry[1] != undefined) {
			tmpAry[1] = tmpAry[1].replace("＃", "#");
		}
		switch (type) {
			case "image":
				//width = (($F('cms_kanko_image_size_' + id) != "") ? ' width="' + ($F('cms_kanko_image_size_' + id) > tmpAry[2] ? tmpAry[2] : $F('cms_kanko_image_size_' + id)) + '"' : "");
				width = set_image_size(id, tmpAry[2], tmpAry[3]);
				var img_path = (baseUrl + htmlEscape(cxEscapeHtmlChars(tmpAry[0]))).replace(/\/+/g, '/');
				$('cms_kanko_link_' + id).innerHTML = '<img src="' + img_path + '?rnd=' + parseInt((Math.random() * 10000) + 1) + '" alt="' + htmlEscape(cxEscapeHtmlChars(tmpAry[1])) + '"' + width + ' w_size="' + $F('cms_kanko_image_size_' + id) + '" h_size="' + $F('cms_kanko_image_size_height_' + id) + '"><br />'
						+ '<a href="javascript:" onclick="entryKanko(\'' + id + '\',\'' + type + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_img_setup_on.gif" border="0" alt="画像設定" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>'
						+ '&nbsp;<a href="javascript:" onclick="deleteImage(\'' + id + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_del_mini.gif" border="0" alt="削除する" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>';
				$('cms_kanko_' + id).value = tmpAry[0] + KANKO_LINK_DELIMITER + tmpAry[1];
				// 定型ページでYoutube設定を行った場合のアラートの対応
				edit_closet_flg = true;
				break;
			case "link":
			case "mail":
			case "file":
				//ファイル
				if (tmpAry[3]) {
					//配列を作成
					var ADD_FILE_DETAIL_EXP_ARY = getAddFileDetailExp();

					// 変数の宣言
					file_size = "";
					file_ext_str = "";
					file_class = "";

					// ファイルサイズ
					if (tmpAry[4])
						file_size = tmpAry[4];
					// ファイル種別の指定
					if (ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]) {
						if (acc_flg == 0)
							file_ext_str = '（' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['JP'];
						else if (acc_flg == 1)
							file_ext_str = '(' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['EN'];
						// クラスの指定
						if (ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['CLASS'] != "")
							file_class = ' class="' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['CLASS'] + '"'
						// ファイルサイズの指定
						if (file_size)
							file_ext_str += (acc_flg == 0 ? "：" : ":") + numEdit(Math.ceil(file_size / 1024)) + "KB";
						file_ext_str += (acc_flg == 0 ? "）" : ")");
					}
					// target属性値に「_blank」（別ウィンドウ）設定が指定されている場合
					if (tmpAry[2] && tmpAry[2] == '_blank') {
						// 日本語テンプレートの場合
						if (acc_flg == 0) {
							file_ext_str += OTHER_WINDOW_STR_JP;
						}
						// 外国語テンプレートの場合
						else if (acc_flg == 1) {
							file_ext_str += OTHER_WINDOW_STR_EN;
						}
					}

					$('cms_kanko_link_' + id).innerHTML = '<a href="#"' + file_class + '>' + htmlEscape(cxEscapeHtmlChars(tmpAry[1] + file_ext_str)) + '</a>&nbsp;<a href="javascript:void(0)" onclick="entryKanko(\'' + id + '\',\'' + type + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_link_setup_on.gif" border="0" alt="リンク設定" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>'
							+ '&nbsp;<a href="javascript:void(0)" onclick="deleteLink(\'' + id + '\',\'' + type + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_del_mini.gif" border="0" alt="削除する" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>';
					$('cms_kanko_' + id).value = tmpAry[0] + KANKO_LINK_DELIMITER + tmpAry[1] + KANKO_LINK_DELIMITER + tmpAry[2] + KANKO_LINK_DELIMITER + tmpAry[3] + KANKO_LINK_DELIMITER + tmpAry[4];
				}
				else {
					var target_str = '';
					// target属性値に「_blank」（別ウィンドウ）設定が指定されている場合
					if (tmpAry[2] && tmpAry[2] == '_blank') {
						// 日本語テンプレートの場合
						if (acc_flg == 0) {
							target_str += OTHER_WINDOW_STR_JP;
						}
						// 外国語テンプレートの場合
						else if (acc_flg == 1) {
							target_str += OTHER_WINDOW_STR_EN;
						}
					}
					$('cms_kanko_link_' + id).innerHTML = '<a href="#">' + htmlEscape(cxEscapeHtmlChars(tmpAry[1] + target_str)) + '</a>&nbsp;<a href="javascript:" onclick="entryKanko(\'' + id + '\',\'' + type + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_link_setup_on.gif" border="0" alt="リンク設定" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>'
							+ '&nbsp;<a href="javascript:void(0)" onclick="deleteLink(\'' + id + '\',\'' + type + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_del_mini.gif" border="0" alt="削除する" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>';
					$('cms_kanko_' + id).value = tmpAry[0] + KANKO_LINK_DELIMITER + tmpAry[1] + KANKO_LINK_DELIMITER + tmpAry[2];
				}
				// 定型ページでYoutube設定を行った場合のアラートの対応
				edit_closet_flg = true;
				break;
			// オープンデータ
			// 定型typeオープンデータ
			case "opendata":
				// ファイルと同様にファイル拡張子の値がとれるかどうかで判断
				if(tmpAry[3]) {
					//配列を作成
					var ADD_FILE_DETAIL_EXP_ARY = getAddFileDetailExp();
		
					// 変数の宣言
					file_size = "";
					file_ext_str = "";
					file_class = "";
		
					// ファイルサイズ
					if (tmpAry[4]) {
						file_size = tmpAry[4];
					}
					// ファイル種別の指定
					if (ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]) {
						if(acc_flg == 0) {
							file_ext_str = '（' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['JP'];
						}
						else if(acc_flg == 1) {
							file_ext_str = '(' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['EN'];
						}
						// クラスの指定
						if(ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['CLASS'] != "") {
							file_class = ' class="' + ADD_FILE_DETAIL_EXP_ARY[tmpAry[3]]['CLASS'] + '"';
						}
						// ファイルサイズの指定
						if(file_size) {
							file_ext_str += (acc_flg == 0 ? "：" : ":") + numEdit(Math.ceil(file_size / 1024)) + "KB";
						}
						file_ext_str += (acc_flg == 0 ? "）" : ")");
					}
					// target属性値に「_blank」（別ウィンドウ）設定が指定されている場合
					if (tmpAry[2] && tmpAry[2] == '_blank') {
						// 日本語テンプレートの場合
						if (acc_flg == 0) {
							file_ext_str += OTHER_WINDOW_STR_JP;
						}
						// 外国語テンプレートの場合
						else if (acc_flg == 1) {
							file_ext_str += OTHER_WINDOW_STR_EN;
						}
					}
					// 表示用HTML生成
					$('cms_kanko_link_' + id).innerHTML = '<a href="#"' + file_class + '>' + htmlEscape(cxEscapeHtmlChars(tmpAry[1] + file_ext_str)) + '</a>&nbsp;<a href="javascript:void(0)" onclick="entryKanko(\'' + id + '\',\'' + type + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_link_setup_on.gif" border="0" alt="リンク設定" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>'
						+ '&nbsp;<a href="javascript:void(0)" onclick="deleteLink(\'' + id + '\',\'' + type + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_del_mini.gif" border="0" alt="削除する" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>';
					// hidden値に、KANKO_LINK_DELIMITER区切りで各パラメータ値をセット
					$('cms_kanko_' + id).value = tmpAry[0] + KANKO_LINK_DELIMITER + tmpAry[1] + KANKO_LINK_DELIMITER + tmpAry[2] + KANKO_LINK_DELIMITER + tmpAry[3] + KANKO_LINK_DELIMITER + tmpAry[4] + KANKO_LINK_DELIMITER + tmpAry[5] + KANKO_LINK_DELIMITER + tmpAry[6] + KANKO_LINK_DELIMITER + tmpAry[7] + KANKO_LINK_DELIMITER + tmpAry[8] + KANKO_LINK_DELIMITER + tmpAry[9] + KANKO_LINK_DELIMITER + tmpAry[10] + KANKO_LINK_DELIMITER + tmpAry[11] + KANKO_LINK_DELIMITER + tmpAry[12] + KANKO_LINK_DELIMITER + tmpAry[13] + KANKO_LINK_DELIMITER + tmpAry[14] + KANKO_LINK_DELIMITER + tmpAry[15];
				}
				// 定型ページでYoutube設定を行った場合のアラートの対応
				edit_closet_flg = true;
				break;
			case "youtube":
				prm = "url=" + tmpAry[0] + "&title=" + tmpAry[1] + "&width=" + tmpAry[2] + "&height=" + tmpAry[3];
				cxAjaxCommand("cxConvertYoutubeCMS", prm, cxConvertYoutubeCMSSuccess)
				$('cms_kanko_' + id).value = retObj['ret'];
				break;
		}
	}
}
function cxConvertYoutubeCMSSuccess(r){
	if(r.responseText == ""){
		alert("YouTubeの挿入に失敗しました");
		// 定型ページでYoutube設定を行った場合のアラートの対応
		edit_closet_flg = true;
		return;
	}
	$('cms_kanko_link_' + active_fixed_id).innerHTML = r.responseText + '<br /><a href="javascript:" onclick="entryKanko(\'' + active_fixed_id + '\',\'' + active_fixed_type + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_youtube_setup_on.jpg" border="0" alt="YouTube設定" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>'
		+ '&nbsp;<a href="javascript:" onclick="deleteYouTube(\'' + active_fixed_id + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_del_mini.gif" border="0" alt="削除する" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>';
	// 定型ページでYoutube設定を行った場合のアラートの対応
	edit_closet_flg = true;
}

/**
 * 画像のsizeをセットする
 * @param id アイテムID
 * @param w 実際の画像のwidth
 * @param h 実際の画像のheight
 */
function set_image_size(id,w,h){
	
	if($F('cms_kanko_image_size_' + id) != "" || $F('cms_kanko_image_size_height_' + id) != ""){
		var max_w = ($F('cms_kanko_image_size_' + id) != "" ? parseInt($F('cms_kanko_image_size_' + id)) : w);
		var max_h = ($F('cms_kanko_image_size_height_' + id) != "" ? parseInt($F('cms_kanko_image_size_height_' + id)) : h);
		if(max_w < w || max_h < h){
			var W = max_w / w;
			var H = max_h / h;
			(W < H) ? key = W : key= H;
			return ' width="' + Math.ceil(w * key) + '" height="' + Math.ceil(h * key) + '"';
		}
	}
	return ' width="' + w + '" height="' + h + '"';
}
/**
 * 定型テンプレート用画像の削除を行なう
 * @param id アイテムID
 */
function deleteImage(id){
	$('cms_kanko_link_' + id).innerHTML = '<img src="' + cms8341admin_path + '/images/thumbnails/temp1.gif" alt="指定無し"><br /><a href="javascript:" onclick="entryKanko(\'' + id + '\',\'image\')"><img src="' + cms8341admin_path + '/images/btn/btn_img_setup_on.gif" border="0" alt="画像設定" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>'
		+ '&nbsp;<a href="javascript:" onclick="deleteImage(\'' + id + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_del_mini.gif" border="0" alt="削除する" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>';
	$('cms_kanko_' + id).value = KANKO_LINK_DELIMITER;
}

/**
 * 定型テンプレート用リンクの削除を行なう
 * @param id アイテムID
 * @param type アイテムタイプ
 */
function deleteLink(id,type){
	$('cms_kanko_link_'+id).innerHTML = '<a href="#"></a><a href="javascript:void(0)" onclick="entryKanko(\'' + id + '\',\'' + type + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_link_setup_on.gif" border="0" alt="リンク設定" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>'
		+ '&nbsp;<a href="javascript:void(0)" onclick="deleteLink(\'' + id + '\',\'' + type + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_del_mini.gif" border="0" alt="削除する" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>';
	$('cms_kanko_' + id).value = KANKO_LINK_DELIMITER;
}

/**
 * 定型テンプレート用YouTube領域の削除を行なう
 * @param id アイテムID
 */
function deleteYouTube(id){
	$('cms_kanko_link_' + id).innerHTML = '<a href="javascript:" onclick="entryKanko(\'' + id + '\',\'youtube\')"><img src="' + cms8341admin_path + '/images/btn/btn_youtube_setup_on.jpg" border="0" alt="YouTube設定" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>'
		+ '&nbsp;<a href="javascript:" onclick="deleteYouTube(\'' + id + '\')"><img src="' + cms8341admin_path + '/images/btn/btn_del_mini.gif" border="0" alt="削除する" class="cms8341-verticalMiddle" style="margin-top:5px; border:0px;"></a>';
	$('cms_kanko_' + id).value = KANKO_LINK_DELIMITER;
}

function resetRadio(item){
	edit_closet_flg = false;
	kankoItem = document;
	for (i = 0; i < kankoItem.getElementsByTagName("input").length; i++) {
		id = kankoItem.getElementsByTagName("input")[i].getAttribute("ID");
		if(id == null)continue;
		if(id.indexOf("cms_kanko_"+item) == 0){
			$(id).checked = false;
		}
	}
}

function kankoCheck(areaId) {
	var info = new Array();
	var group_needs = new Array();
	var kankoItem = new Array();
	var form_name = "cms_fAddpage";
	if ($('cms_fEdit')) form_name = "cms_fEdit";
	if(areaId == undefined){
		var elements = Form.getInputs(form_name,'hidden'); 
		elements.each( 
			function(val,idx) {
				id = val.id;
				if(id.indexOf("cms_kanko_hidden_group_need_") == 0) {
					group_needs.push($F(id));
				// 必須チェック
				} else if(id.indexOf("cms_kanko_hidden_") == 0){
					kankoItem.push(id);
				}
			}
		);
	} else {
		areaItem = document.all(areaId);
		for (fixed_cnt = 0; fixed_cnt < areaItem.getElementsByTagName("input").length; fixed_cnt++) {
			id = areaItem.getElementsByTagName("input")[fixed_cnt].getAttribute("ID");
			if(id==null) continue;
			if(id.indexOf("cms_kanko_hidden_") == 0){
				kankoItem.push(id);
			}
		}
	}

	for (fixed_cnt = 0; fixed_cnt < kankoItem.length; fixed_cnt++) {
		id = kankoItem[fixed_cnt];
		itemName = id.replace("cms_kanko_hidden_","");
		hiddenVal = $F(id);
		tmp = hiddenVal.split(":");
		type = tmp[0];
		kind = tmp[1];
		targetItemName = (kind == "meta")?$('cms_kanko_name_'+itemName).innerHTML:$F('cms_kanko_name_'+itemName);
		switch (type){
			case "text":
			case "textarea":
				if($F('cms_kanko_'+itemName) == ""){
					if($('cms_kanko_require_'+itemName)){
						alert(targetItemName+'が入力されていません。');
						$('cms_kanko_'+itemName).focus();
						return false;
					}
				} else if( itemName != "latitude_and_longitude"){
					info = fckCheck(targetItemName, $('cms_kanko_'+itemName).value, info);
				}
				
				if($('cms_kanko_check_'+itemName) && $F('cms_kanko_check_'+itemName) != ""){
					check_val = $F('cms_kanko_'+itemName);
					if($F('cms_kanko_check_'+itemName) == "numcheck"){
						if(!cxDateNumeric(check_val)){
							alert(targetItemName+'は半角数字を入力してください。');
							$('cms_kanko_'+itemName).focus();
							return false;
						}
					} else {
						var regObj = new RegExp($F('cms_kanko_check_'+itemName),"i");
						if(!check_val.match(regObj)) {
							alert(targetItemName+'が正しい値ではありません。');
							$('cms_kanko_'+itemName).focus();
							return false;
						}
					}
				}
					
				// 緯度経度チェック
				if(itemName == "latitude_and_longitude" && $F('cms_kanko_'+itemName) != ""){
					var regObjMAP = new RegExp('&ll=\-?([0-9]+)(\.[0-9]+)?,\-?([0-9]+)(\.[0-9]+)?(&.*)?$');
					
					// 地図情報に指定された値を整形
					var map_input_value = trim($F('cms_kanko_'+itemName));
					map_input_value = map_input_value.replace(/ /g, '');
					
					// 入力値をチェックし、「&ll=～」の形式でない場合は入力値の先頭に「&ll=」を付与する
					if(!map_input_value.match(regObjMAP)) {
						map_input_value = '&ll=' + map_input_value;
					}
					
					if(!map_input_value.match(regObjMAP) || parseInt(RegExp.$1,10) > 90 || parseInt(RegExp.$3,10) > 180){
						alert(targetItemName+'が正しい値ではありません。\nGoogleMapの地図情報を入力してください');
						return false;
					}
					// 入力値に代入する
					document.getElementById('cms_kanko_'+itemName).value = map_input_value;
				}
				break;
			case "customarea":
				eval("wEditor_"+itemName+".saveEditor()")
				$("cms_kanko_"+itemName).value = eval("wEditor_"+itemName+".saveHTML");
				info = fckCheck(targetItemName, $("cms_kanko_"+itemName).value, info);
				break;
			case "radio":
			case "checkbox":
				if($('cms_kanko_require_'+itemName)){
					isChecked = false;
					var checkbox_elements = (type == "checkbox")
											? Form.getInputs(form_name,type,'cms_kanko_'+itemName+'[]')
											: Form.getInputs(form_name,type,'cms_kanko_'+itemName); 
					checkbox_elements.each( 
						function(val,idx) {
							radioId = val.id;
							if(radioId.indexOf("cms_kanko_"+itemName) == 0){
								if($(radioId).checked) isChecked = true;
							}
						}
					);
					if(!isChecked){
						alert(targetItemName+'が入力されていません。');
						return false;
					}
				}
				break;
			case "select":
				if($('cms_kanko_require_'+itemName)){
					if(areaId == undefined){
						optionItem = document;
					} else {
						optionItem = document.all(areaId);
					}
					isChecked = false;
					for (j = 0; j < optionItem.getElementsByTagName("option").length; j++) {
						optionId = optionItem.getElementsByTagName("option")[j].getAttribute("ID");
						if(optionId == null)continue;
						if(optionId.indexOf("cms_kanko_"+itemName) == 0){
							if($(optionId).selected && $(optionId).value != ""){
								isChecked = true;
								break;
							}
						}
					}
					if(!isChecked){
						alert(targetItemName+'が入力されていません。');
						$('cms_kanko_'+itemName).focus();
						return false;
					}
				}
				break;
			case "date":
				format = ($('cms_kanko_date_format_' + itemName) ? $F('cms_kanko_date_format_' + itemName) : "");
				var format_ary = format.toArray();
				for(var f_cnt = 0;f_cnt < format_ary.length;f_cnt++){
					//小文字に変換
					format_ary[f_cnt] = format_ary[f_cnt].toLowerCase();
					// 強制的に終了する文字
					if(format_ary[f_cnt] == '_'){
						for(var end_cnt = f_cnt;end_cnt < format_ary.length;end_cnt++){
							format_ary[end_cnt] = null;
						}
						break;
					}
					//無視する文字
					if(format_ary[f_cnt] == 'w'){
						format_ary[f_cnt] = null;
						continue;
					}
					//一部の文字を変換
					if(format_ary[f_cnt] == 'n') format_ary[f_cnt] = 'm';
					if(format_ary[f_cnt] == 'j') format_ary[f_cnt] = 'd';
					eval('var ' + format_ary[f_cnt] + '_num = ' + ($('cms_kanko_date_' + itemName+'_' + format_ary[f_cnt]) ? ($F('cms_kanko_date_' + itemName + '_' + format_ary[f_cnt]) ? '"' + cxEscapeHtmlChars($F('cms_kanko_date_' + itemName + '_' + format_ary[f_cnt])) + '"' : "\"\"") : "\"\""));
				}
				p = ($('cms_kanko_date_'+itemName+'_p') ? $F('cms_kanko_date_'+itemName+'_p') : "");
				// 必須チェック
				var require_err_flg = false;
				for(var f_cnt = 0;f_cnt < format_ary.length;f_cnt++){
					//無視する文字
					if(!format_ary[f_cnt] || format_ary[f_cnt] == 'w') continue;
					eval('a = ' + format_ary[f_cnt] + '_num');
					if(a == ""){
						if($('cms_kanko_require_'+itemName)){
							alert(targetItemName + 'が入力されていません。');
							$('cms_kanko_date_' + itemName + '_' + format_ary[f_cnt]).focus();
							return false;
						}
					}
				}
				//必須で無く、入力が無い場合
				if(!$('cms_kanko_require_'+itemName)){
					//全ての入力をチェック
					var input_num = format_ary.length;
					for(var f_cnt = 0,no_input_cnt = 0;f_cnt < format_ary.length;f_cnt++){
						if(!format_ary[f_cnt] || format_ary[f_cnt] == 'w'){
							input_num--;
							continue;
						}
						eval('if(' + format_ary[f_cnt] + '_num == "") no_input_cnt++;');
					}
					//入力されているものが無い場合
					if(no_input_cnt == input_num) break;
				}

				//入力がある場合

				// 期間の指定があった場合
				if($('cms_kanko_date_'+itemName+'_p')){
					switch(p){
						case KANKO_PREOD_FIRST:
							p_day = KANKO_PREOD_FIRST_DAY;
							break;
						case KANKO_PREOD_MIDDLE:
							p_day =KANKO_PREOD_MIDDLE_DAY;
							break;
						case KANKO_PREOD_LATTER:
							p_day = KANKO_PREOD_LATTER_DAY;
							break;
						default :
							p_day = "";
							break;
					}
					if(d_num == ""){
						$('cms_kanko_date_'+itemName+'_d').value = p_day;
					}
					else if(p_day != "" && Number(p_day)+9 < Number(d_num) || Number(p_day) > Number(d_num)){
						$('cms_kanko_date_'+itemName+'_d').value = p_day;
					}
				}

				dc = cxDateCheckNew('cms_kanko_date_' + itemName,format_ary.join(""),4,targetItemName);
				msg = new Array();
				msg = msg.concat(dc);
				if (msg.length > 0) {
					msg_str = msg.join('\n');
					alert(msg_str);
					$('cms_kanko_date_'+itemName+'_y').focus();
					return false;
				}
				break;
			case "link":
			case "file":
			case "mail":
			case "image":
			// オープンデータ
			// 定型typeオープンデータ
			case "opendata":
				if($F('cms_kanko_'+itemName) == KANKO_LINK_DELIMITER) {
					if($('cms_kanko_require_'+itemName)){
						alert(targetItemName+'が入力されていません。');
						return false;
					}
				}
				else{
					tmpAry = $F('cms_kanko_'+itemName).split(KANKO_LINK_DELIMITER);
					if(tmpAry[1] != undefined){
						info = accItemCheck(targetItemName, tmpAry[1], info, type);
					}
				}
				break;
		}
	}

	// グループ必須チェック
	for(i = 0; i < group_needs.length; i++){
		empty_cnt = 0;
		itemNames = "";
		group_need = group_needs[i].split(",");
		for(j = 0; j < group_need.length; j++){
			itemName = group_need[j];
			hiddenVal = $F("cms_kanko_hidden_"+itemName);
			tmp = hiddenVal.split(":");
			type = tmp[0];
			kind = tmp[1];
			switch (type){
				case "text":
				case "textarea":
					if($F('cms_kanko_'+itemName) == "") empty_cnt++;
					break;
				case "customarea":
					if($("cms_kanko_"+itemName).value == "") empty_cnt++;
					break;
				case "radio":
				case "checkbox":
					isChecked = false;
					var checkbox_elements = (type == "checkbox")
											? Form.getInputs(form_name,type,'cms_kanko_'+itemName+'[]')
											: Form.getInputs(form_name,type,'cms_kanko_'+itemName); 
					checkbox_elements.each( 
						function(val,idx) {
							radioId = val.id;
							if(radioId.indexOf("cms_kanko_"+itemName) == 0){
								if($(radioId).checked) isChecked = true;
							}
						}
					);
					if(!isChecked) empty_cnt++;
					break;
				case "select":
					if(areaId == undefined){
						optionItem = document;
					} else {
						optionItem = document.all(areaId);
					}
					isChecked = false;
					for (k = 0; k < optionItem.getElementsByTagName("option").length; k++) {
						optionId = optionItem.getElementsByTagName("option")[k].getAttribute("ID");
						if(optionId == null)continue;
						if(optionId.indexOf("cms_kanko_"+itemName) == 0){
							if($(optionId).selected && $(optionId).value != ""){
								isChecked = true;
								break;
							}
						}
					}
					if(!isChecked) empty_cnt++;
					break;
				case "date":
					format = ($('cms_kanko_date_format_' + itemName) ? $F('cms_kanko_date_format_' + itemName) : "");
					var format_ary = format.toArray();
					for(var f_cnt = 0;f_cnt < format_ary.length;f_cnt++){
						//小文字に変換
						format_ary[f_cnt] = format_ary[f_cnt].toLowerCase();
						// 強制的に終了する文字
						if(format_ary[f_cnt] == '_'){
							for(var end_cnt = f_cnt;end_cnt < format_ary.length;end_cnt++){
								format_ary[end_cnt] = null;
							}
							break;
						}
						//無視する文字
						if(format_ary[f_cnt] == 'w'){
							format_ary[f_cnt] = null;
							continue;
						}
						//一部の文字を変換
						if(format_ary[f_cnt] == 'n') format_ary[f_cnt] = 'm';
						if(format_ary[f_cnt] == 'j') format_ary[f_cnt] = 'd';
						eval('var ' + format_ary[f_cnt] + '_num = ' + ($('cms_kanko_date_' + itemName+'_' + format_ary[f_cnt]) ? ($F('cms_kanko_date_' + itemName + '_' + format_ary[f_cnt]) ? '"' + cxEscapeHtmlChars($F('cms_kanko_date_' + itemName + '_' + format_ary[f_cnt])) + '"' : "\"\"") : "\"\""));
					}
					p = ($('cms_kanko_date_'+itemName+'_p') ? $F('cms_kanko_date_'+itemName+'_p') : "");
					// 必須チェック
					var require_err_flg = false;
					for(var f_cnt = 0;f_cnt < format_ary.length;f_cnt++){
						//無視する文字
						if(!format_ary[f_cnt] || format_ary[f_cnt] == 'w') continue;
						eval('a = ' + format_ary[f_cnt] + '_num');
						if(a == ""){
							empty_cnt++;
							break;
						}
					}
					break;
				case "link":
				case "file":
				case "mail":
				case "image":
				// オープンデータ
				// 定型typeオープンデータ
				case "opendata":
					if($F('cms_kanko_'+itemName) == KANKO_LINK_DELIMITER) empty_cnt++;
					break;
			}
			
			itemNames += (kind == "meta")?$('cms_kanko_name_'+itemName).innerHTML+"　":$F('cms_kanko_name_'+itemName)+"　";
		}
		if(empty_cnt == group_need.length){
			alert(itemNames+"のどれかを入力してください。");
			return false;
		}
	}
	if (info.length > 0) {
		var msg = info.join('\n') + '\nよろしいですか？';
		if (!confirm(msg)) return false;
	}
}

function kankoCustomItemCreate() {
	kankoItem = document;
	for (fixed_cnt = 0; fixed_cnt < kankoItem.getElementsByTagName("input").length; fixed_cnt++) {
		id = kankoItem.getElementsByTagName("input")[fixed_cnt].getAttribute("ID");
		if(id == null)continue;
		if(id.indexOf("cms_kanko_hidden_") == 0){
			itemName = id.replace("cms_kanko_hidden_","");
			hiddenVal = $F(id);
			tmp = hiddenVal.split(":");
			type = tmp[0];
			if(type == "customarea"){
				eval("wEditor_"+itemName+".saveEditor()")
				$("cms_kanko_"+itemName).value = eval("wEditor_"+itemName+".saveHTML");
			}
		}
	}	
}

function kankoPropertyOpen(areaId){
	kankoItem = document.all(areaId);
	for (i = 0; i < kankoItem.getElementsByTagName("input").length; i++) {
		id = kankoItem.getElementsByTagName("input")[i].getAttribute("ID");
		if(id == null)continue;
		if(id.indexOf("cms_kanko_hidden_") == 0){
			itemName = id.replace("cms_kanko_hidden_","");
			hiddenVal = $F(id);
			tmp = hiddenVal.split(":");
			type = tmp[0];
			switch (type){
				case "text":
				case "textarea":
					cmsKankoPropAry[itemName] = $F('cms_kanko_'+itemName);
					break;
				case "radio":
				case "checkbox":
					radioItem = document.all(areaId);
					checkedValue = "";
					for (j = 0; j < radioItem.getElementsByTagName("input").length; j++) {
						radioId = radioItem.getElementsByTagName("input")[j].getAttribute("ID");
						if(radioId == null)continue;
						if(radioId.indexOf("cms_kanko_"+itemName) == 0){
							if($(radioId).checked){
								if(checkedValue != "")checkedValue = checkedValue + ",";
								checkedValue = checkedValue + $F(radioId);
							}
						}
					}
					cmsKankoPropAry[itemName] = checkedValue;
					break;
				case "select":
					cmsKankoPropAry[itemName] = $F('cms_kanko_'+itemName);
					break;
			}
		}
	}
}
function kankoPropertyClose(areaId){
	for (key in cmsKankoPropAry) {
		if($("cms_kanko_hidden_"+key) && cmsKankoPropAry[key] != null){
			hiddenVal = $F("cms_kanko_hidden_"+key);
			tmp = hiddenVal.split(":");
			type = tmp[0];
			switch (type){
				case "text":
				case "textarea":
					$('cms_kanko_'+key).value = cmsKankoPropAry[key];
					break;
				case "radio":
				case "checkbox":
					checkedValue = cmsKankoPropAry[key];
					checkedValueAry = checkedValue.split(",");
					radioItem = document.all(areaId);
					for (j = 0; j < radioItem.getElementsByTagName("input").length; j++) {
						radioId = radioItem.getElementsByTagName("input")[j].getAttribute("ID");
						if (radioId == null) {
							continue;
						}
						if (radioId.indexOf("cms_kanko_" + key) == 0) {
							for (k = 0; k < checkedValueAry.length; k++) {
								if ($(radioId).value == checkedValueAry[k]) {
									$(radioId).checked = true;
									break;
								}
								else {
									$(radioId).checked = false;
								}
							}
						}
					}
					break;
				case "select":
					checkedValue = cmsKankoPropAry[key];
					if($("cms_kanko_"+key+"_"+checkedValue)){
						$("cms_kanko_"+key+"_"+checkedValue).selected = true;
					} else {
						$("cms_kanko_"+key+"_").selected = true;
					}
					break;
			}
		}
	}
}
