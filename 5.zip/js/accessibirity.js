/*
 *
 */
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
cxPreImages(cms8341admin_path+'/images/menu/close01_btn.jpg',
		   cms8341admin_path+'/images/menu/close02_btn.jpg');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//置換チェックボックス
function cxAccReplace() {
	if (!confirm("一時保存または編集完了をしていない場合、変換を行うと元に戻すことができません。\nよろしいですか？")) {
		return false;
	}
	document.cms_fAcc.target = 'win_cms8341Main';
	document.cms_fAcc.submit();
	window.close();
	return false;
}

//全てのチェックボックスOFF
function cxReleaseAll() {
	var alElem = document['cms_fAcc']['acc_error[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = false;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = false;
			}
		}
	}
}

//全てのチェックボックスON
function cxCheckAll() {
	var alElem = document['cms_fAcc']['acc_error[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = true;
		// some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = true;
			}
		}
	}
}

set_x=-20;	//オフセットX
set_y=-20;	//オフセットY
//--------------------------------------
/*
 * エラー情報ポップアップ表示
 */
document.write("<div id='acc_err_popup' class='cms8341-acc_err_popup' onMouseout=\"cxPopUpClose()\"></div>");
function cxPopUpOpen(cnt){
	divid="acc_err_popup";
	if(document.all){
		d_div=document.all(divid);
		rx = event.clientX + (document.documentElement.scrollLeft || document.body.scrollLeft) + set_x;
		ry = event.clientY + (document.documentElement.scrollTop || document.body.scrollTop) + set_y;
	}else{
		d_div=document.getElementById(divid);
		rx = NNX + set_x;
		ry = NNY + set_y;
	}
	
	var settxt = "";
	var check_name = "";
	var massage = "";
	var target = "";
	var replace = "";
	var caption = "";
	var summary = "";
	
	if ($("cms_pop_up_err_class_" + cnt) && $("cms_pop_up_err_class_" + cnt).value != "") {
		// チェック項目名称
		if ($("cms_pop_up_err_check_name_" + cnt)) {
			check_name = $("cms_pop_up_err_check_name_" + cnt).value;
		}
		// メッセージ
		if ($("cms_pop_up_err_msg_" + cnt)) {
			massage = $("cms_pop_up_err_msg_" + cnt).value;
		}
		// 対象文言
		if ($("cms_pop_up_err_target_" + cnt)) {
			target = $("cms_pop_up_err_target_" + cnt).value;
		}
		// 変換文言
		if ($("cms_pop_up_err_replace_" + cnt)) {
			replace = $("cms_pop_up_err_replace_" + cnt).value;
		}
		// キャプション
		if ($("cms_pop_up_err_caption_" + cnt)) {
			caption = $("cms_pop_up_err_caption_" + cnt).value;
		}
		// テーブル目的/構造
		if ($("cms_pop_up_err_summary_" + cnt)) {
			summary = $("cms_pop_up_err_summary_" + cnt).value;
		}
		
		
		var chk_class = $("cms_pop_up_err_class_" + cnt).value;
		switch (chk_class) {
			case CHECK_CLASS_LINK_TEXT :
				settxt += "チェック項目名称 : 【" + check_name + "】" + "<br><br>";
				settxt += "エラーメッセージ : 【" + massage + "】" + "<br>";
				settxt += "リンクテキスト : 【" + target + "】" + "<br>";
				break;
			case CHECK_CLASS_ALT_TEXT :
				settxt += "チェック項目名称 : 【" + check_name + "】" + "<br><br>";
				settxt += "エラーメッセージ : 【" + massage + "】" + "<br>";
				settxt += "代替テキスト : 【" + target + "】" + "<br>";
				break;
			case CHECK_CLASS_TABLE :
				settxt += "チェック項目名称 : 【" + check_name + "】" + "<br><br>";
				settxt += "エラーメッセージ : 【" + massage + "】" + "<br>";
				if (caption != "") {
					settxt += "キャプション : 【" + caption + "】" + "<br>";
				}
				if (summary != "") {
					settxt += "テーブル目的/構造 : 【" + summary + "】" + "<br>";
				}
				break;
			default :
				settxt += "チェック項目名称 : 【" + check_name + "】" + "<br><br>";
				if (massage != "") {
					settxt += "エラーメッセージ : 【" + massage + "】" + "<br>";
				}
				settxt += "変換対象文言 : 【" + target + "】" + "<br>";
				settxt += "変換後文言 : 【" + replace + "】" + "<br>";
				break;
		}
	}

	if(settxt != ""){
		d_div.style.display="block";
		d_div.style.left = rx +"px";
		d_div.style.top = ry +"px";
		d_div.innerHTML = settxt; 
	}else{
		d_div.style.display="none"; 
		d_div.innerHTML = "";
	}
}
/*
* エラー情報ポップアップ非表示
*/
function cxPopUpClose() {
	d_div.style.display="none"; 
	d_div.innerHTML = "";
}
function MouseXY(NNevent){
	NNX = NNevent.pageX;
	NNY = NNevent.pageY;
}
window.onmousemove = MouseXY;


var border = "";
var borderColor = "";
/*
 * レイアウトテーブルボーダーON
 */
function cxBorderOn(id) {
	// テーブルオブジェクト取得
	var obj = document.getElementsByTagName('table');
	
	// 対象となるテーブルオブジェクト変数初期化
	var target_obj = new Object;
	
	var flg = false; 
	for (i = 0; i < obj.length; i++) {
		// 「_cms_voice_reading」要素の値と引数で指定されたidが同一だった場合
		if (obj[i].getAttribute('_cms_voice_reading') == id) {
			// 対象となるテーブルオブジェクトを保持
			target_obj = obj[i];
			// 現在指定されているボーダーを保持
			border = (target_obj.border != undefined ? target_obj.border : 0);
			// 現在指定されているボーダーカラーを保持
			borderColor = (target_obj.borderColor != undefined ? target_obj.borderColor : "");
			// 対象となるテーブルオブジェクトの保持に成功した場合フラグをONにする
			flg = true;
			break;
		}
	}
	
	// 対象となるテーブルオブジェクトの保持に成功していた場合
	if (flg == true) {
//		target_obj.style.borderStyle = "solid";
		// ボーダーに「1」をセット
		target_obj.border = 1;
		// ボーダーカラーに「青」をセット
		target_obj.borderColor = "blue";
	}
}

/*
 * レイアウトテーブルボーダーOFF
 */
function cxBorderOff(id) {
	// テーブルオブジェクト取得
	var obj = document.getElementsByTagName('table');
	
	// 対象となるテーブルオブジェクト変数初期化
	var target_obj = new Object;
	
	var flg = false; 
	for (i = 0; i < obj.length; i++) {
		// 「_cms_voice_reading」要素の値と引数で指定されたidが同一だった場合
		if (obj[i].getAttribute('_cms_voice_reading') == id) {
			// 対象となるテーブルオブジェクトを保持
			target_obj = obj[i];
			// 対象となるテーブルオブジェクトの保持に成功した場合フラグをONにする
			flg = true;
			break;
		}
	}
	
	// 対象となるテーブルオブジェクトの保持に成功していた場合
	if (flg == true) {
//		target_obj.style.borderStyle = "none";
		// ボーダーに保持していた値又は「0」をセット
		target_obj.border = (border != "" ? border : 0);
		// ボーダーカラーに保持していた値をセット
		target_obj.borderColor = borderColor;
		// ボーダー保持用変数を空にする
		border = "";
		// ボーダーカラー保持用変数を空にする
		borderColor = "";
	}
}

/*
 * 音声読み上げ順表示
 */
function cxVoiceReading(id) {

	// ボーダーを非表示にする
	cxBorderOff(id);
	
	// 音声読み上げ順を表示するテーブル文字列を取得
	if ($("cms_voice_reading_" + id)) {
		str = $("cms_voice_reading_" + id).value;
		
		
		var dom = String2DOM(str);
		var table_dom = dom.childNodes[0];
		
		// レイヤーテーブルに枠を表示
		table_dom.border = 1;
		table_dom.borderColor = "blue";
		table_dom.cellspacing = 0;
		table_dom.cellpadding = 0;
		
		
		// テーブルの子ノード分処理を行う
		var voice_reading_cnt = 1;
		for (table_cnt = 0; table_cnt < table_dom.childNodes.length; table_cnt++) {
			// 取得したノードのタグ名が「TBODY」「TR」意外だった場合処理を行わない
			if (table_dom.childNodes[table_cnt].tagName != "TBODY" && table_dom.childNodes[table_cnt].tagName != "TR") {
				continue;
			}
			
			// 取得したノードのタグ名が「TBODY」だった場合子ノードを取得していく
			if (table_dom.childNodes[table_cnt].tagName == "TBODY") {
				var tbody_dom = table_dom.childNodes[table_cnt];
				
				for (tbody_cnt = 0; tbody_cnt < tbody_dom.childNodes.length; tbody_cnt++) {
					if (tbody_dom.childNodes[tbody_cnt].tagName == "TR") {
						var tr_dom = tbody_dom.childNodes[tbody_cnt];
						for (tr_cnt = 0; tr_cnt < tr_dom.childNodes.length; tr_cnt++) {
							// 取得したノードのタグ名が「TH」「TD」だった場合に音声読み上げ順を追記する
							if (tr_dom.childNodes[tr_cnt].tagName == "TH" || tr_dom.childNodes[tr_cnt].tagName == "TD") {
								
								inner_HTML = '<img alt="音声読み上げ順" width="105" height="20" src="' + cms8341admin_path + '/images/accessiblity/voice_reading_cnt.jpg" />' + "【" + voice_reading_cnt + "】" + "<br>" + "\n" + "<br>" + "\n";
								inner_HTML += tr_dom.childNodes[tr_cnt].innerHTML;
								tr_dom.childNodes[tr_cnt].innerHTML = inner_HTML;
								voice_reading_cnt++;
							}
						}
					}
				}
			} else if(table_dom.childNodes[table_cnt].tagName == "TR") {
				var tr_dom = table_dom.childNodes[table_cnt];
				for (tr_cnt = 0; tr_cnt < tr_dom.childNodes.length; tr_cnt++) {
					// 取得したノードのタグ名が「TH」「TD」だった場合に音声読み上げ順を追記する
					if (tr_dom.childNodes[tr_cnt].tagName == "TH" || tr_dom.childNodes[tr_cnt].tagName == "TD") {
						inner_HTML = '<img alt="音声読み上げ順" width="105" height="20" src="' + cms8341admin_path + '/images/accessiblity/voice_reading_cnt.jpg" />' + "【" + voice_reading_cnt + "】" + "<br>" + "\n" + "<br>" + "\n";
						inner_HTML += tr_dom.childNodes[tr_cnt].innerHTML;
						tr_dom.childNodes[tr_cnt].innerHTML = inner_HTML;
						voice_reading_cnt++;
					}
				}
			}
		}
		
		// 別ウィンドウにて表示するHTML文字列作成
		str = $("cms_style_hidden").value;
		str += "<body>" + "\n";
		str += dom.innerHTML + "\n";
		str += "</body>" + "\n";
		str += "</html>";
		
		// 別ウィンドウ作成
		var htmlsource = window.open("", "accessibirity", "");
		htmlsource.document.open();
		htmlsource.document.write(str);
		htmlsource.document.close();
	} else {
		alert("音声読み上げ順表示に失敗しました。");
	}
}