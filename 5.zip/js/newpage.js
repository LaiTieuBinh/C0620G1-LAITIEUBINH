/*
 * 新規ページ作成
 */
//contentsmenu preload images
cxPreImages(cms8341admin_path+'/images/icon/icon-list-green.jpg',
			cms8341admin_path+'/images/btn/btn_del_mini.gif',
			cms8341admin_path+'/images/btn/btn_del_mini.jpg');

//**
//テンプレート選択処理
function cxSelectTemplate(v) {
	var t_id = 'cms_template_' + v;
	$('cms_template_image').src = $(t_id).src;
}
//決定処理
var cmsCateTop = '';
function cxSubmit(uc) {
	var info = new Array();
	var kind = $F('cms_template_kind');
	//入力チェック
	if(!$('cms_page_title').value) {
		alert('タイトルが入力されていません。');
		$('cms_page_title').focus();
		return false;
	}
	if (!$('cms_cate1').value) {
		alert('分類が選択されていません。');
		$('cms_cate1').focus();
		return false;
	}
	if(kind == TEMPLATE_KIND_ENQUETE){
		if(!$('cms_enquete_kind_0').checked && !$('cms_enquete_kind_1').checked) {
			alert('アンケート種別が選択されていません。');
			$('cms_enquete_kind_0').focus();
			return false;
		}
		mail_cnt = 0;
		if($('cms_enquete_kind_1').checked){
			enqEl = document.all("cms8341-newpage");
			for (i = 0; i < enqEl.getElementsByTagName("span").length; i++) {
				id = enqEl.getElementsByTagName("span")[i].getAttribute("ID");
				if(id == null) continue;
				if(id.indexOf("cms_enqmail_") == 0){
					id = id.slice("cms_enqmail_".length); 
					if($F('cms_enq_email') == ""){
						$('cms_enq_email').value = $('cms_enqmail_'+id).innerHTML + ":" + $('cms_enqname_'+id).innerHTML;
					} else {
						$('cms_enq_email').value = $F('cms_enq_email') + "," + $('cms_enqmail_'+id).innerHTML + ":" + $('cms_enqname_'+id).innerHTML;
					}
					mail_cnt++;
				}
			}
			if(mail_cnt == 0){
				alert('アンケート種別が問い合わせの場合はメールアドレスを選択してください。');
				$('cms_enquete_kind_1').focus();
				return false;
			}
		}
	}
	else if(kind == TEMPLATE_KIND_FIXED){
		// 観光種類がイベントの場合
		if ( $('cms_template_kanko_type') && $F('cms_template_kanko_type') == KANKO_TYPE_EVENT ) {
			// イベントカレンダー複数日
			if (EVENT_CAL_MULTI_FLAG == true) {
				// 要素数の取得
				var element_no = document.getElementById('cms_pd_count').value;
				
				// 開始日に入力箇所がある件数を取得
				var input_count = 0;
				for(var i=1 ; i <= element_no ; i++) {
					// 入力欄削除により要素が無ければスキップ
					if (document.getElementById('cms_pd' + i + 'sy') == null) {
						continue;
					}
					if (document.getElementById('cms_pd' + i + 'sy').value != "" && document.getElementById('cms_pd' + i + 'sm').value != "" && document.getElementById('cms_pd' + i + 'sd').value != ""){
						++input_count;
					}
				}
				var no_check_flg = (input_count == 0)?false:true;
				var pd_elem = new Array('sy', 'sm', 'sd', 'sh', 'si', 'ey', 'em', 'ed', 'eh', 'ei');
				var pd = new Array();
				
				// 要素ごとの日付をチェック
				for(var i = 1 ; i <= element_no; i++) {
					// 入力欄削除により要素が無ければスキップ
					if(document.getElementById('cms_pd' + i + 'sy') == null) {
						continue;
					}
					
					// 日時を配列に格納
					for(var key in pd_elem) {
						if(document.getElementById('cms_pd' + i + pd_elem[key]) == null) {
							continue;
						}
						pd[pd_elem[key]] = document.getElementById('cms_pd' + i + pd_elem[key]).value;
					}
					
					// 1行でも開始日が入力されている場合に開始日と終了日が空白の場合はスキップ
					if((pd['sy'] == '' && pd['sm'] == '' && pd['sd'] == '' && pd['sh'] == '' && pd['si'] == '' && pd['ey'] == '' && pd['em'] == '' && pd['ed'] == '' && pd['eh'] == '' && pd['ei'] == '') && no_check_flg == true) {
						continue;
					}
					
					// チェック結果格納用配列
					var dc = new Array();
					var res_error = new Array();
					
					// 開始日チェック
					if(document.getElementById('cms_pd' + i + 'sy').value != "" || document.getElementById('cms_pd' + i + 'sm').value != "" || document.getElementById('cms_pd' + i + 'sd').value != "" || input_count == 0){
						var err = cxDateCheckNew('cms_pd' + i, 'ymd', 2, '開催日');
						res_error.push(err.join('\n'));
					}
					
					// 終了日チェック
					if(document.getElementById('cms_pd' + i + 'ey').value != "" || document.getElementById('cms_pd' + i + 'em').value != "" || document.getElementById('cms_pd' + i + 'ed').value != ""){
						var err = cxDateCheckNew('cms_pd' + i, 'ymd', 1, '開催日');
						res_error.push(err.join('\n'));
					}
					
					// 開始時間チェック
					if(document.getElementById('cms_pd' + i + 'sh').value != "" || document.getElementById('cms_pd' + i + 'si').value != "") {
						var err = cxDateCheckNew('cms_pd' + i, 'hi', 2, '開催日');
						res_error.push(err.join('\n'));
					}
					
					// 終了時間チェック
					if(document.getElementById('cms_pd' + i + 'eh').value != "" || document.getElementById('cms_pd' + i + 'ei').value != "") {
						var err = cxDateCheckNew('cms_pd' + i, 'hi', 3, '開催日');
						res_error.push(err.join('\n'));
					}
					
					// エラーの重複を取り除く
					var error_msg = new Array();
					for(var j in res_error) {
						if(j.match(/[^0-9]/g)) continue;
						if(res_error[j] == '') continue;
						if(error_msg.indexOf(res_error[j]) != -1) continue;
						error_msg.push(res_error[j]);
					}
					if(error_msg.length > 0) {
						dc.push(error_msg.join('\n'));
					}
					
					// エラーメッセージ作成
					msg = new Array();
					msg = msg.concat(dc);
					if (msg.length > 0) {
						msg_str = msg.join('\n');
						alert(msg_str);
							$('cms_pd' + i + 'sy').focus();
						return false;
					}
				}
				var cal_input_area = document.getElementById('calendar_input_area');
				var event_set_limit = parseInt(document.getElementById('cms_pd_limit').value);
				var element_cnt = cal_input_area.getElementsByTagName('tr').length;
				
				// 設定上限を超えている場合はアラートを表示
				if(event_set_limit < element_cnt) {
					alert("開催期間を設定可能な件数を超えています。\n設定可能な開催期間は"+ event_set_limit + "件までです。");
					return false;
				}
			}
			// イベントカレンダー単一日
			else {
				if($F('cms_pdey') == "" && $F('cms_pdem') == "" && $F('cms_pded') == ""){
					dc = cxDateCheckNew('cms_pd', 'ymd', 2, '開催日');
				} else {
					dc = cxDateCheckNew('cms_pd', 'ymd', 1, '開催日');
				}
				msg = new Array();
				msg = msg.concat(dc);
				if (msg.length > 0) {
					msg_str = msg.join('\n');
					alert(msg_str);
					$('cms_pdsy').focus();
					return false;
				}
			}
		}
	}
	
	if ( $('cms_inquiry_tr') && ( ! $('cms_inquiry_tr').style || $('cms_inquiry_tr').style.display != "none" ) ) {
		info = cxInquiryCheck('cms_inquiry',info);
	}
	if(!info)return false;
	
	// 問い合わせ先の第三組織まで必須チェック機能
	var inquiry_table = $('cms_inquiry_table').style.display;
	if (CHECK_INQUIRY_DEPARTMENT_FLG && inquiry_table != 'none') {
		var inquiry_item = Number($('cms_inquiry_cnt').value);
		for (var i = 1; i <= inquiry_item; i++) {
			var dept_name_1 = $('cms_inquiry_dept1_' + i);
			if (dept_name_1 && dept_name_1.value != '') {
				for (var index = 1; index <= CHECK_INQUIRY_DEPARTMENT_DEPTH; index++) {
					var dept_name = $('cms_inquiry_dept' + index + '_' + i);
					if (dept_name.value == '') {
						alert($('cms_inquiry_no_' + i ).innerHTML + '：所属課室には、第' + CHECK_INQUIRY_DEPARTMENT_DEPTH +'階層の組織まで指定してください。\n「指定なし」は選択できません。');
						dept_name.focus();
						return false;
					}
				}
			}
		}
	}

	if(!$('cms_template_id').value) {
		alert('テンプレートが選択されていません。');
		cxTemplateSet();
		return false;
	}
	//アンケートでSSLがON以外のとき
	if (!($F('cms_ssl_flg') == 1 && kind == TEMPLATE_KIND_ENQUETE)) {
		if(!$('cms_dir_path').value || !$('cms_filename').value) {
			alert('ファイルの保存先が設定されていません。');
			cxRefferSet();
			return false;
		}
	}
	if(kind == TEMPLATE_KIND_ENQUETE && $F('cms_ssl_flg') == 1){
		if($F('cms_file_name') == ""){
			alert('ファイルの保存先が入力されていません。');
			$('cms_file_name').focus();
			return false;
		} else if ($F('cms_file_name').match(/[\\\/:\*\?<>\|\.]/)) {
			alert('ファイル名には以下の文字は使えません\n\ / : * ? " < > | .');
			$('cms_file_name').focus();
			return false;
		} else if ($F('cms_file_name').match(/[^\w\-_\.]/i)) {
			alert('ファイル名は半角英数字で入力してください');
			$('cms_file_name').focus();
			return false;
		}
		
		$('cms_filename').value = $F('cms_file_name') + ".html";
		$('cms_dir_path').value = $F('cms_ssl_dir');
	}
	
	// ファイル名を小文字に変換
	$('cms_filename').value = $F('cms_filename').toLowerCase();
	
	//観光入力チェック
	if($('cms_kanko_area') && kankoCheck("cms_kanko_area") == false) return false;
	
	info = fckCheck('タイトル',$('cms_page_title').value,info);
	info = fckCheck('検索エンジン用キーワード',$('cms_keywords').value, info);
	info = fckCheck('検索エンジン用説明文',$('cms_description').value, info);
	info = fckCheck('要約文',$('cms_summary').value, info);
	if(!info)return false;
	if (info.length > 0) {
		var msg = info.join('\n') + '\nよろしいですか？';
		if (!confirm(msg)) {
			return false;
		}
	}
	
	// オープンデータ
	// オープンデータが選択されているかチェック
	var select_opendata_flg = false;
	var opendata_id_elem = document.getElementsByName("opendata_id[]");
	for (i = 0; i < opendata_id_elem.length; i++ ) {
		if (opendata_id_elem.item(i).checked == true) {
			select_opendata_flg = true;
		}
	}
	if (select_opendata_flg) {
		// オープンデータ概要
		var summary_txt = trim($F('opendata_summary'));
		// 必須チェック
		if(summary_txt.length == 0){
			alert("概要を入力してください。");
			$('opendata_summary').focus();
			return false;
		}
		// 機種依存文字チェック
		info = new Array();
		info = fckCheck('概要',summary_txt,info);
		info = accItemCheck('概要',summary_txt,info,'file');
		if (!info) {
			alert("[概要]入力値チェックエラー");
			return false;
		}
		if(info.length > 0){
			var msg = info.join('\n') + '\nよろしいですか？';
			if(!confirm(msg)){
				$('opendata_summary').focus();
				return false;
			}
		}
		// ライセンス必須チェック
		var license_txt = trim($('opendata_license').value);
		if(license_txt.length == 0){
			alert("ライセンスを選択してください。");
			$('opendata_license').focus();
			return false;
		}
		// データ時点入力日付チェック
		if (!($F('opendata_poit_timesy') == "" && $F('opendata_poit_timesm') == "" && $F('opendata_poit_timesd') == "")) {
			var date_check_result = cxDateCheckNew("opendata_poit_time", "ymd", 2, "データ時点");
			if (!disp_date_error(date_check_result, "opendata_poit_timesy")) {
				return false;
			}
		} else {
			alert("データ時点を入力してください。");
			$('opendata_poit_timesy').focus();
			return false;
		}
		// 掲載日
		if (!($F('opendata_pubsy') == "" && $F('opendata_pubsm') == "" && $F('opendata_pubsd') == "")) {
			var date_check_result = cxDateCheckNew("opendata_pub", "ymd", 2, "掲載日");
			if (!disp_date_error(date_check_result, "opendata_pubsy")) {
				return false;
			}
		} else {
			alert("掲載日を入力してください。");
			$('opendata_pubsy').focus();
			return false;
		}
		// カテゴリ必須チェック
		if (!isCheck('opendata_category[]', "checkbox") ) {
			alert("カテゴリを選択してください。");
			return false;
		}
		// データタイプ必須チェック
		var od_data_type_txt = trim($('od_data_type').value);
		if(od_data_type_txt.length == 0){
			alert("データタイプを選択してください。");
			$('od_data_type').focus();
			return false;
		}
		// キーワード検索タグ
		var keyword_search_txt = trim($F('opendata_keywords'));
		// 機種依存文字チェック
		info = new Array();
		info = fckCheck('キーワード検索タグ',keyword_search_txt,info);
		info = accItemCheck('キーワード検索タグ',keyword_search_txt,info,'file');
		if (!info) {
			alert("[キーワード検索タグ]入力値チェックエラー");
			return false;
		}
		if(info.length > 0){
			var msg = info.join('\n') + '\nよろしいですか？';
			if(!confirm(msg)){
				$('opendata_keywords').focus();
				return false;
			}
		}
	}
	
	//main
	document.cms_fAddpage.submit();
	return false;
}

// オープンデータ
/**
*	チェックされている値の取得
*	@palam id Name
*	@palam item アイテム名
*	return チェックされている項目が存在したらValue値、しなかったらFalse
*/
function getCheckValue(id, item){
	var ret = false;
	var nodes = Form.getInputs($('cms_fAddpage'), item, id);
	$A(nodes).each( function(obj) { 
						if(obj.checked) ret = obj.value;
					} ); 
	return ret;
}

// チェックされているかチェック
function isCheck(id, item){
	ret = getCheckValue(id, item);
	return ret;
}

/*********************************************************************************************************************/

function cxGetLabelText(e_id) {
	var le = document.getElementsByTagName('label');
	for(var i=0;i<le.length;i++) {
		var o = le[i].outerHTML;
		var c = o.indexOf(e_id);
		if(c!=-1) {
			return le[i].innerHTML;
		}
	}
	//return false;
}

//テンプレート選択処理
var cmsTemplate = null;
function cxTemplateSet() {
	cmsTemplate = document.cms_fAddpage.cms_template_id.options.selectedIndex;
	//close
	cxLayer('cms8341-reffer',0);
	cxCalendarClose();
	//hidden
	cxComboHidden(new Array("cms_template_id"));
	$('cms_thumb').contentWindow.document.body.style.zoom = 0.5;
	$('cms_thumb').contentWindow.document.body.style.position = "relative";
	cxLayer('cms8341-template-select',1,800,490);
}
//
var cms_sid;
var cms_inv_cnt = 0;
var cms_inv_tim = 200;
var cms_inv_max = 25;
function cxSelectTemplate() {
	var si,src,srcThumb;
	si = $('cms_template_id').options.selectedIndex;
	if(si >= 0) {
			src = $('cms_template_id').options[si].id;
			// テンプレート選択画面のプレビューでレスポンシブをOFF
			$('cms_thumb').src = cms8341admin_path+"/page/common/tplview.php?path=" + encodeURI(src) + '&thum=1';
			if(cms_sid) clearInterval(cms_sid);
		cms_sid = 0;
		cms_inv_cnt = 0;
		cms_sid = setInterval(cxIFrameZoom,cms_inv_tim);
	} else {
		$('cms_thumb').src = 'javascript:';
	}
}
function cxIFrameZoom() {
	if($('cms_thumb').contentWindow.document.body){
		var thumb_body = $('cms_thumb').contentWindow.document.body;
		thumb_body.style.position = "relative";
		thumb_body.style.transform = "scale(0.5)";
		thumb_body.style.transformOrigin = "0 0";
		thumb_body.style.webkitTransform = "scale(0.5)";
		thumb_body.style.webkitTransformOrigin = "0 0";
	}
	//
	cms_inv_cnt++;
	if(cms_inv_cnt > cms_inv_max) {
		clearInterval(cms_sid);
		cms_inv_cnt = 0;
	}
}
function cxTemplateSubmit() {
	var si,label,cate;
	si	= $('cms_template_id').options.selectedIndex;
	cmsTemplate = si;
	if (si >= 0) {
		label = $('cms_template_id').options[si].text;
		cate = 'テンプレート';
		$('cms-template-selected').innerHTML = cate + '：' + label + ' が選択されています。';
		$('cms_template_kind').value = $('cms_template_id').options[si].getAttribute('_kind');
		$('cms_template_kanko_type').value = $('cms_template_id').options[si].getAttribute('_kanko_type');
		if ($('cms_template_id').options[si].getAttribute('_ver')) {
			$('cms_template_ver').value = $('cms_template_id').options[si].getAttribute('_ver');
		}
		
		// 初めての選択の場合検索エンジン用キーワードを設定
		if ( $('cms_keyword_tr').style.display == 'none' ) {
			cxGetTemplateKeywords('cms_keywords','cms_template_id','cms_template_ver');
		}
		
		cxDispChange();
		// 問い合わせ初期化
		for(var i=2; i< Number($F('cms_inquiry_cnt'))+1; i++){
			if($('cms_inquiry_'+i)){
				Element.remove($('cms_inquiry_'+i));
			}
		}
		$('cms_inquiry_cnt').value = 1;
		
		// デフォルトディレクトリ
		if ( $('cms_template_kind').value == TEMPLATE_KIND_FIXED && $('cms_template_kanko_type') ) {
			var def_dir = 'cms_def_dir_fixed_'+$('cms_template_kanko_type').value;
			if ( $(def_dir) ) {
				$('cms_dir_path').value = $(def_dir).value;
				cxRefferSelectDirFirst($('cms_dir_path').value, $('cms_filename').value);
			}
		}
	}
	//
	cxLayer('cms8341-template-select',0);
	//visible
	cxComboVisible();
}
function cxTemplateClose() {
	//close
	cxLayer('cms8341-template-select',0);
	//visible
	cxComboVisible();
	if (cmsTemplate != null) {
		document.cms_fAddpage.cms_template_id.options.selectedIndex = cmsTemplate;
		//re select
		cxSelectTemplate();
	}
	cmsTemplate = null;
}
//通信失敗処理
function cxFailure() {
	$('cms8341-reffer').innerHTML = '<p align="center">情報取得中に通信エラーが発生しました</p>';
}
//cancel
function cxPageCancel() {
	if (!confirm("作成を行わないと現在の内容は保存されません。\nキャンセルしてもよろしいですか？")) {
		return false;
	}
	location.href = RPW+SITE_TOP_PAGE;
	return false;
}

var cms_CateBack = false;
var xmlDoc;
var catePros = false;
function cxChangeCate(level, code) {
	var kind = $F('cms_template_kind')
	if(catePros)return;
	move_level = level;
	catePros = true;
	if(code=="") {
		level = parseInt(level) - 2;
		if(level==0) {
			level = 1;
		}
		code = $("cms_cate"+level).value;
		cms_CateBack = true;
	}
	var prm = 'level='+level+'&code='+code;
	cxAjaxCommand('cxGetCateCombo', prm, cxGetCateComboOK);
	if(move_level == 5){
		if(Element.visible($('cms_pd_tr'))){
			// イベントカレンダー複数日
			if (EVENT_CAL_MULTI_FLAG == true) {
				nextId = 'cms_pd1sy';
			}
			// イベントカレンダー単一日
			else {
				nextId = 'cms_pdsy';
			}
		} else if($('cms_contents_top_tr') && Element.visible($('cms_contents_top_tr'))){
			nextId = 'cms_contents_top_flg';
		} else {
			nextId = 'cms_keywords';
		}
	} else {
		nextId = 'cms_cate' + move_level;
	}
	$(nextId).focus();
}
function cxGetCateComboOK(r) {
	//PHPから処理終了を受信
	xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Categories') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	
	if(cms_CateBack) level++;
	for (var i=level; i<=4; i++) {
		var cmb = $('cms_cate'+i);
		while (cmb.length > 1) {
			cmb.options[1] = null;
		}
	}
	
	var cmb = $('cms_cate'+level);
	var xmlDocfix = xmlDoc.childElementCount;
	for (var i=0; i<xmlDocfix; i++) {
		nodeL = xmlDoc.firstElementChild;
		cmb.length++;
		cmb.options[i+1].text = nodeL.textContent;
		var val = nodeL.attributes.getNamedItem('value').value;
		cmb.options[i+1].value = val;
		xmlDoc.removeChild(xmlDoc.firstElementChild);
	}
	cms_CateBack = false;
	catePros = false;
}

// 組織変更プルダウン処理
var inquiryNum;
function cxChangeDept(lv, val, num) {
	 inquiryNum = num;
	//reset
	if(val=="") {
		var t = lv + 1;
		for(var i=t;i<=3;i++) {
			var obj = $('cms_inquiry_dept'+i+'_'+inquiryNum);
			while(obj.length>1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "";
		}
	} else {
		//get data
		lv++;
		var prm = 'level='+lv+'&code='+val;
		cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
	}
}
function cxGetDeptComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Department') {
			cxFailure();
			return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for (var i=level; i<=3; i++) {
			var obj = $('cms_inquiry_dept'+i+'_'+inquiryNum);
			while (obj.length > 1) {
					obj.options[1] = null;
			}
			if(i==level) {
					obj.options[0].text = "指定なし";
			} else {
					obj.options[0].text = "";
			}
	}
	var obj = $('cms_inquiry_dept'+level+'_'+inquiryNum);
	var xmlDocfix = xmlDoc.childElementCount;
	for (var i=0; i<xmlDocfix; i++) {
		nodeL = xmlDoc.firstElementChild;
		obj.length++;
		obj.options[i+1].text = nodeL.textContent;
		var val = nodeL.attributes.getNamedItem('value').value;
		obj.options[i+1].value = val;
		xmlDoc.removeChild(xmlDoc.firstElementChild);
	}
}
// 問合せ先追加
function cxAddInquiry() {
	$('cms_inquiry_cnt').value = Number($('cms_inquiry_cnt').value ) + 1;
	no = $('cms_inquiry_cnt').value;
	var inquiryStr = '<div id="cms_inquiry_'+no+'"><table width="100%" border="0" class="cms8341-noneBorder"><tr><td><span style="font-weight:bold" id="cms_inquiry_no_'+no+'">問い合わせ先'+no+'</span></td><td align="right"><a href="javascript:" onClick="return cxInquiryDel('+no+')"><img src="' + cms8341admin_path + '/images/btn/btn_del_mini.gif" alt="削除する" width="60" height="20" border="0" style="border:0px;"></a></td></tr></table>'
							+ '<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable">'
							+ '<tr id="cms_inquiry_dept_th_'+no+'"><th style="width:160px;">'+$('cms_inquiry_dept_th').innerHTML+'</th><td>'
							+ '<select name="cms_inquiry_dept1_'+no+'" id="cms_inquiry_dept1_'+no+'" onChange="javascript:cxChangeDept(1, this.value, '+no+')" style="width:120px;">'+$('cms_inquiry_dept_def_sel').innerHTML+'</select>&nbsp;&nbsp;&nbsp;'
							+ '<select name="cms_inquiry_dept2_'+no+'" id="cms_inquiry_dept2_'+no+'" onChange="javascript:cxChangeDept(2, this.value, '+no+')" style="width:120px;"><option value=""></option></select>&nbsp;&nbsp;&nbsp;'
							+ '<select name="cms_inquiry_dept3_'+no+'" id="cms_inquiry_dept3_'+no+'" onChange="javascript:cxChangeDept(3, this.value, '+no+')" style="width:120px;"><option value=""></option></select>&nbsp;&nbsp;&nbsp;</td></tr>'
							+ '<tr id="cms_inquiry_charge_tr_'+no+'"><th>'+$('cms_inquiry_charge_th').innerHTML+'</th><td style="font-size:10px;"><input type="text" name="cms_inquiry_charge_'+no+'" id="cms_inquiry_charge_'+no+'" style="width:240px;"><span id="cms_inquiry_charge_info" style="font-size:11px;">'+$('cms_inquiry_charge_info').innerHTML+'</span></td></tr>'
							+ '<tr id="cms_inquiry_anExtensionNumber_tr_'+no+'"><th>'+$('cms_inquiry_anExtensionNumber_th').innerHTML+'</th><td><input type="text" name="cms_inquiry_anExtensionNumber_'+no+'" id="cms_inquiry_anExtensionNumber_'+no+'" class="cms8341-verticalMiddle"></td></tr>'
							+ '<tr id="cms_inquiry_directNumber_tr_'+no+'"><th>'+$('cms_inquiry_directNumber_th').innerHTML+'</th><td><input type="text" name="cms_inquiry_directNumber_'+no+'" id="cms_inquiry_directNumber_'+no+'"> (例： 03-3502-0000)&nbsp;<a href="javascript:" onClick="cxGetInquiryDeptInfo('+no+',\'tel\')"><img src="'+cms8341admin_path+'/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得" border="0" width="100" height="20" class="cms8341-verticalMiddle"></a></td></tr>'
							+ '<tr id="cms_inquiry_fax_tr_'+no+'"><th>'+$('cms_inquiry_fax_th').innerHTML+'</th><td><input type="text" name="cms_inquiry_fax_'+no+'" id="cms_inquiry_fax_'+no+'"> (例： 03-3502-0000)&nbsp;<a href="javascript:" onClick="cxGetInquiryDeptInfo('+no+',\'fax\')"><img src="'+cms8341admin_path+'/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得" border="0" width="100" height="20" class="cms8341-verticalMiddle"></a></td></tr>'
							+ '<tr id="cms_inquiry_email_tr_'+no+'"><th>'+$('cms_inquiry_email_th').innerHTML+'</th><td><input type="text" name="cms_inquiry_email_'+no+'" id="cms_inquiry_email_'+no+'" style="ime-mode:disabled;">&nbsp;<a href="javascript:" onClick="cxGetInquiryDeptInfo('+no+',\'email\')"><img src="'+cms8341admin_path+'/images/btn/btn_get_deptinfo.jpg" alt="組織情報から取得" border="0" width="100" height="20" class="cms8341-verticalMiddle"></a></td></tr>'
							+ '</table><br></div>';
	new Insertion.Before('cms_inquiry_add', inquiryStr);
	var prm = 'tpl_id='+$F('cms_template_id');
	cxAjaxCommand('cxGetInquryDisp', prm, cxGetInquryDispOK);
}

function cxDispChange(){
	var kind = $F('cms_template_kind');
	Element.show('cms_submit');
	Element.show('cms_page_title_tr');
	Element.show('cms_cate_tr');
	if($('cms_contents_top_tr'))Element.show('cms_contents_top_tr');
	Element.show('cms_keyword_tr');
	Element.show('cms_description_tr');
	Element.show('cms_summry_tr');
	// 大規模災害ページの場合は自動リンク先設定できない
	if ($F('cms_dispMode') != "disaster") {
		Element.show('cms_autoLinks_tr');
	}
	if($F('cms_user_class') == USER_CLASS_WRITER && PARENT_DEL_USER_AUTH != "1"){
		Element.hide('cms_parent_id_none_sp');
	} else {
		Element.show('cms_parent_id_none_sp');
	}
	switch(kind){
		// フリー用
		case TEMPLATE_KIND_FREE:
			Element.hide('cms_pd_tr');
			Element.show('cms_inquiry_tr');
			Element.hide('cms_enquete_kind_tr');
			Element.hide('cms_ssl_reffer_tr');
			Element.show('cms_reffer_tr');
			if($('cms_output_tr'))Element.hide('cms_output_tr');
			cxSetInquiry();
			$('cms_kanko_area').innerHTML = "";
			break;
		// Q&A用
		case '2':
			Element.hide('cms_pd_tr');
			Element.show('cms_inquiry_tr');
			Element.hide('cms_enquete_kind_tr');
			Element.hide('cms_ssl_reffer_tr');
			Element.show('cms_reffer_tr');
			if($('cms_output_tr'))Element.hide('cms_output_tr');
			cxSetInquiry();
			$('cms_kanko_area').innerHTML = "";
			break;
		// アンケート用
		case TEMPLATE_KIND_ENQUETE:
			Element.hide('cms_pd_tr');
			if($('cms_contents_top_tr'))Element.hide('cms_contents_top_tr');
			Element.show('cms_inquiry_tr');
			Element.show('cms_enquete_kind_tr');
			if($F('cms_ssl_flg') == 1){
				Element.show('cms_ssl_reffer_tr');
				Element.hide('cms_reffer_tr');
			} else {
				Element.show('cms_reffer_tr');
				Element.hide('cms_ssl_reffer_tr');
			}
			if($('cms_output_tr'))Element.hide('cms_output_tr');
			cxSetInquiry();
			$('cms_kanko_area').innerHTML = "";
			break;
		// 携帯用
		case TEMPLATE_KIND_MOBILE:
			Element.hide('cms_pd_tr');
			Element.show('cms_inquiry_tr');
			Element.hide('cms_enquete_kind_tr');
			Element.hide('cms_ssl_reffer_tr');
			Element.show('cms_reffer_tr');
			if($('cms_output_tr'))Element.hide('cms_output_tr');
			cxSetInquiry();
			$('cms_kanko_area').innerHTML = "";
			break;
		// 観光用
		case TEMPLATE_KIND_FIXED:
			Element.hide('cms_pd_tr');
			Element.hide('cms_enquete_kind_tr');
			Element.hide('cms_ssl_reffer_tr');
			Element.show('cms_inquiry_tr');
			Element.show('cms_reffer_tr');
			cxSetOutput();
			if($('cms_output_tr'))Element.show('cms_output_tr');
			
			// 観光種類がイベントの場合
			if ( $('cms_template_kanko_type') && $F('cms_template_kanko_type') == KANKO_TYPE_EVENT ) {
				// 開催期間表示
				Element.show('cms_pd_tr');
			}
			
			
			// 観光種類がイベントの場合
			if ( $('cms_template_kanko_type') && $F('cms_template_kanko_type') == KANKO_TYPE_EVENT ) {
				// 開催期間表示
				Element.show('cms_pd_tr');
			}
			
			cxSetInquiry();

			if($F('cms_user_class') == 5){
				mode = 0;
			} else {
				mode = 1;
			}
//			var prm = 'level=2&code='+KANKO_CATE_CODE+'000000000'+'&mode='+mode;
//			cxAjaxCommand('cxGetCateCombo', prm, cxGetCateComboOK);
			cxSetKanko();
			break;
		default:
			alert("エラー");
			break;	
	}
	
	if (kind != TEMPLATE_KIND_FIXED) {
		si = $('cms_template_id').options.selectedIndex;
		if (si >= 0) {
			cmsTemplate = si; 
			$('cms_template_kind').value = $('cms_template_id').options[si].getAttribute('_kind');
			if ($('cms_template_id').options[si].getAttribute('_ver')) {
				$('cms_template_ver').value = $('cms_template_id').options[si].getAttribute('_ver');
			}
			var prm = 'template_id=' + $('cms_template_id').options[cmsTemplate].value + '&template_kind=' + $F('cms_template_kind') + '&template_ver=' + $F('cms_template_ver');
			cxAjaxCommand('cxisFixed', prm, cxisFixedOK);
		}
	}
	// オープンデータ
	// オープンデータ情報指定領域作成
	cxSetOpendata();
}

function cxisFixedOK(r) {
	//PHPから処理終了を受信
	var rText = r.responseText;
	
	if(rText == "true"){
		cxSetKanko();
	}
}

function cxSetOutput(){
	var prm = 'tpl_id='+$F('cms_template_id')+"&sel_op="+$F('cms_sel_op')+"&output_html_flg="+$F('cms_output_html');
	cxAjaxCommand('cxGetOutputDisp', prm, cxGetOutputDispOK);
}
function cxGetOutputDispOK(r){
	var rText = r.responseText;
	if($('cms_output_tr') && rText == ""){
		Element.hide('cms_output_tr');
		return;
	}
	Element.show('cms_output_tr');
	$('cms-outputs').innerHTML = rText;
}
function cxGetOutputDispOK2(r){
	var rText = r.responseText;
	if($('cms_output_tr') && rText == ""){
		Element.hide('cms_output_tr');
		return;
	}
	Element.show('cms_output_tr');
	var elements = Form.getInputs('cms_fAddpage', 'checkbox','cms_output[]');
	$A(elements).each( function(obj) {
						isFind = false;
						id = obj.id;
						id = id.replace("cms_output_","");
						show_id_ary = rText.split(","); 
						for(i = 0;i < show_id_ary.length; i++){
							if(id == show_id_ary[i]){
								isFind = true;
								break;
							}
						}
						if(isFind){
							Element.show(obj.id);
							Element.show(obj.id+"_lbl");
						} else {
							Element.hide(obj.id);
							Element.hide(obj.id+"_lbl");
						}
					} ); 
	
}

function cxSetInquiry(){
	$('cms_inquiry_dept_th').innerHTML = INQUIRY_DEPT_NAME;
	$('cms_inquiry_charge_th').innerHTML = INQUIRY_CHARGE_NAME+'<div class="cms_recommend"></div>';
	$('cms_inquiry_anExtensionNumber_th').innerHTML = INQUIRY_EXTENSIONNUMBER_NAME;
	$('cms_inquiry_directNumber_th').innerHTML = INQUIRY_DIRECTNUMBER_NAME;
	$('cms_inquiry_fax_th').innerHTML = INQUIRY_FAX_NAME;
	$('cms_inquiry_email_th').innerHTML = INQUIRY_EMAIL_NAME;
	$('cms_inquiry_charge_info').innerHTML = "";
	var prm = 'tpl_id='+$F('cms_template_id');
	cxAjaxCommand('cxGetInquryDisp', prm, cxGetInquryDispOK);
}
function cxGetInquryDispOK(r){
	allShowFlg = false;
	inquiryShowFlg = false;
	var rText = r.responseText;
	inquiryItem = rText.split(",");
	for(i = 0;i < inquiryItem.length;i++){
		inquiryDtl = inquiryItem[i].split(":");
		if(inquiryDtl[0] != "memo"){
			allItem = document;
			for (j = 0; j < allItem.getElementsByTagName("tr").length; j++) {
				id = allItem.getElementsByTagName("tr")[j].getAttribute("ID");
				if(id == null)continue;
				if(id.indexOf("cms_inquiry_"+inquiryDtl[0]+"_") == 0){
					if(inquiryDtl[1] == "show"){
						Element.show(id);
						allShowFlg = true;
						inquiryShowFlg = true;
					} else {
						Element.hide(id);
					}
				}
			}
		} else {
			if(inquiryDtl[1] == "show"){
				allShowFlg = true;
				Element.show("cms_inquiry_memo_table");
			} else {
				Element.hide("cms_inquiry_memo_table");
			}
		}
	}
	if(!allShowFlg){
		Element.hide("cms_inquiry_tr");
	} else {
		Element.show("cms_inquiry_tr");
	}
	if(!inquiryShowFlg){
		Element.hide("cms_inquiry_table");
		Element.hide("cms_inquiry_add");
		Element.hide("cms_inquiry_no_1");
		
	} else {
		Element.show("cms_inquiry_table");
		Element.show("cms_inquiry_add");
		Element.show("cms_inquiry_no_1");
	}
	
}

function cxInquiryDel(no){
	if (!confirm("問合せ先"+no+"を削除します。\nよろしいですか？")) {
		return false;
	}
	Element.remove($('cms_inquiry_'+no));
}

function cxFileSubmit(event){
	var item = Event.element(event);
	if($('cms_file_submit') && item.id == "cms_new_file" && event.keyCode == 13){
		cxRefferSubmit();
	}
}

function cxMailSelect(val){
	if($('cms_enquete_mail_form')){
		if(val == 1){
			Element.show('cms_enquete_mail_form');
			Element.show('cms_enquete_mail_add');
			
		} else {
			Element.hide('cms_enquete_mail_form');
			Element.hide('cms_enquete_mail_add');
		}
	}
}

function cxInit() {
	if($F('cms_template_kind') != ""){
		cxDispChange();
		if($F('cms_template_kind') == TEMPLATE_KIND_ENQUETE){
			if($('cms_enquete_kind_1').checked){
				cxMailSelect(1);
			} else if ( $('cms_enquete_kind_0').checked ) {
				cxMailSelect(0);
			}
		}
	}
	Event.observe(document,'keypress',cxFileSubmit,false);
	Event.observe($('cms_enquete_mail_add'),'click',cxOpenMailForm,false);
}
Event.observe(window,'load',cxInit,false);


