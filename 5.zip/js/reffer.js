/*
 * ファイル選択
 */
//** cms8341-reffer（ページの保存先決定）レイヤー **/
function cxRefferSet() {
	edit_closet_flg = false;
	//close
	if($('cms8341-template-select'))cxTemplateClose();
	if($('cms8341-autolinks') && $('cms8341-autolinks').style.display == 'block')cxLayer('cms8341-autolinks',0);
	if($('cms8341-calendar') && $('cms8341-calendar').style.display == 'block')cxCalendarClose();
	if($('cms8341-category') && $('cms8341-category').style.display == 'block') cxLayer('cms8341-category',0);
	if($("cms8341-property")){
		//ディレクトリ移動
		cxRefferSelectDirFirst($('cms_dir_path').value, $('cms_filename').value);
	}	
	//open
	cxLayer('cms8341-reffer',1,810,415);
	cxComboHidden(new Array("cms_template_id","cms_save_dir"));
}
//ディレクトリ作成
function cxRefferMakeDir() {
	edit_closet_flg = false;
	var t_dir = $('cms_new_dir').value;
	
	// ディレクトリ名を小文字に変換
	t_dir = t_dir.toLowerCase();
	
	//入力チェック
	var err_msg = '';
	if (!t_dir) {
		err_msg = 'フォルダ名が入力されていません。';
	} else if (t_dir.match(/[\\\/:\*\?<>\|\.]/)) {
		err_msg = 'フォルダ名には以下の文字は使えません\n\ / : * ? " < > | .';
	} else if (t_dir.match(/[^\w\-_\.]/i)) {
		err_msg = 'フォルダ名は半角英数字で入力してください';
	}
	if (err_msg) {
		alert(err_msg);
		$('cms_new_dir').focus();
		return false;
	}
	var prm = 'new_dir='+t_dir;
	cxAjaxCommand('cxRefferMakeDir', prm, cxRefferMakeDirOK);
	return false;
}
function cxRefferMakeDirOK(r) {
	edit_closet_flg = false;
	var rText = r.responseText;
	var err_msg = '';
	//main
	if (rText == 'true') {
		var prm = 'current_dir=&mode=reflesh';
		if($('cms_pageuser_deptcode')) prm += '&dept_code=' + $('cms_pageuser_deptcode').value;
		cxAjaxCommand('cxRefferMoveDir', prm, cxRefferReview);
	} else if (rText == 'no_create') {
		err_msg = '作成できないフォルダ名です。';
	} else if (rText != '') {
		err_msg = rText+'は既に存在します。';
	} else {
		err_msg = 'フォルダ作成に失敗しました。';
	}
	if (err_msg) {
		alert(err_msg);
		$('cms_new_dir').focus();
		return false;
	}
	return false;
}
//ファイル選択
function cxRefferSelectFile(e) {
	edit_closet_flg = false;
	output_filename = (e.innerHTML).replace(/<img.*>/i,'');//1108北村変更
	$('cms_new_file').value = output_filename.replace(/\.html$/, '');//1108北村変更
}
//newpage.jsと同じにした。もともとあったものだと、ディレクトリのダブルクリック時にも実行されるので
//動作を違うようにする必要があった。
function cxRefferSelectDir(dir) {
	edit_closet_flg = false;
	var prm = 'current_dir='+dir;
	if($('cms_pageuser_deptcode')) prm += '&dept_code=' + $('cms_pageuser_deptcode').value;
	cxAjaxCommand('cxRefferMoveDir', prm, cxRefferReview);
	return false;
}
//参照ボタンを押したときに実行される　1108北村追加
function cxRefferSelectDirFirst(dir, file) {
	edit_closet_flg = false;
	var prm = 'current_dir='+dir+'&new_file='+file.replace(/\.html$/, '');
	if($('cms_pageuser_deptcode')) prm += '&dept_code=' + $('cms_pageuser_deptcode').value;
	cxAjaxCommand('cxRefferMoveDir', prm, cxRefferReview);
	return false;
}
//前のディレクトリに戻る
function cxRefferBackDir() {
	edit_closet_flg = false;
	var prm = 'current_dir=&mode=back';
	if($('cms_pageuser_deptcode')) prm += '&dept_code=' + $('cms_pageuser_deptcode').value;
	cxAjaxCommand('cxRefferMoveDir', prm, cxRefferReview);
	return false;
}
//再表示
function cxRefferReview(r) {
	//return
	var rText = r.responseText;
	$('cms8341-reffer').innerHTML = rText;
}
//キャンセル処理
function cxRefferCansel() {
	edit_closet_flg = false;
	//フォームのリセット処理
	cxLayer('cms8341-reffer',0);
	if($("cms8341-property")){
		cxComboVisible("cms8341-property");
	} else {
		cxComboVisible();
	}	
}
//決定処理
function cxRefferSubmit() {
	var t_dir = $('cms_save_dir').value;
	var t_file  = $('cms_new_file').value;
	
	// ファイル名を小文字に変換
	t_file = t_file.toLowerCase();
	
	//入力チェック
	var err_msg = '';
	if(!t_file) {
		err_msg = 'ファイル名が入力されていません。';
	} else if(t_file == "." || t_file.indexOf(".") == 0) {
		err_msg = '正しいファイル名ではありません。';
	} else if (t_file.match(/[\\\/:\*\?<>\|]/)) {
		err_msg = 'ファイル名に使用できるのは半角英数字と - _ ~ です';
	} else if (t_file.match(/[^\w\-_~]/i)) {
		err_msg = 'ファイル名に使用できるのは半角英数字と - _ ~ です';
	} else if (t_dir.length + t_file.length > 251){ //.htmlもカウントするので合計255以下にする
		err_msg = 'フルパスで255文字以内になるようにしてください';
	}
	if (err_msg) {
		alert(err_msg);
		$('cms_new_file').focus();
		return false;
	}
	edit_closet_flg = false;
	t_file = t_file.replace(/^([^\.]*).*$/, '$1.html');
	$('cms_new_file').value = t_file.replace(/\.html$/, '');//1108北村変更
	// 元のパス
	if($('cms_w_file_path') && $('cms_p_file_path')){
		var fp = $('cms_save_dir').value+$('cms_new_file').value+'.html';
		if (fp == $('cms_w_file_path').value || fp == $('cms_p_file_path').value) {
			var r = new Object();
			r.responseText = '';
			cxRefferSubmitOK(r);
		// パスをチェック
		} else {
			var prm = 'file_path='+t_dir+t_file;
			cxAjaxCommand('cxRefferFileCheck', prm, cxRefferSubmitOK);
		}
	} else {
		var prm = 'file_path='+t_dir+t_file;
		cxAjaxCommand('cxRefferFileCheck', prm, cxRefferSubmitOK);
	}
	return false;
}
function cxRefferSubmitOK(r) {
	//PHPから処理終了を受信
	var rText = trim(r.responseText);
	var err_msg = '';
	if (rText == 'no_create') {
		err_msg = '作成できないファイル名です。';
	} else if (rText != '') {
		err_msg = rText+'は既に存在します。';
	} else {
		//main
		$('cms_dir_path').value = $('cms_save_dir').value;
		$('cms_filename').value = $('cms_new_file').value+".html";
		$('cms_file_path').innerHTML = $('cms_dir_path').value+$('cms_filename').value;
		cxLayer('cms8341-reffer',0);
		if($("cms8341-property")){
			cxComboVisible("cms8341-property");
		} else {
			cxComboVisible();
		}	
	}
	if (err_msg) {
		alert(err_msg);
		$('cms_new_dir').focus();
		return false;
	}
}
