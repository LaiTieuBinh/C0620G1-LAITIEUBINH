/*
 *
 */
var IMG_FolderOpened = cms8341admin_path+'/images/treelist/FolderOpened.gif';
var IMG_Folder       = cms8341admin_path+'/images/treelist/Folder.gif';
cxPreImages(cms8341admin_path+'/images/menu/logout01_btn.jpg',
			cms8341admin_path+'/images/menu/logout02_btn.jpg',
			cms8341admin_path+'/images/btn/btn_prev.gif',
			cms8341admin_path+'/images/contentsmenu/menu_edit01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_accessibilitycheck01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_totalcheck01.jpg',				// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_spellcheck01.jpg',				// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_linkcheck01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_headlinecheck01.jpg',		// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_contrastcheck01.jpg',		// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_preview01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_pageproperty01.jpg',
			IMG_FolderOpened);


function cxPagePropertyClose() {
	cxLayer('cms8341-property',0);
}
function cxCloseError() {
	cxLayer('cms8341-error',0);
}

//treelist
var tree_dir_path = '';
function cxOpenList(path) {
	if(path != undefined){
		if(cms_prev_layer) cms_prev_layer.style.display = 'none';
		if (!$('cms_dir_'+path)) {
			$('cms_dir_/').innerHTML = '<p>指定したフォルダは存在しません。</p>';
			return false;
		}
		if ($('cms_dir_'+path).style.display == 'block' || $('cms_folder_'+path).alt == '閉じる') {
			$('cms_dir_'+path).style.display = 'none';
			$('cms_folder_'+path).src = IMG_Folder;
			$('cms_folder_'+path).alt = '開く';
			return false;
		}
		tree_dir_path = path;
	} else {
		path = "/";
		tree_dir_path = "/"
	}
	if($('cms_target1').checked)checked = 0;
	if($('cms_target2').checked)checked = 1;
	$('cms_isAll').value = checked;
	var prm = 'dir_path='+path+'&isAll='+checked;
	cxAjaxCommand('cxGetTreeList', prm, cxOpenListSuccess);
	//
	if(tree_dir_path != "")$('cms_dir_'+tree_dir_path).style.display = 'block';
	if(tree_dir_path != "")$('cms_dir_'+tree_dir_path).innerHTML = '<p>読み込み中...</p>';
//	return false;
}
//
function cxOpenListSuccess (r) {
	var rText = r.responseText;
	if (rText == -1) {
		$('cms_dir_/').innerHTML = '<p>指定したフォルダは存在しません。</p>';
		return false;
	}
	$('cms_dir_'+tree_dir_path).style.display = 'block';
	$('cms_dir_'+tree_dir_path).innerHTML = rText;
	$('cms_folder_'+tree_dir_path).src = IMG_FolderOpened;
	$('cms_folder_'+tree_dir_path).alt = "閉じる";
}
function cxFileView(path) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	window.open(path,'preview','status=no,menubar=no,toolbar=no,scrollbars=yes,resizable=yes');
	return false;
}
function cxFileDel(path) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	var filename = path.replace(/^\/.*\//,'');
	var cnf = confirm('ファイル"'+filename+'"を削除しますか？');
	if(!cnf) return false;
	tree_dir_path = path.substr(0, path.lastIndexOf("/"));
	var prm = 'file_path='+path;
	cxAjaxCommand('cxDeleteFile', prm, cxDeleteFileSuccess);
}
function cxDeleteFileSuccess (r) {
	var rText = r.responseText;
	if (rText == 1) {
		if(tree_dir_path == ""){
			document.fSearchDir.action = cms8341admin_path+'/page/siteview/treelist.php';
			document.fSearchDir.submit();
		} else {
			var prm = 'dir_path='+tree_dir_path;
			cxAjaxCommand('cxGetTreeList', prm, cxOpenListSuccess);
		}
	} else {
		var msg = '';
		if (rText == -1) msg = 'このファイルはページから参照されているため削除できません。';
		else if (rText == -2) msg = 'ファイルの削除に失敗しました。';
		else if (rText == -3) msg = 'ファイルの削除に失敗しました。（cms8341_real）';		//2007.11.02
		else if (rText == -4) msg = 'ファイルの削除に失敗しました。（公開サーバ）';			//2007.11.02
		else msg = rText;
		$('cms8341-errormsg').innerHTML = '<p align="center">'+msg+'</p>';
		cxLayer('cms8341-error',1,500,375);
	}
}
function cxFolderMenu(path) {
	var obj = $('cms_dirctrl_'+path);
	if ($('cms_dir_'+path).style.display == 'block' || $('cms_folder_'+path).alt == '閉じる') {
		obj.src = cms8341admin_path+'/images/treelist/menu_dir_close00.jpg';
		obj.alt = 'フォルダを閉じる';
		obj.onmouseover = function() {
			this.src = cms8341admin_path+'/images/treelist/menu_dir_close01.jpg';
		}
		obj.onmouseout = function() {
			this.src = cms8341admin_path+'/images/treelist/menu_dir_close00.jpg';
		}
	} else {
		obj.src = cms8341admin_path+'/images/treelist/menu_dir_open00.jpg';
		obj.alt = 'フォルダを開く';
		obj.onmouseover = function() {
			this.src = cms8341admin_path+'/images/treelist/menu_dir_open01.jpg';
		}
		obj.onmouseout = function() {
			this.src = cms8341admin_path+'/images/treelist/menu_dir_open00.jpg';
		}
	}
	cxContentsMenu('cms_menu_'+path);
}
function cxFolderDel(path) {
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	var dirname = path.replace(/\/$/,'');
	dirname = dirname.replace(/^.*\//,'');
	var cnf = confirm('フォルダ"'+dirname+'"を削除しますか？');
	if(!cnf) return false;
	tree_dir_path = path.replace(/\/[^\/]*\/$/,'');
	if(tree_dir_path=='') tree_dir_path = '/';
	var prm = 'dir_path='+path;
	cxAjaxCommand('cxDeleteFolder', prm, cxDeleteFolderSuccess);

}
function cxDeleteFolderSuccess(r) {
	var rText = r.responseText;
	if (rText == 1) {
		//var prm = 'dir_path='+tree_dir_path;
		//cxAjaxCommand('cxGetTreeList', prm, cxOpenListSuccess);
		document.fSearchDir.action = cms8341admin_path+'/page/siteview/treelist.php';
		$('dir_path').value = tree_dir_path;
		$('cms_treelist_dirDel').value = 1;
		document.fSearchDir.submit();
	} else {
		var msg = '';
		if (rText == -1) msg = 'フォルダの削除に失敗しました。';
		else if (rText == -2) msg = 'フォルダの削除に失敗しました。（cms8341_real）';
		else if (rText == -3) msg = 'フォルダの削除に失敗しました。（公開サーバ）';
		else if (rText == -4) msg = '権限の削除に失敗しました。';
		else msg = rText;
		$('cms8341-errormsg').innerHTML = '<p align="center">'+msg+'</p>';
		cxLayer('cms8341-error',1,500,375);
	}
}
function cxInputCheck(){
	var dir = $F('dir_path');
	if ( dir.match(/[^\w\-\_\/]/i) ) {
		alert( '対象フォルダは半角英数字で入力してください' );
		return false;
	}
}
