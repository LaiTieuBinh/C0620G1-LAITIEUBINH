/*
 *
 */
function Contrast(A) {
	this.obj = document.getElementById(A) || document;
	this.tag = this.obj.getElementsByTagName('*');
	this.errStyle = '';
	this.errIcon = cms8341admin_path+'/images/contrast/error_icon.gif';
	this.errIconWidth  = 140;
	this.errIconHeight = 20;
	this.errImgHtml    = this.createErrImg(this.errIcon, this.errIconWidth, this.errIconHeight);
	this.errCnt = 0;
	this.errMsgObjId = 'cms8341-headmessage';
	this.check();
	this.output();
}
Contrast.prototype.check = function() {
	var e = this.tag;
	var ratio = 4.5; // チェック用比率設定
	// コントラストチェックの基準が「AAA(トリプルエー)」の場合比率を「7」に設定
	if (contrast_standard && contrast_standard == 2) {
		ratio = 7;
	}
	
	//for(var i=0;i<e.length;i++) {
	for(var i=e.length-1;i>=0;i--) {
		if(e[i].tagName.match('(TABLE|THEAD|TBODY|TFOOT|COLGROUP|COL|TR|UL|OL|DL|HR|FRAMESET|FRAME|NOFRAMES|IFRAME|OBJECT|EMBED|APPLET|SCRIPT|PARAM|NOSCRIPT|IMG|HR|AREA|INPUT|BR|!)')) continue;
		if(e[i].currentStyle) {
			/* IE */
			// 前景色
			var fc = e[i].currentStyle['color'];
			// 背景色
			var ele = e[i];
			var bc;
			var bg = 'none';
			do {
				if(bg=='none') bg = ele.currentStyle['backgroundImage'];
				bc = ele.currentStyle['backgroundColor'];
				if(bc!='transparent') break;
				ele = ele.parentNode;
			}
			while(ele.tagName);
		} else {
			/* moz */
			// 前景色
			var fc = document.defaultView.getComputedStyle(e[i],null).getPropertyValue('color');
			// 背景色
			var ele = e[i];
			var bc;
			var bg = 'none';
			do {
				if(bg=='none') bg = document.defaultView.getComputedStyle(ele,null).getPropertyValue('background-image');
				bc = document.defaultView.getComputedStyle(ele,null).getPropertyValue('background-color');
				if(bc!='transparent') break;
				ele = ele.parentNode;
			}
			while(ele.tagName);
		}
		/* result */
		if(!fc || !bc) continue;
		bc = (bc=='transparent')? '#ffffff' : bc;
		var L1 = this.getColorNumber(fc);
		var L2 = this.getColorNumber(bc);
		var temp_L = "";
		// 「L1」に明るい方の色の相対輝度、「L2」に暗い方の相対輝度となるように入れ替える
		if (L1 < L2) {
			temp_L = L2;
			L2 = L1;
			L1 = temp_L;
		}
		
		// コントラスト比取得
		var L3 = (L1 + 0.05) / (L2 + 0.05);
		// 少数第1位四捨五入
		L3 = L3.toFixed(1);
		
		
		if (L3 < ratio) {
			if(e[i].tagName=="!") continue;
			if(this.errStyle!='') e[i].style.cssText = this.errStyle;
			e[i].innerHTML = this.errImgHtml + e[i].innerHTML;
			this.errCnt++;
		}
		e[i].title = '【 コントラスト比 / ['+L3+'：1] 】';
		if(bg && bg!='none') {
			e[i].title += '★要確認：背景画像とのコントラスト';
		}
	}
}
Contrast.prototype.output = function() {
	var msg = '';
	if(this.errCnt==0) {
		msg = '<img src="' + cms8341admin_path + '/images/icon/result_normal.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px">コントラストに問題はありません。';
	} else {
		msg = '<span style="color:#FF0000;font-weight:bold;"><img src="' + cms8341admin_path + '/images/icon/result_error.gif" width="12" height="12" alt="" style="vertical-align:middle;margin-right:15px">対象ページに'+this.errCnt+'個のコントラスト比に達しない箇所があります。</span>';
	}
	if (contrast_standard && contrast_standard == 2) {
		msg += "<br><br>" + "\n\n" + "※AAA(トリプルエー)基準を指標としコントラストチェックを行いました。";
		msg += "<br>" + "※コントラスト比が「7：1」以上となるように作成してください。";
	} else {
		msg += "<br><br>" + "\n\n" + "※AA(ダブルエー)基準を指標としコントラストチェックを行いました。";
		msg += "<br>" + "※コントラスト比が「4.5：1」以上となるように作成してください。";
	}
	if(this.errMsgObjId!='' && document.getElementById(this.errMsgObjId)) {
		var eObj = document.getElementById(this.errMsgObjId);
		eObj.innerHTML = msg;
	} else {
		alert(msg);
	}
}
Contrast.prototype.getColorNumber = function(A) {
	// Red/Green/Blue値を取得
	var B=this.getCode(A);
	// 計算用Red値作成
	var RsRGB = B[0]/255;
	// 計算用Green値作成
	var GsRGB = B[1]/255;
	// 計算用Blue値作成
	var BsRGB = B[2]/255;
	
	// 相対輝度計算用Red値作成
	if (RsRGB <= 0.03928) {
		R = RsRGB/12.92;
	} else {
		R = Math.pow(((RsRGB+0.055)/1.055),2.4);
	}
	// 相対輝度計算用Green値作成
	if (GsRGB <= 0.03928) {
		G = GsRGB/12.92;
	} else {
		G = Math.pow(((GsRGB+0.055)/1.055),2.4);
	}
	// 相対輝度計算用Blue値作成
	if (BsRGB <= 0.03928){
		B = BsRGB/12.92;
	} else {
		B = Math.pow(((BsRGB+0.055)/1.055),2.4);
	}
	
	// 相対輝度値取得
	var L = 0.2126 * R + 0.7152 * G + 0.0722 * B;
	
	return L;
}
Contrast.prototype.getCode = function(A) {
	if(A.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/)){
		return [RegExp.$1, RegExp.$2, RegExp.$3];
	}else if(A.charAt(0)!='#') {
		return '';
	}
	var B='0123456789abcdef';
	var C=[];
	A=A.substr(1);
	if(A.length==3){
		D=A.charAt(0);
		E=A.charAt(1);
		F=A.charAt(2);
		A=D+D+E+E+F+F;
	}
	for(var i=0;i<3;i++) {
		C[i]=B.indexOf(A.charAt(i*2))*16+B.indexOf(A.charAt(i*2+1));
	}
	return C;
}
Contrast.prototype.isBlock = function(obj) {
	var tagName = obj.tagName;
	return (tagName.match(/^(DIV|H[1-6]|ADDRESS|BLOCKQUOTE|P|PRE|OBJECT|EMBED|FORM)$/i))? true : false;
}
Contrast.prototype.createErrImg = function(src,width,height) {
	return '<img src="'+src+'" width="'+width+'" height="'+height+'" hspace="2" align="absmiddle" style="border:none;margin:0 5px;vertical-align:middle;" />';
}