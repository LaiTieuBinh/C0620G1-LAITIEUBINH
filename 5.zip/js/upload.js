/*
 *
 */
cxPreImages(cms8341admin_path+'/images/menu/logout01_btn.jpg',
			cms8341admin_path+'/images/menu/logout02_btn.jpg',
			cms8341admin_path+'/images/btn/btn_close_mini.jpg',
			cms8341admin_path+'/images/btn/btn_prev.gif');

//通信失敗処理
function cxFailure() {
	$('cms8341-errormsg').innerHTML = '<p align="center">情報取得中に通信エラーが発生しました</p>';
	cxComboHidden();
	cxLayer('cms8341-error',1,500,375);
}
//search
function cxSearch() {
	var msg = new Array();
	var pdsy       = $('cms_pdsy');
	var pdsm       = $('cms_pdsm');
	var pdsd       = $('cms_pdsd');
	var pdey       = $('cms_pdey');
	var pdem       = $('cms_pdem');
	var pded       = $('cms_pded');
	if(pdsy.value || pdsm.value || pdsd.value) {
		if(!pdsy.value || !pdsm.value || !pdsd.value) {
			msg.push('公開日の指定をする場合は、年月日すべてを指定してください。');
		}
	}
	if(pdey.value || pdem.value || pded.value ) {
		if(!pdey.value || !pdem.value || !pded.value ) {
			msg.push('公開日の指定をする場合は、年月日すべてを指定してください。');
		}
	}
	var dateObj = new Object();
	dateObj.sy = pdsy.value;
	dateObj.sm = pdsm.value;
	dateObj.sd = pdsd.value;
	dateObj.ey = pdey.value;
	dateObj.em = pdem.value;
	dateObj.ed = pded.value;
	var dc = cxDateCheck(dateObj);
	msg = msg.concat(dc);
	//
	if(msg.length>=1 && msg[0]!='') {
		var output_msg = '<p>';
		for(var i=0;i<msg.length;i++) {
			output_msg += msg[i] + '<br>';
		}
		output_msg += '</p>';
		$('cms8341-errormsg').innerHTML = output_msg;
		cxComboHidden();
		cxLayer('cms8341-error',1,500,375);
	} else {
		//main
		document.cms_fSearch.cms_dispMode.value = "search";
		document.cms_fSearch.submit();
		return false;
	}
}
function cxLastSearch(){
	document.cms_fSearch.cms_dispMode.value = "last_condition";
	document.cms_fSearch.submit();
	return false;
}

//date check
function cxDateCheck(obj) {
	var retAry = new Array();
	var stat;
	var c_days;
	//charactor check
	if(obj.sy) {
		stat = cxDateNumeric(obj.sy);
		if(!stat) {
			retAry.push('公開日（年）に数字ではない文字列が入力されています。');
			obj.sy = false;
		} else if(Number(obj.sy) < 2000) {
			retAry.push('公開日（年）は2000年以降を指定してください。');
			obj.sy = false;
		}
	}
	if(obj.sm) {
		stat = cxDateNumeric(obj.sm);
		if(!stat) {
			retAry.push('公開日（月）に数字ではない文字列が入力されています。');
			obj.sm = false;
		} else if(Number(obj.sm) < 1 || Number(obj.sm) > 12) {
			retAry.push('公開日（月）には 1 ～ 12 を指定してください。');
			obj.sm = false;
		}
	}
	if(obj.sd) {
		stat = cxDateNumeric(obj.sd);
		if(!stat) {
			retAry.push('公開日（日）に数字ではない文字列が入力されています。');
			obj.sd = false;
		} else if(Number(obj.sd) < 1 || Number(obj.sd) > 31) {
			retAry.push('公開日（日）には 1 ～ 31 を指定してください。');
			obj.sd = false;
		}
	}
	if(obj.ey) {
		stat = cxDateNumeric(obj.ey);
		if(!stat) {
			retAry.push('公開日（年）に数字ではない文字列が入力されています。');
			obj.ey = false;
		} else if(Number(obj.ey) < 2000) {
			retAry.push('公開日（年）は2000年以降を指定してください。');
			obj.ey = false;
		}
	}
	if(obj.em) {
		stat = cxDateNumeric(obj.em);
		if(!stat) {
			retAry.push('公開日（月）に数字ではない文字列が入力されています。');
			obj.em = false;
		} else if(Number(obj.em) < 1 || Number(obj.em) > 12) {
			retAry.push('公開日（月）には 1 ～ 12 を指定してください。');
			obj.em = false;
		}
	}
	if(obj.ed) {
		stat = cxDateNumeric(obj.ed);
		if(!stat) {
			retAry.push('公開日（日）に数字ではない文字列が入力されています。');
			obj.ed = false;
		} else if(Number(obj.ed) < 1 || Number(obj.ed) > 31) {
			retAry.push('公開日（日）には 1 ～ 31 を指定してください。');
			obj.ed = false;
		}
	}
	//
	return retAry;
}
//
function cxChangeDept(lv, val) {
	//reset
	if(val=="") {
		var t = lv + 1;
		for(var i=t;i<=3;i++) {
			var obj = $('cms_target'+i);
			while(obj.length>1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "----------------";
		}
	} else {
		//get data
		lv++;
		var prm = 'level='+lv+'&code='+val;
		cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
	}
}
function cxGetDeptComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Department') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    for (var i=level; i<=3; i++) {
        var obj = $('cms_target'+i);
        while (obj.length > 1) {
                obj.options[1] = null;
        }
        if(i==level) {
                obj.options[0].text = "指定なし";
        } else {
                obj.options[0].text = "----------------";
        }
    }
    var obj = $('cms_target'+level);
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i=0; i<xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        obj.length++;
        obj.options[i+1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        obj.options[i+1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}
function cxCheckAll() {
	var alElem = document['cms_fUpload']['cms_page_id[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = true;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = true;
			}
		}
	}
}
function cxReleaseAll() {
	var alElem = document['cms_fUpload']['cms_page_id[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = false;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = false;
			}
		}
	}
}
//手動アップロード
function cxUpload() {
	var chkFlg = false;
	var alElem = document['cms_fUpload']['cms_page_id[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			if (alElem.checked) chkFlg = true;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				if (alElem[i].checked) {
					chkFlg = true;
					break;
				}
			}
		}
	}
	if (!chkFlg) {
		alert('ページが一つも選択されていません。');
	} else {
		document.cms_fUpload.submit();
	}
	return false;
}
function cxCloseError() {
	cxLayer('cms8341-error',0);
	cxComboVisible();
}

/**
 * ページ番号をPOSTする
 * @param page ページ番号
 * @return false
 */
function cxPageSet(page){
	$('cms_page_post').cms_page.value = page;
	$('cms_page_post').maxrow.value = $('dispNum').value;
	$('cms_page_post').submit();
	return false;
}

/**
 * 表示件数を変える
 * @param prev_num 表示件数
 * @return false
 */
function cxDispNum(prev_num){
	$('cms_page_post').cms_page.value = 1;
	$('cms_page_post').maxrow.value = prev_num;
	$('cms_page_post').submit();
	return false;
}

/**
 * アップロード処理のロックファイルを削除する。
 * @param なし
 * @return false
 */
function cxUnlock(){
	if (confirm("自動アップロード又は他のユーザーがアップロードを行っている可能性があります。\nロックを解除してもよろしいですか？")) {
		var prm = '';
		cxAjaxCommand('cxUploadUnlock', prm, cxUnlockOK);
	}
	return false;
}

/**
 * アップロード処理のロックファイル削除する。(Ajaxの戻り値)
 * @param r Ajax戻り値
 * @return false
 */
function cxUnlockOK(r){
	var rText = r.responseText;
	if(rText == "true"){
		$('cms_fSearch').cms_dispMode.value = "";
		$('cms_fSearch').submit();
	}
	else{
		alert("ロック解除に失敗しました。");
	}
	return false;
}
