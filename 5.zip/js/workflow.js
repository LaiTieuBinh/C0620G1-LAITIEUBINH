/*
 * ワークフロー
 */
//contentsmenu preload images
cxPreImages(cms8341admin_path+'/images/contentsmenu/menu_edit01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_cansel01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_pageadd01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_linkcheck01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_accessibilitycheck01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_totalcheck01.jpg',				// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_spellcheck01.jpg',				// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_headlinecheck01.jpg',		// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_contrastcheck01.jpg',		// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_pageproperty01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_edhitpreview01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_publicpreview01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_preview01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_publiccansel01.jpg',
			cms8341admin_path+'/page/workflow/images/icon_minus.jpg',
			cms8341admin_path+'/page/workflow/images/bg_open.jpg',
			cms8341admin_path+'/images/btn/btn_close_mini.jpg',
			cms8341admin_path+'/images/menu/logout01_btn.jpg',
			cms8341admin_path+'/images/menu/logout02_btn.jpg');

var active_id;

// contentsgroup appear toggle
function cxAutoScroll(p) {
	var s = 0;
	while(s < p) {
		window.scrollBy(0,20);
		s += 20;
	}
}
function cxContentsGroupToggle(t_id) {
	//display:none
	var c = $('cms8341-calendar');
	if(c.style.display=='block') c.style.display = 'none';
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	// main
	var td    = $('cms_group_cell_'+t_id);
	var icon  = $('cms_group_icon_'+t_id);
	var block = $('cms_group_block_'+t_id);
	var cnd = block.style.display;
	var bgcss = 'url('+cms8341admin_path+'/page/workflow/images/bg_open.jpg) center repeat-y';
	if(cnd=='none') {
		td.style.background = bgcss;
		icon.src = cms8341admin_path+'/page/workflow/images/icon_minus.jpg';
		block.style.display = 'block';
		var st = (document.compatMode == "CSS1Compat") ? document.documentElement.scrollTop: document.body.scrollTop;
		var ey = event.clientY;
		var eh = td.offsetHeight;
		var wh = document.documentElement.clientHeight;
		var sc_sw = ey + eh > wh ? true:false;
		if(sc_sw) {
			var smax = (ey+eh) - wh + 20;
			var s = 0;
			cxAutoScroll(smax);
		}
		//new Effect.ScrollTo('cms_group_block_'+t_id,{duration:0.5});
	} else {
		td.style.background = 'none';
		icon.src = cms8341admin_path+'/page/workflow/images/icon_plus.jpg';
		block.style.display = 'none';
	}
}
//revise submit
function cxRevise(id) {
	document.cms_fApprove.cms_group_id.value = id;
	document.cms_fApprove.cms_dispMode.value = 'revise';
	document.cms_fApprove.submit();
	return false;
}
//approve submit
function cxApprove(id, gid, num) {
	document.cms_fApprove.cms_group_id.value = gid;
	document.cms_fApprove.cms_dispMode.value = 'approve';
	date = StringToDate($(id+'start_'+num).innerHTML,0);
	document.cms_fApprove.cms_publish_start.value = date["y"] + "-" + date["m"] + "-" + date["d"] + " " + date["h"] + ":00:00";
	date = StringToDate($(id+'end_'+num).innerHTML,0);
	
	if ($(id+'end_'+num).innerHTML == PUB_INDEFINITE) {
		date["y"] = PUB_INDEFINITE_YAER;
		date["m"] = PUB_INDEFINITE_MONTH;
		date["d"] = PUB_INDEFINITE_DAY;
		date["h"] = PUB_INDEFINITE_HOUR;
		document.cms_fApprove.cms_publish_end.value = date["y"] + "-" + date["m"] + "-" + date["d"] + " " + date["h"] + ":00:00";
	}
	else {
		document.cms_fApprove.cms_publish_end.value = date["y"] + "-" + date["m"] + "-" + date["d"] + " " + date["h"] + ":00:00";
	}
	if(id.match(/skip/i)){
		$('cms_isSkip').value = "1";
	}
	$('cms8341-progressmsg').innerHTML = '<p>処理中です...</p>';
	cxComboHidden();
	cxLayer('cms8341-progress',1,500,500);
	document.cms_fApprove.submit();
	return false;
}
//denail submit
function cxDenail(id,gid) {
	if (!$(id+gid).value) {
		alert('否認理由が入力されていません。');
		$(id+gid).focus();
		return false;
	} else if (!cxCheckMachineCode($(id+gid).value)) {
		alert('否認理由に機種依存文字が含まれています。');
		$(id+gid).focus();
		return false;
	}
	//否認ページ取得
	var denial_page_ary = new Array();
	var check_box_ele = document.getElementsByName('cms_denial_page_' + gid + '[]');
	$A(check_box_ele).each( function(obj) { 
		if(obj.checked) denial_page_ary.push(obj.value);
	} );
	// 1件も選択されていない場合
	if(denial_page_ary.length <= 0){
		alert('否認理由入力ページを選択してください。');
		return false;
	}
	
	// 移行作業用：否認時ファイル添付機能
	// 否認が実行された場合は、否認レイヤーのformを送信する
	if (IKOU_MODE == true) {
		// cms_fApproveフォーム内の重複するhiddenパラメータを削除する
		var del_target = document.getElementById('cms_group_id');
		del_target.parentNode.removeChild(del_target);
		del_target = document.getElementById('cms_dispMode');
		del_target.parentNode.removeChild(del_target);
		del_target = document.getElementById('cms_note2');
		del_target.parentNode.removeChild(del_target);
		del_target = document.getElementById('cms_denial_page');
		del_target.parentNode.removeChild(del_target);
		
		// 否認レイヤーのフォーム内に、hidden値を追加
		var add_target = document.getElementById('cms_denial_form');
		var hidden_data = document.createElement("input");
		hidden_data.type = "hidden";
		// cms_group_id
		hidden_data.name = 'cms_group_id';
		hidden_data.id = 'cms_group_id';
		hidden_data.value = gid;
		add_target.appendChild(hidden_data);
		// cms_dispMode
		hidden_data = document.createElement("input");
		hidden_data.type = "hidden";
		hidden_data.name = 'cms_dispMode';
		hidden_data.id = 'cms_dispMode';
		hidden_data.value = 'denail';
		add_target.appendChild(hidden_data);
		// cms_dispMode
		hidden_data = document.createElement("input");
		hidden_data.type = "hidden";
		hidden_data.name = 'cms_note2';
		hidden_data.id = 'cms_note2';
		hidden_data.value = $(id+gid).value;
		add_target.appendChild(hidden_data);
		// cms_denial_page
		hidden_data = document.createElement("input");
		hidden_data.type = "hidden";
		hidden_data.name = 'cms_denial_page';
		hidden_data.id = 'cms_denial_page';
		hidden_data.value = denial_page_ary.join(',');
		add_target.appendChild(hidden_data);
	}
	else {
		//main
		document.cms_fApprove.cms_group_id.value = gid;
		document.cms_fApprove.cms_dispMode.value = 'denail';
		document.cms_fApprove.cms_note2.value = $(id+gid).value;
		document.cms_fApprove.cms_denial_page.value = denial_page_ary.join(',');
	}
	
	if(id.match(/skip/i)){
		$('cms_isSkip').value = "1";
	}
	$('cms8341-progressmsg').innerHTML = '<p>処理中です...</p>';
	cxComboHidden();
	cxLayer('cms8341-progress',1,500,500);
	// 移行作業用：否認時ファイル添付機能
	// 移行モード有効時は否認理由レイヤーのformをsubmitする(添付ファイル対応)
	if (IKOU_MODE == true) {
		document.cms_denial_form.submit();
	}
	else {
		document.cms_fApprove.submit();
	}
	return false;
}

/**
* 否認理由レイヤー表示
* @param gid グループID
* @param is_skip スキップ承認フラグ
* @return false;
*/
function cxDenailReason(gid,is_skip) {
	WorkFlowdelLayer();
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	
	var note_id = (is_skip && is_skip == 1) ? 'cms_note2_skip_' : 'cms_note2_';
	$('cms-denail-submit').onclick = function(){ return cxDenail(note_id, gid); };

	// 移行作業用：否認時ファイル添付機能
	// 否認理由入力ダイアログのサイズ調整
	$('cms_denail_note_td').innerHTML = '<textarea name="' + note_id + gid + '" rows="5" id="' + note_id + gid + '" style="width: 320px;"></textarea>';
	
	$('cms_denail_pages_td').innerHTML = '';
	
	Element.show('cms-denail-progress');
	Element.hide('cms_denail_table');
	
	// 否認対象ページを取得する
	var prm = 'cms_group_id='+gid;
	cxAjaxCommand('cxGetDenailPageStr', prm, cxGetDenailPageStrOK);
	// レイヤー表示
	cxComboHidden();
	cxLayer('cms8341-denailreason',1,600,375);
}
/**
* Ajaxで取得した否認対象ページを表示する
* @param r Ajaxの戻り値
* @return false;
*/
function cxGetDenailPageStrOK(r){
	var rText = r.responseText;
	if(rText == 'false') {
		delLayer('cms8341-denailreason');
		$('cms8341-errormsg').innerHTML = '<p>承認依頼ページ情報を取得できませんでした。<br>※別ユーザーの作業によりページの状態が変更されている可能性があります。<p>';
		cxLayer('cms8341-error',1,500,375);
		return false;
	}
	$('cms_denail_pages_td').innerHTML = rText;
	
	// 1ページしかない場合は否認対象ページを非表示
	
	var check_box_ele = $('cms_denail_pages_td').getElementsByTagName('input');
	if(check_box_ele.length < 2){
		check_box_ele[0].disabled = true;
	}
	
	Element.hide('cms-denail-progress');
	Element.show('cms_denail_table');
	return false;
}
//search
function cxSearch() {
	var msg = new Array();
	var pdsy       = $('cms_pdsy');
	var pdsm       = $('cms_pdsm');
	var pdsd       = $('cms_pdsd');
	var pdey       = $('cms_pdey');
	var pdem       = $('cms_pdem');
	var pded       = $('cms_pded');
	if(pdsy.value || pdsm.value || pdsd.value) {
		if(!pdsy.value || !pdsm.value || !pdsd.value) {
			msg.push('公開日の指定をする場合は、年月日すべてを指定してください。');
		}
	}
	if(pdey.value || pdem.value || pded.value ) {
		if(!pdey.value || !pdem.value || !pded.value ) {
			msg.push('公開日の指定をする場合は、年月日すべてを指定してください。');
		}
	}
	var dateObj = new Object();
	dateObj.sy = pdsy.value;
	dateObj.sm = pdsm.value;
	dateObj.sd = pdsd.value;
	dateObj.ey = pdey.value;
	dateObj.em = pdem.value;
	dateObj.ed = pded.value;
	var dc = cxDateCheckSearch(dateObj);
	msg = msg.concat(dc);
	// エラーがある場合
	if(msg.length>=1 && msg[0]!='') {
		var output_msg = '<p>';
		for(var i=0;i<msg.length;i++) {
			output_msg += msg[i] + '<br>';
		}
		output_msg += '</p>';
		$('cms8341-errormsg').innerHTML = output_msg;
		cxComboHidden();
		cxLayer('cms8341-error',1,500,375);
	}
	else{
		var disp_Num = $('dispNum_publicwaitlist').value;
		// main
		$('cms8341-publicwaitlist').innerHTML = '<p>検索中です...</p>';
		// Search Ajax
		// ページID検索
		var page_id = $('cms_search_page_id').value;
		var page_title   = $('cms_search_page_title').value;
		page_title = page_title.replace('&', '＆');
		var search_keywords   = $('cms_search_keywords').value;
		search_keywords = search_keywords.replace('&', '＆');
		var is_tag_search = ($('cms_is_tag_search_1').checked == true) ? FLAG_ON : FLAG_OFF;
		var prm = 'page_title=' + page_title;
		// ページID検索
		prm += '&page_id=' + page_id;
		prm += '&search_keywords=' + search_keywords;
		prm += '&is_tag_search=' + is_tag_search;
		prm += '&pdsy=' + pdsy.value;
		prm += '&pdsm=' + pdsm.value;
		prm += '&pdsd=' + pdsd.value;
		prm += '&pdey=' + pdey.value;
		prm += '&pdem=' + pdem.value;
		prm += '&pded=' + pded.value;
		prm += '&mode=search';
		view_target_list(1,disp_Num,'publicwaitlist',prm);
	}
}
//search
function cxLastSearch() {
	//Search Ajax
	var disp_Num = $('dispNum_publicwaitlist').value;
	$('cms8341-publicwaitlist').innerHTML = '<p>検索中です...</p>';
	prm = 'mode=last_condition';
	view_target_list(1,disp_Num,'publicwaitlist',prm);
}
function search_rewrite(){
	//検索項目書き直し
	// ページID検索
	$('cms_search_page_id').value = $('search_page_id').value;
	$('cms_search_page_title').value = $('search_page_title').value;
	$('cms_search_keywords').value = $('search_keywords').value;
	$('cms_pdsy').value = $('search_pdsy').value;
	$('cms_pdsm').value = $('search_pdsm').value;
	$('cms_pdsd').value = $('search_pdsd').value;
	$('cms_pdey').value = $('search_pdey').value;
	$('cms_pdem').value = $('search_pdem').value;
	$('cms_pded').value = $('search_pded').value;
	if($('is_tag_search').value == FLAG_ON){
		$('cms_is_tag_search_1').checked = true;
	}
	else{
		$('cms_is_tag_search_0').checked = true;
	}
}
//date check
function cxDateCheckSearch(obj) {
	var retAry = new Array();
	var stat;
	var c_days;
	// charactor check
	if(obj.sy) {
		stat = cxDateNumeric(obj.sy);
		if(!stat) {
			retAry.push('公開日（年）に数字ではない文字列が入力されています。');
			obj.sy = false;
		} else if(Number(obj.sy) < 2000) {
			retAry.push('公開日（年）は2000年以降を指定してください。');
			obj.sy = false;
		}
	}
	if(obj.sm) {
		stat = cxDateNumeric(obj.sm);
		if(!stat) {
			retAry.push('公開日（月）に数字ではない文字列が入力されています。');
			obj.sm = false;
		} else if(Number(obj.sm) < 1 || Number(obj.sm) > 12) {
			retAry.push('公開日（月）には 1 ～ 12 を指定してください。');
			obj.sm = false;
		}
	}
	if(obj.sd) {
		stat = cxDateNumeric(obj.sd);
		if(!stat) {
			retAry.push('公開日（日）に数字ではない文字列が入力されています。');
			obj.sd = false;
		} else if(Number(obj.sd) < 1 || Number(obj.sd) > 31) {
			retAry.push('公開日（日）には 1 ～ 31 を指定してください。');
			obj.sd = false;
		}
	}
	if(obj.ey) {
		stat = cxDateNumeric(obj.ey);
		if(!stat) {
			retAry.push('公開日（年）に数字ではない文字列が入力されています。');
			obj.ey = false;
		} else if(Number(obj.ey) < 2000) {
			retAry.push('公開日（年）は2000年以降を指定してください。');
			obj.ey = false;
		}
	}
	if(obj.em) {
		stat = cxDateNumeric(obj.em);
		if(!stat) {
			retAry.push('公開日（月）に数字ではない文字列が入力されています。');
			obj.em = false;
		} else if(Number(obj.em) < 1 || Number(obj.em) > 12) {
			retAry.push('公開日（月）には 1 ～ 12 を指定してください。');
			obj.em = false;
		}
	}
	if(obj.ed) {
		stat = cxDateNumeric(obj.ed);
		if(!stat) {
			retAry.push('公開日（日）に数字ではない文字列が入力されています。');
			obj.ed = false;
		} else if(Number(obj.ed) < 1 || Number(obj.ed) > 31) {
			retAry.push('公開日（日）には 1 ～ 31 を指定してください。');
			obj.ed = false;
		}
	}
	//
	return retAry;
}
//**060704
var cmsALnkObj = new Object();
function cxAutoLinksSet() {
	//keep
	var auto_links = new Array();
	var alElem = document['cms_fProperty2']['cms_auto_link[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			if(alElem.checked) {
				auto_links.push(true);
			} else {
				auto_links.push(false);
			}
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				if(alElem[i].checked) {
					auto_links.push(true);
				} else {
					auto_links.push(false);
				}
			}
		}
	}
	cmsALnkObj.auto_links  = auto_links;
	cmsALnkObj.index_title = $('cms_index_title').value.replace(/"/g,'&quot;');
	// open
	cxComboHidden();
	cxLayer('cms8341-autolinks',1,350,470);
}
//autolinks layer events
function cxAutoLinksClose() {
	//close
	delLayer('cms8341-autolinks');
	// reset
	var alElem = document['cms_fProperty2']['cms_auto_link[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			if(cmsALnkObj.auto_links[0]) {
				alElem.checked = true;
			} else {
				alElem.checked = false;
			}
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				if(cmsALnkObj.auto_links[i]) {
					alElem[i].checked = true;
				} else {
					alElem[i].checked = false;
				}
			}
		}
	}
	$('cms_index_title').value   =  cmsALnkObj.index_title;
}
function cxAutoLinksSubmit() {
	var auto_links = '';
	var alElem = document['cms_fProperty2']['cms_auto_link[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			if(alElem.checked) {
				auto_links = alElem.value;
			}
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				if(alElem[i].checked) {
					auto_links += alElem[i].value+',';
				}
			}
		}
	}
	var index_title = $('cms_index_title').value;
	index_title = index_title.replace('&', '＆');
	var prop_page_id = $('cms_prop_page_id').value;
	var prm = 'page_id='+prop_page_id+'&auto_links='+auto_links+'&index_title='+index_title;
	cxAjaxCommand('cxALinksEdit', prm, cxALinksEditSuccess);
}
function cxALinksEditSuccess(r) {
	var rText = r.responseText;
	var labels = new Array();
	var alElem = document['cms_fProperty2']['cms_auto_link[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			if (alElem.checked) {
				labels.push(cxGetLabelText(alElem.id));
			}
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				if(alElem[i].checked) {
					labels.push(cxGetLabelText(alElem[i].id));
				}
			}
		}
	}
	var li = '';
	for(var j=0;j<labels.length;j++) {
		if(labels[j] && labels[j]!='') {
			li += '<li>' + labels[j] + '</li>';
		}
	}
	if(li) {
		$('cms-auto-links').innerHTML = li;
		$('cms-auto-links').style.display = 'block';
		if($F('cms_index_title') == ""){
			$('cms-link-title').innerHTML = "リンク掲載用タイトルは設定されていません。";
		} else {
			$('cms-link-title').innerHTML = "リンク掲載用タイトルに【"+cxEscapeHtmlChars($('cms_index_title').value) + "】を設定します。";
		}
		$('cms-link-title').style.display = 'block';
	} else {
		$('cms-auto-links').style.display = 'none';
		$('cms-link-title').style.display = 'none';
	}
	
	//close
	delLayer('cms8341-autolinks');
}
function cxGetLabelText(e_id) {
	var le = document.getElementsByTagName('label');
	for(var i=0;i<le.length;i++) {
		var o = le[i].outerHTML;
		var c = o.indexOf(e_id);
		if(c!=-1) {
			return le[i].innerHTML;
		}
	}
	//return false;
}

// PublicSetting open
function cxPublicSetting(id, num) {
	active_menu = '';
	active_id = '';
	ys = $(id+'start_'+num).innerHTML;
	ye = $(id+'end_'+num).innerHTML;
	WorkFlowdelLayer();
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	
	date = StringToDate(ys,1);
	$('cms_psy_l').value = date["y"];
	$('cms_psm_l').value = date["m"];
	$('cms_psd_l').value = date["d"];
	$('cms_psh_l').value = date["h"];

	if (ye == PUB_INDEFINITE) {
		$('cms_pey_l').value = "";
		$('cms_pem_l').value = "";
		$('cms_ped_l').value = "";
		$('cms_peh_l').value = "";
		cxPublicDisabledTrue();
	}
	else if (USE_INDEFINITE == true) {
		date = StringToDate(ye,1);
		$('cms_pey_l').value = date["y"];
		$('cms_pem_l').value = date["m"];
		$('cms_ped_l').value = date["d"];
		$('cms_peh_l').value = date["h"];
		cxPublicDisabledFalse();
	}
	else {
		date = StringToDate(ye,1);
		$('cms_pey_l').value = date["y"];
		$('cms_pem_l').value = date["m"];
		$('cms_ped_l').value = date["d"];
		$('cms_peh_l').value = date["h"];
	}
	
	cxComboHidden();
	cxLayer('cms8341-public_setting',1,502,380);
	active_menu = num;
	active_id = id;
}
function cxPublicDisabledTrue(){
	$('cms_pey_l').disabled = true;
	$('cms_pem_l').disabled = true;
	$('cms_ped_l').disabled = true;
	$('cms_peh_l').disabled = true;
	$('cms-pubend-Unrestricted-wf').checked = true;
	$('cms_pey_l').style.backgroundColor="#C0C0C0";
	$('cms_pem_l').style.backgroundColor="#C0C0C0";
	$('cms_ped_l').style.backgroundColor="#C0C0C0";
	$('cms_peh_l').style.backgroundColor="#C0C0C0";
}

function cxPublicDisabledFalse(){
	$('cms_pey_l').disabled = false;
	$('cms_pem_l').disabled = false;
	$('cms_ped_l').disabled = false;
	$('cms_peh_l').disabled = false;
	$('cms-pubend-Unrestricted-wf').checked = false;
	$('cms_pey_l').style.backgroundColor="#FFFFFF";
	$('cms_pem_l').style.backgroundColor="#FFFFFF";
	$('cms_ped_l').style.backgroundColor="#FFFFFF";
	$('cms_peh_l').style.backgroundColor="#FFFFFF";
}

function cxPublicSettingSubmit(){
	var msg = new Array();
	var publish_start = $F('cms_psy_l') + "年" 
	+ $F('cms_psm_l') + "月" 
	+ $F('cms_psd_l') +"日" 
	+ $F('cms_psh_l') + "時"
	
	if (USE_INDEFINITE && $('cms-pubend-Unrestricted-wf') && $('cms-pubend-Unrestricted-wf').checked) {
		var publish_end = PUB_INDEFINITE;
// cxPublicEndUnrestricted();
		$('cms_pey_l').value = PUB_INDEFINITE_YAER;
		$('cms_pem_l').value = PUB_INDEFINITE_MONTH;
		$('cms_ped_l').value = PUB_INDEFINITE_DAY;
		$('cms_peh_l').value = PUB_INDEFINITE_HOUR;
	}
	else if (USE_INDEFINITE && $('cms_pey_l').value == PUB_INDEFINITE_YAER && $('cms_pem_l').value == PUB_INDEFINITE_MONTH && $('cms_peh_l').value == PUB_INDEFINITE_HOUR && $F('cms_ped_l') == PUB_INDEFINITE_DAY){
		var publish_end = PUB_INDEFINITE;
	}
	else {
		var publish_end = $F('cms_pey_l') + "年" 
		+ $F('cms_pem_l') + "月" 
		+ $F('cms_ped_l') +"日" 
		+ $F('cms_peh_l') + "時"
	}
	if(!$F('cms_psy_l') || !$F('cms_psm_l') || !$F('cms_psd_l') || !$F('cms_psh_l') 
	    || !$F('cms_pey_l') || !$F('cms_pem_l') || !$F('cms_ped_l') || !$F('cms_peh_l')) {
		msg.push('公開期間に入力されていない箇所があります。');
	}
	var dateObj = new Object();
	dateObj.sy = $F('cms_psy_l');
	dateObj.sm = $F('cms_psm_l');
	dateObj.sd = $F('cms_psd_l');
	dateObj.sh = $F('cms_psh_l');
	dateObj.ey = $F('cms_pey_l');
	dateObj.em = $F('cms_pem_l');
	dateObj.ed = $F('cms_ped_l');
	dateObj.eh = $F('cms_peh_l');
	var dc = cxDateCheck(dateObj);
	msg = msg.concat(dc);
	//
	if(msg.length>=1 && msg[0]!='') {
		var output_msg = '<p>';
		for(var i=0;i<msg.length;i++) {
			output_msg += msg[i] + '<br>';
		}
		output_msg += '</p>';
		$('cms8341-errormsg').innerHTML = output_msg;
		cxComboHidden();
		cxLayer('cms8341-error',1,500,375);
	} else {
		$(active_id+'start_'+active_menu).innerHTML = publish_start;
		delLayer('cms8341-public_setting');
		$(active_id+'end_'+active_menu).innerHTML = publish_end;
	}
}


// 取り戻し
function cxRegain(pid) {
	//main
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	if (!confirm("承認依頼の取り戻しを行います。\nよろしいですか？")) {
		return false;
	}
	$('cms8341-progressmsg').innerHTML = '<p>処理中です...</p>';
	cxComboHidden();
	cxLayer('cms8341-progress',1,500,500);
	// Search Ajax
	var prm = 'page_id='+pid;
	cxAjaxCommand('cxRegain', prm, cxRegainSuccess);
}
function cxRegainSuccess(r) {
	delLayer('cms8341-progress');
	var rText = r.responseText;
	if (rText == 'false') {
		alert('取り戻しに失敗しました。');
		return false;
	}
	location.href = rText;
}


function cxAreaBox() {
	if($('cms8341-approvelist_none')){
		Element.hide($('cms8341-approvelist'));
		$('cms-approveSwitch').src= cms8341admin_path+"/images/btn/btn_open_mini.jpg"
		$('cms-approveSwitch').alt= "開く"
	} else {
		Element.show($('cms8341-approvelist'));
		$('cms-approveSwitch').src= cms8341admin_path+"/images/btn/btn_close_mini.jpg"
		$('cms-approveSwitch').alt= "閉じる"
	}
	if($('cms8341-progresslist')){
		if($('cms8341-progresslist_none')){
			Element.hide($('cms8341-progresslist'));
			$('cms-progressSwitch').alt= "開く"
			$('cms-progressSwitch').src= cms8341admin_path+"/images/btn/btn_open_mini.jpg"
		} else {
			Element.show($('cms8341-progresslist'));
			$('cms-progressSwitch').alt= "閉じる"
			$('cms-progressSwitch').src= cms8341admin_path+"/images/btn/btn_close_mini.jpg"
		}
	}
	if($('cms8341-skiplist')){
		if($('cms8341-skiplist_none')){
			Element.hide($('cms8341-skiplist'));
			$('cms-skipSwitch').alt= "開く"
			$('cms-skipSwitch').src= cms8341admin_path+"/images/btn/btn_open_mini.jpg"
		} else {
			Element.show($('cms8341-skiplist'));
			$('cms-skipSwitch').alt= "閉じる"
			$('cms-skipSwitch').src= cms8341admin_path+"/images/btn/btn_close_mini.jpg"
		}
	}
	if($('cms8341-waitinglist_none')){
		Element.hide($('cms8341-waitinglist'));
		$('cms-waitingSwitch').alt= "開く"
		$('cms-waitingSwitch').src= cms8341admin_path+"/images/btn/btn_open_mini.jpg"
	} else {
		Element.show($('cms8341-waitinglist'));
		$('cms-waitingSwitch').alt= "閉じる"
		$('cms-waitingSwitch').src= cms8341admin_path+"/images/btn/btn_close_mini.jpg"
	}
}

/**
 * ページ番号をPOSTする(承認依頼されたグループ)
 * @param page ページ番号
 * @return false
 */
function cxPageSet_Approvelist(page){
	//エリアが存在しなければ、無視
	if($('dispNum_approvelist')){
		//ページ番号が無い場合は、1ページに設定
		if(page == "") page = 1;
		view_target_list(page,$('dispNum_approvelist').value,'approvelist');
	}
	return false;
}

/**
 * ページ番号をPOSTする(承認待ちグループ)
 * @param page ページ番号
 * @return false
 */
function cxPageSet_Progresslist(page){
	//エリアが存在しなければ、無視
	if($('dispNum_progresslist')){
		//ページ番号が無い場合は、1ページに設定
		if(page == "") page = 1;
		view_target_list(page,$('dispNum_progresslist').value,'progresslist');
	}
	return false;
}

/**
 * ページ番号をPOSTする(承認依頼予定のグループ)
 * @param page ページ番号
 * @return false
 */
function cxPageSet_Skiplist(page){
	//エリアが存在しなければ、無視
	if($('dispNum_skiplist')){
		//ページ番号が無い場合は、1ページに設定
		if(page == "") page = 1;
		view_target_list(page,$('dispNum_skiplist').value,'skiplist');
	}
	return false;
}

/**
 * ページ番号をPOSTする(公開待ちページリスト)
 * @param page ページ番号
 * @return false
 */
function cxPageSet_Publicwaitlist(page){
	//エリアが存在しなければ、無視
	if($('dispNum_publicwaitlist')){
		//ページ番号が無い場合は、1ページに設定
		if(page == "") page = 1;
		// 検索を行なった条件を一緒にPOSTする
		var prm = "";
		prm += 'page_title=' + ($('search_page_title').value ? $('search_page_title').value : "");
		// ページID検索
		prm += '&page_id=' + ($('search_page_id').value ? $('search_page_id').value : "");
		prm += '&search_keywords=' + ($('search_keywords').value ? $('search_keywords').value : "");
		prm += '&is_tag_search=' + ($('is_tag_search').value ? $('is_tag_search').value : "");
		prm += '&pdsy=' + ($('search_pdsy').value ? $('search_pdsy').value : "");
		prm += '&pdsm=' + ($('search_pdsm').value ? $('search_pdsm').value : "");
		prm += '&pdsd=' + ($('search_pdsd').value ? $('search_pdsd').value : "");
		prm += '&pdey=' + ($('search_pdey').value ? $('search_pdey').value : "");
		prm += '&pdem=' + ($('search_pdem').value ? $('search_pdem').value : "");
		prm += '&pded=' + ($('search_pded').value ? $('search_pded').value : "");
		view_target_list(page,$('dispNum_publicwaitlist').value,'publicwaitlist',prm);
	}
	return false;
}

/**
 * 表示件数を変える
 * @param prev_num 表示件数
 * @param target_sorce 呼び出し元のソース
 * @return false
 */
function cxDispNum(prev_num,target_sorce){
	var prm = "";
	// 公開待ちの場合のみ、検索を行なった条件を一緒にPOSTする
	if(target_sorce == "publicwaitlist"){
		prm += 'page_title=' + ($('search_page_title').value ? $('search_page_title').value : "");
		// ページID検索
		prm += '&page_id=' + ($('search_page_id').value ? $('search_page_id').value : "");
		prm += '&search_keywords=' + ($('search_keywords').value ? $('search_keywords').value : "");
		prm += '&is_tag_search=' + ($('is_tag_search').value ? $('is_tag_search').value : "");
		prm += '&pdsy=' + ($('search_pdsy').value ? $('search_pdsy').value : "");
		prm += '&pdsm=' + ($('search_pdsm').value ? $('search_pdsm').value : "");
		prm += '&pdsd=' + ($('search_pdsd').value ? $('search_pdsd').value : "");
		prm += '&pdey=' + ($('search_pdey').value ? $('search_pdey').value : "");
		prm += '&pdem=' + ($('search_pdem').value ? $('search_pdem').value : "");
		prm += '&pded=' + ($('search_pded').value ? $('search_pded').value : "");
	}
	view_target_list(1,prev_num,target_sorce,prm);
	return false;
}

/**
 * 対象のリストを取得する
 * @param page ページ番号
 * @param prev_num 表示件数
 * @param target_sorce 呼び出し元のソース
 * @param param 付加する（POSTする）パラメータ
 * @return false
 */
function view_target_list(page,prev_num,target_sorce,param){
	//レイヤーを消す
	WorkFlowdelLayer();
	// 表示用PHPを呼び出す(Ajax)
	var prm = 'cms_page=' + page + '&maxrow=' + prev_num;
	if(param) prm += '&' + param;
	var a = new Ajax.Request(
		baseUrl + 'admin/page/workflow/' + target_sorce + '.php',
		{
			method: 'post',
			postBody: prm,
			//成功した場合
			onComplete: function(originalRequest){
				if(originalRequest.responseText != "") {
					$('cms8341-' + target_sorce).innerHTML = originalRequest.responseText;
					search_rewrite();
				}
				else $('cms8341-' + target_sorce).innerHTML = "<p>情報の取得に失敗しました</p>";
			},
			//失敗した場合
			onFailure: function(request){
				alert('情報の取得に失敗しました');
			}
		}   
	);
	return false;
}

/**
 * 対象のレイヤーを消す
 * @param layer_id レイヤーのID
 * @return false;
 */
function delLayer(layer_id){
	cxLayer(layer_id,0);
	try{
		if($('cms8341-public_setting') && $('cms8341-public_setting').style.display == 'block') throw "";
		if($('cms8341-calendar') && $('cms8341-calendar').style.display == 'block') throw "";
		if($('cms8341-property') && $('cms8341-property').style.display == 'block') throw "";
		if($('cms8341-pubCancel') && $('cms8341-pubCancel').style.display == 'block') throw "";
		if($('cms8341-autolinks') && $('cms8341-autolinks').style.display == 'block') throw "";
		if($('cms8341-error') && $('cms8341-error').style.display == 'block') throw "";
		if($('cms8341-progress') && $('cms8341-progress').style.display == 'block') throw "";
		if($('cms8341-denial') && $('cms8341-denial').style.display == 'block') throw "";
		if($('cms8341-denailreason') && $('cms8341-denailreason').style.display == 'block') throw "";
		cxComboVisible();
	}
	catch(e){}
	return false;
}

/**
 * レイヤーをすべて消す
 */
function WorkFlowdelLayer(){
	if($('cms8341-property') && $('cms8341-property').style.display == 'block') delLayer('cms8341-property',0);
	if($('cms8341-public_setting') && $('cms8341-public_setting').style.display == 'block') delLayer('cms8341-public_setting',0);
	if($('cms8341-error') && $('cms8341-error').style.display == 'block') delLayer('cms8341-error',0);
	if($('cms8341-pubCancel') && $('cms8341-pubCancel').style.display == 'block') delLayer('cms8341-pubCancel',0);
	if($('cms8341-calendar') && $('cms8341-calendar').style.display == 'block') delLayer('cms8341-calendar',0);
	if($('cms8341-denial') && $('cms8341-denial').style.display == 'block') delLayer('cms8341-denial',0);
	if($('cms8341-denailreason') && $('cms8341-denailreason').style.display == 'block') delLayer('cms8341-denailreason',0);
}
/**
 * 全て選択
 * @param gid グループID
 * @return
 */
function cxCheckAll(gid) {
	var alElem = document.getElementsByName('cms_denial_page_' + gid + '[]');
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = true;
		// some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = true;
			}
		}
	}
}
/**
 * 全て解除
 * @param gid グループID
 * @return
 */
function cxReleaseAll(gid) {
	var alElem = document.getElementsByName('cms_denial_page_' + gid + '[]');
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = false;
		// some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = false;
			}
		}
	}
}
/**
 * common_action.js#cxCalendarClose()のオーバーライド
 * 
 */
function cxCalendarClose(){
	edit_closet_flg = false;
	delLayer('cms8341-calendar');
}

//ロード時のイベントを登録
Event.observe(window,'load',cxAreaBox,false);
