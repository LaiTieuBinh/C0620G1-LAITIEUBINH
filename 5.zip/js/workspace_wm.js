/*
 * ワークスペース（ウェブマスター用）
 */
﻿//contentsmenu preload images
cxPreImages(cms8341admin_path+'/images/contentsmenu/menu_edit01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_cansel01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_pageadd01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_linkcheck01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_accessibilitycheck01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_totalcheck01.jpg',				// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_spellcheck01.jpg',				// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_headlinecheck01.jpg',		// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_contrastcheck01.jpg',		// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_pageproperty01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_edhitpreview01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_publicpreview01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_preview01.jpg',
			cms8341admin_path+'/page/workflow/images/icon_minus.jpg',
			cms8341admin_path+'/page/workflow/images/bg_open.jpg',
			cms8341admin_path+'/images/menu/logout01_btn.jpg',
			cms8341admin_path+'/images/menu/logout02_btn.jpg');


