/*
 * ワークスペース
 */
//contentsmenu preload images
cxPreImages(cms8341admin_path+'/images/contentsmenu/menu_edit01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_cansel01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_pageadd01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_linkcheck01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_accessibilitycheck01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_totalcheck01.jpg',				// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_spellcheck01.jpg',				// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_headlinecheck01.jpg',		// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_contrastcheck01.jpg',		// CMS-8341 Version2
			cms8341admin_path+'/images/contentsmenu/menu_pageproperty01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_edhitpreview01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_publicpreview01.jpg',
			cms8341admin_path+'/images/contentsmenu/menu_preview01.jpg',
			cms8341admin_path+'/page/workflow/images/icon_minus.jpg',
			cms8341admin_path+'/page/workflow/images/bg_open.jpg',
			cms8341admin_path+'/images/menu/logout01_btn.jpg',
			cms8341admin_path+'/images/menu/logout02_btn.jpg');

// request unlock flg
var cms_unLock = true;

//request click
var cms_request_lck = false;
function cxRequestSet() {
	//request lock check
	if(cms_request_lck) return;
	//display:none
	var c = $('cms8341-calendar');
	if(c.style.display=='block') c.style.display = 'none';
	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	//get form object
	var fe = document['cms_fAppreq'].elements['cms_page_id[]'];
	//form check & get selected param
	var r_param = false
	if (fe) {
		//one checkbox
		if (!fe.length && fe.value) {
			if (fe.checked) {
				r_param = fe.value;
			}
		//some checkboxes
		} else {
			for(var i=0;i<fe.length;i++) {
				if(fe[i].checked) {
					if(!r_param) {
						r_param = fe[i].value;
					} else {
						r_param += ',' + fe[i].value;
					}
				}
			}
		}
	}
	if(!r_param) {
		alert('承認依頼するページを選択してください。');
		return;
	}
	//request lock
	cms_request_lck = true;
	//form disabled:true
	if (!fe.length && fe.value) {
		fe.disabled = 'true';
	} else {
		for(var i=0;i<fe.length;i++) {
			fe[i].disabled = 'true';
		}
	}
	//processing
	$('cms8341-progressmsg').innerHTML = '<p>承認依頼、対象ファイルのチェック中です...</p>';
	cxLayer('cms8341-progress',1,500,375);
	//Approve request page check (approve flow and links) Ajax
	var prm = 'cms_page_id=' + r_param;
	cxAjaxCommand('cxChkApproveRequest', prm, cxChkResult);
}
//Ajax Response Success
function cxChkResult(r) {
	//progress layer:none
	cxLayer('cms8341-progress',0);
	cms_unLock = true;
	var fe = document['cms_fAppreq'].elements['cms_page_id[]'];
	//form check & get selected param
	var cnt = 0;
	var other = "";
	if (fe) {
		//one checkbox
		if (!fe.length && fe.value) {
		//some checkboxes
		} else {
			for(var i=0;i<fe.length;i++) {
				if(fe[i].checked) cnt++;
			}
		}
	}
	if(cnt > 1){
		cnt--;
		other = "、他"+cnt+"ページ";
	}
	//return
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName == 'ok') {
		//set approve_id
		$('cms_approve_id').value = xmlDoc.attributes.getNamedItem('approve_id').value;
		$('cms_group_name').value = xmlDoc.attributes.getNamedItem('page_title').value + other;
		//request layer open
		cxLayer('cms8341-request',1,500,400);
		$('cms_group_name').focus();
	} else if (xmlDoc.nodeName == 'alert') {
		//set approve_id
		$('cms_approve_id').value = xmlDoc.attributes.getNamedItem('approve_id').value;
		$('cms_group_name').value = xmlDoc.attributes.getNamedItem('page_title').value + other;
		//causion layer open
		var msg;
		msg = xmlDoc.textContent+'<p>承認依頼しますか？</p>';
		$('cms8341-causionmsg').innerHTML = msg;
		cxLayer('cms8341-causion',1,500,375);
	} else if (xmlDoc.nodeName == 'error') {
		$('cms8341-errormsg').innerHTML = xmlDoc.textContent;
		cxLayer('cms8341-error',1,500,375);
	} else {
		cxFailure();
	}
}
//Ajax Response Failure
function cxFailure() {
	cms_request_lck = false;
	cxLayer('cms8341-progress',0);
	$('cms8341-errormsg').innerHTML = '<p align="center">認証処理中に通信エラーが発生しました</p>';
	cms_unLock = true;
	cxLayer('cms8341-error',1,500,375);
}
//causion layer yes
function cxCausionYes() {
	//causion layer:none
	cxLayer('cms8341-causion',0);
	//request layer open
	cxLayer('cms8341-request',1,500,400);
	$('cms_group_name').focus();
}
//close layer
function cxLayerClose(name) {
	//request unlock
	if (cms_unLock) {
		cms_request_lck = false;
		//form disabled:none
		var fe = document['cms_fAppreq'].elements['cms_page_id[]'];
		if (fe) {
			if (!fe.length && fe.value) {
				fe.disabled = '';
			} else {
				for(var i=0;i<fe.length;i++) {
					fe[i].disabled = '';
				}
			}
		}
	}
	if ($('cms-pubend-Unrestricted-ws') && $('cms-pubend-Unrestricted-ws').checked == true) {
		if ($('cms_pdey') && !$('cms_pdey').disabled) {
			cxDisabledChange('cms_pdey');
			cxDisabledChange('cms_pdem');
			cxDisabledChange('cms_pded');
			cxDisabledChange('cms_pdeh');
		}
	}
	cms_unLock = true;
	//layer:none
	cxLayer(name,0);
}
//request layer close
function cxRequestClose() {
	//form reset
	$('cms_group_name').value = '';
	$('cms_note1').value = '';
	//main
	unLock = true;
	cxLayer('cms8341-calendar',0);
	cxLayerClose('cms8341-request');
}
//request layer submit
function cxRequestSubmit() {
	//
	var msg = new Array();
	//get parameters
	var group_name = $('cms_group_name');
	var note1      = $('cms_note1');
	var pdsy       = $('cms_pdsy');
	var pdsm       = $('cms_pdsm');
	var pdsd       = $('cms_pdsd');
	var pdsh       = $('cms_pdsh');	
	
	if($('cms-pubend-Unrestricted-ws') && $('cms-pubend-Unrestricted-ws').checked){
		cxPublicEndUnrestricted();
		var pdey       = $('cms_pdey');
		var pdem       = $('cms_pdem');
		var pded       = $('cms_pded');
		var pdeh       = $('cms_pdeh');
		pdey.value = PUB_INDEFINITE_YAER;
		pdem.value = PUB_INDEFINITE_MONTH;
		pded.value = PUB_INDEFINITE_DAY;
		pdeh.value = PUB_INDEFINITE_HOUR;
	}
	else {
		var pdey       = $('cms_pdey');
		var pdem       = $('cms_pdem');
		var pded       = $('cms_pded');
		var pdeh       = $('cms_pdeh');
	}
			
	//input check
	if(!group_name.value) {
		msg.push('承認グループ名が入力されていません。')
	} else if (!cxCheckMachineCode(group_name.value)) {
		msg.push('承認グループ名に機種依存文字が含まれています。');
	}
	if(!cxCheckMachineCode(note1.value)) {
		msg.push('依頼内容に機種依存文字が含まれています。');
	}
	if(!pdsy.value || !pdsm.value || !pdsd.value || !pdsh.value
	    || !pdey.value || !pdem.value || !pded.value || !pdeh.value) {
		msg.push('公開期間に入力されていない箇所があります。');
		//pdsy.focus();
		//return;
	}
	var dateObj = new Object();
	dateObj.sy = pdsy.value;
	dateObj.sm = pdsm.value;
	dateObj.sd = pdsd.value;
	dateObj.sh = pdsh.value;
	dateObj.ey = pdey.value;
	dateObj.em = pdem.value;
	dateObj.ed = pded.value;
	dateObj.eh = pdeh.value;
	var dc = cxDateCheck(dateObj);
	msg = msg.concat(dc);
	//
	if(msg.length>=1 && msg[0]!='') {
		var output_msg = '<p>';
		for(var i=0;i<msg.length;i++) {
			output_msg += msg[i] + '<br>';
		}
		output_msg += '</p>';
		$('cms8341-errormsg').innerHTML = output_msg;
		cms_unLock = false;
		cxLayer('cms8341-error',1,500,375);
	} else {
		//main submit
		//form disabled:none
		var fe = document['cms_fAppreq'].elements['cms_page_id[]'];
		if (fe) {
			if (!fe.length && fe.value) {
				fe.disabled = '';
			} else {
				for(var i=0;i<fe.length;i++) {
					fe[i].disabled = '';
				}
			}
		}
		document.cms_fAppreq.submit();
		$('cms8341-progressmsg').innerHTML = '<p>承認依頼を申請中です...</p>';
		cxLayer('cms8341-progress',1,500,375);
		return false;
	}
}
