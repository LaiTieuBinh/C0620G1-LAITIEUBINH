/*
 *
 */
cxPreImages(cms8341admin_path+'/images/menu/logout01_btn.jpg',
			cms8341admin_path+'/images/menu/logout02_btn.jpg',
			cms8341admin_path+'/images/btn/btn_open_mini.jpg');


function cxCheckAll() {
	_checkAll(document['cms_fImport']['cms_file_path[]']);
	_checkAll(document['cms_fImport']['cms_item_path[]']);
}

function cxReleaseAll() {
	_releaseAll(document['cms_fImport']['cms_file_path[]']);
	_releaseAll(document['cms_fImport']['cms_item_path[]']);
}

//
function cxSubmit() {
	if ( ( _isChecked(document['cms_fImport']['cms_file_path[]']) == false ) &&
		 ( _isChecked(document['cms_fImport']['cms_item_path[]']) == false ) ) {
		alert('取り込むファイルを選択してください。');
		return false;
	}
	$('cms8341-progressmsg').innerHTML = '<p>処理中です...</p>';
	cxLayer('cms8341-progress',1,500,500);
	document.cms_fImport.submit();
	return false;
}

//
function _checkAll(alElem) {
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = true;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = true;
			}
		}
	}
}
function _releaseAll(alElem) {
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = false;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				alElem[i].checked = false;
			}
		}
	}
}
function _isChecked(alElem) {
	var err = false;
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			if (alElem.checked) err = true;
		//some checkboxes
		} else {
			for(var i=0;i<alElem.length;i++) {
				if (alElem[i].checked) {
					err = true;
					break;
				}
			}
		}
	}
	return err;
}
