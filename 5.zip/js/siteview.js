/*
 *
 */
cxPreImages(cms8341admin_path+'/images/menu/new01_btn.jpg',
		   cms8341admin_path+'/images/menu/new02_btn.jpg',
		   cms8341admin_path+'/images/menu/edit01_btn.jpg',
		   cms8341admin_path+'/images/menu/edit02_btn.jpg',
		   cms8341admin_path+'/images/menu/del01_btn.jpg',
		   cms8341admin_path+'/images/menu/del02_btn.jpg',
		   cms8341admin_path+'/images/menu/totalcheck01_btn.jpg',		// CMS-8341 Version2
		   cms8341admin_path+'/images/menu/totalcheck02_btn.jpg',		// CMS-8341 Version2
			 cms8341admin_path+'/images/contentsmenu/menu_linkcheck01.jpg',
			 cms8341admin_path+'/images/contentsmenu/menu_accessibilitycheck01.jpg',
			 cms8341admin_path+'/images/contentsmenu/menu_spellcheck01.jpg',				// CMS-8341 Version2
			 cms8341admin_path+'/images/contentsmenu/menu_headlinecheck01.jpg',		// CMS-8341 Version2
			 cms8341admin_path+'/images/contentsmenu/menu_contrastcheck01.jpg',		// CMS-8341 Version2
		   cms8341admin_path+'/images/menu/property01_btn.jpg',
		   cms8341admin_path+'/images/menu/property02_btn.jpg',
		   cms8341admin_path+'/images/menu/logout01_btn.jpg',
		   cms8341admin_path+'/images/menu/logout02_btn.jpg');

/* サイトビューの場合の cxLayer
 * cxLayer の前にセレクトボックスを表示・非表示
 */
function cxLayerView(t,sw,w,h) {
	if(sw==1) {
		cxComboHidden();
		//フラッシュ(かん動)の表示を消す
		if($('flashcontent')) $('flashcontent').style.visibility = 'hidden';
	} else {
		cxComboVisible();
		//フラッシュ(かん動)を表示する
		if($('flashcontent')) $('flashcontent').style.visibility = '';
	}
	cxLayer(t,sw,w,h);
}

/**
 * IE8の場合ヘッダーとコンテンツの幅を調整
 */
//Event.observe(window,'load', function() {
//	var ie_var = cxGetIeVersion();
//	// IE8対応 IE9対応
//	if ((ie_var == 8 || ie_var == 9) && $('cms8341-contentsZero') && $('cms8341-headmessage')) {
//		var top = $('cms8341-contentsZero').offsetTop;
//		var height = $('cms8341-headmessage').offsetHeight;
//		$('cms8341-contentsZero').style.top = (top + height) + "px";
//	}
//} ,false);
