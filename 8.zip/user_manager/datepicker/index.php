<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Hướng dẫn tạo Datepicker bằng Bootstrap - hocwebgiare.com</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel='stylesheet prefetch' href='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css'>
<style>
label{margin-left: 20px;}
#datepicker{width:180px; margin: 0 20px 20px 20px;}
#datepicker > span:hover{cursor: pointer;}
</style>
</head>
<body>
<h2 class="text-center">Hướng dẫn tạo Datepicker bằng Bootstrap</h2>
<label>Chọn ngày: </label>
<div id="datepicker" class="input-group date" data-date-format="dd-mm-yyyy">
  <input class="form-control" type="text" readonly />
  <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span> 
</div>
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js'></script>
<script type="text/javascript">
$(function () {
  $("#datepicker").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  }).datepicker('update', new Date());
});
</script>
</body>
</html>