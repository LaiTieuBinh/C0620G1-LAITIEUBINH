<?php
// error_reporting(E_ALL);
ini_set('display_errors', '1');

include('./class/logs.php');

$logs = new Logs();

$res = $logs->logs_info('folder_logs/', 'Database', 'logs_2705', '.txt', 'this is error !!!');

echo $res ? $res : 'failed';

 ?>
 