<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

include('logging.php');

$logger = new Logging();

$logger->set_location('logs/');

//jha-- file type could be DB, File, FileAndDB
$logger->set_type(Logging::File);

//jha-- set 3 to log all only warning and errors
//jha-- remember logs added with level higher than this level will be logged only
$logger->set_level(Logging::Warning);

//jha-- set dtabase credentails
// $logger->set_db_credentails('localhost','root', 'cms-8341', 'test');

//jha-- file type could be Fixed or Daily
$logger->set_file_name(Logging::Daily,'logs','.txt');

//jha-- this will be written
$logger->write('This is Error', Logging::Error);

// //jha-- this will be written
// $logger->write('This is Warning', Logging::Warning);

// //jha-- this will not be written
// $logger->write('This is Warning', Logging::Debug);

// //jha-- this will not be written
// $logger->write('This is Warning', Logging::Info);

//jha-- flush logs
$logger->flush(true, true);

