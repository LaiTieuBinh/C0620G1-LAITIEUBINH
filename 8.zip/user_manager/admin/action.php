<?php
include('../class/User.php');

if (!empty($_POST['action'])) {
	$user = new User();
	$post = Validate::handle_input($_POST['action']);
	
	switch ($post) {
		case 'userDelete': 
			$user->delete_user();
			break;
		case 'getUser': 
			$user->get_user();
			break;
		case 'addUser': 
			$user->add_user();
			break;
		case 'updateUser': 
			$user->update_user();
			break;
		case 'filter': 
			$user->dashboard_filter();
			break;
		default:
			echo 'Failed!';
	}
} else {
	$user = new User();
	$get = Validate::handle_input($_GET['action']);

	if ($_GET['action'] == 'listUser') {
		$user->get_user_list();
	}
}
?>