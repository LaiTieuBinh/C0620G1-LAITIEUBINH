<?php
class dbConfig1 {
    protected $serverName;
    protected $userName;
    protected $password;
    protected $dbName;
    function dbConfig() {
        $this -> serverName = 'localhost';
        $this -> userName = 'root';
        $this -> password = 'cms-8341';
        $this -> dbName = 'my_database';
    }

    // $timeZone = date_default_timezone_set('Asia/Ho_Chi_Minh');
    function set_time_zone ($timeZone) {
        $timeZone = date_default_timezone_set($timeZone);
    }
}
?>